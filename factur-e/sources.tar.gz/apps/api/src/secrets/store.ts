/**
 * `SecretStore` — interface unifiée pour le stockage de bundles
 * `access + refresh` SuperPDP. Cf. ADR-005 D9 sprint-03.
 *
 * Le bundle est sérialisé en JSON puis stocké tel quel — ni l'adapter
 * ni le caller ne touche au format de stockage natif (Keychain item ou
 * Scaleway secret payload). Cela permet d'ajouter d'autres champs
 * (ex. `accessExpiresAt`) sans toucher aux wrappers backend.
 *
 * Le SecretRef (ex. `factur-e-superpdp-{customer_id}-bundle` côté
 * Keychain ou `/factur-e/prod/superpdp/{customer_id}/bundle` côté
 * Scaleway) est calculé par le caller — l'interface est agnostique.
 *
 * Tests : `MemorySecretStore` ne touche aucune ressource externe.
 */

export interface PaTokenBundle {
  accessToken: string;
  refreshToken: string;
  /** ISO timestamp UTC -- expiration du access token. Stocké pour le
   *  job refresh-pa-tokens (T-CL-06) qui sweepe par seuil. */
  accessExpiresAt: string;
}

export interface SecretStore {
  /** Read the JSON bundle stored at `secretRef`. Returns `null` if no
   *  secret exists (legitimate state right after disconnect). */
  get(secretRef: string): Promise<PaTokenBundle | null>;
  /** Upsert the JSON bundle. Overwrites silently if it already exists. */
  put(secretRef: string, bundle: PaTokenBundle): Promise<void>;
  /** Delete the bundle. Idempotent — no error if absent. */
  delete(secretRef: string): Promise<void>;
}

/** In-memory implementation for tests + ad-hoc dev. Keeps a Map so
 *  tests can assert by reading after `put`. */
export class MemorySecretStore implements SecretStore {
  private readonly bundles = new Map<string, PaTokenBundle>();

  get(secretRef: string): Promise<PaTokenBundle | null> {
    return Promise.resolve(this.bundles.get(secretRef) ?? null);
  }
  put(secretRef: string, bundle: PaTokenBundle): Promise<void> {
    this.bundles.set(secretRef, { ...bundle });
    return Promise.resolve();
  }
  delete(secretRef: string): Promise<void> {
    this.bundles.delete(secretRef);
    return Promise.resolve();
  }

  /** Test helper — drop everything between cases. */
  clear(): void {
    this.bundles.clear();
  }
}
