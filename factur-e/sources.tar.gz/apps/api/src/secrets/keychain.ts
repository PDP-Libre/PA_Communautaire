import { spawn } from "node:child_process";

import type { PaTokenBundle, SecretStore } from "./store.js";

/**
 * `KeychainSecretStore` — wrapper macOS `security` CLI pour le dev
 * local Bruno (CLAUDE.md §11.1). Convention : `account=factur-e`,
 * `service=<secretRef>` (ex. `superpdp-bundle-<customer_id>`).
 *
 * Sécurité :
 *  - `spawn()` avec args array (pas de shell), élimine l'injection
 *    via le `secretRef`. La valeur transite en argv (`-w <payload>`) —
 *    visible dans `ps` du process security pendant son exécution
 *    (millisecondes). Compromis acceptable sur la machine de dev
 *    locale ; en staging/prod le wrapper actif est
 *    `ScalewaySecretManagerStore` (API HTTPS, pas de surface argv).
 *  - Pourquoi pas stdin ? `security` macOS utilise `getpass()` qui lit
 *    `/dev/tty`, pas stdin. Quand le process est forké sans TTY
 *    (`pnpm dev`), security hang sur le prompt "password data for
 *    new item:". Confirmé smoke test T-CL-08 11 mai 2026 (Bruno).
 *  - Les valeurs lues sortent en stdout du sous-processus, JAMAIS
 *    loggées. Les erreurs stderr sont remontées sans le contenu.
 *
 * `security` exit codes connus :
 *  - 0       : succès.
 *  - 44      : `errSecItemNotFound` (secret absent — `get` retourne null).
 *  - autres  : remontés en exception avec le code.
 *
 * Out-of-scope T-CL-05 (à adresser quand staging linux arrive) :
 *  - alternative Linux (libsecret) — non requis aujourd'hui (dev macOS
 *    pur, prod Scaleway via `ScalewaySecretManagerStore`).
 */

const KEYCHAIN_ACCOUNT = "factur-e";

export class KeychainSecretStore implements SecretStore {
  async get(secretRef: string): Promise<PaTokenBundle | null> {
    const result = await runSecurity([
      "find-generic-password",
      "-a",
      KEYCHAIN_ACCOUNT,
      "-s",
      secretRef,
      "-w",
    ]);
    if (result.exitCode === 44) return null;
    if (result.exitCode !== 0) {
      throw new Error(
        `[keychain] find-generic-password ${secretRef}: exit ${String(result.exitCode)}`,
      );
    }
    const raw = result.stdout.trim();
    if (raw === "") return null;
    return JSON.parse(raw) as PaTokenBundle;
  }

  async put(secretRef: string, bundle: PaTokenBundle): Promise<void> {
    const payload = JSON.stringify(bundle);
    // -U : update if it already exists (idempotent).
    // -w <value> : valeur en argv. `security` n'a pas de moyen de lire
    // un secret via stdin (getpass lit /dev/tty), donc argv est la
    // seule option non-interactive. Surface argv limitée au process
    // security éphémère sur la machine dev locale — cf. file header.
    const result = await runSecurity([
      "add-generic-password",
      "-a",
      KEYCHAIN_ACCOUNT,
      "-s",
      secretRef,
      "-U",
      "-w",
      payload,
    ]);
    if (result.exitCode !== 0) {
      throw new Error(
        `[keychain] add-generic-password ${secretRef}: exit ${String(result.exitCode)} ${result.stderr}`,
      );
    }
  }

  async delete(secretRef: string): Promise<void> {
    const result = await runSecurity([
      "delete-generic-password",
      "-a",
      KEYCHAIN_ACCOUNT,
      "-s",
      secretRef,
    ]);
    // Idempotent : 44 = absent.
    if (result.exitCode !== 0 && result.exitCode !== 44) {
      throw new Error(
        `[keychain] delete-generic-password ${secretRef}: exit ${String(result.exitCode)}`,
      );
    }
  }
}

interface SpawnResult {
  exitCode: number;
  stdout: string;
  stderr: string;
}

function runSecurity(args: readonly string[], stdin?: string): Promise<SpawnResult> {
  return new Promise((resolve, reject) => {
    const child = spawn("security", args, {
      stdio: ["pipe", "pipe", "pipe"],
    });
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (chunk: Buffer) => {
      stdout += chunk.toString("utf8");
    });
    child.stderr.on("data", (chunk: Buffer) => {
      stderr += chunk.toString("utf8");
    });
    child.on("error", reject);
    child.on("close", (code) => {
      resolve({ exitCode: code ?? -1, stdout, stderr });
    });
    if (stdin !== undefined) {
      child.stdin.end(stdin);
    } else {
      child.stdin.end();
    }
  });
}
