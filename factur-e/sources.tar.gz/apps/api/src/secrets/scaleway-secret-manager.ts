import type { PaTokenBundle, SecretStore } from "./store.js";

/**
 * `ScalewaySecretManagerStore` — wrapper Scaleway Secret Manager API
 * pour staging + prod (CLAUDE.md §11.1). Convention de path :
 * `/factur-e/<env>/superpdp/<customer_id>/bundle` — l'application passe
 * le path complet en `secretRef`.
 *
 * Pas encore wired prod (T-BR-02 sprint-03 provisionne les credentials).
 * Implémentation HTTPS testée via `fetch` injectable. Bruno fait la
 * promotion manuelle dev -> prod (ADR-005 D9 + CLAUDE.md §11.1).
 *
 * Endpoints utilisés (Scaleway Secret Manager API v1beta1) :
 *  - GET    /v1beta1/regions/{region}/secrets-by-path?secret_path={path}
 *  - POST   /v1beta1/regions/{region}/secrets/{id}/versions    (create)
 *  - GET    /v1beta1/regions/{region}/secrets/{id}/versions/latest_enabled/access
 *  - DELETE /v1beta1/regions/{region}/secrets/{id}             (idempotent)
 *
 * NOTE T-CL-06 : la lecture/écriture en deux temps (resolve path -> id,
 * puis access version) est inhérente à l'API Scaleway. On l'encapsule
 * ici pour que les call sites consomment juste le `secretRef`.
 *
 * Pas de retry interne — Scaleway publie un SLA 99.9% ; en cas
 * d'incident le caller (job background T-CL-06) re-tentera au prochain
 * tick. Hors scope sprint-03.
 */

export interface ScalewaySecretManagerConfig {
  /** API token IAM Scaleway. Stocké en Keychain dev
   *  (`scaleway-api-key`), Scaleway env prod. */
  apiToken: string;
  /** Région Scaleway (ex. `fr-par`). */
  region: string;
  /** Override `fetch` for tests. */
  fetch?: typeof globalThis.fetch;
  /** Override base URL for tests (default Scaleway prod). */
  baseUrl?: string;
}

const DEFAULT_BASE_URL = "https://api.scaleway.com";

export class ScalewaySecretManagerStore implements SecretStore {
  private readonly apiToken: string;
  private readonly region: string;
  private readonly baseUrl: string;
  private readonly fetchFn: typeof globalThis.fetch;

  constructor(cfg: ScalewaySecretManagerConfig) {
    this.apiToken = cfg.apiToken;
    this.region = cfg.region;
    this.baseUrl = cfg.baseUrl ?? DEFAULT_BASE_URL;
    this.fetchFn = cfg.fetch ?? globalThis.fetch;
  }

  async get(secretRef: string): Promise<PaTokenBundle | null> {
    const id = await this.resolveSecretId(secretRef);
    if (id === null) return null;
    const url = `${this.regionUrl()}/secrets/${id}/versions/latest_enabled/access`;
    const res = await this.fetchFn(url, {
      method: "GET",
      headers: this.headers(),
    });
    if (res.status === 404) return null;
    if (!res.ok) {
      throw new Error(`[scaleway-sm] access ${secretRef}: status ${String(res.status)}`);
    }
    const body = (await res.json()) as { data?: string };
    if (typeof body.data !== "string") return null;
    const decoded = Buffer.from(body.data, "base64").toString("utf8");
    return JSON.parse(decoded) as PaTokenBundle;
  }

  async put(secretRef: string, bundle: PaTokenBundle): Promise<void> {
    const id = (await this.resolveSecretId(secretRef)) ?? (await this.createSecret(secretRef));
    const url = `${this.regionUrl()}/secrets/${id}/versions`;
    const data = Buffer.from(JSON.stringify(bundle), "utf8").toString("base64");
    const res = await this.fetchFn(url, {
      method: "POST",
      headers: { ...this.headers(), "content-type": "application/json" },
      body: JSON.stringify({ data }),
    });
    if (!res.ok) {
      throw new Error(`[scaleway-sm] create-version ${secretRef}: status ${String(res.status)}`);
    }
  }

  async delete(secretRef: string): Promise<void> {
    const id = await this.resolveSecretId(secretRef);
    if (id === null) return;
    const url = `${this.regionUrl()}/secrets/${id}`;
    const res = await this.fetchFn(url, {
      method: "DELETE",
      headers: this.headers(),
    });
    if (!res.ok && res.status !== 404) {
      throw new Error(`[scaleway-sm] delete ${secretRef}: status ${String(res.status)}`);
    }
  }

  private async resolveSecretId(secretRef: string): Promise<string | null> {
    const url = `${this.regionUrl()}/secrets-by-path?secret_path=${encodeURIComponent(secretRef)}`;
    const res = await this.fetchFn(url, {
      method: "GET",
      headers: this.headers(),
    });
    if (res.status === 404) return null;
    if (!res.ok) {
      throw new Error(`[scaleway-sm] resolve ${secretRef}: status ${String(res.status)}`);
    }
    const body = (await res.json()) as { id?: string };
    return body.id ?? null;
  }

  private async createSecret(secretRef: string): Promise<string> {
    // Scaleway expects a `path` for hierarchical secrets and a `name`.
    // We split the path on the last `/` to get a leaf name.
    const lastSlash = secretRef.lastIndexOf("/");
    const path = lastSlash === -1 ? "/" : secretRef.slice(0, lastSlash);
    const name = lastSlash === -1 ? secretRef : secretRef.slice(lastSlash + 1);
    const res = await this.fetchFn(`${this.regionUrl()}/secrets`, {
      method: "POST",
      headers: { ...this.headers(), "content-type": "application/json" },
      body: JSON.stringify({ path, name, type: "opaque" }),
    });
    if (!res.ok) {
      throw new Error(`[scaleway-sm] create ${secretRef}: status ${String(res.status)}`);
    }
    const body = (await res.json()) as { id?: string };
    if (typeof body.id !== "string" || body.id === "") {
      throw new Error(`[scaleway-sm] create ${secretRef}: missing id in response`);
    }
    return body.id;
  }

  private regionUrl(): string {
    return `${this.baseUrl}/secret-manager/v1beta1/regions/${this.region}`;
  }

  private headers(): Record<string, string> {
    return {
      "X-Auth-Token": this.apiToken,
      accept: "application/json",
    };
  }
}
