import type { FastifyInstance } from "fastify";

import { createDefaultSecretStore, type SecretStore } from "./index.js";

declare module "fastify" {
  interface FastifyInstance {
    secrets: SecretStore;
  }
}

/** Decorate the Fastify instance with a single shared SecretStore.
 *  T-CL-05 sprint-03 livré le store + factory ; T-CL-06 ajoute juste
 *  le decorator pour que les routes / jobs y accèdent via `app.secrets`. */
export function attachSecretStore(app: FastifyInstance, store: SecretStore): void {
  app.decorate("secrets", store);
}

export { createDefaultSecretStore };
export type { SecretStore };
