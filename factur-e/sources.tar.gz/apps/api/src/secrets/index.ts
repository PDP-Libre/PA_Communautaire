/**
 * Secrets API for Factur-e backend (T-CL-05 sprint-03).
 *
 * Public surface :
 *  - `SecretStore` interface (3 methods : get / put / delete).
 *  - `MemorySecretStore` for tests + ad-hoc dev.
 *  - `KeychainSecretStore` for dev macOS local (Bruno).
 *  - `ScalewaySecretManagerStore` for staging / prod.
 *  - `createDefaultSecretStore()` factory : dispatches by `NODE_ENV` +
 *    presence of `SCALEWAY_API_TOKEN`.
 *
 * Convention secretRef :
 *  - Dev (Keychain) : `superpdp-bundle-{customerId}` (account fixed
 *    `factur-e`, cf. CLAUDE.md §11.1).
 *  - Staging/prod (Scaleway) : `/factur-e/{env}/superpdp/{customerId}/bundle`.
 *
 * Le caller (T-CL-06) calcule le secretRef à partir de `customerId` et
 * du wrapper actif. Aucune logique de path bakée dans les wrappers eux-mêmes.
 */

export { type PaTokenBundle, type SecretStore, MemorySecretStore } from "./store.js";
export { KeychainSecretStore } from "./keychain.js";
export {
  ScalewaySecretManagerStore,
  type ScalewaySecretManagerConfig,
} from "./scaleway-secret-manager.js";

import { KeychainSecretStore } from "./keychain.js";
import { ScalewaySecretManagerStore } from "./scaleway-secret-manager.js";
import { MemorySecretStore, type SecretStore } from "./store.js";

/**
 * Factory : pick the wrapper from env. Tests bypass this and inject a
 * `MemorySecretStore` directly.
 */
export function createDefaultSecretStore(): SecretStore {
  if (process.env.NODE_ENV === "test") {
    return new MemorySecretStore();
  }
  // T-CL-16 sprint-03 — `SECRETS_ADAPTER=memory` opt-out pour Playwright
  // E2E en CI Linux (le KeychainSecretStore spawn `security` macOS-only).
  // Gated `NODE_ENV !== production` pour eviter une activation
  // accidentelle en prod (cohérent avec PA_ADAPTER=mock /
  // RATE_LIMIT_DISABLED).
  if (process.env.SECRETS_ADAPTER === "memory" && process.env.NODE_ENV !== "production") {
    return new MemorySecretStore();
  }
  const scwToken = process.env.SCALEWAY_API_TOKEN;
  const scwRegion = process.env.SCALEWAY_REGION;
  if (
    typeof scwToken === "string" &&
    scwToken !== "" &&
    typeof scwRegion === "string" &&
    scwRegion !== ""
  ) {
    return new ScalewaySecretManagerStore({ apiToken: scwToken, region: scwRegion });
  }
  if (process.env.NODE_ENV === "production") {
    throw new Error(
      "[secrets] SCALEWAY_API_TOKEN + SCALEWAY_REGION are required in production " +
        "(no Keychain fallback in prod — cf. CLAUDE.md §11.1).",
    );
  }
  // Dev no-creds : macOS Keychain.
  return new KeychainSecretStore();
}
