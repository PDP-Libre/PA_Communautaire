import fastifyCookie from "@fastify/cookie";
import fastifyCors from "@fastify/cors";
import fastifyHelmet from "@fastify/helmet";
import fastifyMultipart from "@fastify/multipart";
import fastifyRateLimit from "@fastify/rate-limit";
import Fastify, { type FastifyInstance } from "fastify";

import type { InseeClient } from "@factur-e/insee-adapter";
import type { PADriver } from "@factur-e/pa-adapter";

import { registerMfaResetGuard } from "./auth/mfa-reset-guard.js";
import { attachEmailSender, createDefaultEmailSender, type EmailSender } from "./email/sender.js";
import { attachInseeClient, createDefaultInseeClient } from "./onboarding/insee-plugin.js";
import { attachPaDriver, createDefaultPaDriver } from "./pa/driver-plugin.js";
import { dbPlugin } from "./plugins/db.js";
import { healthRoute } from "./routes/health.js";
import { registerAuthRoutes } from "./routes/auth/index.js";
import { registerDirectoryRoutes } from "./routes/directory/index.js";
import { registerInvoiceDraftsRoutes } from "./routes/invoice-drafts/index.js";
import { registerInvoicesRoutes } from "./routes/invoices/index.js";
import { registerOAuthRoutes } from "./routes/oauth/index.js";
import { registerPaRoutes } from "./routes/pa/index.js";
import { registerReceivedInvoicesRoutes } from "./routes/received-invoices/index.js";
import { registerWebhookRoutes } from "./routes/webhooks/index.js";
import { registerProductsRoutes } from "./routes/products/index.js";
import { registerProfileRoutes } from "./routes/profile/index.js";
import { registerUsersRoutes } from "./routes/users/index.js";
import { attachSecretStore, createDefaultSecretStore } from "./secrets/plugin.js";
import type { SecretStore } from "./secrets/plugin.js";
import {
  attachExportsStorage,
  attachObjectStorage,
  createDefaultExportsStorage,
  createDefaultObjectStorage,
  type ObjectStorage,
} from "./storage/object-storage.js";
import { attachJobQueue, createDefaultJobQueue, type JobQueue } from "./jobs/job-queue.js";
import { registerExportsRoutes } from "./routes/exports/index.js";
import { registerDashboardRoutes } from "./routes/dashboard/index.js";

export interface BuildAppOptions {
  /** Postgres connection string. Falls back to env (POSTGRES_URL or
   *  POSTGRES_HOST/PORT/DB/USER/PASSWORD). Tests override this. */
  connectionString?: string;
  /** Email sender. Defaults to a mock that captures sends in-memory.
   *  T-CL-04 swaps in the Scaleway TEM adapter. Tests pass a mock to
   *  inspect outgoing OTP codes. */
  emailSender?: EmailSender;
  /** INSEE Sirene client. Defaults to RealInseeClient if `INSEE_API_KEY`
   *  set, else `StubInseeClient` (returns `unavailable`). Tests inject
   *  a mock with controlled fixtures. */
  inseeClient?: InseeClient;
  /** Object storage (logos, invoice PDFs). Defaults to S3-compat (MinIO
   *  dev / Scaleway prod) when env vars are set, else a `MockObjectStorage`
   *  that keeps uploads in memory. Tests inject the mock. */
  objectStorage?: ObjectStorage;
  /** Object storage dédié aux archives ZIP d'export (bucket privé distinct
   *  des logos). Défaut comme `objectStorage`. Tests injectent le mock. */
  exportsStorage?: ObjectStorage;
  /** Job queue (pgboss en dev/prod, mock en test). Le endpoint Export ZIP
   *  enqueue `export-zip-generate`. Défaut : `MockJobQueue` (capture).
   *  `start.ts` injecte la queue pgboss réelle. */
  jobQueue?: JobQueue;
  /** PA driver (T-CL-06 sprint-03). Defaults to `SuperPDPDriver` when
   *  `SUPERPDP_CLIENT_ID/SECRET` exported, else `StubPaDriver` (throws
   *  on every method, used for dev no-creds + as a `NODE_ENV=test`
   *  default — tests inject `MockPADriver`). */
  paDriver?: PADriver;
  /** Token store for SuperPDP access/refresh bundles (T-CL-05 sprint-03).
   *  Defaults to Keychain (dev) / Scaleway Secret Manager (staging+prod)
   *  / Memory (test). Tests can override with `MemorySecretStore`. */
  secretStore?: SecretStore;
}

/**
 * Build a Fastify app instance without starting to listen.
 *
 * Used by:
 *  - `start.ts` (production / dev entry — calls `.listen` after migrations).
 *  - HTTP tests (cf. `tests/helpers/build-app.ts`) which `.listen({ port: 0 })`
 *    on a random free port. NEVER use `app.inject()` — see CLAUDE.md §6.1.
 */
export async function buildApp(opts: BuildAppOptions = {}): Promise<FastifyInstance> {
  const app = Fastify({
    logger:
      process.env.NODE_ENV === "test"
        ? false
        : {
            level: process.env.LOG_LEVEL ?? "info",
          },
    trustProxy: true,
  });

  // Security headers (T-CL-02 sprint-03 — audit architecture sprint-02 §4.14).
  // Registered first so headers apply to every response, including 404 / errors.
  // CSP minimal pour une API JSON : pas de scripts/styles inline nécessaires,
  // pas de framing (l'API n'est jamais embarquée), pas d'image externe attendue
  // sauf data: pour les logos retournés en base64 le cas échéant.
  // HSTS uniquement en prod — on ne veut pas forcer HTTPS sur localhost dev.
  await app.register(fastifyHelmet, {
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'"],
        styleSrc: ["'self'"],
        imgSrc: ["'self'", "data:"],
        connectSrc: ["'self'"],
        fontSrc: ["'self'"],
        frameAncestors: ["'none'"],
        objectSrc: ["'none'"],
        baseUri: ["'self'"],
        formAction: ["'self'"],
      },
    },
    frameguard: { action: "deny" },
    noSniff: true,
    referrerPolicy: { policy: "strict-origin-when-cross-origin" },
    hsts:
      process.env.NODE_ENV === "production"
        ? { maxAge: 31_536_000, includeSubDomains: true, preload: true }
        : false,
  });

  // CORS — allow the SPA dev server to send credentialed requests against
  // this API. In prod the SPA + API live under the same origin via the
  // Kapsule Ingress, so this only matters during local development.
  //
  // Defaults cover localhost, 127.0.0.1, and the dev box LAN IP so a
  // teammate / a phone on the same network can hit the SPA without
  // touching configuration. Override via `WEB_BASE_URL` (comma-separated)
  // for any other host (CI E2E, staging via tunnel, etc.).
  //
  // Port 5174 because Bruno's dev box has another tool listening on 5173.
  // These defaults are dev-only — production boot enforces `WEB_BASE_URL`
  // via `start.ts:assertProductionInvariants` (T-CL-02 sprint-03).
  const DEFAULT_DEV_ORIGINS =
    "http://localhost:5174,http://127.0.0.1:5174,http://192.168.99.15:5174";
  const corsOrigins = (process.env.WEB_BASE_URL ?? DEFAULT_DEV_ORIGINS)
    .split(",")
    .map((o) => o.trim())
    .filter((o) => o.length > 0);
  await app.register(fastifyCors, {
    origin: corsOrigins,
    credentials: true,
    // `@fastify/cors` v11 a réduit son défaut `methods` de
    // `'GET,HEAD,PUT,PATCH,POST,DELETE'` (≤ v10) à `'GET,HEAD,POST'` —
    // sans cet override, tous les PATCH/PUT/DELETE échouent au preflight
    // CORS depuis la SPA dev (`access-control-allow-methods` ne retourne
    // que `GET,HEAD,POST`). Révélé en testant T-CL-14 frontend Articles
    // (les routes /api/products PATCH/DELETE étaient les premières
    // consommées depuis la SPA — les autres /users, /profile, /invitations,
    // /customers/me/logo étaient latentes). Cf. release notes v11
    // @fastify/cors si retrait/changement futur.
    methods: ["GET", "HEAD", "POST", "PATCH", "PUT", "DELETE"],
  });
  await app.register(fastifyCookie);
  await app.register(fastifyMultipart, {
    limits: {
      // Per-route limits override this global cap (logo: 2 Mo).
      fileSize: 10 * 1024 * 1024,
      files: 1,
    },
  });

  // Skip rate-limit in tests so suites don't trip 429s on intentional
  // login-failure loops. PRD §7.1 thresholds enforced in dev/staging/prod.
  //
  // T-CL-16 sprint-03 — additional opt-out via `RATE_LIMIT_DISABLED=true`
  // for Playwright E2E in dev mode : 9 specs enchainant signup express
  // (~50 calls chacune dont 25 polls `/__dev/last-email`) saturent le
  // max=100/1min. Gated `NODE_ENV !== production` pour eviter une
  // desactivation accidentelle en prod. Cohérent avec `PA_ADAPTER=mock`
  // et `INSEE_ADAPTER=preset` (autres opt-outs E2E).
  const rateLimitDisabled =
    process.env.RATE_LIMIT_DISABLED === "true" && process.env.NODE_ENV !== "production";
  if (process.env.NODE_ENV !== "test" && !rateLimitDisabled) {
    await app.register(fastifyRateLimit, {
      max: 100,
      timeWindow: "1 minute",
    });
  }

  await app.register(dbPlugin, {
    connectionString: opts.connectionString ?? postgresUrlFromEnv(),
    readConnectionString: process.env.POSTGRES_READ_URL,
  });

  attachEmailSender(app, opts.emailSender ?? createDefaultEmailSender());
  app.log.info({ adapter: app.email.constructor.name }, "[email] adapter selected");

  attachInseeClient(app, opts.inseeClient ?? createDefaultInseeClient());
  app.log.info({ adapter: app.insee.constructor.name }, "[insee] adapter selected");

  attachObjectStorage(app, opts.objectStorage ?? createDefaultObjectStorage());
  app.log.info({ adapter: app.storage.constructor.name }, "[storage] adapter selected");

  attachExportsStorage(app, opts.exportsStorage ?? createDefaultExportsStorage());
  app.log.info(
    { adapter: app.exportsStorage.constructor.name },
    "[exports-storage] adapter selected",
  );

  attachJobQueue(app, opts.jobQueue ?? createDefaultJobQueue());
  app.log.info({ adapter: app.jobQueue.constructor.name }, "[job-queue] adapter selected");

  // T-CL-05/06 sprint-03 — PA OAuth driver + secret store for tokens.
  attachPaDriver(app, opts.paDriver ?? createDefaultPaDriver());
  app.log.info({ adapter: app.paDriver.constructor.name }, "[pa-driver] adapter selected");

  attachSecretStore(app, opts.secretStore ?? createDefaultSecretStore());
  app.log.info({ adapter: app.secrets.constructor.name }, "[secrets] adapter selected");

  // T-CL-03 sprint-03 + patch T-CL-06 — global preHandler that 403s
  // authenticated users whose `mfa_reset_required` flag is set, on the
  // protected prefix groups (`/customers`, `/users`, `/profile`,
  // `/invitations`, `/oauth/superpdp`, `/pa`). Registered before route
  // registration so `addHook` applies to all subsequent registrations.
  registerMfaResetGuard(app);

  await app.register(healthRoute);
  registerAuthRoutes(app);
  registerOAuthRoutes(app);
  registerPaRoutes(app);
  registerDirectoryRoutes(app);
  registerProductsRoutes(app);
  registerInvoicesRoutes(app);
  registerReceivedInvoicesRoutes(app);
  registerInvoiceDraftsRoutes(app);
  registerProfileRoutes(app);
  registerUsersRoutes(app);
  // T-CL-EXPORT-ZIP-RETENTION sprint-06 L12 — Export ZIP + rétention RGPD.
  registerExportsRoutes(app);
  registerDashboardRoutes(app);
  // T-CL-PA-EXT sprint-04 — webhook PA HMAC (ADR-009 D1+D4+D5). Pas
  // d'auth user, signature HMAC suffit. Route enregistrée dans un
  // sub-context Fastify pour appliquer un contentTypeParser dédié qui
  // capture le raw body (octets bruts pour HMAC).
  registerWebhookRoutes(app);

  // Dev-only HTTP surface for E2E tests (Playwright T-CL-10) and ad-hoc
  // debugging. Never exposed in production.
  if (process.env.NODE_ENV !== "production") {
    const { registerDevRoutes } = await import("./routes/dev/index.js");
    registerDevRoutes(app);
    app.log.info("[dev] /__dev/* routes enabled (NODE_ENV != production)");
  }

  return app;
}

export function postgresUrlFromEnv(): string {
  if (process.env.POSTGRES_URL !== undefined && process.env.POSTGRES_URL !== "") {
    return process.env.POSTGRES_URL;
  }
  const host = process.env.POSTGRES_HOST ?? "localhost";
  // Default port 5442 — matches docker-compose.dev.yml port mapping
  // (5442:5432 to avoid conflict with the native Postgres mac on 5432
  // which is dedicated to CI, cf. docs/operations/ci-postgres.md).
  const port = process.env.POSTGRES_PORT ?? "5442";
  const db = process.env.POSTGRES_DB ?? "factur_e_dev";
  const user = process.env.POSTGRES_USER ?? "factur_e_dev";
  const password = process.env.POSTGRES_PASSWORD ?? "factur_e_dev_password";
  return `postgresql://${user}:${password}@${host}:${port}/${db}`;
}
