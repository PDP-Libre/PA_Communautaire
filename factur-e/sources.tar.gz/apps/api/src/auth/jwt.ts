import { SignJWT, jwtVerify } from "jose";

/**
 * JWT signing helpers backed by `JWT_SIGNING_KEY` env var (HS256).
 *
 * In dev, the key comes from macOS Keychain via `scripts/dev/load-secrets.sh`
 * (`-s jwt-signing-key-dev`). In tests, a dummy fixed value is set by Vitest
 * setup. In production, the key sits in Scaleway Secret Manager and is
 * injected as env via External Secrets Operator (out of scope for T-CL-02).
 *
 * Three token shapes:
 *
 * - **Signup session** (cookie `signup_session`, HttpOnly + SameSite=Lax,
 *   TTL 7 d): wraps a `signup_pending.id`. SameSite=Lax so the magic email
 *   link in §6.4 can carry the cookie back to the app on first navigation.
 *
 * - **Access** (returned as `Authorization: Bearer …`, TTL 15 min): wraps
 *   the user `id` and `customer_id`. Stateless — verification is a signature
 *   check. Short TTL combined with stateful refresh rotation reduces the
 *   exploitation window of a stolen bearer to ~15 min (T-CL-02 sprint-03,
 *   audit §4.6 / §4.19). The SPA refreshes silently in background — no UX cost.
 *
 * - **Refresh** (cookie `_session`, HttpOnly + Secure + SameSite=Strict,
 *   TTL 30 d): wraps the `sessions.id` (= JWT `jti`) so we can revoke server-
 *   side. Refresh endpoint comes in T-CL-04+.
 */

const ACCESS_TTL_SECONDS = 60 * 15;
const REFRESH_TTL_SECONDS = 60 * 60 * 24 * 30;
const SIGNUP_TTL_SECONDS = 60 * 60 * 24 * 7;
const MFA_CHALLENGE_TTL_SECONDS = 60 * 5;
const MFA_RESET_TTL_SECONDS = 60 * 15;

const ACCESS_AUD = "factur-e:access";
const REFRESH_AUD = "factur-e:refresh";
const SIGNUP_AUD = "factur-e:signup-pending";
const MFA_CHALLENGE_AUD = "factur-e:mfa-challenge";
const MFA_RESET_AUD = "factur-e:mfa-reset";

function getKey(): Uint8Array {
  const raw = process.env.JWT_SIGNING_KEY;
  if (raw === undefined || raw.length < 32) {
    throw new Error(
      "JWT_SIGNING_KEY env var missing or shorter than 32 chars. " +
        "Dev: load via scripts/dev/load-secrets.sh (Keychain `jwt-signing-key-dev`).",
    );
  }
  return new TextEncoder().encode(raw);
}

export interface AccessPayload {
  user_id: string;
  customer_id: string;
}

export async function signAccessToken(payload: AccessPayload): Promise<string> {
  return new SignJWT({ ...payload })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setAudience(ACCESS_AUD)
    .setExpirationTime(`${String(ACCESS_TTL_SECONDS)}s`)
    .sign(getKey());
}

export async function verifyAccessToken(token: string): Promise<AccessPayload> {
  const { payload } = await jwtVerify(token, getKey(), { audience: ACCESS_AUD });
  const userId = payload.user_id;
  const customerId = payload.customer_id;
  if (typeof userId !== "string" || typeof customerId !== "string") {
    throw new Error("invalid_access_payload");
  }
  return { user_id: userId, customer_id: customerId };
}

export interface RefreshPayload {
  session_id: string;
  user_id: string;
}

export async function signRefreshToken(payload: RefreshPayload): Promise<string> {
  return new SignJWT({ ...payload })
    .setProtectedHeader({ alg: "HS256" })
    .setJti(payload.session_id)
    .setIssuedAt()
    .setAudience(REFRESH_AUD)
    .setExpirationTime(`${String(REFRESH_TTL_SECONDS)}s`)
    .sign(getKey());
}

export async function verifyRefreshToken(token: string): Promise<RefreshPayload> {
  const { payload } = await jwtVerify(token, getKey(), { audience: REFRESH_AUD });
  const sessionId = payload.session_id;
  const userId = payload.user_id;
  if (typeof sessionId !== "string" || typeof userId !== "string") {
    throw new Error("invalid_refresh_payload");
  }
  return { session_id: sessionId, user_id: userId };
}

export interface SignupSessionPayload {
  signup_pending_id: string;
}

export async function signSignupSessionToken(payload: SignupSessionPayload): Promise<string> {
  return new SignJWT({ ...payload })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setAudience(SIGNUP_AUD)
    .setExpirationTime(`${String(SIGNUP_TTL_SECONDS)}s`)
    .sign(getKey());
}

export async function verifySignupSessionToken(token: string): Promise<SignupSessionPayload> {
  const { payload } = await jwtVerify(token, getKey(), { audience: SIGNUP_AUD });
  const id = payload.signup_pending_id;
  if (typeof id !== "string") {
    throw new Error("invalid_signup_payload");
  }
  return { signup_pending_id: id };
}

export interface MfaChallengePayload {
  user_id: string;
  customer_id: string;
  mfa_mode: "email" | "totp";
}

export async function signMfaChallengeToken(payload: MfaChallengePayload): Promise<string> {
  return new SignJWT({ ...payload })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setAudience(MFA_CHALLENGE_AUD)
    .setExpirationTime(`${String(MFA_CHALLENGE_TTL_SECONDS)}s`)
    .sign(getKey());
}

export async function verifyMfaChallengeToken(token: string): Promise<MfaChallengePayload> {
  const { payload } = await jwtVerify(token, getKey(), { audience: MFA_CHALLENGE_AUD });
  const userId = payload.user_id;
  const customerId = payload.customer_id;
  const mfaMode = payload.mfa_mode;
  if (
    typeof userId !== "string" ||
    typeof customerId !== "string" ||
    (mfaMode !== "email" && mfaMode !== "totp")
  ) {
    throw new Error("invalid_mfa_challenge_payload");
  }
  return { user_id: userId, customer_id: customerId, mfa_mode: mfaMode };
}

export interface MfaResetPayload {
  user_id: string;
}

export async function signMfaResetToken(payload: MfaResetPayload): Promise<string> {
  return new SignJWT({ ...payload })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setAudience(MFA_RESET_AUD)
    .setExpirationTime(`${String(MFA_RESET_TTL_SECONDS)}s`)
    .sign(getKey());
}

export async function verifyMfaResetToken(token: string): Promise<MfaResetPayload> {
  const { payload } = await jwtVerify(token, getKey(), { audience: MFA_RESET_AUD });
  const userId = payload.user_id;
  if (typeof userId !== "string") {
    throw new Error("invalid_mfa_reset_payload");
  }
  return { user_id: userId };
}

export const TTL_SECONDS = {
  access: ACCESS_TTL_SECONDS,
  refresh: REFRESH_TTL_SECONDS,
  signup: SIGNUP_TTL_SECONDS,
  mfaChallenge: MFA_CHALLENGE_TTL_SECONDS,
  mfaReset: MFA_RESET_TTL_SECONDS,
} as const;
