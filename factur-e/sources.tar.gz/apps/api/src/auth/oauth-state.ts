import "@fastify/cookie";

import { SignJWT, jwtVerify } from "jose";

/**
 * OAuth state cookie for the SuperPDP authorize → callback dance
 * (T-CL-06 sprint-03). The cookie carries the PKCE `code_verifier`,
 * the CSRF `state`, and enough caller context (customer_id, user_id)
 * to write `pa_connections` at the callback even if the user's main
 * session expired during the SuperPDP tunnel (5–10 min).
 *
 * Cookie attributes (chat ajustements D1) :
 *  - HttpOnly                — pas de lecture JS côté SPA.
 *  - SameSite=Lax            — le callback est une top-level navigation
 *                              cross-site depuis l'origine SuperPDP ;
 *                              `Strict` drop le cookie. CSRF reste
 *                              couvert par le claim `state`.
 *  - Secure                  — uniquement en production / HTTPS.
 *  - Path=/oauth/superpdp/   — scope tight, le cookie ne fuit pas
 *                              vers les autres routes.
 *  - TTL 5 min               — durée typique d'un tunnel SuperPDP.
 *
 * Audience JWT : `factur-e:oauth-state` (cohérent avec les 5 audiences
 * existantes de `auth/jwt.ts`). HS256 + clé `JWT_SIGNING_KEY` partagée
 * avec les autres tokens — clé unique par environnement.
 *
 * Le caller `clearStateCookie()` est appelé systématiquement en fin
 * de callback (succès OU échec) pour ne laisser aucun JWT consommable
 * dans le browser (pattern auth recovery defense in depth).
 */

const OAUTH_STATE_AUD = "factur-e:oauth-state";
const OAUTH_STATE_TTL_SECONDS = 60 * 5;

export const OAUTH_STATE_COOKIE = "oauth_state";
export const OAUTH_STATE_COOKIE_PATH = "/oauth/superpdp/";

export interface OAuthStatePayload {
  state: string;
  code_verifier: string;
  customer_id: string;
  user_id: string;
  /** Provider discriminator — extensible V2 multi-PA. */
  pa_code: "superpdp";
}

function getKey(): Uint8Array {
  const raw = process.env.JWT_SIGNING_KEY;
  if (raw === undefined || raw.length < 32) {
    throw new Error("JWT_SIGNING_KEY env var missing or shorter than 32 chars (cf. auth/jwt.ts).");
  }
  return new TextEncoder().encode(raw);
}

export async function signOAuthStateToken(payload: OAuthStatePayload): Promise<string> {
  return new SignJWT({ ...payload })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setAudience(OAUTH_STATE_AUD)
    .setExpirationTime(`${String(OAUTH_STATE_TTL_SECONDS)}s`)
    .sign(getKey());
}

export async function verifyOAuthStateToken(token: string): Promise<OAuthStatePayload> {
  const { payload } = await jwtVerify(token, getKey(), { audience: OAUTH_STATE_AUD });
  const state = payload.state;
  const codeVerifier = payload.code_verifier;
  const customerId = payload.customer_id;
  const userId = payload.user_id;
  const paCode = payload.pa_code;
  if (
    typeof state !== "string" ||
    typeof codeVerifier !== "string" ||
    typeof customerId !== "string" ||
    typeof userId !== "string" ||
    paCode !== "superpdp"
  ) {
    throw new Error("invalid_oauth_state_payload");
  }
  return {
    state,
    code_verifier: codeVerifier,
    customer_id: customerId,
    user_id: userId,
    pa_code: paCode,
  };
}

/** Cookie options to set the state cookie at `/oauth/superpdp/authorize`. */
export function oauthStateCookieOptions(): {
  httpOnly: true;
  sameSite: "lax";
  secure: boolean;
  path: string;
  maxAge: number;
} {
  return {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: OAUTH_STATE_COOKIE_PATH,
    maxAge: OAUTH_STATE_TTL_SECONDS,
  };
}

/** Cookie options to clear the state cookie at the end of the callback. */
export function clearOAuthStateCookieOptions(): {
  httpOnly: true;
  sameSite: "lax";
  secure: boolean;
  path: string;
  maxAge: 0;
} {
  return {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: OAUTH_STATE_COOKIE_PATH,
    maxAge: 0,
  };
}
