import type postgres from "postgres";

/**
 * Outgoing transactional email throttle — anti-spam / anti-DDoS-emails
 * (T-CL-02 sprint-03, audit architecture sprint-02 §4.9 trou résiduel
 * non couvert par l'IP lockout login).
 *
 * Threat model : un attaquant qui rotate ses IPs cible un email victime
 * et appelle en boucle `/auth/signup` ou `/auth/password-reset/request`
 * pour saturer la boîte du destinataire. L'IP lockout login ne ferme pas
 * ce vecteur (rotation IP triviale) ; il faut un compteur **par email**.
 *
 * Mécanique : on consulte `auth_audit` pour les events qui mentionnent
 * cet email dans `metadata->>'email'`. Si un envoi a déjà eu lieu dans
 * la fenêtre, on **skip l'envoi** côté route (le row signup_pending est
 * tout de même persisté pour ne pas casser le flow legit d'un user qui
 * retry rapidement après cookie perdu — il pourra renvoyer le lien via
 * `/auth/phase1/email/verify-trigger`).
 *
 * Events comptés :
 *  - `signup_success`         (non-decoy) → envoie un magic link verify
 *  - `signup_failed`          (decoy email_exists) → envoie un reset link
 *  - `password_reset_request` (succès = mail reel envoye, echec = silent)
 *
 * Tous trois trigger un mail outgoing vers l'adresse cible si le throttle
 * n'est pas active. C'est exactement la surface qu'on veut limiter.
 *
 * Fenêtre : 5 minutes — assez court pour les retry legit (cookie perdu),
 * assez long pour décourager le spam massif sur une même cible.
 */

const THROTTLE_WINDOW_MIN = 5;

const THROTTLED_EVENT_TYPES = [
  "signup_success",
  "signup_failed",
  "password_reset_request",
] as const;

export async function isEmailRecentlyThrottled(sql: postgres.Sql, email: string): Promise<boolean> {
  const rows = await sql<{ count: string }[]>`
    SELECT COUNT(*)::text AS count
    FROM auth_audit
    WHERE metadata ->> 'email' = ${email}
      AND event_type IN ${sql([...THROTTLED_EVENT_TYPES])}
      AND occurred_at > NOW() - INTERVAL '${sql.unsafe(String(THROTTLE_WINDOW_MIN))} minutes'
  `;
  const r = rows[0];
  if (r === undefined) return false;
  return Number(r.count) >= 1;
}

export const EMAIL_THROTTLE_CONFIG = {
  windowMinutes: THROTTLE_WINDOW_MIN,
} as const;

/**
 * T-CL-15 sprint-03 — throttle dédié pour le set d'email secours invité.
 *
 * Cible : `/auth/accept-invitation/secondary-email/set`. Le user invité
 * est authentifié Bearer (donc on a son `user_id`) ; on compte les
 * `invite_secondary_email_set` events par `user_id` dans la fenêtre
 * 5 min plutôt que par email — l'attaquant qui rotate l'email saisi
 * resterait limité par son `user_id`, et le user legit retry rapide
 * (refresh page, etc.) n'est pas affecté outre mesure (TTL OTP = 5 min
 * de toute façon).
 *
 * Pas inclus dans `THROTTLED_EVENT_TYPES` ci-dessus pour ne pas changer
 * la sémantique du throttle email-based (anti-spam tiers).
 */
export async function isInviteSecondaryEmailRecentlyIssued(
  sql: postgres.Sql,
  userId: string,
): Promise<boolean> {
  const rows = await sql<{ count: string }[]>`
    SELECT COUNT(*)::text AS count
    FROM auth_audit
    WHERE user_id = ${userId}
      AND event_type = 'invite_secondary_email_set'
      AND occurred_at > NOW() - INTERVAL '${sql.unsafe(String(THROTTLE_WINDOW_MIN))} minutes'
  `;
  const r = rows[0];
  if (r === undefined) return false;
  return Number(r.count) >= 1;
}
