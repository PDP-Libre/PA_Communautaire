import { hash, verify, type Options } from "@node-rs/argon2";

/**
 * Argon2id wrapper. PRD §6.2 / §7.1 mandates argon2id for password hashing
 * with m=64 MiB / t=3 / p=4 in production. `@node-rs/argon2` defaults to
 * Argon2id when `algorithm` is omitted, so we don't pass it explicitly
 * (avoids `isolatedModules`-incompatible `const enum` import).
 *
 * Vitest setup flips `ARGON2_MODE=test` to drop the cost so unit tests
 * stay sub-second. Never set `ARGON2_MODE=test` in production.
 */

const PROD_PARAMS: Options = {
  memoryCost: 64 * 1024,
  timeCost: 3,
  parallelism: 4,
};

const TEST_PARAMS: Options = {
  memoryCost: 8 * 1024,
  timeCost: 1,
  parallelism: 1,
};

function params(): Options {
  return process.env.ARGON2_MODE === "test" ? TEST_PARAMS : PROD_PARAMS;
}

export async function hashPassword(plain: string): Promise<string> {
  return hash(plain, params());
}

export async function verifyPassword(stored: string, candidate: string): Promise<boolean> {
  try {
    return await verify(stored, candidate);
  } catch {
    return false;
  }
}
