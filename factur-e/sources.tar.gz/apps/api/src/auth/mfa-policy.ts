import type { UserRole } from "../db/repos/users.js";

/**
 * Politique d'enforcement MFA — TOTP-only pour les rôles privilégiés
 * (ADR-006 sprint-03, D3).
 *
 * Règle dérivée (pas de colonne `mfa_enforced_mode` BDD) :
 *   `role === 'full'`  OU  `can_purchase === true`  ⇒  TOTP obligatoire.
 *
 * Threat model : email principal compromis isolément ne doit pas exposer
 * les rôles privilégiés (gestion d'équipe Full, achat de packs
 * can_purchase, connexion à la Plateforme Agréée Full). Le 2ᵉ facteur
 * email envoie le code sur l'adresse même qui sert au reset password →
 * single-factor déguisé. TOTP via authenticator garantit un facteur de
 * possession indépendant.
 *
 * 5 endpoints concernés (ADR-006 §"Conséquences côté CLI") :
 *   - phase1/mfa/choose (signup) — T-CL-02 / T-CL-15
 *   - accept-invitation/mfa/choose (invité) — T-CL-15 patch /auth/mfa/setup-choose
 *   - users/:id/role (admin promotion → vérifier user a TOTP)
 *   - users/:id/can-purchase (admin flip → idem)
 *   - users/me/mfa/mode (downgrade vers email refusé) — futur
 *
 * Cette fonction est volontairement pure (pas de SQL, pas d'effet de
 * bord) — le caller charge le row utilisateur et passe la projection
 * minimale `{ role, can_purchase }`. Test unitaire trivial dans
 * `tests/auth/mfa-policy.test.ts`.
 */

export interface UserPolicyProjection {
  readonly role: UserRole;
  readonly can_purchase: boolean;
}

export function requiresTotp(user: UserPolicyProjection): boolean {
  return user.role === "full" || user.can_purchase;
}
