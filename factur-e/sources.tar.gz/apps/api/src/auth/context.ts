import "@fastify/cookie";

import type { FastifyRequest } from "fastify";

import { verifyAccessToken, verifySignupSessionToken } from "./jwt.js";
import { SIGNUP_SESSION_COOKIE } from "./cookies.js";

/**
 * Resolves the auth state of an incoming request, consumed by routes that
 * need to branch on it (notably `GET /auth/me`).
 *
 * Order of precedence:
 *   1. `Authorization: Bearer …` header → authenticated user
 *   2. `signup_session` cookie          → pending (phase 1 in progress)
 *   3. none                             → anonymous
 *
 * The former `?token=<bearer>` query fallback (SSE only) was removed by
 * T-CL-AUTH-SSE-COOKIE-HTTPONLY (sprint-06, hard cut Z1) — SSE now
 * authenticates via the HttpOnly `_session` cookie, see
 * `apps/api/src/auth/sse-auth.ts`. No bearer ever travels in a URL anymore.
 */

export interface AnonContext {
  state: "anon";
}

export interface AuthenticatedContext {
  state: "authenticated";
  user_id: string;
  customer_id: string;
}

export interface PendingContext {
  state: "pending";
  signup_pending_id: string;
}

export type AuthContext = AnonContext | AuthenticatedContext | PendingContext;

function readBearer(req: FastifyRequest): string | undefined {
  const header = req.headers.authorization;
  if (typeof header === "string") {
    const match = /^Bearer\s+(.+)$/i.exec(header);
    if (match?.[1] !== undefined) return match[1];
  }
  return undefined;
}

export async function resolveAuthContext(req: FastifyRequest): Promise<AuthContext> {
  const bearer = readBearer(req);
  if (bearer !== undefined) {
    try {
      const { user_id, customer_id } = await verifyAccessToken(bearer);
      return { state: "authenticated", user_id, customer_id };
    } catch {
      // fall through — invalid/expired bearer is treated as anon
    }
  }

  const signupCookieRaw = req.cookies[SIGNUP_SESSION_COOKIE];
  if (typeof signupCookieRaw === "string" && signupCookieRaw.length > 0) {
    try {
      const { signup_pending_id } = await verifySignupSessionToken(signupCookieRaw);
      return { state: "pending", signup_pending_id };
    } catch {
      // expired / invalid cookie → anon
    }
  }

  return { state: "anon" };
}
