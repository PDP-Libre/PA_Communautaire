import { randomInt } from "node:crypto";

import { hash, verify } from "@node-rs/bcrypt";
import type postgres from "postgres";

/**
 * Stateful one-time password storage: `otp_codes` table. Each row holds
 * a bcrypt hash of a 6-digit numeric code, scoped to either a `user_id`
 * (login MFA) or a `signup_pending_id` (phase 1).
 *
 * - 6 digits, generated via `crypto.randomInt`.
 * - bcrypt cost 10 (PRD-compliant for hashed secrets at rest).
 * - 5 min TTL (brief §pattern OTP).
 * - 3 attempts before the code is locked (consumed_at set + audit).
 */

export type OtpPurpose =
  | "phase1_mfa_setup"
  | "login_mfa"
  | "phase1_email_verify"
  | "phase1_secondary_verify"
  | "invite_secondary_verify";

const TTL_SECONDS = 5 * 60;
const MAX_ATTEMPTS = 3;
const BCRYPT_COST = 10;

export interface OtpOwner {
  user_id?: string;
  signup_pending_id?: string;
}

export interface IssuedOtp {
  id: string;
  /** Plain code, returned ONCE for delivery (email send). */
  code: string;
  expires_at: Date;
}

function generateCode(): string {
  return String(randomInt(0, 1_000_000)).padStart(6, "0");
}

/**
 * Issue a fresh OTP. Existing un-consumed OTPs of the same `purpose`+owner
 * are immediately consumed (consumed_at = NOW()) so only one valid code
 * is in flight at any time. Returns the plain code so the caller (email
 * sender) can deliver it; nothing else may persist or log it.
 */
export async function issueOtp(
  sql: postgres.Sql,
  owner: OtpOwner,
  purpose: OtpPurpose,
): Promise<IssuedOtp> {
  if (
    (owner.user_id === undefined && owner.signup_pending_id === undefined) ||
    (owner.user_id !== undefined && owner.signup_pending_id !== undefined)
  ) {
    throw new Error("OtpOwner must specify exactly one of user_id / signup_pending_id");
  }

  // Invalidate previous in-flight codes for the same owner+purpose.
  if (owner.user_id !== undefined) {
    await sql`
      UPDATE otp_codes
      SET consumed_at = NOW()
      WHERE user_id = ${owner.user_id}
        AND purpose = ${purpose}
        AND consumed_at IS NULL
    `;
  } else if (owner.signup_pending_id !== undefined) {
    await sql`
      UPDATE otp_codes
      SET consumed_at = NOW()
      WHERE signup_pending_id = ${owner.signup_pending_id}
        AND purpose = ${purpose}
        AND consumed_at IS NULL
    `;
  }

  const code = generateCode();
  const codeHash = await hash(code, BCRYPT_COST);

  const rows = await sql<{ id: string; expires_at: Date }[]>`
    INSERT INTO otp_codes (user_id, signup_pending_id, code_hash, purpose, expires_at)
    VALUES (
      ${owner.user_id ?? null},
      ${owner.signup_pending_id ?? null},
      ${codeHash},
      ${purpose},
      NOW() + INTERVAL '${sql.unsafe(String(TTL_SECONDS))} seconds'
    )
    RETURNING id, expires_at
  `;
  const row = rows[0];
  if (row === undefined) throw new Error("OTP insert failed");
  return { id: row.id, code, expires_at: row.expires_at };
}

export type ConsumeResult =
  | { kind: "ok" }
  | { kind: "no_active_code" }
  | { kind: "wrong_code"; attempts_remaining: number }
  | { kind: "locked" }
  | { kind: "expired" };

/**
 * Consume an OTP. Returns a discriminated outcome:
 *   - `ok` — code matched and was consumed (single-use)
 *   - `no_active_code` — no in-flight code for this owner+purpose
 *   - `wrong_code` — increment attempts, code still alive (or returns `locked` if threshold hit)
 *   - `locked` — code reached MAX_ATTEMPTS, marked consumed_at to invalidate
 *   - `expired` — code TTL elapsed (we treat it as `no_active_code` to caller; helper still
 *                 exposes the distinct kind for richer audit)
 */
export async function consumeOtp(
  sql: postgres.Sql,
  owner: OtpOwner,
  purpose: OtpPurpose,
  code: string,
): Promise<ConsumeResult> {
  let active: { id: string; code_hash: string; expires_at: Date; attempts: number } | undefined;
  if (owner.user_id !== undefined) {
    const rows = await sql<{ id: string; code_hash: string; expires_at: Date; attempts: number }[]>`
      SELECT id, code_hash, expires_at, attempts
      FROM otp_codes
      WHERE user_id = ${owner.user_id}
        AND purpose = ${purpose}
        AND consumed_at IS NULL
      ORDER BY created_at DESC
      LIMIT 1
    `;
    active = rows[0];
  } else if (owner.signup_pending_id !== undefined) {
    const rows = await sql<{ id: string; code_hash: string; expires_at: Date; attempts: number }[]>`
      SELECT id, code_hash, expires_at, attempts
      FROM otp_codes
      WHERE signup_pending_id = ${owner.signup_pending_id}
        AND purpose = ${purpose}
        AND consumed_at IS NULL
      ORDER BY created_at DESC
      LIMIT 1
    `;
    active = rows[0];
  }

  if (active === undefined) return { kind: "no_active_code" };

  if (active.expires_at.getTime() < Date.now()) {
    await sql`UPDATE otp_codes SET consumed_at = NOW() WHERE id = ${active.id}`;
    return { kind: "expired" };
  }

  const ok = await verify(code, active.code_hash);
  if (ok) {
    await sql`UPDATE otp_codes SET consumed_at = NOW() WHERE id = ${active.id}`;
    return { kind: "ok" };
  }

  const newAttempts = active.attempts + 1;
  if (newAttempts >= MAX_ATTEMPTS) {
    await sql`
      UPDATE otp_codes
      SET attempts = ${newAttempts}, consumed_at = NOW()
      WHERE id = ${active.id}
    `;
    return { kind: "locked" };
  }
  await sql`
    UPDATE otp_codes
    SET attempts = ${newAttempts}
    WHERE id = ${active.id}
  `;
  return { kind: "wrong_code", attempts_remaining: MAX_ATTEMPTS - newAttempts };
}

export const OTP_CONFIG = {
  ttlSeconds: TTL_SECONDS,
  maxAttempts: MAX_ATTEMPTS,
} as const;
