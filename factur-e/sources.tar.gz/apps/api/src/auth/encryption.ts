import { createCipheriv, createDecipheriv, randomBytes } from "node:crypto";

/**
 * AES-256-GCM for at-rest encryption of small secrets (TOTP MFA secret).
 *
 * Storage layouts (one bytea blob) :
 *   v1     : [0x01][12-byte IV][16-byte AUTH TAG][N-byte ciphertext]   ← current
 *   legacy : [12-byte IV][16-byte AUTH TAG][N-byte ciphertext]         ← pre-T-CL-02
 *
 * Versioning rationale (T-CL-02 sprint-03 — audit architecture sprint-02 §4.5) :
 * a single byte prefix lets us bump the layout (e.g. when rotating the key,
 * widening the IV, or migrating to AES-GCM-SIV) without ambiguity. The
 * `decrypt()` cascade tries v1 first when the heuristic matches (length +
 * leading 0x01) and falls through to legacy on auth-tag mismatch — robust
 * against the 1/256 chance of a legacy IV starting with 0x01.
 *
 * Migration policy : no one-shot script. Existing legacy blobs are re-encrypted
 * naturally at the next mutation (mfa-setup re-writes mfa_secret, IBAN update
 * re-writes customers.iban). The decrypt fallback supports both formats
 * indefinitely until we choose to drop legacy in a future sprint.
 *
 * Key sourced from `ENCRYPTION_KEY_HEX` env var (64 hex chars = 32 bytes).
 *  - Dev: macOS Keychain `factur-e-encryption-key` exported by
 *    `scripts/dev/load-secrets.sh`.
 *  - Prod: Scaleway Secret Manager `/factur-e/prod/encryption/key`.
 *  - Tests: `tests/setup.ts` sets a fixed dummy.
 *
 * Algorithm choice: AES-256-GCM authenticates the ciphertext (tag) so
 * tampering is detected at decrypt. Nonce reuse with GCM is catastrophic
 * — we always pick a fresh 96-bit IV per encryption.
 */

const IV_LENGTH = 12;
const TAG_LENGTH = 16;
const KEY_LENGTH = 32;

const VERSION_V1 = 0x01;
const V1_PREFIX_LENGTH = 1;
const LEGACY_MIN_LENGTH = IV_LENGTH + TAG_LENGTH;
const V1_MIN_LENGTH = V1_PREFIX_LENGTH + IV_LENGTH + TAG_LENGTH;

function getKey(): Buffer {
  const hex = process.env.ENCRYPTION_KEY_HEX;
  if (hex === undefined || hex === "") {
    throw new Error(
      "ENCRYPTION_KEY_HEX env var missing. " +
        "Dev: load via scripts/dev/load-secrets.sh (Keychain `factur-e-encryption-key`).",
    );
  }
  if (hex.length !== KEY_LENGTH * 2) {
    throw new Error(
      `ENCRYPTION_KEY_HEX must be ${String(KEY_LENGTH * 2)} hex chars (${String(KEY_LENGTH)} bytes); got ${String(hex.length)}.`,
    );
  }
  const buf = Buffer.from(hex, "hex");
  if (buf.length !== KEY_LENGTH) {
    throw new Error("ENCRYPTION_KEY_HEX is not valid hex.");
  }
  return buf;
}

/** Always emits a v1 blob (prefixed with version byte 0x01). */
export function encrypt(plain: Buffer | string): Buffer {
  const key = getKey();
  const iv = randomBytes(IV_LENGTH);
  const cipher = createCipheriv("aes-256-gcm", key, iv);
  const plainBuf = typeof plain === "string" ? Buffer.from(plain, "utf8") : plain;
  const ciphertext = Buffer.concat([cipher.update(plainBuf), cipher.final()]);
  const tag = cipher.getAuthTag();
  return Buffer.concat([Buffer.from([VERSION_V1]), iv, tag, ciphertext]);
}

function decryptCore(key: Buffer, iv: Buffer, tag: Buffer, ciphertext: Buffer): Buffer {
  const decipher = createDecipheriv("aes-256-gcm", key, iv);
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(ciphertext), decipher.final()]);
}

function decryptLegacy(blob: Buffer, key: Buffer): Buffer {
  if (blob.length < LEGACY_MIN_LENGTH) {
    throw new Error("encrypted blob too short");
  }
  const iv = blob.subarray(0, IV_LENGTH);
  const tag = blob.subarray(IV_LENGTH, IV_LENGTH + TAG_LENGTH);
  const ciphertext = blob.subarray(IV_LENGTH + TAG_LENGTH);
  return decryptCore(key, iv, tag, ciphertext);
}

function decryptV1(blob: Buffer, key: Buffer): Buffer {
  // Caller has already checked blob[0] === 0x01 + length sanity.
  const iv = blob.subarray(V1_PREFIX_LENGTH, V1_PREFIX_LENGTH + IV_LENGTH);
  const tag = blob.subarray(
    V1_PREFIX_LENGTH + IV_LENGTH,
    V1_PREFIX_LENGTH + IV_LENGTH + TAG_LENGTH,
  );
  const ciphertext = blob.subarray(V1_PREFIX_LENGTH + IV_LENGTH + TAG_LENGTH);
  return decryptCore(key, iv, tag, ciphertext);
}

/**
 * Cascade try-decrypt — supports both v1 (current) and legacy (pre-T-CL-02)
 * blob layouts. The 1/256 collision case (legacy IV starts with 0x01) is
 * resolved by GCM's auth-tag verification : a wrong layout interpretation
 * produces an auth-tag mismatch, we then fall through to the other format.
 */
export function decrypt(blob: Buffer): Buffer {
  const key = getKey();

  // Try v1 first if the heuristic plausibly matches : leading byte 0x01
  // and overall length compatible with the v1 layout.
  if (blob.length >= V1_MIN_LENGTH && blob[0] === VERSION_V1) {
    try {
      return decryptV1(blob, key);
    } catch {
      // Auth-tag mismatch → 0x01 was a coincidental IV byte on a legacy
      // blob. Fall through to the legacy path.
    }
  }

  return decryptLegacy(blob, key);
}
