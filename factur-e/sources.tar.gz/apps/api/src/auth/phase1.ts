import { randomUUID } from "node:crypto";

import type postgres from "postgres";

import * as customersRepo from "../db/repos/customers.js";
import * as signupPendingRepo from "../db/repos/signup_pending.js";
import * as usersRepo from "../db/repos/users.js";
import { insertSession, withTransaction } from "../db/tx.js";

import { writeAuthAudit } from "./audit.js";
import { signAccessToken, signRefreshToken, TTL_SECONDS } from "./jwt.js";

/**
 * Atomic finalization of the phase 1 onboarding (cf. plan T-CL-03 §3c).
 * Reads `signup_pending`, validates state, then in a single transaction:
 *   1. INSERT customers (data prefilled by INSEE response, T-CL-05)
 *   2. INSERT users (role=full, can_purchase=true — first user is always
 *      Responsable, brief §5.1 phase 1)
 *   3. DELETE signup_pending
 *   4. INSERT sessions + emit access+refresh tokens
 *
 * Discriminated outcome lets the caller route to HTTP status codes:
 *   - `success`  → 200 with access_token + cookies set
 *   - `decoy`    → 401 neutral (anti-énumération brief §6.1)
 *   - `incomplete` → 400 with `current_step` to resume
 *   - `expired`  → 410 (signup_pending past TTL or not found)
 *
 * `email_verified_at` and `secondary_email_verified_at` are required by
 * spec; until T-CL-04 (Scaleway TEM) wires the verification endpoints,
 * tests seed these fields directly. T-CL-03 does not relax the check.
 */

export type FinalizeResult =
  | {
      kind: "success";
      access_token: string;
      refresh_token: string;
      user_id: string;
      customer_id: string;
      access_ttl_seconds: number;
    }
  | { kind: "decoy" }
  | { kind: "incomplete"; current_step: string; missing: string }
  | { kind: "expired" };

export async function finalizePhase1(
  sql: postgres.Sql,
  signupPendingId: string,
  meta: { ip?: string | null; user_agent?: string | null },
): Promise<FinalizeResult> {
  const row = await signupPendingRepo.findPendingFullById(sql, signupPendingId);
  if (row === undefined || row.expires_at.getTime() < Date.now()) {
    return { kind: "expired" };
  }

  if (row.is_decoy) {
    // Anti-énumération: silently delete and reply with the same neutral
    // 401 the route will turn into. Audit it for support visibility.
    await signupPendingRepo.deletePendingById(sql, row.id);
    await writeAuthAudit(sql, {
      event_type: "signup_decoy_blocked",
      success: false,
      ip: meta.ip ?? null,
      user_agent: meta.user_agent ?? null,
      metadata: { email: row.email, signup_pending_id: row.id },
    });
    return { kind: "decoy" };
  }

  // Required fields ordered by `current_step` progression so the message
  // points at the earliest missing prerequisite the user can act on.
  const checks: { ok: boolean; step: string; missing: string }[] = [
    { ok: row.siren !== null, step: "siren", missing: "siren" },
    {
      ok: row.customer_data_prefilled !== null,
      step: "siret",
      missing: "customer_data_prefilled",
    },
    { ok: row.email_verified_at !== null, step: "email_verify", missing: "email_verified_at" },
    {
      ok: row.secondary_email_verified_at !== null,
      step: "secondary_email",
      missing: "secondary_email_verified_at",
    },
    {
      ok: row.mfa_setup_completed_at !== null,
      step: "mfa_setup",
      missing: "mfa_setup_completed_at",
    },
    {
      ok: row.recovery_codes_acked_at !== null,
      step: "recovery_codes",
      missing: "recovery_codes_acked_at",
    },
  ];
  for (const c of checks) {
    if (!c.ok) {
      return { kind: "incomplete", current_step: c.step, missing: c.missing };
    }
  }

  // Defensive — after the checks above, all of these are non-null.
  const prefilled = row.customer_data_prefilled;
  if (prefilled === null || row.siren === null) {
    return { kind: "incomplete", current_step: "siren", missing: "customer_data_prefilled" };
  }

  const rawLegalName = prefilled.legal_name ?? prefilled.denominationUniteLegale;
  const legalName = typeof rawLegalName === "string" ? rawLegalName : "";
  const nafCode =
    typeof prefilled.naf_code === "string"
      ? prefilled.naf_code
      : typeof prefilled.activitePrincipaleUniteLegale === "string"
        ? prefilled.activitePrincipaleUniteLegale
        : null;
  const juridiqueCode =
    typeof prefilled.juridique_code === "string"
      ? prefilled.juridique_code
      : typeof prefilled.categorieJuridiqueUniteLegale === "string"
        ? prefilled.categorieJuridiqueUniteLegale
        : null;
  const address =
    typeof prefilled.address === "object" && prefilled.address !== null
      ? (prefilled.address as Record<string, unknown>)
      : {};
  // ALWAYS true at signup time. INSEE Sirene gives us a publicly-available
  // snapshot — that's not the same thing as a verified identity attestation.
  // The flag is cleared only when the PA (SuperPDP) onboarding returns a
  // KYC attestation (sprint-03). Drives the "à confirmer" badge in
  // post-onboarding UIs.
  const profileUnverified = true;
  void prefilled.is_manual; // intentionally unused now that the flag is unconditional

  const sessionId = randomUUID();
  let userId = "";
  let customerId = "";
  // Closure capture: TS narrows `row.siren` to `string` here, but the
  // narrowing doesn't survive the async lambda — alias it locally.
  const siren = row.siren;

  await withTransaction(sql, async (tx) => {
    const c = await customersRepo.insertCustomerFromPhase1(tx, {
      siren,
      legalName,
      address: address as postgres.JSONValue,
      nafCode,
      juridiqueCode,
      directoryAddress: siren,
      profileUnverified,
    });
    customerId = c.id;

    const u = await usersRepo.insertUserFromPhase1(tx, {
      customerId,
      email: row.email,
      passwordHash: row.password_hash,
      mfaSecret: row.mfa_secret_pending,
      mfaMode: row.mfa_mode_choice ?? "none",
      mfaEnrolledAt: row.mfa_setup_completed_at,
      recoveryCodesHashed: row.recovery_codes_pending,
      role: "full",
      canPurchase: true,
      emailVerifiedAt: row.email_verified_at,
      secondaryEmail: row.secondary_email ?? "",
      secondaryEmailVerifiedAt: row.secondary_email_verified_at,
      termsAcceptedAt: row.terms_accepted_at,
    });
    userId = u.id;

    await signupPendingRepo.deletePendingById(tx, row.id);

    await insertSession(tx, {
      id: sessionId,
      userId,
      ip: meta.ip ?? null,
      userAgent: meta.user_agent ?? null,
    });
  });

  await writeAuthAudit(sql, {
    event_type: "signup_completed",
    success: true,
    user_id: userId,
    customer_id: customerId,
    ip: meta.ip ?? null,
    user_agent: meta.user_agent ?? null,
    metadata: { signup_pending_id: row.id, session_id: sessionId },
  });

  const accessToken = await signAccessToken({ user_id: userId, customer_id: customerId });
  const refreshToken = await signRefreshToken({
    session_id: sessionId,
    user_id: userId,
  });

  return {
    kind: "success",
    access_token: accessToken,
    refresh_token: refreshToken,
    user_id: userId,
    customer_id: customerId,
    access_ttl_seconds: TTL_SECONDS.access,
  };
}
