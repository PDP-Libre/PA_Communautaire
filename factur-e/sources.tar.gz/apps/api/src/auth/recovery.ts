import { randomBytes } from "node:crypto";

import { hash, verify } from "@node-rs/bcrypt";

/**
 * Recovery codes for MFA bypass. 10 single-use codes generated at MFA
 * setup, hashed bcrypt (cost 10), shown to the user once in plain text
 * for download / paper backup. Format: `XXXX-XXXX-XXXX` (12 hex chars
 * grouped) — easy to read and dictate over the phone.
 */

const COUNT = 10;
const HEX_CHARS = 12;
const BCRYPT_COST = 10;

function formatCode(hex: string): string {
  return `${hex.slice(0, 4)}-${hex.slice(4, 8)}-${hex.slice(8, 12)}`;
}

function normalizeCandidate(code: string): string {
  return code.replace(/[\s-]/g, "").toLowerCase();
}

/**
 * Generate `COUNT` plain codes plus their bcrypt hashes. Both arrays
 * align by index. Caller persists the hashes and returns the plain
 * codes ONCE in the API response.
 */
export async function generateRecoveryCodes(): Promise<{
  plain: string[];
  hashed: string[];
}> {
  const plain: string[] = [];
  const hashed: string[] = [];
  for (let i = 0; i < COUNT; i++) {
    const hex = randomBytes(HEX_CHARS / 2).toString("hex");
    const code = formatCode(hex);
    plain.push(code);
    hashed.push(await hash(hex, BCRYPT_COST));
  }
  return { plain, hashed };
}

/**
 * Match `candidate` against the user's stored hashes. Returns the index
 * of the consumed hash on success (caller removes it), or `-1` on no
 * match. Whitespace and dashes in `candidate` are tolerated.
 */
export async function findMatchingRecoveryHash(
  storedHashes: readonly string[],
  candidate: string,
): Promise<number> {
  const normalized = normalizeCandidate(candidate);
  if (normalized.length !== HEX_CHARS) return -1;
  for (let i = 0; i < storedHashes.length; i++) {
    const h = storedHashes[i];
    if (h === undefined) continue;
    if (await verify(normalized, h)) return i;
  }
  return -1;
}

export const RECOVERY_CONFIG = {
  count: COUNT,
} as const;
