import "@fastify/cookie";

import type { FastifyReply } from "fastify";

import { TTL_SECONDS } from "./jwt.js";

/**
 * Cookie helpers for the two HttpOnly cookies set by the auth flow.
 *
 * `signup_session` — HttpOnly, SameSite=Lax, 7 d. Lax (vs Strict) so the
 *   magic email link in §6.4 carries the cookie back to the app on first
 *   navigation.
 *
 * `_session` — HttpOnly, Secure, SameSite=Strict, 30 d. Holds the refresh
 *   token; consumed by `/auth/refresh` (T-CL-04+).
 *
 * Both cookies are flagged Secure in production. In tests / dev over HTTP
 * we drop Secure so the browser accepts the cookie on `localhost`.
 */

const isProd = (): boolean => process.env.NODE_ENV === "production";

export const SIGNUP_SESSION_COOKIE = "signup_session";
export const REFRESH_SESSION_COOKIE = "_session";

export function setSignupSessionCookie(reply: FastifyReply, token: string): void {
  reply.setCookie(SIGNUP_SESSION_COOKIE, token, {
    httpOnly: true,
    secure: isProd(),
    sameSite: "lax",
    path: "/",
    maxAge: TTL_SECONDS.signup,
  });
}

export function clearSignupSessionCookie(reply: FastifyReply): void {
  reply.clearCookie(SIGNUP_SESSION_COOKIE, { path: "/" });
}

export function setRefreshSessionCookie(reply: FastifyReply, token: string): void {
  reply.setCookie(REFRESH_SESSION_COOKIE, token, {
    httpOnly: true,
    secure: isProd(),
    sameSite: "strict",
    path: "/",
    maxAge: TTL_SECONDS.refresh,
  });
}

export function clearRefreshSessionCookie(reply: FastifyReply): void {
  reply.clearCookie(REFRESH_SESSION_COOKIE, { path: "/" });
}
