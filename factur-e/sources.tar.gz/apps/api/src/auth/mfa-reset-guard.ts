import type { FastifyInstance, FastifyReply, FastifyRequest } from "fastify";

import { apiError } from "@factur-e/shared-schemas";

import * as usersRepo from "../db/repos/users.js";
import { resolveAuthContext } from "./context.js";

/**
 * `mfa_reset_required` enforcement preHandler — T-CL-03 sprint-03.
 *
 * Background. When an admin (or self-service recovery flow) sets
 * `users.mfa_reset_required = TRUE`, the user must re-enroll their MFA
 * factor before any sensitive action lands. Sprint-02 delegated this gate
 * to the SPA, which is single-factor coverage. This middleware ports the
 * gate to the backend so a forged / stale frontend cannot bypass it.
 *
 * Scope. The guard fires on six prefix groups that mutate or read
 * sensitive customer / user data : `/customers`, `/users`, `/profile`,
 * `/invitations` (T-CL-03 sprint-03), plus `/oauth/superpdp` and
 * `/pa` added in T-CL-06 sprint-03 — a user with a pending MFA reset
 * shouldn't be able to trigger a fresh PA OAuth flow before clearing
 * the flag. Only `/auth/*` stays prefix-libre because it carries the
 * `/auth/setup-mfa` reconfiguration endpoint that lifts the flag.
 *
 * The OAuth callback `/oauth/superpdp/callback` is anon (the user
 * arrives via a SuperPDP redirect carrying state + code in the URL),
 * so the `state !== "authenticated"` early-return below lets it pass
 * naturally. The prefix-bypass that previously covered `/oauth/*`
 * (T-CL-03) was a wider exemption than necessary — the anon-bypass
 * alone is sufficient for the callback case.
 *
 * Anonymous + pending-signup requests pass through (the route they hit
 * decides whether to 401 or 403). Authenticated requests trigger one
 * lean SELECT against the read pool.
 *
 * Forward compat. New top-level prefixes — sprint-04+ `/invoices`,
 * `/payments`, etc. — are caught by the route inventory test
 * (`tests/http/auth/mfa-reset-guard.it.test.ts`) which fails until the
 * author either adds the prefix to `MFA_PROTECTED_PREFIXES` or
 * justifies it under `ALLOWED_UNGUARDED_*`.
 *
 * cf. retro sprint-02 §"Dette créée ce sprint" point [medium] +
 * ADR-006 (politique MFA rôles privilégiés) + ADR-007 (profile_unverified) +
 * patch design T-CL-06 sprint-03 (oauth/superpdp + pa added).
 */

export const MFA_PROTECTED_PREFIXES = [
  // T-CL-03 sprint-03.
  "/customers",
  "/users",
  "/profile",
  "/invitations",
  // T-CL-06 sprint-03 — patch design : a user with mfa_reset_required
  // shouldn't trigger a fresh PA OAuth flow nor read the PA status.
  "/oauth/superpdp",
  "/pa",
  // T-CL-10 sprint-03 — annuaire SuperPDP. Un user avec mfa_reset_required
  // ne doit pas pouvoir interroger l'annuaire ni mémoriser des préférences
  // (cohérent avec le bloc OAuth ci-dessus — usage légitime requiert
  // une session pleine).
  "/api/directory",
  // T-CL-12 sprint-03 — catalogue Articles (table BDD `products`). Un
  // user mfa_reset_required ne doit pas créer/modifier des articles
  // partagés avec les autres users du customer.
  "/api/products",
  // T-CL-API-INVOICE sprint-04 — émission factures + brouillons. Un
  // user avec mfa_reset_required ne doit pas pouvoir émettre une
  // facture, modifier un brouillon, ni consulter le cycle de vie
  // CDAR — toute action affectant le customer multi-tenant est gated.
  "/api/invoices",
  "/api/invoice-drafts",
  // T-CL-RECV-API sprint-05 W2 — Réception (factures reçues). Surface
  // business multi-tenant : un user mfa_reset_required ne doit pas
  // consulter les factures reçues ni poser de statut CDAR (205/210) ni
  // télécharger les PDF/XML originaux. Gated comme l'émission.
  "/api/received-invoices",
  // T-CL-EXPORT-ZIP-RETENTION sprint-06 L12 — Export ZIP + alertes rétention.
  // Surface données sensibles (export complet émission/réception) : un user
  // mfa_reset_required ne doit pas déclencher d'export ni télécharger une
  // archive. Le dashboard rétention est gated de même (cohérence UI).
  "/api/exports",
  "/api/dashboard",
] as const;

/** Top-level prefixes that intentionally bypass the guard. Cf. file
 *  header for rationale.
 *
 *  - `/auth` : flows d'auth (login, signup, MFA reset) qui n'ont pas de
 *    user authentifié post-MFA-reset par construction.
 *  - `/__dev` : routes de seed/reset Playwright, gated NODE_ENV !==
 *    production. Pas d'auth — c'est volontaire (cf. test-playwright.md).
 *  - `/__fake` : bridge HTTP fakeSuperPdp pour T-BR-03 sprint-04+
 *    (T-CL-16 sprint-03), gated NODE_ENV !== production. Même profil
 *    sécurité que `/__dev`.
 *  - `/api/v1/webhooks` : webhooks PA (T-CL-PA-EXT sprint-04), pas
 *    d'auth user — signature HMAC suffit pour authenticité (ADR-009 D4).
 *    Le `mfa_reset_required` ne s'applique pas à un appel partenaire
 *    sortant qui ne porte pas de session utilisateur.
 */
export const MFA_GUARD_ALLOWED_UNGUARDED_PREFIXES = [
  "/auth",
  "/__dev",
  "/__fake",
  "/api/v1/webhooks",
] as const;

/** Single-segment routes that aren't part of any prefix group above.
 *  - `/health` : liveness probe (no auth).
 *  - `/api/pa/providers` : T-CL-PA-INVOICE-FIX sprint-04 — liste
 *    publique des PA disponibles (ADR-012 D8). Pas d'auth car consommé
 *    en pré-login par l'UI Bloc 3 onboarding pour pré-construire le
 *    sélecteur. Aucune donnée tenant-cross exposée. */
export const MFA_GUARD_ALLOWED_UNGUARDED_EXACT = ["/health", "/api/pa/providers"] as const;

function pathOnly(url: string): string {
  const qIdx = url.indexOf("?");
  return qIdx === -1 ? url : url.slice(0, qIdx);
}

/** True when `url` equals `prefix` exactly (e.g. `/users`) or starts with
 *  `prefix + '/'` (e.g. `/users/me/profile`). Returns false on prefix
 *  collisions like `/users-foo` so adding a `/users-stats` route in the
 *  future doesn't accidentally pull it under the guard. */
export function matchesPrefix(url: string, prefix: string): boolean {
  const path = pathOnly(url);
  return path === prefix || path.startsWith(prefix + "/");
}

export function isMfaProtectedUrl(url: string): boolean {
  return MFA_PROTECTED_PREFIXES.some((p) => matchesPrefix(url, p));
}

/**
 * Build the preHandler. Closes over `app` so the read connection is
 * resolved once at registration time. Returning the reply early stops
 * Fastify from invoking the route handler.
 */
function makeGuard(app: FastifyInstance) {
  return async function mfaResetGuard(
    req: FastifyRequest,
    reply: FastifyReply,
  ): Promise<FastifyReply | undefined> {
    if (!isMfaProtectedUrl(req.url)) return undefined;

    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") return undefined;

    const row = await usersRepo.findActiveUserMfaResetRequiredById(app.sqlRead, ctx.user_id);
    if (row?.mfa_reset_required === true) {
      // Enveloppe d'erreur standard (NC-15) : `message` user-facing + `code`
      // machine (remplace l'ancien `{reason}` sans message). Le routing SPA
      // s'appuie sur `me.data.user.mfa_reset_required`, pas sur ce corps.
      return reply.code(403).send(
        apiError("Réinitialisation de votre double authentification requise.", {
          code: "mfa_reset_required",
        }),
      );
    }
    return undefined;
  };
}

export function registerMfaResetGuard(app: FastifyInstance): void {
  app.addHook("preHandler", makeGuard(app));
}
