import type postgres from "postgres";

/**
 * Append-only audit trail for auth events. Cf. plan T-CL-01 — `event_type`
 * is `text` (not enum) to allow extension without a migration. Service-level
 * convention is to use the documented event names listed in the migration:
 * signup_success, signup_failed, login_success, login_failed, logout, …
 */

export interface AuthAuditEvent {
  event_type: string;
  success: boolean;
  user_id?: string | null;
  customer_id?: string | null;
  ip?: string | null;
  user_agent?: string | null;
  metadata?: Record<string, unknown>;
}

export async function writeAuthAudit(sql: postgres.Sql, event: AuthAuditEvent): Promise<void> {
  await sql`
    INSERT INTO auth_audit (event_type, success, user_id, customer_id, ip, user_agent, metadata)
    VALUES (
      ${event.event_type},
      ${event.success},
      ${event.user_id ?? null},
      ${event.customer_id ?? null},
      ${event.ip ?? null},
      ${event.user_agent ?? null},
      ${sql.json((event.metadata ?? {}) as postgres.JSONValue)}
    )
  `;
}
