import "@fastify/cookie";

import type { FastifyRequest } from "fastify";
import type postgres from "postgres";

import * as sessionsRepo from "../db/repos/sessions.js";
import * as usersRepo from "../db/repos/users.js";

import type { AnonContext, AuthenticatedContext } from "./context.js";
import { REFRESH_SESSION_COOKIE } from "./cookies.js";
import { verifyRefreshToken } from "./jwt.js";

/**
 * Résout l'auth d'un flux SSE à partir du cookie HttpOnly `_session`
 * (refresh token, SameSite=Strict, posé au login `routes/auth/login.ts`).
 *
 * Resolver dédié plutôt que `resolveAuthContext` (T-CL-AUTH-SSE-COOKIE-HTTPONLY
 * sprint-06, arbitrage Bruno Z9) :
 *   - `EventSource` ne peut pas poser de header `Authorization` → le bearer
 *     transitait avant en `?token=` query (exposition dans les logs reverse-
 *     proxy, le Referer et l'historique navigateur — ADR-006/008). Vecteur
 *     supprimé : l'auth SSE passe désormais uniquement par le cookie HttpOnly.
 *   - aucun cookie d'access token court-vie n'existe (l'access token ne vit
 *     qu'en RAM côté SPA) ; on réutilise donc le cookie refresh `_session`.
 *   - périmètre volontairement limité au SSE : on NE touche pas
 *     `resolveAuthContext` (les autres routes restent en Bearer header) pour
 *     ne pas élargir la surface d'auth. Same-origin via proxy Vite (ADR-014)
 *     ⇒ `SameSite=Strict` suffit, le cookie est envoyé avec `withCredentials`.
 *
 * Validation identique à `POST /auth/refresh` : signature refresh valide +
 * session active (non révoquée, non expirée) + user actif. Lecture seule.
 */
export async function resolveSseAuthContext(
  req: FastifyRequest,
  sql: postgres.Sql,
): Promise<AuthenticatedContext | AnonContext> {
  const cookie = req.cookies[REFRESH_SESSION_COOKIE];
  if (typeof cookie !== "string" || cookie.length === 0) {
    return { state: "anon" };
  }

  let payload;
  try {
    payload = await verifyRefreshToken(cookie);
  } catch {
    // Signature invalide / expirée / mauvaise audience → anon.
    return { state: "anon" };
  }

  const session = await sessionsRepo.findActiveSessionForRefresh(sql, {
    sessionId: payload.session_id,
    userId: payload.user_id,
  });
  if (session === undefined) {
    return { state: "anon" };
  }

  const user = await usersRepo.findActiveUserCustomerById(sql, payload.user_id);
  if (user === undefined) {
    return { state: "anon" };
  }

  return { state: "authenticated", user_id: user.id, customer_id: user.customer_id };
}
