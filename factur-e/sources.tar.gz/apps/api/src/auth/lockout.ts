import type postgres from "postgres";

/**
 * Login lockout per PRD §5.1 US-AUTH-002 / §7.1: 5 failed attempts within
 * 15 min triggers a 30-min lockout. Counted on the fly via `auth_audit`
 * to avoid an extra column on `users` and keep the policy easily tunable.
 *
 * The 15-min window is the failure-count window. Lockout itself extends
 * 30 min from the most recent failure: as long as one of the last 5
 * `login_failed` events happened in the last 30 min, the account is
 * locked.
 *
 * IP lockout (T-CL-02 sprint-03 — audit architecture sprint-02 §4.9) :
 * 20 fails / 30 min from the same IP triggers a lockout. Complements the
 * per-email lockout to defeat slow enumeration where an attacker scans
 * many emails from a single IP — the email-based lockout never fires
 * because each email reaches at most 4 fails.
 */

const FAIL_WINDOW_MIN = 15;
const LOCKOUT_DURATION_MIN = 30;
const FAIL_THRESHOLD = 5;

const IP_FAIL_THRESHOLD = 20;
const IP_LOCKOUT_DURATION_MIN = 30;

export async function isEmailLockedOut(sql: postgres.Sql, email: string): Promise<boolean> {
  const rows = await sql<{ count: string }[]>`
    SELECT COUNT(*)::text AS count
    FROM auth_audit
    WHERE event_type = 'login_failed'
      AND metadata ->> 'email' = ${email}
      AND occurred_at > NOW() - INTERVAL '${sql.unsafe(String(LOCKOUT_DURATION_MIN))} minutes'
  `;
  const recent = rows[0];
  if (recent === undefined) return false;
  return Number(recent.count) >= FAIL_THRESHOLD;
}

/**
 * IP-based lockout — independent of `isEmailLockedOut`. Both checks fire
 * before the password verify on `/auth/login`; either match returns the
 * same neutral 401 (anti-énumération).
 */
export async function isIpLockedOut(sql: postgres.Sql, ip: string): Promise<boolean> {
  const rows = await sql<{ count: string }[]>`
    SELECT COUNT(*)::text AS count
    FROM auth_audit
    WHERE event_type = 'login_failed'
      AND ip = ${ip}::inet
      AND occurred_at > NOW() - INTERVAL '${sql.unsafe(String(IP_LOCKOUT_DURATION_MIN))} minutes'
  `;
  const recent = rows[0];
  if (recent === undefined) return false;
  return Number(recent.count) >= IP_FAIL_THRESHOLD;
}

export const LOCKOUT_CONFIG = {
  failWindowMinutes: FAIL_WINDOW_MIN,
  lockoutDurationMinutes: LOCKOUT_DURATION_MIN,
  failThreshold: FAIL_THRESHOLD,
  ipFailThreshold: IP_FAIL_THRESHOLD,
  ipLockoutDurationMinutes: IP_LOCKOUT_DURATION_MIN,
} as const;
