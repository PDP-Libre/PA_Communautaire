import { Secret, TOTP } from "otpauth";
import QRCode from "qrcode";

/**
 * TOTP wrapper (RFC 6238). 20 random bytes secret (160 bits, RFC reco),
 * SHA-1 (default authenticator support), 6 digits, 30s step, ±1 step
 * verification window for clock drift tolerance.
 *
 * Issuer label "Factur-e" appears in the authenticator app. Internally
 * we manipulate raw bytes via `Buffer` for storage / encryption, and
 * cross over into otpauth's `Secret` via hex (avoids Buffer-vs-
 * ArrayBuffer typing friction with `Uint8Array`).
 */

const ISSUER = "Factur-e";
const DIGITS = 6;
const PERIOD = 30;
const ALGORITHM = "SHA1";
const SECRET_BYTES = 20;

/** Generate a fresh 160-bit secret in raw bytes. */
export function generateTotpSecret(): Buffer {
  return Buffer.from(new Secret({ size: SECRET_BYTES }).hex, "hex");
}

function secretFromBytes(bytes: Buffer): Secret {
  return Secret.fromHex(bytes.toString("hex"));
}

export function totpUriFromSecret(secretBytes: Buffer, accountLabel: string): string {
  // Pourquoi construire le URI manuellement plutôt que `new TOTP({...}).toString()` :
  // `otpauth` lib génère `otpauth://totp/Factur-e:user@mail?secret=...&issuer=Factur-e`
  // (préfixe issuer dans le label, RFC backward-compat). Les authenticator
  // apps lisent BOTH le préfixe ET le param `issuer=`, ce qui affiche dans
  // l'alerte d'import « Factur-e, Factur-e:user@mail » (retour Bruno test
  // T-CL-15). En émettant juste l'email comme label, l'alerte devient
  // « Factur-e, user@mail » — propre, le service est listé "Factur-e" +
  // sous-titre email côté authenticator.
  const secret = secretFromBytes(secretBytes);
  const params = new URLSearchParams({
    secret: secret.base32,
    issuer: ISSUER,
    algorithm: ALGORITHM,
    digits: String(DIGITS),
    period: String(PERIOD),
  });
  return `otpauth://totp/${encodeURIComponent(accountLabel)}?${params.toString()}`;
}

export async function totpQrSvgFromUri(uri: string): Promise<string> {
  return QRCode.toString(uri, { type: "svg", margin: 1, width: 240 });
}

/** Verify a TOTP code with ±1 step tolerance (~30s drift each way). */
export function verifyTotpCode(secretBytes: Buffer, code: string): boolean {
  const totp = new TOTP({
    issuer: ISSUER,
    algorithm: ALGORITHM,
    digits: DIGITS,
    period: PERIOD,
    secret: secretFromBytes(secretBytes),
  });
  const delta = totp.validate({ token: code, window: 1 });
  return delta !== null;
}

/** Test helper: compute the current TOTP code for a given secret. */
export function currentTotpCode(secretBytes: Buffer): string {
  const totp = new TOTP({
    issuer: ISSUER,
    algorithm: ALGORITHM,
    digits: DIGITS,
    period: PERIOD,
    secret: secretFromBytes(secretBytes),
  });
  return totp.generate();
}
