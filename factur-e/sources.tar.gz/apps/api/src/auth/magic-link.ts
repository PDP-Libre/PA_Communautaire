import { SignJWT, jwtVerify } from "jose";

/**
 * Magic-link JWT helper. Stateless: a link's validity is encoded entirely
 * in the JWT signature + expiration. Single-use enforcement is delegated
 * to the consuming flow:
 *
 *   - `email_verify` (phase 1): the link is consumed when
 *     `signup_pending.email_verified_at` becomes non-null. Re-clicking
 *     does not flip back to null, so the second attempt finds a verified
 *     row and the route returns 410.
 *
 *   - `password_reset`: the JWT carries a hash of the user's current
 *     `password_hash` ("hash marker"). Resetting the password mutates
 *     `password_hash`, which makes the marker mismatch on subsequent
 *     verify calls — the token is implicitly invalidated.
 *
 * TTL is 1 h per brief §6.4 (verify email) / §5.4 (reset password).
 *
 * Audience is `factur-e:magic-link`. Purpose is a JWT claim the consumer
 * checks to refuse cross-purpose token reuse (a verify token can't be
 * used to reset a password and vice-versa).
 */

import { createHash } from "node:crypto";

const TTL_SECONDS = 60 * 60;
const AUDIENCE = "factur-e:magic-link";

export type MagicLinkPurpose = "email_verify" | "password_reset";

export interface MagicLinkPayload {
  purpose: MagicLinkPurpose;
  /** signup_pending.id for `email_verify`, users.id for `password_reset`. */
  target_id: string;
  /** Recipient email (used for display + audit). */
  email: string;
  /** Marker used by `password_reset` to invalidate after a password change.
   *  Empty string for `email_verify` (single-use is enforced by `email_verified_at`). */
  hash_marker: string;
}

function getKey(): Uint8Array {
  const raw = process.env.JWT_SIGNING_KEY;
  if (raw === undefined || raw.length < 32) {
    throw new Error("JWT_SIGNING_KEY env var missing or shorter than 32 chars.");
  }
  return new TextEncoder().encode(raw);
}

/** Short SHA-256 prefix of a stored password hash — never the hash itself. */
export function passwordHashMarker(passwordHash: string): string {
  return createHash("sha256").update(passwordHash).digest("hex").slice(0, 16);
}

export async function signMagicLink(payload: MagicLinkPayload): Promise<string> {
  return new SignJWT({ ...payload })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setAudience(AUDIENCE)
    .setExpirationTime(`${String(TTL_SECONDS)}s`)
    .sign(getKey());
}

export async function verifyMagicLink(token: string): Promise<MagicLinkPayload> {
  const { payload } = await jwtVerify(token, getKey(), { audience: AUDIENCE });
  const purpose = payload.purpose;
  const targetId = payload.target_id;
  const email = payload.email;
  const hashMarker = payload.hash_marker;
  if (
    (purpose !== "email_verify" && purpose !== "password_reset") ||
    typeof targetId !== "string" ||
    typeof email !== "string" ||
    typeof hashMarker !== "string"
  ) {
    throw new Error("invalid_magic_link_payload");
  }
  return { purpose, target_id: targetId, email, hash_marker: hashMarker };
}

export const MAGIC_LINK_TTL_SECONDS = TTL_SECONDS;
