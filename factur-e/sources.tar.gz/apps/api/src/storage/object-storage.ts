import { Buffer } from "node:buffer";

import {
  CreateBucketCommand,
  DeleteObjectCommand,
  GetObjectCommand,
  HeadBucketCommand,
  PutBucketLifecycleConfigurationCommand,
  PutBucketPolicyCommand,
  PutObjectCommand,
  S3Client,
} from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import type { FastifyInstance } from "fastify";

/**
 * Object storage contract — used for the customer logo (T-CL-06 §6.18)
 * and reserved for invoice PDFs (T-CL-08+).
 *
 * Two implementations:
 *   - `S3ObjectStorage` — `@aws-sdk/client-s3`, compatible with both
 *     MinIO (dev, S3-compat) and Scaleway Object Storage (prod, S3-compat).
 *   - `MockObjectStorage` — in-memory, used in tests.
 *
 * The path stored on `customers.logo_s3_key` is `customers/{customer_id}/
 * logo.{ext}`. The adapter doesn't care about the convention; it's the
 * routes' job to compute the key.
 */

export interface ObjectStorage {
  /** Upload an object. Overwrites existing object at the same key. */
  uploadObject(args: { key: string; body: Buffer; contentType: string }): Promise<void>;
  /** Best-effort delete. Missing object is not an error. */
  deleteObject(key: string): Promise<void>;
  /** Public URL (or pre-signed if private). T-CL-06 dev exposes MinIO
   *  publicly; prod will move to pre-signed URLs in T-CL-08+. */
  getObjectUrl(key: string): string;
  /** Download an object's raw bytes + content-type. Throws if missing.
   *  T-CL-EXPORT-ZIP-RETENTION — lecture des objets archivés. */
  downloadObject(key: string): Promise<{ body: Buffer; contentType: string }>;
  /** Pre-signed time-limited GET URL — buckets privés (exports). Le lien
   *  email pointe vers l'endpoint app qui génère cette URL à la volée. */
  getPresignedUrl(key: string, expiresInSec: number): Promise<string>;
}

declare module "fastify" {
  interface FastifyInstance {
    storage: ObjectStorage;
    /** Bucket privé dédié aux archives ZIP d'export (distinct des logos).
     *  T-CL-EXPORT-ZIP-RETENTION — jamais public-read, accès presigned. */
    exportsStorage: ObjectStorage;
  }
}

export interface S3ObjectStorageConfig {
  endpoint: string;
  region: string;
  bucket: string;
  accessKey: string;
  secretKey: string;
  /** S3-compat services (MinIO, Scaleway) require path-style addressing. */
  forcePathStyle?: boolean;
  /** Préfixe d'URL publique servi par le SPA (dev Vite proxy / staging
   *  nginx / prod Ingress) qui forward vers MinIO interne. Pattern
   *  same-origin pour éviter les bundles JS avec URL absolue baked
   *  (cohérent hotfix #4 staging-lan-proxy + candidat ADR-014).
   *  Default `/storage`. Surcharger via env `S3_PUBLIC_PATH_PREFIX`. */
  publicPathPrefix?: string;
  /** Override fetch / S3Client constructor for tests if needed. */
  client?: S3Client;
}

export class S3ObjectStorage implements ObjectStorage {
  private readonly client: S3Client;
  private readonly bucket: string;
  private readonly publicPathPrefix: string;

  constructor(cfg: S3ObjectStorageConfig) {
    this.bucket = cfg.bucket;
    this.publicPathPrefix = (cfg.publicPathPrefix ?? "/storage").replace(/\/$/, "");
    this.client =
      cfg.client ??
      new S3Client({
        endpoint: cfg.endpoint,
        region: cfg.region,
        credentials: {
          accessKeyId: cfg.accessKey,
          secretAccessKey: cfg.secretKey,
        },
        forcePathStyle: cfg.forcePathStyle ?? true,
      });
  }

  async uploadObject(args: { key: string; body: Buffer; contentType: string }): Promise<void> {
    await this.client.send(
      new PutObjectCommand({
        Bucket: this.bucket,
        Key: args.key,
        Body: args.body,
        ContentType: args.contentType,
      }),
    );
  }

  async deleteObject(key: string): Promise<void> {
    try {
      await this.client.send(new DeleteObjectCommand({ Bucket: this.bucket, Key: key }));
    } catch {
      // ignore — best effort
    }
  }

  getObjectUrl(key: string): string {
    // URL relative `{publicPathPrefix}/{bucket}/{key}` consommée transparemment
    // par le browser sur l'origine SPA. Le reverse proxy (Vite dev / nginx
    // staging / Ingress prod) rewrite vers `{S3_ENDPOINT}/{bucket}/{key}`.
    // Sprint-05 followups #1 — corrige `NS_ERROR_UNKNOWN_HOST` quand
    // `S3_ENDPOINT=http://minio:9000` (hostname Docker interne non
    // résolvable depuis browser host/LAN).
    return `${this.publicPathPrefix}/${this.bucket}/${key}`;
  }

  async downloadObject(key: string): Promise<{ body: Buffer; contentType: string }> {
    const res = await this.client.send(new GetObjectCommand({ Bucket: this.bucket, Key: key }));
    if (res.Body === undefined) {
      throw new Error(`Object ${key} has no body`);
    }
    const bytes = await res.Body.transformToByteArray();
    return {
      body: Buffer.from(bytes),
      contentType: res.ContentType ?? "application/octet-stream",
    };
  }

  async getPresignedUrl(key: string, expiresInSec: number): Promise<string> {
    return getSignedUrl(this.client, new GetObjectCommand({ Bucket: this.bucket, Key: key }), {
      expiresIn: expiresInSec,
    });
  }

  /** Idempotent boot helper — create bucket if it doesn't exist. */
  async ensureBucket(): Promise<void> {
    try {
      await this.client.send(new HeadBucketCommand({ Bucket: this.bucket }));
    } catch {
      try {
        await this.client.send(new CreateBucketCommand({ Bucket: this.bucket }));
      } catch {
        // bucket may have been created by a concurrent boot — ignore
      }
    }
  }

  /**
   * Idempotent boot helper — set the bucket policy to allow anonymous
   * `GetObject` on all keys. Required for the same-origin proxy pattern
   * (nginx/Vite `location /storage/` → MinIO) to serve customer logos
   * without S3 signature.
   *
   * Sprint-05 followups (hotfix #8) — corrige `403 AccessDenied` quand
   * MinIO refuse les requêtes anonymes par défaut. Évite la création
   * manuelle de la policy via `mc anonymous set download` à chaque reset
   * volume staging.
   *
   * ⚠️ Logos d'entreprise sont publics par nature (affichage facture).
   * En prod L17 Kapsule, à reconsidérer si des objets sensibles cohabitent
   * dans le même bucket — sinon split en `factur-e-logos` (public) +
   * `factur-e-invoices` (privé + presigned URLs).
   */
  async ensurePublicReadPolicy(): Promise<void> {
    const policy = {
      Version: "2012-10-17",
      Statement: [
        {
          Sid: "AllowAnonymousGetObject",
          Effect: "Allow",
          Principal: { AWS: ["*"] },
          Action: ["s3:GetObject"],
          Resource: [`arn:aws:s3:::${this.bucket}/*`],
        },
      ],
    };
    await this.client.send(
      new PutBucketPolicyCommand({
        Bucket: this.bucket,
        Policy: JSON.stringify(policy),
      }),
    );
  }

  /**
   * Idempotent boot helper — auto-delete objects after `days` days.
   * T-CL-EXPORT-ZIP-RETENTION Z8 (ceinture-bretelles) : le lifecycle S3 (180j)
   * double la purge applicative pgboss. Si l'un faille, l'autre couvre.
   */
  async ensureLifecyclePolicy(days: number): Promise<void> {
    await this.client.send(
      new PutBucketLifecycleConfigurationCommand({
        Bucket: this.bucket,
        LifecycleConfiguration: {
          Rules: [
            {
              ID: "expire-exports",
              Status: "Enabled",
              Filter: { Prefix: "" },
              Expiration: { Days: days },
            },
          ],
        },
      }),
    );
  }
}

export class MockObjectStorage implements ObjectStorage {
  private readonly objects = new Map<string, { body: Buffer; contentType: string }>();

  async uploadObject(args: { key: string; body: Buffer; contentType: string }): Promise<void> {
    this.objects.set(args.key, { body: args.body, contentType: args.contentType });
    await Promise.resolve();
  }

  async deleteObject(key: string): Promise<void> {
    this.objects.delete(key);
    await Promise.resolve();
  }

  getObjectUrl(key: string): string {
    return `mock://storage/${key}`;
  }

  async downloadObject(key: string): Promise<{ body: Buffer; contentType: string }> {
    const obj = this.objects.get(key);
    if (obj === undefined) {
      throw new Error(`Object ${key} not found`);
    }
    return Promise.resolve(obj);
  }

  async getPresignedUrl(key: string, expiresInSec: number): Promise<string> {
    return Promise.resolve(`mock://presigned/${key}?expires=${String(expiresInSec)}`);
  }

  /** Test helper: read back an uploaded object (synchrone, distinct de
   *  `downloadObject` de l'interface). */
  getObject(key: string): { body: Buffer; contentType: string } | undefined {
    return this.objects.get(key);
  }

  /** Test helper: clear all uploads between cases. */
  reset(): void {
    this.objects.clear();
  }
}

export function attachObjectStorage(app: FastifyInstance, storage: ObjectStorage): void {
  app.decorate("storage", storage);
}

export function s3StorageFromEnv(): S3ObjectStorage | undefined {
  const endpoint = process.env.S3_ENDPOINT;
  const region = process.env.S3_REGION ?? "fr-par";
  const bucket = process.env.S3_BUCKET ?? "factur-e-logos";
  const accessKey = process.env.S3_ACCESS_KEY;
  const secretKey = process.env.S3_SECRET_KEY;
  const publicPathPrefix = process.env.S3_PUBLIC_PATH_PREFIX;
  if (
    endpoint === undefined ||
    endpoint === "" ||
    accessKey === undefined ||
    accessKey === "" ||
    secretKey === undefined ||
    secretKey === ""
  ) {
    return undefined;
  }
  return new S3ObjectStorage({
    endpoint,
    region,
    bucket,
    accessKey,
    secretKey,
    publicPathPrefix,
  });
}

export function createDefaultObjectStorage(): ObjectStorage {
  if (process.env.NODE_ENV === "test") {
    return new MockObjectStorage();
  }
  const s3 = s3StorageFromEnv();
  if (s3 === undefined) {
    if (process.env.NODE_ENV === "production") {
      throw new Error(
        "Object storage `s3` selected (NODE_ENV=production) but S3_ENDPOINT / S3_ACCESS_KEY / S3_SECRET_KEY env vars are missing.",
      );
    }
    console.warn(
      "[storage] S3_* env vars missing — falling back to MockObjectStorage (in-memory, lost on restart).",
    );
    return new MockObjectStorage();
  }
  return s3;
}

// ─────────────────────────────────────────────────────────────────────────
// Exports storage — bucket privé dédié aux archives ZIP (T-CL-EXPORT-ZIP-…)
// ─────────────────────────────────────────────────────────────────────────

export function attachExportsStorage(app: FastifyInstance, storage: ObjectStorage): void {
  app.decorate("exportsStorage", storage);
}

/** Bucket exports — réutilise les credentials/endpoint S3 mais un bucket
 *  distinct (`S3_EXPORTS_BUCKET`, défaut `factur-e-exports`). Privé : pas de
 *  `publicPathPrefix` exploité (accès presigned uniquement). */
export function exportsStorageFromEnv(): S3ObjectStorage | undefined {
  const endpoint = process.env.S3_ENDPOINT;
  const region = process.env.S3_REGION ?? "fr-par";
  const bucket = process.env.S3_EXPORTS_BUCKET ?? "factur-e-exports";
  const accessKey = process.env.S3_ACCESS_KEY;
  const secretKey = process.env.S3_SECRET_KEY;
  if (
    endpoint === undefined ||
    endpoint === "" ||
    accessKey === undefined ||
    accessKey === "" ||
    secretKey === undefined ||
    secretKey === ""
  ) {
    return undefined;
  }
  return new S3ObjectStorage({ endpoint, region, bucket, accessKey, secretKey });
}

export function createDefaultExportsStorage(): ObjectStorage {
  if (process.env.NODE_ENV === "test") {
    return new MockObjectStorage();
  }
  const s3 = exportsStorageFromEnv();
  if (s3 === undefined) {
    if (process.env.NODE_ENV === "production") {
      throw new Error(
        "Exports storage `s3` selected (NODE_ENV=production) but S3_ENDPOINT / S3_ACCESS_KEY / S3_SECRET_KEY env vars are missing.",
      );
    }
    console.warn(
      "[storage] S3_* env vars missing — exports falling back to MockObjectStorage (in-memory).",
    );
    return new MockObjectStorage();
  }
  return s3;
}
