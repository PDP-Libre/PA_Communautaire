import type { FastifyBaseLogger, FastifyInstance } from "fastify";
import schedule from "node-schedule";
import type postgres from "postgres";

import {
  canReadCdar,
  cdarCapability,
  isWebOnboarding,
  SUPERPDP_CDAR_CAPABILITY,
  toCanonicalCode,
  type CdarEvent,
  type CustomerContext,
  type PADriverCore,
  type PaCredentials,
} from "@factur-e/pa-adapter";

import { writeAuthAudit } from "../auth/audit.js";
import * as cdarRepo from "../db/repos/cdar_events.js";
import * as incomingCdarRepo from "../db/repos/incoming_cdar_events.js";
import * as paRepo from "../db/repos/pa_connections.js";
import * as pollingStateRepo from "../db/repos/pa_polling_state.js";
import * as recvRepo from "../db/repos/received_invoices.js";
import type { SecretStore } from "../secrets/plugin.js";

/**
 * Polling background job CDAR — refondu T-CL-PA-INVOICE-FIX sprint-04
 * (ADR-010 v2 D4 + ADR-012 D5 + ADR-009 D1+D3+D4+D5).
 *
 * **Refonte vs T-CL-PA-EXT** : passage d'une boucle per-invoice
 * (`pollDocumentStatus(flowId)`) à une boucle per-customer avec cursor
 * global (`pollCdarEvents({cursor, limit})`) — cohérent l'API SuperPDP
 * propriétaire réelle qui n'expose qu'un endpoint d'events global
 * `GET /v1.beta/invoice_events?starting_after_id=`.
 *
 * Pipeline d'un tick :
 *  1. `pg_try_advisory_lock(43213)` (multi-replica safety).
 *  2. `findActivePaConnectionsByProvider(sql, 'superpdp')` — liste des
 *     customers connectés (arbitrage Bruno Z2 : V1 hardcode `'superpdp'`,
 *     V2 itérer sur `listEnabledProviders()`).
 *  3. Pour chaque customer :
 *     a. Charger credentials via SecretStore (`secret_ref` →
 *        `PaTokens` legacy → wrap en `PaCredentials.superpdp-oauth-ac`).
 *     b. `getCursor(sql, customer_id, 'superpdp')` → cursor courant
 *        (default `'0'` premier tick).
 *     c. `driver.pollCdarEvents({cursor, limit: 100}, ctx)`.
 *     d. Pour chaque event : `findActiveInvoiceByPaInvoiceId` (facture
 *        ÉMISE) → si trouvé → `insertCdarEvent` (ON CONFLICT DO NOTHING —
 *        ADR-009 D4) + UPDATE `invoices.status_current` (= `event.status`
 *        mappé) + audit. Si event.status === 'unknown' (fallback) + raw ≠
 *        'unknown' → audit `pa_status_code_unmapped` (ADR-012 D7).
 *        **V2 routing entrant (ADR-020 D6 / ADR-022 ZG-4)** : si la facture
 *        émise est absente, tenter `findReceivedInvoiceByPaInvoiceIdIn`
 *        (facture REÇUE, scopé `customer_id`) — le feed global porte aussi
 *        les events des reçues (202/205…). Match → `insertIncomingCdarEvent`
 *        (source 'polling', idempotent) + `markReceivedInvoiceStatus`.
 *        L'annulation (209/220) reste possédée par `poll-received-invoices`
 *        (V1a). Audit `pa_polling_event_unknown_invoice` seulement si AUCUN
 *        des deux lookups ne matche.
 *     e. **Sur succès** : `upsertCursor` → `nextCursor`.
 *     f. **Sur fail** (5xx épuisé, exception non typée) : log + pas
 *        d'upsert (pattern fail-safe ADR-009 D1 — le tick suivant retry).
 *
 * CRON paramétrable env `CDAR_POLLING_CRON` (default `*\/15 * * * *`,
 * dev `* * * * *`) — ADR-009 D3 amendement 2026-05-16.
 *
 * Multi-replica safety : `pg_try_advisory_lock(43213)`. Skip si tenu.
 *
 * Tests : `runPollCdarEvents(deps)` est l'entrypoint pur. Scheduler
 * wired dans `start.ts` conditionnel `NODE_ENV !== 'test'`.
 */

const ADVISORY_LOCK_KEY = 43213;
const DEFAULT_CRON_EXPRESSION = "*/15 * * * *";
const DEFAULT_LIMIT = 100;
const CURSOR_INITIAL = "0";
const PROVIDER = "superpdp";

export interface CdarPollTickResult {
  skipped: boolean;
  customersScanned: number;
  events_inserted: number;
  /** Events routés vers une facture REÇUE (V2 — ADR-020 D6). Distinct de
   *  `events_inserted` (factures émises → `cdar_events`). */
  received_events_routed: number;
  errors: number;
}

export interface CdarPollTickDeps {
  sql: postgres.Sql;
  driver: PADriverCore;
  secrets: SecretStore;
  log?: Pick<FastifyBaseLogger, "info" | "error" | "warn">;
}

/** Pure tick runner — idempotent, multi-replica-safe. Test entrypoint. */
export async function runPollCdarEvents(deps: CdarPollTickDeps): Promise<CdarPollTickResult> {
  const log = deps.log ?? console;
  const reserved = await deps.sql.reserve();
  try {
    const lockRows = await reserved<{ acquired: boolean }[]>`
      SELECT pg_try_advisory_lock(${ADVISORY_LOCK_KEY}) AS acquired
    `;
    if (lockRows[0]?.acquired !== true) {
      return {
        skipped: true,
        customersScanned: 0,
        events_inserted: 0,
        received_events_routed: 0,
        errors: 0,
      };
    }
    try {
      const connections = await paRepo.findActivePaConnectionsByProvider(reserved, PROVIDER);
      let totalInserted = 0;
      let totalReceivedRouted = 0;
      let totalErrors = 0;
      for (const conn of connections) {
        const outcome = await pollOneCustomer({ conn, deps, sql: reserved });
        totalInserted += outcome.eventsInserted;
        totalReceivedRouted += outcome.receivedRouted;
        if (outcome.error) totalErrors += 1;
      }
      log.info(
        {
          job: "poll_cdar",
          provider: PROVIDER,
          customers_scanned: connections.length,
          events_inserted: totalInserted,
          received_events_routed: totalReceivedRouted,
          errors: totalErrors,
        },
        "[poll-cdar-events] tick done",
      );
      return {
        skipped: false,
        customersScanned: connections.length,
        events_inserted: totalInserted,
        received_events_routed: totalReceivedRouted,
        errors: totalErrors,
      };
    } finally {
      await reserved`SELECT pg_advisory_unlock(${ADVISORY_LOCK_KEY})`;
    }
  } finally {
    reserved.release();
  }
}

async function pollOneCustomer(args: {
  conn: paRepo.PaConnectionForCdarPollingRow;
  deps: CdarPollTickDeps;
  sql: postgres.Sql;
}): Promise<{ eventsInserted: number; receivedRouted: number; error: boolean }> {
  const { conn, deps, sql } = args;
  const log = deps.log ?? console;

  // 1. Charger credentials via SecretStore. Le bundle stocké côté
  //    sprint-03 est au format `PaTokenBundle` (accessExpiresAt: ISO
  //    string) — on le wrap en `PaCredentials.superpdp-oauth-ac` pour
  //    cohérence ADR-012 D3. `paUserId: null` (SuperPDP n'expose pas
  //    d'id user côté `oauth2_session`, cf. parseIdentityResponse
  //    sprint-03).
  let bundle: { accessToken: string; refreshToken: string; accessExpiresAt: string };
  try {
    const loaded = await deps.secrets.get(conn.secret_ref);
    if (loaded === null) {
      log.warn({ conn_id: conn.id }, "[poll-cdar-events] secret_ref returned null");
      return { eventsInserted: 0, receivedRouted: 0, error: true };
    }
    bundle = loaded;
  } catch (err) {
    log.error({ err, conn_id: conn.id }, "[poll-cdar-events] secrets.get failed");
    return { eventsInserted: 0, receivedRouted: 0, error: true };
  }

  const credentials: PaCredentials = {
    kind: "superpdp-oauth-ac",
    accessToken: bundle.accessToken,
    refreshToken: bundle.refreshToken,
    accessExpiresAt: new Date(bundle.accessExpiresAt),
    paUserId: null,
  };
  const ctx: CustomerContext = { customerId: conn.customer_id, credentials };

  // 2. Cursor courant (ou cursor initial '0' si premier tick).
  //    Namespace de curseur = celui du driver actif (Z7 sprint-10) : la
  //    config `superpdp-afnor` utilise `superpdp-afnor` (curseur ISO
  //    `updatedAfter`) pour ne pas collisionner le curseur propriétaire
  //    (id numérique `starting_after_id`) sous le même `provider`.
  const cursorNamespace = deps.driver.pollingCursorNamespace ?? PROVIDER;
  const cursorRow = await pollingStateRepo.getCursor(sql, conn.customer_id, cursorNamespace);
  const cursor = cursorRow?.cursor ?? CURSOR_INITIAL;

  // 3. Appel driver. Pattern fail-safe ADR-009 D1 : absorber exceptions
  //    + log + retourner. Pas d'upsert cursor sur fail (le tick suivant
  //    retry le même range — pas de perte d'events).
  let result: { events: readonly CdarEvent[]; nextCursor: string; hasMore: boolean };
  try {
    // Capability check : sanity narrow. V1 driver = SuperPDP
    // (PADriverWebOnboarding). isWebOnboarding() est conservateur —
    // tout PADriverCore satisfait pollCdarEvents (méthode Core).
    if (!isWebOnboarding(deps.driver) && deps.driver.providerId !== "superpdp") {
      log.warn(
        { conn_id: conn.id, provider_id: deps.driver.providerId },
        "[poll-cdar-events] non-SuperPDP driver — skip (V2 multi-PA pas livré)",
      );
      return { eventsInserted: 0, receivedRouted: 0, error: false };
    }
    result = await deps.driver.pollCdarEvents({ cursor, limit: DEFAULT_LIMIT }, ctx);
  } catch (err) {
    log.error(
      { err, conn_id: conn.id, customer_id: conn.customer_id, cursor },
      "[poll-cdar-events] driver.pollCdarEvents failed",
    );
    return { eventsInserted: 0, receivedRouted: 0, error: true };
  }

  // 4. Pour chaque event : router vers invoice via pa_invoice_id, puis
  //    insertCdarEvent + UPDATE status + audit.
  let inserted = 0;
  let receivedRouted = 0;
  for (const event of result.events) {
    // Scoping tenant (invariant R1) : `pa_invoice_id` = id assigné par la
    // PA (namespace externe, non global) → lookup scopé `customer_id` de la
    // connexion courante. Sans ça, fuite cross-tenant sous compte PA partagé.
    const invoice = await cdarRepo.findActiveInvoiceByPaInvoiceId(
      sql,
      conn.customer_id,
      event.paInvoiceId,
    );
    if (invoice === undefined) {
      // V2 routing entrant (ADR-020 D6) : la facture ÉMISE est absente — le
      // feed global porte aussi les events des factures REÇUES. Tenter le 2e
      // lookup (scopé `customer_id`) avant de dropper.
      const routed = await routeEventToReceivedInvoice({ sql, conn, event, deps });
      if (routed.matched) {
        if (routed.inserted) receivedRouted += 1;
        continue;
      }
      // Aucun des deux lookups (émise + reçue) ne matche → vrai unknown.
      await writeAuthAudit(deps.sql, {
        event_type: "pa_polling_event_unknown_invoice",
        success: false,
        customer_id: conn.customer_id,
        metadata: { pa_invoice_id: event.paInvoiceId, raw_status_code: event.rawStatusCode },
      });
      continue;
    }

    const insertResult = await cdarRepo.insertCdarEvent(sql, {
      invoice_id: invoice.id,
      code: event.rawStatusCode,
      label: event.label ?? null,
      occurred_at: event.occurredAt,
      payload: event.payload,
      reason: event.reason ?? null,
      source: "polling",
    });

    if (insertResult.inserted) {
      inserted += 1;
      // Dédup doublon Déposée (finding C T-CL-W3-A-CYCLE-VIE-FIXS) : le vrai
      // event polling supersede le placeholder `source='synthetic'` de même
      // code posé à l'envoi (`create.ts`, ADR-009 D4 fail-safe). Drop ciblé
      // une fois le vrai event persisté → 1 seule ligne par code. Si le
      // polling n'arrive jamais, le synthetic reste seul (D4 préservé).
      await cdarRepo.deleteSyntheticCdarEvent(sql, {
        invoiceId: invoice.id,
        code: event.rawStatusCode,
      });
      // UPDATE invoices.status_current avec la valeur normalisée
      // FacturEStatusCode (ADR-012 D2) — pas le raw code.
      await cdarRepo.updateInvoiceStatusCurrent(sql, invoice.id, event.status);
      await writeAuthAudit(deps.sql, {
        event_type: "pa_polling_caught_missed_event",
        success: true,
        customer_id: conn.customer_id,
        metadata: {
          pa_invoice_id: event.paInvoiceId,
          raw_status_code: event.rawStatusCode,
          status: event.status,
          cdar_event_id: insertResult.id,
        },
      });

      // Audit ADR-012 D7 si le mapping a fallback sur 'unknown'. On
      // détecte ça via `status === 'unknown' && rawStatusCode !== ''`
      // (le mapping retourne 'unknown' pour un raw vide aussi).
      if (event.status === "unknown" && event.rawStatusCode !== "") {
        await writeAuthAudit(deps.sql, {
          event_type: "pa_status_code_unmapped",
          success: false,
          customer_id: conn.customer_id,
          metadata: {
            provider: PROVIDER,
            raw_status_code: event.rawStatusCode,
            pa_invoice_id: event.paInvoiceId,
          },
        });
      }
    }
  }

  // 5. UPSERT cursor seulement sur succès driver (pas d'avancée sur
  //    fail — ADR-009 D1 fail-safe). Upsert même si events.length === 0
  //    lorsque nextCursor a avancé (cas extrême has_after=false avec
  //    pagination interne SuperPDP) — sinon on garde le même cursor.
  if (result.nextCursor !== cursor || result.events.length > 0) {
    await pollingStateRepo.upsertCursor(sql, {
      customerId: conn.customer_id,
      provider: cursorNamespace,
      cursor: result.nextCursor,
    });
  }

  return { eventsInserted: inserted, receivedRouted, error: false };
}

/**
 * V2 routing entrant (ADR-020 D6 / ADR-022 ZG-4) — achemine un event du feed
 * global vers une facture **reçue** (le feed mélange émission + réception).
 *
 * Frontière « V2 achemine / (A) interprète » : V2 consomme `event.status` déjà
 * mappé par le driver (qui consomme le référentiel), il ne ré-interprète pas le
 * code. Set routable **dérivé** (pas un sous-ensemble figé) : tout jalon
 * lifecycle **lisible** par la PA active, MOINS l'annulation (209/220) dont la
 * sémantique reste possédée par `poll-received-invoices`/`maybeIngestCancellation`
 * (V1a, doctrine 209-vs-220 non tranchée — arbitrage T-CL-CDAR-CAPABILITY-V2).
 *
 * Écrit `incoming_cdar_events` (timeline, source 'polling', idempotent) +
 * `markReceivedInvoiceStatus` (badge), scopés `customer_id`. `matched=true` dès
 * que la facture reçue existe (connue → pas d'`unknown_invoice`), même si le
 * code n'est pas routé (annulation déléguée, code technique/non-lisible).
 */
async function routeEventToReceivedInvoice(args: {
  sql: postgres.Sql;
  conn: paRepo.PaConnectionForCdarPollingRow;
  event: CdarEvent;
  deps: CdarPollTickDeps;
}): Promise<{ matched: boolean; inserted: boolean }> {
  const { sql, conn, event, deps } = args;

  // Scoping tenant (invariant R1) : `pa_invoice_id_in` unique seulement par
  // compte PA → lookup scopé `customer_id` (sinon fuite cross-tenant).
  const received = await recvRepo.findReceivedInvoiceByPaInvoiceIdIn(
    sql,
    conn.customer_id,
    event.paInvoiceId,
  );
  if (received === undefined) return { matched: false, inserted: false };

  const canonical = toCanonicalCode(event.rawStatusCode);
  const isCancellation = canonical === "209" || canonical === "220";
  const isRoutable =
    canonical !== null &&
    !isCancellation &&
    canReadCdar(cdarCapability(SUPERPDP_CDAR_CAPABILITY, canonical));
  if (!isRoutable) {
    // Facture reçue connue, mais code non routé par V2 (annulation déléguée à
    // poll-received-invoices, ou code technique/non-lisible) → pas d'unknown,
    // pas d'écriture (idempotence : un re-tick ne change rien).
    return { matched: true, inserted: false };
  }

  const ev = await incomingCdarRepo.insertIncomingCdarEvent(sql, {
    received_invoice_id: received.id,
    code: event.rawStatusCode,
    label: event.label ?? null,
    occurred_at: event.occurredAt,
    payload: event.payload,
    reason_text: event.reason ?? null,
    source: "polling",
  });
  if (!ev.inserted) return { matched: true, inserted: false };

  // Statut appliqué seulement si mapping significatif (jamais downgrade vers
  // 'unknown' un statut déjà connu). `received.id` est scopé tenant (lookup
  // ci-dessus) → markReceivedInvoiceStatus(id) sûr.
  if (event.status !== "unknown") {
    await recvRepo.markReceivedInvoiceStatus(sql, received.id, event.status);
  }
  await writeAuthAudit(deps.sql, {
    event_type: "pa_polling_received_event_routed",
    success: true,
    customer_id: conn.customer_id,
    metadata: {
      received_invoice_id: received.id,
      pa_invoice_id: event.paInvoiceId,
      raw_status_code: event.rawStatusCode,
      status: event.status,
    },
  });
  return { matched: true, inserted: true };
}

/** Register the cron scheduler. CRON expression lue depuis env
 *  `CDAR_POLLING_CRON` (ADR-009 D3 amendement) — default
 *  `*\/15 * * * *` prod, override `* * * * *` (1 min) dev local. */
export function registerPollCdarEventsJob(app: FastifyInstance): schedule.Job {
  const cron = process.env.CDAR_POLLING_CRON ?? DEFAULT_CRON_EXPRESSION;
  app.log.info({ cron }, "[poll-cdar-events] scheduling job");
  return schedule.scheduleJob(cron, () => {
    void runPollCdarEvents({
      sql: app.sql,
      driver: app.paDriver,
      secrets: app.secrets,
      log: app.log,
    })
      .then((result) => {
        if (result.skipped) {
          app.log.info("[poll-cdar-events] another replica holds the lock, skip");
        }
      })
      .catch((err: unknown) => {
        app.log.error({ err }, "[poll-cdar-events] tick failed unexpectedly");
      });
  });
}
