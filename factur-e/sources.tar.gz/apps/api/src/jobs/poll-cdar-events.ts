import type { FastifyBaseLogger, FastifyInstance } from "fastify";
import schedule from "node-schedule";
import type postgres from "postgres";

import {
  isWebOnboarding,
  type CdarEvent,
  type CustomerContext,
  type PADriverCore,
  type PaCredentials,
} from "@factur-e/pa-adapter";

import { writeAuthAudit } from "../auth/audit.js";
import * as cdarRepo from "../db/repos/cdar_events.js";
import * as paRepo from "../db/repos/pa_connections.js";
import * as pollingStateRepo from "../db/repos/pa_polling_state.js";
import type { SecretStore } from "../secrets/plugin.js";

/**
 * Polling background job CDAR — refondu T-CL-PA-INVOICE-FIX sprint-04
 * (ADR-010 v2 D4 + ADR-012 D5 + ADR-009 D1+D3+D4+D5).
 *
 * **Refonte vs T-CL-PA-EXT** : passage d'une boucle per-invoice
 * (`pollDocumentStatus(flowId)`) à une boucle per-customer avec cursor
 * global (`pollCdarEvents({cursor, limit})`) — cohérent l'API SuperPDP
 * propriétaire réelle qui n'expose qu'un endpoint d'events global
 * `GET /v1.beta/invoice_events?starting_after_id=`.
 *
 * Pipeline d'un tick :
 *  1. `pg_try_advisory_lock(43213)` (multi-replica safety).
 *  2. `findActivePaConnectionsByProvider(sql, 'superpdp')` — liste des
 *     customers connectés (arbitrage Bruno Z2 : V1 hardcode `'superpdp'`,
 *     V2 itérer sur `listEnabledProviders()`).
 *  3. Pour chaque customer :
 *     a. Charger credentials via SecretStore (`secret_ref` →
 *        `PaTokens` legacy → wrap en `PaCredentials.superpdp-oauth-ac`).
 *     b. `getCursor(sql, customer_id, 'superpdp')` → cursor courant
 *        (default `'0'` premier tick).
 *     c. `driver.pollCdarEvents({cursor, limit: 100}, ctx)`.
 *     d. Pour chaque event : `findActiveInvoiceByPaInvoiceId` → si
 *        trouvé → `insertCdarEvent` (ON CONFLICT DO NOTHING — ADR-009 D4)
 *        + UPDATE `invoices.status_current` (= `event.status` mappé) +
 *        audit. Si event.status === 'unknown' (fallback) + raw ≠
 *        'unknown' → audit `pa_status_code_unmapped` (ADR-012 D7).
 *     e. **Sur succès** : `upsertCursor` → `nextCursor`.
 *     f. **Sur fail** (5xx épuisé, exception non typée) : log + pas
 *        d'upsert (pattern fail-safe ADR-009 D1 — le tick suivant retry).
 *
 * CRON paramétrable env `CDAR_POLLING_CRON` (default `*\/15 * * * *`,
 * dev `* * * * *`) — ADR-009 D3 amendement 2026-05-16.
 *
 * Multi-replica safety : `pg_try_advisory_lock(43213)`. Skip si tenu.
 *
 * Tests : `runPollCdarEvents(deps)` est l'entrypoint pur. Scheduler
 * wired dans `start.ts` conditionnel `NODE_ENV !== 'test'`.
 */

const ADVISORY_LOCK_KEY = 43213;
const DEFAULT_CRON_EXPRESSION = "*/15 * * * *";
const DEFAULT_LIMIT = 100;
const CURSOR_INITIAL = "0";
const PROVIDER = "superpdp";

export interface CdarPollTickResult {
  skipped: boolean;
  customersScanned: number;
  events_inserted: number;
  errors: number;
}

export interface CdarPollTickDeps {
  sql: postgres.Sql;
  driver: PADriverCore;
  secrets: SecretStore;
  log?: Pick<FastifyBaseLogger, "info" | "error" | "warn">;
}

/** Pure tick runner — idempotent, multi-replica-safe. Test entrypoint. */
export async function runPollCdarEvents(deps: CdarPollTickDeps): Promise<CdarPollTickResult> {
  const log = deps.log ?? console;
  const reserved = await deps.sql.reserve();
  try {
    const lockRows = await reserved<{ acquired: boolean }[]>`
      SELECT pg_try_advisory_lock(${ADVISORY_LOCK_KEY}) AS acquired
    `;
    if (lockRows[0]?.acquired !== true) {
      return { skipped: true, customersScanned: 0, events_inserted: 0, errors: 0 };
    }
    try {
      const connections = await paRepo.findActivePaConnectionsByProvider(reserved, PROVIDER);
      let totalInserted = 0;
      let totalErrors = 0;
      for (const conn of connections) {
        const outcome = await pollOneCustomer({ conn, deps, sql: reserved });
        totalInserted += outcome.eventsInserted;
        if (outcome.error) totalErrors += 1;
      }
      log.info(
        {
          job: "poll_cdar",
          provider: PROVIDER,
          customers_scanned: connections.length,
          events_inserted: totalInserted,
          errors: totalErrors,
        },
        "[poll-cdar-events] tick done",
      );
      return {
        skipped: false,
        customersScanned: connections.length,
        events_inserted: totalInserted,
        errors: totalErrors,
      };
    } finally {
      await reserved`SELECT pg_advisory_unlock(${ADVISORY_LOCK_KEY})`;
    }
  } finally {
    reserved.release();
  }
}

async function pollOneCustomer(args: {
  conn: paRepo.PaConnectionForCdarPollingRow;
  deps: CdarPollTickDeps;
  sql: postgres.Sql;
}): Promise<{ eventsInserted: number; error: boolean }> {
  const { conn, deps, sql } = args;
  const log = deps.log ?? console;

  // 1. Charger credentials via SecretStore. Le bundle stocké côté
  //    sprint-03 est au format `PaTokenBundle` (accessExpiresAt: ISO
  //    string) — on le wrap en `PaCredentials.superpdp-oauth-ac` pour
  //    cohérence ADR-012 D3. `paUserId: null` (SuperPDP n'expose pas
  //    d'id user côté `oauth2_session`, cf. parseIdentityResponse
  //    sprint-03).
  let bundle: { accessToken: string; refreshToken: string; accessExpiresAt: string };
  try {
    const loaded = await deps.secrets.get(conn.secret_ref);
    if (loaded === null) {
      log.warn({ conn_id: conn.id }, "[poll-cdar-events] secret_ref returned null");
      return { eventsInserted: 0, error: true };
    }
    bundle = loaded;
  } catch (err) {
    log.error({ err, conn_id: conn.id }, "[poll-cdar-events] secrets.get failed");
    return { eventsInserted: 0, error: true };
  }

  const credentials: PaCredentials = {
    kind: "superpdp-oauth-ac",
    accessToken: bundle.accessToken,
    refreshToken: bundle.refreshToken,
    accessExpiresAt: new Date(bundle.accessExpiresAt),
    paUserId: null,
  };
  const ctx: CustomerContext = { customerId: conn.customer_id, credentials };

  // 2. Cursor courant (ou cursor initial '0' si premier tick).
  const cursorRow = await pollingStateRepo.getCursor(sql, conn.customer_id, PROVIDER);
  const cursor = cursorRow?.cursor ?? CURSOR_INITIAL;

  // 3. Appel driver. Pattern fail-safe ADR-009 D1 : absorber exceptions
  //    + log + retourner. Pas d'upsert cursor sur fail (le tick suivant
  //    retry le même range — pas de perte d'events).
  let result: { events: readonly CdarEvent[]; nextCursor: string; hasMore: boolean };
  try {
    // Capability check : sanity narrow. V1 driver = SuperPDP
    // (PADriverWebOnboarding). isWebOnboarding() est conservateur —
    // tout PADriverCore satisfait pollCdarEvents (méthode Core).
    if (!isWebOnboarding(deps.driver) && deps.driver.providerId !== "superpdp") {
      log.warn(
        { conn_id: conn.id, provider_id: deps.driver.providerId },
        "[poll-cdar-events] non-SuperPDP driver — skip (V2 multi-PA pas livré)",
      );
      return { eventsInserted: 0, error: false };
    }
    result = await deps.driver.pollCdarEvents({ cursor, limit: DEFAULT_LIMIT }, ctx);
  } catch (err) {
    log.error(
      { err, conn_id: conn.id, customer_id: conn.customer_id, cursor },
      "[poll-cdar-events] driver.pollCdarEvents failed",
    );
    return { eventsInserted: 0, error: true };
  }

  // 4. Pour chaque event : router vers invoice via pa_invoice_id, puis
  //    insertCdarEvent + UPDATE status + audit.
  let inserted = 0;
  for (const event of result.events) {
    const invoice = await cdarRepo.findActiveInvoiceByPaInvoiceId(sql, event.paInvoiceId);
    if (invoice === undefined) {
      // Event reçu pour une invoice qu'on ne connaît pas (cas rare —
      // legacy data ou race condition). Log + audit, pas d'erreur.
      await writeAuthAudit(deps.sql, {
        event_type: "pa_polling_event_unknown_invoice",
        success: false,
        customer_id: conn.customer_id,
        metadata: { pa_invoice_id: event.paInvoiceId, raw_status_code: event.rawStatusCode },
      });
      continue;
    }

    const insertResult = await cdarRepo.insertCdarEvent(sql, {
      invoice_id: invoice.id,
      code: event.rawStatusCode,
      label: event.label ?? null,
      occurred_at: event.occurredAt,
      payload: event.payload,
      reason: event.reason ?? null,
      source: "polling",
    });

    if (insertResult.inserted) {
      inserted += 1;
      // Dédup doublon Déposée (finding C T-CL-W3-A-CYCLE-VIE-FIXS) : le vrai
      // event polling supersede le placeholder `source='synthetic'` de même
      // code posé à l'envoi (`create.ts`, ADR-009 D4 fail-safe). Drop ciblé
      // une fois le vrai event persisté → 1 seule ligne par code. Si le
      // polling n'arrive jamais, le synthetic reste seul (D4 préservé).
      await cdarRepo.deleteSyntheticCdarEvent(sql, {
        invoiceId: invoice.id,
        code: event.rawStatusCode,
      });
      // UPDATE invoices.status_current avec la valeur normalisée
      // FacturEStatusCode (ADR-012 D2) — pas le raw code.
      await cdarRepo.updateInvoiceStatusCurrent(sql, invoice.id, event.status);
      await writeAuthAudit(deps.sql, {
        event_type: "pa_polling_caught_missed_event",
        success: true,
        customer_id: conn.customer_id,
        metadata: {
          pa_invoice_id: event.paInvoiceId,
          raw_status_code: event.rawStatusCode,
          status: event.status,
          cdar_event_id: insertResult.id,
        },
      });

      // Audit ADR-012 D7 si le mapping a fallback sur 'unknown'. On
      // détecte ça via `status === 'unknown' && rawStatusCode !== ''`
      // (le mapping retourne 'unknown' pour un raw vide aussi).
      if (event.status === "unknown" && event.rawStatusCode !== "") {
        await writeAuthAudit(deps.sql, {
          event_type: "pa_status_code_unmapped",
          success: false,
          customer_id: conn.customer_id,
          metadata: {
            provider: PROVIDER,
            raw_status_code: event.rawStatusCode,
            pa_invoice_id: event.paInvoiceId,
          },
        });
      }
    }
  }

  // 5. UPSERT cursor seulement sur succès driver (pas d'avancée sur
  //    fail — ADR-009 D1 fail-safe). Upsert même si events.length === 0
  //    lorsque nextCursor a avancé (cas extrême has_after=false avec
  //    pagination interne SuperPDP) — sinon on garde le même cursor.
  if (result.nextCursor !== cursor || result.events.length > 0) {
    await pollingStateRepo.upsertCursor(sql, {
      customerId: conn.customer_id,
      provider: PROVIDER,
      cursor: result.nextCursor,
    });
  }

  return { eventsInserted: inserted, error: false };
}

/** Register the cron scheduler. CRON expression lue depuis env
 *  `CDAR_POLLING_CRON` (ADR-009 D3 amendement) — default
 *  `*\/15 * * * *` prod, override `* * * * *` (1 min) dev local. */
export function registerPollCdarEventsJob(app: FastifyInstance): schedule.Job {
  const cron = process.env.CDAR_POLLING_CRON ?? DEFAULT_CRON_EXPRESSION;
  app.log.info({ cron }, "[poll-cdar-events] scheduling job");
  return schedule.scheduleJob(cron, () => {
    void runPollCdarEvents({
      sql: app.sql,
      driver: app.paDriver,
      secrets: app.secrets,
      log: app.log,
    })
      .then((result) => {
        if (result.skipped) {
          app.log.info("[poll-cdar-events] another replica holds the lock, skip");
        }
      })
      .catch((err: unknown) => {
        app.log.error({ err }, "[poll-cdar-events] tick failed unexpectedly");
      });
  });
}
