import type { FastifyBaseLogger, FastifyInstance } from "fastify";
import schedule from "node-schedule";
import type postgres from "postgres";

import {
  extractEmbeddedXml,
  parseInvoiceMetadata,
  type InvoiceMetadata,
} from "@factur-e/factur-x-builder";
import {
  isWebOnboarding,
  type CustomerContext,
  type DownloadInvoiceFileResult,
  type IncomingInvoiceEnData,
  type PADriverCore,
  type PaCredentials,
} from "@factur-e/pa-adapter";

import { writeAuthAudit } from "../auth/audit.js";
import * as paRepo from "../db/repos/pa_connections.js";
import type { SecretStore } from "../secrets/plugin.js";

/**
 * Job cron AUDIT DRIFT — T-CL-RECV-AUDIT-DRIFT-EN-INVOICE sprint-06.
 *
 * Origine : apprentissage #28 retro sprint-05 — stratégie hybride métadonnées
 * Réception (worker `expand[]=en_invoice` pour la perf + parser XML on-demand
 * comme source de vérité stricte EN 16931, ADR-003). Le `en_invoice` JSON de
 * SuperPDP peut diverger du XML brut (drift de spec partenaire) ; ce job
 * échantillonne périodiquement et compare → monitoring pré-prod (Z5/Z6).
 *
 * Pattern miroir `poll-received-invoices.ts` (advisory lock + scan connexions
 * actives + fail-safe ADR-009 D1). NE persiste rien dans `received_invoices` :
 * lecture seule + audit `audit_drift_run` (+ log warn agrégé si drift, Z6
 * Option A — pas d'alerte email/Sentry V1, cohérent ADR-009).
 *
 * Pipeline d'un tick :
 *  1. `pg_try_advisory_lock(43215)` — distinct CDAR sortant 43213 + RECV 43214.
 *  2. `findActivePaConnectionsByProvider(sql, 'superpdp')`.
 *  3. Par customer : `listIncomingInvoices({cursor:'0', limit:N})` (en_invoice
 *     live), puis pour chaque facture :
 *       - `downloadInvoiceFile` → XML (extraction embedded si Factur-X PDF) ;
 *       - `parseInvoiceMetadata(xml)` → source de vérité stricte ;
 *       - `compareEnInvoiceDrift(en, meta)` → champs BT divergents.
 *  4. audit `audit_drift_run` {customer_id, sample_size, invoices_compared,
 *     drift_count, drift_fields[]} ; log warn si drift.
 *
 * **Périmètre des champs comparés (Z5 — set réduit acté Bruno)** : le
 * `en_invoice` exposé par le driver V1 (`IncomingInvoiceEnData`) couvre BT-1,
 * BT-2, BT-30, BT-44, BT-112. BT-47 (buyer.siren) et BT-117 (vatAmount) ne sont
 * pas exposés par l'accesseur en_invoice actuel → comparaison reportée à une
 * extension driver (raw en_invoice JSON). [NOTE-COWORK] trace.
 *
 * CRON paramétrable env `AUDIT_DRIFT_CRON` (default `0 3 * * *` UTC nightly, Z5).
 * Tests : `runAuditDriftEnInvoice(deps)` + `compareEnInvoiceDrift` purs.
 * Scheduler wired `start.ts` conditionnel `NODE_ENV !== 'test'`.
 */

const ADVISORY_LOCK_KEY = 43215;
const DEFAULT_CRON_EXPRESSION = "0 3 * * *";
const DEFAULT_SAMPLE_SIZE = 10;
const CURSOR_INITIAL = "0";
const PROVIDER = "superpdp";

export interface AuditDriftTickResult {
  skipped: boolean;
  customersScanned: number;
  /** Factures effectivement comparées (en_invoice + XML parsés). */
  invoicesCompared: number;
  /** Nombre de factures présentant au moins un champ divergent. */
  driftDetected: number;
  /** Champs BT-XXX divergents agrégés (dédupliqués) sur le tick. */
  driftFields: string[];
  errors: number;
}

export interface AuditDriftTickDeps {
  sql: postgres.Sql;
  driver: PADriverCore;
  secrets: SecretStore;
  log?: Pick<FastifyBaseLogger, "info" | "error" | "warn">;
  /** Taille d'échantillon par customer (default 10, Z5). Override pour tests. */
  sampleSize?: number;
}

/**
 * Compare le `en_invoice` (métadonnées SuperPDP) au XML parsé (source de
 * vérité EN 16931). Retourne les libellés BT-XXX divergents. Champs comparés
 * uniquement si présents des deux côtés (un `en_invoice` partiel ne compte pas
 * comme drift). Fonction pure — testable sans I/O.
 */
export function compareEnInvoiceDrift(en: IncomingInvoiceEnData, meta: InvoiceMetadata): string[] {
  const drift: string[] = [];
  const strNe = (a: string | undefined, b: string | undefined): boolean =>
    a !== undefined && a !== "" && b !== undefined && a.trim() !== b.trim();

  if (strNe(en.number, meta.document.invoiceNumber)) drift.push("BT-1");
  if (strNe(en.issueDate, meta.document.issueDate)) drift.push("BT-2");
  if (strNe(en.sellerSiren, meta.parties.seller.siren)) drift.push("BT-30");
  if (strNe(en.sellerName, meta.parties.seller.name)) drift.push("BT-44");
  if (en.totalTtcCents !== undefined && en.totalTtcCents !== meta.totals.totalTtc) {
    drift.push("BT-112");
  }
  return drift;
}

/** PDF Factur-X → XML embedded ; XML pur → utf8 ; sinon `null` (best-effort,
 *  miroir `received-invoices/_shared.ts:xmlFromDownload`). */
async function xmlFromDownload(result: DownloadInvoiceFileResult): Promise<string | null> {
  const ct = result.contentType.toLowerCase();
  if (ct.includes("xml")) return result.bytes.toString("utf8");
  if (ct.includes("pdf")) return extractEmbeddedXml(new Uint8Array(result.bytes));
  return null;
}

/** Pure tick runner — idempotent, multi-replica-safe. Test entrypoint. */
export async function runAuditDriftEnInvoice(
  deps: AuditDriftTickDeps,
): Promise<AuditDriftTickResult> {
  const log = deps.log ?? console;
  const sampleSize = deps.sampleSize ?? DEFAULT_SAMPLE_SIZE;
  const reserved = await deps.sql.reserve();
  try {
    const lockRows = await reserved<{ acquired: boolean }[]>`
      SELECT pg_try_advisory_lock(${ADVISORY_LOCK_KEY}) AS acquired
    `;
    if (lockRows[0]?.acquired !== true) {
      return {
        skipped: true,
        customersScanned: 0,
        invoicesCompared: 0,
        driftDetected: 0,
        driftFields: [],
        errors: 0,
      };
    }
    try {
      const connections = await paRepo.findActivePaConnectionsByProvider(reserved, PROVIDER);
      let invoicesCompared = 0;
      let driftDetected = 0;
      let errors = 0;
      const driftFields = new Set<string>();
      for (const conn of connections) {
        const outcome = await auditOneCustomer({ conn, deps, sampleSize });
        invoicesCompared += outcome.invoicesCompared;
        driftDetected += outcome.driftDetected;
        errors += outcome.errors;
        for (const f of outcome.driftFields) driftFields.add(f);
      }
      log.info(
        {
          job: "audit_drift_en_invoice",
          provider: PROVIDER,
          customers_scanned: connections.length,
          invoices_compared: invoicesCompared,
          drift_detected: driftDetected,
          drift_fields: [...driftFields],
          errors,
        },
        "[audit-drift-en-invoice] tick done",
      );
      return {
        skipped: false,
        customersScanned: connections.length,
        invoicesCompared,
        driftDetected,
        driftFields: [...driftFields],
        errors,
      };
    } finally {
      await reserved`SELECT pg_advisory_unlock(${ADVISORY_LOCK_KEY})`;
    }
  } finally {
    reserved.release();
  }
}

async function auditOneCustomer(args: {
  conn: paRepo.PaConnectionForCdarPollingRow;
  deps: AuditDriftTickDeps;
  sampleSize: number;
}): Promise<{
  invoicesCompared: number;
  driftDetected: number;
  driftFields: string[];
  errors: number;
}> {
  const { conn, deps, sampleSize } = args;
  const log = deps.log ?? console;

  // 1. Credentials SecretStore (même pattern que poll-received-invoices).
  let bundle: { accessToken: string; refreshToken: string; accessExpiresAt: string };
  try {
    const loaded = await deps.secrets.get(conn.secret_ref);
    if (loaded === null) {
      log.warn({ conn_id: conn.id }, "[audit-drift-en-invoice] secret_ref returned null");
      return { invoicesCompared: 0, driftDetected: 0, driftFields: [], errors: 1 };
    }
    bundle = loaded;
  } catch (err) {
    log.error({ err, conn_id: conn.id }, "[audit-drift-en-invoice] secrets.get failed");
    return { invoicesCompared: 0, driftDetected: 0, driftFields: [], errors: 1 };
  }

  const credentials: PaCredentials = {
    kind: "superpdp-oauth-ac",
    accessToken: bundle.accessToken,
    refreshToken: bundle.refreshToken,
    accessExpiresAt: new Date(bundle.accessExpiresAt),
    paUserId: null,
  };
  const ctx: CustomerContext = { customerId: conn.customer_id, credentials };

  // 2. Échantillon en_invoice live — fail-safe ADR-009 D1 (audit + skip).
  if (!isWebOnboarding(deps.driver) && deps.driver.providerId !== "superpdp") {
    log.warn(
      { conn_id: conn.id, provider_id: deps.driver.providerId },
      "[audit-drift-en-invoice] non-SuperPDP driver — skip (V2 multi-PA pas livré)",
    );
    return { invoicesCompared: 0, driftDetected: 0, driftFields: [], errors: 0 };
  }
  let invoices;
  try {
    const result = await deps.driver.listIncomingInvoices(
      { cursor: CURSOR_INITIAL, limit: sampleSize },
      ctx,
    );
    invoices = result.invoices.slice(0, sampleSize);
  } catch (err) {
    log.error(
      { err, conn_id: conn.id, customer_id: conn.customer_id },
      "[audit-drift-en-invoice] driver.listIncomingInvoices failed",
    );
    await writeAuthAudit(deps.sql, {
      event_type: "audit_drift_failed",
      success: false,
      customer_id: conn.customer_id,
      metadata: { provider: PROVIDER },
    });
    return { invoicesCompared: 0, driftDetected: 0, driftFields: [], errors: 1 };
  }

  // 3. Comparer chaque facture (en_invoice vs XML on-demand).
  let invoicesCompared = 0;
  let driftDetected = 0;
  let errors = 0;
  const driftFields = new Set<string>();

  for (const invoice of invoices) {
    const en = invoice.enInvoice;
    if (en === undefined) continue; // pas d'en_invoice → rien à comparer.
    let meta: InvoiceMetadata;
    try {
      const file = await deps.driver.downloadInvoiceFile({ paInvoiceId: invoice.paInvoiceId }, ctx);
      const xml = await xmlFromDownload(file);
      if (xml === null) {
        errors += 1;
        continue;
      }
      meta = parseInvoiceMetadata(xml);
    } catch (err) {
      log.warn(
        { err, conn_id: conn.id, pa_invoice_id_in: invoice.paInvoiceId },
        "[audit-drift-en-invoice] download/parse failed — skip (best-effort)",
      );
      errors += 1;
      continue;
    }

    invoicesCompared += 1;
    const fields = compareEnInvoiceDrift(en, meta);
    if (fields.length > 0) {
      driftDetected += 1;
      for (const f of fields) driftFields.add(f);
      log.warn(
        {
          conn_id: conn.id,
          customer_id: conn.customer_id,
          pa_invoice_id_in: invoice.paInvoiceId,
          drift_fields: fields,
        },
        "[audit-drift-en-invoice] DRIFT en_invoice vs XML parser",
      );
    }
  }

  // 4. Audit agrégé par customer (Z6 — log + audit, pas d'alerte V1).
  await writeAuthAudit(deps.sql, {
    event_type: "audit_drift_run",
    success: true,
    customer_id: conn.customer_id,
    metadata: {
      provider: PROVIDER,
      sample_size: sampleSize,
      invoices_compared: invoicesCompared,
      drift_count: driftDetected,
      drift_fields: [...driftFields],
    },
  });

  return { invoicesCompared, driftDetected, driftFields: [...driftFields], errors };
}

/** Register the cron scheduler. CRON env `AUDIT_DRIFT_CRON` (default
 *  `0 3 * * *` UTC nightly, Z5). */
export function registerAuditDriftEnInvoiceJob(app: FastifyInstance): schedule.Job {
  const cron = process.env.AUDIT_DRIFT_CRON ?? DEFAULT_CRON_EXPRESSION;
  app.log.info({ cron }, "[audit-drift-en-invoice] scheduling job");
  return schedule.scheduleJob(cron, () => {
    void runAuditDriftEnInvoice({
      sql: app.sql,
      driver: app.paDriver,
      secrets: app.secrets,
      log: app.log,
    })
      .then((result) => {
        if (result.skipped) {
          app.log.info("[audit-drift-en-invoice] another replica holds the lock, skip");
        }
      })
      .catch((err: unknown) => {
        app.log.error({ err }, "[audit-drift-en-invoice] tick failed unexpectedly");
      });
  });
}
