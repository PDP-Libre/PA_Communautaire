import type { FastifyBaseLogger, FastifyInstance } from "fastify";
import schedule from "node-schedule";
import type postgres from "postgres";

import type { IdentityStatus, PADriver } from "@factur-e/pa-adapter";

import { writeAuthAudit } from "../auth/audit.js";
import * as customersRepo from "../db/repos/customers.js";
import * as paRepo from "../db/repos/pa_connections.js";
import type { SecretStore } from "../secrets/plugin.js";
import { reconcileCustomerIdentity } from "../services/identity-reconciliation.js";

/**
 * Polling sub-job for SuperPDP identity statuses (T-CL-06 sprint-03 —
 * ADR-005 D6+D7 + ADR-007).
 *
 * Cron : `*\/30 * * * *` (every 30 min). Sweeps `pa_connections` rows
 * with `user_identity_verification_status='needs_review'` OR
 * `company_verification_status='needs_review'`. For each :
 *  - Read bundle from SecretStore.
 *  - Call `driver.getIdentityStatus(accessToken)`.
 *  - If statuses changed (especially `needs_review → verified`) →
 *    `markPaConnectionIdentityStatuses` + audit
 *    `pa_identity_status_changed`.
 *  - If both axes are now `verified` AND the customer's profile was
 *    unverified → `markCustomerProfileVerified` (FALSE) + audit
 *    `pa_profile_verified` (cf. ADR-007).
 *
 * Multi-replica safety : `pg_try_advisory_lock(43212)`. Skip if held.
 *
 * Tests trigger `runPollPaIdentityStatus(...)` directly. Scheduler
 * wired in `start.ts` conditionally on `NODE_ENV !== 'test'`.
 */

const ADVISORY_LOCK_KEY = 43212;
const CRON_EXPRESSION = "*/30 * * * *";

export interface PollTickResult {
  skipped: boolean;
  scanned: number;
  changed: number;
  cleared_profile_unverified: number;
}

export interface PollTickDeps {
  sql: postgres.Sql;
  driver: PADriver;
  secrets: SecretStore;
  log?: Pick<FastifyBaseLogger, "info" | "error" | "warn">;
}

/** Pure tick runner — idempotent, multi-replica-safe. Test entrypoint. */
export async function runPollPaIdentityStatus(deps: PollTickDeps): Promise<PollTickResult> {
  const log = deps.log ?? console;
  const reserved = await deps.sql.reserve();
  try {
    const lockRows = await reserved<{ acquired: boolean }[]>`
      SELECT pg_try_advisory_lock(${ADVISORY_LOCK_KEY}) AS acquired
    `;
    if (lockRows[0]?.acquired !== true) {
      return { skipped: true, scanned: 0, changed: 0, cleared_profile_unverified: 0 };
    }
    try {
      const due = await paRepo.findPaConnectionsForIdentityPolling(reserved);
      let changed = 0;
      let cleared = 0;
      for (const conn of due) {
        const result = await pollOne({ conn, deps, sql: reserved });
        if (result.changed) changed += 1;
        if (result.cleared_profile_unverified) cleared += 1;
      }
      log.info(
        { scanned: due.length, changed, cleared_profile_unverified: cleared },
        "[poll-pa-identity-status] tick done",
      );
      return {
        skipped: false,
        scanned: due.length,
        changed,
        cleared_profile_unverified: cleared,
      };
    } finally {
      await reserved`SELECT pg_advisory_unlock(${ADVISORY_LOCK_KEY})`;
    }
  } finally {
    reserved.release();
  }
}

async function pollOne(args: {
  conn: paRepo.PaConnectionPollingRow;
  deps: PollTickDeps;
  sql: postgres.Sql;
}): Promise<{ changed: boolean; cleared_profile_unverified: boolean }> {
  const { conn, deps, sql } = args;
  const log = deps.log ?? console;

  const bundle = await deps.secrets.get(conn.secret_ref).catch((err: unknown) => {
    log.error({ err, conn: conn.id }, "[poll-pa-identity-status] secrets.get failed");
    return null;
  });
  if (bundle === null) {
    return { changed: false, cleared_profile_unverified: false };
  }

  let next;
  try {
    next = await deps.driver.getIdentityStatus({ accessToken: bundle.accessToken });
  } catch (err) {
    log.error({ err, conn: conn.id }, "[poll-pa-identity-status] driver.getIdentityStatus failed");
    return { changed: false, cleared_profile_unverified: false };
  }

  const userChanged = next.user !== conn.user_identity_verification_status;
  const companyChanged = next.company !== conn.company_verification_status;
  if (!userChanged && !companyChanged) {
    return { changed: false, cleared_profile_unverified: false };
  }

  await paRepo.markPaConnectionIdentityStatuses(sql, conn.id, {
    user: next.user,
    company: next.company,
  });
  await writeAuthAudit(deps.sql, {
    event_type: "pa_identity_status_changed",
    success: true,
    customer_id: conn.customer_id,
    metadata: {
      from: {
        user: conn.user_identity_verification_status,
        company: conn.company_verification_status,
      },
      to: { user: next.user, company: next.company },
    },
  });

  // Mécanisme 2 (ADR-007bis D3 → ADR-007ter D2 candidat) — distinguer le
  // cycle régressif (`verified → needs_review`) du `needs_review` initial
  // pour le KPI SLA SuperPDP ("fréquence de ré-évaluation KYC après
  // vérification initiale"). Event additif, ne remplace pas
  // `pa_identity_status_changed`. Enfin émis sprint-06 W1 (documenté mais
  // non implémenté sprint-04 — [DEBT-medium] levée, T-CL-OBSERVABILITY-
  // IDENTITY-CYCLE absorbé). NB : `profile_unverified` reste FALSE sur ce
  // cycle (garde D1 ADR-007bis dans `markCustomerProfileVerified`).
  const isRegressionFromVerified =
    (next.user === "needs_review" && conn.user_identity_verification_status === "verified") ||
    (next.company === "needs_review" && conn.company_verification_status === "verified");
  if (isRegressionFromVerified) {
    await writeAuthAudit(deps.sql, {
      event_type: "pa_identity_status_pending_after_verified",
      success: true,
      customer_id: conn.customer_id,
      metadata: {
        from: {
          user: conn.user_identity_verification_status,
          company: conn.company_verification_status,
        },
        to: { user: next.user, company: next.company },
      },
    });
  }

  // ADR-007 : flip profile_unverified FALSE when both axes are verified.
  // The repo function returns the row count it updated — 0 means the
  // flag was already FALSE (e.g. after a transient
  // verified → needs_review → verified cycle), in which case we skip
  // the audit to avoid pollution. T-CL-07 expert review [low] #5.
  let clearedProfile = false;
  if (next.user === "verified" && next.company === "verified") {
    const updatedRows = await customersRepo.markCustomerProfileVerified(deps.sql, conn.customer_id);
    if (updatedRows > 0) {
      await writeAuthAudit(deps.sql, {
        event_type: "pa_profile_verified",
        success: true,
        customer_id: conn.customer_id,
      });
      clearedProfile = true;
    }

    // Mécanisme 3 — réconciliation silencieuse SIREN au retour `verified`
    // (cycle régressif `verified → needs_review → verified`, US-PA-005
    // crit. 5). Le SIREN attesté vient de `GET /v1.beta/companies/me`
    // (pas de `oauth2_sessions/me.siren`). Idempotente : n'émet
    // `pa_identity_siren_reconciled` que si la valeur a changé. Hors
    // `if updatedRows>0` car le SIREN peut différer alors même que
    // `profile_unverified` est déjà FALSE. Non-bloquant (ADR-009) : une
    // erreur companies/me n'interrompt pas le tick pour les autres rows.
    // (Règle de blocage facture appliquée par le service ; côté polling pas
    // de redirection UI — l'audit `pa_identity_siren_reconcile_blocked` /
    // `pa_identity_siren_reconciled` trace l'issue.)
    try {
      const company = await deps.driver.getConnectedCompany({ accessToken: bundle.accessToken });
      await reconcileCustomerIdentity({
        sql: deps.sql,
        customerId: conn.customer_id,
        company,
      });
    } catch (err) {
      log.error({ err, conn: conn.id }, "[poll-pa-identity-status] siren reconciliation failed");
    }
  }
  return { changed: true, cleared_profile_unverified: clearedProfile };
}

// Sentinel: keep the type used at module level for re-exports/devs.
export type { IdentityStatus };

/** Register the cron scheduler. */
export function registerPollPaIdentityStatusJob(app: FastifyInstance): schedule.Job {
  return schedule.scheduleJob(CRON_EXPRESSION, () => {
    void runPollPaIdentityStatus({
      sql: app.sql,
      driver: app.paDriver,
      secrets: app.secrets,
      log: app.log,
    })
      .then((result) => {
        if (result.skipped) {
          app.log.info("[poll-pa-identity-status] another replica holds the lock, skip");
        }
      })
      .catch((err: unknown) => {
        app.log.error({ err }, "[poll-pa-identity-status] tick failed unexpectedly");
      });
  });
}
