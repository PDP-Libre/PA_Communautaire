import type { FastifyInstance } from "fastify";
import type PgBoss from "pg-boss";

import { runExportZipGenerate } from "../services/export-zip-generate.js";

import { JOB_EXPORT_ZIP_GENERATE, type ExportZipGeneratePayload } from "./job-queue.js";

/**
 * Worker pgboss `export-zip-generate` (Z1) — consomme les jobs enqueue par
 * `POST /api/exports/zip` et délègue au service pur `runExportZipGenerate`.
 *
 * Retry 3 + backoff exponentiel posés sur la queue (le service pose `failed`
 * avant de re-throw pour visibilité immédiate côté UI ; pgboss retente).
 */
export async function registerExportZipWorker(app: FastifyInstance, boss: PgBoss): Promise<void> {
  await boss.createQueue(JOB_EXPORT_ZIP_GENERATE, {
    name: JOB_EXPORT_ZIP_GENERATE,
    retryLimit: 3,
    retryBackoff: true,
  });
  await boss.work<ExportZipGeneratePayload>(
    JOB_EXPORT_ZIP_GENERATE,
    { batchSize: 2 },
    async (jobs) => {
      for (const job of jobs) {
        await runExportZipGenerate(
          {
            sql: app.sql,
            exportsStorage: app.exportsStorage,
            paDriver: app.paDriver,
            secrets: app.secrets,
            email: app.email,
            webBaseUrl: exportWebBaseUrl(),
          },
          { exportRequestId: job.data.export_request_id },
        );
      }
    },
  );
}

/** Première origine de `WEB_BASE_URL` (same-origin proxy ADR-014) pour les
 *  liens email. Défaut dev cohérent avec `server.ts`. */
export function exportWebBaseUrl(): string {
  const first = (process.env.WEB_BASE_URL ?? "").split(",")[0]?.trim();
  return first !== undefined && first !== "" ? first : "http://localhost:5174";
}
