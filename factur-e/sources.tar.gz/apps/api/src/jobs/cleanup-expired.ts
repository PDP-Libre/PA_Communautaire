import type { FastifyBaseLogger, FastifyInstance } from "fastify";
import schedule from "node-schedule";
import type postgres from "postgres";

import * as directoryCacheRepo from "../db/repos/directory_cache.js";
import * as invitationsRepo from "../db/repos/invitations.js";
import * as signupPendingRepo from "../db/repos/signup_pending.js";

/**
 * Hourly cleanup job (T-CL-03 sprint-03) — drops rows whose TTL is past
 * across four short-lived tables. Levée de la dette `[low]` retro
 * sprint-02 ("TTL posé mais aucun cron").
 *
 * Tables :
 *   - `signup_pending`  : decoy + non-decoy expirés (TTL 7 j),
 *     ON DELETE CASCADE sur `otp_codes.signup_pending_id`.
 *   - `invitations`     : expirés ET non acceptés (les acceptées
 *     restent comme historique d'audit).
 *   - `otp_codes`       : tous les codes expirés (TTL 5 min usuellement,
 *     beaucoup plus court que `signup_pending` donc l'essentiel y est).
 *   - `insee_cache`     : enveloppe Sirene cachée TTL 90 j.
 *   - `directory_cache` : annuaire SuperPDP TTL 15 min (T-CL-10 sprint-03).
 *     TTL court → accumulation rapide, purge nécessaire pour borner la
 *     table.
 *
 * Decision Bruno (D4 sprint-03) : `node-schedule` côté Node, pas
 * `pg_cron`. Conservé in-process pour simplicité ; un advisory lock
 * Postgres garantit qu'un seul replica purge à la fois quand l'API
 * tournera en multi-pod Kapsule (PRD §7.4).
 *
 * Pattern :
 *   - `cleanupExpired(sql)` est pur et idempotent — testable sans
 *     scheduler. Erreur sur une table → log + continue (graceful par
 *     table). L'advisory lock est session-level via `sql.reserve()`.
 *   - `registerCleanupJob(app)` enregistre le cron `17 * * * *` (offset
 *     17 min pour ne pas s'aligner avec le job refresh-PA-tokens
 *     futur T-CL-06 `*\/5 * * * *`).
 *
 * `start.ts` n'appelle `registerCleanupJob` que si `NODE_ENV !== 'test'`
 * pour éviter de fond-tourner pendant les suites Vitest.
 */

const ADVISORY_LOCK_KEY = 43210;
const CRON_EXPRESSION = "17 * * * *";

export interface CleanupCounts {
  signup_pending: number | null;
  invitations: number | null;
  otp_codes: number | null;
  insee_cache: number | null;
  directory_cache: number | null;
}

export type CleanupResult =
  | { skipped: true; reason: "lock_held" }
  | { skipped: false; counts: CleanupCounts };

/** Single-table runner — catches its own SQL errors so a transient issue
 *  on one table doesn't starve the others on the next hour's tick. */
async function runStep(
  log: Pick<FastifyBaseLogger, "error">,
  table: keyof CleanupCounts,
  fn: () => Promise<number>,
): Promise<number | null> {
  try {
    return await fn();
  } catch (err) {
    log.error({ err, table }, "[cleanup-expired] table failed");
    return null;
  }
}

/**
 * Pure cleanup runner — also the test entry-point. Acquires
 * `pg_try_advisory_lock(43210)` on a reserved connection so concurrent
 * replicas / scheduler firings end up no-ops on all but one. The
 * try-acquire variant returns immediately, never blocks.
 */
export async function cleanupExpired(
  sql: postgres.Sql,
  log: Pick<FastifyBaseLogger, "error"> = console,
): Promise<CleanupResult> {
  // Reserve a connection so the SELECT lock and the DELETEs share the
  // same backend session — otherwise a pooled connection rotation
  // releases the lock under our feet.
  const reserved = await sql.reserve();
  try {
    const lockRows = await reserved<{ acquired: boolean }[]>`
      SELECT pg_try_advisory_lock(${ADVISORY_LOCK_KEY}) AS acquired
    `;
    if (lockRows[0]?.acquired !== true) {
      return { skipped: true, reason: "lock_held" };
    }
    try {
      const counts: CleanupCounts = {
        signup_pending: null,
        invitations: null,
        otp_codes: null,
        insee_cache: null,
        directory_cache: null,
      };
      // Order matters only for FK cascade clarity: otp_codes is dropped
      // first as a standalone count, then signup_pending whose cascade
      // would have already drained the dependent rows. Either order is
      // correct — this one keeps the count breakdown intuitive.
      counts.otp_codes = await runStep(log, "otp_codes", async () => {
        const r = await reserved`DELETE FROM otp_codes WHERE expires_at < NOW()`;
        return r.count;
      });
      counts.insee_cache = await runStep(log, "insee_cache", async () => {
        const r = await reserved`DELETE FROM insee_cache WHERE expires_at < NOW()`;
        return r.count;
      });
      counts.signup_pending = await runStep(log, "signup_pending", () =>
        signupPendingRepo.deletePendingExpired(reserved),
      );
      counts.invitations = await runStep(log, "invitations", () =>
        invitationsRepo.deleteInvitationsExpiredUnaccepted(reserved),
      );
      counts.directory_cache = await runStep(log, "directory_cache", () =>
        directoryCacheRepo.deleteExpiredDirectoryCache(reserved),
      );
      return { skipped: false, counts };
    } finally {
      await reserved`SELECT pg_advisory_unlock(${ADVISORY_LOCK_KEY})`;
    }
  } finally {
    reserved.release();
  }
}

/** Register the hourly scheduler. Returns the Job so the caller can
 *  cancel it during graceful shutdown (`onClose` could chain this if a
 *  future bug surfaces; not needed at this point — Fastify close stops
 *  the process and node-schedule timers die with it). */
export function registerCleanupJob(app: FastifyInstance): schedule.Job {
  return schedule.scheduleJob(CRON_EXPRESSION, () => {
    void cleanupExpired(app.sql, app.log)
      .then((result) => {
        if (result.skipped) {
          app.log.info({ reason: result.reason }, "[cleanup-expired] skipped");
        } else {
          app.log.info({ counts: result.counts }, "[cleanup-expired] purge done");
        }
      })
      .catch((err: unknown) => {
        // The graceful per-table catch in `cleanupExpired` covers
        // expected failures; this top-level handler logs the
        // unexpected (e.g. lock acquisition itself throwing).
        app.log.error({ err }, "[cleanup-expired] tick failed unexpectedly");
      });
  });
}
