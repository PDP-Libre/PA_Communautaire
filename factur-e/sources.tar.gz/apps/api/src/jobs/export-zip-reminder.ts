import type { FastifyInstance } from "fastify";
import type PgBoss from "pg-boss";
import type postgres from "postgres";

import { writeAuthAudit } from "../auth/audit.js";
import {
  findExportsForReminder,
  markExportReminderSent,
  type ExportRequestRow,
} from "../db/repos/export_requests.js";
import { findUserEmailById } from "../db/repos/users.js";
import type { EmailSender } from "../email/sender.js";

import { JOB_EXPORT_ZIP_REMINDER } from "./job-queue.js";

/**
 * Cron nightly `export-zip-reminder-j30` (Z3 — `0 4 * * *` UTC). Envoie 1 email
 * de rappel par customer dont des exports approchent leur date de suppression
 * (≤ 30j) et n'ont pas encore reçu de rappel (`reminder_sent_at IS NULL`).
 *
 * Idempotence : `reminder_sent_at` est posé sur TOUS les exports du batch du
 * customer → un seul email J-30 par export. Le bandeau dashboard gère J-7
 * visuellement (pas d'email J-7 — §4.6).
 *
 * Dégradation gracieuse ADR-009 : si l'email échoue, `reminder_sent_at` N'est
 * PAS posé (re-tenté au prochain tick).
 */

export interface ExportZipReminderDeps {
  sql: postgres.Sql;
  email: EmailSender;
  /** Base URL SPA pour le CTA "Voir les factures concernées". */
  webBaseUrl: string;
}

const DAY_MS = 24 * 60 * 60 * 1000;

export async function runExportZipReminder(
  deps: ExportZipReminderDeps,
): Promise<{ remindersSent: number }> {
  const rows = await findExportsForReminder(deps.sql);
  // Agrégation par customer (rows déjà triées customer_id, purge_at ASC).
  const byCustomer = new Map<string, ExportRequestRow[]>();
  for (const row of rows) {
    const list = byCustomer.get(row.customer_id) ?? [];
    list.push(row);
    byCustomer.set(row.customer_id, list);
  }

  const now = Date.now();
  let remindersSent = 0;

  for (const [customerId, exports] of byCustomer) {
    const first = exports[0];
    if (first === undefined) continue;
    const count = exports.reduce((sum, e) => sum + e.invoice_count, 0);
    const minPurge = Math.min(...exports.map((e) => e.purge_at.getTime()));
    const daysRemaining = Math.max(0, Math.ceil((minPurge - now) / DAY_MS));

    // Destinataire : le demandeur de l'export le plus proche de la purge.
    const requester = await findUserEmailById(deps.sql, first.requested_by_user_id);
    const to = requester?.email;
    if (to === undefined) continue;

    try {
      await deps.email.send({
        to,
        purpose: "export_reminder",
        payload: {
          magic_link: `${deps.webBaseUrl}/parametres/exports`,
          vars: { count: String(count), days_remaining: String(daysRemaining) },
        },
      });
    } catch {
      // email KO → on ne marque pas, re-tenté au prochain tick (ADR-009).
      continue;
    }

    for (const e of exports) await markExportReminderSent(deps.sql, e.id);
    await writeAuthAudit(deps.sql, {
      event_type: "export_reminder_sent",
      success: true,
      customer_id: customerId,
      metadata: { count, days_remaining: daysRemaining, export_ids: exports.map((e) => e.id) },
    });
    remindersSent += 1;
  }

  return { remindersSent };
}

export async function registerExportZipReminderJob(
  app: FastifyInstance,
  boss: PgBoss,
  webBaseUrl: string,
): Promise<void> {
  await boss.createQueue(JOB_EXPORT_ZIP_REMINDER);
  await boss.schedule(JOB_EXPORT_ZIP_REMINDER, "0 4 * * *", {}, { tz: "UTC" });
  await boss.work(JOB_EXPORT_ZIP_REMINDER, async () => {
    const result = await runExportZipReminder({ sql: app.sql, email: app.email, webBaseUrl });
    app.log.info({ remindersSent: result.remindersSent }, "[export-zip-reminder] done");
  });
}
