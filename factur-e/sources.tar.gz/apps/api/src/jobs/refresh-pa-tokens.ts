import type { FastifyBaseLogger, FastifyInstance } from "fastify";
import schedule from "node-schedule";
import type postgres from "postgres";

import { RefreshExpiredException, type PADriver, type PaTokens } from "@factur-e/pa-adapter";

import { writeAuthAudit } from "../auth/audit.js";
import * as paRepo from "../db/repos/pa_connections.js";
import * as usersRepo from "../db/repos/users.js";
import * as customersRepo from "../db/repos/customers.js";
import { paConnectionUiUrl } from "../pa/secret-ref.js";
import type { SecretStore } from "../secrets/plugin.js";
import type { EmailSender } from "../email/sender.js";

/**
 * Refresh background job (T-CL-06 sprint-03 — ADR-005 D8).
 *
 * Cron : `*\/5 * * * *` (every 5 min). Sweeps `pa_connections` whose
 * `last_refreshed_at < NOW() - 25 min` (window 5 min before access
 * token expiration at 1800 s SuperPDP) AND not revoked / deleted.
 *
 * For each row :
 *  - Read bundle from SecretStore.
 *  - Call `driver.refreshToken(refreshToken)` — rotation imposée.
 *  - On success : SecretStore.put new bundle (rotation transparente),
 *    `markPaConnectionRefreshed` (resets failures counter to 0),
 *    audit `pa_token_refreshed`.
 *  - On `RefreshExpiredException` (mapping ADR-005 D8 invalid_grant) :
 *    `markPaConnectionRefreshFailureIncrement` -> returns new count.
 *    At 3 → soft-delete + delete secret + audit `pa_token_lost` +
 *    email customer "Votre PA s'est déconnectée".
 *  - On other errors (5xx exhausted, protocol) : audit
 *    `pa_token_refresh_failed` reason + leave the row alone (next
 *    tick re-attempts).
 *
 * Multi-replica safety : `pg_try_advisory_lock(43211)` on a reserved
 * connection (cf. T-CL-03 cleanup-expired pattern). Skip if another
 * replica holds it. Key 43211 distinct from cleanup (43210) and
 * polling (43212).
 *
 * `start.ts` wires the scheduler conditionally on `NODE_ENV !== 'test'`.
 * Tests trigger `runRefreshPaTokens(...)` directly.
 */

const ADVISORY_LOCK_KEY = 43211;
const CRON_EXPRESSION = "*/5 * * * *";

/** Threshold in seconds — refresh when `last_refreshed_at` is older
 *  than this. 22 min = 1320 s (8 min margin before 1800 s SuperPDP
 *  access token expiration). With cron `*\/5` this gives ~2 ticks of
 *  retry budget if the first hits a transient 5xx (Scaleway rate-limit
 *  on secrets.put, network blip, etc.) before the user faces a 401-on-PA.
 *  T-CL-07 expert review [low] #4 — was 25 min (single-tick budget). */
const REFRESH_THRESHOLD_SECONDS = 22 * 60;

/** Number of consecutive `RefreshExpiredException` after which the
 *  connection is soft-deleted (ADR-005 D8). */
const MAX_REFRESH_FAILURES = 3;

export interface RefreshTickResult {
  skipped: boolean;
  refreshed: number;
  failed: number;
  lost: number;
}

export interface RefreshTickDeps {
  sql: postgres.Sql;
  driver: PADriver;
  secrets: SecretStore;
  email: EmailSender;
  log?: Pick<FastifyBaseLogger, "info" | "error" | "warn">;
}

/** Pure tick runner — idempotent, multi-replica-safe. Test entrypoint. */
export async function runRefreshPaTokens(deps: RefreshTickDeps): Promise<RefreshTickResult> {
  const log = deps.log ?? console;
  const reserved = await deps.sql.reserve();
  try {
    const lockRows = await reserved<{ acquired: boolean }[]>`
      SELECT pg_try_advisory_lock(${ADVISORY_LOCK_KEY}) AS acquired
    `;
    if (lockRows[0]?.acquired !== true) {
      return { skipped: true, refreshed: 0, failed: 0, lost: 0 };
    }
    try {
      const due = await paRepo.findPaConnectionsForRefresh(reserved, REFRESH_THRESHOLD_SECONDS);
      let refreshed = 0;
      let failed = 0;
      let lost = 0;
      for (const conn of due) {
        const outcome = await refreshOne({ conn, deps, sql: reserved });
        if (outcome === "refreshed") refreshed += 1;
        else if (outcome === "lost") lost += 1;
        else failed += 1;
      }
      log.info({ refreshed, failed, lost }, "[refresh-pa-tokens] tick done");
      return { skipped: false, refreshed, failed, lost };
    } finally {
      await reserved`SELECT pg_advisory_unlock(${ADVISORY_LOCK_KEY})`;
    }
  } finally {
    reserved.release();
  }
}

async function refreshOne(args: {
  conn: paRepo.PaConnectionRefreshDueRow;
  deps: RefreshTickDeps;
  sql: postgres.Sql;
}): Promise<"refreshed" | "failed" | "lost"> {
  const { conn, deps, sql } = args;
  const log = deps.log ?? console;

  const bundle = await deps.secrets.get(conn.secret_ref).catch((err: unknown) => {
    log.error({ err, conn: conn.id }, "[refresh-pa-tokens] secrets.get failed");
    return null;
  });
  if (bundle === null) {
    // No secret → connection orphan, mark as lost.
    await markLost(deps, conn, "secret_missing");
    return "lost";
  }

  let next: PaTokens;
  try {
    next = await deps.driver.refreshToken({ refreshToken: bundle.refreshToken });
  } catch (err) {
    if (err instanceof RefreshExpiredException) {
      const newCount = await paRepo.markPaConnectionRefreshFailureIncrement(sql, conn.id);
      await writeAuthAudit(deps.sql, {
        event_type: "pa_token_refresh_failed",
        success: false,
        customer_id: conn.customer_id,
        metadata: { reason: "refresh_expired", failures_count: newCount },
      });
      if (newCount >= MAX_REFRESH_FAILURES) {
        await markLost(deps, conn, "max_failures");
        return "lost";
      }
      return "failed";
    }
    log.error({ err, conn: conn.id }, "[refresh-pa-tokens] driver.refreshToken failed");
    await writeAuthAudit(deps.sql, {
      event_type: "pa_token_refresh_failed",
      success: false,
      customer_id: conn.customer_id,
      metadata: { reason: "driver_error" },
    });
    return "failed";
  }

  // Success — write new bundle + reset failures.
  try {
    await deps.secrets.put(conn.secret_ref, {
      accessToken: next.accessToken,
      refreshToken: next.refreshToken,
      accessExpiresAt: next.accessExpiresAt.toISOString(),
    });
  } catch (err) {
    log.error({ err, conn: conn.id }, "[refresh-pa-tokens] secrets.put failed");
    return "failed";
  }
  await paRepo.markPaConnectionRefreshed(sql, conn.id);
  await writeAuthAudit(deps.sql, {
    event_type: "pa_token_refreshed",
    success: true,
    customer_id: conn.customer_id,
  });
  return "refreshed";
}

async function markLost(
  deps: RefreshTickDeps,
  conn: paRepo.PaConnectionRefreshDueRow,
  reason: string,
): Promise<void> {
  await paRepo.markPaConnectionRevoked(deps.sql, conn.id);
  await deps.secrets.delete(conn.secret_ref).catch(() => undefined);
  await writeAuthAudit(deps.sql, {
    event_type: "pa_token_lost",
    success: false,
    customer_id: conn.customer_id,
    metadata: { reason },
  });
  // Notify the customer's primary email — find the Full user via repo.
  // We pick the first Full as a reasonable proxy; multi-Full TPEs may
  // refine in T-CL-15 sprint-03+ to notify all owners.
  try {
    const owners = await usersRepo.findActiveUsersByCustomerForList(deps.sql, conn.customer_id);
    const recipient = owners.find((u) => u.role === "full")?.email;
    if (recipient !== undefined) {
      await deps.email.send({
        to: recipient,
        purpose: "pa_token_lost",
        payload: { magic_link: paConnectionUiUrl({ status: "error", reason: "token_lost" }) },
      });
    }
  } catch (err) {
    deps.log?.error({ err, conn: conn.id }, "[refresh-pa-tokens] email notify failed");
  }
  // Touch customers.profile_unverified ? No — losing a connection
  // doesn't regress verification state (audit history says "was
  // verified at time T"). The user must re-connect to use the API.
  void customersRepo; // (kept import for future regression flips)
}

/** Register the cron scheduler. Returns the Job for graceful shutdown. */
export function registerRefreshPaTokensJob(app: FastifyInstance): schedule.Job {
  return schedule.scheduleJob(CRON_EXPRESSION, () => {
    void runRefreshPaTokens({
      sql: app.sql,
      driver: app.paDriver,
      secrets: app.secrets,
      email: app.email,
      log: app.log,
    })
      .then((result) => {
        if (result.skipped) {
          app.log.info("[refresh-pa-tokens] another replica holds the lock, skip");
        }
      })
      .catch((err: unknown) => {
        app.log.error({ err }, "[refresh-pa-tokens] tick failed unexpectedly");
      });
  });
}
