import type { FastifyInstance } from "fastify";
import PgBoss from "pg-boss";

/**
 * Job queue abstraction (T-CL-EXPORT-ZIP-RETENTION sprint-06 L12, Z1).
 *
 * pgboss = file de jobs PostgreSQL native (arbitrage Bruno sprint-06 §12 —
 * pas de Redis V1). Seul le *producteur* (enqueue) est exposé ici ; les
 * *workers* + crons sont enregistrés au boot dans `start.ts` (pattern des
 * jobs `node-schedule` existants — non migrés, cf. §12).
 *
 * Deux implémentations, sélection comme les autres adapters (email/storage) :
 *  - `MockJobQueue` — capture en mémoire. Défaut `buildApp` (tests : le
 *    endpoint enqueue, le test inspecte `enqueued`). Le worker n'est pas
 *    déclenché en test — on appelle `runExportZipGenerate(...)` directement.
 *  - `PgBossJobQueue` — `boss.send(name, data)`. Injectée par `start.ts` via
 *    `buildApp({ jobQueue })` une fois `boss.start()` résolu.
 */

export const JOB_EXPORT_ZIP_GENERATE = "export-zip-generate";
export const JOB_EXPORT_ZIP_REMINDER = "export-zip-reminder-j30";
export const JOB_EXPORT_ZIP_PURGE = "export-zip-purge";

export interface ExportZipGeneratePayload {
  export_request_id: string;
}

export interface JobQueue {
  /** Enqueue un job nommé avec son payload. */
  enqueue(name: string, data: Record<string, unknown>): Promise<void>;
}

declare module "fastify" {
  interface FastifyInstance {
    jobQueue: JobQueue;
  }
}

export class MockJobQueue implements JobQueue {
  readonly enqueued: { name: string; data: Record<string, unknown> }[] = [];

  async enqueue(name: string, data: Record<string, unknown>): Promise<void> {
    this.enqueued.push({ name, data });
    await Promise.resolve();
  }

  /** Test helper : dernier job enqueue pour un nom donné. */
  lastEnqueued(name: string): Record<string, unknown> | undefined {
    for (let i = this.enqueued.length - 1; i >= 0; i--) {
      const item = this.enqueued[i];
      if (item?.name === name) return item.data;
    }
    return undefined;
  }

  reset(): void {
    this.enqueued.length = 0;
  }
}

export class PgBossJobQueue implements JobQueue {
  private readonly boss: PgBoss;

  constructor(boss: PgBoss) {
    this.boss = boss;
  }

  async enqueue(name: string, data: Record<string, unknown>): Promise<void> {
    // retryLimit/backoff/expire posés au niveau du PgBoss constructor (§12).
    await this.boss.send(name, data);
  }
}

/**
 * Construit l'instance PgBoss du module Export (§12). Le constructeur VALIDE la
 * config en synchrone (sans connexion DB) — d'où le test unitaire dédié.
 *
 * `expireInHours` doit être STRICTEMENT < 24 : l'assertion pg-boss attorney est
 * `expireIn/3600 < MAX_EXPIRATION_HOURS (24)`, donc 24 pile est rejeté
 * (« expiration cannot exceed 24 hours »). 23h couvre largement une génération
 * ZIP TPE. retryLimit 3 + backoff exponentiel (export-zip-generate).
 */
export function buildExportPgBoss(connectionString: string): PgBoss {
  return new PgBoss({
    connectionString,
    retryLimit: 3,
    retryBackoff: true,
    expireInHours: 23,
  });
}

export function attachJobQueue(app: FastifyInstance, queue: JobQueue): void {
  app.decorate("jobQueue", queue);
}

/** Défaut `buildApp` : toujours le mock. La queue pgboss réelle est construite
 *  explicitement dans `start.ts` (cycle de vie start/stop géré au boot). */
export function createDefaultJobQueue(): JobQueue {
  return new MockJobQueue();
}
