import type { FastifyInstance } from "fastify";
import type PgBoss from "pg-boss";
import type postgres from "postgres";

import { writeAuthAudit } from "../auth/audit.js";
import { findCompletedExportsToPurge, markExportPurged } from "../db/repos/export_requests.js";
import type { ObjectStorage } from "../storage/object-storage.js";

import { JOB_EXPORT_ZIP_PURGE } from "./job-queue.js";

/**
 * Cron nightly `export-zip-purge` (Z3 — `0 5 * * *` UTC). Purge RGPD 6 mois
 * (RET-6) : supprime le fichier S3 des exports expirés et passe la row à
 * `purged` (file_key NULL). La row est PRÉSERVÉE pour auditabilité.
 *
 * Protection critique (RET-6) : ce job purge les ARCHIVES ZIP, jamais les
 * factures `invoices`/`received_invoices` (leur purge est un mécanisme séparé,
 * hors scope sprint-06).
 */

export interface ExportZipPurgeDeps {
  sql: postgres.Sql;
  exportsStorage: ObjectStorage;
}

export async function runExportZipPurge(deps: ExportZipPurgeDeps): Promise<{ purged: number }> {
  const expired = await findCompletedExportsToPurge(deps.sql);
  let purged = 0;
  for (const row of expired) {
    if (row.file_key !== null) {
      await deps.exportsStorage.deleteObject(row.file_key); // best-effort
    }
    await markExportPurged(deps.sql, row.id);
    await writeAuthAudit(deps.sql, {
      event_type: "export_zip_purged",
      success: true,
      customer_id: row.customer_id,
      metadata: { export_id: row.id },
    });
    purged += 1;
  }
  return { purged };
}

export async function registerExportZipPurgeJob(app: FastifyInstance, boss: PgBoss): Promise<void> {
  await boss.createQueue(JOB_EXPORT_ZIP_PURGE);
  await boss.schedule(JOB_EXPORT_ZIP_PURGE, "0 5 * * *", {}, { tz: "UTC" });
  await boss.work(JOB_EXPORT_ZIP_PURGE, async () => {
    const result = await runExportZipPurge({ sql: app.sql, exportsStorage: app.exportsStorage });
    app.log.info({ purged: result.purged }, "[export-zip-purge] done");
  });
}
