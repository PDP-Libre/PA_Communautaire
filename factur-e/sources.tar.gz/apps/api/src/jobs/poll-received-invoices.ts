import type { FastifyBaseLogger, FastifyInstance } from "fastify";
import schedule from "node-schedule";
import type postgres from "postgres";

import {
  isWebOnboarding,
  type CustomerContext,
  type IncomingInvoice,
  type PADriverCore,
  type PaCredentials,
} from "@factur-e/pa-adapter";

import { writeAuthAudit } from "../auth/audit.js";
import * as directoryCacheRepo from "../db/repos/directory_cache.js";
import * as incomingCdarRepo from "../db/repos/incoming_cdar_events.js";
import * as paRepo from "../db/repos/pa_connections.js";
import * as pollingStateRepo from "../db/repos/pa_polling_state.js";
import * as recvRepo from "../db/repos/received_invoices.js";
import type { SecretStore } from "../secrets/plugin.js";

/**
 * Polling background job RÉCEPTION — T-CL-RECV-API sprint-05 W2. Pattern
 * miroir `poll-cdar-events.ts` (ADR-010 v2 D4 + ADR-012 D5 + ADR-009
 * D1+D3+D4+D5), adapté à la découverte des factures REÇUES.
 *
 * **Pivot prompt v1→v2** : le prompt visait `searchIncomingFlows` sur
 * `GET /flows/search?direction=In` (ADR-010 v1 SUPERSEDED). Le vrai
 * endpoint est `GET /v1.beta/invoices?direction=in&starting_after_id=`
 * (cursor Stripe-like, miroir `invoice_events`). Cf. trace `[NOTE-COWORK]`.
 *
 * Pipeline d'un tick :
 *  1. `pg_try_advisory_lock(43214)` — multi-replica safety (distinct du
 *     43213 sortant CDAR). Skip si tenu.
 *  2. `findActivePaConnectionsByProvider(sql, 'superpdp')`.
 *  3. Pour chaque customer :
 *     a. Charger credentials SecretStore (`PaTokens` → `PaCredentials`).
 *     b. `getCursor(sql, customer_id, 'superpdp', 'in')` (default '0').
 *     c. `driver.listIncomingInvoices({cursor, limit: 100}, ctx)`.
 *     d. Pour chaque facture :
 *        - SIREN absent → skip + audit (table `seller_siren` NOT NULL).
 *        - Matching SIREN : `directory_cache` (TTL 7j) + fallback
 *          `driver.searchSiren` → `seller_name_cached` + `supplier_matched`.
 *        - INSERT `received_invoices` ON CONFLICT DO NOTHING (ADR-009 D4).
 *        - Si nouveau : INSERT `incoming_cdar_events` fr:204 source
 *          'polling' + audit `received_invoice_inserted`.
 *     e. Sur succès : `upsertCursor` direction 'in' → nextCursor.
 *     f. Sur fail (5xx épuisé, exception) : log + audit
 *        `pa_polling_recv_failed` + **pas d'upsert** (retry tick suivant).
 *
 * CRON paramétrable env `RECV_POLLING_CRON` (default `*\/15 * * * *` prod,
 * `* * * * *` dev) — cohérent ADR-009 D3 / `CDAR_POLLING_CRON`.
 *
 * Tests : `runPollReceivedInvoices(deps)` entrypoint pur. Scheduler wired
 * dans `start.ts` conditionnel `NODE_ENV !== 'test'`.
 */

const ADVISORY_LOCK_KEY = 43214;
const DEFAULT_CRON_EXPRESSION = "*/15 * * * *";
const DEFAULT_LIMIT = 100;
const CURSOR_INITIAL = "0";
const PROVIDER = "superpdp";
const DIRECTION = "in" as const;
/** Code AFNOR auto-posé localement à la réception (fr:204 Prise en charge
 *  = "Reçue" glossaire UI base). Enregistré timeline, pas (re)posé à la PA. */
const RECEPTION_CDAR_CODE = "fr:204";
/** Annulation par le fournisseur (fr:209) — événement ENTRANT détecté au
 *  polling (snapshot `rawStatusCode`), ingéré côté Acquéreur en lecture seule
 *  (T-CL-RECV-WEB-211-209 sprint-07). */
const CANCELLED_CDAR_CODE = "fr:209";

export interface RecvPollTickResult {
  skipped: boolean;
  customersScanned: number;
  /** INSERT effectifs (nouvelles factures reçues). */
  receivedInvoicesInserted: number;
  /** ON CONFLICT no-ops (factures déjà reçues — idempotence). */
  receivedInvoicesSkipped: number;
  errors: number;
}

export interface RecvPollTickDeps {
  sql: postgres.Sql;
  driver: PADriverCore;
  secrets: SecretStore;
  log?: Pick<FastifyBaseLogger, "info" | "error" | "warn">;
}

/** Pure tick runner — idempotent, multi-replica-safe. Test entrypoint. */
export async function runPollReceivedInvoices(deps: RecvPollTickDeps): Promise<RecvPollTickResult> {
  const log = deps.log ?? console;
  const reserved = await deps.sql.reserve();
  try {
    const lockRows = await reserved<{ acquired: boolean }[]>`
      SELECT pg_try_advisory_lock(${ADVISORY_LOCK_KEY}) AS acquired
    `;
    if (lockRows[0]?.acquired !== true) {
      return {
        skipped: true,
        customersScanned: 0,
        receivedInvoicesInserted: 0,
        receivedInvoicesSkipped: 0,
        errors: 0,
      };
    }
    try {
      const connections = await paRepo.findActivePaConnectionsByProvider(reserved, PROVIDER);
      let inserted = 0;
      let skipped = 0;
      let errors = 0;
      for (const conn of connections) {
        const outcome = await pollOneCustomer({ conn, deps, sql: reserved });
        inserted += outcome.inserted;
        skipped += outcome.skipped;
        errors += outcome.errors;
      }
      log.info(
        {
          job: "poll_received_invoices",
          provider: PROVIDER,
          customers_scanned: connections.length,
          received_invoices_inserted: inserted,
          received_invoices_skipped: skipped,
          errors,
        },
        "[poll-received-invoices] tick done",
      );
      return {
        skipped: false,
        customersScanned: connections.length,
        receivedInvoicesInserted: inserted,
        receivedInvoicesSkipped: skipped,
        errors,
      };
    } finally {
      await reserved`SELECT pg_advisory_unlock(${ADVISORY_LOCK_KEY})`;
    }
  } finally {
    reserved.release();
  }
}

async function pollOneCustomer(args: {
  conn: paRepo.PaConnectionForCdarPollingRow;
  deps: RecvPollTickDeps;
  sql: postgres.Sql;
}): Promise<{ inserted: number; skipped: number; errors: number }> {
  const { conn, deps, sql } = args;
  const log = deps.log ?? console;

  // 1. Charger credentials SecretStore (même pattern que poll-cdar-events).
  let bundle: { accessToken: string; refreshToken: string; accessExpiresAt: string };
  try {
    const loaded = await deps.secrets.get(conn.secret_ref);
    if (loaded === null) {
      log.warn({ conn_id: conn.id }, "[poll-received-invoices] secret_ref returned null");
      return { inserted: 0, skipped: 0, errors: 1 };
    }
    bundle = loaded;
  } catch (err) {
    log.error({ err, conn_id: conn.id }, "[poll-received-invoices] secrets.get failed");
    return { inserted: 0, skipped: 0, errors: 1 };
  }

  const credentials: PaCredentials = {
    kind: "superpdp-oauth-ac",
    accessToken: bundle.accessToken,
    refreshToken: bundle.refreshToken,
    accessExpiresAt: new Date(bundle.accessExpiresAt),
    paUserId: null,
  };
  const ctx: CustomerContext = { customerId: conn.customer_id, credentials };

  // 2. Cursor courant scopé direction 'in' (distinct du cursor sortant).
  const cursorRow = await pollingStateRepo.getCursor(sql, conn.customer_id, PROVIDER, DIRECTION);
  const cursor = cursorRow?.cursor ?? CURSOR_INITIAL;

  // 3. Appel driver — fail-safe ADR-009 D1 : absorber exceptions, pas
  //    d'upsert cursor sur fail (retry au tick suivant, pas de perte).
  let result: { invoices: readonly IncomingInvoice[]; nextCursor: string; hasMore: boolean };
  try {
    if (!isWebOnboarding(deps.driver) && deps.driver.providerId !== "superpdp") {
      log.warn(
        { conn_id: conn.id, provider_id: deps.driver.providerId },
        "[poll-received-invoices] non-SuperPDP driver — skip (V2 multi-PA pas livré)",
      );
      return { inserted: 0, skipped: 0, errors: 0 };
    }
    result = await deps.driver.listIncomingInvoices({ cursor, limit: DEFAULT_LIMIT }, ctx);
  } catch (err) {
    log.error(
      { err, conn_id: conn.id, customer_id: conn.customer_id, cursor },
      "[poll-received-invoices] driver.listIncomingInvoices failed",
    );
    await writeAuthAudit(deps.sql, {
      event_type: "pa_polling_recv_failed",
      success: false,
      customer_id: conn.customer_id,
      metadata: { provider: PROVIDER, cursor },
    });
    return { inserted: 0, skipped: 0, errors: 1 };
  }

  // 4. Persister chaque facture entrante (idempotent ON CONFLICT).
  let inserted = 0;
  let skipped = 0;
  let errors = 0;
  for (const invoice of result.invoices) {
    const outcome = await persistIncomingInvoice({ invoice, conn, deps, sql, ctx });
    inserted += outcome.inserted;
    skipped += outcome.skipped;
    errors += outcome.errors;
  }

  // 5. UPSERT cursor seulement sur succès driver (ADR-009 D1). Avance même
  //    si batch vide quand nextCursor a bougé (cohérent poll-cdar-events).
  if (result.nextCursor !== cursor || result.invoices.length > 0) {
    await pollingStateRepo.upsertCursor(sql, {
      customerId: conn.customer_id,
      provider: PROVIDER,
      direction: DIRECTION,
      cursor: result.nextCursor,
    });
  }

  return { inserted, skipped, errors };
}

async function persistIncomingInvoice(args: {
  invoice: IncomingInvoice;
  conn: paRepo.PaConnectionForCdarPollingRow;
  deps: RecvPollTickDeps;
  sql: postgres.Sql;
  ctx: CustomerContext;
}): Promise<{ inserted: number; skipped: number; errors: number }> {
  const { invoice, conn, deps, sql, ctx } = args;
  const log = deps.log ?? console;
  const en = invoice.enInvoice;

  // SIREN obligatoire (colonne NOT NULL). Absent → skip + audit (anomalie :
  // fournisseur étranger sans registration ID, ou expand partiel).
  const sellerSiren = en?.sellerSiren;
  if (sellerSiren === undefined || sellerSiren === "") {
    log.warn(
      { conn_id: conn.id, pa_invoice_id_in: invoice.paInvoiceId },
      "[poll-received-invoices] incoming invoice without seller SIREN — skip",
    );
    await writeAuthAudit(deps.sql, {
      event_type: "received_invoice_skipped_no_siren",
      success: false,
      customer_id: conn.customer_id,
      metadata: { pa_invoice_id_in: invoice.paInvoiceId },
    });
    return { inserted: 0, skipped: 0, errors: 1 };
  }

  // Matching fournisseur — cache annuaire 7j + fallback PA searchSiren.
  const match = await resolveSupplier({
    sellerSiren,
    fallbackName: en?.sellerName,
    deps,
    sql,
    ctx,
  });

  const totalTtcCents = en?.totalTtcCents ?? null;
  const insertedRow = await recvRepo.insertReceivedInvoice(sql, {
    customer_id: conn.customer_id,
    pa_invoice_id_in: invoice.paInvoiceId,
    pa_provider: PROVIDER,
    seller_siren: sellerSiren,
    seller_name_cached: match.name,
    supplier_matched: match.matched,
    invoice_number_extracted: en?.number ?? null,
    issue_date: en?.issueDate ?? null,
    due_date: en?.dueDate ?? null,
    total_ttc_cents: totalTtcCents,
    currency: en?.currency ?? "EUR",
    received_at: invoice.receivedAt,
  });

  if (insertedRow === null) {
    // ON CONFLICT — facture déjà reçue (idempotence ADR-009 D4). On vérifie
    // tout de même une éventuelle annulation entrante (fr:209) à ingérer.
    const existing = await recvRepo.findReceivedInvoiceByPaInvoiceIdIn(
      sql,
      conn.customer_id,
      invoice.paInvoiceId,
    );
    if (existing !== undefined) {
      await maybeIngestCancellation({ row: existing, invoice, conn, deps, sql });
    }
    return { inserted: 0, skipped: 1, errors: 0 };
  }

  // CDAR fr:204 auto (Prise en charge / "Reçue") — timeline locale, source
  // 'polling'. occurred_at = received_at pour idempotence stable.
  await incomingCdarRepo.insertIncomingCdarEvent(sql, {
    received_invoice_id: insertedRow.id,
    code: RECEPTION_CDAR_CODE,
    label: "Prise en charge",
    occurred_at: insertedRow.received_at,
    source: "polling",
  });

  await writeAuthAudit(deps.sql, {
    event_type: "received_invoice_inserted",
    success: true,
    customer_id: conn.customer_id,
    metadata: {
      received_invoice_id: insertedRow.id,
      pa_invoice_id_in: invoice.paInvoiceId,
      seller_siren: sellerSiren,
      supplier_matched: match.matched,
    },
  });

  // Facture déjà annulée à la première réception (rare) — ingère le 209.
  await maybeIngestCancellation({ row: insertedRow, invoice, conn, deps, sql });

  return { inserted: 1, skipped: 0, errors: 0 };
}

/**
 * Ingère une annulation fournisseur (fr:209) détectée au snapshot de polling
 * (T-CL-RECV-WEB-211-209). Lecture seule Acquéreur — événement timeline +
 * `status_current = cancelled`. Idempotent : gate sur `status_current` +
 * `ON CONFLICT (received_invoice_id, code, occurred_at)`. V1 snapshot : pas
 * d'horodatage d'événement distinct → `occurred_at = received_at` (clé stable).
 */
async function maybeIngestCancellation(args: {
  row: recvRepo.ReceivedInvoiceRow;
  invoice: IncomingInvoice;
  conn: paRepo.PaConnectionForCdarPollingRow;
  deps: RecvPollTickDeps;
  sql: postgres.Sql;
}): Promise<void> {
  const { row, invoice, conn, deps, sql } = args;
  if (invoice.rawStatusCode !== CANCELLED_CDAR_CODE) return;
  if (row.status_current === "cancelled") return;

  const ev = await incomingCdarRepo.insertIncomingCdarEvent(sql, {
    received_invoice_id: row.id,
    code: CANCELLED_CDAR_CODE,
    label: "Annulée",
    occurred_at: row.received_at,
    source: "polling",
  });
  if (!ev.inserted) return;

  await recvRepo.markReceivedInvoiceStatus(sql, row.id, "cancelled");
  await writeAuthAudit(deps.sql, {
    event_type: "received_invoice_cancelled_ingested",
    success: true,
    customer_id: conn.customer_id,
    metadata: { received_invoice_id: row.id, pa_invoice_id_in: invoice.paInvoiceId },
  });
}

/**
 * Résout la raison sociale fournisseur depuis l'annuaire. Cascade :
 *  1. `directory_cache` (TTL 7j sprint-03) — hit positif → matched.
 *  2. Fallback `driver.searchSiren` (ne throw pas — retourne `unavailable`
 *     sur 5xx/timeout). Found → matched + upsert cache.
 *  3. Sinon → fallback nom parsé (`en_invoice.seller.name`), matched=false
 *     (warning UI "Fournisseur non identifié" brief §6.8 — ne bloque pas).
 */
async function resolveSupplier(args: {
  sellerSiren: string;
  fallbackName: string | undefined;
  deps: RecvPollTickDeps;
  sql: postgres.Sql;
  ctx: CustomerContext;
}): Promise<{ name: string | null; matched: boolean }> {
  const { sellerSiren, fallbackName, deps, sql, ctx } = args;

  const cached = await directoryCacheRepo.findFreshDirectoryCacheBySiren(sql, sellerSiren);
  if (cached !== undefined) {
    const cachedName = extractFormalName(cached.payload);
    if (cachedName !== null) return { name: cachedName, matched: true };
    // Cache négatif (payload null) → SIREN connu absent annuaire.
    return { name: fallbackName ?? null, matched: false };
  }

  const search = await deps.driver.searchSiren({ siren: sellerSiren }, ctx);
  if (search.kind === "found_one_address" || search.kind === "found_multi_address") {
    const addresses = search.kind === "found_one_address" ? [search.address] : search.addresses;
    await directoryCacheRepo.upsertDirectoryCache(sql, {
      siren: sellerSiren,
      payload: search.company as unknown as postgres.JSONValue,
      addresses: addresses.map((a) => ({
        party_id: a.party_id,
        scheme_id: a.scheme_id,
        is_active: a.is_active,
        pa_name: a.pa_name,
      })),
    });
    return { name: search.company.formal_name, matched: true };
  }

  // not_found / disabled / unavailable → fallback nom parsé, non matché.
  return { name: fallbackName ?? null, matched: false };
}

/** Extrait `formal_name` d'un payload `directory_cache` (raw company). */
function extractFormalName(payload: Record<string, unknown> | null): string | null {
  if (payload === null) return null;
  const name = payload.formal_name;
  return typeof name === "string" && name !== "" ? name : null;
}

/** Register the cron scheduler. CRON lu depuis env `RECV_POLLING_CRON`
 *  (ADR-009 D3) — default `*\/15 * * * *` prod, `* * * * *` dev. */
export function registerPollReceivedInvoicesJob(app: FastifyInstance): schedule.Job {
  const cron = process.env.RECV_POLLING_CRON ?? DEFAULT_CRON_EXPRESSION;
  app.log.info({ cron }, "[poll-received-invoices] scheduling job");
  return schedule.scheduleJob(cron, () => {
    void runPollReceivedInvoices({
      sql: app.sql,
      driver: app.paDriver,
      secrets: app.secrets,
      log: app.log,
    })
      .then((result) => {
        if (result.skipped) {
          app.log.info("[poll-received-invoices] another replica holds the lock, skip");
        }
      })
      .catch((err: unknown) => {
        app.log.error({ err }, "[poll-received-invoices] tick failed unexpectedly");
      });
  });
}
