import type { FastifyBaseLogger, FastifyInstance } from "fastify";
import schedule from "node-schedule";
import type postgres from "postgres";

import type { PADriver } from "@factur-e/pa-adapter";

import { writeAuthAudit } from "../auth/audit.js";
import * as customersRepo from "../db/repos/customers.js";
import * as paRepo from "../db/repos/pa_connections.js";
import type { SecretStore } from "../secrets/plugin.js";

/**
 * T-CL-PA-DIRECTORY-PEPPOL sprint-05 — Job background pour enrichir
 * l'adresse Peppol `customers.directory_address` quand le callback OAuth
 * a échoué (not_found / 5xx / disabled) ou pour les customers
 * pré-existants au sprint-05 (migration historique best-effort).
 *
 * Pattern node-schedule reproduit `poll-pa-identity-status.ts` (sprint-03)
 * + `refresh-pa-tokens.ts`. Multi-replica safe via
 * `pg_try_advisory_lock(43213)`.
 *
 * Backoff (arbitrage Bruno récap pré-code) : 5/30/60/360/1440 min, 5
 * retries max. Au-delà → audit `peppol_address_enrichment_giveup` + flag
 * `peppol_address_retry_count = 5` (skip définitif côté SELECT).
 *
 * Cohérent ADR-009 D1 fail-safe degradation + D2 statut intermédiaire
 * (UI EmptyState "Adresse en cours d'attribution" pendant la fenêtre
 * retry).
 */
const ADVISORY_LOCK_KEY = 43213;
const CRON_EXPRESSION = "*/5 * * * *"; // toutes les 5 min — backoff côté row
const MAX_RETRIES = 5;

/** Backoff en minutes selon `retry_count` post-increment. */
const BACKOFF_MINUTES: readonly number[] = [5, 30, 60, 360, 1440];

function nextRetryDate(retryCountAfterIncrement: number): Date | null {
  if (retryCountAfterIncrement >= MAX_RETRIES) return null;
  const minutes = BACKOFF_MINUTES[retryCountAfterIncrement] ?? 1440;
  return new Date(Date.now() + minutes * 60 * 1000);
}

export interface EnrichTickResult {
  skipped: boolean;
  scanned: number;
  enriched: number;
  givenup: number;
}

export interface EnrichTickDeps {
  sql: postgres.Sql;
  driver: PADriver;
  /** T-CL-PA-OWN-DIRECTORY-ENTRIES sprint-06 — l'adresse propre vient de
   *  `getOwnDirectoryEntries` (authentifié) → besoin du token PA du
   *  customer, lu depuis le SecretStore via le `secret_ref` de sa
   *  `pa_connection`. */
  secrets: SecretStore;
  log?: Pick<FastifyBaseLogger, "info" | "error" | "warn">;
}

/** Pure tick runner — idempotent, multi-replica-safe. Test entrypoint. */
export async function runEnrichCustomerPeppolAddress(
  deps: EnrichTickDeps,
): Promise<EnrichTickResult> {
  const log = deps.log ?? console;
  const reserved = await deps.sql.reserve();
  try {
    const lockRows = await reserved<{ acquired: boolean }[]>`
      SELECT pg_try_advisory_lock(${ADVISORY_LOCK_KEY}) AS acquired
    `;
    if (lockRows[0]?.acquired !== true) {
      return { skipped: true, scanned: 0, enriched: 0, givenup: 0 };
    }
    try {
      const due = await customersRepo.findCustomersPendingPeppolEnrichment(reserved, MAX_RETRIES);
      let enriched = 0;
      let givenup = 0;
      for (const cust of due) {
        const result = await enrichOne({ cust, deps, sql: reserved });
        if (result === "enriched") enriched += 1;
        if (result === "givenup") givenup += 1;
      }
      log.info(
        { scanned: due.length, enriched, givenup },
        "[enrich-customer-peppol-address] tick done",
      );
      return { skipped: false, scanned: due.length, enriched, givenup };
    } finally {
      await reserved`SELECT pg_advisory_unlock(${ADVISORY_LOCK_KEY})`;
    }
  } finally {
    reserved.release();
  }
}

async function enrichOne(args: {
  cust: { id: string; siren: string; peppol_address_retry_count: number };
  deps: EnrichTickDeps;
  sql: postgres.Sql;
}): Promise<"enriched" | "retry" | "givenup"> {
  const { cust, deps, sql } = args;
  const log = deps.log ?? console;

  // Adresse propre via `directory_entries` (authentifié) → token PA du
  // customer. Sans connexion PA active / bundle → on reprogramme un retry.
  const conn = await paRepo.findActivePaConnectionForDisconnectByCustomerId(sql, cust.id);
  const bundle =
    conn === undefined ? null : await deps.secrets.get(conn.secret_ref).catch(() => null);
  if (bundle === null) {
    return await scheduleRetryOrGiveup({ cust, sql, deps, reason: "unavailable" });
  }

  let result;
  try {
    result = await deps.driver.getOwnDirectoryEntries({ accessToken: bundle.accessToken });
  } catch (err) {
    log.warn(
      { err, customer_id: cust.id },
      "[enrich-customer-peppol-address] getOwnDirectoryEntries threw",
    );
    return await scheduleRetryOrGiveup({
      cust,
      sql,
      deps,
      reason: "lookup_5xx",
    });
  }

  if (result.kind === "found_one_address" || result.kind === "found_multi_address") {
    const address = result.kind === "found_one_address" ? result.address : result.addresses[0];
    if (address !== undefined) {
      await customersRepo.updateCustomerDirectoryAddress(sql, cust.id, address.party_id);
      await writeAuthAudit(deps.sql, {
        event_type: "peppol_address_enriched_via_job",
        success: true,
        customer_id: cust.id,
        metadata: {
          directory_address: address.party_id,
          retry_count: cust.peppol_address_retry_count,
          kind: result.kind,
        },
      });
      return "enriched";
    }
  }

  return await scheduleRetryOrGiveup({
    cust,
    sql,
    deps,
    reason:
      result.kind === "not_found"
        ? "not_found"
        : result.kind === "disabled"
          ? "disabled"
          : "unavailable",
  });
}

async function scheduleRetryOrGiveup(args: {
  cust: { id: string; peppol_address_retry_count: number };
  sql: postgres.Sql;
  deps: EnrichTickDeps;
  reason: "not_found" | "disabled" | "unavailable" | "lookup_5xx";
}): Promise<"retry" | "givenup"> {
  const { cust, sql, deps, reason } = args;
  const nextCount = cust.peppol_address_retry_count + 1;
  const nextAt = nextRetryDate(nextCount);
  await customersRepo.bumpCustomerPeppolRetry(sql, cust.id, nextAt);

  if (nextCount >= MAX_RETRIES) {
    await writeAuthAudit(deps.sql, {
      event_type: "peppol_address_enrichment_giveup",
      success: false,
      customer_id: cust.id,
      metadata: { retry_count: nextCount, last_reason: reason },
    });
    return "givenup";
  }
  return "retry";
}

/** Register the cron scheduler. */
export function registerEnrichCustomerPeppolAddressJob(app: FastifyInstance): schedule.Job {
  return schedule.scheduleJob(CRON_EXPRESSION, () => {
    void runEnrichCustomerPeppolAddress({
      sql: app.sql,
      driver: app.paDriver,
      secrets: app.secrets,
      log: app.log,
    })
      .then((result) => {
        if (result.skipped) {
          app.log.info("[enrich-customer-peppol-address] another replica holds the lock, skip");
        }
      })
      .catch((err: unknown) => {
        app.log.error({ err }, "[enrich-customer-peppol-address] tick failed unexpectedly");
      });
  });
}
