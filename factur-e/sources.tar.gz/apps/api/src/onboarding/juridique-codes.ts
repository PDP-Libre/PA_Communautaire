/**
 * INSEE `categorieJuridiqueUniteLegale` — short label table for the
 * codes that show up in the onboarding flow (TPE / artisan / EI / SAS /
 * SARL / EURL / SCI / association / etc.). Source: INSEE Liste des
 * catégories juridiques niveau III (https://insee.fr/fr/information/2028129).
 *
 * Codes not in this table fall back to a neutral "Forme juridique
 * inconnue" — the raw 4-digit code stays in the `signup_pending` audit
 * trail. Adding a code here is a one-line PR; we deliberately don't
 * try to be exhaustive.
 */

const JURIDIQUE_LABELS: Record<string, string> = {
  "1000": "Entrepreneur individuel",
  "5202": "Société en nom collectif",
  "5306": "Société en commandite simple",
  "5410": "SARL nationale",
  "5415": "SARL d'économie mixte",
  "5422": "SARL immobilière",
  "5426": "SARL immobilière de gestion",
  "5430": "SARL d'attribution",
  "5431": "SARL coopérative de construction",
  "5432": "SARL coopérative de consommation",
  "5442": "SARL d'aménagement foncier et d'équipement rural",
  "5451": "SARL coopérative ouvrière de production (SCOP)",
  "5453": "SARL coopérative agricole",
  "5454": "SARL coopérative artisanale",
  "5455": "SARL coopérative d'intérêt maritime",
  "5458": "SARL coopérative de transports",
  "5459": "SARL coopérative",
  "5460": "Autre SARL coopérative",
  "5485": "Société d'exercice libéral à responsabilité limitée (SELARL)",
  "5498": "SARL unipersonnelle (EURL)",
  "5499": "Société à responsabilité limitée (SARL)",
  "5505": "SA à participation ouvrière à conseil d'administration",
  "5510": "SA nationale à conseil d'administration",
  "5515": "SA d'économie mixte à conseil d'administration",
  "5520": "Fonds à forme de société anonyme",
  "5522": "SA immobilière à conseil d'administration",
  "5525": "SA immobilière d'investissement à conseil d'administration",
  "5530": "SA d'attribution à conseil d'administration",
  "5531": "SA coopérative de construction à conseil d'administration",
  "5532": "SA HLM à conseil d'administration",
  "5542": "SA coopérative agricole à conseil d'administration",
  "5543": "SA coopérative d'intérêt collectif agricole à CA",
  "5546": "SA coopérative artisanale à conseil d'administration",
  "5547": "SA coopérative de transports à conseil d'administration",
  "5548": "SA coopérative ouvrière de production (SCOP) à CA",
  "5560": "Autre SA coopérative à conseil d'administration",
  "5585": "Société d'exercice libéral à forme anonyme à CA (SELAFA)",
  "5599": "Société anonyme (SA) à conseil d'administration",
  "5605": "SA à participation ouvrière à directoire",
  "5610": "SA nationale à directoire",
  "5615": "SA d'économie mixte à directoire",
  "5625": "SA immobilière d'investissement à directoire",
  "5630": "SA d'attribution à directoire",
  "5631": "SA coopérative de construction à directoire",
  "5632": "SA HLM à directoire",
  "5642": "SA coopérative agricole à directoire",
  "5643": "SA coopérative d'intérêt collectif agricole à directoire",
  "5646": "SA coopérative artisanale à directoire",
  "5647": "SA coopérative de transports à directoire",
  "5648": "SA coopérative ouvrière de production (SCOP) à directoire",
  "5660": "Autre SA coopérative à directoire",
  "5685": "Société d'exercice libéral à forme anonyme à directoire",
  "5699": "Société anonyme (SA) à directoire",
  "5710": "Société par actions simplifiée (SAS)",
  "5720": "Société par actions simplifiée à associé unique (SASU)",
  "5785": "Société d'exercice libéral par actions simplifiée (SELAS)",
  "5800": "Société européenne",
  "6100": "Caisse d'épargne et de prévoyance",
  "6411": "Société anonyme à directoire et à conseil de surveillance",
  "9220": "Association déclarée",
  "9230": "Association déclarée d'insertion par l'économique",
  "9240": "Association reconnue d'utilité publique",
};

export function juridiqueLabel(code: string | null | undefined): string {
  if (code === null || code === undefined || code === "") return "Forme juridique inconnue";
  return JURIDIQUE_LABELS[code] ?? "Forme juridique inconnue";
}
