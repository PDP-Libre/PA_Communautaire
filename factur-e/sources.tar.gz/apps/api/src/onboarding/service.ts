import type postgres from "postgres";

import type { InseeClient, InseeLookupResult } from "@factur-e/insee-adapter";

import { lookupCache, writeCache } from "./cache.js";

/**
 * Onboarding orchestration: combine BDD anti-doublon check + insee_cache
 * + INSEE adapter into a single discriminated outcome the route layer
 * maps to HTTP.
 *
 * Decision order (cheap → costly):
 *   1. SIREN already attached to a `customers` row → `already_bound`.
 *   2. Cache hit (fresh) → use cached `found`/`not_found`/`restricted`.
 *   3. Cache miss / stale → call INSEE.
 *   4. INSEE `unavailable` + cache stale row available → degrade to that.
 */

export type ResolveSirenResult =
  | { kind: "found"; payload: InseeLookupResult & { kind: "found" } }
  | { kind: "not_found" }
  | { kind: "already_bound" }
  | { kind: "restricted" }
  | { kind: "unavailable" };

export async function resolveSiren(
  sql: postgres.Sql,
  insee: InseeClient,
  siren: string,
): Promise<ResolveSirenResult> {
  // 1. Already bound to a Factur-e customer?
  const customers = await sql<{ id: string }[]>`
    SELECT id FROM customers WHERE siren = ${siren} AND deleted_at IS NULL
  `;
  if (customers.length > 0) return { kind: "already_bound" };

  // 2. Fresh cache.
  const cached = await lookupCache(sql, siren);
  if (cached?.fresh === true) {
    if (cached.found.kind === "found") return { kind: "found", payload: cached.found };
    if (cached.found.kind === "not_found") return { kind: "not_found" };
    if (cached.found.kind === "restricted") return { kind: "restricted" };
  }

  // 3. INSEE call.
  const fetched = await insee.lookupSiren(siren);

  if (fetched.kind === "unavailable") {
    // 4. Graceful degradation — use stale cache if any.
    if (cached !== null && cached.found.kind === "found") {
      return { kind: "found", payload: cached.found };
    }
    return { kind: "unavailable" };
  }

  await writeCache(sql, siren, fetched);

  if (fetched.kind === "found") return { kind: "found", payload: fetched };
  if (fetched.kind === "not_found") return { kind: "not_found" };
  return { kind: "restricted" };
}
