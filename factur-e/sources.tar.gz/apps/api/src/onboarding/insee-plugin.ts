import type { FastifyInstance } from "fastify";

import {
  inseeClientFromEnv,
  type InseeClient,
  type InseeLookupResult,
} from "@factur-e/insee-adapter";

declare module "fastify" {
  interface FastifyInstance {
    insee: InseeClient;
  }
}

/**
 * Mock client used when `INSEE_API_KEY` is missing (dev no-creds, tests).
 * Returns `unavailable` for any siren — callers see the same code path
 * they'd see in a true outage. Tests inject their own mock via
 * `buildApp({ inseeClient })`.
 */
export class StubInseeClient implements InseeClient {
  async lookupSiren(): Promise<InseeLookupResult> {
    await Promise.resolve();
    return { kind: "unavailable", cause: "network" };
  }
}

/**
 * Programmable client used in dev (no `INSEE_API_KEY`) and consumed by E2E
 * tests through `POST /__dev/insee/preset`. Callers pre-load fixtures keyed
 * by siren; absent siren → `unavailable` (same surface as Stub).
 */
export class PresetInseeClient implements InseeClient {
  private readonly fixtures = new Map<string, InseeLookupResult>();

  setPreset(siren: string, result: InseeLookupResult): void {
    this.fixtures.set(siren, result);
  }

  reset(): void {
    this.fixtures.clear();
  }

  async lookupSiren(siren: string): Promise<InseeLookupResult> {
    await Promise.resolve();
    return this.fixtures.get(siren) ?? { kind: "unavailable", cause: "network" };
  }
}

export function attachInseeClient(app: FastifyInstance, client: InseeClient): void {
  app.decorate("insee", client);
}

export function createDefaultInseeClient(): InseeClient {
  if (process.env.NODE_ENV === "test") {
    return new StubInseeClient();
  }
  // `INSEE_ADAPTER=preset` force le client programmable même si une clé
  // est exportée — pratique pour les E2E Playwright qui veulent injecter
  // des fixtures déterministes via POST /__dev/insee/preset sans dépendre
  // de la disponibilité réelle de l'API Sirene.
  if (process.env.INSEE_ADAPTER === "preset") {
    if (process.env.NODE_ENV === "production") {
      throw new Error("INSEE_ADAPTER=preset is forbidden in production.");
    }
    console.warn("[insee] INSEE_ADAPTER=preset — using PresetInseeClient (programmable).");
    return new PresetInseeClient();
  }
  const real = inseeClientFromEnv();
  if (real === undefined) {
    if (process.env.NODE_ENV === "production") {
      throw new Error("INSEE_API_KEY env var missing in production.");
    }
    // Dev no-creds: programmable client so E2E tests can inject fixtures
    // via POST /__dev/insee/preset.
    console.warn(
      "[insee] INSEE_API_KEY missing — falling back to PresetInseeClient (programmable via /__dev/insee/preset).",
    );
    return new PresetInseeClient();
  }
  return real;
}
