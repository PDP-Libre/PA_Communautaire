import type postgres from "postgres";

import type { InseeLookupResult } from "@factur-e/insee-adapter";

/**
 * `insee_cache` table TTL is 90 days (T-CL-01 migration). Stale rows are
 * served only on adapter `unavailable` (graceful degradation), never on
 * `not_found` / `restricted` — those are persisted but only re-served
 * within the TTL.
 *
 * We persist the *raw payload* + parsed `etablissements` so the JSONB
 * blob can be re-parsed without hitting the API again. Negative results
 * (`not_found`, `restricted`) are also cached as marker rows with empty
 * payload but a `kind` discriminator stored in the JSONB.
 */

interface CachedEntry {
  found: InseeLookupResult;
  fresh: boolean;
}

export async function lookupCache(sql: postgres.Sql, siren: string): Promise<CachedEntry | null> {
  const rows = await sql<
    { payload: Record<string, unknown>; establishments: unknown; expires_at: Date }[]
  >`
    SELECT payload, establishments, expires_at
    FROM insee_cache
    WHERE siren = ${siren}
  `;
  const row = rows[0];
  if (row === undefined) return null;

  const payload = row.payload;
  const kind = payload.kind;
  const fresh = row.expires_at.getTime() > Date.now();

  if (kind === "not_found") return { found: { kind: "not_found" }, fresh };
  if (kind === "restricted") return { found: { kind: "restricted" }, fresh };

  if (kind === "found" && payload.unite !== undefined && payload.raw !== undefined) {
    const result: InseeLookupResult = {
      kind: "found",
      unite: payload.unite as InseeLookupResult & { kind: "found" } extends {
        unite: infer U;
      }
        ? U
        : never,
      etablissements: Array.isArray(row.establishments) ? (row.establishments as never) : [],
      raw: payload.raw as Record<string, unknown>,
    };
    return { found: result, fresh };
  }

  return null;
}

export async function writeCache(
  sql: postgres.Sql,
  siren: string,
  result: InseeLookupResult,
): Promise<void> {
  if (result.kind === "unavailable") {
    // Don't pollute cache with transient failures.
    return;
  }

  const payload: Record<string, unknown> =
    result.kind === "found"
      ? { kind: "found", unite: result.unite, raw: result.raw }
      : { kind: result.kind };
  const establishments = result.kind === "found" ? result.etablissements : [];

  await sql`
    INSERT INTO insee_cache (siren, payload, establishments, fetched_at, expires_at)
    VALUES (
      ${siren},
      ${sql.json(payload as postgres.JSONValue)},
      ${sql.json(establishments as unknown as postgres.JSONValue)},
      NOW(),
      NOW() + INTERVAL '90 days'
    )
    ON CONFLICT (siren) DO UPDATE SET
      payload = EXCLUDED.payload,
      establishments = EXCLUDED.establishments,
      fetched_at = EXCLUDED.fetched_at,
      expires_at = EXCLUDED.expires_at
  `;
}
