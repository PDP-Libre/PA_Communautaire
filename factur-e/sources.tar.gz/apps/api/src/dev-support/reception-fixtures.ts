/**
 * Dev-support — helpers EXÉCUTABLES du corpus RÉCEPTION
 * (`@factur-e/factur-x-fixtures`), pendant des helpers émission
 * (`fixture-seller.ts`). Consommateurs autorisés (override ESLint
 * `no-restricted-imports`) : suites de test + route seed `__dev/*`.
 *
 * Le paquet fixtures ne peut PAS dériver le document lui-même (`formToModel`
 * vit dans apps/api) : c'est ICI que `kind:"emission"` devient un vrai
 * document via le PIPELINE RÉEL (Z2 — pas de XML figé), et que les snapshots
 * `IncomingInvoice` / rows `received_invoices` / séquences CDAR se câblent au
 * mock PA et à la BDD.
 */

import {
  getFixture,
  type IncomingCdarSequence,
  type ReceptionFixture,
} from "@factur-e/factur-x-fixtures";
import { generateCII, renderInvoicePdfFromModel } from "@factur-e/factur-x-builder";
import { FX_CONFORMANCE_LEVELS } from "@factur-e/factur-x-model";
import {
  type DirectorySearchResult,
  type DownloadInvoiceFileResult,
  type IncomingInvoice,
  mapSuperPDPStatusCode,
} from "@factur-e/pa-adapter";
import type postgres from "postgres";

import { insertCdarEvent, updateInvoiceStatusCurrent } from "../db/repos/cdar_events.js";
import { insertIncomingCdarEvent } from "../db/repos/incoming_cdar_events.js";
import {
  findReceivedInvoiceByPaInvoiceIdIn,
  insertReceivedInvoice,
  type ReceivedInvoiceRow,
} from "../db/repos/received_invoices.js";
import { formToModel } from "../services/invoice-form-to-model.js";

import { customerRowFromFixtureSeller } from "./fixture-seller.js";

/**
 * Attribution DÉTERMINISTE `received_invoices.pa_invoice_id_in` par fixture
 * (integer SuperPDP stringifié — 02-contrat-consommation.md §4.2). Stable :
 * le seed est idempotent sur la clé `(customer_id, pa_invoice_id_in)`.
 */
export const RECEPTION_PA_INVOICE_IDS: Readonly<Record<string, string>> = {
  "rx-380-base-facturx": "910001",
  "rx-380-cii-partiel": "910002",
  "rx-381-avoir-bg3": "910003",
  "rx-384-rectif-bg3": "910004",
  "rx-384-origine-introuvable": "910005",
  "rx-381-sans-bg3": "910006",
  "rx-380-sans-typecode": "910007",
};

export function paInvoiceIdForFixture(rx: ReceptionFixture): string {
  const id = RECEPTION_PA_INVOICE_IDS[rx.meta.id];
  if (id === undefined) {
    throw new Error(
      `Aucun pa_invoice_id_in déterministe pour "${rx.meta.id}" — compléter RECEPTION_PA_INVOICE_IDS.`,
    );
  }
  return id;
}

export interface IncomingFile {
  xmlString: string;
  facturxPdfBytes: Uint8Array;
}

/**
 * Dérive le document entrant d'une fixture ÉMISSION via le pipeline RÉEL
 * (`formToModel` → `generateCII` → assemblage Factur-X). Sert la
 * représentation indiquée par `source.download` (le caller choisit
 * xmlString vs facturxPdfBytes). Source VIVANTE : un changement de builder
 * casse les tests réception → détecteur, pas fragilité (Z2).
 */
export async function buildIncomingFileFromEmissionFixture(
  emissionFixtureId: string,
): Promise<IncomingFile> {
  const fx = getFixture(emissionFixtureId);
  const seller = customerRowFromFixtureSeller(fx.seller);
  const mapping = formToModel(fx.form, seller);
  if (!mapping.ok) {
    throw new Error(
      `buildIncomingFileFromEmissionFixture("${emissionFixtureId}") — formToModel KO : ${JSON.stringify(mapping.errors)}`,
    );
  }
  const xmlString = generateCII(mapping.value);
  const facturxPdfBytes = await renderInvoicePdfFromModel({
    invoice: mapping.value,
    xmlBytes: Buffer.from(xmlString, "utf8"),
    conformanceLevel: FX_CONFORMANCE_LEVELS.EXTENDED,
  });
  return { xmlString, facturxPdfBytes };
}

/**
 * Glue `MockPADriver.seedIncomingInvoices` — snapshot listing PA tel que le
 * worker `poll-received-invoices` le voit. Les champs `enInvoice` ABSENTS
 * RESTENT absents (cas fonctionnel R8 : expand partiel — ne JAMAIS inventer).
 */
export function incomingInvoiceFromFixture(rx: ReceptionFixture): IncomingInvoice {
  const incoming: IncomingInvoice = {
    paInvoiceId: paInvoiceIdForFixture(rx),
    direction: "in",
    receivedAt: rx.incoming.receivedAt,
  };
  if (rx.incoming.enInvoice !== undefined) incoming.enInvoice = { ...rx.incoming.enInvoice };
  if (rx.incoming.rawStatusCode !== undefined) incoming.rawStatusCode = rx.incoming.rawStatusCode;
  return incoming;
}

/**
 * Outcome `MockPADriver.searchSiren` cohérent avec l'oracle
 * `expect.row.supplierMatched` (02-contrat-consommation.md §5) : sinon
 * l'oracle « Fournisseur non identifié » ment. `found` → company minimale
 * (le worker ne lit que `kind`), `not_found` → SENDER_TIERS hors annuaire.
 */
export function searchSirenOutcomeForFixture(rx: ReceptionFixture): DirectorySearchResult {
  if (!rx.expect.row.supplierMatched) return { kind: "not_found" };
  const siren = rx.expect.row.sellerSiren;
  return {
    kind: "found_one_address",
    company: {
      number: siren,
      formal_name: rx.incoming.enInvoice?.sellerName ?? "",
      address: "",
      postcode: "",
      city: "",
      country: "FR",
    },
    address: { party_id: `0225:${siren}`, scheme_id: "0225", is_active: true, pa_name: null },
  };
}

/**
 * Document à servir par `downloadInvoiceFile` (mock PA) selon `source.download`
 * — sinon la fiche (parsedMetadata, /pdf, /xml) reste vide (R2). `kind:emission`
 * dérive le doc via le pipeline réel ; `kind:xml` sert le XML statique embarqué.
 */
export async function downloadResultForFixture(
  rx: ReceptionFixture,
): Promise<DownloadInvoiceFileResult> {
  if (rx.source.kind === "emission") {
    const file = await buildIncomingFileFromEmissionFixture(rx.source.emissionFixtureId);
    return rx.source.download === "facturx-pdf"
      ? { bytes: Buffer.from(file.facturxPdfBytes), contentType: "application/pdf" }
      : { bytes: Buffer.from(file.xmlString, "utf8"), contentType: "application/xml" };
  }
  return rx.source.download === "facturx-pdf"
    ? { bytes: Buffer.from(rx.source.xml, "utf8"), contentType: "application/pdf" }
    : { bytes: Buffer.from(rx.source.xml, "utf8"), contentType: "application/xml" };
}

/**
 * Seed DB-direct d'une row `received_invoices` depuis une fixture (migration
 * des factories `seedReceived()` inline — sites §1.3-1/3/5). N'utilise PAS le
 * worker : déterministe, miroir du seed émission. Pose l'event fr:204 « Prise
 * en charge » (source `polling`, `occurred_at = received_at`). Idempotent
 * (clé `(customer_id, pa_invoice_id_in)`) → si la row existe déjà, la relit.
 */
export async function seedReceivedRowFromFixture(
  sql: postgres.Sql,
  customerId: string,
  rx: ReceptionFixture,
): Promise<ReceivedInvoiceRow> {
  const paInvoiceId = paInvoiceIdForFixture(rx);
  const inserted = await insertReceivedInvoice(sql, {
    customer_id: customerId,
    pa_invoice_id_in: paInvoiceId,
    seller_siren: rx.expect.row.sellerSiren,
    seller_name_cached: rx.incoming.enInvoice?.sellerName ?? null,
    supplier_matched: rx.expect.row.supplierMatched,
    invoice_number_extracted: rx.expect.row.numberExtracted,
    // BT-3 cache liste (R5/Z4) : branche « colonne type_code » du corpus —
    // miroir DB-direct de l'extraction worker (`en.documentType`).
    type_code: rx.expect.row.typeCodeIfPersisted,
    issue_date: rx.incoming.enInvoice?.issueDate ?? null,
    due_date: rx.incoming.enInvoice?.dueDate ?? null,
    total_ttc_cents: rx.expect.row.totalTtcCents,
    currency: rx.incoming.enInvoice?.currency ?? "EUR",
    format: rx.source.download === "facturx-pdf" ? "facturx" : "cii",
    received_at: rx.incoming.receivedAt,
  });
  const row = inserted ?? (await findReceivedInvoiceByPaInvoiceIdIn(sql, customerId, paInvoiceId));
  if (row === undefined) {
    throw new Error(`seedReceivedRowFromFixture — row introuvable après INSERT pour ${rx.meta.id}`);
  }
  await insertIncomingCdarEvent(sql, {
    received_invoice_id: row.id,
    code: "fr:204",
    label: "Prise en charge",
    occurred_at: rx.incoming.receivedAt,
    source: "polling",
  });
  return row;
}

export interface ApplyCdarSequenceResult {
  /** `status_current` final de la facture émise après rejeu de la séquence. */
  statusCurrent: string;
  /** Nombre d'events effectivement insérés (idempotence ADR-009 D4). */
  insertedCount: number;
}

/**
 * Rejeu ORDONNÉ d'une `IncomingCdarSequence` sur une facture ÉMISE existante
 * (`cdar_events` + `invoices.status_current`). `occurred_at = t0 +
 * offsetMinutes` (déterminisme timeline). Convention motif V1
 * (02-contrat-consommation.md §4.4) : `reason.code` → colonne `reason`
 * (= `data.reason` SuperPDP) ; `reason.text` → `payload.data` (⚠ H-REASON-TEXT
 * GAP-T2-1 : à confirmer au smoke G1). Le `status_current` suit
 * `mapSuperPDPStatusCode` (table 43 codes).
 */
export async function applyCdarSequence(
  sql: postgres.Sql,
  invoiceId: string,
  seq: IncomingCdarSequence,
  t0: Date,
): Promise<ApplyCdarSequenceResult> {
  let insertedCount = 0;
  let lastStatus = "unknown";
  for (const ev of seq.events) {
    const occurredAt = new Date(t0.getTime() + ev.offsetMinutes * 60_000);
    const status = mapSuperPDPStatusCode(ev.statusCode).status;
    lastStatus = status;
    const res = await insertCdarEvent(sql, {
      invoice_id: invoiceId,
      code: ev.statusCode,
      label: ev.statusCode,
      occurred_at: occurredAt,
      payload: ev.reason?.text !== undefined ? { data: ev.reason.text } : {},
      reason: ev.reason?.code ?? null,
      source: "synthetic",
    });
    if (res.inserted) {
      insertedCount += 1;
      await updateInvoiceStatusCurrent(sql, invoiceId, status);
    }
  }
  return { statusCurrent: lastStatus, insertedCount };
}
