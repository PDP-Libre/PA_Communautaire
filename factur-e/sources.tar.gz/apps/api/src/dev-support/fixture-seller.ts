/**
 * Dev-support — adaptateur `FixtureSeller` (corpus `@factur-e/factur-x-fixtures`)
 * → `CustomerRow` (apps/api). UNE seule implémentation partagée par les deux
 * consommateurs autorisés (T-CL-FIXTURES-WIRING ZG-2) :
 *   - les suites de test (`formToModel`, convergence, GAP-1) ;
 *   - la route seed `__dev/invoice-drafts/seed` (Levier 2).
 *
 * Vit dans `src/dev-support/` (pas dans `tests/`) car `routes/dev/**` ne peut
 * pas importer depuis `tests/`. L'import du corpus y est autorisé par la règle
 * ESLint `no-restricted-imports` d'apps/api (override dev-support + routes/dev).
 *
 * Le corpus `FixtureSeller` est un sous-ensemble structurel de `CustomerRow` :
 * cet adaptateur complète les champs absents (id, couleurs, flags
 * réconciliation, timestamps) par des défauts neutres.
 */

import type { FixtureSeller } from "@factur-e/factur-x-fixtures";

import type { CustomerRow, VatRegime } from "../db/repos/customers.js";

/** Régime TVA par défaut si la valeur corpus n'est pas un `VatRegime` connu.
 *  Le corpus utilise "real" ; "franchise" (legacy) est mappé sur
 *  "franchise_293b". */
function toVatRegime(raw: string): VatRegime {
  switch (raw) {
    case "real":
    case "franchise_293b":
    case "reverse_charge_eu":
    case "simplified":
      return raw;
    case "franchise":
      return "franchise_293b";
    default:
      return "real";
  }
}

/** Construit un `CustomerRow` complet à partir d'un `FixtureSeller`. Les
 *  `overrides` permettent de fixer un `id` déterministe (ex. seed) ou
 *  d'ajuster un flag pour un test ciblé. */
export function customerRowFromFixtureSeller(
  seller: FixtureSeller,
  overrides: Partial<CustomerRow> = {},
): CustomerRow {
  const epoch = new Date("2026-01-01T00:00:00Z");
  return {
    id: "00000000-0000-4000-8000-0000000c0000",
    siren: seller.siren,
    legal_name: seller.legal_name,
    trading_name: seller.trading_name,
    address: seller.address,
    naf_code: seller.naf_code,
    rcs: seller.rcs,
    juridique_code: seller.juridique_code,
    capital_social: seller.capital_social,
    vat_number: seller.vat_number,
    vat_regime: toVatRegime(seller.vat_regime),
    vat_on_encashment: seller.vat_on_encashment,
    iban: seller.iban,
    bic: seller.bic,
    logo_s3_key: null,
    primary_color: "#316128",
    legal_mentions: seller.legal_mentions,
    directory_address: seller.directory_address,
    peppol_address_retry_count: 0,
    peppol_address_next_retry_at: null,
    default_invoice_values: seller.default_invoice_values,
    ui_mode_default: "basic",
    profile_unverified: false,
    siren_unverified: false,
    legal_name_unverified: false,
    address_unverified: false,
    vat_number_unverified: false,
    created_at: epoch,
    updated_at: epoch,
    deleted_at: null,
    ...overrides,
  };
}
