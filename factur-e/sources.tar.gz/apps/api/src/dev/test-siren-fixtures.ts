import type { InseeLookupResult } from "@factur-e/insee-adapter";

import type { CachedDirectoryAddress } from "../db/repos/directory_cache.js";

/**
 * Fixtures SIREN sandbox SuperPDP (T-CL-DEV-FAKE-SIREN-SEED sprint-06) —
 * Tricatel `000000001` + Burger Queen `000000002`. Ces SIREN de test
 * n'existent ni à l'INSEE Sirene ni dans l'annuaire public français, d'où
 * le besoin de pré-peupler les caches en dev/recette (`insee_cache` +
 * `directory_cache`) — sinon l'identité de l'émetteur (onboarding INSEE)
 * et du buyer (recherche annuaire à l'émission) échoue.
 *
 * Adresses Peppol = valeurs réelles du sandbox (compte Bruno délégué) :
 * primaire seule (les `_replyto` sont des adresses techniques de réponse,
 * exclues par convention `is_replyto=false` ; les variantes `_fe`/`_dirrh`
 * sont auxiliaires — on garde la primaire pour une résolution buyer
 * `found_one_address` sans sélecteur).
 *
 * Données entreprise fictives mais cohérentes — alignées entre INSEE et
 * annuaire pour la cohérence de la recette.
 */

export interface TestSirenFixture {
  siren: string;
  /** Résultat INSEE (`insee_cache`). */
  insee: Extract<InseeLookupResult, { kind: "found" }>;
  /** Company brute annuaire (`directory_cache.payload`). */
  directoryCompany: {
    number: string;
    formal_name: string;
    address: string;
    postcode: string;
    city: string;
    country: string;
  };
  /** Adresses Peppol (`directory_cache.addresses`, `is_replyto=false`). */
  directoryAddresses: CachedDirectoryAddress[];
}

function inseeFound(args: {
  siren: string;
  legalName: string;
  nafCode: string;
  juridiqueCode: string;
  nic: string;
  street: string;
  zip: string;
  city: string;
}): Extract<InseeLookupResult, { kind: "found" }> {
  const creationDate = "2015-01-01";
  return {
    kind: "found",
    unite: {
      siren: args.siren,
      legal_name: args.legalName,
      juridique_code: args.juridiqueCode,
      naf_code: args.nafCode,
      creation_date: creationDate,
      etat_administratif: "A",
    },
    etablissements: [
      {
        siret: `${args.siren}${args.nic}`,
        is_siege: true,
        etat_administratif: "A",
        creation_date: creationDate,
        address: { street: args.street, zip: args.zip, city: args.city, country_code: "FR" },
      },
    ],
    raw: {
      header: { statut: 200, message: "OK" },
      uniteLegale: {
        siren: args.siren,
        denominationUniteLegale: args.legalName,
        dateCreationUniteLegale: creationDate,
        statutDiffusionUniteLegale: "O",
        categorieJuridiqueUniteLegale: args.juridiqueCode,
        periodesUniteLegale: [
          {
            dateFin: null,
            dateDebut: creationDate,
            denominationUniteLegale: args.legalName,
            activitePrincipaleUniteLegale: args.nafCode,
            categorieJuridiqueUniteLegale: args.juridiqueCode,
            etatAdministratifUniteLegale: "A",
            nicSiegeUniteLegale: args.nic,
            nomenclatureActivitePrincipaleUniteLegale: "NAFRev2",
          },
        ],
      },
    },
  };
}

export const TEST_SIREN_FIXTURES: readonly TestSirenFixture[] = [
  {
    siren: "000000001",
    insee: inseeFound({
      siren: "000000001",
      legalName: "TRICATEL",
      nafCode: "10.89Z",
      juridiqueCode: "5710",
      nic: "00018",
      street: "1 RUE DE LA GASTRONOMIE",
      zip: "75001",
      city: "PARIS",
    }),
    directoryCompany: {
      number: "000000001",
      formal_name: "TRICATEL",
      address: "1 RUE DE LA GASTRONOMIE",
      postcode: "75001",
      city: "PARIS",
      country: "FR",
    },
    directoryAddresses: [
      { party_id: "0225:315143296_3685", scheme_id: "0225", is_active: true, pa_name: "SuperPDP" },
    ],
  },
  {
    siren: "000000002",
    insee: inseeFound({
      siren: "000000002",
      legalName: "BURGER QUEEN",
      nafCode: "56.10C",
      juridiqueCode: "5710",
      nic: "00027",
      street: "2 AVENUE DU FAST FOOD",
      zip: "69002",
      city: "LYON",
    }),
    directoryCompany: {
      number: "000000002",
      formal_name: "BURGER QUEEN",
      address: "2 AVENUE DU FAST FOOD",
      postcode: "69002",
      city: "LYON",
      country: "FR",
    },
    directoryAddresses: [
      { party_id: "0225:315143296_3686", scheme_id: "0225", is_active: true, pa_name: "SuperPDP" },
    ],
  },
];
