import postgres from "postgres";

import { writeCache } from "../onboarding/cache.js";
import { upsertDirectoryCache } from "../db/repos/directory_cache.js";
import { postgresUrlFromEnv } from "../server.js";
import { TEST_SIREN_FIXTURES } from "./test-siren-fixtures.js";

/**
 * `pnpm dev:seed-test-sirens` (T-CL-DEV-FAKE-SIREN-SEED sprint-06).
 *
 * Pré-peuple les caches `insee_cache` + `directory_cache` avec les SIREN
 * sandbox SuperPDP (Tricatel `000000001` + Burger Queen `000000002`) pour
 * que l'identification de l'émetteur (onboarding INSEE) et du buyer
 * (recherche annuaire à l'émission) fonctionne en dev/recette — ces SIREN
 * de test n'existent ni à l'INSEE ni dans l'annuaire public.
 *
 * Lève le workaround psql/pgAdmin manuel répété à chaque reset de BDD.
 * Idempotent (les deux repos font de l'upsert). Réservé au dev : refuse de
 * tourner si `NODE_ENV=production`.
 *
 * Périmètre V1 (absorbé) : seeding caches des 2 SIREN sandbox. Les autres
 * besoins T-CL-DEV-FAKE-SIREN-SEED (customers/users seedés, capital social,
 * etc.) sont traités ultérieurement.
 */

/**
 * TTL long (~100 ans) pour les entrées `directory_cache` des SIREN de test.
 * Ce sont des fixtures sandbox stables (vraies adresses Peppol du compte
 * délégué), pas un cache à rafraîchir. Avec le défaut 7 j, l'entrée expirait
 * → la recherche buyer retombait sur SuperPDP qui renvoie `not_found` (ces
 * SIREN ne sont pas dans l'annuaire public) → négatif caché 15 min → "Non
 * inscrit" réapparaissait au bout d'une semaine. Symptôme piégeux : il pousse
 * à un INSERT manuel d'un faux `party_id`, qui passe le check UI mais fait
 * *rejeter l'envoi* au pre-check Peppol de SuperPDP. On fige donc le seed pour
 * que les SIREN de test restent résolus tant que la BDD vit. Important en
 * distribution (PA_Communautaire/Forgejo) où l'instance tourne souvent plus
 * de 7 jours sans relancer `init.sh`.
 */
const SEED_TTL_SECONDS = 100 * 365 * 24 * 60 * 60; // ~100 ans

async function main(): Promise<void> {
  if (process.env.NODE_ENV === "production") {
    throw new Error("[seed-test-sirens] refus : ne pas exécuter en production.");
  }

  const url = postgresUrlFromEnv();
  const sql = postgres(url, { max: 2, onnotice: () => undefined });
  try {
    for (const fixture of TEST_SIREN_FIXTURES) {
      await writeCache(sql, fixture.siren, fixture.insee);
      await upsertDirectoryCache(sql, {
        siren: fixture.siren,
        payload: fixture.directoryCompany,
        addresses: fixture.directoryAddresses,
        ttlSeconds: SEED_TTL_SECONDS,
      });
      const peppol = fixture.directoryAddresses.map((a) => a.party_id).join(", ");
      // eslint-disable-next-line no-console
      console.log(
        `[seed-test-sirens] ${fixture.siren} ${fixture.insee.unite.legal_name} ` +
          `→ insee_cache + directory_cache (${peppol})`,
      );
    }
    // eslint-disable-next-line no-console
    console.log(`[seed-test-sirens] OK — ${String(TEST_SIREN_FIXTURES.length)} SIREN seedés.`);
  } finally {
    await sql.end();
  }
}

main().catch((err: unknown) => {
  console.error("[seed-test-sirens] échec :", err);
  process.exit(1);
});
