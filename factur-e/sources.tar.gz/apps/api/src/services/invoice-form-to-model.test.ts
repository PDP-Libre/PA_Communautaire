import { describe, expect, it } from "vitest";

import type { CustomerRow } from "../db/repos/customers.js";
import { IncotermCodeSchema } from "@factur-e/shared-schemas";
import type { InvoiceFormAdvanced, InvoiceFormBase } from "@factur-e/shared-schemas";

import {
  extractPayloadExtended,
  formToModel,
  validateBillingMode,
  validateMixedVATCategories,
} from "./invoice-form-to-model.js";

/**
 * Tests unitaires `formToModel` — sprint-04 T-CL-API-INVOICE.
 *
 * Couverture cible : ≥ 8 cas (1 par section × mode), focus sur :
 *   - structure du modèle EN 16931 produite
 *   - calcul des totaux + ventilation TVA agrégée
 *   - erreurs typées (EMPTY_LINES, IBAN manquant, cohérence TVA)
 *   - extension `payload_extended` jsonb pour mode avancé
 *
 * La validation XSD du XML CII généré ensuite est couverte par les
 * tests d'intégration HTTP (étape suivante).
 */

// ─────────────────────────────────────────────────────────────────────
// Fixtures
// ─────────────────────────────────────────────────────────────────────

function makeSeller(overrides: Partial<CustomerRow> = {}): CustomerRow {
  return {
    id: "00000000-0000-0000-0000-000000000001",
    siren: "123456789",
    legal_name: "Ma Boîte SAS",
    trading_name: "Ma Boîte",
    address: {
      line_one: "12 rue de la Paix",
      postcode: "75002",
      city: "Paris",
      country_code: "FR",
    },
    naf_code: "6201Z",
    rcs: "Paris B 123 456 789",
    juridique_code: "5710",
    capital_social: "10000.00",
    vat_number: "FR12345678901",
    vat_regime: "real",
    vat_on_encashment: false,
    iban: "FR7630006000011234567890189",
    bic: "AGRIFRPP",
    logo_s3_key: null,
    primary_color: "#316128",
    legal_mentions: "RCS Paris B 123 456 789 — TVA FR12345678901",
    directory_address: "0225:123456789_dgfip",
    peppol_address_retry_count: 0,
    peppol_address_next_retry_at: null,
    default_invoice_values: {},
    ui_mode_default: "basic",
    profile_unverified: false,
    siren_unverified: false,
    legal_name_unverified: false,
    address_unverified: false,
    vat_number_unverified: false,
    created_at: new Date("2026-01-01T00:00:00Z"),
    updated_at: new Date("2026-01-01T00:00:00Z"),
    deleted_at: null,
    ...overrides,
  };
}

function makeBaseForm(overrides: Partial<InvoiceFormBase> = {}): InvoiceFormBase {
  return {
    ui_mode: "base",
    document: {
      number: "F-2026-0001",
      issueDate: "2026-05-16",
      notes: null,
    },
    parties: {
      buyer: {
        siren: "987654321",
        legalName: "Client Corp",
        address: {
          lineOne: "5 avenue des Champs",
          lineTwo: null,
          postcode: "69000",
          city: "Lyon",
          countryCode: "FR",
        },
        electronicAddress: "0225:987654321_dgfip",
        electronicAddressScheme: "0225",
      },
    },
    lines: [
      {
        label: "Prestation de conseil",
        description: null,
        quantity: "1",
        unitCode: "HUR",
        unitPriceHt: "500.00",
        vatCategory: "S",
        vatRate: "20.00",
        totalHt: "500.00",
      },
    ],
    payment: {
      paymentTerms: { kind: "days", days: 30 },
      paymentMethodKind: "transfer",
      mentionsLegales: null,
    },
    ...overrides,
  };
}

function makeAdvancedForm(overrides: Partial<InvoiceFormAdvanced> = {}): InvoiceFormAdvanced {
  return {
    ui_mode: "advanced",
    document: {
      number: "F-2026-0042",
      issueDate: "2026-05-16",
      typeCode: "380",
      currency: "EUR",
      processingRule: "B2B",
      buyerOrderRef: "PO-2026-1234",
      sellerOrderRef: "202502-1",
      contractRef: "CTR-2025-456",
      projectRef: null,
      billingPeriod: null,
      notes: "Merci de votre confiance",
      privateComments: "Client habituel — paiement à 30j respecté",
      footerMentions: "TVA non applicable, art. 293 B du CGI",
      generalComments: "Acompte signé le 02/05/2026",
    },
    parties: {
      buyer: {
        siren: "987654321",
        legalName: "Client Corp",
        address: {
          lineOne: "5 avenue des Champs",
          lineTwo: null,
          postcode: "69000",
          city: "Lyon",
          countryCode: "FR",
        },
        electronicAddress: "0225:987654321_dgfip",
        electronicAddressScheme: "0225",
      },
      shipping: {
        name: "Client Corp — Entrepôt Sud",
        locationId: null,
        address: {
          lineOne: "Z.I. Sud",
          lineTwo: null,
          postcode: "13000",
          city: "Marseille",
          countryCode: "FR",
        },
      },
      deliveryDate: "2026-05-20",
      clientTaxRegime: "default",
      transporter: "DHL Express",
      trackingNumber: "DHL12345",
    },
    lines: [
      {
        label: "Ligne 1",
        description: null,
        quantity: "2",
        unitCode: "C62",
        unitPriceHt: "100.00",
        vatCategory: "S",
        vatRate: "20.00",
        totalHt: "200.00",
        longDescription: "Description longue produit",
        note: "Remarque ligne 1",
        basisQuantity: null,
      },
    ],
    documentLevelAllowance: null,
    payment: {
      paymentTerms: { kind: "days", days: 30 },
      paymentMethodKind: "transfer",
      paymentMeansCode: null,
      creditorReference: "FR76ZZZ123456",
      prepaidAmount: null,
      customPenalties: null,
      mentionsLegales: null,
    },
    ...overrides,
  };
}

// ─────────────────────────────────────────────────────────────────────
// Section Document — Base + Avancé
// ─────────────────────────────────────────────────────────────────────

describe("formToModel — Section Document", () => {
  it("mode base — produit invoiceNumber + issueDate + type 380 + currency EUR par défaut", () => {
    const seller = makeSeller();
    const form = makeBaseForm({
      document: { number: "F-2026-0001", issueDate: "2026-05-16", notes: null },
    });
    const r = formToModel(form, seller);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.value.exchangedDocument.invoiceNumber).toBe("F-2026-0001");
    expect(r.value.exchangedDocument.invoiceTypeCode).toBe("380");
    expect(r.value.exchangedDocument.issueDate).toEqual({
      value: "20260516",
      format: "102",
    });
    expect(r.value.tradeTransaction.tradeSettlement.invoiceCurrencyCode).toBe("EUR");
    // BR-FR-05 (sprint-05 SCHEMATRON) — sans note utilisateur, 3 IncludedNote
    // auto-générées PMT/PMD/AAB (mentions légales AFNOR XP Z12-012 §5.2).
    expect(r.value.exchangedDocument.includedNotes).toHaveLength(3);
    expect(r.value.exchangedDocument.includedNotes?.[0]?.subjectCode).toBe("PMT");
    expect(r.value.exchangedDocument.includedNotes?.[1]?.subjectCode).toBe("PMD");
    expect(r.value.exchangedDocument.includedNotes?.[2]?.subjectCode).toBe("AAB");
  });

  it("mode avancé — mappe BT-13 buyerOrderRef + BT-14 sellerOrderRef + BT-12 contractRef + générale comments → IncludedNotes", () => {
    const seller = makeSeller();
    const form = makeAdvancedForm();
    const r = formToModel(form, seller);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.value.tradeTransaction.tradeAgreement.buyerOrderReference).toBe("PO-2026-1234");
    expect(r.value.tradeTransaction.tradeAgreement.sellerOrderReference).toBe("202502-1");
    expect(r.value.tradeTransaction.tradeAgreement.contractReference).toBe("CTR-2025-456");
    // Notes publiques + generalComments + footerMentions (REG, finding K2) +
    // 3 auto PMT/PMD/AAB (BR-FR-05) → 6 entrées BG-1, dans l'ordre : user notes
    // simple, generalComments, footerMentions REG, PMT, PMD, AAB.
    expect(r.value.exchangedDocument.includedNotes).toHaveLength(6);
    expect(r.value.exchangedDocument.includedNotes?.[0]?.content).toBe("Merci de votre confiance");
    expect(r.value.exchangedDocument.includedNotes?.[1]?.content).toBe(
      "Acompte signé le 02/05/2026",
    );
    expect(r.value.exchangedDocument.includedNotes?.[2]?.content).toBe(
      "TVA non applicable, art. 293 B du CGI",
    );
    expect(r.value.exchangedDocument.includedNotes?.[2]?.subjectCode).toBe("REG");
    expect(r.value.exchangedDocument.includedNotes?.[3]?.subjectCode).toBe("PMT");
    expect(r.value.exchangedDocument.includedNotes?.[4]?.subjectCode).toBe("PMD");
    expect(r.value.exchangedDocument.includedNotes?.[5]?.subjectCode).toBe("AAB");
  });
});

// ─────────────────────────────────────────────────────────────────────
// Section Parties — Base + Avancé
// ─────────────────────────────────────────────────────────────────────

describe("formToModel — Section Parties", () => {
  it("mode base — seller TradeParty depuis customer + buyer depuis form", () => {
    const seller = makeSeller();
    const form = makeBaseForm();
    const r = formToModel(form, seller);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    const ta = r.value.tradeTransaction.tradeAgreement;
    expect(ta.sellerTradeParty.name).toBe("Ma Boîte SAS");
    expect(ta.sellerTradeParty.legalRegistrationID?.value).toBe("123456789");
    expect(ta.sellerTradeParty.legalRegistrationID?.schemeID).toBe("0002");
    expect(ta.sellerTradeParty.vatID?.value).toBe("FR12345678901");
    expect(ta.buyerTradeParty.name).toBe("Client Corp");
    expect(ta.buyerTradeParty.legalRegistrationID?.value).toBe("987654321");
    expect(ta.buyerTradeParty.electronicAddress?.value).toBe("0225:987654321_dgfip");
    // Sprint-05 SCHEMATRON patch (c) — pas de delivery info en mode base mais
    // R008 (Peppol) interdit `<ApplicableHeaderTradeDelivery/>` vide. Le
    // helper `buildTradeDelivery` injecte donc `actualDeliveryDate = issueDate`
    // par défaut (livraison réputée à émission). Aucune adresse delivery
    // n'est posée en mode base.
    expect(r.value.tradeTransaction.tradeDelivery.deliveryAddress).toBeUndefined();
    expect(r.value.tradeTransaction.tradeDelivery.actualDeliveryDate).toEqual({
      value: "20260516",
      format: "102",
    });
  });

  it("mode avancé — BG-13 shipping + BT-72 deliveryDate posés dans tradeDelivery", () => {
    const seller = makeSeller();
    const form = makeAdvancedForm();
    const r = formToModel(form, seller);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    const td = r.value.tradeTransaction.tradeDelivery;
    expect(td.shipToPartyName).toBe("Client Corp — Entrepôt Sud");
    expect(td.deliveryAddress?.cityName).toBe("Marseille");
    expect(td.deliveryAddress?.countryCode).toBe("FR");
    expect(td.actualDeliveryDate).toEqual({ value: "20260520", format: "102" });
  });
});

// ─────────────────────────────────────────────────────────────────────
// Section Lignes — Base + Avancé + Breakdown TVA
// ─────────────────────────────────────────────────────────────────────

describe("formToModel — Section Lignes", () => {
  it("mode base multi-lignes TVA mixte — vatBreakdown agrégé par (cat, rate)", () => {
    const seller = makeSeller();
    const form = makeBaseForm({
      lines: [
        {
          label: "L1",
          description: null,
          quantity: "1",
          unitCode: "C62",
          unitPriceHt: "200.00",
          vatCategory: "S",
          vatRate: "20.00",
          totalHt: "200.00",
        },
        {
          label: "L2",
          description: null,
          quantity: "1",
          unitCode: "C62",
          unitPriceHt: "300.00",
          vatCategory: "S",
          vatRate: "20.00",
          totalHt: "300.00",
        },
        {
          label: "L3",
          description: null,
          quantity: "1",
          unitCode: "C62",
          unitPriceHt: "100.00",
          vatCategory: "S",
          vatRate: "5.50",
          totalHt: "100.00",
        },
      ],
    });
    const r = formToModel(form, seller);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    const vb = r.value.tradeTransaction.tradeSettlement.vatBreakdowns;
    expect(vb).toHaveLength(2);
    // 2 buckets : (S, 20) = 500 HT / 100 VAT, (S, 5.5) = 100 HT / 5.5 VAT
    const std20 = vb.find((b) => b.categoryCode === "S" && b.ratePercent === 20);
    const std5 = vb.find((b) => b.categoryCode === "S" && b.ratePercent === 5.5);
    expect(std20?.taxBasisAmount).toBe(500);
    expect(std20?.calculatedAmount).toBe(100);
    expect(std5?.taxBasisAmount).toBe(100);
    expect(std5?.calculatedAmount).toBe(5.5);
    const ms = r.value.tradeTransaction.tradeSettlement.monetarySummation;
    expect(ms.lineTotalAmount).toBe(600);
    expect(ms.taxBasisTotalAmount).toBe(600);
    expect(ms.vatTotalAmount?.value).toBe(105.5);
    expect(ms.grandTotalAmount).toBe(705.5);
    expect(ms.duePayableAmount).toBe(705.5);
  });

  it("mode avancé — BG-20 documentLevelAllowance déduit du taxBasis + ajoute son montant au breakdown TVA", () => {
    const seller = makeSeller();
    const form = makeAdvancedForm({
      lines: [
        {
          label: "L1",
          description: null,
          quantity: "1",
          unitCode: "C62",
          unitPriceHt: "1000.00",
          vatCategory: "S",
          vatRate: "20.00",
          totalHt: "1000.00",
          longDescription: null,
          note: null,
          basisQuantity: null,
        },
      ],
      documentLevelAllowance: {
        chargeIndicator: false,
        // Finding I — mode % : montant non figé (sentinelle "0"), dérivé au
        // build depuis percent × base HT catégorie. Auparavant le test
        // masquait le bug en passant `amount:"100.00"` en dur.
        amount: "0",
        baseAmount: null,
        percent: "10.00",
        reason: "Remise commerciale 10 %",
        reasonCode: "95",
        vatCategory: "S",
        vatRate: "20.00",
      },
    });
    const r = formToModel(form, seller);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    const ms = r.value.tradeTransaction.tradeSettlement.monetarySummation;
    expect(ms.lineTotalAmount).toBe(1000);
    expect(ms.allowanceTotalAmount).toBe(100);
    expect(ms.taxBasisTotalAmount).toBe(900);
    // VAT recomputé sur la base nette : 900 × 20 % = 180
    expect(ms.vatTotalAmount?.value).toBe(180);
    expect(ms.grandTotalAmount).toBe(1080);
    const ac = r.value.tradeTransaction.tradeSettlement.documentAllowances?.[0];
    // ActualAmount = round2(1000 × 10 %) = 100, dérivé (et non figé).
    expect(ac?.actualAmount).toBe(100);
    // BT-93 BasisAmount présent (cohérence ActualAmount/BasisAmount/Percent).
    expect(ac?.basisAmount).toBe(1000);
    expect(ac?.calculationPercent).toBe(10);
  });

  it("finding I — remise globale % flux modal (sans vatRate) : taux dérivé du taux ligne uniforme → TVA déduite", () => {
    const seller = makeSeller();
    const form = makeAdvancedForm({
      lines: [
        {
          label: "L1",
          description: null,
          quantity: "1",
          unitCode: "C62",
          unitPriceHt: "1000.00",
          vatCategory: "S",
          vatRate: "20.00",
          totalHt: "1000.00",
          longDescription: null,
          note: null,
          basisQuantity: null,
        },
      ],
      // Reproduit exactement ce qu'envoie `GlobalAllowanceModal` : amount "0"
      // sentinelle, percent saisi, PAS de vatRate (le modal ne le connaît pas).
      documentLevelAllowance: {
        chargeIndicator: false,
        amount: "0",
        baseAmount: null,
        percent: "10.00",
        reason: "Remise commerciale",
        reasonCode: null,
        vatCategory: "S",
        vatRate: null,
      },
    });
    const r = formToModel(form, seller);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    const ms = r.value.tradeTransaction.tradeSettlement.monetarySummation;
    expect(ms.taxBasisTotalAmount).toBe(900);
    // Taux 20 dérivé des lignes → TVA déduite dans le bon bucket : 900 × 20 %.
    expect(ms.vatTotalAmount?.value).toBe(180);
    expect(ms.grandTotalAmount).toBe(1080);
    const ac = r.value.tradeTransaction.tradeSettlement.documentAllowances?.[0];
    expect(ac?.actualAmount).toBe(100);
    expect(ac?.basisAmount).toBe(1000);
    expect(ac?.taxPercent).toBe(20);
  });

  it("finding J — shippingCostHt → BG-21 charge document (FC) ajoutée au taxBasis + TVA + total", () => {
    const seller = makeSeller();
    const form = makeAdvancedForm({
      lines: [
        {
          label: "L1",
          description: null,
          quantity: "1",
          unitCode: "C62",
          unitPriceHt: "1000.00",
          vatCategory: "S",
          vatRate: "20.00",
          totalHt: "1000.00",
          longDescription: null,
          note: null,
          basisQuantity: null,
        },
      ],
      documentLevelAllowance: null,
      shippingCostHt: "50.00",
      shippingCostVatCategory: "S",
      shippingCostVatRate: "20.00",
    });
    const r = formToModel(form, seller);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    const ts = r.value.tradeTransaction.tradeSettlement;
    const ms = ts.monetarySummation;
    expect(ms.lineTotalAmount).toBe(1000);
    // BT-108 — la charge frais de port s'ajoute à la base imposable.
    expect(ms.chargeTotalAmount).toBe(50);
    expect(ms.taxBasisTotalAmount).toBe(1050);
    // TVA recalculée sur 1050 × 20 % = 210.
    expect(ms.vatTotalAmount?.value).toBe(210);
    expect(ms.grandTotalAmount).toBe(1260);
    // BG-21 charge sérialisable : isCharge + reasonCode FC + CategoryTradeTax.
    const charge = ts.documentCharges?.[0];
    expect(charge?.isCharge).toBe(true);
    expect(charge?.actualAmount).toBe(50);
    expect(charge?.reasonCode).toBe("FC");
    expect(charge?.reason).toBe("Frais de port");
    expect(charge?.taxCategoryCode).toBe("S");
    expect(charge?.taxPercent).toBe(20);
  });

  it("finding J — remise globale + frais de port coexistent (BT-107 + BT-108 + équilibre)", () => {
    const seller = makeSeller();
    const form = makeAdvancedForm({
      lines: [
        {
          label: "L1",
          description: null,
          quantity: "1",
          unitCode: "C62",
          unitPriceHt: "1000.00",
          vatCategory: "S",
          vatRate: "20.00",
          totalHt: "1000.00",
          longDescription: null,
          note: null,
          basisQuantity: null,
        },
      ],
      documentLevelAllowance: {
        chargeIndicator: false,
        amount: "100.00",
        baseAmount: null,
        percent: null,
        reason: "Remise commerciale",
        reasonCode: "95",
        vatCategory: "S",
        vatRate: "20.00",
      },
      shippingCostHt: "50.00",
      shippingCostVatCategory: "S",
      shippingCostVatRate: "20.00",
    });
    const r = formToModel(form, seller);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    const ts = r.value.tradeTransaction.tradeSettlement;
    const ms = ts.monetarySummation;
    expect(ms.allowanceTotalAmount).toBe(100); // BT-107 remise globale
    expect(ms.chargeTotalAmount).toBe(50); // BT-108 frais de port
    // base = 1000 − 100 + 50 = 950 ; TVA 950 × 20 % = 190 ; TTC = 1140.
    expect(ms.taxBasisTotalAmount).toBe(950);
    expect(ms.vatTotalAmount?.value).toBe(190);
    expect(ms.grandTotalAmount).toBe(1140);
    // Les deux nodes coexistent (remise ET charge document).
    expect(ts.documentAllowances).toHaveLength(1);
    expect(ts.documentCharges).toHaveLength(1);
  });

  it("finding K1 — IncotermCodeSchema : 13 codes FR acceptés, hors whitelist rejeté", () => {
    for (const code of ["EXW", "FCA", "DDP", "CIF", "1", "2"]) {
      expect(IncotermCodeSchema.safeParse(code).success).toBe(true);
    }
    for (const bad of ["ZZZ", "exw", "", "DDU"]) {
      expect(IncotermCodeSchema.safeParse(bad).success).toBe(false);
    }
  });

  it("finding K1 — incoterm EXW → tradeAgreement.incoterm='EXW' ; null → absent", () => {
    const seller = makeSeller();
    const line = {
      label: "L1",
      description: null,
      quantity: "1",
      unitCode: "C62",
      unitPriceHt: "1000.00",
      vatCategory: "S" as const,
      vatRate: "20.00",
      totalHt: "1000.00",
      longDescription: null,
      note: null,
      basisQuantity: null,
    };
    const withInc = formToModel(makeAdvancedForm({ lines: [line], incoterm: "EXW" }), seller);
    expect(withInc.ok).toBe(true);
    if (!withInc.ok) return;
    expect(withInc.value.tradeTransaction.tradeAgreement.incoterm).toBe("EXW");

    const withoutInc = formToModel(makeAdvancedForm({ lines: [line], incoterm: null }), seller);
    expect(withoutInc.ok).toBe(true);
    if (!withoutInc.ok) return;
    expect(withoutInc.value.tradeTransaction.tradeAgreement.incoterm).toBeUndefined();
  });

  it("finding K2 — 4 zones notes : notes/generalComments BG-1 + footerMentions REG + LME auto + privateComments interne", () => {
    const seller = makeSeller();
    const form = makeAdvancedForm({
      document: {
        number: "F-2026-0042",
        issueDate: "2026-05-16",
        typeCode: "380",
        currency: "EUR",
        processingRule: "B2B",
        buyerOrderRef: null,
        sellerOrderRef: null,
        contractRef: null,
        projectRef: null,
        billingPeriod: null,
        notes: "Note publique client",
        privateComments: "Notes internes confidentielles",
        footerMentions: "Mention légale de pied",
        generalComments: "Commentaire général en-tête",
      },
      lines: [
        {
          label: "L1",
          description: null,
          quantity: "1",
          unitCode: "C62",
          unitPriceHt: "1000.00",
          vatCategory: "S",
          vatRate: "20.00",
          totalHt: "1000.00",
          longDescription: null,
          note: null,
          basisQuantity: null,
        },
      ],
    });
    const r = formToModel(form, seller);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    const notes = r.value.exchangedDocument.includedNotes ?? [];
    // notes + generalComments → BG-1 sans qualifier.
    expect(notes).toContainEqual({ content: "Note publique client" });
    expect(notes).toContainEqual({ content: "Commentaire général en-tête" });
    // footerMentions → BG-1 qualifier REG (Option B1).
    expect(notes).toContainEqual({ content: "Mention légale de pied", subjectCode: "REG" });
    // 3 mentions légales LME auto préservées (régression sprint-04).
    const codes = notes.map((n) => n.subjectCode).filter(Boolean);
    expect(codes).toEqual(expect.arrayContaining(["PMT", "PMD", "AAB"]));
    // privateComments JAMAIS dans le XML (Option A), mais dans payload_extended.
    expect(notes.some((n) => n.content.includes("internes"))).toBe(false);
    const payload = extractPayloadExtended(form);
    expect(payload.privateComments).toBe("Notes internes confidentielles");
    // footerMentions conservé aussi pour le rendu PDF (B1 = XML REG + PDF).
    expect(payload.footerMentions).toBe("Mention légale de pied");
  });

  it("finding J — shippingCostHt absent/0 → pas de charge frais de port", () => {
    const seller = makeSeller();
    const base = {
      label: "L1",
      description: null,
      quantity: "1",
      unitCode: "C62",
      unitPriceHt: "1000.00",
      vatCategory: "S" as const,
      vatRate: "20.00",
      totalHt: "1000.00",
      longDescription: null,
      note: null,
      basisQuantity: null,
    };
    for (const shippingCostHt of [null, "0.00"]) {
      const r = formToModel(
        makeAdvancedForm({ lines: [base], documentLevelAllowance: null, shippingCostHt }),
        seller,
      );
      expect(r.ok).toBe(true);
      if (!r.ok) return;
      const ts = r.value.tradeTransaction.tradeSettlement;
      expect(ts.documentCharges).toBeUndefined();
      expect(ts.monetarySummation.taxBasisTotalAmount).toBe(1000);
    }
  });

  it("mode avancé — ligne avec longDescription + note + basisQuantity → BT-154 + BT-127 + BT-149 mappés", () => {
    const seller = makeSeller();
    const form = makeAdvancedForm({
      lines: [
        {
          label: "Forfait mensuel",
          description: null,
          quantity: "12",
          unitCode: "MON",
          unitPriceHt: "100.00",
          vatCategory: "S",
          vatRate: "20.00",
          totalHt: "1200.00",
          longDescription: "Abonnement annuel mensualisé sur 12 mois",
          note: "Facture annuelle — détail mensuel pour comptabilité client",
          basisQuantity: "1",
        },
      ],
    });
    const r = formToModel(form, seller);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    const li = r.value.tradeTransaction.lineItems[0];
    expect(li?.product.description).toBe("Abonnement annuel mensualisé sur 12 mois");
    expect(li?.note).toBe("Facture annuelle — détail mensuel pour comptabilité client");
    expect(li?.tradeAgreement.basisQuantity).toBe(1);
    expect(li?.tradeAgreement.basisQuantityUnitCode).toBe("MON");
  });
});

// ─────────────────────────────────────────────────────────────────────
// Section Règlement — Base + Avancé
// ─────────────────────────────────────────────────────────────────────

describe("formToModel — Section Règlement", () => {
  it("mode base — paymentTerms days N → BT-9 dueDate = issueDate + N jours", () => {
    const seller = makeSeller();
    const form = makeBaseForm({
      document: { number: "F-2026-0001", issueDate: "2026-05-16", notes: null },
      payment: {
        paymentTerms: { kind: "days", days: 30 },
        paymentMethodKind: "transfer",
        mentionsLegales: null,
      },
    });
    const r = formToModel(form, seller);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    // 2026-05-16 + 30j = 2026-06-15
    expect(r.value.tradeTransaction.tradeSettlement.dueDate).toEqual({
      value: "20260615",
      format: "102",
    });
    expect(r.value.tradeTransaction.tradeSettlement.paymentTermsDescription).toBe(
      "Règlement à 30 jours",
    );
    // BG-16 paymentMeans : transfer → 58 SEPA credit transfer + payeeFinancialAccount IBAN customer
    const pm = r.value.tradeTransaction.tradeSettlement.paymentMeans?.[0];
    expect(pm?.typeCode).toBe("58");
    expect(pm?.payeeFinancialAccounts?.[0]?.accountID.value).toBe("FR7630006000011234567890189");
    expect(pm?.payeeFinancialAccounts?.[0]?.financialInstitutionID?.value).toBe("AGRIFRPP");
  });

  it("mode avancé — BT-90 creditorReference + paymentMeansCode override → BG-16 typeCode reflète l'override", () => {
    const seller = makeSeller();
    const form = makeAdvancedForm({
      payment: {
        paymentTerms: { kind: "fixedDate", dueDate: "2026-07-31" },
        paymentMethodKind: "transfer",
        paymentMeansCode: "30", // override SEPA credit transfer générique vs 58 SEPA specific
        creditorReference: "FR76ZZZ123456",
        prepaidAmount: "100.00",
        customPenalties: null,
        mentionsLegales: null,
      },
    });
    const r = formToModel(form, seller);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    const ts = r.value.tradeTransaction.tradeSettlement;
    expect(ts.paymentMeans?.[0]?.typeCode).toBe("30");
    expect(ts.creditorReferenceID?.value).toBe("FR76ZZZ123456");
    expect(ts.dueDate).toEqual({ value: "20260731", format: "102" });
    // BT-113 paidAmount → duePayable = grand - prepaid
    const ms = ts.monetarySummation;
    expect(ms.paidAmount).toBe(100);
    expect(ms.grandTotalAmount).toBe(240); // 200 HT + 20% TVA = 240
    expect(ms.duePayableAmount).toBe(140);
  });
});

// ─────────────────────────────────────────────────────────────────────
// Erreurs typées
// ─────────────────────────────────────────────────────────────────────

describe("formToModel — Erreurs typées", () => {
  it("EMPTY_LINES si form.lines vide", () => {
    const seller = makeSeller();
    const form = { ...makeBaseForm(), lines: [] } as InvoiceFormBase;
    const r = formToModel(form, seller);
    expect(r.ok).toBe(false);
    if (r.ok) return;
    expect(r.errors[0]?.code).toBe("EMPTY_LINES");
  });

  it("INVALID_PAYMENT_METHOD_MISSING_IBAN si transfer + customer sans IBAN", () => {
    const seller = makeSeller({ iban: null });
    const form = makeBaseForm({
      payment: {
        paymentTerms: { kind: "days", days: 30 },
        paymentMethodKind: "transfer",
        mentionsLegales: null,
      },
    });
    const r = formToModel(form, seller);
    expect(r.ok).toBe(false);
    if (r.ok) return;
    expect(r.errors[0]?.code).toBe("INVALID_PAYMENT_METHOD_MISSING_IBAN");
    expect(r.errors[0]?.field).toBe("iban");
  });

  it("paymentMethodKind=cash + customer sans IBAN → OK (IBAN non requis pour espèces)", () => {
    const seller = makeSeller({ iban: null, bic: null });
    const form = makeBaseForm({
      payment: {
        paymentTerms: { kind: "onSight" },
        paymentMethodKind: "cash",
        mentionsLegales: null,
      },
    });
    const r = formToModel(form, seller);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    const pm = r.value.tradeTransaction.tradeSettlement.paymentMeans?.[0];
    expect(pm?.typeCode).toBe("10"); // CASH
    expect(pm?.payeeFinancialAccounts).toBeUndefined();
  });
});

// ─────────────────────────────────────────────────────────────────────
// SCHEMATRON NC-17 (sprint-05) — 4 patches BR-S-02 BT-31 + unitCode
// UN/CEFACT Rec 20 + PEPPOL-EN16931-R008 + BR-FR-05 IncludedNote
// ─────────────────────────────────────────────────────────────────────

describe("formToModel — SCHEMATRON NC-17 (a) BR-S-02 BT-31 Seller VAT", () => {
  it("seller.vat_number présent → vatID injecté dans SellerTradeParty (schemeID='VA')", () => {
    const seller = makeSeller({ vat_number: "FR12821456789" });
    const r = formToModel(makeBaseForm(), seller);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    const sp = r.value.tradeTransaction.tradeAgreement.sellerTradeParty;
    expect(sp.vatID).toEqual({ value: "FR12821456789", schemeID: "VA" });
  });

  it("seller.vat_number NULL → vatID absent, pas de crash (mode dégradé ADR-009 D1)", () => {
    const seller = makeSeller({ vat_number: null });
    const r = formToModel(makeBaseForm(), seller);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.value.tradeTransaction.tradeAgreement.sellerTradeParty.vatID).toBeUndefined();
  });

  it("seller.vat_number string vide → vatID absent (traité comme NULL)", () => {
    const seller = makeSeller({ vat_number: "" });
    const r = formToModel(makeBaseForm(), seller);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.value.tradeTransaction.tradeAgreement.sellerTradeParty.vatID).toBeUndefined();
  });
});

describe("formToModel — SCHEMATRON NC-17 (b) unitCode UN/CEFACT Rec 20", () => {
  const cases: readonly { input: string; expected: string }[] = [
    // Comptables
    { input: "pièce", expected: "C62" },
    { input: "PIÈCE", expected: "C62" },
    { input: "pcs", expected: "C62" },
    { input: "unité", expected: "C62" },
    // Service / forfait
    { input: "forfait", expected: "C62" },
    // Temps
    { input: "jour", expected: "DAY" },
    { input: "mois", expected: "MON" },
    { input: "an", expected: "ANN" },
    { input: "année", expected: "ANN" },
    { input: "heure", expected: "HUR" },
    { input: "minute", expected: "MIN" },
    // Masse
    { input: "kg", expected: "KGM" },
    { input: "gramme", expected: "GRM" },
    { input: "tonne", expected: "TNE" },
    // Distance / surface / volume
    { input: "mètre", expected: "MTR" },
    { input: "km", expected: "KMT" },
    { input: "m²", expected: "MTK" },
    { input: "m³", expected: "MTQ" },
    { input: "litre", expected: "LTR" },
    { input: "ml", expected: "MLT" },
    // Packaging Rec 21
    { input: "colis", expected: "XPP" },
    { input: "boîte", expected: "XBX" },
    { input: "carton", expected: "XBX" },
    // Codes UNECE déjà valides (passthrough après upper-case)
    { input: "C62", expected: "C62" },
    { input: "KGM", expected: "KGM" },
    { input: "hur", expected: "HUR" },
    // Fallback
    { input: "truc bizarre inconnu", expected: "C62" },
  ];

  for (const { input, expected } of cases) {
    it(`unitCode "${input}" → ${expected}`, () => {
      const seller = makeSeller();
      const form = makeBaseForm({
        lines: [
          {
            label: "L1",
            description: null,
            quantity: "1",
            unitCode: input,
            unitPriceHt: "100.00",
            vatCategory: "S",
            vatRate: "20.00",
            totalHt: "100.00",
          },
        ],
      });
      const r = formToModel(form, seller);
      expect(r.ok).toBe(true);
      if (!r.ok) return;
      expect(r.value.tradeTransaction.lineItems[0]?.tradeDelivery.unitCode).toBe(expected);
    });
  }
});

describe("formToModel — SCHEMATRON NC-17 (c) PEPPOL-EN16931-R008 HeaderTradeDelivery", () => {
  it("mode base sans delivery → actualDeliveryDate placeholder = issueDate (R008 satisfait)", () => {
    const seller = makeSeller();
    const form = makeBaseForm({
      document: { number: "F-2026-0001", issueDate: "2026-05-16", notes: null },
    });
    const r = formToModel(form, seller);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    const td = r.value.tradeTransaction.tradeDelivery;
    expect(td.actualDeliveryDate).toEqual({ value: "20260516", format: "102" });
    expect(td.deliveryAddress).toBeUndefined();
    expect(td.shipToPartyName).toBeUndefined();
    expect(td.shipToPartyID).toBeUndefined();
  });

  it("mode avancé sans shipping ni deliveryDate → placeholder actualDeliveryDate injecté", () => {
    const seller = makeSeller();
    // Build advanced form sans shipping ni deliveryDate.
    const baseAdv = makeAdvancedForm();
    const form: InvoiceFormAdvanced = {
      ...baseAdv,
      parties: { ...baseAdv.parties, shipping: null, deliveryDate: null },
    };
    const r = formToModel(form, seller);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    const td = r.value.tradeTransaction.tradeDelivery;
    // issueDate fixture par défaut makeAdvancedForm = 2026-05-16
    expect(td.actualDeliveryDate?.value).toBe("20260516");
    expect(td.deliveryAddress).toBeUndefined();
    expect(td.shipToPartyName).toBeUndefined();
  });

  it("mode avancé avec deliveryDate user → pas de placeholder, date user préservée", () => {
    const seller = makeSeller();
    const baseAdv = makeAdvancedForm();
    const form: InvoiceFormAdvanced = {
      ...baseAdv,
      parties: { ...baseAdv.parties, shipping: null, deliveryDate: "2026-06-15" },
    };
    const r = formToModel(form, seller);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.value.tradeTransaction.tradeDelivery.actualDeliveryDate).toEqual({
      value: "20260615",
      format: "102",
    });
  });

  it("mode avancé avec shipping (sans deliveryDate) → shipTo posé, pas de placeholder date", () => {
    const seller = makeSeller();
    const baseAdv = makeAdvancedForm();
    const form: InvoiceFormAdvanced = {
      ...baseAdv,
      parties: { ...baseAdv.parties, deliveryDate: null },
    };
    const r = formToModel(form, seller);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    const td = r.value.tradeTransaction.tradeDelivery;
    expect(td.shipToPartyName).toBe("Client Corp — Entrepôt Sud");
    expect(td.deliveryAddress).toBeDefined();
    // Pas de placeholder injecté car shipping est rempli.
    expect(td.actualDeliveryDate).toBeUndefined();
  });
});

describe("formToModel — SCHEMATRON NC-17 (d) BR-FR-05 IncludedNote PMT/PMD/AAB", () => {
  it("3 IncludedNote auto-générées avec exemples AFNOR Annexe B par défaut", () => {
    const seller = makeSeller(); // default_invoice_values: {}
    const r = formToModel(makeBaseForm(), seller);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    const notes = r.value.exchangedDocument.includedNotes;
    expect(notes).toHaveLength(3);
    expect(notes?.[0]).toEqual({
      content:
        "Indemnité forfaitaire pour frais de recouvrement en cas de retard de paiement : 40 €.",
      subjectCode: "PMT",
    });
    expect(notes?.[1]?.subjectCode).toBe("PMD");
    expect(notes?.[1]?.content).toMatch(/trois fois le taux d'intérêt légal/);
    expect(notes?.[2]?.subjectCode).toBe("AAB");
    expect(notes?.[2]?.content).toMatch(/escompte/);
  });

  it("override PMD via customers.default_invoice_values.late_penalties_mention", () => {
    const seller = makeSeller({
      default_invoice_values: {
        late_penalties_mention: "Pénalité 12 % annuel + indemnité 40 €.",
      },
    });
    const r = formToModel(makeBaseForm(), seller);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    const pmd = r.value.exchangedDocument.includedNotes?.[1];
    expect(pmd?.subjectCode).toBe("PMD");
    expect(pmd?.content).toBe("Pénalité 12 % annuel + indemnité 40 €.");
  });

  it("override AAB via customers.default_invoice_values.discount_mention", () => {
    const seller = makeSeller({
      default_invoice_values: {
        discount_mention: "Escompte 2 % paiement à 10 jours.",
      },
    });
    const r = formToModel(makeBaseForm(), seller);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    const aab = r.value.exchangedDocument.includedNotes?.[2];
    expect(aab?.subjectCode).toBe("AAB");
    expect(aab?.content).toBe("Escompte 2 % paiement à 10 jours.");
  });

  it("PMT toujours hardcoded Loi LME, jamais paramétrable (override ignoré)", () => {
    const seller = makeSeller({
      // Clé inexistante d'overide PMT — pas censée fonctionner par design.
      default_invoice_values: { pmt_mention: "Custom PMT mention ignored" },
    });
    const r = formToModel(makeBaseForm(), seller);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    const pmt = r.value.exchangedDocument.includedNotes?.[0];
    expect(pmt?.subjectCode).toBe("PMT");
    expect(pmt?.content).toBe(
      "Indemnité forfaitaire pour frais de recouvrement en cas de retard de paiement : 40 €.",
    );
  });

  it("override avec string vide → fallback default AFNOR (treated as not set)", () => {
    const seller = makeSeller({
      default_invoice_values: { late_penalties_mention: "", discount_mention: "" },
    });
    const r = formToModel(makeBaseForm(), seller);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.value.exchangedDocument.includedNotes?.[1]?.content).toMatch(
      /trois fois le taux d'intérêt légal/,
    );
    expect(r.value.exchangedDocument.includedNotes?.[2]?.content).toMatch(/escompte/);
  });

  it("notes utilisateur BT-22 simple + 3 auto cohabitent (BR-FR-06 unicité respectée)", () => {
    const seller = makeSeller();
    const form = makeBaseForm({
      document: {
        number: "F-2026-0001",
        issueDate: "2026-05-16",
        notes: "Merci de régler dans les délais.",
      },
    });
    const r = formToModel(form, seller);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    const notes = r.value.exchangedDocument.includedNotes;
    // 1 user (sans subjectCode) + 3 auto (PMT/PMD/AAB)
    expect(notes).toHaveLength(4);
    expect(notes?.[0]).toEqual({ content: "Merci de régler dans les délais." });
    expect(notes?.[0]?.subjectCode).toBeUndefined();
    expect(notes?.[1]?.subjectCode).toBe("PMT");
    expect(notes?.[2]?.subjectCode).toBe("PMD");
    expect(notes?.[3]?.subjectCode).toBe("AAB");
  });
});

// ─────────────────────────────────────────────────────────────────────
// T-CL-FACTURX-AUDIT-V1 — Pattern défensif S1 catégorie B
// (cf. `docs/standards/factur-x-1.07.3-extended-xsd-cardinalities.md` §5)
// ─────────────────────────────────────────────────────────────────────

describe("formToModel — FACTURX-AUDIT-V1 cat. B billingPeriod (BG-14)", () => {
  it("billingPeriod = null → modèle sans billingPeriod (S1 omission)", () => {
    const seller = makeSeller();
    const form = makeAdvancedForm({
      document: {
        ...makeAdvancedForm().document,
        billingPeriod: null,
      },
    });
    const r = formToModel(form, seller);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.value.tradeTransaction.tradeSettlement.billingPeriod).toBeUndefined();
  });

  it("billingPeriod = {} (undefined/undefined côté Zod nullish) → modèle sans billingPeriod (garde S1)", () => {
    // Zod `BillingPeriodSchema` refine exige `startDate !== null || endDate !== null`
    // mais accepte `undefined` (cas {} pré-spread). La garde S1 défensive
    // côté formToModel omet la clé du modèle pour éviter `billingPeriod: {}` vide.
    const seller = makeSeller();
    const form = makeAdvancedForm({
      document: {
        ...makeAdvancedForm().document,
        billingPeriod: {},
      },
    });
    const r = formToModel(form, seller);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.value.tradeTransaction.tradeSettlement.billingPeriod).toBeUndefined();
  });

  it("billingPeriod = { startDate seul } → modèle billingPeriod avec startDate uniquement", () => {
    const seller = makeSeller();
    const form = makeAdvancedForm({
      document: {
        ...makeAdvancedForm().document,
        billingPeriod: { startDate: "2026-01-01", endDate: null },
      },
    });
    const r = formToModel(form, seller);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    const bp = r.value.tradeTransaction.tradeSettlement.billingPeriod;
    expect(bp).toBeDefined();
    expect(bp?.startDate).toEqual({ value: "20260101", format: "102" });
    expect(bp?.endDate).toBeUndefined();
  });

  it("billingPeriod = { endDate seul } → modèle billingPeriod avec endDate uniquement", () => {
    const seller = makeSeller();
    const form = makeAdvancedForm({
      document: {
        ...makeAdvancedForm().document,
        billingPeriod: { startDate: null, endDate: "2026-06-30" },
      },
    });
    const r = formToModel(form, seller);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    const bp = r.value.tradeTransaction.tradeSettlement.billingPeriod;
    expect(bp).toBeDefined();
    expect(bp?.startDate).toBeUndefined();
    expect(bp?.endDate).toEqual({ value: "20260630", format: "102" });
  });

  it("billingPeriod = { startDate, endDate } → modèle billingPeriod complet", () => {
    const seller = makeSeller();
    const form = makeAdvancedForm({
      document: {
        ...makeAdvancedForm().document,
        billingPeriod: { startDate: "2026-01-01", endDate: "2026-06-30" },
      },
    });
    const r = formToModel(form, seller);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    const bp = r.value.tradeTransaction.tradeSettlement.billingPeriod;
    expect(bp).toBeDefined();
    expect(bp?.startDate).toEqual({ value: "20260101", format: "102" });
    expect(bp?.endDate).toEqual({ value: "20260630", format: "102" });
  });
});

describe("formToModel — FACTURX-AUDIT-V1 cat. B lineBillingPeriod (BG-26)", () => {
  it("line.period = null → ligne sans lineBillingPeriod", () => {
    const seller = makeSeller();
    const form = makeAdvancedForm({
      lines: [
        {
          label: "L1",
          description: null,
          quantity: "1",
          unitCode: "C62",
          unitPriceHt: "100.00",
          vatCategory: "S",
          vatRate: "20.00",
          totalHt: "100.00",
          longDescription: null,
          note: null,
          basisQuantity: null,
          period: null,
        },
      ],
    });
    const r = formToModel(form, seller);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(
      r.value.tradeTransaction.lineItems[0]?.tradeSettlement.lineBillingPeriod,
    ).toBeUndefined();
  });

  it("line.period = { startDate seul } → ligne lineBillingPeriod avec startDate uniquement", () => {
    const seller = makeSeller();
    const form = makeAdvancedForm({
      lines: [
        {
          label: "L1",
          description: null,
          quantity: "1",
          unitCode: "C62",
          unitPriceHt: "100.00",
          vatCategory: "S",
          vatRate: "20.00",
          totalHt: "100.00",
          longDescription: null,
          note: null,
          basisQuantity: null,
          period: { startDate: "2026-05-01", endDate: null },
        },
      ],
    });
    const r = formToModel(form, seller);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    const lbp = r.value.tradeTransaction.lineItems[0]?.tradeSettlement.lineBillingPeriod;
    expect(lbp).toBeDefined();
    expect(lbp?.startDate).toEqual({ value: "20260501", format: "102" });
    expect(lbp?.endDate).toBeUndefined();
  });

  it("line.period = { startDate, endDate } → ligne lineBillingPeriod complet", () => {
    const seller = makeSeller();
    const form = makeAdvancedForm({
      lines: [
        {
          label: "L1",
          description: null,
          quantity: "1",
          unitCode: "C62",
          unitPriceHt: "100.00",
          vatCategory: "S",
          vatRate: "20.00",
          totalHt: "100.00",
          longDescription: null,
          note: null,
          basisQuantity: null,
          period: { startDate: "2026-05-01", endDate: "2026-05-31" },
        },
      ],
    });
    const r = formToModel(form, seller);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    const lbp = r.value.tradeTransaction.lineItems[0]?.tradeSettlement.lineBillingPeriod;
    expect(lbp).toBeDefined();
    expect(lbp?.startDate).toEqual({ value: "20260501", format: "102" });
    expect(lbp?.endDate).toEqual({ value: "20260531", format: "102" });
  });
});

// ─────────────────────────────────────────────────────────────────────
// extractPayloadExtended
// ─────────────────────────────────────────────────────────────────────

describe("extractPayloadExtended", () => {
  it("mode base → expose le buyer pour la reconstruction post-envoi", () => {
    // Le buyer est **toujours** stocké dans `payload_extended` pour
    // permettre la reconstruction du form via `_reconstruct.ts` lors
    // des consultations `/api/invoices/:id/{xml,pdf}`. Sans ça, la
    // route de reconstruction tombait sur un fallback "Inconnu /
    // 000000000" — découvert en recette FORM 2026-05-19.
    const out = extractPayloadExtended(makeBaseForm());
    expect(Object.keys(out)).toEqual(["buyer"]);
    expect((out.buyer as { siren: string }).siren).toBe("987654321");
  });

  it("mode avancé → contient buyer + BT-13/14/12 + commentaires privés + shipping + clientTaxRegime + ICS", () => {
    const out = extractPayloadExtended(makeAdvancedForm());
    expect((out.buyer as { siren: string }).siren).toBe("987654321");
    expect(out.buyerOrderRef).toBe("PO-2026-1234");
    expect(out.sellerOrderRef).toBe("202502-1");
    expect(out.contractRef).toBe("CTR-2025-456");
    expect(out.privateComments).toBe("Client habituel — paiement à 30j respecté");
    expect(out.footerMentions).toBe("TVA non applicable, art. 293 B du CGI");
    expect(out.clientTaxRegime).toBe("default");
    expect(out.transporter).toBe("DHL Express");
    expect(out.creditorReference).toBe("FR76ZZZ123456");
    // privateComments ne doit JAMAIS aller dans le XML CII — mais est
    // bien stocké en payload_extended pour rappel UI ultérieur.
  });
});

// ─────────────────────────────────────────────────────────────────────
// Restrictions politique builder V1 (sprint-06 — A-strict O+S + C1 cotraitance)
// ─────────────────────────────────────────────────────────────────────

describe("validateMixedVATCategories — A-strict O+S (ADR-016 candidat D2)", () => {
  const baseLine = {
    label: "Prestation",
    description: null,
    quantity: "1",
    unitCode: "HUR",
    unitPriceHt: "500.00",
    vatCategory: "S" as const,
    vatRate: "20.00" as string | null,
    totalHt: "500.00",
  };
  const sLine = { ...baseLine, vatCategory: "S" as const, vatRate: "20.00" };
  const oLine = { ...baseLine, label: "Subvention", vatCategory: "O" as const, vatRate: null };

  it("refuse un mix O + S avec message métier verbatim", () => {
    const form = { ...makeBaseForm(), lines: [sLine, oLine] } as InvoiceFormBase;
    const e = validateMixedVATCategories(form);
    expect(e?.code).toBe("MIXED_O_S_CATEGORIES");
    expect(e?.message).toBe(
      "Factures mixtes O+S non supportées V1 — facturez subvention et prestation séparément",
    );
  });

  it("refuse un mix O + E (étendu au-delà de S)", () => {
    const eLine = { ...oLine, vatCategory: "E" as const, label: "Export" };
    const form = { ...makeBaseForm(), lines: [oLine, eLine] } as InvoiceFormBase;
    // O + E : O présent + E taxable-exonéré → refusé.
    expect(validateMixedVATCategories(form)?.code).toBe("MIXED_O_S_CATEGORIES");
  });

  it("accepte O seul", () => {
    const form = { ...makeBaseForm(), lines: [oLine] } as InvoiceFormBase;
    expect(validateMixedVATCategories(form)).toBeNull();
  });

  it("accepte S seul (cas nominal)", () => {
    expect(validateMixedVATCategories(makeBaseForm())).toBeNull();
  });

  it("étend la détection à la remise document BG-20/BG-21 (Z9)", () => {
    const form = makeAdvancedForm({
      documentLevelAllowance: {
        chargeIndicator: false,
        amount: "10.00",
        baseAmount: null,
        percent: null,
        reason: "Remise",
        reasonCode: null,
        vatCategory: "O",
        vatRate: null,
      },
    });
    // Lignes en S (fixture) + remise document en O → mix refusé.
    expect(validateMixedVATCategories(form)?.code).toBe("MIXED_O_S_CATEGORIES");
  });
});

describe("validateBillingMode — C1 cotraitance (ADR-016 candidat D3)", () => {
  it("refuse B8 / S8 / M8 avec message cotraitance verbatim", () => {
    for (const mode of ["B8", "S8", "M8"]) {
      const e = validateBillingMode(mode);
      expect(e?.code).toBe("UNSUPPORTED_BILLING_MODE");
      expect(e?.message).toBe("Mode cotraitance non supporté V1 — contactez support");
    }
  });

  it("accepte les 14 modes V1", () => {
    const allowed = [
      "B1",
      "S1",
      "M1",
      "B2",
      "S2",
      "M2",
      "S3",
      "B4",
      "S4",
      "M4",
      "S5",
      "S6",
      "B7",
      "S7",
    ];
    for (const mode of allowed) {
      expect(validateBillingMode(mode)).toBeNull();
    }
  });

  it("undefined / vide → pas de garde (BT-23 non exposé V1)", () => {
    expect(validateBillingMode(undefined)).toBeNull();
    expect(validateBillingMode("")).toBeNull();
  });

  it("mode inconnu hors liste → erreur générique BR-FR-08", () => {
    const e = validateBillingMode("ZZ");
    expect(e?.code).toBe("UNSUPPORTED_BILLING_MODE");
    expect(e?.message).toContain("BR-FR-08");
  });
});

describe("formToModel — intégration restriction A-strict", () => {
  it("retourne err MIXED_O_S_CATEGORIES sur facture mixte O+S", () => {
    const mkLine = (cat: "S" | "O") => ({
      label: cat === "O" ? "Subvention" : "Prestation",
      description: null,
      quantity: "1",
      unitCode: "HUR",
      unitPriceHt: "500.00",
      vatCategory: cat,
      vatRate: cat === "S" ? "20.00" : null,
      totalHt: "500.00",
    });
    const form = { ...makeBaseForm(), lines: [mkLine("S"), mkLine("O")] } as InvoiceFormBase;
    const r = formToModel(form, makeSeller());
    expect(r.ok).toBe(false);
    if (r.ok) return;
    expect(r.errors.some((e) => e.code === "MIXED_O_S_CATEGORIES")).toBe(true);
  });
});

describe("formToModel — L11 avoir/rectificative (BT-3 + BG-3 BR-55)", () => {
  it("avoir 381 → invoiceTypeCode 381 + precedingInvoices BG-3 (BT-25 + BT-26)", () => {
    const base = makeBaseForm();
    const form: InvoiceFormBase = {
      ...base,
      document: { ...base.document, typeCode: "381" },
      precedingInvoiceId: "00000000-0000-4000-8000-000000000099",
      precedingInvoiceNumber: "F-2026-0042",
      precedingIssueDate: "2026-01-15",
    };
    const r = formToModel(form, makeSeller());
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.value.exchangedDocument.invoiceTypeCode).toBe("381");
    const preceding = r.value.tradeTransaction.tradeSettlement.precedingInvoices;
    expect(preceding).toHaveLength(1);
    expect(preceding?.[0]?.invoiceNumber).toBe("F-2026-0042");
    expect(preceding?.[0]?.issueDate).toBeDefined();
  });

  it("rectificative 384 → invoiceTypeCode 384 + precedingInvoices", () => {
    const base = makeBaseForm();
    const form: InvoiceFormBase = {
      ...base,
      document: { ...base.document, typeCode: "384" },
      precedingInvoiceId: "00000000-0000-4000-8000-000000000098",
      precedingInvoiceNumber: "F-2026-0050",
    };
    const r = formToModel(form, makeSeller());
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.value.exchangedDocument.invoiceTypeCode).toBe("384");
    expect(r.value.tradeTransaction.tradeSettlement.precedingInvoices?.[0]?.invoiceNumber).toBe(
      "F-2026-0050",
    );
  });

  it("avoir : montants positifs (le BT-3 inverse la nature fiscale, pas le signe)", () => {
    const base = makeBaseForm();
    const form: InvoiceFormBase = {
      ...base,
      document: { ...base.document, typeCode: "381" },
      precedingInvoiceNumber: "F-2026-0042",
    };
    const r = formToModel(form, makeSeller());
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(
      r.value.tradeTransaction.tradeSettlement.monetarySummation.grandTotalAmount,
    ).toBeGreaterThan(0);
  });

  it("facture standard 380 → pas de precedingInvoices", () => {
    const r = formToModel(makeBaseForm(), makeSeller());
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.value.exchangedDocument.invoiceTypeCode).toBe("380");
    expect(r.value.tradeTransaction.tradeSettlement.precedingInvoices).toBeUndefined();
  });
});
