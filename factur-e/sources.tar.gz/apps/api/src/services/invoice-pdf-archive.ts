/**
 * F8 — copie immuable du PDF Factur-X transmis (T-CL-RECONSTRUCT-FIDELE-F8).
 *
 * À l'envoi, le PDF réellement transmis à la PA est copié sur le stockage
 * objet (réutilise `app.exportsStorage` — bucket privé, **conservation
 * 180 j** ; pas d'archivage légal : doctrine PRD §1.6 / US-EMIT-012,
 * l'archivage 10 ans est à la charge de l'utilisateur via l'export ZIP).
 * `GET /api/invoices/:id/pdf` sert cette copie immuable pour une facture
 * envoyée, garantissant des bytes stables (l'ID trailer d'une reconstruction
 * dynamique dépend de la generationDate → non byte-stable).
 */

/** Clé de la copie immuable, scopée tenant (`customer_id` en préfixe — même
 *  convention que `exports/{customer_id}/...`). `invoice_id` est notre UUID
 *  interne, mais le préfixe tenant isole les copies par client. */
export function invoicePdfArchiveKey(customerId: string, invoiceId: string): string {
  return `invoices/${customerId}/${invoiceId}.pdf`;
}
