import {
  type CrossIndustryInvoice,
  type DocumentAllowanceCharge,
  type DocumentNote,
  type PaymentMeans,
  type PostalAddress,
  type SupplyChainTradeLineItem,
  type TradeParty,
  type VATBreakdown,
  type Result,
  dateOf,
  err,
  identifier,
  ok,
  FACTUR_X_PROFILES,
  NOTE_SUBJECT_CODES,
  PAYMENT_MEANS_CODES,
  SCHEME_IDS,
  UNIT_CODES,
} from "@factur-e/factur-x-model";
import {
  AFNOR_BR_FR_05_AAB_DEFAULT_ABSENCE_ESCOMPTE,
  AFNOR_BR_FR_05_PMD_DEFAULT_LME_3X_TAUX_LEGAL,
  AFNOR_BR_FR_05_PMT_FORFAIT_40_EUR,
  AFNOR_DEFAULT_INVOICE_VALUES_AAB_KEY,
  AFNOR_DEFAULT_INVOICE_VALUES_PMD_KEY,
  type InvoiceForm,
  type InvoiceFormAdvanced,
  type InvoicePaymentTerms,
  type LineItemBase,
  type LineItemAdvanced,
} from "@factur-e/shared-schemas";
import { COTRAITANCE_BILLING_MODES, isAllowedBillingMode } from "@factur-e/factur-x-builder";

import { decrypt } from "../auth/encryption.js";
import type { CustomerRow } from "../db/repos/customers.js";

const IBAN_CIPHER_PREFIX = "v1:";

/** Déchiffre l'IBAN stocké au format `v1:<base64(encrypted)>` produit
 *  par la route `PATCH /customers/me/profile`. Retourne la valeur en
 *  clair pour injection dans le XML CII (BT-84). Si l'entrée n'est pas
 *  préfixée `v1:` on retourne tel quel (rétro-compat données legacy
 *  ou tests qui passent un IBAN clair). */
function decryptCustomerIban(stored: string): string {
  if (!stored.startsWith(IBAN_CIPHER_PREFIX)) return stored;
  const base64 = stored.slice(IBAN_CIPHER_PREFIX.length);
  return decrypt(Buffer.from(base64, "base64")).toString("utf8");
}

/**
 * `formToModel` — fonction pure mappant un `InvoiceFormSchema` UI
 * (mode base 15 champs / mode avancé 54 champs) vers le modèle
 * `CrossIndustryInvoice` EN 16931 EXTENDED de `packages/factur-x-model`
 * (sprint-01 ADR-003).
 *
 * Mode UI base : 15 champs explicites + valeurs inférées depuis le
 * `sellerContext` (CustomerRow) — currency, vat_regime, IBAN, BIC,
 * mentions légales, vat_on_encashment, processingRule, typeCode 380.
 *
 * Mode UI avancé : 54 champs explicites + payload_extended jsonb
 * stockable séparément (BT-13/14 commandes, BG-13 shipping, VATEX,
 * 4 zones commentaires, BG-20 doc-level allowance, BT-90 ICS, BT-113
 * acompte, pénalités custom).
 *
 * Cf. `docs/product/mapping-bt-bg.md` (113 entrées BT/BG) +
 * `docs/design/sprint-04-invariants.md` §5 (couverture 15 base + 54
 * avancé).
 */

// ─────────────────────────────────────────────────────────────────────
// Erreurs typées
// ─────────────────────────────────────────────────────────────────────

export interface FormToModelError {
  code:
    | "EMPTY_LINES"
    | "INVALID_PAYMENT_METHOD_MISSING_IBAN"
    | "INVALID_VAT_RATE"
    | "INCONSISTENT_VAT_CATEGORY"
    | "INVALID_BUYER_ADDRESS"
    | "INVALID_SELLER_CONTEXT"
    // Restrictions politique builder V1 (sprint-06, ADR-016 candidat D2/D3).
    | "MIXED_O_S_CATEGORIES"
    | "UNSUPPORTED_BILLING_MODE";
  message: string;
  field?: string;
}

// ─────────────────────────────────────────────────────────────────────
// Restrictions politique builder V1 — plus strictes que l'EXTENDED-CTC-FR
// officiel (arbitrages Bruno A-strict + C1, 2026-05-25).
// ─────────────────────────────────────────────────────────────────────

/**
 * A-strict (ADR-016 candidat D2) — refuse les factures mixant la catégorie TVA
 * `O` (hors champ TVA, ex. subvention) avec une catégorie taxable/exonérée
 * (`S/E/AE/K/G/Z`). Plus strict que l'EXTENDED-CTC-FR officiel qui désactive
 * BR-CO-17 + BR-O-02/03/04/08/11/12/13/14 (8 relaxations autorisant le mix O).
 *
 * Périmètre Z9 : catégories collectées sur les lignes (BT-151), les remises/
 * charges de ligne (BT-95/102) ET la remise/charge document (BG-20/BG-21).
 */
export function validateMixedVATCategories(form: InvoiceForm): FormToModelError | null {
  const categories = new Set<string>();
  for (const line of form.lines) {
    categories.add(line.vatCategory);
    if ("allowance" in line && line.allowance !== null && line.allowance !== undefined) {
      categories.add(line.allowance.vatCategory);
    }
  }
  if (
    form.ui_mode === "advanced" &&
    form.documentLevelAllowance !== null &&
    form.documentLevelAllowance !== undefined
  ) {
    categories.add(form.documentLevelAllowance.vatCategory);
  }
  const hasO = categories.has("O");
  const hasTaxable = [...categories].some((c) => c !== "O");
  if (hasO && hasTaxable) {
    return {
      code: "MIXED_O_S_CATEGORIES",
      message:
        "Factures mixtes O+S non supportées V1 — facturez subvention et prestation séparément",
      field: "lines",
    };
  }
  return null;
}

/**
 * C1 (ADR-016 candidat D3) — refuse les modes de facturation cotraitance
 * (B8/S8/M8, 18 fatales BR-FR-MV-01..13) hors périmètre V1. Les 14 modes
 * autorisés sont portés par `ALLOWED_BILLING_MODES` (builder, BR-FR-08).
 *
 * Note V1 : le formulaire n'expose pas encore BT-23 (`businessProcessID`) —
 * la cotraitance est donc structurellement impossible à saisir aujourd'hui.
 * Ce garde est le point d'application canonique pour le jour où BT-23 sera
 * exposé (cohérent backlog cotraitance sprint-09+).
 */
export function validateBillingMode(mode: string | undefined): FormToModelError | null {
  if (mode === undefined || mode === "") return null;
  if ((COTRAITANCE_BILLING_MODES as readonly string[]).includes(mode)) {
    return {
      code: "UNSUPPORTED_BILLING_MODE",
      message: "Mode cotraitance non supporté V1 — contactez support",
      field: "billingMode",
    };
  }
  if (!isAllowedBillingMode(mode)) {
    return {
      code: "UNSUPPORTED_BILLING_MODE",
      message: `Mode de facturation BT-23 "${mode}" non reconnu (BR-FR-08).`,
      field: "billingMode",
    };
  }
  return null;
}

// ─────────────────────────────────────────────────────────────────────
// Helpers — calcul totaux + breakdown TVA
// ─────────────────────────────────────────────────────────────────────

/** Arrondi banker's rounding à 2 décimales pour les amounts BT-* */
function round2(n: number): number {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

/** Arrondi à 4 décimales pour quantité / prix unitaire EN 16931. */
function round4(n: number): number {
  return Math.round((n + Number.EPSILON) * 10000) / 10000;
}

/** Parse une string décimale en number — préserver la précision côté
 *  modèle (factur-x-model utilise number, la précision décimale est
 *  préservée à la sérialisation XML par le formatage côté builder). */
function toNumber(s: string): number {
  return Number(s);
}

interface VatBucket {
  category: string;
  rate: number | null;
  basis: number;
  vat: number;
  /** BT-121 — code VATEX d'exonération propagé depuis `line.vatex` (GAP-1).
   *  Posé pour les catégories à exemption {E,AE,K,G,O} ; satisfait BR-E-10
   *  (et sœurs) « code OU texte ». Le texte BT-120 n'est pas dérivable du
   *  form → non inventé. */
  exemptionReasonCode?: string;
}

/** Catégories TVA dont la ventilation BG-23 exige un motif d'exonération
 *  (BT-121 code ou BT-120 texte) — BR-E-10 / BR-AE-10 / BR-K-10 / BR-G-10 /
 *  BR-O-10. `vatex` du form porte le code (ex. VATEX-EU-132). */
const VATEX_REQUIRED_CATEGORIES = new Set(["E", "AE", "K", "G", "O"]);

/** Code VATEX porté par une ligne (mode avancé uniquement — `vatex` n'existe
 *  pas sur les lignes mode base), ou `undefined`. */
function lineVatex(line: LineItemBase | LineItemAdvanced): string | undefined {
  return "vatex" in line && line.vatex !== null && line.vatex !== undefined
    ? line.vatex
    : undefined;
}

/**
 * Taux TVA effectif d'une catégorie au niveau modèle (BT-152 ligne /
 * BT-119 ventilation). GAP-1 : le schéma Zod force `vatRate === null` hors
 * catégorie S, or EN 16931 exige un **taux 0 explicite** pour les catégories
 * à taux zéro / exonérées {Z, E, AE, K, G} (BR-{Z,E,AE,IC,G}-05/08 + BR-48 :
 * la ventilation doit porter un taux). Sans ce 0, le breakdown E ne porte ni
 * BT-119 ni la ligne BT-152 → fatales BR-E-05 / BR-48 / BR-FREXT-E-08.
 * Catégorie O = hors champ d'application : aucun taux (exclue de BR-48).
 */
function effectiveCategoryRate(category: string, vatRate: string | null): number | null {
  if (category === "S") return vatRate === null ? null : toNumber(vatRate);
  if (category === "O") return null;
  return 0;
}

/** Agrège les lignes par (vatCategory, vatRate) pour produire la
 *  ventilation BG-23 VATBreakdown[]. */
function aggregateVATBreakdown(
  lines: (LineItemBase | LineItemAdvanced)[],
  documentLevelCharges: DocumentAllowanceCharge[],
): VATBreakdown[] {
  const buckets = new Map<string, VatBucket>();

  for (const line of lines) {
    const rate = effectiveCategoryRate(line.vatCategory, line.vatRate);
    const key = `${line.vatCategory}|${rate === null ? "null" : String(rate)}`;
    const totalHt = toNumber(line.totalHt);
    const vat = rate === null ? 0 : round2((totalHt * rate) / 100);
    // GAP-1 — propagation BT-121 : seules les catégories à exemption portent
    // un code ; on retient le premier code rencontré dans le bucket.
    const vatex = VATEX_REQUIRED_CATEGORIES.has(line.vatCategory) ? lineVatex(line) : undefined;
    const existing = buckets.get(key);
    if (existing === undefined) {
      buckets.set(key, {
        category: line.vatCategory,
        rate,
        basis: totalHt,
        vat,
        exemptionReasonCode: vatex,
      });
    } else {
      existing.basis = round2(existing.basis + totalHt);
      existing.vat = round2(existing.vat + vat);
      existing.exemptionReasonCode ??= vatex;
    }
  }

  // Remises/charges niveau document (BG-20/21 : remise globale + frais de
  // port) — chacune affecte la base du bucket de sa taxCategoryCode
  // (négatif si remise, positif si charge).
  for (const ac of documentLevelCharges) {
    const cat = ac.taxCategoryCode;
    const rate = ac.taxPercent ?? null;
    const key = `${cat}|${rate === null ? "null" : String(rate)}`;
    const signedAmount = ac.isCharge ? ac.actualAmount : -ac.actualAmount;
    const signedVat = rate === null ? 0 : round2((signedAmount * rate) / 100);
    const existing = buckets.get(key);
    if (existing === undefined) {
      buckets.set(key, { category: cat, rate, basis: signedAmount, vat: signedVat });
    } else {
      existing.basis = round2(existing.basis + signedAmount);
      existing.vat = round2(existing.vat + signedVat);
    }
  }

  return Array.from(buckets.values()).map((b) => ({
    taxBasisAmount: b.basis,
    calculatedAmount: b.vat,
    categoryCode: b.category,
    ratePercent: b.rate ?? undefined,
    exemptionReasonCode: b.exemptionReasonCode, // BT-121 (GAP-1) — undefined hors exemption
  }));
}

interface TotalsBundle {
  lineTotalHt: number;
  documentAllowance: number;
  documentCharge: number;
  taxBasis: number;
  vatTotal: number;
  grandTotal: number;
  duePayable: number;
}

/** Calcul des totaux BG-22 MonetarySummation. */
function computeTotals(
  lines: (LineItemBase | LineItemAdvanced)[],
  documentLevelCharges: DocumentAllowanceCharge[],
  vatBreakdown: VATBreakdown[],
  prepaidAmount: number,
): TotalsBundle {
  const lineTotalHt = round2(lines.reduce((acc, l) => acc + toNumber(l.totalHt), 0));
  // BT-107 / BT-108 — somme des remises (resp. charges) niveau document.
  const documentAllowance = round2(
    documentLevelCharges.filter((a) => !a.isCharge).reduce((acc, a) => acc + a.actualAmount, 0),
  );
  const documentCharge = round2(
    documentLevelCharges.filter((a) => a.isCharge).reduce((acc, a) => acc + a.actualAmount, 0),
  );
  const taxBasis = round2(lineTotalHt + documentCharge - documentAllowance);
  const vatTotal = round2(vatBreakdown.reduce((acc, vb) => acc + vb.calculatedAmount, 0));
  const grandTotal = round2(taxBasis + vatTotal);
  const duePayable = round2(grandTotal - prepaidAmount);
  return {
    lineTotalHt,
    documentAllowance,
    documentCharge,
    taxBasis,
    vatTotal,
    grandTotal,
    duePayable,
  };
}

/** Mapping `paymentMethodKind` (familles UI) → BT-81 UNTDID 4461. */
function paymentMethodToTypeCode(kind: InvoiceForm["payment"]["paymentMethodKind"]): string {
  switch (kind) {
    case "transfer":
      return PAYMENT_MEANS_CODES.SEPA_CREDIT_TRANSFER; // 58
    case "direct_debit":
      return PAYMENT_MEANS_CODES.SEPA_DIRECT_DEBIT; // 59
    case "card":
      return PAYMENT_MEANS_CODES.CARD; // 48
    case "check":
      return PAYMENT_MEANS_CODES.CHEQUE; // 20
    case "cash":
      return PAYMENT_MEANS_CODES.CASH; // 10
  }
}

/** Calcul de la due date BT-9 depuis les modalités hybrides UI. */
function computeDueDate(issueDate: Date, terms: InvoicePaymentTerms): Date {
  switch (terms.kind) {
    case "onSight":
      return issueDate;
    case "days": {
      const d = new Date(issueDate.getTime());
      d.setUTCDate(d.getUTCDate() + terms.days);
      return d;
    }
    case "endOfMonth": {
      // Fin du mois courant + N jours
      const d = new Date(Date.UTC(issueDate.getUTCFullYear(), issueDate.getUTCMonth() + 1, 0));
      d.setUTCDate(d.getUTCDate() + terms.days);
      return d;
    }
    case "fixedDate":
      return new Date(`${terms.dueDate}T00:00:00Z`);
  }
}

/**
 * Description textuelle BT-20 (libellé conditions de règlement). `undefined`
 * pour `fixedDate` : l'échéance est déjà portée par la BT-9 `DueDateDateTime`
 * (BR-CO-25 satisfaite par BT-9) — une Description « Date d'échéance : <ISO> »
 * serait redondante, et apparaissait en double + non formatée au PDF
 * (recette T-CL-PDF-MOTEUR-V2 anomalie B). Pour les autres modalités, le
 * libellé reste informatif (« Règlement à 30 jours », etc.).
 */
function paymentTermsDescription(terms: InvoicePaymentTerms): string | undefined {
  switch (terms.kind) {
    case "onSight":
      return "Règlement à vue";
    case "days":
      return `Règlement à ${String(terms.days)} jours`;
    case "endOfMonth":
      return terms.days === 0
        ? "Règlement fin de mois"
        : `Règlement à ${String(terms.days)} jours fin de mois`;
    case "fixedDate":
      return undefined;
  }
}

// ─────────────────────────────────────────────────────────────────────
// Helpers — construction TradeParty
// ─────────────────────────────────────────────────────────────────────

function postalAddressFromForm(addr: {
  lineOne?: string | null | undefined;
  lineTwo?: string | null | undefined;
  postcode: string;
  city: string;
  countryCode: string;
}): PostalAddress {
  const out: PostalAddress = {
    countryCode: addr.countryCode,
    postalCode: addr.postcode,
    cityName: addr.city,
  };
  if (addr.lineOne !== null && addr.lineOne !== undefined && addr.lineOne !== "") {
    out.lineOne = addr.lineOne;
  }
  if (addr.lineTwo !== null && addr.lineTwo !== undefined && addr.lineTwo !== "") {
    out.lineTwo = addr.lineTwo;
  }
  return out;
}

/** Parse l'adresse JSONB du customer (forme libre depuis sprint-02
 *  `customers.address jsonb`). On accepte plusieurs formes : à plat ou
 *  imbriquée. */
function sellerAddressFromCustomer(addr: Record<string, unknown>): PostalAddress {
  const countryCode =
    typeof addr.country_code === "string"
      ? addr.country_code
      : typeof addr.countryCode === "string"
        ? addr.countryCode
        : "FR";
  const postalCode =
    typeof addr.postcode === "string"
      ? addr.postcode
      : typeof addr.postal_code === "string"
        ? addr.postal_code
        : undefined;
  const cityName = typeof addr.city === "string" ? addr.city : undefined;
  const lineOne =
    typeof addr.line_one === "string"
      ? addr.line_one
      : typeof addr.lineOne === "string"
        ? addr.lineOne
        : typeof addr.street === "string"
          ? addr.street
          : undefined;
  const out: PostalAddress = { countryCode };
  if (postalCode !== undefined) out.postalCode = postalCode;
  if (cityName !== undefined) out.cityName = cityName;
  if (lineOne !== undefined) out.lineOne = lineOne;
  return out;
}

function buildSellerTradeParty(seller: CustomerRow): TradeParty {
  const out: TradeParty = {
    name: seller.legal_name,
    // BT-29 — `GlobalID schemeID="0225"` Peppol Seller identifier.
    // Obligatoire côté SuperPDP pour indexer la facture sur l'identité
    // Peppol du vendeur (sans ça la facture est marquée "invalide"
    // dans leur IHM — recette FORM 2026-05-19). Distinct du BT-30
    // ci-dessous (registration légale SIREN/SIRET au scheme 0002).
    globalID: identifier(seller.siren, "0225"),
    postalAddress: sellerAddressFromCustomer(seller.address),
    legalRegistrationID: identifier(seller.siren, SCHEME_IDS.SIREN_SIRET),
  };
  // BR-S-02 (NC-17) — Seller VAT Identifier (BT-31). Obligatoire sur facture
  // contenant une ligne TVA standard rated (catégorie `S`). Mappé par le
  // sérialiseur `serializeTradeParty` en `SpecifiedTaxRegistration/ID@schemeID="VA"`.
  // Mode dégradé ADR-009 D1 : si `seller.vat_number IS NULL` (customer non
  // provisionné via UI Paramètres > Entreprise), facture émise sans BT-31 —
  // Schematron BR-S-2 retournera warning côté SuperPDP (acceptable V1, BR-S-2
  // tolère alternative BT-32/BT-63 et/ou warning non bloquant).
  if (seller.vat_number !== null && seller.vat_number !== "") {
    out.vatID = identifier(seller.vat_number, SCHEME_IDS.VAT);
  }
  if (seller.trading_name !== null && seller.trading_name !== "") {
    out.tradingName = seller.trading_name;
  }
  // BT-34 — `URIUniversalCommunication.URIID` du Seller (adresse Peppol).
  // Stocké dans `customers.directory_address` au format composé
  // `<scheme>:<id>` (ex `"0225:315143296_3686"`). Hard required par
  // SuperPDP au dépôt sandbox — son absence déclenche un
  // `InvoiceRejectedXsdException` 422 (constaté sur le sample
  // `extended-sample-001` en smoke tests, cf. trace sprint-04). Le
  // `BuyerTradeParty` porte déjà ce champ via `b.electronicAddress`
  // ligne 312 ; le seller était l'oublié asymétrique.
  if (seller.directory_address !== null && seller.directory_address !== "") {
    const colon = seller.directory_address.indexOf(":");
    if (colon > 0) {
      const scheme = seller.directory_address.slice(0, colon);
      const id = seller.directory_address.slice(colon + 1);
      out.electronicAddress = identifier(id, scheme);
    }
  }
  return out;
}

function buildBuyerTradeParty(form: InvoiceForm): TradeParty {
  const b = form.parties.buyer;
  return {
    name: b.legalName,
    // BT-47 — `GlobalID schemeID="0225"` Peppol Buyer identifier
    // (symétrique BT-29 seller). Obligatoire côté SuperPDP, sans ça
    // la facture est marquée "invalide" dans leur IHM.
    globalID: identifier(b.siren, "0225"),
    postalAddress: postalAddressFromForm(b.address),
    legalRegistrationID: identifier(b.siren, SCHEME_IDS.SIREN_SIRET),
    electronicAddress: identifier(b.electronicAddress, b.electronicAddressScheme),
  };
}

// ─────────────────────────────────────────────────────────────────────
// Helpers — construction Line Items
// ─────────────────────────────────────────────────────────────────────

const UNECE_VALID_CODES: ReadonlySet<string> = new Set(Object.values(UNIT_CODES));

// BT-130 (NC-17) — mapping libellés FR courants → codes UN/ECE Rec 20 + Rec 21.
// Source : Factur-X 1.07.3 v15 (`Rec20r20 + Rec21r20`, effective 2025-05-15) —
// cf. `docs/standards/factur-x-1.07.3-unit-codes-un-cefact-rec-20.md` §2 (table
// FR validée v15). Clés normalisées NFD + lowercase (cf. `toUneceUnitCode`).
const FR_UNIT_LABEL_TO_UNECE: Readonly<Record<string, string>> = {
  // Comptables / unité (pièce → C62 conservé — cohérence repo Factur-E acquise
  // sprint-01, vs recommandation Cowork H87 piece). [NOTE-COWORK] : ajuster
  // sprint-06+ si retours pilote remontent collisions sémantiques.
  piece: UNIT_CODES.PIECE,
  pieces: UNIT_CODES.PIECE,
  pcs: UNIT_CODES.PIECE,
  u: UNIT_CODES.PIECE,
  unite: UNIT_CODES.PIECE,
  unites: UNIT_CODES.PIECE,
  // Service / forfait (fallback piece — acceptable Schematron).
  forfait: UNIT_CODES.PIECE,
  service: UNIT_CODES.PIECE,
  // Temps
  heure: UNIT_CODES.HOUR,
  heures: UNIT_CODES.HOUR,
  h: UNIT_CODES.HOUR,
  minute: UNIT_CODES.MINUTE,
  minutes: UNIT_CODES.MINUTE,
  min: UNIT_CODES.MINUTE,
  seconde: UNIT_CODES.SECOND,
  secondes: UNIT_CODES.SECOND,
  jour: UNIT_CODES.DAY,
  jours: UNIT_CODES.DAY,
  j: UNIT_CODES.DAY,
  mois: UNIT_CODES.MONTH,
  annee: UNIT_CODES.YEAR,
  annees: UNIT_CODES.YEAR,
  an: UNIT_CODES.YEAR,
  ans: UNIT_CODES.YEAR,
  "homme-mois": UNIT_CODES.MAN_MONTH,
  hommemois: UNIT_CODES.MAN_MONTH,
  // Masse
  kg: UNIT_CODES.KILOGRAM,
  kilogramme: UNIT_CODES.KILOGRAM,
  kilogrammes: UNIT_CODES.KILOGRAM,
  g: UNIT_CODES.GRAM,
  gramme: UNIT_CODES.GRAM,
  grammes: UNIT_CODES.GRAM,
  t: UNIT_CODES.TONNE,
  tonne: UNIT_CODES.TONNE,
  tonnes: UNIT_CODES.TONNE,
  // Distance
  metre: UNIT_CODES.METRE,
  metres: UNIT_CODES.METRE,
  m: UNIT_CODES.METRE,
  cm: UNIT_CODES.CENTIMETRE,
  centimetre: UNIT_CODES.CENTIMETRE,
  centimetres: UNIT_CODES.CENTIMETRE,
  mm: UNIT_CODES.MILLIMETRE,
  millimetre: UNIT_CODES.MILLIMETRE,
  millimetres: UNIT_CODES.MILLIMETRE,
  km: UNIT_CODES.KILOMETRE,
  kilometre: UNIT_CODES.KILOMETRE,
  kilometres: UNIT_CODES.KILOMETRE,
  // Surface
  m2: UNIT_CODES.SQUARE_METRE,
  "m²": UNIT_CODES.SQUARE_METRE,
  // Volume
  m3: UNIT_CODES.CUBIC_METRE,
  "m³": UNIT_CODES.CUBIC_METRE,
  // Liquides
  litre: UNIT_CODES.LITRE,
  litres: UNIT_CODES.LITRE,
  l: UNIT_CODES.LITRE,
  ml: UNIT_CODES.MILLILITRE,
  millilitre: UNIT_CODES.MILLILITRE,
  millilitres: UNIT_CODES.MILLILITRE,
  // Packaging (Rec 21)
  colis: UNIT_CODES.PACKAGE_PIECE,
  boite: UNIT_CODES.BOX,
  carton: UNIT_CODES.BOX,
  paquet: UNIT_CODES.PACKAGE,
  package: UNIT_CODES.PACKAGE,
};

/** Convertit un libellé UI (FR ou code UNECE déjà valide) vers le code
 *  UN/ECE Rec 20 strict requis par BT-130 + Schematron EN 16931 / BR-FR.
 *  Cf. `apps/web/src/emit/new/sections/SectionLignes.tsx` §183-187 qui
 *  documente cette frontière (libellé humain côté UI, code strict côté
 *  modèle Factur-X). Fallback `C62` pour ne pas bloquer l'émission si
 *  la valeur saisie est inconnue. */
function toUneceUnitCode(raw: string): string {
  const upper = raw.trim().toUpperCase();
  if (UNECE_VALID_CODES.has(upper)) return upper;
  const norm = raw
    .trim()
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
  return FR_UNIT_LABEL_TO_UNECE[norm] ?? UNIT_CODES.PIECE;
}

function buildLineItem(
  line: LineItemBase | LineItemAdvanced,
  index: number,
): SupplyChainTradeLineItem {
  const uneceUnit = toUneceUnitCode(line.unitCode);
  const out: SupplyChainTradeLineItem = {
    lineID: String(index + 1), // BT-126
    product: {
      name: line.label, // BT-153
    },
    tradeAgreement: {
      netPrice: round4(toNumber(line.unitPriceHt)), // BT-146
    },
    tradeDelivery: {
      billedQuantity: round4(toNumber(line.quantity)), // BT-129
      unitCode: uneceUnit, // BT-130
    },
    tradeSettlement: {
      vatInformation: {
        categoryCode: line.vatCategory, // BT-151
        // BT-152 — taux ligne. GAP-1 : 0 explicite pour {Z,E,AE,K,G}
        // (BR-E-05 & sœurs), absent pour O (hors champ).
        ...((): { ratePercent: number } | Record<string, never> => {
          const rate = effectiveCategoryRate(line.vatCategory, line.vatRate);
          return rate !== null ? { ratePercent: rate } : {};
        })(),
        // BT-121 — code VATEX répliqué au niveau ligne pour les catégories
        // exonérées (réconciliation FR BR-FREXT-*-08rev ligne↔ventilation).
        ...((): { exemptionReasonCode: string } | Record<string, never> => {
          const vatex = VATEX_REQUIRED_CATEGORIES.has(line.vatCategory)
            ? lineVatex(line)
            : undefined;
          return vatex !== undefined ? { exemptionReasonCode: vatex } : {};
        })(),
      },
      netLineAmount: round2(toNumber(line.totalHt)), // BT-131
    },
  };

  // BT-154 description (advanced only). Le schema Advanced a `description`
  // simple + `longDescription`. On préfère longDescription si présente,
  // sinon description.
  if (
    "longDescription" in line &&
    line.longDescription !== null &&
    line.longDescription !== undefined &&
    line.longDescription !== ""
  ) {
    out.product.description = line.longDescription;
  } else if (
    line.description !== null &&
    line.description !== undefined &&
    line.description !== ""
  ) {
    out.product.description = line.description;
  }

  // BT-127 note ligne (advanced only).
  if ("note" in line && line.note !== null && line.note !== undefined && line.note !== "") {
    out.note = line.note;
  }

  // BT-149 quantité de base (advanced only).
  if ("basisQuantity" in line && line.basisQuantity !== null && line.basisQuantity !== undefined) {
    out.tradeAgreement.basisQuantity = round4(toNumber(line.basisQuantity));
    out.tradeAgreement.basisQuantityUnitCode = uneceUnit;
  }

  // BG-26 période ligne (advanced only).
  // T-CL-FACTURX-AUDIT-V1 — pattern défensif S1 (cat. B `docs/standards/factur-x
  // -1.07.3-extended-xsd-cardinalities.md` §5). Le schéma Zod `period` est
  // `BillingPeriodSchema.nullish()` : il accepte techniquement `{ startDate:
  // null, endDate: null }`. Sans la garde finale, le spread produirait
  // `lineBillingPeriod: {}` vide dans le modèle TS — XML valide grâce au
  // sérialiseur défensif `serialize/billing-period.ts` qui retourne `null`
  // si les deux dates sont undefined, mais sémantique modèle sale. La garde
  // explicite omet la clé du modèle si aucune date n'est posée.
  if (
    "period" in line &&
    line.period !== null &&
    line.period !== undefined &&
    (line.period.startDate !== null || line.period.endDate !== null)
  ) {
    const period: SupplyChainTradeLineItem["tradeSettlement"]["lineBillingPeriod"] = {};
    if (line.period.startDate !== null && line.period.startDate !== undefined) {
      period.startDate = dateOf(new Date(`${line.period.startDate}T00:00:00Z`));
    }
    if (line.period.endDate !== null && line.period.endDate !== undefined) {
      period.endDate = dateOf(new Date(`${line.period.endDate}T00:00:00Z`));
    }
    if (period.startDate !== undefined || period.endDate !== undefined) {
      out.tradeSettlement.lineBillingPeriod = period;
    }
  }

  // BG-27/28 remise/charge ligne (advanced only).
  if ("allowance" in line && line.allowance !== null && line.allowance !== undefined) {
    const ac = {
      isCharge: line.allowance.chargeIndicator,
      actualAmount: round2(toNumber(line.allowance.amount)),
      ...(line.allowance.reason !== null &&
      line.allowance.reason !== undefined &&
      line.allowance.reason !== ""
        ? { reason: line.allowance.reason }
        : {}),
      ...(line.allowance.reasonCode !== null &&
      line.allowance.reasonCode !== undefined &&
      line.allowance.reasonCode !== ""
        ? { reasonCode: line.allowance.reasonCode }
        : {}),
    };
    if (line.allowance.chargeIndicator) {
      out.tradeSettlement.lineCharges = [ac];
    } else {
      out.tradeSettlement.lineAllowances = [ac];
    }
  }

  return out;
}

// ─────────────────────────────────────────────────────────────────────
// Helpers — document-level allowances/charges (BG-20/21 advanced only)
// ─────────────────────────────────────────────────────────────────────

/** Taux TVA uniforme des lignes fournies, ou `null` si aucune n'est taxée
 *  ou si les taux divergent (cas multi-taux → ambigu, pas de dérivation). */
function uniformLineRate(lines: readonly (LineItemBase | LineItemAdvanced)[]): number | null {
  let rate: number | null = null;
  for (const l of lines) {
    if (l.vatRate === null) continue;
    const r = toNumber(l.vatRate);
    if (rate === null) rate = r;
    else if (rate !== r) return null;
  }
  return rate;
}

function buildDocumentLevelAllowance(
  advanced: InvoiceFormAdvanced,
): DocumentAllowanceCharge | undefined {
  const a = advanced.documentLevelAllowance;
  if (a === null || a === undefined) return undefined;
  // Finding I — remise globale en mode pourcentage : `GlobalAllowanceModal`
  // envoie `amount:"0"` (sentinelle) ; le montant réel est DÉRIVÉ ici à
  // chaque build (jamais figé côté form → robuste à l'édition des lignes).
  // BT-93 base = Σ HT des lignes de la catégorie TVA de la remise (= base du
  // VATBreakdown de cette catégorie avant remise document).
  const matching = advanced.lines.filter((l) => l.vatCategory === a.vatCategory);
  const basis = round2(matching.reduce((acc, l) => acc + toNumber(l.totalHt), 0));
  const percent = a.percent !== null && a.percent !== undefined ? toNumber(a.percent) : null;
  const out: DocumentAllowanceCharge = {
    isCharge: a.chargeIndicator,
    actualAmount: percent !== null ? round2((basis * percent) / 100) : round2(toNumber(a.amount)),
    taxCategoryCode: a.vatCategory,
  };
  // BT-96 taux TVA de la remise : explicite sinon dérivé du taux uniforme des
  // lignes de sa catégorie. Sans taux la TVA de la remise tomberait dans un
  // bucket distinct (S|null) et ne réduirait pas le total TTC (finding I).
  const taxPercent =
    a.vatRate !== null && a.vatRate !== undefined ? toNumber(a.vatRate) : uniformLineRate(matching);
  if (taxPercent !== null) out.taxPercent = taxPercent;
  if (percent !== null) {
    out.calculationPercent = percent;
    out.basisAmount = basis; // BT-93 — cohérence ActualAmount/BasisAmount/Percent.
  } else if (a.baseAmount !== null && a.baseAmount !== undefined) {
    out.basisAmount = round2(toNumber(a.baseAmount));
  }
  if (a.reason !== null && a.reason !== undefined && a.reason !== "") out.reason = a.reason;
  if (a.reasonCode !== null && a.reasonCode !== undefined && a.reasonCode !== "")
    out.reasonCode = a.reasonCode;
  return out;
}

/** Finding J — frais de port → BG-21 charge document. reasonCode UNTDID
 *  7161 "FC" (Freight) + Reason texte "Frais de port" (BR-42/43). La
 *  CategoryTradeTax (BG-21 obligatoire) est portée par `shippingCostVatCategory`
 *  (défaut "S") + `shippingCostVatRate`. `undefined` si pas de frais (≤ 0). */
function buildShippingCharge(advanced: InvoiceFormAdvanced): DocumentAllowanceCharge | undefined {
  const raw = advanced.shippingCostHt;
  if (raw === null || raw === undefined || raw === "") return undefined;
  const amount = round2(toNumber(raw));
  if (amount <= 0) return undefined;
  const out: DocumentAllowanceCharge = {
    isCharge: true,
    actualAmount: amount,
    taxCategoryCode: advanced.shippingCostVatCategory ?? "S",
    reason: "Frais de port",
    reasonCode: "FC",
  };
  if (advanced.shippingCostVatRate !== null && advanced.shippingCostVatRate !== undefined)
    out.taxPercent = toNumber(advanced.shippingCostVatRate);
  return out;
}

/** Remises/charges niveau document (mode avancé) : remise globale
 *  (`documentLevelAllowance` BG-20/21) + frais de port (BG-21). Les deux
 *  coexistent — pipeline totaux + ventilation TVA itère sur la liste. */
function buildDocumentLevelCharges(form: InvoiceForm): DocumentAllowanceCharge[] {
  if (form.ui_mode !== "advanced") return [];
  const out: DocumentAllowanceCharge[] = [];
  const global = buildDocumentLevelAllowance(form);
  if (global !== undefined) out.push(global);
  const shipping = buildShippingCharge(form);
  if (shipping !== undefined) out.push(shipping);
  return out;
}

// ─────────────────────────────────────────────────────────────────────
// Helpers — DocumentNote (BG-1)
// ─────────────────────────────────────────────────────────────────────

function buildIncludedNotes(form: InvoiceForm, seller: CustomerRow): DocumentNote[] {
  const notes: DocumentNote[] = [];
  // Zone "Notes" simple (BT-22) — présente dans les 2 modes. Pas de
  // subjectCode : note libre utilisateur, distincte des 3 mentions LME
  // PMT/PMD/AAB auto-générées ci-dessous (BR-FR-06 unicité non violée :
  // ces notes utilisateur n'ont pas de subjectCode).
  if (
    form.document.notes !== null &&
    form.document.notes !== undefined &&
    form.document.notes !== ""
  ) {
    notes.push({ content: form.document.notes });
  }
  if (form.ui_mode === "advanced") {
    // 3 zones supplémentaires mode avancé : `generalComments` en-tête PDF
    // (BG-1 sans qualifier), `footerMentions` mentions légales de pied (BG-1
    // `qual:REG`, finding K2 Option B1), `privateComments` INTERNE qui ne va
    // PAS dans l'XML (Option A — `payload_extended` seul, cf. mécanique #8).
    if (
      form.document.generalComments !== null &&
      form.document.generalComments !== undefined &&
      form.document.generalComments !== ""
    ) {
      notes.push({ content: form.document.generalComments });
    }
    // K2 Option B1 — footerMentions (mentions légales de pied) → BG-1
    // IncludedNote `subjectCode:REG` (information réglementaire). REG n'est
    // pas soumis à l'unicité BR-FR-06 (PMT/PMD/AAB/TXD uniquement). Conservé
    // en parallèle dans `payload_extended` pour le rendu pied de page PDF.
    if (
      form.document.footerMentions !== null &&
      form.document.footerMentions !== undefined &&
      form.document.footerMentions !== ""
    ) {
      notes.push({
        content: form.document.footerMentions,
        subjectCode: NOTE_SUBJECT_CODES.REGULATORY_INFO,
      });
    }
  }

  // BR-FR-05 (NC-17) — 3 mentions légales obligatoires AFNOR XP Z12-012 §5.2 :
  //   PMT = indemnité forfaitaire 40 € Loi LME (fixe FR, immuable)
  //   PMD = pénalités de retard (paramétrable customer, fallback LME 3× taux légal)
  //   AAB = mention escompte ou absence (paramétrable customer, fallback absence)
  // Cf. `docs/standards/afnor-xp-z12-012-br-fr-05-included-notes.md` §3.
  // BR-FR-06 unicité : aucune note utilisateur n'expose actuellement de
  // subjectCode PMT/PMD/AAB (zone Notes simple BT-22 = `{content}` sans code),
  // donc aucun risque de duplication. À raffiner sprint-06+ si l'UI mode
  // avancé expose une saisie subjectCode user.
  const customerDefaults = seller.default_invoice_values;
  const rawPmd = customerDefaults[AFNOR_DEFAULT_INVOICE_VALUES_PMD_KEY];
  const pmdMention =
    typeof rawPmd === "string" && rawPmd !== ""
      ? rawPmd
      : AFNOR_BR_FR_05_PMD_DEFAULT_LME_3X_TAUX_LEGAL;
  const rawAab = customerDefaults[AFNOR_DEFAULT_INVOICE_VALUES_AAB_KEY];
  const aabMention =
    typeof rawAab === "string" && rawAab !== ""
      ? rawAab
      : AFNOR_BR_FR_05_AAB_DEFAULT_ABSENCE_ESCOMPTE;

  notes.push({
    content: AFNOR_BR_FR_05_PMT_FORFAIT_40_EUR,
    subjectCode: NOTE_SUBJECT_CODES.PAYMENT_TERMS,
  });
  notes.push({
    content: pmdMention,
    subjectCode: NOTE_SUBJECT_CODES.PAYMENT_MEANS_NOTE,
  });
  notes.push({
    content: aabMention,
    subjectCode: NOTE_SUBJECT_CODES.ADDITIONAL_BUYER_REF,
  });

  return notes;
}

// ─────────────────────────────────────────────────────────────────────
// Helpers — PaymentMeans (BG-16)
// ─────────────────────────────────────────────────────────────────────

function buildPaymentMeans(form: InvoiceForm, seller: CustomerRow): PaymentMeans {
  const advancedCode =
    form.ui_mode === "advanced" &&
    form.payment.paymentMeansCode !== null &&
    form.payment.paymentMeansCode !== undefined
      ? form.payment.paymentMeansCode
      : undefined;
  const typeCode = advancedCode ?? paymentMethodToTypeCode(form.payment.paymentMethodKind);
  const out: PaymentMeans = { typeCode };

  // BG-17 compte créditeur (BT-84 IBAN + BT-86 BIC) — depuis customer pour
  // transfer/direct_debit ; vide pour card/check/cash.
  if (
    form.payment.paymentMethodKind === "transfer" ||
    form.payment.paymentMethodKind === "direct_debit"
  ) {
    if (seller.iban !== null && seller.iban !== "") {
      // L'IBAN est stocké chiffré applicativement (`v1:<base64>`) côté
      // BDD. Il DOIT être déchiffré avant d'aller dans le XML CII —
      // sans ça SuperPDP et toute autre PA reçoit un cipher illisible
      // dans `<ram:IBANID>` (bug recette FORM 2026-05-19).
      const ibanPlain = decryptCustomerIban(seller.iban);
      const account: PaymentMeans["payeeFinancialAccounts"] = [
        {
          accountID: identifier(ibanPlain),
          ...(seller.bic !== null && seller.bic !== ""
            ? { financialInstitutionID: identifier(seller.bic) }
            : {}),
        },
      ];
      out.payeeFinancialAccounts = account;
    }
  }
  return out;
}

// ─────────────────────────────────────────────────────────────────────
// Helpers — HeaderTradeDelivery (BG-13 + BG-15 advanced)
// ─────────────────────────────────────────────────────────────────────

function buildTradeDelivery(
  form: InvoiceForm,
  issueDate: Date,
): CrossIndustryInvoice["tradeTransaction"]["tradeDelivery"] {
  // PEPPOL-EN16931-R008 (NC-17) — "Document MUST not contain empty elements"
  // (fatal). L'élément XSD `ApplicableHeaderTradeDelivery` est `minOccurs=1`
  // implicite dans `SupplyChainTradeTransactionType` (audit CLI 2026-05-24 sur
  // `CrossIndustryInvoice_100pD22B_..._ReusableAggregate...100.xsd:261`) — on
  // ne peut donc pas omettre l'élément (sinon casse XSD validation strict).
  // Tous les sous-éléments de `HeaderTradeDeliveryType` étant `minOccurs=0`,
  // un élément vide est XSD-valide mais déclenche R008 fatal côté Peppol.
  // Stratégie V1 : si form ne fournit aucun champ delivery → injecter
  // placeholder `actualDeliveryDate = issueDate` (BT-72 "livraison réputée
  // à émission"). Cf. `docs/standards/peppol-bis-billing-3-r008-no-empty-
  // elements.md` §"Hypothèse de travail" — extraction à patcher Cowork PMO
  // post-merge (synchro audit XSD confirmé `minOccurs=1`).
  const out: CrossIndustryInvoice["tradeTransaction"]["tradeDelivery"] = {};

  if (form.ui_mode === "advanced") {
    if (form.parties.shipping !== null && form.parties.shipping !== undefined) {
      out.deliveryAddress = postalAddressFromForm(form.parties.shipping.address);
      if (
        form.parties.shipping.name !== null &&
        form.parties.shipping.name !== undefined &&
        form.parties.shipping.name !== ""
      ) {
        out.shipToPartyName = form.parties.shipping.name;
      }
      if (
        form.parties.shipping.locationId !== null &&
        form.parties.shipping.locationId !== undefined &&
        form.parties.shipping.locationId !== ""
      ) {
        out.shipToPartyID = identifier(form.parties.shipping.locationId);
      }
    }
    if (form.parties.deliveryDate !== null && form.parties.deliveryDate !== undefined) {
      out.actualDeliveryDate = dateOf(new Date(`${form.parties.deliveryDate}T00:00:00Z`));
    }
  }

  // R008 défensif : si aucun champ delivery n'a été émis, injecter le
  // placeholder BT-72 = date d'émission pour garantir un sous-élément non
  // vide dans `ApplicableHeaderTradeDelivery`.
  if (
    out.actualDeliveryDate === undefined &&
    out.deliveryAddress === undefined &&
    out.shipToPartyName === undefined &&
    out.shipToPartyID === undefined
  ) {
    out.actualDeliveryDate = dateOf(issueDate);
  }

  return out;
}

// ─────────────────────────────────────────────────────────────────────
// Main — formToModel
// ─────────────────────────────────────────────────────────────────────

/**
 * Transforme `InvoiceFormSchema` (15/54 champs UI) en
 * `CrossIndustryInvoice` EN 16931 EXTENDED prêt à `generateCII()`.
 *
 * @param form Formulaire validé Zod
 * @param seller Row complet du customer émetteur (depuis
 *   `findActiveCustomerById`).
 * @returns `Result<CrossIndustryInvoice, FormToModelError>` — `ok`
 *   pour succès, `err` avec un tableau d'erreurs typées sinon.
 */
export function formToModel(
  form: InvoiceForm,
  seller: CustomerRow,
): Result<CrossIndustryInvoice, FormToModelError> {
  const errors: FormToModelError[] = [];

  // Validation pré-mapping
  if (form.lines.length === 0) {
    errors.push({
      code: "EMPTY_LINES",
      message: "Au moins une ligne de facture est requise (BR-16).",
      field: "lines",
    });
  }

  // IBAN obligatoire pour virement / prélèvement (mapping vers BG-17).
  if (
    (form.payment.paymentMethodKind === "transfer" ||
      form.payment.paymentMethodKind === "direct_debit") &&
    (seller.iban === null || seller.iban === "")
  ) {
    errors.push({
      code: "INVALID_PAYMENT_METHOD_MISSING_IBAN",
      message:
        "L'IBAN de votre entreprise est requis pour ce mode de paiement. Configurez-le dans Paramètres > Entreprise.",
      field: "iban",
    });
  }

  // Cohérence catégorie TVA ↔ taux par ligne (Zod l'a déjà fait pour
  // mode base via superRefine ; on revérifie pour mode avancé qui ne
  // peut pas chaîner refine sur extend).
  for (let i = 0; i < form.lines.length; i++) {
    const l = form.lines[i];
    if (l === undefined) continue;
    const lineNum = String(i + 1);
    if (l.vatCategory === "S" && l.vatRate === null) {
      errors.push({
        code: "INVALID_VAT_RATE",
        message: `Taux TVA requis pour la ligne ${lineNum} (catégorie standard S).`,
        field: `lines.${String(i)}.vatRate`,
      });
    }
    if (l.vatCategory !== "S" && l.vatRate !== null) {
      errors.push({
        code: "INCONSISTENT_VAT_CATEGORY",
        message: `Le taux TVA doit être null pour la catégorie ${l.vatCategory} (ligne ${lineNum}).`,
        field: `lines.${String(i)}.vatRate`,
      });
    }
  }

  // Restriction A-strict (ADR-016 candidat D2) — refus mix O+S amont métier.
  const mixedVatError = validateMixedVATCategories(form);
  if (mixedVatError !== null) errors.push(mixedVatError);

  // Restriction C1 (ADR-016 candidat D3) — refus cotraitance. BT-23 non exposé
  // par le formulaire V1 → garde dormant mais canonique (cf. validateBillingMode).
  const billingModeError = validateBillingMode(undefined);
  if (billingModeError !== null) errors.push(billingModeError);

  if (errors.length > 0) return err<FormToModelError>(errors);

  // ── Construction du modèle ──────────────────────────────────────────

  const issueDateObj = new Date(`${form.document.issueDate}T00:00:00Z`);
  const docLevelCharges = buildDocumentLevelCharges(form);
  const documentAllowances = docLevelCharges.filter((a) => !a.isCharge);
  const documentCharges = docLevelCharges.filter((a) => a.isCharge);
  const vatBreakdown = aggregateVATBreakdown(form.lines, docLevelCharges);
  const prepaidAmount =
    form.ui_mode === "advanced" &&
    form.payment.prepaidAmount !== null &&
    form.payment.prepaidAmount !== undefined
      ? toNumber(form.payment.prepaidAmount)
      : 0;
  const totals = computeTotals(form.lines, docLevelCharges, vatBreakdown, prepaidAmount);
  const lineItems = form.lines.map((l, i) => buildLineItem(l, i));

  const currency = form.ui_mode === "advanced" ? form.document.currency : "EUR";
  // BT-3 — type document. Disponible dans les 2 modes depuis L11 (base :
  // optionnel, absent ⇒ 380). 381 avoir / 384 rectificative.
  const typeCode = form.document.typeCode ?? "380";
  const dueDate = computeDueDate(issueDateObj, form.payment.paymentTerms);
  const paymentTermsDesc = paymentTermsDescription(form.payment.paymentTerms);
  const includedNotes = buildIncludedNotes(form, seller);

  // BG-3 PrecedingInvoiceReference (BR-55) — lien vers la facture d'origine
  // pour un avoir (381) / rectificative (384). Les métadonnées sont portées
  // au niveau du formulaire (pré-remplies par POST /api/invoices/:id/credit-note),
  // sérialisées en `tradeSettlement.precedingInvoices` (ordre XSD : après
  // MonetarySummation) via `serializePrecedingInvoiceReference` (builder W1).
  const precedingInvoices =
    form.precedingInvoiceNumber !== null &&
    form.precedingInvoiceNumber !== undefined &&
    form.precedingInvoiceNumber !== ""
      ? [
          {
            invoiceNumber: form.precedingInvoiceNumber, // BT-25
            ...(form.precedingIssueDate !== null && form.precedingIssueDate !== undefined
              ? { issueDate: dateOf(new Date(`${form.precedingIssueDate}T00:00:00Z`)) } // BT-26
              : {}),
          },
        ]
      : undefined;

  // BG-14 BillingSpecifiedPeriod (advanced only) — pattern défensif S1
  // (cat. B `docs/standards/factur-x-1.07.3-extended-xsd-cardinalities.md` §5).
  // Le schéma Zod `billingPeriod` est `BillingPeriodSchema.nullish()` :
  // techniquement `{ startDate: null, endDate: null }` est accepté. Sans la
  // garde finale, le spread produirait `billingPeriod: {}` vide dans le
  // modèle TS (XML resterait valide via `serialize/billing-period.ts`
  // défensif retournant `null` si 2 dates undefined, mais sémantique sale).
  // La garde explicite omet la clé du modèle si aucune date n'est posée.
  let billingPeriod: CrossIndustryInvoice["tradeTransaction"]["tradeSettlement"]["billingPeriod"];
  if (
    form.ui_mode === "advanced" &&
    form.document.billingPeriod !== null &&
    form.document.billingPeriod !== undefined
  ) {
    const period: NonNullable<typeof billingPeriod> = {};
    if (
      form.document.billingPeriod.startDate !== null &&
      form.document.billingPeriod.startDate !== undefined
    ) {
      period.startDate = dateOf(new Date(`${form.document.billingPeriod.startDate}T00:00:00Z`));
    }
    if (
      form.document.billingPeriod.endDate !== null &&
      form.document.billingPeriod.endDate !== undefined
    ) {
      period.endDate = dateOf(new Date(`${form.document.billingPeriod.endDate}T00:00:00Z`));
    }
    if (period.startDate !== undefined || period.endDate !== undefined) {
      billingPeriod = period;
    }
  }

  const invoice: CrossIndustryInvoice = {
    documentContext: {
      specificationID: identifier(FACTUR_X_PROFILES.EXTENDED),
    },
    exchangedDocument: {
      invoiceNumber: form.document.number,
      invoiceTypeCode: typeCode,
      issueDate: dateOf(issueDateObj),
      ...(includedNotes.length > 0 ? { includedNotes } : {}),
    },
    tradeTransaction: {
      lineItems,
      tradeAgreement: {
        sellerTradeParty: buildSellerTradeParty(seller),
        buyerTradeParty: buildBuyerTradeParty(form),
        ...(form.ui_mode === "advanced" &&
        form.document.buyerOrderRef !== null &&
        form.document.buyerOrderRef !== undefined &&
        form.document.buyerOrderRef !== ""
          ? { buyerOrderReference: form.document.buyerOrderRef }
          : {}),
        ...(form.ui_mode === "advanced" &&
        form.document.sellerOrderRef !== null &&
        form.document.sellerOrderRef !== undefined &&
        form.document.sellerOrderRef !== ""
          ? { sellerOrderReference: form.document.sellerOrderRef }
          : {}),
        ...(form.ui_mode === "advanced" &&
        form.document.contractRef !== null &&
        form.document.contractRef !== undefined &&
        form.document.contractRef !== ""
          ? { contractReference: form.document.contractRef }
          : {}),
        // BT-X-22 INCOTERM (finding K1) — whitelist 13 codes FR validée par le
        // builder (`buildDeliveryTermsIncoterm`). null → clé omise.
        ...(form.ui_mode === "advanced" && form.incoterm !== null && form.incoterm !== undefined
          ? { incoterm: form.incoterm }
          : {}),
      },
      tradeDelivery: buildTradeDelivery(form, issueDateObj),
      tradeSettlement: {
        invoiceCurrencyCode: currency,
        vatBreakdowns: vatBreakdown,
        monetarySummation: {
          lineTotalAmount: totals.lineTotalHt,
          ...(totals.documentAllowance > 0
            ? { allowanceTotalAmount: round2(totals.documentAllowance) }
            : {}),
          ...(totals.documentCharge > 0
            ? { chargeTotalAmount: round2(totals.documentCharge) }
            : {}),
          taxBasisTotalAmount: totals.taxBasis,
          vatTotalAmount: { value: totals.vatTotal, currencyID: currency },
          grandTotalAmount: totals.grandTotal,
          ...(prepaidAmount > 0 ? { paidAmount: prepaidAmount } : {}),
          duePayableAmount: totals.duePayable,
        },
        // BT-20 omis pour `fixedDate` (redondant avec BT-9 — cf.
        // `paymentTermsDescription`). Le nœud Description n'est pas sérialisé
        // quand absent (`serialize/payment-terms.ts`).
        ...(paymentTermsDesc !== undefined ? { paymentTermsDescription: paymentTermsDesc } : {}),
        dueDate: dateOf(dueDate),
        paymentMeans: [buildPaymentMeans(form, seller)],
        ...(documentAllowances.length > 0 ? { documentAllowances } : {}),
        ...(documentCharges.length > 0 ? { documentCharges } : {}),
        ...(form.ui_mode === "advanced" &&
        form.payment.creditorReference !== null &&
        form.payment.creditorReference !== undefined &&
        form.payment.creditorReference !== ""
          ? { creditorReferenceID: identifier(form.payment.creditorReference) }
          : {}),
        ...(billingPeriod !== undefined ? { billingPeriod } : {}),
        ...(precedingInvoices !== undefined ? { precedingInvoices } : {}),
      },
    },
  };

  return ok(invoice);
}

/** Helper exposé pour les routes : extrait le `payload_extended` à
 *  stocker dans `invoices.payload_extended jsonb` — sous-ensemble du
 *  form qui n'est pas modélisé en colonnes BDD ni dans le CII XML
 *  (commentaires privés, override clientTaxRegime, transporter,
 *  trackingNumber, projectRef, custom penalties, footer mentions
 *  rendues PDF, etc.). */
export function extractPayloadExtended(form: InvoiceForm): Record<string, unknown> {
  // Le `buyer` est stocké **dans tous les modes** (base ET avancé) pour
  // que les routes `/api/invoices/:id/{xml,pdf}` puissent reconstituer
  // l'identité du client après envoi via `_reconstruct.ts`. Sans cette
  // entrée, la reconstruction tombait sur le fallback `"Inconnu" /
  // "000000000"` (cf. recette FORM 2026-05-19) qui faisait apparaître
  // une facture émise sans identification du destinataire dans la
  // fiche LIST et l'aperçu post-envoi.
  const buyer = form.parties.buyer;
  // Bloc paiement regroupé persisté **dans tous les modes** (base ET
  // avancé) pour que `_reconstruct.ts` régénère le document avec le moyen
  // / les termes / les mentions LME réellement saisis — sans ça la
  // reconstruction hardcodait `transfer`/30j/null (finding G sprint-07),
  // faisant apparaître « virement à 30 jours » sur toute facture régénérée
  // et provoquant un 500 `INVALID_PAYMENT_METHOD_MISSING_IBAN` sur une
  // facture chèque émise par un vendeur sans IBAN. Sous-objet uniforme
  // limité aux 3 champs cœur portés par le schéma base — suffisant pour la
  // reconstruction `ui_mode:"base"`. AUCUN IBAN/BIC ici (ADR-008 — l'IBAN
  // reste un secret chiffré côté `customers.iban`, ré-sourcé depuis
  // `seller` à la reconstruction).
  const payment = {
    paymentTerms: form.payment.paymentTerms,
    paymentMethodKind: form.payment.paymentMethodKind,
    mentionsLegales: form.payment.mentionsLegales ?? null,
  };
  // Champs communs aux 2 modes nécessaires à une reconstruction fidèle
  // (T-CL-RECONSTRUCT-FIDELE-F8). `ui_mode` est persisté pour que
  // `_reconstruct.ts` régénère un form de la bonne forme (base vs avancé —
  // le schéma base ne porte pas les champs avancés). `notes` (BT-22 zone
  // publique, F3) était perdu dans les 2 modes. BG-3 (BT-25/26) : le numéro
  // / la date d'origine ne sont pas en colonne (seul `preceding_invoice_id`
  // l'est) → persistés ici (ZG-4) pour réinjection sans lookup de l'origine.
  const notes = form.document.notes ?? null;
  const precedingInvoiceNumber = form.precedingInvoiceNumber ?? null;
  const precedingIssueDate = form.precedingIssueDate ?? null;
  if (form.ui_mode === "base") {
    return {
      ui_mode: "base",
      buyer,
      payment,
      notes,
      precedingInvoiceNumber,
      precedingIssueDate,
    };
  }
  return {
    ui_mode: "advanced",
    buyer,
    payment,
    notes,
    precedingInvoiceNumber,
    precedingIssueDate,
    buyerOrderRef: form.document.buyerOrderRef ?? null,
    sellerOrderRef: form.document.sellerOrderRef ?? null,
    contractRef: form.document.contractRef ?? null,
    projectRef: form.document.projectRef ?? null,
    billingPeriod: form.document.billingPeriod ?? null,
    privateComments: form.document.privateComments ?? null,
    footerMentions: form.document.footerMentions ?? null,
    generalComments: form.document.generalComments ?? null,
    clientTaxRegime: form.parties.clientTaxRegime,
    transporter: form.parties.transporter ?? null,
    trackingNumber: form.parties.trackingNumber ?? null,
    shipping: form.parties.shipping ?? null,
    deliveryDate: form.parties.deliveryDate ?? null,
    documentLevelAllowance: form.documentLevelAllowance ?? null,
    // BG-21 frais de port + BT-X-22 INCOTERM : top-level du form avancé,
    // dans les `roundTripFields` (fx-380-adv-riche) mais non persistés
    // jusqu'ici → réinjection impossible. Ajoutés (T-CL-RECONSTRUCT-FIDELE-F8).
    shippingCostHt: form.shippingCostHt ?? null,
    shippingCostVatCategory: form.shippingCostVatCategory ?? null,
    shippingCostVatRate: form.shippingCostVatRate ?? null,
    incoterm: form.incoterm ?? null,
    paymentMeansCode: form.payment.paymentMeansCode ?? null,
    creditorReference: form.payment.creditorReference ?? null,
    prepaidAmount: form.payment.prepaidAmount ?? null,
    customPenalties: form.payment.customPenalties ?? null,
  };
}
