import type postgres from "postgres";

import type { ConnectedCompany, ConnectedCompanyAddress } from "@factur-e/pa-adapter";

import { writeAuthAudit } from "../auth/audit.js";
import * as customersRepo from "../db/repos/customers.js";
import { countActiveInvoicesByCustomer } from "../db/repos/invoices.js";
import { countReceivedInvoicesByCustomer } from "../db/repos/received_invoices.js";

/**
 * Mécanisme 3 — réconciliation SIREN onboarding ↔ société attestée KYC
 * (T-CL-SIREN-RECONCILIATION sprint-06 W1, ADR-007ter candidat ; US-PA-005
 * PRD v1.7 §5.3).
 *
 * Au callback OAuth SuperPDP `verified` (et à chaque bascule `verified`
 * observée par le polling), on compare `customers.siren` (saisi onboarding
 * INSEE) au SIREN attesté de la société connectée — `GET /v1.beta/
 * companies/me` (`company.number`, cf. fix companies/me). Si mismatch :
 *
 *  - **Historique de factures (émises OU reçues) en base** → **BLOCAGE** :
 *    on ne change RIEN. La société attestée diffère de l'établissement
 *    ayant déjà une activité Factur-E → un changement de SIREN corromprait
 *    l'historique (CDAR, archivage légal). L'utilisateur doit supprimer son
 *    historique ou créer un nouveau compte. Audit
 *    `pa_identity_siren_reconcile_blocked`. (Règle actée Bruno sprint-06 —
 *    pas d'US dédiée, à formaliser PMO. Le message bloquant est rendu côté
 *    UI PaConnection.)
 *  - **Aucune facture** → réconciliation priorité KYC (Z2 hard-switch) +
 *    **réinitialisation des informations de description d'entreprise**
 *    liées à l'ancien SIREN (Option B Bruno — éviter toute incohérence) via
 *    `applyReconciledCompany`. Audit `pa_identity_siren_reconciled`.
 *
 * Lève proprement le workaround `psql UPDATE customers SET siren=...`
 * historique des recettes T-BR-EMIT sandbox (NC-13 sprint-04).
 *
 * **Idempotence applicative** (Z3 — pas de UNIQUE BDD, ADR-009 D4) :
 * réconciliation/blocage seulement sur mismatch réel ; un re-jeu identique
 * (cycle régressif sans changement) est un no-op sans event.
 *
 * **Fail-safe** (ADR-009) : si la PA ne retourne pas de SIREN attesté
 * (`company.siren === null`), on ne déclenche rien. Le callback OAuth ne
 * doit jamais échouer à cause de la réconciliation.
 */

export type ReconcileStatus = "no_op" | "reconciled" | "blocked";

export interface ReconcileResult {
  status: ReconcileStatus;
  /** SIREN à utiliser en aval (ex. re-résolution Peppol émetteur) : le
   *  nouveau si réconcilié, le courant sinon. `null` si customer absent. */
  effectiveSiren: string | null;
  valueBefore?: string;
  valueAfter?: string;
  /** Détail du blocage (status="blocked") — consommé par le callback OAuth
   *  pour l'audit `pa_connection_blocked_cleanup` de la déconnexion
   *  programmatique (finding F sprint-07, ADR-017 D5). */
  blocked?: {
    customerSiren: string;
    kycSiren: string;
    emittedInvoices: number;
    receivedInvoices: number;
  };
}

/** Mappe l'adresse `companies/me` vers le format `customers.address`
 *  (`{ line_one, postcode, city, country_code }`). `null` si absente. */
function mapCompanyAddress(address: ConnectedCompanyAddress | null): postgres.JSONValue | null {
  if (address === null) return null;
  return {
    line_one: address.line,
    postcode: address.postcode,
    city: address.city,
    country_code: address.country,
  };
}

export async function reconcileCustomerIdentity(args: {
  sql: postgres.Sql;
  customerId: string;
  company: Pick<ConnectedCompany, "siren" | "formalName" | "address">;
}): Promise<ReconcileResult> {
  const { sql, customerId, company } = args;

  const current = await customersRepo.findCustomerSirenById(sql, customerId);
  if (current === undefined) return { status: "no_op", effectiveSiren: null };

  // Fail-safe : pas de SIREN attesté → rien à réconcilier.
  const kycSiren = company.siren;
  if (kycSiren === null || kycSiren === "") {
    return { status: "no_op", effectiveSiren: current.siren };
  }

  // Pas de mismatch → no-op (US-PA-005 crit. 7).
  if (current.siren === kycSiren) {
    return { status: "no_op", effectiveSiren: current.siren };
  }

  // Mismatch — règle de blocage : interdit si historique de factures
  // (émises OU reçues) en base.
  const [emitted, received] = await Promise.all([
    countActiveInvoicesByCustomer(sql, customerId),
    countReceivedInvoicesByCustomer(sql, customerId),
  ]);
  if (emitted > 0 || received > 0) {
    await writeAuthAudit(sql, {
      event_type: "pa_identity_siren_reconcile_blocked",
      success: false,
      customer_id: customerId,
      metadata: {
        siren_before: current.siren,
        siren_after: kycSiren,
        emitted_invoices: emitted,
        received_invoices: received,
        reason: "has_invoice_history",
      },
    });
    return {
      status: "blocked",
      effectiveSiren: current.siren,
      blocked: {
        customerSiren: current.siren,
        kycSiren,
        emittedInvoices: emitted,
        receivedInvoices: received,
      },
    };
  }

  // Réconciliation + réinitialisation des infos d'entreprise (Option B).
  const updated = await customersRepo.applyReconciledCompany(sql, customerId, {
    newSiren: kycSiren,
    legalName: company.formalName,
    address: mapCompanyAddress(company.address),
  });
  if (updated === 0) return { status: "no_op", effectiveSiren: current.siren };

  // Event audit `pa_identity_siren_reconciled` — payload US-PA-005 crit. 4
  // ({field, value_before, value_after, kyc_source}) + `fields_reset` pour
  // tracer la réinitialisation des descripteurs entreprise (Option B).
  await writeAuthAudit(sql, {
    event_type: "pa_identity_siren_reconciled",
    success: true,
    customer_id: customerId,
    metadata: {
      field: "siren",
      value_before: current.siren,
      value_after: kycSiren,
      kyc_source: "superpdp",
      fields_reset: [
        "legal_name",
        "address",
        "trading_name",
        "naf_code",
        "rcs",
        "juridique_code",
        "capital_social",
        "vat_number",
        "directory_address",
      ],
    },
  });

  return {
    status: "reconciled",
    effectiveSiren: kycSiren,
    valueBefore: current.siren,
    valueAfter: kycSiren,
  };
}
