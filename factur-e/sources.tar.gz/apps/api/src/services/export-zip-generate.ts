import { Buffer } from "node:buffer";
import { createHash } from "node:crypto";

import JSZip from "jszip";
import type postgres from "postgres";

import {
  extractEmbeddedXml,
  generateCII,
  renderInvoicePdfFromModel,
} from "@factur-e/factur-x-builder";
import { FX_CONFORMANCE_LEVELS } from "@factur-e/factur-x-model";
import type { CustomerContext, PADriver } from "@factur-e/pa-adapter";
import type { ExportFilters, ExportScope } from "@factur-e/shared-schemas";

import { writeAuthAudit } from "../auth/audit.js";
import { findActiveCustomerById, type CustomerRow } from "../db/repos/customers.js";
import { findCdarEventsByInvoiceId } from "../db/repos/cdar_events.js";
import {
  findExportRequestById,
  markExportCompleted,
  markExportFailed,
  markExportProcessing,
} from "../db/repos/export_requests.js";
import { findIncomingCdarEventsByReceivedInvoiceId } from "../db/repos/incoming_cdar_events.js";
import { findLinesByInvoiceId } from "../db/repos/invoice_lines.js";
import { findInvoiceByIdAndCustomer } from "../db/repos/invoices.js";
import { findActivePaConnectionForDisconnectByCustomerId } from "../db/repos/pa_connections.js";
import { getReceivedInvoiceById } from "../db/repos/received_invoices.js";
import { findUserEmailById } from "../db/repos/users.js";
import type { EmailSender } from "../email/sender.js";
import {
  reconstructFormFromPersisted,
  reconstructInvoiceModel,
} from "../routes/invoices/_reconstruct.js";
import type { ObjectStorage } from "../storage/object-storage.js";
import { buildSellerEnrichment, footerLineFor } from "./pdf-enrichment.js";

/**
 * Service pur de génération d'archive ZIP (T-CL-EXPORT-ZIP-RETENTION L12).
 * Appelé par le worker pgboss `export-zip-generate` ET directement par les
 * tests (pas de pgboss en test, cf. §8).
 *
 * C1 (validé Bruno) : il n'existe PAS de bucket S3 émission — les PDF/XML des
 * factures émises sont RÉGÉNÉRÉS à la volée (`_reconstruct` + builder, Q3
 * acté), pas téléchargés.
 * C2 (validé Bruno) : les factures reçues sont téléchargées depuis la PA
 * (`downloadInvoiceFile`, pas de param docType) ; le XML structuré est extrait
 * du PDF Factur-X embarqué (`extractEmbeddedXml`) ou passthrough si XML pur.
 *
 * Robustesse : une erreur PAR FACTURE est notée dans `manifest.json` (`error`)
 * et n'interrompt pas l'archive (ADR-009 fail-safe). Une erreur d'infra (upload
 * S3, DB) propage → pgboss retry 3 (le statut `failed` est posé avant de
 * re-throw pour visibilité immédiate côté UI).
 */

export interface ExportZipGenerateDeps {
  sql: postgres.Sql;
  exportsStorage: ObjectStorage;
  paDriver: PADriver;
  secrets: {
    get(
      secretRef: string,
    ): Promise<{ accessToken: string; refreshToken: string; accessExpiresAt: string } | null>;
  };
  email: EmailSender;
  /** Base URL SPA (same-origin proxy ADR-014) pour le lien download email. */
  webBaseUrl: string;
}

export interface ExportZipGenerateInput {
  exportRequestId: string;
}

interface ManifestInvoiceEntry {
  id: string;
  scope: "emission" | "reception";
  number: string | null;
  date: string | null;
  type_code: string | null;
  hash_pdf_sha256: string | null;
  hash_xml_sha256: string | null;
  files: string[];
  error?: string;
}

interface Manifest {
  exported_at: string;
  count: number;
  scope: ExportScope;
  filters: ExportFilters;
  invoices: ManifestInvoiceEntry[];
}

const sha256 = (buf: Buffer): string => createHash("sha256").update(buf).digest("hex");

/** Segment de chemin sûr dans le ZIP (numéro de facture → dossier). */
const safeSegment = (raw: string): string => raw.replace(/[^\w\-.]+/g, "_");

const isPdf = (contentType: string): boolean => contentType.toLowerCase().includes("pdf");
const isXml = (contentType: string): boolean => contentType.toLowerCase().includes("xml");

export async function runExportZipGenerate(
  deps: ExportZipGenerateDeps,
  input: ExportZipGenerateInput,
): Promise<void> {
  const { sql } = deps;
  const request = await findExportRequestById(sql, input.exportRequestId);
  if (request === undefined) {
    throw new Error(`export_request ${input.exportRequestId} introuvable`);
  }
  // Idempotence : un re-run pgboss sur un export déjà finalisé ne refait rien.
  if (request.status === "completed" || request.status === "purged") return;

  await markExportProcessing(sql, request.id);

  try {
    const seller = await findActiveCustomerById(sql, request.customer_id);
    if (seller === undefined) {
      throw new Error(`customer ${request.customer_id} introuvable`);
    }

    // Contexte PA chargé paresseusement (seulement si une facture reçue est
    // matchée). Réutilise le pattern routes/received-invoices/_shared.
    let paCtx: CustomerContext | null | undefined;
    const loadPaCtx = async (): Promise<CustomerContext | null> => {
      if (paCtx !== undefined) return paCtx;
      const conn = await findActivePaConnectionForDisconnectByCustomerId(sql, request.customer_id);
      if (conn === undefined) {
        paCtx = null;
        return null;
      }
      const bundle = await deps.secrets.get(conn.secret_ref);
      if (bundle === null) {
        paCtx = null;
        return null;
      }
      paCtx = {
        customerId: request.customer_id,
        credentials: {
          kind: "superpdp-oauth-ac",
          accessToken: bundle.accessToken,
          refreshToken: bundle.refreshToken,
          accessExpiresAt: new Date(bundle.accessExpiresAt),
          paUserId: null,
        },
      };
      return paCtx;
    };

    const zip = new JSZip();
    const manifestEntries: ManifestInvoiceEntry[] = [];
    const exportedEmissionIds: string[] = [];
    const exportedReceptionIds: string[] = [];

    for (const id of request.invoice_ids) {
      // Les id émission et reçue sont disjoints (gen_random_uuid distinct).
      const emission = await findInvoiceByIdAndCustomer(sql, {
        id,
        customerId: request.customer_id,
      });
      if (emission !== undefined) {
        const entry = await buildEmissionEntry(deps, seller, emission, zip);
        manifestEntries.push(entry);
        if (entry.error === undefined) exportedEmissionIds.push(id);
        continue;
      }
      const reception = await getReceivedInvoiceById(sql, id, request.customer_id);
      if (reception !== undefined) {
        const entry = await buildReceptionEntry(deps, loadPaCtx, reception, zip);
        manifestEntries.push(entry);
        if (entry.error === undefined) exportedReceptionIds.push(id);
        continue;
      }
      // Facture soft-deletée entre la demande et la génération → ignorée.
    }

    const manifest: Manifest = {
      exported_at: new Date().toISOString(),
      count: manifestEntries.length,
      scope: request.scope,
      filters: request.filters,
      invoices: manifestEntries,
    };
    zip.file("manifest.json", Buffer.from(JSON.stringify(manifest, null, 2), "utf8"));

    const zipBuffer = await zip.generateAsync({
      type: "nodebuffer",
      compression: "DEFLATE",
      compressionOptions: { level: 9 },
    });

    const fileKey = `exports/${request.customer_id}/${request.id}.zip`;
    await deps.exportsStorage.uploadObject({
      key: fileKey,
      body: zipBuffer,
      contentType: "application/zip",
    });

    await markExportCompleted(sql, {
      id: request.id,
      fileKey,
      fileSizeBytes: zipBuffer.length,
    });

    // exported_at sur les factures incluses (alimente RetentionStatusBadge).
    if (exportedEmissionIds.length > 0) {
      await sql`UPDATE invoices SET exported_at = NOW() WHERE id = ANY(${exportedEmissionIds}::uuid[])`;
    }
    if (exportedReceptionIds.length > 0) {
      await sql`UPDATE received_invoices SET exported_at = NOW() WHERE id = ANY(${exportedReceptionIds}::uuid[])`;
    }

    await writeAuthAudit(sql, {
      event_type: "export_zip_generated",
      success: true,
      customer_id: request.customer_id,
      user_id: request.requested_by_user_id,
      metadata: { export_id: request.id, count: manifest.count },
    });

    // Email "export prêt" — lien vers l'endpoint app (presigned fresh + 302),
    // accessible 7 jours (Z5). Dégradation gracieuse ADR-009 : si TEM échoue,
    // l'export reste `completed` (le bandeau/page restent le signal).
    const requester = await findUserEmailById(sql, request.requested_by_user_id);
    const to = requester?.email;
    if (to !== undefined) {
      try {
        await deps.email.send({
          to,
          purpose: "export_ready",
          payload: {
            magic_link: `${deps.webBaseUrl}/api/exports/${request.id}/download`,
            vars: { count: String(manifest.count) },
          },
        });
      } catch {
        // signal non bloquant — l'export est prêt, l'email est best-effort.
      }
    }
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    await markExportFailed(sql, { id: request.id, errorMessage: message });
    await writeAuthAudit(sql, {
      event_type: "export_zip_failed",
      success: false,
      customer_id: request.customer_id,
      user_id: request.requested_by_user_id,
      metadata: { export_id: request.id, error: message },
    });
    throw err;
  }
}

/** Émission : régénère PDF + XML à la volée (C1) + events CDAR émission. */
async function buildEmissionEntry(
  deps: ExportZipGenerateDeps,
  seller: CustomerRow,
  invoice: NonNullable<Awaited<ReturnType<typeof findInvoiceByIdAndCustomer>>>,
  zip: JSZip,
): Promise<ManifestInvoiceEntry> {
  const dir = safeSegment(invoice.number);
  const date = invoice.issue_date.toISOString().slice(0, 10);
  try {
    const lines = await findLinesByInvoiceId(deps.sql, invoice.id);
    const mapping = reconstructInvoiceModel(reconstructFormFromPersisted(invoice, lines), seller);
    if (!mapping.ok) {
      return {
        id: invoice.id,
        scope: "emission",
        number: invoice.number,
        date,
        type_code: invoice.type_code,
        hash_pdf_sha256: null,
        hash_xml_sha256: null,
        files: [],
        error: "reconstruction_failed",
      };
    }
    const xml = generateCII(mapping.value);
    const xmlBuffer = Buffer.from(xml, "utf8");
    // Enrichissement texte seul (Capital social / RCS / forme juridique) — le
    // service d'export n'a pas le stockage logos dans ses deps (logo = nice-to-
    // have V1, rendu sans image ; raison sociale en fallback texte).
    const pdfBytes = await renderInvoicePdfFromModel({
      invoice: mapping.value,
      xmlBytes: xmlBuffer,
      conformanceLevel: FX_CONFORMANCE_LEVELS.EXTENDED,
      generationDate: invoice.submitted_at ?? invoice.created_at,
      enrichment: buildSellerEnrichment(seller),
      footerLine: footerLineFor(seller),
    });
    const pdfBuffer = Buffer.from(pdfBytes);
    const events = await findCdarEventsByInvoiceId(deps.sql, invoice.id);

    zip.file(`${dir}/lisible.pdf`, pdfBuffer);
    zip.file(`${dir}/original.xml`, xmlBuffer);
    zip.file(`${dir}/cdar-events.json`, Buffer.from(JSON.stringify(events, null, 2), "utf8"));
    return {
      id: invoice.id,
      scope: "emission",
      number: invoice.number,
      date,
      type_code: invoice.type_code,
      hash_pdf_sha256: sha256(pdfBuffer),
      hash_xml_sha256: sha256(xmlBuffer),
      files: [`${dir}/lisible.pdf`, `${dir}/original.xml`, `${dir}/cdar-events.json`],
    };
  } catch (err) {
    return {
      id: invoice.id,
      scope: "emission",
      number: invoice.number,
      date,
      type_code: invoice.type_code,
      hash_pdf_sha256: null,
      hash_xml_sha256: null,
      files: [],
      error: err instanceof Error ? err.message : "generation_failed",
    };
  }
}

/** Reçue : download PA (C2) → lisible.pdf si PDF, original.xml extrait/passthrough. */
async function buildReceptionEntry(
  deps: ExportZipGenerateDeps,
  loadPaCtx: () => Promise<CustomerContext | null>,
  row: NonNullable<Awaited<ReturnType<typeof getReceivedInvoiceById>>>,
  zip: JSZip,
): Promise<ManifestInvoiceEntry> {
  const number = row.invoice_number_extracted ?? row.id;
  const dir = safeSegment(number);
  const date = row.issue_date?.toISOString().slice(0, 10) ?? null;
  const base: ManifestInvoiceEntry = {
    id: row.id,
    scope: "reception",
    number: row.invoice_number_extracted,
    date,
    type_code: null,
    hash_pdf_sha256: null,
    hash_xml_sha256: null,
    files: [],
  };
  try {
    const ctx = await loadPaCtx();
    if (ctx === null) {
      return { ...base, error: "pa_not_connected" };
    }
    const file = await deps.paDriver.downloadInvoiceFile(
      { paInvoiceId: row.pa_invoice_id_in },
      ctx,
    );
    const fileBuffer = Buffer.from(file.bytes);
    const files: string[] = [];
    let hashPdf: string | null = null;
    let hashXml: string | null = null;

    let xmlBuffer: Buffer | null = null;
    if (isPdf(file.contentType)) {
      zip.file(`${dir}/lisible.pdf`, fileBuffer);
      files.push(`${dir}/lisible.pdf`);
      hashPdf = sha256(fileBuffer);
      // Extraction best-effort : un PDF non-Factur-X (sans pièce jointe XML)
      // ne fait pas échouer l'entrée — le PDF lisible reste inclus.
      try {
        const embedded = await extractEmbeddedXml(new Uint8Array(fileBuffer));
        if (embedded !== null) xmlBuffer = Buffer.from(embedded, "utf8");
      } catch {
        // pas de XML extractible
      }
    } else if (isXml(file.contentType)) {
      xmlBuffer = fileBuffer;
    }
    if (xmlBuffer !== null) {
      zip.file(`${dir}/original.xml`, xmlBuffer);
      files.push(`${dir}/original.xml`);
      hashXml = sha256(xmlBuffer);
    }

    const events = await findIncomingCdarEventsByReceivedInvoiceId(deps.sql, row.id);
    zip.file(`${dir}/cdar-events.json`, Buffer.from(JSON.stringify(events, null, 2), "utf8"));
    files.push(`${dir}/cdar-events.json`);

    return { ...base, hash_pdf_sha256: hashPdf, hash_xml_sha256: hashXml, files };
  } catch (err) {
    return { ...base, error: err instanceof Error ? err.message : "download_failed" };
  }
}
