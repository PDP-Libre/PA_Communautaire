// Construit l'enrichissement PDF (`PdfEnrichment`) consommé par
// `renderInvoicePdfFromModel` à partir de la row `customers` — champs ABSENTS
// du modèle CII mais requis au PDF lisible (Axe B sprint-07 V2) :
//   - Capital social (`customers.capital_social`) — affiché si présent.
//   - RCS (`customers.rcs`).
//   - Forme juridique — libellé résolu depuis `customers.juridique_code`.
//   - Logo (`customers.logo_s3_key`) — PNG embarqué ; SVG → fallback texte
//     (pdf-lib ne supporte pas SVG nativement — ZG-B3 Option A).
//
// Le builder n'accède pas à la BDD ni au stockage objet : c'est `apps/api` qui
// résout ces données et les passe au moteur de template.

import type { FastifyBaseLogger } from "fastify";

import type { PdfEnrichment, PdfLogo } from "@factur-e/factur-x-builder";

import type { CustomerRow } from "../db/repos/customers.js";
import { juridiqueLabel } from "../onboarding/juridique-codes.js";
import type { ObjectStorage } from "../storage/object-storage.js";

/** Enrichissement texte (synchrone) — Capital social / RCS / forme juridique. */
export function buildSellerEnrichment(seller: CustomerRow): PdfEnrichment {
  const label = seller.juridique_code !== null ? juridiqueLabel(seller.juridique_code) : null;
  return {
    seller: {
      rcs: seller.rcs,
      // "Forme juridique inconnue" (fallback du helper) → non affiché.
      juridiqueLabel: label !== null && label !== "Forme juridique inconnue" ? label : null,
      capitalSocial: seller.capital_social,
    },
  };
}

/** Télécharge le logo S3 et le typifie pour pdf-lib. PNG/JPEG only ; sinon undefined. */
async function loadLogo(
  storage: ObjectStorage,
  key: string,
  log?: FastifyBaseLogger,
): Promise<PdfLogo | undefined> {
  try {
    const { body, contentType } = await storage.downloadObject(key);
    if (contentType === "image/png") return { bytes: new Uint8Array(body), format: "png" };
    if (contentType === "image/jpeg" || contentType === "image/jpg") {
      return { bytes: new Uint8Array(body), format: "jpeg" };
    }
    // SVG ou type non supporté pdf-lib → fallback raison sociale texte.
    return undefined;
  } catch (e) {
    // ADR-009 fail-safe : un logo inaccessible ne casse pas la génération PDF.
    log?.warn(
      { key, error: e instanceof Error ? e.message : String(e) },
      "[pdf] logo indisponible",
    );
    return undefined;
  }
}

/** Enrichissement complet (texte + logo). À utiliser dans les routes (app.storage). */
export async function buildPdfEnrichment(
  seller: CustomerRow,
  storage: ObjectStorage,
  log?: FastifyBaseLogger,
): Promise<PdfEnrichment> {
  const base = buildSellerEnrichment(seller);
  const logo =
    seller.logo_s3_key !== null ? await loadLogo(storage, seller.logo_s3_key, log) : undefined;
  return { ...base, logo };
}

/** Ligne de pied de page répétée (raison sociale émetteur). */
export function footerLineFor(seller: CustomerRow): string {
  return seller.legal_name;
}
