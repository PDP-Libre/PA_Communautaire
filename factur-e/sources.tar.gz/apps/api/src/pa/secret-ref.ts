/**
 * `secret_ref` convention helper for SuperPDP token bundles. Cohérent
 * avec ADR-005 D9 + CLAUDE.md §11.1.
 *
 * Forme du `secret_ref` :
 *  - dev / test : `superpdp-bundle-{customer_id}` (Keychain account fixe
 *    `factur-e`, service = ce string).
 *  - staging / prod : `/factur-e/{staging|prod}/superpdp/{customer_id}/bundle`
 *    (Scaleway Secret Manager path hiérarchique).
 *
 * Le caller (route + jobs) demande le ref ici plutôt que le bake en dur,
 * pour que le swap dev → staging → prod soit transparent côté code.
 */

export function paSecretRef(args: { customerId: string; provider?: "superpdp" }): string {
  const provider = args.provider ?? "superpdp";
  const env = process.env.NODE_ENV;
  if (env === "production") {
    return `/factur-e/prod/${provider}/${args.customerId}/bundle`;
  }
  if (env === "staging") {
    return `/factur-e/staging/${provider}/${args.customerId}/bundle`;
  }
  return `${provider}-bundle-${args.customerId}`;
}

/** Compute the redirect URI for SuperPDP OAuth callback. The env var
 *  `SUPERPDP_REDIRECT_URI` overrides — useful when the API is fronted
 *  by a tunnel (LAN dev, ngrok for testing) or when SuperPDP partner
 *  has registered a specific URL. Default points to localhost:3001 in
 *  dev. T-BR-01 sprint-03 configures the prod redirect in SuperPDP's
 *  partner UI. */
export function superpdpRedirectUri(): string {
  const override = process.env.SUPERPDP_REDIRECT_URI;
  if (typeof override === "string" && override !== "") return override;
  if (process.env.NODE_ENV === "production") {
    throw new Error("[oauth] SUPERPDP_REDIRECT_URI is required in production.");
  }
  return "http://localhost:3001/oauth/superpdp/callback";
}

/** Compute the SPA URL where the callback redirects the user after the
 *  OAuth dance. Reads `WEB_BASE_URL` (the SPA origin) and points to
 *  `/parametres/connexion-pa` with a `status` query param. */
export function paConnectionUiUrl(args: {
  // `disconnected` : déconnexion programmatique côté serveur (finding F
  // sprint-07, blocage SIREN historique) — la SPA l'interprète déjà comme
  // un état déconnecté (cf. PaConnection.tsx) ; le type l'expose désormais.
  status: "connected" | "needs_review" | "rejected" | "error" | "disconnected";
  reason?: string;
  /** T-CL-SIREN-RECONCILIATION sprint-06 W1 — issue de la réconciliation
   *  SIREN au callback : `reconciled` (SIREN mis à jour + infos entreprise
   *  réinitialisées → Toast info) ou `blocked` (mismatch + historique de
   *  factures → Alert bloquant). Absent = pas de réconciliation. */
  siren?: "reconciled" | "blocked";
}): string {
  const webBase = process.env.WEB_BASE_URL ?? "http://localhost:5174";
  // WEB_BASE_URL may be a comma-separated list (CORS) — pick the first.
  const first = webBase.split(",")[0]?.trim() ?? "http://localhost:5174";
  const params = new URLSearchParams({ status: args.status });
  if (args.reason !== undefined) params.set("reason", args.reason);
  if (args.siren !== undefined) params.set("siren", args.siren);
  return `${first}/parametres/connexion-pa?${params.toString()}`;
}
