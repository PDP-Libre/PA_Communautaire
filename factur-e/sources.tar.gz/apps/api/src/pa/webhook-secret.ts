import { spawn } from "node:child_process";

/**
 * `getWebhookSecret` — récupère le secret HMAC partagé pour vérifier
 * les webhooks PA entrants. Source selon environnement (CLAUDE.md §11.1) :
 *
 *  - **Test** : valeur fixe `process.env.SUPERPDP_WEBHOOK_SECRET` si
 *    définie, sinon throw. Les tests passent directement la valeur
 *    via env var au boot de `buildApp`.
 *  - **Dev (macOS)** : lit Keychain via `security find-generic-password
 *    -a factur-e -s <secret_ref>`. Convention `secret_ref` :
 *    `superpdp-webhook-secret` (string brut, **pas** `PaTokenBundle` —
 *    distinct du store sprint-03 qui sérialise des tokens OAuth JSON).
 *  - **Prod** : lit Scaleway Secret Manager via wrapper dédié quand
 *    `SUPERPDP_WEBHOOK_SECRET_REF` pointe sur un path
 *    `/factur-e/prod/superpdp/webhook-secret`. **Pas encore wired** —
 *    Bruno provisionne T-BR-EMIT quand SuperPDP partenaire livrera le
 *    vrai secret. Pour la promotion staging/prod, voir
 *    `docs/operations/oauth-tokens.md`.
 *
 * Cache mémoire process-wide : le secret est lu une fois au premier
 * accès puis mis en cache. Si une rotation est faite côté ops (rare),
 * il faut redémarrer le process. Acceptable : la rotation HMAC PA n'est
 * pas un cas d'usage fréquent.
 *
 * Pour les tests d'intégration HTTP webhook : passer
 * `SUPERPDP_WEBHOOK_SECRET=<valeur>` au scope du test, ou utiliser
 * `setWebhookSecretForTests(secret)` ci-dessous pour injecter
 * programmatiquement.
 *
 * cf. ADR-009 D5 audit `pa_webhook_signature_invalid` si la vérif KO.
 */

const KEYCHAIN_ACCOUNT = "factur-e";
const DEFAULT_SECRET_REF = "superpdp-webhook-secret";

let cached: string | null = null;
let cachedSource: "env" | "keychain" | "test-override" | null = null;

export function getWebhookSecretRef(): string {
  return process.env.SUPERPDP_WEBHOOK_SECRET_REF ?? DEFAULT_SECRET_REF;
}

export async function getWebhookSecret(): Promise<string> {
  if (cached !== null) return cached;

  // Test / dev override via env — tests injectent ainsi sans toucher
  // au Keychain réel de la machine.
  const envValue = process.env.SUPERPDP_WEBHOOK_SECRET;
  if (typeof envValue === "string" && envValue !== "") {
    cached = envValue;
    cachedSource = "env";
    return cached;
  }

  // Production : aujourd'hui pas wired. Le `[NOTE-COWORK]` trace.md
  // T-CL-PA-EXT acte la promotion T-BR-EMIT future. En attendant, on
  // throw pour ne pas démarrer en silence avec un secret indéfini.
  if (process.env.NODE_ENV === "production") {
    throw new Error(
      "[webhook-secret] SUPERPDP_WEBHOOK_SECRET not set in production " +
        "(promotion T-BR-EMIT pending — cf. docs/operations/oauth-tokens.md).",
    );
  }

  // Dev macOS : lecture Keychain. Le secret ref par défaut est
  // `superpdp-webhook-secret` — Bruno provisionne en saisie interactive
  // (`security add-generic-password -a factur-e -s superpdp-webhook-secret`).
  if (process.platform === "darwin") {
    const secretRef = getWebhookSecretRef();
    const result = await runSecurity([
      "find-generic-password",
      "-a",
      KEYCHAIN_ACCOUNT,
      "-s",
      secretRef,
      "-w",
    ]);
    if (result.exitCode === 0) {
      const raw = result.stdout.trim();
      if (raw !== "") {
        cached = raw;
        cachedSource = "keychain";
        return cached;
      }
    }
    // 44 = errSecItemNotFound — Bruno n'a pas encore provisionné.
    if (result.exitCode === 44) {
      throw new Error(
        `[webhook-secret] Keychain item '${secretRef}' not found. ` +
          "Provision via: security add-generic-password -a factur-e -s " +
          `${secretRef} (saisie interactive).`,
      );
    }
    throw new Error(
      `[webhook-secret] Keychain read failed (${secretRef}): exit ${String(result.exitCode)}`,
    );
  }

  throw new Error(
    "[webhook-secret] No source configured. Set SUPERPDP_WEBHOOK_SECRET in env " +
      "or provision Keychain (macOS dev) / Scaleway Secret Manager (prod).",
  );
}

/** Test helper — injecte le secret en cache sans toucher au Keychain. */
export function setWebhookSecretForTests(secret: string): void {
  cached = secret;
  cachedSource = "test-override";
}

/** Test helper — invalide le cache (entre 2 suites). */
export function resetWebhookSecretCache(): void {
  cached = null;
  cachedSource = null;
}

/** Debug helper — source d'où vient le secret en mémoire. */
export function getWebhookSecretSource(): string | null {
  return cachedSource;
}

interface SpawnResult {
  exitCode: number;
  stdout: string;
  stderr: string;
}

function runSecurity(args: readonly string[]): Promise<SpawnResult> {
  return new Promise((resolve, reject) => {
    const child = spawn("security", args, { stdio: ["pipe", "pipe", "pipe"] });
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (chunk: Buffer) => {
      stdout += chunk.toString("utf8");
    });
    child.stderr.on("data", (chunk: Buffer) => {
      stderr += chunk.toString("utf8");
    });
    child.on("error", reject);
    child.on("close", (code) => {
      resolve({ exitCode: code ?? -1, stdout, stderr });
    });
    child.stdin.end();
  });
}
