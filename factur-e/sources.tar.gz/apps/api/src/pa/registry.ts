import {
  EsaLinkDriver,
  SuperPDPDriver,
  UnknownProviderException,
  type EsaLinkDriverConfig,
  type PADriverCore,
  type SuperPDPDriverConfig,
} from "@factur-e/pa-adapter";

/**
 * Registry des providers PA — feature flag gating (ADR-012 D8).
 *
 * **V1 SuperPDP** : toujours activé (provider primary historique
 * sprint-03). Aucune env var n'est requise pour le désactiver — c'est la
 * PA cible MVP.
 *
 * **V1 EsaLink partiel** : gated par `ENABLE_ESALINK_PROVIDER=true`.
 * Default `false` — l'UI Factur-E ne propose pas EsaLink V1 en
 * sélecteur onboarding. Flip `true` en dev local pour tester les 3
 * méthodes EsaLink contre sandbox Hubtimize. Flip `true` sandbox/prod
 * quand V2.3 livré (createCustomer + submitInvoice + pollCdarEvents).
 *
 * **Endpoint `GET /api/pa/providers`** consomme `listEnabledProviders()`
 * et retourne uniquement les providers activés — le frontend (UI Bloc 3
 * onboarding) ne montre pas EsaLink V1.
 *
 * cf. ADR-012 D8 + ADR-011 (V1 partiel) + ADR-010 v2 (SuperPDP cœur MVP).
 */

/** Identifiant string littéral d'un provider — aligné `ProviderId`
 *  côté pa-adapter. */
export type RegistryProviderId = "superpdp" | "esalink";

/** Descripteur public d'un provider — sérialisé tel quel en JSON par
 *  `GET /api/pa/providers`. Consommé par UI onboarding pour proposer le
 *  choix de PA (V1 : uniquement SuperPDP visible). */
export interface ProviderDescriptor {
  providerId: RegistryProviderId;
  /** Libellé public commercial — utilisé en UI sélecteur. */
  label: string;
  /** Mode d'onboarding — `web-authorization-code` (SuperPDP, tunnel
   *  OAuth UI) ou `api-customer-managed` (EsaLink, serveur-à-serveur). */
  onboardingMode: "web-authorization-code" | "api-customer-managed";
}

// ─────────────────────────────────────────────────────────────────────
// Feature flag detection (lue au boot — pas de live-toggle)
// ─────────────────────────────────────────────────────────────────────

function readBooleanEnv(name: string, defaultValue: boolean): boolean {
  const raw = process.env[name];
  if (raw === undefined || raw === "") return defaultValue;
  return raw === "true" || raw === "1";
}

/** SuperPDP toujours activé V1 (provider primary historique sprint-03).
 *  Exporté pour lisibilité — pas de toggle. */
export const SUPERPDP_ENABLED = true;

/** EsaLink V1 partiel sous feature flag (ADR-012 D8). Lecture env au
 *  module load — process.env est figé pour la durée du process Node. */
export const ESALINK_ENABLED = readBooleanEnv("ENABLE_ESALINK_PROVIDER", false);

// ─────────────────────────────────────────────────────────────────────
// Public API
// ─────────────────────────────────────────────────────────────────────

const SUPERPDP_DESCRIPTOR: ProviderDescriptor = {
  providerId: "superpdp",
  label: "SuperPDP",
  onboardingMode: "web-authorization-code",
};

const ESALINK_DESCRIPTOR: ProviderDescriptor = {
  providerId: "esalink",
  label: "EsaLink",
  onboardingMode: "api-customer-managed",
};

/** Liste des providers activés — l'ordre reflète la priorité commerciale
 *  (SuperPDP d'abord, EsaLink ensuite quand activé). SUPERPDP_ENABLED
 *  est toujours `true` V1 (gating env reservé V2+ multi-provider). */
export function listEnabledProviders(): ProviderDescriptor[] {
  const out: ProviderDescriptor[] = [SUPERPDP_DESCRIPTOR];
  if (ESALINK_ENABLED) out.push(ESALINK_DESCRIPTOR);
  return out;
}

/** Vérifie qu'un provider est activé. Utilisé en gating côté
 *  `instantiateDriver` + routes UI qui valident un `providerId`
 *  user-provided. */
export function isProviderEnabled(provider: string): boolean {
  if (provider === "superpdp") return SUPERPDP_ENABLED;
  if (provider === "esalink") return ESALINK_ENABLED;
  return false;
}

/** Configuration injectable côté caller — chaque provider attend sa
 *  shape spécifique. Union typée pour permettre au caller d'utiliser un
 *  switch exhaustif. */
export type ProviderConfig =
  | { providerId: "superpdp"; config: SuperPDPDriverConfig }
  | { providerId: "esalink"; config: EsaLinkDriverConfig };

/**
 * Instancie un driver pour le provider demandé. Throws
 * `UnknownProviderException` si le provider est inconnu ou désactivé
 * par feature flag (`ENABLE_<provider>_PROVIDER=false`). Le retour est
 * typé `PADriverCore` — le caller doit narrow via `isWebOnboarding` /
 * `isApiOnboarding` (ADR-012 D6) pour accéder aux méthodes spécifiques.
 */
export function instantiateDriver(args: ProviderConfig): PADriverCore {
  if (!isProviderEnabled(args.providerId)) {
    throw new UnknownProviderException(
      args.providerId,
      `Provider '${args.providerId}' is not enabled. Set ENABLE_${args.providerId.toUpperCase()}_PROVIDER=true to activate.`,
    );
  }
  if (args.providerId === "superpdp") {
    return new SuperPDPDriver(args.config);
  }
  // Narrowing exhaustif sur l'union `ProviderConfig` — seul `'esalink'`
  // reste après élimination de `'superpdp'`. V2+ ajout d'un 3e provider
  // ré-introduira un `else if` explicite ici.
  return new EsaLinkDriver(args.config);
}

// ─────────────────────────────────────────────────────────────────────
// Registre PA multi-config (sprint-10 W1 — T-CL-REGISTRE-AFNORDRIVER)
//
// Distinction clé : un **provider** (`RegistryProviderId` = famille de
// driver, gating feature-flag) ≠ une **config** (`PaConfigId`). Une même
// plateforme peut exposer plusieurs configs — SuperPDP a une config
// propriétaire (`/v1.beta`) ET une config AFNOR (`/afnor-flow/v1`), même
// compte/token, mêmes identités. La config active est résolue par
// `PA_ACTIVE_CONFIG` au boot (le cron poll partage `app.paDriver` → pas de
// résolution per-request ; bascule = redémarrage avec l'env). La
// résolution per-tenant/per-request (migration prod propriétaire→AFNOR)
// est différée hors S10. Matière ADR « Registre PA multi-config » à
// formaliser côté PMO post-merge.
// ─────────────────────────────────────────────────────────────────────

/** Famille de protocole transport (dépôt/poll) d'une config PA. */
export type PaFamily = "superpdp-proprietary" | "afnor-flow";

/** Identifiant de **config** PA (≠ provider). */
export type PaConfigId =
  | "superpdp-proprietaire"
  | "superpdp-afnor"
  | "esalink"
  | "proxypdplibre"
  | "pa_communautaire";

export interface PaConfigDescriptor {
  paId: PaConfigId;
  family: PaFamily;
  /** Provider/driver de gating — réutilise le feature-flag existant
   *  (`superpdp` toujours activé, `esalink` sous `ENABLE_ESALINK_PROVIDER`). */
  provider: RegistryProviderId;
  /** Clé d'identités **partagées par plateforme** (`actors.json`).
   *  `superpdp-proprietaire` et `superpdp-afnor` partagent `"superpdp"` →
   *  un seul bloc d'identités, zéro duplication (DoD : mêmes SIREN). */
  identitiesKey: string;
  /** `true` = câblée et instanciable comme driver actif W1.
   *  `false` = déclarée mais gated (creds/endpoints externes à
   *  provisionner — `esalink`/`proxypdplibre`/`pa_communautaire`, W1+). */
  wired: boolean;
  /** Libellé public (UI sélecteur W2). */
  label: string;
}

/** Config PA active par défaut (provider primary historique sprint-03). */
export const DEFAULT_PA_CONFIG_ID: PaConfigId = "superpdp-proprietaire";

/** Table des configs PA déclarées. `superpdp-*` câblées W1 ; les configs
 *  externes sont déclarables (gabarits `actors.json`) mais gated. */
export const PA_CONFIGS: Record<PaConfigId, PaConfigDescriptor> = {
  "superpdp-proprietaire": {
    paId: "superpdp-proprietaire",
    family: "superpdp-proprietary",
    provider: "superpdp",
    identitiesKey: "superpdp",
    wired: true,
    label: "SuperPDP (propriétaire /v1.beta)",
  },
  "superpdp-afnor": {
    paId: "superpdp-afnor",
    family: "afnor-flow",
    provider: "superpdp",
    identitiesKey: "superpdp",
    wired: true,
    label: "SuperPDP-AFNOR (/afnor-flow/v1)",
  },
  esalink: {
    paId: "esalink",
    family: "afnor-flow",
    provider: "esalink",
    identitiesKey: "esalink",
    wired: false,
    label: "EsaLink (Hubtimize)",
  },
  proxypdplibre: {
    paId: "proxypdplibre",
    family: "afnor-flow",
    provider: "esalink",
    identitiesKey: "proxypdplibre",
    wired: false,
    label: "ProxyPDPLibre",
  },
  pa_communautaire: {
    paId: "pa_communautaire",
    family: "afnor-flow",
    provider: "esalink",
    identitiesKey: "pa_communautaire",
    wired: false,
    label: "PA Communautaire",
  },
};

/** Résout un descripteur de config par id. Throws `UnknownProviderException`
 *  si l'id est inconnu. */
export function resolvePaConfig(paId: string): PaConfigDescriptor {
  const cfg = (PA_CONFIGS as Record<string, PaConfigDescriptor | undefined>)[paId];
  if (cfg === undefined) {
    throw new UnknownProviderException(
      paId,
      `Unknown PA config '${paId}'. Known configs: ${Object.keys(PA_CONFIGS).join(", ")}.`,
    );
  }
  return cfg;
}

/** Résout la config PA **active** au boot depuis `PA_ACTIVE_CONFIG`
 *  (défaut `superpdp-proprietaire`). Throws si l'env nomme une config
 *  inconnue ou non câblée (`wired:false`) — on ne démarre pas l'app sur
 *  une config externe non provisionnée. */
export function resolveActivePaConfig(): PaConfigDescriptor {
  const raw = process.env.PA_ACTIVE_CONFIG;
  const cfg = resolvePaConfig(raw === undefined || raw === "" ? DEFAULT_PA_CONFIG_ID : raw);
  if (!cfg.wired) {
    throw new UnknownProviderException(
      cfg.paId,
      `PA config '${cfg.paId}' is declared but not wired (W1). Active config must be one of: ${Object.values(
        PA_CONFIGS,
      )
        .filter((c) => c.wired)
        .map((c) => c.paId)
        .join(", ")}.`,
    );
  }
  return cfg;
}
