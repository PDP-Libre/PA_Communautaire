import type { FastifyInstance } from "fastify";

import {
  RefreshExpiredException,
  type AuthorizeArgs,
  type AuthorizeChallenge,
  type ConnectedCompany,
  type CreateInvoiceEventInput,
  type CreateInvoiceEventOutput,
  type CustomerContext,
  type DirectorySearchResult,
  type DownloadInvoiceFileInput,
  type DownloadInvoiceFileResult,
  type ExchangeCodeArgs,
  type GetConnectedCompanyArgs,
  type GetOwnDirectoryEntriesArgs,
  type GetIdentityStatusArgs,
  type IdentityStatusSnapshot,
  type ListIncomingInvoicesInput,
  type ListIncomingInvoicesOutput,
  type PADriver,
  type PaCustomerSnapshot,
  type PaTokens,
  type PollCdarEventsInput,
  type PollCdarEventsOutput,
  type RefreshTokenArgs,
  type RevokeArgs,
  type SearchSirenArgs,
  type SubmitInvoiceInput,
  type SubmitInvoiceOutput,
} from "@factur-e/pa-adapter";
import { MockPADriver } from "@factur-e/shared-fakes";

import { instantiateDriver } from "./registry.js";

declare module "fastify" {
  interface FastifyInstance {
    paDriver: PADriver;
  }
}

/**
 * Stub utilisé en dev quand `SUPERPDP_CLIENT_ID/SECRET` ne sont pas
 * exportés (équivalent `StubInseeClient`). Toutes les méthodes lèvent
 * — l'UI verra un 503 sur `/oauth/superpdp/*` et le SPA affichera
 * "PA non configurée — voir support". C'est le comportement souhaité
 * en dev no-creds : on ne veut pas de "succès silencieux" qui
 * masquerait la mauvaise configuration.
 *
 * Implémente `PADriver = PADriverWebOnboarding` (refactor T-CL-PA-INVOICE-FIX
 * — ADR-012 D1). Les méthodes Pipeline (`submitInvoice` / `pollCdarEvents`)
 * et `getCustomerSnapshot` héritées de `PADriverCore` throw `notConfigured`.
 */
export class StubPaDriver implements PADriver {
  readonly providerId = "superpdp" as const;
  readonly onboardingMode = "web-authorization-code" as const;

  private throwNotConfigured(method: string): never {
    throw new Error(
      `[pa-driver] PA not configured (SUPERPDP_CLIENT_ID/SECRET missing). Method '${method}' unavailable. ` +
        "Dev: load via scripts/dev/load-secrets.sh.",
    );
  }
  healthcheck(): Promise<boolean> {
    return Promise.resolve(false);
  }
  authorize(_args: AuthorizeArgs): Promise<AuthorizeChallenge> {
    this.throwNotConfigured("authorize");
  }
  exchangeCode(_args: ExchangeCodeArgs): Promise<PaTokens> {
    this.throwNotConfigured("exchangeCode");
  }
  refreshToken(_args: RefreshTokenArgs): Promise<PaTokens> {
    this.throwNotConfigured("refreshToken");
  }
  revoke(_args: RevokeArgs): Promise<void> {
    this.throwNotConfigured("revoke");
  }
  getIdentityStatus(_args: GetIdentityStatusArgs): Promise<IdentityStatusSnapshot> {
    this.throwNotConfigured("getIdentityStatus");
  }
  getConnectedCompany(_args: GetConnectedCompanyArgs): Promise<ConnectedCompany> {
    this.throwNotConfigured("getConnectedCompany");
  }
  getOwnDirectoryEntries(_args: GetOwnDirectoryEntriesArgs): Promise<DirectorySearchResult> {
    this.throwNotConfigured("getOwnDirectoryEntries");
  }
  getCustomerSnapshot(_ctx: CustomerContext): Promise<PaCustomerSnapshot> {
    this.throwNotConfigured("getCustomerSnapshot");
  }
  searchSiren(_args: SearchSirenArgs, _ctx: CustomerContext): Promise<DirectorySearchResult> {
    this.throwNotConfigured("searchSiren");
  }
  fetchOwnPeppolAddresses(_siren: string): Promise<DirectorySearchResult> {
    this.throwNotConfigured("fetchOwnPeppolAddresses");
  }
  submitInvoice(_input: SubmitInvoiceInput, _ctx: CustomerContext): Promise<SubmitInvoiceOutput> {
    this.throwNotConfigured("submitInvoice");
  }
  pollCdarEvents(
    _input: PollCdarEventsInput,
    _ctx: CustomerContext,
  ): Promise<PollCdarEventsOutput> {
    this.throwNotConfigured("pollCdarEvents");
  }
  listIncomingInvoices(
    _input: ListIncomingInvoicesInput,
    _ctx: CustomerContext,
  ): Promise<ListIncomingInvoicesOutput> {
    this.throwNotConfigured("listIncomingInvoices");
  }
  createInvoiceEvent(
    _input: CreateInvoiceEventInput,
    _ctx: CustomerContext,
  ): Promise<CreateInvoiceEventOutput> {
    this.throwNotConfigured("createInvoiceEvent");
  }
  downloadInvoiceFile(
    _input: DownloadInvoiceFileInput,
    _ctx: CustomerContext,
  ): Promise<DownloadInvoiceFileResult> {
    this.throwNotConfigured("downloadInvoiceFile");
  }
}

/** Decorate the Fastify instance with a single shared driver. */
export function attachPaDriver(app: FastifyInstance, driver: PADriver): void {
  app.decorate("paDriver", driver);
}

/**
 * Pick a driver based on env. Used when `buildApp` doesn't override.
 *
 * V1 multi-PA (T-CL-PA-INVOICE-FIX) :
 *  - SuperPDP toujours primary (`app.paDriver`). Le registry sert pour
 *    `GET /api/pa/providers` + tests EsaLink intégration.
 *  - EsaLink V1 partiel sous `ENABLE_ESALINK_PROVIDER` — pas instancié
 *    ici comme primary (V2.3 le promouvra quand `pollCdarEvents` livré).
 *
 * Sources des credentials (CLAUDE.md §11.1) :
 *  - dev    : `scripts/dev/load-secrets.sh` lit Keychain
 *             (`superpdp-sandbox-client-{id,secret}`) et exporte
 *             `SUPERPDP_CLIENT_ID`/`SUPERPDP_CLIENT_SECRET`. Si
 *             absent → `StubPaDriver` + warn.
 *  - prod   : ESO inject Scaleway Secret Manager dans le pod env.
 *             Throw fast si absent (cf. `start.ts` invariants).
 *  - test   : default `StubPaDriver` qui throw — les tests injectent
 *             `MockPADriver` via `buildApp({ paDriver })`.
 */
export function createDefaultPaDriver(): PADriver {
  if (process.env.NODE_ENV === "test") {
    return new StubPaDriver();
  }
  // T-CL-16 sprint-03 — `PA_ADAPTER=mock` is honored for Playwright E2E
  // runs (analogue à `INSEE_ADAPTER=preset`). MockPADriver est mémoire-only,
  // pas d'appel HTTP, et expose `setSearchSirenOutcome` consommé par
  // `POST /__dev/directory/preset`. Gating supplémentaire `NODE_ENV !==
  // 'production'` pour éviter une activation accidentelle en prod.
  if (process.env.PA_ADAPTER === "mock" && process.env.NODE_ENV !== "production") {
    return new MockPADriver();
  }
  const clientId = process.env.SUPERPDP_CLIENT_ID;
  const clientSecret = process.env.SUPERPDP_CLIENT_SECRET;
  const baseUrl = process.env.SUPERPDP_BASE_URL ?? "https://api.superpdp.tech";
  if (
    typeof clientId === "string" &&
    clientId !== "" &&
    typeof clientSecret === "string" &&
    clientSecret !== ""
  ) {
    // Via le registry pour cohérence ADR-012 D8 — bien que SuperPDP soit
    // toujours activé, l'usage du registry pose le pattern propre pour
    // V2 multi-provider.
    const driver = instantiateDriver({
      providerId: "superpdp",
      config: { clientId, clientSecret, baseUrl },
    });
    // Narrow vers PADriverWebOnboarding (SuperPDP onboardingMode connu
    // statiquement). Le cast est safe car instantiateDriver('superpdp')
    // retourne toujours un SuperPDPDriver qui implem WebOnboarding.
    return driver as PADriver;
  }
  if (process.env.NODE_ENV === "production") {
    throw new Error(
      "[pa-driver] SUPERPDP_CLIENT_ID + SUPERPDP_CLIENT_SECRET are required in production " +
        "(no Stub fallback in prod — cf. CLAUDE.md §11.1).",
    );
  }
  console.warn(
    "[pa-driver] SUPERPDP_CLIENT_ID/SECRET missing — falling back to StubPaDriver (PA endpoints will return 503).",
  );
  return new StubPaDriver();
}

// Re-export for callers that want to type-check on the typed exception.
export { RefreshExpiredException };
