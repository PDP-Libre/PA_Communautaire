import type { EmailPayload, EmailPurpose, EmailSender } from "./sender.js";
import {
  exportReadyTemplate,
  exportReminderTemplate,
  invitationTemplate,
  mfaOtpTemplate,
  paTokenLostTemplate,
  passwordChangedTemplate,
  resetPasswordTemplate,
  secondaryEmailOtpTemplate,
  verifyEmailTemplate,
  type RenderedEmail,
} from "./templates/index.js";

/**
 * Scaleway Transactional Email (TEM) adapter.
 *
 * Endpoint: `POST {baseUrl}/transactional-email/v1alpha1/regions/{region}/emails`
 *
 * Auth: `X-Auth-Token: <api-key>`. Project ID + sender are body fields.
 *
 * Anti-énumération is enforced upstream (the route decides whether to
 * call `send` at all). The adapter itself is dumb: given a purpose and
 * payload, it renders the template and pushes the request.
 *
 * On a 4xx/5xx response we throw so the caller can audit the failure;
 * we do NOT retry here (a future job-runner can wrap this with a
 * back-off if needed — out of scope for T-CL-04).
 */

export interface ScalewayTemConfig {
  apiKey: string;
  projectId: string;
  fromEmail: string;
  fromName?: string;
  region?: string;
  baseUrl?: string;
  /** Override `fetch` for tests (mock). Defaults to global fetch. */
  fetch?: typeof globalThis.fetch;
}

const DEFAULT_REGION = "fr-par";
const DEFAULT_BASE_URL = "https://api.scaleway.com";

function renderForPurpose(purpose: EmailPurpose, payload: EmailPayload): RenderedEmail {
  switch (purpose) {
    case "phase1_email_verify_otp": {
      // Phase 1 uses a magic link (brief §6.4). The route passes the URL
      // via `payload.magic_link`. The legacy purpose name is kept for
      // back-compat with the EmailSender interface declared in T-CL-03.
      const url = payload.magic_link ?? "";
      return verifyEmailTemplate({ magicLinkUrl: url });
    }
    case "phase1_secondary_email_verify_otp":
    case "invite_secondary_email_verify_otp": {
      // T-CL-15 sprint-03 — réutilise le template phase1 (même contenu :
      // OTP 6 chiffres + intro brève). Le contexte de l'utilisateur
      // (signup vs invitation accept) est interne backend, l'email-rendu
      // est identique côté destinataire.
      const code = payload.otp_code ?? "";
      return secondaryEmailOtpTemplate({ code });
    }
    case "phase1_mfa_setup_otp": {
      const code = payload.otp_code ?? "";
      return mfaOtpTemplate({ code, context: "phase1_setup" });
    }
    case "login_mfa_otp": {
      const code = payload.otp_code ?? "";
      return mfaOtpTemplate({ code, context: "login" });
    }
    case "password_reset": {
      const url = payload.magic_link ?? "";
      return resetPasswordTemplate({ magicLinkUrl: url });
    }
    case "password_changed":
      return passwordChangedTemplate();
    case "invitation": {
      const inviterName = payload.vars?.inviter_name ?? "Un collaborateur";
      const customerName = payload.vars?.customer_name ?? "votre entreprise";
      const acceptUrl = payload.magic_link ?? "";
      return invitationTemplate({ inviterName, customerName, acceptUrl });
    }
    case "pa_token_lost": {
      const reconnectUrl = payload.magic_link ?? "";
      return paTokenLostTemplate({ reconnectUrl });
    }
    case "export_ready": {
      const count = Number(payload.vars?.count ?? "0");
      const downloadUrl = payload.magic_link ?? "";
      return exportReadyTemplate({ count, downloadUrl });
    }
    case "export_reminder": {
      const count = Number(payload.vars?.count ?? "0");
      const daysRemaining = Number(payload.vars?.days_remaining ?? "30");
      const dashboardUrl = payload.magic_link ?? "";
      return exportReminderTemplate({ count, daysRemaining, dashboardUrl });
    }
  }
}

export class ScalewayTemSender implements EmailSender {
  private readonly endpoint: string;
  private readonly fetchFn: typeof globalThis.fetch;
  private readonly fromEmail: string;
  private readonly fromName: string;
  private readonly projectId: string;
  private readonly apiKey: string;

  constructor(cfg: ScalewayTemConfig) {
    const region = cfg.region ?? DEFAULT_REGION;
    const baseUrl = cfg.baseUrl ?? DEFAULT_BASE_URL;
    this.endpoint = `${baseUrl}/transactional-email/v1alpha1/regions/${region}/emails`;
    this.fetchFn = cfg.fetch ?? globalThis.fetch;
    this.fromEmail = cfg.fromEmail;
    this.fromName = cfg.fromName ?? "Factur-e";
    this.projectId = cfg.projectId;
    this.apiKey = cfg.apiKey;
  }

  async send(args: { to: string; purpose: EmailPurpose; payload: EmailPayload }): Promise<void> {
    const rendered = renderForPurpose(args.purpose, args.payload);
    const body = {
      project_id: this.projectId,
      from: { email: this.fromEmail, name: this.fromName },
      to: [{ email: args.to }],
      subject: rendered.subject,
      text: rendered.text,
      html: rendered.html,
    };

    const res = await this.fetchFn(this.endpoint, {
      method: "POST",
      headers: {
        "X-Auth-Token": this.apiKey,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
    });

    if (!res.ok) {
      const detail = await res.text().catch(() => "");
      throw new Error(
        `Scaleway TEM responded ${String(res.status)} for purpose=${args.purpose} to=${args.to}: ${detail.slice(0, 200)}`,
      );
    }
  }
}

export function scalewayTemFromEnv(): ScalewayTemSender | undefined {
  const apiKey = process.env.SCALEWAY_TEM_API_KEY;
  const projectId = process.env.SCALEWAY_TEM_PROJECT_ID;
  const fromEmail = process.env.EMAIL_FROM ?? "noreply@factur-e.fr";
  if (apiKey === undefined || apiKey === "" || projectId === undefined || projectId === "") {
    return undefined;
  }
  return new ScalewayTemSender({ apiKey, projectId, fromEmail });
}
