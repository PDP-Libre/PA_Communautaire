import type { FastifyInstance } from "fastify";

import { scalewayTemFromEnv } from "./scaleway-tem.js";

/**
 * Outgoing transactional email contract.
 *
 * Two implementations ship in T-CL-04:
 *   - `MockEmailSender` — captures sends in-memory. Default for tests
 *     and dev (no real emails leaked while debugging).
 *   - `ScalewayTemSender` — POSTs to Scaleway TEM. Selected when
 *     `EMAIL_ADAPTER=tem` (any env) or `NODE_ENV=production` (forced).
 *
 * Production with TEM env vars missing → `createDefaultEmailSender`
 * throws so we don't ship an app that silently swallows mails.
 */

export type EmailPurpose =
  | "phase1_email_verify_otp"
  | "phase1_secondary_email_verify_otp"
  | "phase1_mfa_setup_otp"
  | "login_mfa_otp"
  | "password_reset"
  | "invitation"
  | "password_changed"
  | "pa_token_lost"
  | "invite_secondary_email_verify_otp"
  // T-CL-EXPORT-ZIP-RETENTION sprint-06 L12.
  | "export_ready"
  | "export_reminder";

export interface EmailPayload {
  /** Plain OTP code (numeric 6 digits) when applicable. */
  otp_code?: string;
  /** Magic link / action URL when applicable (download, dashboard…). */
  magic_link?: string;
  /** Free-form template variables (recipient first name, count…). */
  vars?: Record<string, string>;
}

export interface EmailSender {
  send(args: { to: string; purpose: EmailPurpose; payload: EmailPayload }): Promise<void>;
}

declare module "fastify" {
  interface FastifyInstance {
    email: EmailSender;
  }
}

/**
 * Mock sender — keeps a ring buffer of recent sends in memory for tests.
 * Per CLAUDE.md §11.3 we never hit a real external service from tests,
 * so this is also the default sender in `NODE_ENV=test`.
 */
export class MockEmailSender implements EmailSender {
  private readonly captured: { to: string; purpose: EmailPurpose; payload: EmailPayload }[] = [];

  async send(args: { to: string; purpose: EmailPurpose; payload: EmailPayload }): Promise<void> {
    this.captured.push(args);
    await Promise.resolve();
  }

  /** Test helper: read & clear the most recent send for a given recipient. */
  lastSentTo(email: string): { purpose: EmailPurpose; payload: EmailPayload } | undefined {
    for (let i = this.captured.length - 1; i >= 0; i--) {
      const item = this.captured[i];
      if (item?.to === email) return { purpose: item.purpose, payload: item.payload };
    }
    return undefined;
  }

  /** Test helper: reset capture between cases. */
  reset(): void {
    this.captured.length = 0;
  }
}

/** Decorate the Fastify instance with a single shared sender. */
export function attachEmailSender(app: FastifyInstance, sender: EmailSender): void {
  app.decorate("email", sender);
}

/**
 * Pick a sender based on env. Used when `buildApp` doesn't override.
 *
 * - `NODE_ENV=test` → `MockEmailSender` (always; ignores EMAIL_ADAPTER).
 * - `NODE_ENV=production` → `ScalewayTemSender` mandatory; throws if creds
 *   are missing.
 * - Otherwise (dev): `EMAIL_ADAPTER=tem` switches on TEM if creds are
 *   present; default is `MockEmailSender` so devs don't accidentally
 *   email real users.
 */
export function createDefaultEmailSender(): EmailSender {
  if (process.env.NODE_ENV === "test") {
    return new MockEmailSender();
  }

  const wantTem = process.env.NODE_ENV === "production" || process.env.EMAIL_ADAPTER === "tem";
  if (!wantTem) {
    return new MockEmailSender();
  }

  const tem = scalewayTemFromEnv();
  if (tem === undefined) {
    if (process.env.NODE_ENV === "production") {
      throw new Error(
        "Email adapter `tem` selected (NODE_ENV=production) but SCALEWAY_TEM_API_KEY / SCALEWAY_TEM_PROJECT_ID env vars are missing.",
      );
    }
    // dev with `EMAIL_ADAPTER=tem` but no creds → fall back to mock with
    // a console warning so the misconfiguration is visible.
    console.warn(
      "[email] EMAIL_ADAPTER=tem requested but SCALEWAY_TEM_* env vars are missing. Falling back to MockEmailSender.",
    );
    return new MockEmailSender();
  }
  return tem;
}
