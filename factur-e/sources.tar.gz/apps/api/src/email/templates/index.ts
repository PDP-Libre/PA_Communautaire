/**
 * Email templates — string interpolation, no template engine.
 *
 * Each template returns `{subject, text, html}` consumed by the
 * `EmailSender.send` adapter (Scaleway TEM or mock). HTML is plain
 * inline styles for maximum cross-client compatibility.
 *
 * No external CSS, no images (logo as PNG attachment is out of scope
 * — T-CL-04 minimal, design polish is L08+).
 */

const BRAND_GREEN = "#316128";

function layout(args: {
  heading: string;
  bodyHtml: string;
  ctaHtml?: string;
  footer?: string;
}): string {
  const cta = args.ctaHtml ?? "";
  const footer =
    args.footer ??
    "Cet email a été envoyé par Factur-e. Si vous n'attendiez pas ce message, ignorez-le.";
  return `<!doctype html>
<html lang="fr"><head><meta charset="utf-8"><title>Factur-e</title></head>
<body style="margin:0;padding:0;background:#f5f5f4;font-family:-apple-system,Segoe UI,Roboto,sans-serif;color:#1c1917;">
  <table role="presentation" cellpadding="0" cellspacing="0" width="100%" style="padding:24px 0;">
    <tr><td align="center">
      <table role="presentation" cellpadding="0" cellspacing="0" width="560" style="background:#ffffff;border-radius:8px;padding:32px;">
        <tr><td>
          <div style="font-weight:700;color:${BRAND_GREEN};font-size:18px;margin-bottom:24px;">Factur-e</div>
          <h1 style="font-size:20px;line-height:1.4;margin:0 0 16px;">${args.heading}</h1>
          ${args.bodyHtml}
          ${cta}
          <p style="font-size:13px;color:#78716c;margin-top:32px;">${footer}</p>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body></html>`;
}

function ctaButton(href: string, label: string): string {
  return `<p style="margin:24px 0;"><a href="${href}" style="display:inline-block;background:${BRAND_GREEN};color:#ffffff;padding:12px 20px;border-radius:6px;text-decoration:none;font-weight:600;">${label}</a></p>`;
}

export interface RenderedEmail {
  subject: string;
  text: string;
  html: string;
}

export function verifyEmailTemplate(args: { magicLinkUrl: string }): RenderedEmail {
  const subject = "Vérifions votre adresse email";
  const text = `Bienvenue sur Factur-e.

Cliquez sur le lien ci-dessous pour vérifier votre adresse email et continuer votre inscription :
${args.magicLinkUrl}

Ce lien est valide pendant 1 heure.`;
  const html = layout({
    heading: "Vérifions votre adresse email",
    bodyHtml: `<p>Bienvenue sur Factur-e. Cliquez sur le bouton pour vérifier votre adresse et continuer votre inscription.</p>`,
    ctaHtml: ctaButton(args.magicLinkUrl, "Vérifier mon email"),
    footer:
      "Lien valide pendant 1 heure. Si vous n'avez pas démarré d'inscription, ignorez cet email.",
  });
  return { subject, text, html };
}

export function secondaryEmailOtpTemplate(args: { code: string }): RenderedEmail {
  // Issue #1 — pas de PII dans le subject. Le code reste dans le body.
  const subject = "Code de vérification Factur-e";
  const text = `Votre code de vérification d'email de secours est : ${args.code}

Ce code est valide pendant 5 minutes.`;
  const html = layout({
    heading: "Code de vérification",
    bodyHtml: `<p>Votre code à 6 chiffres pour vérifier votre email de secours :</p>
<p style="font-family:Menlo,Consolas,monospace;font-size:32px;font-weight:700;letter-spacing:6px;text-align:center;background:#f5f5f4;padding:16px;border-radius:6px;">${args.code}</p>`,
    footer: "Code valide pendant 5 minutes.",
  });
  return { subject, text, html };
}

export function mfaOtpTemplate(args: {
  code: string;
  context: "phase1_setup" | "login";
}): RenderedEmail {
  const heading =
    args.context === "phase1_setup" ? "Activons votre code de connexion" : "Code de connexion";
  // Issue #1 — pas de PII dans le subject.
  const subject = "Code de connexion Factur-e";
  const text = `Votre code à 6 chiffres : ${args.code}

Ce code est valide pendant 5 minutes.

Si vous n'avez pas tenté de vous connecter, ignorez ce message et vérifiez la sécurité de votre compte.`;
  const html = layout({
    heading,
    bodyHtml: `<p>Votre code à 6 chiffres :</p>
<p style="font-family:Menlo,Consolas,monospace;font-size:32px;font-weight:700;letter-spacing:6px;text-align:center;background:#f5f5f4;padding:16px;border-radius:6px;">${args.code}</p>`,
    footer:
      "Code valide pendant 5 minutes. Si vous n'avez pas tenté de vous connecter, ignorez ce message.",
  });
  return { subject, text, html };
}

export function resetPasswordTemplate(args: { magicLinkUrl: string }): RenderedEmail {
  const subject = "Réinitialiser votre mot de passe Factur-e";
  const text = `Pour réinitialiser votre mot de passe Factur-e, cliquez sur le lien ci-dessous :
${args.magicLinkUrl}

Ce lien est valide pendant 1 heure. Si vous n'avez pas demandé de réinitialisation, ignorez cet email.`;
  const html = layout({
    heading: "Réinitialiser votre mot de passe",
    bodyHtml: `<p>Vous avez demandé à réinitialiser votre mot de passe. Cliquez sur le bouton pour choisir un nouveau mot de passe.</p>`,
    ctaHtml: ctaButton(args.magicLinkUrl, "Choisir un nouveau mot de passe"),
    footer:
      "Lien valide pendant 1 heure. Si vous n'avez pas demandé de réinitialisation, ignorez cet email.",
  });
  return { subject, text, html };
}

export function passwordChangedTemplate(): RenderedEmail {
  const subject = "Votre mot de passe Factur-e a été modifié";
  const text = `Votre mot de passe Factur-e vient d'être modifié.

Si vous n'êtes pas à l'origine de ce changement, contactez immédiatement notre support.`;
  const html = layout({
    heading: "Votre mot de passe a été modifié",
    bodyHtml: `<p>Votre mot de passe Factur-e vient d'être modifié.</p>
<p>Si vous n'êtes pas à l'origine de ce changement, contactez immédiatement notre support.</p>`,
  });
  return { subject, text, html };
}

/** T-CL-06 sprint-03 — sent to the customer's primary email when the
 *  refresh job has burned through 3 consecutive `RefreshExpiredException`s
 *  (ADR-005 D8). The PA connection is soft-deleted at the same time, so
 *  the user must re-authorize from Paramètres > Connexion PA. Subject
 *  conforme ADR-008 sprint-03 (no PII). */
export function paTokenLostTemplate(args: { reconnectUrl: string }): RenderedEmail {
  const subject = "Votre Plateforme Agréée s'est déconnectée";
  const text = `Votre Plateforme Agréée (SuperPDP) s'est déconnectée de Factur-e.

Aucune action de votre côté n'est requise immédiatement, mais vous ne pourrez pas émettre ou recevoir de factures tant que la connexion n'aura pas été rétablie.

Reconnectez-vous depuis Paramètres > Connexion PA :
${args.reconnectUrl}

Si vous pensez avoir révoqué l'accès par erreur ou rencontrez une difficulté, contactez notre support.`;
  const html = layout({
    heading: "Votre Plateforme Agréée s'est déconnectée",
    bodyHtml: `<p>Votre Plateforme Agréée (SuperPDP) s'est déconnectée de Factur-e. Aucune action urgente de votre côté n'est requise, mais l'émission et la réception de factures sont suspendues tant que la connexion n'aura pas été rétablie.</p>
<p>Pour reconnecter votre PA, rendez-vous dans <strong>Paramètres &rsaquo; Connexion PA</strong>.</p>`,
    ctaHtml: ctaButton(args.reconnectUrl, "Rétablir la connexion"),
    footer: "Si vous pensez avoir révoqué l'accès par erreur, contactez notre support.",
  });
  return { subject, text, html };
}

/** T-CL-EXPORT-ZIP-RETENTION sprint-06 L12 — archive ZIP prête au
 *  téléchargement. Sujet conforme ADR-008 (no PII : pas de count, pas de nom
 *  customer dans le sujet — le count est dans le body). Le lien pointe vers
 *  l'endpoint app `GET /api/exports/:id/download` (presigned fresh + 302),
 *  accessible 7 jours (Z5). */
export function exportReadyTemplate(args: { count: number; downloadUrl: string }): RenderedEmail {
  const subject = "Votre export Factur-e est prêt";
  const text = `Votre archive ZIP contenant ${String(args.count)} facture(s) est prête.

Téléchargez-la via le lien ci-dessous. Ce lien est valide pendant 7 jours :
${args.downloadUrl}`;
  const html = layout({
    heading: "Votre export est prêt",
    bodyHtml: `<p>Votre archive ZIP contenant <strong>${String(args.count)} facture(s)</strong> est prête. Vous pouvez la télécharger via le bouton ci-dessous.</p>`,
    ctaHtml: ctaButton(args.downloadUrl, "Télécharger l'archive"),
    footer: "Lien valide pendant 7 jours.",
  });
  return { subject, text, html };
}

/** T-CL-EXPORT-ZIP-RETENTION sprint-06 L12 — rappel J-30 avant purge des
 *  archives. Sujet conforme ADR-008 (no PII). Vocabulaire pédagogique T-CW-11
 *  (pas de "RGPD"/"purge" — "date de suppression"). */
export function exportReminderTemplate(args: {
  count: number;
  daysRemaining: number;
  dashboardUrl: string;
}): RenderedEmail {
  const subject = "Vos exports approchent de leur date de suppression";
  const text = `${String(args.count)} facture(s) seront supprimées dans moins de ${String(args.daysRemaining)} jours sur Factur-e.

Téléchargez-les pour les conserver :
${args.dashboardUrl}`;
  const html = layout({
    heading: "Vos exports vont être supprimés",
    bodyHtml: `<p><strong>${String(args.count)} facture(s)</strong> seront supprimées dans moins de <strong>${String(args.daysRemaining)} jours</strong> sur Factur-e. Téléchargez-les pour les conserver.</p>`,
    ctaHtml: ctaButton(args.dashboardUrl, "Voir les factures concernées"),
    footer: "Cet email vous est envoyé une seule fois, 30 jours avant la suppression.",
  });
  return { subject, text, html };
}

export function invitationTemplate(args: {
  inviterName: string;
  customerName: string;
  acceptUrl: string;
}): RenderedEmail {
  // Issue #1 — pas de PII (nom inviter / customer) dans le subject.
  const subject = "Vous avez reçu une invitation Factur-e";
  const text = `${args.inviterName} vous a donné accès à son compte Factur-e pour ${args.customerName}.

Acceptez l'accès en cliquant sur ce lien : ${args.acceptUrl}

Ce lien est valide pendant 7 jours.`;
  const html = layout({
    heading: `${args.inviterName} vous donne accès à son compte Factur-e`,
    bodyHtml: `<p>${args.inviterName} vous a donné accès à son compte Factur-e pour <strong>${args.customerName}</strong>. Acceptez l'accès pour créer votre identifiant de connexion.</p>`,
    ctaHtml: ctaButton(args.acceptUrl, "Accéder au compte"),
    footer: "Lien valide pendant 7 jours.",
  });
  return { subject, text, html };
}
