import { randomBytes } from "node:crypto";

import { hash, verify } from "@node-rs/bcrypt";

/**
 * Invitation token shape: `<invitation_id>.<32-hex-secret>`.
 *
 * The id half lets the server `SELECT * FROM invitations WHERE id = …`
 * without scanning the table; the secret half is bcrypt-hashed and
 * stored in `invitations.token_hash`. Bcrypt cost 12 (cf. T-CL-01 note).
 *
 * Plaintext token is sent ONLY in the invitation email; the server keeps
 * just the hash, so even a DB read won't leak something usable.
 */

const SECRET_BYTES = 16; // 32 hex chars
const BCRYPT_COST = 12;
const TOKEN_RE = /^([0-9a-f-]{36})\.([0-9a-f]{32})$/;

export function generateInvitationSecret(): string {
  return randomBytes(SECRET_BYTES).toString("hex");
}

export async function hashInvitationSecret(secret: string): Promise<string> {
  return hash(secret, BCRYPT_COST);
}

export function buildInvitationToken(id: string, secret: string): string {
  return `${id}.${secret}`;
}

export interface ParsedInvitationToken {
  id: string;
  secret: string;
}

export function parseInvitationToken(token: string): ParsedInvitationToken | null {
  const match = TOKEN_RE.exec(token);
  if (match?.[1] === undefined || match[2] === undefined) return null;
  return { id: match[1], secret: match[2] };
}

export async function verifyInvitationSecret(secret: string, hashStored: string): Promise<boolean> {
  return verify(secret, hashStored);
}
