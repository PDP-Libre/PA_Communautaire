import type postgres from "postgres";

import * as usersRepo from "../db/repos/users.js";

/**
 * Invariants enforced when admins (role=full) mutate users:
 *
 *  - A Full admin cannot modify their own role / can_purchase / delete
 *    themselves (would lock the org out).
 *  - A customer must keep at least one active (`deleted_at IS NULL`)
 *    Full user. Last-Full demotion / deletion is refused.
 *
 * Pure read helpers — they delegate the SELECTs to `repos/users.ts` and
 * combine them into a business rule. Naming kept stable for call sites
 * (loadUserForCustomer, wouldDropLastFull) — same semantics, thinner
 * implementation since T-CL-01 sprint-03.
 */

export type UserAdminRow = usersRepo.UserAdminRow;

export async function loadUserForCustomer(
  sql: postgres.Sql,
  userId: string,
  customerId: string,
): Promise<UserAdminRow | undefined> {
  return usersRepo.findUserForCustomerAdmin(sql, userId, customerId);
}

/** True if removing/demoting `target` would leave 0 active Full users. */
export async function wouldDropLastFull(sql: postgres.Sql, target: UserAdminRow): Promise<boolean> {
  if (target.role !== "full" || target.deleted_at !== null) return false;
  const active = await usersRepo.countActiveFullsByCustomer(sql, target.customer_id);
  return active <= 1;
}
