import type { FastifyInstance, FastifyReply } from "fastify";

import type { AuthenticatedContext } from "../auth/context.js";
import * as usersRepo from "../db/repos/users.js";

/**
 * Reload the user from BDD and ensure role === 'full'. Used to gate
 * customer-level mutations (profil vendeur, logo, paramètres défaut).
 *
 * Returns the user role on success (for audit metadata), or sends 403
 * and returns null if the role is not full. Caller must short-circuit
 * on null.
 */
export async function requireFullRole(
  app: FastifyInstance,
  reply: FastifyReply,
  ctx: AuthenticatedContext,
): Promise<"full" | null> {
  const r = await usersRepo.findActiveUserRoleById(app.sql, ctx.user_id);
  if (r?.role !== "full") {
    reply.code(403).send({ message: "Permission insuffisante." });
    return null;
  }
  return "full";
}
