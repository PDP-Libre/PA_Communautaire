/**
 * IBAN MOD 97 validation (ISO 13616) — checks both format and the
 * embedded check digits. We accept any country code; T-CL-06 brief §6.17
 * requires "format IBAN FR (27 c.) ou international, validation MOD 97".
 *
 * IBAN length range: 15 to 34 chars (Norway 15, Malta/UK 22, France 27,
 * Hungary 28, Saint Lucia 32, …). We let any length within bounds pass
 * the algorithmic check rather than maintain a country-length table.
 */

import { decrypt } from "../auth/encryption.js";

const IBAN_MIN = 15;
const IBAN_MAX = 34;

/** Strip whitespace + uppercase. Useful for normalizing UI input. */
export function normalizeIban(input: string): string {
  return input.replace(/\s+/g, "").toUpperCase();
}

export function isValidIban(input: string): boolean {
  const iban = normalizeIban(input);
  if (iban.length < IBAN_MIN || iban.length > IBAN_MAX) return false;
  if (!/^[A-Z]{2}\d{2}[A-Z0-9]+$/.test(iban)) return false;

  // Move first 4 chars (CCDD) to the end and convert letters: A=10, B=11,
  // …, Z=35. Then `BigInt % 97` must equal 1.
  const rearranged = iban.slice(4) + iban.slice(0, 4);
  let numeric = "";
  for (const ch of rearranged) {
    if (ch >= "A" && ch <= "Z") {
      numeric += String(ch.charCodeAt(0) - 55); // 'A' = 65 → 10
    } else {
      numeric += ch;
    }
  }
  return BigInt(numeric) % 97n === 1n;
}

const BIC_RE = /^[A-Z]{4}[A-Z]{2}[A-Z0-9]{2}([A-Z0-9]{3})?$/;

export function isValidBic(input: string): boolean {
  const bic = input.replace(/\s+/g, "").toUpperCase();
  return BIC_RE.test(bic);
}

// ─────────────────────────────────────────────────────────────────────
// Stored IBAN — déchiffrement + masque d'affichage (NC-3 sprint-05)
// ─────────────────────────────────────────────────────────────────────

const IBAN_CIPHER_PREFIX = "v1:";

/**
 * Déchiffre un IBAN stocké (`v1:base64` AES-256-GCM, cf. `PATCH
 * /customers/me/profile`) et le retourne en clair. Une valeur non
 * préfixée `v1:` est retournée telle quelle (rétro-compat données legacy
 * ou tests qui stockent un IBAN clair). Même logique que le pipeline
 * d'émission (`invoice-form-to-model`), centralisée ici côté IBAN.
 */
export function decryptStoredIban(stored: string): string {
  if (!stored.startsWith(IBAN_CIPHER_PREFIX)) return stored;
  const base64 = stored.slice(IBAN_CIPHER_PREFIX.length);
  // Import dynamique-free : `decrypt` ne lit la clé qu'à l'appel, donc
  // l'import statique n'impacte pas les fonctions de validation pures.
  return decrypt(Buffer.from(base64, "base64")).toString("utf8");
}

/**
 * Masque un IBAN clair pour affichage (NC-3 / Scene-04). Conserve le code
 * pays + clé de contrôle (2+2, non sensibles) et les 4 derniers chiffres ;
 * le reste est masqué par blocs de 4. Ex : `FR7610278080000002386440129`
 * → `FR76 •••• •••• •••• •••• •••• 0129`. Jamais l'IBAN complet en clair
 * côté API (le PDF Factur-X serveur reste seul à porter la valeur claire).
 */
export function maskIban(plain: string): string {
  const iban = normalizeIban(plain);
  if (iban.length <= 8) return iban;
  const first4 = iban.slice(0, 4);
  const last4 = iban.slice(-4);
  const middleGroups = Math.ceil((iban.length - 8) / 4);
  const bullets = Array.from({ length: middleGroups }, () => "••••").join(" ");
  return `${first4} ${bullets} ${last4}`;
}
