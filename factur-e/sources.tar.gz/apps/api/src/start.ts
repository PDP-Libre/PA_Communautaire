/**
 * Entry point — production and dev (via `tsx watch src/start.ts`).
 *
 * Boot sequence:
 *  1. Assert production invariants (T-CL-02 sprint-03 boot guards).
 *  2. Run pending DB migrations (advisory lock 4242 serializes replicas).
 *  3. Build the Fastify app.
 *  4. Listen on `API_PORT` (default 3001 — 3000 cohabite mal avec d'autres
 *     stacks dev locales sur la machine de Bruno), host `0.0.0.0` so
 *     containers can expose the port.
 *
 * Tests use `buildApp()` directly via the `buildTestApp` helper — they don't
 * go through this entry, so they don't require a live Postgres.
 */

import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

import { runMigrations } from "./db/migrate.js";
import { registerAuditDriftEnInvoiceJob } from "./jobs/audit-drift-en-invoice.js";
import { registerCleanupJob } from "./jobs/cleanup-expired.js";
import { registerEnrichCustomerPeppolAddressJob } from "./jobs/enrich-customer-peppol-address.js";
import { registerExportZipPurgeJob } from "./jobs/export-zip-purge.js";
import { registerExportZipReminderJob } from "./jobs/export-zip-reminder.js";
import { exportWebBaseUrl, registerExportZipWorker } from "./jobs/export-zip-worker.js";
import { buildExportPgBoss, PgBossJobQueue } from "./jobs/job-queue.js";
import { registerPollCdarEventsJob } from "./jobs/poll-cdar-events.js";
import { registerPollPaIdentityStatusJob } from "./jobs/poll-pa-identity-status.js";
import { registerPollReceivedInvoicesJob } from "./jobs/poll-received-invoices.js";
import { registerRefreshPaTokensJob } from "./jobs/refresh-pa-tokens.js";
import { buildApp } from "./server.js";
import { S3ObjectStorage } from "./storage/object-storage.js";

/** Lifecycle S3 des archives ZIP (Z8 — 180 jours, ceinture-bretelles). */
const EXPORTS_LIFECYCLE_DAYS = 180;

const __dirname = dirname(fileURLToPath(import.meta.url));

function postgresUrlFromEnv(): string {
  if (process.env.POSTGRES_URL) return process.env.POSTGRES_URL;
  const host = process.env.POSTGRES_HOST ?? "localhost";
  // Default port 5442 — cf. server.ts comment.
  const port = process.env.POSTGRES_PORT ?? "5442";
  const db = process.env.POSTGRES_DB ?? "factur_e_dev";
  const user = process.env.POSTGRES_USER ?? "factur_e_dev";
  const password = process.env.POSTGRES_PASSWORD ?? "factur_e_dev_password";
  return `postgresql://${user}:${password}@${host}:${port}/${db}`;
}

/**
 * Hoist invariants checks at boot time so a misconfigured prod fails fast
 * instead of leaking dev defaults at runtime. Cf. T-CL-02 sprint-03 +
 * audit architecture sprint-02 §4.13 / §4.1 / §4.6.
 */
function assertProductionInvariants(): void {
  if (process.env.NODE_ENV !== "production") return;

  if (process.env.WEB_BASE_URL === undefined || process.env.WEB_BASE_URL === "") {
    throw new Error(
      "[start] WEB_BASE_URL must be set in production (CORS allowlist + magic link base URL).",
    );
  }
  if (process.env.ARGON2_MODE === "test") {
    throw new Error(
      "[start] ARGON2_MODE=test is forbidden in production (m=8 MiB, t=1, p=1 — far too weak).",
    );
  }
  const jwtKey = process.env.JWT_SIGNING_KEY;
  if (jwtKey === undefined || jwtKey.length < 32) {
    throw new Error("[start] JWT_SIGNING_KEY must be at least 32 chars in production.");
  }
}

async function main(): Promise<void> {
  assertProductionInvariants();

  const migrationsDir = join(__dirname, "db", "migrations");
  const skipMigrations = process.env.SKIP_MIGRATIONS === "true";

  if (skipMigrations) {
    console.warn("[start] SKIP_MIGRATIONS=true — skipping DB migrations.");
  } else {
    const result = await runMigrations({
      connectionString: postgresUrlFromEnv(),
      migrationsDir,
      logger: {
        info: (msg: string): void => {
          console.warn(msg);
        },
      },
    });
    console.warn(
      `[start] migrations: ${String(result.applied.length)} newly applied${result.applied.length > 0 ? ` (${result.applied.join(", ")})` : ""}`,
    );
  }

  // pgboss — file de jobs PostgreSQL native (Z1, §12). Démarrée avant
  // `buildApp` pour injecter la queue réelle (le défaut buildApp est un mock).
  // retryLimit/backoff globaux (export-zip-generate retry 3 + dead letter).
  const boss = buildExportPgBoss(postgresUrlFromEnv());
  boss.on("error", (err: unknown) => {
    console.error("[pgboss] error:", err);
  });
  await boss.start();

  const app = await buildApp({ jobQueue: new PgBossJobQueue(boss) });

  // Graceful shutdown pgboss (Z10) — vidange des workers en cours (30 s max).
  app.addHook("onClose", async () => {
    await boss.stop({ graceful: true, timeout: 30_000 });
  });

  // S3 bucket boot — idempotent HeadBucket + CreateBucket si manquant
  // (cf. `apps/api/src/storage/object-storage.ts:ensureBucket`). Évite le
  // 500 "The specified bucket does not exist" au premier upload logo en
  // staging (MinIO ne crée pas les buckets auto). Inutile pour
  // MockObjectStorage (dev/test sans S3_*). Cohérent ADR-009 fail-safe :
  // si CreateBucket throw pour cause non-409, log + continue (l'app boot
  // OK, premier upload throw clair côté UI).
  //
  // Puis applique la policy public-read sur le bucket — requis pour le
  // pattern same-origin proxy nginx/Vite `/storage/` (cf. hotfix #8
  // `ensurePublicReadPolicy`). Évite `mc anonymous set download` manuel
  // à chaque reset volume MinIO. Logos publics par nature (factures).
  if (app.storage instanceof S3ObjectStorage) {
    try {
      await app.storage.ensureBucket();
      app.log.info("[start] S3 bucket ensured");
    } catch (err) {
      app.log.warn({ err }, "[start] S3 ensureBucket failed (continuing — uploads may fail)");
    }
    try {
      await app.storage.ensurePublicReadPolicy();
      app.log.info("[start] S3 public-read policy applied");
    } catch (err) {
      app.log.warn(
        { err },
        "[start] S3 ensurePublicReadPolicy failed (continuing — logo URLs may 403)",
      );
    }
  }

  // Bucket exports privé (ADR-014 D4) — JAMAIS public-read (presigned only).
  // + lifecycle 180j (Z8 ceinture-bretelles avec la purge applicative pgboss).
  if (app.exportsStorage instanceof S3ObjectStorage) {
    try {
      await app.exportsStorage.ensureBucket();
      await app.exportsStorage.ensureLifecyclePolicy(EXPORTS_LIFECYCLE_DAYS);
      app.log.info("[start] S3 exports bucket ensured (+ lifecycle 180d)");
    } catch (err) {
      app.log.warn({ err }, "[start] S3 exports bucket setup failed (continuing)");
    }
  }

  // T-CL-03/06 sprint-03 — background jobs. Skip in tests so suites
  // don't fight in-process timers (tests trigger `runX(...)` directly).
  if (process.env.NODE_ENV !== "test") {
    registerCleanupJob(app);
    console.warn("[start] cleanup-expired cron registered (17 * * * *)");
    registerRefreshPaTokensJob(app);
    console.warn("[start] refresh-pa-tokens cron registered (*/5 * * * *)");
    registerPollPaIdentityStatusJob(app);
    console.warn("[start] poll-pa-identity-status cron registered (*/30 * * * *)");
    registerPollCdarEventsJob(app);
    console.warn("[start] poll-cdar-events cron registered (*/15 * * * *)");
    registerPollReceivedInvoicesJob(app);
    console.warn("[start] poll-received-invoices cron registered (*/15 * * * *)");
    registerEnrichCustomerPeppolAddressJob(app);
    console.warn("[start] enrich-customer-peppol-address cron registered (*/5 * * * *)");
    registerAuditDriftEnInvoiceJob(app);
    console.warn("[start] audit-drift-en-invoice cron registered (0 3 * * *)");

    // T-CL-EXPORT-ZIP-RETENTION sprint-06 L12 — jobs pgboss.
    await registerExportZipWorker(app, boss);
    console.warn("[start] export-zip-generate worker registered (pgboss)");
    await registerExportZipReminderJob(app, boss, exportWebBaseUrl());
    console.warn("[start] export-zip-reminder-j30 cron registered (0 4 * * * UTC)");
    await registerExportZipPurgeJob(app, boss);
    console.warn("[start] export-zip-purge cron registered (0 5 * * * UTC)");
  }

  const port = Number(process.env.API_PORT ?? "3001");
  const host = process.env.API_HOST ?? "0.0.0.0";

  await app.listen({ port, host });
  console.warn(`[start] api listening on http://${host}:${String(port)}`);
}

main().catch((err: unknown) => {
  console.error("[start] fatal:", err);
  process.exit(1);
});
