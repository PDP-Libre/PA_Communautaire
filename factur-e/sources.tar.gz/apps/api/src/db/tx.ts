import type postgres from "postgres";

import { TTL_SECONDS } from "../auth/jwt.js";

/**
 * Transaction helper + cohesive session insert (T-CL-01 sprint-03).
 *
 * `withTransaction(sql, fn)` wraps `sql.begin(fn)` with a slow-query
 * threshold log (>200 ms). The intent is to centralize tracing, latency
 * sampling and (later) OpenTelemetry spans on a single chokepoint —
 * not to repeat `sql.begin` in every call site.
 *
 * `insertSession(tx, args)` lifts the verbose
 *     INSERT INTO sessions (...)
 *     VALUES (..., NOW() + INTERVAL '${tx.unsafe(String(TTL_SECONDS.refresh))} seconds')
 * boilerplate that was duplicated 4× before this refacto (login,
 * mfa-verify, mfa-setup-recovery-ack, finalizePhase1, invitations.accept).
 *
 * The TTL constant comes from `auth/jwt.ts` so changing the refresh
 * lifetime needs zero touch in repos.
 */

const SLOW_TX_THRESHOLD_MS = 200;

export async function withTransaction<T>(
  sql: postgres.Sql,
  fn: (tx: postgres.Sql) => Promise<T>,
): Promise<T> {
  const start = Date.now();
  try {
    // postgres.js' `sql.begin` types its inner handle as
    // `TransactionSql`, a stripped-down sibling of `Sql` (no CLOSE/END/
    // options). Repos accept `postgres.Sql` so they can be used outside a
    // transaction too — the cast here is the single bridge between the
    // two views, scoped to this helper.
    return (await sql.begin(async (tx) => fn(tx as unknown as postgres.Sql))) as T;
  } finally {
    const ms = Date.now() - start;
    if (ms > SLOW_TX_THRESHOLD_MS) {
      // Framework-agnostic — route handlers don't always carry req.log
      // when they call into helpers. OpenTelemetry span would be the
      // proper destination later.
      console.warn(`[tx] slow transaction: ${String(ms)} ms`);
    }
  }
}

export interface InsertSessionArgs {
  id: string;
  userId: string;
  ip: string | null;
  userAgent: string | null;
}

/** Single source of truth for the session row INSERT (refresh TTL applied). */
export async function insertSession(sql: postgres.Sql, args: InsertSessionArgs): Promise<void> {
  await sql`
    INSERT INTO sessions (id, user_id, ip, user_agent, expires_at)
    VALUES (
      ${args.id},
      ${args.userId},
      ${args.ip},
      ${args.userAgent},
      NOW() + INTERVAL '${sql.unsafe(String(TTL_SECONDS.refresh))} seconds'
    )
  `;
}
