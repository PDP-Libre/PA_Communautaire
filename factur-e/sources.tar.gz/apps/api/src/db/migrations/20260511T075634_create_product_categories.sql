-- Migration: create_product_categories
-- Generated: 20260511T075634 UTC
--
-- Catégories d'articles (T-CL-11 sprint-03 — catalogue Articles UI / table
-- `products` BDD). Optionnel en phase 1 (formulaires articles n'imposent
-- pas de catégorie) mais schéma posé pour éviter une migration ultérieure
-- bloquante côté UI quand T-CL-12+ ajoutera le filtre catégorie.
--
-- Multi-tenant : un customer voit ses propres catégories, isolation totale.
-- ON DELETE CASCADE sur `customer_id` : un customer supprimé (RGPD admin)
-- voit ses catégories disparaître avec ses articles (cohérence schéma
-- `products` qui CASCADE aussi).
--
-- Glossaire T-CW-11 : table BDD nommée `product_categories` pour cohérence
-- avec `products` (modèle EN 16931/Factur-X) ; UI dit « Catégories
-- d'articles ». Pas de rename code/BDD.
--
-- `deleted_at` : hard-delete admin uniquement (RGPD). Soft-delete absent
-- volontairement — une catégorie sans articles n'a pas de raison d'exister
-- en archive ; l'UI propose de réassigner ou de supprimer.

BEGIN;

CREATE TABLE product_categories (
  id           UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id  UUID         NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  label        TEXT         NOT NULL,
  created_at   TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  updated_at   TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  deleted_at   TIMESTAMPTZ
);

CREATE INDEX product_categories_customer_id_idx
  ON product_categories (customer_id)
  WHERE deleted_at IS NULL;

COMMIT;
