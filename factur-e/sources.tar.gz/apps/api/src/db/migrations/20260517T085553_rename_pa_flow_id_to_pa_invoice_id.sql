-- T-CL-PA-INVOICE-FIX sprint-04 — rename `invoices.pa_flow_id` →
-- `invoices.pa_invoice_id` (ADR-010 v2 D7).
--
-- T-CL-PA-EXT a posé `pa_flow_id` en supposant que les paths SuperPDP
-- `/v1.beta/flows*` existaient. L'investigation 2026-05-16/17 a montré
-- que (a) ces paths n'existent ni propriétaire ni AFNOR, (b) l'API
-- réelle expose `POST /v1.beta/invoices` + `GET /v1.beta/invoice_events`
-- avec un `invoice.id` integer SuperPDP. Le rename aligne le nom de la
-- colonne sur la réalité de l'API consommée.
--
-- **Non-breaking V1** (arbitrage Bruno Z5) : la sandbox dev locale ne
-- contient aucune data au moment du rename (pas de facture émise vers
-- la nouvelle API). Le callsite unique côté apps/api (repo `invoices.ts`
-- + `cdar_events.ts` + job `poll-cdar-events.ts` + route webhook
-- désactivée) est mis à jour dans la même MR. L'expand-then-contract
-- (CLAUDE.md §7.3) ne s'applique pas ici car aucun déploiement n'a
-- exposé cette colonne en prod — V1 dev exclusivement.
--
-- cf. ADR-010 v2 D7 (identifiants : invoice.id integer SuperPDP
-- stringifié, persisté `invoices.pa_invoice_id TEXT`).

BEGIN;

ALTER TABLE invoices RENAME COLUMN pa_flow_id TO pa_invoice_id;

-- Préserver les index posés par T-CL-PA-EXT sur la colonne renommée.
-- Postgres renomme automatiquement les index dérivés de
-- `CREATE INDEX ... ON invoices(pa_flow_id)` créés implicitement, mais
-- pas ceux nommés explicitement — on liste et renomme défensivement.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_indexes
    WHERE schemaname = current_schema()
      AND tablename = 'invoices'
      AND indexname = 'invoices_pa_flow_id_idx'
  ) THEN
    EXECUTE 'ALTER INDEX invoices_pa_flow_id_idx RENAME TO invoices_pa_invoice_id_idx';
  END IF;
END$$;

COMMIT;
