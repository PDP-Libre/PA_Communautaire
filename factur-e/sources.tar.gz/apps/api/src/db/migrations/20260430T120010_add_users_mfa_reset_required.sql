-- Migration: add_users_mfa_reset_required
-- Generated: 20260430T120010 UTC
--
-- Flag forcing MFA re-setup after a recovery code consume (cf. PRD §5.1
-- US-AUTH-003 critère 4). Set `true` quand un user a utilisé un recovery
-- code pour se connecter ; T-CL-03 retourne dans /auth/me pour que le
-- frontend impose la re-configuration MFA. Middleware backend strict
-- est `[DEBT]` medium — à durcir avant prod (cf. trace.md sprint-02).
--
-- DEFAULT FALSE pour les rows existants (aucun en sprint-02 mais cohérent).

BEGIN;

ALTER TABLE users
  ADD COLUMN mfa_reset_required BOOLEAN NOT NULL DEFAULT FALSE;

COMMIT;
