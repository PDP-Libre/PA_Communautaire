-- Migration: add_users_terms_accepted_at
-- Generated: 20260430T110010 UTC
--
-- Ajout du `terms_accepted_at` sur `users` (oubli T-CL-01). PRD §5.1
-- US-AUTH-001 : "L'acceptation des CGU et de la politique de
-- confidentialité est obligatoire". À la finalisation phase 1
-- (T-CL-03 `POST /auth/phase1/complete`), la valeur est recopiée
-- depuis `signup_pending.terms_accepted_at`.
--
-- DEFAULT NOW() pour rester applicable même si la table contenait
-- déjà des rows (pas le cas en sprint-02 mais conforme aux
-- bonnes pratiques migration). En pratique le service force la
-- valeur explicite à l'INSERT, le default n'est pas atteint.

BEGIN;

ALTER TABLE users
  ADD COLUMN terms_accepted_at TIMESTAMPTZ NOT NULL DEFAULT NOW();

COMMIT;
