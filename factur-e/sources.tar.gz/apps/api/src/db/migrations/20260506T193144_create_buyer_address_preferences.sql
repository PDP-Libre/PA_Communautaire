-- Migration: create_buyer_address_preferences
-- Generated: 20260506T193144 UTC
--
-- Memorise la preference d'adresse Peppol par couple (customer_id, buyer_siren)
-- (T-CL-09 sprint-03 + T-CW-09 sprint-02 Q3 acte). Justification : le tuilage
-- entre PA peut faire qu'un meme acheteur soit inscrit chez plusieurs PA
-- (multiples `french_directory_entry`). Une fois que le user a choisi une
-- adresse parmi les multiples, on memorise pour ne plus afficher le selecteur
-- aux recherches suivantes du meme SIREN.
--
-- Cf. PRD v1.4 §5.5 critere 4 + audit T-CW-08 §3.2 + ROADMAP L07 patch T-CW-06.
--
-- `preferred_party_id` = identifier Peppol complet (ex `0225:123456789_dgfip`)
-- pour reutilisation directe a l'emission BT-49 buyer endpoint identifier
-- (sprint-04+).
-- `last_used_at` permet de detecter les preferences obsoletes (V2 cleanup
-- au-dela de N mois sans utilisation).

BEGIN;

CREATE TABLE buyer_address_preferences (
  customer_id          UUID         NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  buyer_siren          CHAR(9)      NOT NULL,
  preferred_party_id   TEXT         NOT NULL,
  last_used_at         TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  PRIMARY KEY (customer_id, buyer_siren)
);

CREATE INDEX buyer_address_preferences_last_used_idx
  ON buyer_address_preferences (last_used_at);

COMMIT;
