-- Migration: create_export_requests
-- Generated: 20260527T132146 UTC
--
-- T-CL-EXPORT-ZIP-RETENTION sprint-06 W2 L12 — Export ZIP + rétention RGPD
-- 6 mois (PRD §3.12 RET-1..12, brief T-CW-DESIGN-S06 §4).
--
-- Table `export_requests` : une demande d'archive ZIP (factures émises +
-- reçues) déclenchée par le rôle Full, générée en asynchrone par le worker
-- pgboss `export-zip-generate`. `purge_at = created_at + 6 mois` (RGPD strict
-- non configurable, RET-6). La row est PRÉSERVÉE post-purge (`status='purged'`,
-- file_key NULL) pour auditabilité — seul le fichier S3 est supprimé.
--
-- Colonnes `exported_at` ajoutées sur `invoices` + `received_invoices`
-- (Z9 validé Bruno) : alimentées au moment de l'upload du ZIP, consommées par
-- `RetentionStatusBadge` (a-t-on déjà archivé cette facture ?). Nullable —
-- pas de backfill (les factures existantes n'ont pas encore été exportées).
--
-- Convention CLAUDE.md §7 :
--   - une migration ne se modifie jamais une fois mergée (corrections par compensation)
--   - pas de DROP TABLE / DROP COLUMN / RENAME sans expand-then-contract
--   - colonnes NOT NULL → valeur par défaut ou backfill dans la même migration

BEGIN;

CREATE TABLE export_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES customers(id),
  requested_by_user_id uuid NOT NULL REFERENCES users(id),
  scope text NOT NULL CHECK (scope IN ('emission', 'reception', 'all')),
  filters jsonb NOT NULL DEFAULT '{}',
  invoice_ids uuid[] NOT NULL,
  invoice_count integer NOT NULL,
  status text NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending', 'processing', 'completed', 'failed', 'purged')),
  file_key text,
  file_size_bytes integer,
  purge_at timestamptz NOT NULL,
  reminder_sent_at timestamptz,
  error_message text,
  correlation_id uuid NOT NULL DEFAULT gen_random_uuid(),
  created_at timestamptz NOT NULL DEFAULT NOW(),
  updated_at timestamptz NOT NULL DEFAULT NOW()
);

-- Liste paginée Paramètres > Mes exports (le plus récent d'abord).
CREATE INDEX idx_export_requests_customer
  ON export_requests (customer_id, created_at DESC);

-- Scan nightly du job purge (`export-zip-purge`).
CREATE INDEX idx_export_requests_purge
  ON export_requests (purge_at) WHERE status = 'completed';

-- Scan nightly du job rappel J-30 (`export-zip-reminder-j30`).
CREATE INDEX idx_export_requests_reminder
  ON export_requests (purge_at)
  WHERE status = 'completed' AND reminder_sent_at IS NULL;

-- Z9 — horodatage "déjà archivé dans un ZIP" (RetentionStatusBadge).
-- Nullable, pas de backfill : factures pré-existantes non encore exportées.
ALTER TABLE invoices ADD COLUMN exported_at timestamptz;
ALTER TABLE received_invoices ADD COLUMN exported_at timestamptz;

COMMIT;
