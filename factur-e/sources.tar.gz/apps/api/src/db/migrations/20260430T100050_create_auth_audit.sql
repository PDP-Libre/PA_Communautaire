-- Migration: create_auth_audit
-- Generated: 20260430T100050 UTC
--
-- Journal d'audit des événements auth. Append-only. Source : plan.md
-- T-CL-01 + test.md scénario 8.
--
-- Notes :
-- - `event_type` : `text` plutôt que `CREATE TYPE ... AS ENUM` car
--   l'extension d'enum Postgres est non-transactionnelle (consigne
--   Bruno T-CL-01). Liste indicative non-exhaustive validée à l'app :
--     signup_success, signup_failed,
--     login_success, login_failed,
--     logout,
--     mfa_setup, mfa_verified, mfa_failed, mfa_recovery_used,
--     password_reset_request, password_reset_complete,
--     email_verified, email_secondary_verified,
--     invitation_sent, invitation_accepted,
--     recovery_codes_regenerated,
--     secondary_email_changed.
-- - `user_id` et `customer_id` nullable pour les events anté-account
--   (signup_failed avant création user) ou system-level.
-- - ON DELETE SET NULL pour conserver la trace même après hard-delete
--   (rare en pratique grâce au soft delete via deleted_at).

BEGIN;

CREATE TABLE auth_audit (
  id            BIGSERIAL    PRIMARY KEY,
  user_id       UUID         REFERENCES users(id) ON DELETE SET NULL,
  customer_id   UUID         REFERENCES customers(id) ON DELETE SET NULL,
  event_type    TEXT         NOT NULL,
  ip            INET,
  user_agent    TEXT,
  success       BOOLEAN      NOT NULL,
  metadata      JSONB        NOT NULL DEFAULT '{}'::jsonb,
  occurred_at   TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE INDEX auth_audit_user_occurred_idx
  ON auth_audit (user_id, occurred_at DESC);
CREATE INDEX auth_audit_customer_occurred_idx
  ON auth_audit (customer_id, occurred_at DESC);
CREATE INDEX auth_audit_event_type_idx
  ON auth_audit (event_type, occurred_at DESC);

COMMIT;
