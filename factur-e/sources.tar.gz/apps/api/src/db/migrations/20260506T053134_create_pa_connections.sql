-- Migration: create_pa_connections
-- Generated: 20260506T053134 UTC
--
-- Connexion PA OAuth (PRD v1.4 §6.2 + ADR-005 sprint-03). Cible MVP : un
-- customer = 1 connexion SuperPDP. Forward-compat multi-PA (V2) via la
-- colonne `provider` + UNIQUE PARTIAL `(customer_id, provider) WHERE
-- deleted_at IS NULL` -- un même customer pourra avoir plusieurs lignes
-- actives sur des providers distincts sans migration de contrainte.
--
-- Choix UNIQUE PARTIAL (vs `customer_id UNIQUE` strict) :
--   1. Reconnexion historique : Alice se déconnecte (row 1 deleted_at set)
--      puis se reconnecte (row 2 INSERT). Le partial autorise les deux.
--      Un UNIQUE strict bloquerait la 2e ligne avec violation.
--   2. Multi-PA V2 : extend-then-contract sans ALTER TABLE coûteux sous
--      charge prod.
--
-- Tokens d'accès / refresh : jamais en BDD. La colonne `secret_ref` pointe
-- vers Scaleway Secret Manager prod (`/factur-e/prod/superpdp/<customer_id>/...`)
-- ou Keychain dev (alias `factur-e-superpdp-{customer_id}-{access,refresh}`).
-- Cf. ADR-005 D9 + CLAUDE.md §11.1.
--
-- Statuts d'identité : `text` (pas enum Postgres) pour évolution sans
-- migration -- cf. ADR-005 D5. Valeurs SuperPDP MVP : `verified`,
-- `needs_review`, `rejected`. Le polling background sub-job (T-CL-06)
-- bascule `needs_review -> verified` quand SuperPDP confirme l'audit
-- humain async (D7).
--
-- Index :
--   - lookup customer (status endpoint T-CL-06) → customer + active filter.
--   - refresh job (T-CL-06) → last_refreshed_at.
--   - polling job (T-CL-06) → needs_review filter.

BEGIN;

CREATE TABLE pa_connections (
  id                                  UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id                         UUID         NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  provider                            TEXT         NOT NULL DEFAULT 'superpdp',
  pa_user_id                          TEXT,
  secret_ref                          TEXT         NOT NULL,
  user_identity_verification_status   TEXT         NOT NULL,
  company_verification_status         TEXT         NOT NULL,
  scopes                              TEXT[]       NOT NULL DEFAULT '{}',
  connected_at                        TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  last_refreshed_at                   TIMESTAMPTZ,
  refresh_failures_count              INTEGER      NOT NULL DEFAULT 0,
  revoked_at                          TIMESTAMPTZ,
  deleted_at                          TIMESTAMPTZ
);

-- Un customer = 1 connexion active par provider. Partial sur deleted_at IS NULL
-- (cf. en-tête : reconnexion historique + multi-PA V2 sans migration).
CREATE UNIQUE INDEX pa_connections_customer_provider_active_uidx
  ON pa_connections (customer_id, provider)
  WHERE deleted_at IS NULL;

-- Lookup status endpoint (T-CL-06) : 1 hit par GET /api/pa/status.
CREATE INDEX pa_connections_customer_active_idx
  ON pa_connections (customer_id)
  WHERE deleted_at IS NULL;

-- Refresh job (T-CL-06) : sweep toutes les 5 min sur les rows actives
-- non-révoquées dont l'access token approche l'expiration (1800 s SuperPDP).
CREATE INDEX pa_connections_refresh_due_idx
  ON pa_connections (last_refreshed_at)
  WHERE deleted_at IS NULL AND revoked_at IS NULL;

-- Polling job identity status (T-CL-06) : sweep toutes les 30 min sur les
-- rows en attente d'un retour KYC asynchrone SuperPDP (ADR-005 D6+D7).
CREATE INDEX pa_connections_needs_review_idx
  ON pa_connections (id)
  WHERE deleted_at IS NULL
    AND (user_identity_verification_status = 'needs_review'
         OR company_verification_status = 'needs_review');

COMMIT;
