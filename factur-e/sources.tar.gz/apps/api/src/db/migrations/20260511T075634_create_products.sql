-- Migration: create_products
-- Generated: 20260511T075634 UTC
--
-- Catalogue d'articles (T-CL-11 sprint-03). Table BDD `products` (modèle
-- EN 16931/Factur-X) mais UI dit « Articles » (glossaire T-CW-11).
-- Cf. PRD v1.4 §3.4 + §6.2 + mockups T-CW-10/12 §6.10-6.13.
--
-- Multi-tenant strict (customer_id NOT NULL FK). ON DELETE CASCADE :
-- customer supprimé (RGPD admin) → ses articles disparaissent.
--
-- Champs prix :
--   - `unit_price_ht numeric(12,4)` — précision EN 16931 BT-146 (le
--     standard exige 4 décimales pour les prix unitaires HT, distinct
--     des montants totaux à 2 décimales).
--   - `unit text` — mode base : libre ("unité", "heure", "kg"). Mode
--     avancé : code UN/ECE Recommendation 20 (HUR/heure, KGM/kilogramme,
--     etc.) — validation côté API, pas en BDD pour laisser la liberté UI.
--
-- Champs TVA :
--   - `vat_category text` CHECK contraint sur les 7 codes EN 16931 BT-151 :
--     S (standard), AE (autoliquidation), Z (taux 0), E (exonéré),
--     K (intracom), G (export hors UE), O (hors champ). Défense en
--     profondeur en plus du Zod côté API.
--   - `vat_rate numeric(5,2)` NULL — taux % (20.00, 10.00, 5.50, 2.10).
--     NULL pour AE/Z/E/K/G/O qui n'ont pas de taux applicable.
--
-- `internal_code` : libre, doublons autorisés au même customer (cf.
-- T-CW-10 Q5 acté Bruno : un user peut avoir 2 articles "J1k" si ça
-- fait sens — l'UI badge la collision sans bloquer). Pas de UNIQUE.
--
-- `category_id` FK SET NULL : si une catégorie est supprimée (admin),
-- ses articles deviennent orphelins (category_id=NULL) mais sont
-- préservés. La table `product_categories` est créée dans la migration
-- jumelle 20260511T075634_create_product_categories.sql.
--
-- Soft-delete :
--   - `is_archived` (UI "archiver") — masque dans listing par défaut,
--     reste consultable, ré-activable. Cas standard utilisateur.
--   - `deleted_at` (admin RGPD) — hard-delete logique, jamais accessible
--     via API utilisateur. Différent des autres tables qui n'ont que
--     `deleted_at` parce qu'ici l'archivage UI a une sémantique propre.

BEGIN;

CREATE TABLE products (
  id              UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id     UUID         NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  label           TEXT         NOT NULL,
  description     TEXT,
  internal_code   TEXT,
  unit_price_ht   NUMERIC(12,4) NOT NULL,
  unit            TEXT         NOT NULL DEFAULT 'unité',
  vat_category    TEXT         NOT NULL
                  CHECK (vat_category IN ('S', 'AE', 'Z', 'E', 'K', 'G', 'O')),
  vat_rate        NUMERIC(5,2) CHECK (vat_rate IS NULL OR (vat_rate >= 0 AND vat_rate <= 100)),
  category_id     UUID         REFERENCES product_categories(id) ON DELETE SET NULL,
  is_archived     BOOLEAN      NOT NULL DEFAULT FALSE,
  created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  deleted_at      TIMESTAMPTZ
);

-- Listing par défaut : un customer voit ses articles non-archivés non-supprimés.
CREATE INDEX products_customer_active_idx
  ON products (customer_id, is_archived)
  WHERE deleted_at IS NULL;

-- Recherche par code interne (doublons OK, on retourne array).
CREATE INDEX products_customer_internal_code_idx
  ON products (customer_id, internal_code)
  WHERE deleted_at IS NULL AND internal_code IS NOT NULL;

-- Filtre par catégorie.
CREATE INDEX products_customer_category_idx
  ON products (customer_id, category_id)
  WHERE deleted_at IS NULL AND category_id IS NOT NULL;

COMMIT;
