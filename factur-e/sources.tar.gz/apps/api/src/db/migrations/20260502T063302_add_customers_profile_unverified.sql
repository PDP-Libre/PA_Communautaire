-- Migration: add_customers_profile_unverified
-- Generated: 20260502T063302 UTC
--
-- Tracks whether the customer's identity (legal_name + address) was
-- captured manually by the user during phase 1 onboarding. Set to TRUE
-- when INSEE Sirene returns the entreprise as partially-diffused
-- (statutDiffusion = "P" — typical for personnes physiques /
-- entrepreneurs individuels), which forces the user into manual entry.
--
-- Consumed by post-onboarding UIs to display a "à confirmer" badge next
-- to the legal_name / address until the PA (SuperPDP) onboarding
-- confirms the identity through its own KYC checks. Cleared back to
-- FALSE once the PA returns a successful identity attestation
-- (sprint-03 — SuperPDP onboarding flow).
--
-- Why: avoid surfacing INSEE-unverified entreprise data without context.
-- Without this flag, downstream UIs (PeopleAccess, profil vendeur,
-- dashboard, factures) treat the entreprise as INSEE-validated, which is
-- false for partial-diffusion cases.

BEGIN;

ALTER TABLE customers
  ADD COLUMN profile_unverified BOOLEAN NOT NULL DEFAULT FALSE;

COMMIT;
