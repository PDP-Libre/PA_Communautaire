-- Migration: create_sessions
-- Generated: 20260430T100040 UTC
--
-- Sessions JWT actives. Une ligne = un JWT émis. La PK est le `jti` du
-- JWT. Permet la révocation côté serveur (logout, "Voir mes sessions
-- actives" brief design sprint-02 §6.21) sans recourir à un blacklist
-- séparé.

BEGIN;

CREATE TABLE sessions (
  id           UUID         PRIMARY KEY,
  user_id      UUID         NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  ip           INET,
  user_agent   TEXT,
  expires_at   TIMESTAMPTZ  NOT NULL,
  revoked_at   TIMESTAMPTZ,
  created_at   TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE INDEX sessions_user_id_idx ON sessions (user_id);
CREATE INDEX sessions_expires_at_idx ON sessions (expires_at)
  WHERE revoked_at IS NULL;

COMMIT;
