-- T-CL-PA-INVOICE-FIX sprint-04 — table `pa_polling_state` (ADR-012 D5).
--
-- Persiste le curseur de polling CDAR par couple (customer_id, provider).
-- Découplage essentiel pour supporter multi-PA :
--  - SuperPDP : cursor = `event.id` integer stringifié (cf. ADR-010 v2 D4
--    cursor Stripe-like `GET /v1.beta/invoice_events?starting_after_id=`).
--  - EsaLink V2 : cursor = ISO8601 timestamp (`max(results[].updatedAt)`,
--    cf. ADR-011 D7 pull-only).
--
-- Sémantique cursor portable TEXT — chaque driver interprète selon son
-- protocole. PK composite (customer_id, provider) garantit qu'un même
-- customer peut être connecté à plusieurs PA simultanément (forward-compat
-- multi-PA V2+).
--
-- Pattern fail-safe ADR-009 D1 : le job `poll-cdar-events.ts` n'avance le
-- cursor que sur tick OK. Sur 5xx épuisé → log + retry au prochain tick
-- sans `upsertCursor`, donc pas de perte d'events.
--
-- Cursor initial : la première lecture retourne `undefined` côté repo →
-- le caller passe `'0'` au driver SuperPDP (premier event id >0). EsaLink
-- V2 utilisera epoch ISO ou `now() - lookback` selon stratégie de
-- bootstrap.
--
-- cf. ADR-012 D5 (table polling cursor per-customer per-provider) +
--     ADR-009 D1 (fail-safe) + D3 (intervalle paramétrable).

BEGIN;

CREATE TABLE pa_polling_state (
  customer_id     uuid        NOT NULL,
  -- Provider identifier — text (pas enum) pour évolution facile.
  -- V1 : 'superpdp'. V2+ : 'esalink', autres PA AFNOR.
  provider        text        NOT NULL,
  -- Cursor opaque côté driver. SuperPDP : `event.id` integer stringifié.
  -- EsaLink : ISO8601 timestamp. Le driver est la source de vérité du
  -- format ; ce repo le persiste tel quel.
  cursor          text        NOT NULL,
  last_polled_at  timestamptz NOT NULL DEFAULT NOW(),
  PRIMARY KEY (customer_id, provider)
);

-- Pas de FK vers `customers(id)` — par cohérence avec le pattern T-CL-01
-- repo `pa_connections.ts` (FK non posée). À ajouter ultérieurement si
-- jugé nécessaire (migration compensatoire).

COMMENT ON TABLE pa_polling_state IS
  'Curseur de polling CDAR per-(customer, provider) — ADR-012 D5. Format cursor opaque côté driver (SuperPDP integer stringifié, EsaLink ISO8601).';
COMMENT ON COLUMN pa_polling_state.cursor IS
  'Cursor opaque interprété par le driver. SuperPDP: event.id integer stringifié. EsaLink V2: ISO8601 timestamp.';

COMMIT;
