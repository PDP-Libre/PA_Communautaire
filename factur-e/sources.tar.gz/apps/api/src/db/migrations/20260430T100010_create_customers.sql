-- Migration: create_customers
-- Generated: 20260430T100010 UTC
--
-- Compte client Factur-e (auto-entrepreneur, EI, EURL, SAS, etc.).
-- Source : PRD §6.2 + brief design sprint-02 §6.17/§6.18/§6.19.
-- Un seul SIREN par compte (pas de multi-entité au MVP).
--
-- Notes :
-- - `iban` : stocké chiffré applicativement (AES-256-GCM, préfixe `v1:`,
--   clé Keychain dev / Scaleway Secret Manager prod). Décrypt côté app
--   uniquement. Implémentation en T-CL-06.
-- - `default_invoice_values` : jsonb libre alimenté par §6.19 paramètres
--   défaut facture (devise, échéance, mentions, IBAN, etc.).
-- - `directory_address` : par défaut = SIREN du customer (norme AFNOR
--   SchemeID 0225). Renseigné par le service à l'inscription.
-- - `vat_regime` et `ui_mode_default` : stockés en `text` + CHECK plutôt
--   que `CREATE TYPE ... AS ENUM` car l'extension d'un enum Postgres
--   est non-transactionnelle (cf. consigne Bruno T-CL-01).

BEGIN;

CREATE TABLE customers (
  id                       UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
  siren                    CHAR(9)      NOT NULL UNIQUE,
  legal_name               TEXT         NOT NULL,
  trading_name             TEXT,
  address                  JSONB        NOT NULL DEFAULT '{}'::jsonb,
  naf_code                 TEXT,
  rcs                      TEXT,
  vat_number               TEXT,
  vat_regime               TEXT         NOT NULL DEFAULT 'real'
                                        CHECK (vat_regime IN (
                                          'real',
                                          'franchise_293b',
                                          'reverse_charge_eu',
                                          'simplified'
                                        )),
  vat_on_encashment        BOOLEAN      NOT NULL DEFAULT FALSE,
  iban                     TEXT,
  bic                      TEXT,
  logo_s3_key              TEXT,
  primary_color            CHAR(7)      NOT NULL DEFAULT '#316128'
                                        CHECK (primary_color ~ '^#[0-9A-Fa-f]{6}$'),
  legal_mentions           TEXT         CHECK (legal_mentions IS NULL OR LENGTH(legal_mentions) <= 500),
  directory_address        TEXT,
  default_invoice_values   JSONB        NOT NULL DEFAULT '{}'::jsonb,
  ui_mode_default          TEXT         NOT NULL DEFAULT 'basic'
                                        CHECK (ui_mode_default IN ('basic', 'advanced')),
  created_at               TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  updated_at               TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  deleted_at               TIMESTAMPTZ
);

CREATE TRIGGER customers_set_updated_at
  BEFORE UPDATE ON customers
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

COMMIT;
