-- T-CL-PA-EXT sprint-04 — table `cdar_events` (cycle de vie facture).
--
-- Stocke les events CDAR PA (sortants L09 : reçus via webhook signé HMAC
-- + polling 15 min hybride pour rattrapage — pattern fail-safe degradation
-- ADR-009 D1 + D3). Application stricte de la décision **ADR-009 D4** :
-- UNIQUE constraint sur la clé naturelle `(invoice_id, code, occurred_at)`
-- → `INSERT … ON CONFLICT DO NOTHING` côté repo.
--
-- Pas de foreign key vers `invoices(id)` à ce stade : T-CL-API-INVOICE
-- [P] créera la table `invoices` dans une migration distincte (timestamp
-- ultérieur). Une migration compensatoire ultérieure pourra ajouter la FK
-- via `ALTER TABLE cdar_events ADD CONSTRAINT fk_cdar_events_invoice …`
-- si jugé nécessaire après merge T-CL-API-INVOICE — `[NOTE-COWORK]`
-- trace.md sprint-04.
--
-- cf. ADR-009 D4 (idempotence + UNIQUE clé naturelle), brief sprint-04
-- §6.11 timeline CDAR, plan.md sprint-04 T-CL-PA-EXT lignes 269-279.

BEGIN;

CREATE TABLE cdar_events (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_id    uuid NOT NULL,
  code          text NOT NULL,
  label         text,
  occurred_at   timestamptz NOT NULL,
  payload       jsonb NOT NULL DEFAULT '{}'::jsonb,
  reason        text,
  -- Source de l'event : 'webhook' (push signé HMAC PA), 'polling'
  -- (rattrapage 15 min via pa-adapter.pollDocumentStatus), 'synthetic'
  -- (event injecté côté Factur-E ex. "Déposée" initial post-submit).
  -- Type text (pas enum) pour évolution facile (ADR-009 §"Côté schéma BDD").
  source        text NOT NULL DEFAULT 'webhook',
  created_at    timestamptz NOT NULL DEFAULT NOW()
);

-- ADR-009 D4 — idempotence par clé naturelle. Webhook + polling peuvent
-- recevoir le même event 2 fois (race condition) ; `INSERT … ON CONFLICT
-- DO NOTHING` évite les doublons en BDD, doublons d'audit, doublons SSE,
-- statut courant qui régresse, métriques faussées.
CREATE UNIQUE INDEX uq_cdar_events_natural_key
  ON cdar_events (invoice_id, code, occurred_at);

-- Index pour le job polling 15 min — SELECT par invoice + recent events.
CREATE INDEX idx_cdar_events_invoice_occurred_at
  ON cdar_events (invoice_id, occurred_at DESC);

-- Source valide — guard ceinture/bretelles (les valeurs sont normalisées
-- côté code, mais un CHECK protège contre les drifts silencieux).
ALTER TABLE cdar_events
  ADD CONSTRAINT cdar_events_source_check
  CHECK (source IN ('webhook', 'polling', 'synthetic'));

COMMIT;
