-- Migration: add_customer_unverified_fields
-- Generated: 20260526T154950 UTC
--
-- T-CL-SIREN-RECONCILIATION sprint-06 W1 — Mécanisme 1 (ADR-007ter D1
-- candidat). Généralise le badge global `customers.profile_unverified`
-- (acquis ADR-007 D3 sprint-03) en flags champ-spécifiques par attribut
-- réconciliable au callback OAuth SuperPDP `verified`.
--
-- Arbitrage Bruno récap pré-code Z1 = Option B : additif, on PRÉSERVE
-- `profile_unverified` (PRD v1.7 §5.3 US-PA-005 crit. 9 — "maintenu en
-- complément, pas en remplacement") et on AJOUTE 4 colonnes booléennes.
-- Pas de DROP (cf. CLAUDE.md §7.3 expand-then-contract).
--
-- Backfill rétrocompat Z6 : les customers existants héritent du flag
-- global (`*_unverified = profile_unverified`) — tous champs marqués
-- non-vérifiés si le profil l'était (cohérent ADR-007 D1 : INSEE =
-- donnée publique non attestée).
--
-- Convention CLAUDE.md §7 :
--   - une migration ne se modifie jamais une fois mergée (corrections par compensation)
--   - pas de DROP TABLE / DROP COLUMN / RENAME sans expand-then-contract
--   - colonnes NOT NULL → valeur par défaut ou backfill dans la même migration
--
-- Idempotence : `IF NOT EXISTS` sur les ADD COLUMN.

BEGIN;

-- Cohérent DEFAULT TRUE de `profile_unverified` (ADR-007 D1) : un nouvel
-- onboarding INSEE marque les 4 champs comme non-attestés tant qu'aucun
-- KYC SuperPDP `verified` n'a réconcilié/cleared.
ALTER TABLE customers
  ADD COLUMN IF NOT EXISTS siren_unverified BOOLEAN NOT NULL DEFAULT TRUE;
ALTER TABLE customers
  ADD COLUMN IF NOT EXISTS legal_name_unverified BOOLEAN NOT NULL DEFAULT TRUE;
ALTER TABLE customers
  ADD COLUMN IF NOT EXISTS address_unverified BOOLEAN NOT NULL DEFAULT TRUE;
ALTER TABLE customers
  ADD COLUMN IF NOT EXISTS vat_number_unverified BOOLEAN NOT NULL DEFAULT TRUE;

-- Backfill rétrocompat (Z6) : recopie une fois le flag global legacy
-- dans les 4 colonnes pour les rows existantes (la migration ne
-- s'applique qu'une fois — `_migrations_applied`). Les rows déjà
-- `profile_unverified=FALSE` (KYC passé) restent toutes FALSE → pas de
-- badge réarmé (cohérent non-régression D1 ADR-007bis / ADR-007ter).
UPDATE customers
SET siren_unverified = profile_unverified,
    legal_name_unverified = profile_unverified,
    address_unverified = profile_unverified,
    vat_number_unverified = profile_unverified;

COMMIT;
