-- Migration: init_auth_helpers
-- Generated: 20260430T100000 UTC
--
-- Fonctions utilitaires partagées par les tables auth (customers, users) :
-- trigger générique `set_updated_at` qui maintient `updated_at` à NOW()
-- à chaque UPDATE. Postgres 16 fournit `gen_random_uuid()` nativement,
-- pas besoin d'extension pgcrypto.

BEGIN;

CREATE OR REPLACE FUNCTION set_updated_at() RETURNS trigger AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

COMMIT;
