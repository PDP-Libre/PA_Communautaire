-- Migration: add_type_code_to_received_invoices
-- Generated: 20260612T062006 UTC
-- Convention CLAUDE.md §7 :
--   - une migration ne se modifie jamais une fois mergée (corrections par compensation)
--   - pas de DROP TABLE / DROP COLUMN / RENAME sans expand-then-contract
--   - colonnes NOT NULL → valeur par défaut ou backfill dans la même migration

-- AVOIR-11 / R5 (T-CL-RECV-RECTIF-AFNOR sprint-09) : type de pièce BT-3
-- (UN/CEFACT 380 facture / 381 avoir / 384 rectificative) mis en cache sur la
-- ligne pour rendre la LISTE réception type-aware sans re-parser le document de
-- chaque ligne (la fiche, elle, dérive le type on-demand du XML parsé).
--
-- NULLABLE volontairement (expand-then-contract, ADR-009 D1) : alimenté à
-- l'INSERT depuis le snapshot PA `en_invoice.type_code` (BT-3, exposé par
-- SuperPDP). Reste NULL quand la source ne porte pas le type (extraction
-- stricte, pas de fallback "380" — GAP-5) ou pour les lignes antérieures à
-- cette migration (backfill non requis : la fiche reste correcte via le parse
-- on-demand, la liste affiche simplement un libellé neutre).

BEGIN;

ALTER TABLE received_invoices
  ADD COLUMN IF NOT EXISTS type_code TEXT;

COMMENT ON COLUMN received_invoices.type_code IS
  'BT-3 type de pièce (380/381/384), cache liste — NULL si indéterminé au poll (AVOIR-11).';

COMMIT;
