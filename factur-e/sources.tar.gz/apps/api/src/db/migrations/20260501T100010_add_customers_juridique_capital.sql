-- Migration: add_customers_juridique_capital
-- Generated: 20260501T100010 UTC
--
-- - `juridique_code` was missing from T-CL-01 schema. Stored from the
--   INSEE `categorieJuridiqueUniteLegale` at phase 1 finalize (T-CL-03
--   `finalizePhase1` patched). Used by T-CL-06 to drive the conditional
--   `capital_social` validation (brief §6.17 — required for SAS / SARL /
--   SA / EURL / SELARL, masked otherwise).
--
-- - `capital_social` brief §6.17 requirement. NUMERIC(15,2) covers up to
--   9 999 999 999 999.99 € (12 digits before decimal). Currency is the
--   customer's `default_invoice_values.currency` JSONB; we don't add a
--   separate column (capital is reported on invoices, denominated in the
--   customer's primary currency).
--
-- Both nullable — backfilled progressively by phase 1 finalize for
-- juridique_code, and by §6.17 phase 2 for capital_social.

BEGIN;

ALTER TABLE customers
  ADD COLUMN juridique_code  TEXT,
  ADD COLUMN capital_social  NUMERIC(15, 2);

COMMIT;
