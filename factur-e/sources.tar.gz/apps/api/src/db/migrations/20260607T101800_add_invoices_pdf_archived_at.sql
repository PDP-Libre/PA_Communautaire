-- T-CL-RECONSTRUCT-FIDELE-F8 sprint-08 — Copie immuable du PDF transmis (F8).
--
-- À l'envoi (`POST /api/invoices`), le PDF Factur-X assemblé réellement
-- transmis à la PA est copié sur le stockage objet (réutilise l'infra
-- export-zip, fenêtre de **conservation 180 j** — pas d'archivage légal :
-- doctrine PRD §1.6 / US-EMIT-012, l'archivage 10 ans est à la charge de
-- l'utilisateur via l'export ZIP). `GET /api/invoices/:id/pdf` sert cette
-- copie immuable pour une facture envoyée (intégrité : bytes stables, ≠
-- reconstruction dynamique dont l'ID trailer dépend de la generationDate).
--
-- `pdf_archived_at` = horodatage de la copie réussie (flag de service, évite
-- un probe S3 à chaque GET). NULL =
--   - facture jamais envoyée (brouillon/preview) → reconstruction ;
--   - facture envoyée AVANT ce fix (legacy) → fallback reconstruction.
-- Pas de backfill (les legacy restent NULL = fallback fail-safe, ADR-009).
--
-- Idempotence : `IF NOT EXISTS`.

BEGIN;

ALTER TABLE invoices
  ADD COLUMN IF NOT EXISTS pdf_archived_at TIMESTAMPTZ NULL;

COMMIT;
