-- Migration: add_invoice_preceding_invoice_id
-- Generated: 20260527T131744 UTC
--
-- L11 Avoirs/rectificatives (sprint-06 T-CL-CREDIT-NOTES). Matérialise le
-- lien BG-3 (BR-55) entre un avoir (BT-3 = 381) ou une rectificative
-- (BT-3 = 384) et sa facture d'origine (BT-1).
--
-- `type_code` existe déjà (migration 20260516T064718_create_invoices.sql,
-- colonne `type_code TEXT NOT NULL DEFAULT '380'`) — non ré-ajoutée ici.
--
-- Ajout unique : `preceding_invoice_id` — FK self-référentielle vers
-- `invoices(id)` (la facture d'origine 380). NULL pour une facture
-- standard. Posée au moment de l'INSERT de l'avoir/rectificative (au
-- moment de l'envoi PA via POST /api/invoices, cf. modèle invoice_drafts :
-- une ligne invoices n'existe qu'après transmission). Pas de ON DELETE
-- CASCADE : l'origine est conservée 10 ans (obligation légale) et n'est
-- jamais supprimée physiquement ; les avoirs/rectificatives portent le
-- lien sans contrainte de suppression.
--
-- Index :
--   - `idx_invoices_preceding` : lookup rapide des documents enfants d'une
--     origine (GET /api/invoices/:id → linked_invoices) + résolution du
--     numéro origine sur les lignes liste. Partiel (NOT NULL only).
--   - `idx_invoices_type_code` : filtre liste par type (pills
--     Avoirs/Rectificatives). Partiel (exclut le cas standard 380 majoritaire).
--
-- Migration additive sans backfill : toutes les factures existantes sont
-- type 380, preceding_invoice_id reste NULL (Z10).

BEGIN;

ALTER TABLE invoices
  ADD COLUMN preceding_invoice_id UUID REFERENCES invoices(id);

CREATE INDEX idx_invoices_preceding
  ON invoices(preceding_invoice_id)
  WHERE preceding_invoice_id IS NOT NULL;

CREATE INDEX idx_invoices_type_code
  ON invoices(type_code)
  WHERE type_code <> '380';

COMMIT;
