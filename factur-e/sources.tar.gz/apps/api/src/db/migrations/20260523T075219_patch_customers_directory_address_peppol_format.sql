-- T-CL-PA-DIRECTORY-PEPPOL sprint-05 — Patch idempotent des valeurs
-- erronées historiques `customers.directory_address`.
--
-- Contexte : sprint-02 `phase1.ts:148` set `directory_address = siren`
-- brut (sans scheme `0225:`). Pour les customers déjà signés up
-- sandbox/dev sprint-02/03/04, la valeur ne match pas le format Peppol
-- attendu par `buildSellerTradeParty` (BT-34 manquant à l'émission).
--
-- Stratégie best-effort : ajouter le scheme `0225:` devant le SIREN
-- brut. Le suffixe propriétaire SuperPDP `_<suffix>` (ex. `_3686`) sera
-- ajouté ultérieurement par le job `enrich-customer-peppol-address`
-- (re-fetch annuaire) ou le script Node `migrate-customer-directory-
-- addresses.ts` (best-effort manuel).
--
-- Idempotence : clause `WHERE directory_address ~ '^[0-9]{9}$'` ne
-- match que les valeurs SIREN brut (9 digits sans scheme). Re-exécution
-- = no-op.
--
-- ROW COUNT estimé : 2-5 rows (sandbox BQ + Tricatel dev local + tests
-- d'intégration éphémères). Prod sprint-09+ aura zéro row (callback OAuth
-- du jour 1 produira directement `0225:<SIREN>[_<suffix>]`).

BEGIN;

UPDATE customers
SET directory_address = '0225:' || directory_address
WHERE deleted_at IS NULL
  AND directory_address ~ '^[0-9]{9}$';

COMMIT;
