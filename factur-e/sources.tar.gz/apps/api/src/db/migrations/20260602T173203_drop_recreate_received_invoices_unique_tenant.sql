-- T-CL-HOTFIX-RECV-UNIQUE-TENANT sprint-07 (finding R1 recette T-BR-SPRINT-07)
-- Scoper l'unicité d'idempotence `received_invoices` par client.
--
-- Bug latent sprint-05 (migration `20260525T093000`, index `:57`) : l'index
-- d'idempotence du worker de réception était UNIQUE *global* sur
-- `pa_invoice_id_in`. Or `pa_invoice_id_in` (= `invoice.id` SuperPDP) n'est
-- unique qu'au sein d'un compte SuperPDP, pas globalement. Si deux clients
-- Factur-E partagent un compte SuperPDP, le premier à poller « réserve »
-- globalement la ligne → `ON CONFLICT DO NOTHING` skip chez l'autre → l'autre
-- ne reçoit jamais cette facture (réception partielle).
--
-- Correctif : clé naturelle d'idempotence ADR-009 D4 = `(customer_id,
-- pa_invoice_id_in)`, pas `pa_invoice_id_in` seul. Migration compensatoire
-- (CLAUDE.md §7.3 — la migration sprint-05 historique n'est pas modifiée).
--
-- Relaxation, pas de dédup : l'ancienne contrainte globale était plus stricte
-- que la nouvelle (scopée) → toute paire de lignes vivantes distinctes sur
-- `pa_invoice_id_in` reste distincte sur `(customer_id, pa_invoice_id_in)`.
-- Aucune ligne existante ne peut violer la nouvelle clé. Le bloc de garde
-- ci-dessous l'acte explicitement (attendu : 0).

BEGIN;

-- Garde anti-doublon défensive (par sécurité — attendu 0 vu la contrainte
-- globale antérieure plus stricte). Abort la migration si une collision
-- inattendue existait, plutôt que de la masquer.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM received_invoices
    WHERE deleted_at IS NULL
    GROUP BY customer_id, pa_invoice_id_in
    HAVING count(*) > 1
  ) THEN
    RAISE EXCEPTION
      'received_invoices: doublons (customer_id, pa_invoice_id_in) sur lignes vivantes — investiguer avant de scoper la clé';
  END IF;
END $$;

-- Ancien index global (non scopé tenant) → nouvel index scopé customer_id.
DROP INDEX received_invoices_pa_invoice_id_in_uk;

-- ADR-009 D4 — idempotence worker, clé naturelle scopée par client. UNIQUE
-- partiel sur les lignes vivantes : un même flux PA re-vu à chaque tick n'est
-- inséré qu'une fois *pour un client donné*, mais deux clients distincts
-- partageant un compte SuperPDP reçoivent chacun leur copie.
CREATE UNIQUE INDEX received_invoices_customer_pa_invoice_id_in_uk
  ON received_invoices (customer_id, pa_invoice_id_in)
  WHERE deleted_at IS NULL;

COMMENT ON COLUMN received_invoices.pa_invoice_id_in IS
  'ID SuperPDP du flux entrant (invoice.id stringifié). UNIQUE par (customer_id, pa_invoice_id_in) sur lignes vivantes pour idempotence worker ON CONFLICT DO NOTHING (scopé tenant — T-CL-HOTFIX-RECV-UNIQUE-TENANT).';

COMMIT;
