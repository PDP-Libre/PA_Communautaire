-- T-CL-RECV-API sprint-05 W2 — table `received_invoices` (L10 Réception
-- minimal+). Factures reçues via SuperPDP polling
-- `GET /v1.beta/invoices?direction=in` (ADR-010 v2 — pas de `/flows/*`,
-- cf. [NOTE-COWORK] pivot prompt v1→v2 trace sprint-05).
--
-- Schéma cf. PRD v1.6 §6.2 + invariants sprint-05 §5. Colonnes alimentées
-- par le worker `poll-received-invoices.ts` depuis `expand[]=en_invoice`
-- (données EN 16931 structurées JSON, pas de parsing XML en boucle).
--
-- Idempotence ADR-009 D4 : UNIQUE `(pa_invoice_id_in)` partiel sur les
-- lignes vivantes → worker `INSERT … ON CONFLICT DO NOTHING`.

BEGIN;

CREATE TABLE received_invoices (
  id                       uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id              uuid        NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  -- ID SuperPDP du flux entrant (= `invoice.id` integer stringifié).
  -- UNIQUE (partiel deleted_at IS NULL) pour idempotence worker.
  pa_invoice_id_in         text        NOT NULL,
  -- Provider d'origine — forward-compat multi-PA (V1 'superpdp').
  pa_provider              text        NOT NULL DEFAULT 'superpdp',
  -- BT-31 SIREN émetteur (extrait `en_invoice.seller`). NOT NULL : un flux
  -- sans SIREN parsable est skippé worker (audit), jamais inséré.
  seller_siren             text        NOT NULL,
  -- Cache raison sociale fournisseur (annuaire `directory_cache` 7j +
  -- fallback `en_invoice.seller.name`). NULL → "Fournisseur non identifié"
  -- (brief §6.8) si ni annuaire ni parsing ne résolvent.
  seller_name_cached       text,
  -- True si le SIREN a matché l'annuaire PA (directory_cache / searchSiren).
  -- False → warning UI "Fournisseur non identifié" (brief §6.8). Ne bloque
  -- jamais la pose de statut.
  supplier_matched         boolean     NOT NULL DEFAULT false,
  invoice_number_extracted text,                                  -- BT-1
  issue_date               date,                                  -- BT-2
  due_date                 date,                                  -- BT-9 (échéance liste)
  total_ttc_cents          integer,                               -- BT-112 (cents, pas de float)
  currency                 char(3)     DEFAULT 'EUR',             -- BT-5
  -- Format détecté ('facturx' | 'ubl' | 'cii') — hint, peut être NULL si
  -- non déterminé à la réception (rempli au parsing fiche on-demand).
  format                   text,
  -- FacturEStatusCode normalisé (enum 21 valeurs T-CL-PA-STATUS-RFC W1).
  -- Default 'in_process' = fr:204 "Prise en charge" (glossaire UI base
  -- "Reçue"). NB : le prompt mentionnait 'received_by_pa' qui n'est pas une
  -- valeur valide de l'enum — mappé sur 'in_process' (cf. [NOTE-COWORK]).
  status_current           text        NOT NULL DEFAULT 'in_process',
  -- Mark-as-read user (badge unread Bell topbar W2 RECV-WEB).
  read_at                  timestamptz,
  received_at              timestamptz NOT NULL DEFAULT NOW(),
  deleted_at               timestamptz,
  created_at               timestamptz NOT NULL DEFAULT NOW(),
  updated_at               timestamptz NOT NULL DEFAULT NOW()
);

-- ADR-009 D4 — idempotence worker. UNIQUE partiel sur les lignes vivantes :
-- un même flux PA re-vu à chaque tick n'est inséré qu'une fois.
CREATE UNIQUE INDEX received_invoices_pa_invoice_id_in_uk
  ON received_invoices (pa_invoice_id_in)
  WHERE deleted_at IS NULL;

-- Liste filtrable (customer + statut + date desc) — endpoint GET liste.
CREATE INDEX received_invoices_list_idx
  ON received_invoices (customer_id, status_current, received_at DESC)
  WHERE deleted_at IS NULL;

-- Matching SIREN fournisseur (jointure annuaire + filtre liste).
CREATE INDEX received_invoices_seller_siren_idx
  ON received_invoices (seller_siren)
  WHERE deleted_at IS NULL;

COMMENT ON TABLE received_invoices IS
  'Factures reçues via SuperPDP polling GET /v1.beta/invoices?direction=in. T-CL-RECV-API sprint-05 W2 (ADR-010 v2).';
COMMENT ON COLUMN received_invoices.pa_invoice_id_in IS
  'ID SuperPDP du flux entrant (invoice.id stringifié). UNIQUE (vivants) pour idempotence worker ON CONFLICT DO NOTHING.';
COMMENT ON COLUMN received_invoices.status_current IS
  'FacturEStatusCode normalisé (T-CL-PA-STATUS-RFC W1, mapping AFNOR XP Z12-013). Default in_process (fr:204).';

COMMIT;
