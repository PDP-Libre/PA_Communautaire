-- Migration: create_invoices
-- Generated: 20260516T064718 UTC
--
-- Tables Émission B2B core (sprint-04 T-CL-API-INVOICE, lots L08 + amorce L09).
-- Cf. PRD v1.5 §5.6 EMIT-001..009 + §6.2 modèle données + plan.md sprint-04.
--
-- Multi-tenant strict (customer_id NOT NULL FK ON DELETE CASCADE — RGPD admin).
--
-- Stratégie de modélisation :
--   - Colonnes relationnelles searchables/indexables : number, issue_date,
--     totaux, currency, processing_rule, type_code, status_current, sha256,
--     tracking_id (BT-1, BT-2, BT-106..115, BT-5, BT-3...).
--   - `payload_extended jsonb` pour les 39 champs additionnels mode UI avancé
--     non-modélisés en colonnes (BT-13/14 commandes, BG-13 expédition, BG-20
--     remise globale, VATEX BT-121, 4 zones commentaires, ICS BT-90,
--     acompte BT-113, etc.). Permet d'évoluer le mode avancé sans migration.
--
-- `tracking_id uuid UNIQUE` (UUIDv7 généré côté Factur-E) : idempotence
-- consommée par pa-adapter.submitInvoice côté PA (US-EMIT-005 critère 2).
--
-- `status_current text NULL` (pas enum) : cohérent ADR-009 D2 — colonne texte
-- pour évoluer les valeurs (`Déposée`, `Transmise`, `204 Prise en charge`,
-- `205 Approuvée`, `210 Refusée`, `212 Encaissée`, `209 Annulée`,
-- `501 Irrecevable`, `213 Rejet métier`...) sans migration BDD.
--
-- `pa_flow_id text NULL` : populé après submitInvoice OK, NULL pendant la tx.
-- `pa_provider text DEFAULT 'superpdp'` : extensibilité multi-PA V2.
-- `submitted_at` : populé à la fin de la transaction émission.
--
-- Soft-delete via `deleted_at` (cohérent customers/users sprint-02).
--
-- Index :
--   - `(customer_id, number) UNIQUE WHERE deleted_at IS NULL` :
--     US-EMIT-002 unicité du numéro par customer (validation à la perte de
--     focus côté UI via POST /api/invoices/check-number-unique).
--   - `(customer_id, issue_date DESC)` : pagination liste Émission ordered
--     par date d'émission (le plus récent d'abord) — pattern §6.2 brief.
--   - `(customer_id, status_current)` : filtre pills (Brouillons / En cours /
--     Approuvées / Refusées) §6.2 brief.
--   - `tracking_id UNIQUE` : recherche par tracking + idempotence PA.
--
-- Pattern repo T-CL-01 : `findActive*ByCustomer*` avec garde `deleted_at IS NULL`,
-- `findInvoiceByIdAndCustomer` (tenant isolation), `updateInvoicePaSubmission`
-- (UPDATE atomique post-submitInvoice OK).

BEGIN;

CREATE TABLE invoices (
  id                UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id       UUID          NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  number            TEXT          NOT NULL,
  issue_date        DATE          NOT NULL,
  tracking_id       UUID          NOT NULL DEFAULT gen_random_uuid(),
  total_ht          NUMERIC(15,2) NOT NULL DEFAULT 0,
  total_vat         NUMERIC(15,2) NOT NULL DEFAULT 0,
  total_ttc         NUMERIC(15,2) NOT NULL DEFAULT 0,
  currency          CHAR(3)       NOT NULL DEFAULT 'EUR',
  processing_rule   TEXT          NOT NULL DEFAULT 'B2B'
                    CHECK (processing_rule IN ('B2B', 'B2BInt')),
  type_code         TEXT          NOT NULL DEFAULT '380'
                    CHECK (type_code IN ('380', '381', '384', '386', '389', '261')),
  pa_flow_id        TEXT,
  pa_provider       TEXT          NOT NULL DEFAULT 'superpdp',
  sha256            CHAR(64),
  submitted_at      TIMESTAMPTZ,
  status_current    TEXT,
  payload_extended  JSONB         NOT NULL DEFAULT '{}'::jsonb,
  deleted_at        TIMESTAMPTZ,
  created_at        TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

-- Unicité du numéro par customer (US-EMIT-002 critère 2). Partial index
-- WHERE deleted_at IS NULL pour permettre la réutilisation d'un numéro
-- après hard-delete admin (cas RGPD).
CREATE UNIQUE INDEX invoices_customer_number_uniq
  ON invoices (customer_id, number)
  WHERE deleted_at IS NULL;

-- Pagination liste Émission ordered par date émission (le plus récent d'abord).
CREATE INDEX invoices_customer_issue_date_idx
  ON invoices (customer_id, issue_date DESC)
  WHERE deleted_at IS NULL;

-- Filtre par statut (pills liste Émission §6.2 brief).
CREATE INDEX invoices_customer_status_current_idx
  ON invoices (customer_id, status_current)
  WHERE deleted_at IS NULL AND status_current IS NOT NULL;

-- tracking_id UNIQUE global (idempotence PA + recherche par tracking).
CREATE UNIQUE INDEX invoices_tracking_id_uniq
  ON invoices (tracking_id);

COMMIT;
