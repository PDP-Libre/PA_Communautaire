-- Migration: create_insee_cache
-- Generated: 20260430T100060 UTC
--
-- Cache local des réponses INSEE Sirene. Réduit la pression sur l'API
-- INSEE (rate limit, latence) et survit aux incidents Sirene. TTL 90 j
-- (plan.md T-CL-05). Clé = SIREN du customer recherché. Indépendant de
-- la table customers (un SIREN peut être recherché sans qu'un compte
-- existe — onboarding §6.2 / §6.3).

BEGIN;

CREATE TABLE insee_cache (
  siren           CHAR(9)      PRIMARY KEY,
  payload         JSONB        NOT NULL,
  establishments  JSONB        NOT NULL DEFAULT '[]'::jsonb,
  fetched_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  expires_at      TIMESTAMPTZ  NOT NULL
);

CREATE INDEX insee_cache_expires_at_idx ON insee_cache (expires_at);

COMMIT;
