-- T-CL-RECV-API sprint-05 W2 — extension `pa_polling_state` avec colonne
-- `direction` (§7.5 Z9). Migration ADDITIVE, non-breaking.
--
-- Pourquoi : le polling SORTANT (`poll-cdar-events.ts`, cursor
-- `GET /v1.beta/invoice_events?starting_after_id=`) et le polling ENTRANT
-- (`poll-received-invoices.ts`, cursor `GET /v1.beta/invoices?direction=in
-- &starting_after_id=`) sont DEUX cursors distincts pour le même couple
-- (customer_id, 'superpdp'). Le PK composite `(customer_id, provider)`
-- d'origine (ADR-012 D5) provoquerait une collision. On scope donc le
-- cursor par `direction` ('in' | 'out').
--
-- Compat : DEFAULT 'out' backfill les lignes existantes (cursor sortant
-- `invoice_events`). Le repo `pa_polling_state.ts` expose un param
-- `direction` optionnel défaut 'out' → `poll-cdar-events.ts` reste intact.

BEGIN;

ALTER TABLE pa_polling_state
  ADD COLUMN direction text NOT NULL DEFAULT 'out';

-- Recompose le PK pour inclure la direction (les lignes existantes sont
-- déjà backfillées 'out' par le DEFAULT ci-dessus).
ALTER TABLE pa_polling_state DROP CONSTRAINT pa_polling_state_pkey;
ALTER TABLE pa_polling_state
  ADD CONSTRAINT pa_polling_state_pkey PRIMARY KEY (customer_id, provider, direction);

ALTER TABLE pa_polling_state
  ADD CONSTRAINT pa_polling_state_direction_check CHECK (direction IN ('in', 'out'));

COMMENT ON COLUMN pa_polling_state.direction IS
  'Scope du cursor : out (invoice_events, émission) | in (invoices?direction=in, réception). T-CL-RECV-API sprint-05 W2 §7.5 Z9.';

COMMIT;
