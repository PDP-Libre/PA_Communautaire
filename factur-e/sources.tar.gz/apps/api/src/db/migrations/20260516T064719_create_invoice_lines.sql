-- Migration: create_invoice_lines
-- Generated: 20260516T064719 UTC
--
-- Lignes de facture (BG-25 SupplyChainTradeLineItem EN 16931) — sprint-04
-- T-CL-API-INVOICE. Cohérence avec migration jumelle create_invoices.
--
-- FK invoice_id ON DELETE CASCADE : si une invoice est hard-delete (admin
-- RGPD), ses lignes disparaissent en même temps. Pas de soft-delete au
-- niveau ligne — la ligne suit l'invoice.
--
-- **Mécanique Article = initialiseur (T-CW-11 acté)** :
--   Pas de FK vers `products`. Une ligne est créée soit en saisie libre
--   soit via `LineItemPicker` qui pré-remplit les valeurs depuis un
--   Article catalogue. Après initialisation, la ligne est INDÉPENDANTE
--   de l'Article source — modifier la ligne ne modifie pas l'Article,
--   modifier l'Article ne propage pas vers les lignes historisées.
--   Test négatif obligatoire dans tests d'intégration sprint-04.
--
-- Précision décimale BT-129 (quantity) + BT-146 (unit_price_ht) :
-- 4 décimales (EN 16931). Totaux 2 décimales (BR-DEC-* sur amounts).
--
-- `vat_rate numeric(5,2) NULL` : NULL pour AE/Z/E/K/G/O qui n'ont pas
-- de taux applicable (la catégorie suffit + VATEX pour exonération).
--
-- `payload_extended jsonb` : extensions mode UI avancé non en colonnes :
--   - BT-127 note ligne (cardinalité 0..n)
--   - BT-149 quantité de base
--   - BT-121 VATEX code (peut être promu en colonne en V1 si recherche
--     intensive — pour MVP on garde en jsonb car non indexable utile)
--   - BT-154 description longue (long_description)
--   - allowance.reason / reasonCode / percent / baseAmount (BG-27/28)
--
-- Index `(invoice_id, line_number)` : ordering ligne dans la fiche
-- (ASC). Pas d'UNIQUE car (invoice_id, line_number) est l'ordering
-- canonique mais peut être réécrit en éditant ; on évite la contrainte.

BEGIN;

CREATE TABLE invoice_lines (
  id                UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_id        UUID          NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  line_number       INT           NOT NULL,
  label             TEXT          NOT NULL,
  description       TEXT,
  quantity          NUMERIC(15,4) NOT NULL CHECK (quantity > 0),
  unit_code         TEXT          NOT NULL DEFAULT 'C62',
  unit_price_ht     NUMERIC(15,4) NOT NULL CHECK (unit_price_ht >= 0),
  vat_rate          NUMERIC(5,2)  CHECK (vat_rate IS NULL OR (vat_rate >= 0 AND vat_rate <= 100)),
  vat_category      TEXT          NOT NULL DEFAULT 'S'
                    CHECK (vat_category IN ('S', 'AE', 'Z', 'E', 'K', 'G', 'O')),
  total_ht          NUMERIC(15,2) NOT NULL,
  period_start      DATE,
  period_end        DATE,
  allowance_amount  NUMERIC(15,2),
  charge_amount     NUMERIC(15,2),
  payload_extended  JSONB         NOT NULL DEFAULT '{}'::jsonb
);

-- Ordering ligne dans la fiche (ASC) — chargé par findLinesByInvoiceId.
CREATE INDEX invoice_lines_invoice_line_number_idx
  ON invoice_lines (invoice_id, line_number);

COMMIT;
