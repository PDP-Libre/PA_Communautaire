-- Migration: create_directory_cache
-- Generated: 20260506T193144 UTC
--
-- Cache local des resultats annuaire SuperPDP (T-CL-09 sprint-03).
-- Reduit la latence + protege contre les rate limits SuperPDP (30 req/s).
-- Cf. PRD v1.4 §5.5 + audit T-CW-08 §3 + ROADMAP L07.
--
-- Endpoints SuperPDP cascadés cote adapter `pa-adapter` :
--   GET /v1.beta/french_directory/companies?number={siren} -> raw company
--   GET /v1.beta/french_directory/entries?number={siren}   -> array adresses Peppol
--
-- Cache 7 j (PRD §5.5 critere 7). Cache aussi les outcomes negatifs
-- `not_found` / `disabled` (le user qui re-cherche un siren inexistant
-- ne consomme pas de quota SuperPDP). PAS de cache pour les outcomes
-- `unavailable` (5xx / timeout transient -- meme strategie que
-- `insee_cache` T-CL-05 sprint-02).
--
-- `payload` = raw `french_directory_company` JSON (number, formal_name,
-- address, postcode, city, country) ou NULL si negative cache.
-- `addresses` = array de `french_directory_entry` filtres `is_replyto=false`
-- cote adapter (audit T-CW-08 §3.2). Vide si pas d'adresse active.
--
-- Cleanup non automatise -- l'expires_at filter dans les SELECTs garantit
-- la correctness ; la purge disque est deferree (potentiellement T-CL-10
-- ou plus tard, pattern T-CL-03 cleanup-expired existant a etendre).

BEGIN;

CREATE TABLE directory_cache (
  siren        CHAR(9)      PRIMARY KEY,
  payload      JSONB,                                      -- raw company, NULL si not_found
  addresses    JSONB        NOT NULL DEFAULT '[]'::jsonb,  -- entries Peppol filtres is_replyto=false
  fetched_at   TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  expires_at   TIMESTAMPTZ  NOT NULL DEFAULT (NOW() + INTERVAL '7 days')
);

CREATE INDEX directory_cache_expires_at_idx ON directory_cache (expires_at);

COMMIT;
