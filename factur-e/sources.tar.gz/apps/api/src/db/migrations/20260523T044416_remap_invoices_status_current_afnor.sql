-- T-CL-PA-STATUS-RFC sprint-05 — Re-mapping idempotent de
-- `invoices.status_current` post refonte AFNOR XP Z12-013 stricte.
--
-- Contexte : 7 entrées `fr:*` SuperPDP étaient sémantiquement fausses
-- sprint-04 (NC-19 audit). Les `invoices` ayant reçu un cdar_event
-- `fr:204/205/206/207/208/211/213` portent un `status_current` issu de
-- l'ancien mapping faux. Cette migration corrige les valeurs persistées
-- en s'appuyant sur le dernier `cdar_events.code` réel par invoice.
--
-- Stratégie : `DISTINCT ON (invoice_id) ... ORDER BY occurred_at DESC`
-- pour retenir uniquement le dernier event par facture (évite les faux
-- positifs sur factures multi-events). Idempotente via clause
-- `AND i.status_current = '<ancienne_valeur>'` — re-exécuter cette
-- migration sur une BDD déjà patchée est un no-op.
--
-- Scope : dev + staging (sandbox SuperPDP). Prod sera migrée sprint-09+
-- pré-pilote via migration dédiée + plan de rollback (rows production
-- inexistantes sprint-05).
--
-- ROW COUNT estimé : 0-30 rows (sandbox BQ + Tricatel — selon historique
-- recettes T-BR-EMIT/CDAR sprint-04).
--
-- Cf. ADR-012 D2 amendée + `docs/guides/cdar.md` (T-BR-CDAR sprint-04).

BEGIN;

-- CTE : dernier code raw cdar_events par invoice (ORDER BY occurred_at
-- DESC). Une seule ligne par invoice_id grâce à DISTINCT ON.
WITH latest_event AS (
  SELECT DISTINCT ON (invoice_id) invoice_id, code
  FROM cdar_events
  ORDER BY invoice_id, occurred_at DESC
)

-- fr:204 Prise en charge → in_process (était `refused_business`)
UPDATE invoices i
SET status_current = 'in_process'
FROM latest_event le
WHERE le.invoice_id = i.id
  AND le.code = 'fr:204'
  AND i.status_current = 'refused_business';

-- fr:205 Approuvée → accepted_business (était `refused_business`)
WITH latest_event AS (
  SELECT DISTINCT ON (invoice_id) invoice_id, code
  FROM cdar_events
  ORDER BY invoice_id, occurred_at DESC
)
UPDATE invoices i
SET status_current = 'accepted_business'
FROM latest_event le
WHERE le.invoice_id = i.id
  AND le.code = 'fr:205'
  AND i.status_current = 'refused_business';

-- fr:206 Approuvée partiellement → partially_accepted (était `accepted_business`)
WITH latest_event AS (
  SELECT DISTINCT ON (invoice_id) invoice_id, code
  FROM cdar_events
  ORDER BY invoice_id, occurred_at DESC
)
UPDATE invoices i
SET status_current = 'partially_accepted'
FROM latest_event le
WHERE le.invoice_id = i.id
  AND le.code = 'fr:206'
  AND i.status_current = 'accepted_business';

-- fr:207 En litige → under_query (était `accepted_business`)
WITH latest_event AS (
  SELECT DISTINCT ON (invoice_id) invoice_id, code
  FROM cdar_events
  ORDER BY invoice_id, occurred_at DESC
)
UPDATE invoices i
SET status_current = 'under_query'
FROM latest_event le
WHERE le.invoice_id = i.id
  AND le.code = 'fr:207'
  AND i.status_current = 'accepted_business';

-- fr:208 Complétée (info ajoutée) → info_complete (était `partially_accepted`)
WITH latest_event AS (
  SELECT DISTINCT ON (invoice_id) invoice_id, code
  FROM cdar_events
  ORDER BY invoice_id, occurred_at DESC
)
UPDATE invoices i
SET status_current = 'info_complete'
FROM latest_event le
WHERE le.invoice_id = i.id
  AND le.code = 'fr:208'
  AND i.status_current = 'partially_accepted';

-- fr:211 Paiement transmis (info) → payment_transmitted (était `on_hold`)
WITH latest_event AS (
  SELECT DISTINCT ON (invoice_id) invoice_id, code
  FROM cdar_events
  ORDER BY invoice_id, occurred_at DESC
)
UPDATE invoices i
SET status_current = 'payment_transmitted'
FROM latest_event le
WHERE le.invoice_id = i.id
  AND le.code = 'fr:211'
  AND i.status_current = 'on_hold';

-- fr:213 Rejet plateforme → rejected_compliance (était `completed`)
WITH latest_event AS (
  SELECT DISTINCT ON (invoice_id) invoice_id, code
  FROM cdar_events
  ORDER BY invoice_id, occurred_at DESC
)
UPDATE invoices i
SET status_current = 'rejected_compliance'
FROM latest_event le
WHERE le.invoice_id = i.id
  AND le.code = 'fr:213'
  AND i.status_current = 'completed';

COMMIT;
