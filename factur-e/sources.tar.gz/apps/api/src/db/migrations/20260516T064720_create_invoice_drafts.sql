-- Migration: create_invoice_drafts
-- Generated: 20260516T064720 UTC
--
-- Brouillons de facture en cours de saisie (US-EMIT-008-bis auto-save 5s
-- acté T-CW-09 §10.1 #4) — sprint-04 T-CL-API-INVOICE.
--
-- Multi-tenant strict (customer_id NOT NULL FK ON DELETE CASCADE).
--
-- Multiples drafts par customer autorisés (pas d'unicité — Q10 acté
-- Bruno 2026-05-16). Filtre pills "Brouillons" liste Émission affiche
-- tous les drafts du customer ordered by last_modified_at DESC.
--
-- `payload jsonb` : état partiel/cassé du formulaire 4 sections. Permissif
-- (cf. InvoiceFormDraftPayloadSchema côté shared-schemas) — la validation
-- stricte n'a lieu qu'au POST /api/invoices (envoi effectif).
--
-- `step_completed jsonb DEFAULT '{}'` : complétion % par section pour le
-- Stepper UI (consommé par `InvoiceFormStepper` T-CL-UI-01). Forme :
--   { document: 100, parties: 75, lines: 0, payment: 0 }
--
-- `last_modified_at` : touché à chaque PATCH (auto-save) — utilisé pour
-- ordering liste brouillons et détection de stale drafts.
--
-- Pas de soft-delete : un draft = état temporaire qui s'efface
-- soit à l'envoi (DELETE en fin de POST /api/invoices) soit à la
-- demande explicite user (DELETE /api/invoice-drafts/:id).
--
-- Index :
--   - `(customer_id, last_modified_at DESC)` : liste brouillons du
--     customer ordered par fraîcheur (le plus récemment modifié d'abord).

BEGIN;

CREATE TABLE invoice_drafts (
  id                UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id       UUID         NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  payload           JSONB        NOT NULL,
  step_completed    JSONB        NOT NULL DEFAULT '{}'::jsonb,
  last_modified_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  created_at        TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

-- Liste brouillons ordered par fraîcheur (le plus récent d'abord).
CREATE INDEX invoice_drafts_customer_last_modified_idx
  ON invoice_drafts (customer_id, last_modified_at DESC);

COMMIT;
