-- Migration: create_users
-- Generated: 20260430T100020 UTC
--
-- Utilisateur d'un customer Factur-e. Plusieurs users par customer
-- (Responsable + employés/proches/comptable). Source : PRD §6.2 + brief
-- design sprint-02 §5.5 / §5.6.
--
-- Notes :
-- - `password_hash` : argon2id (PRD §6.2 / §7.1 / §4.1). bcrypt cost 12
--   réservé aux recovery_codes_hashed et invitations.token_hash.
-- - `mfa_secret` : TOTP secret chiffré AES-256-GCM (clé Keychain/Scaleway).
--   NULL si mfa_mode != 'totp'.
-- - `mfa_mode` : 'none' à la création, 'email' (défaut Pierre/Claire) ou
--   'totp' (opt-in Sophie/Claire chevronnée) après §6.6 choix sécurité.
-- - `recovery_codes_hashed` : 10 hashes bcrypt single-use. Affichés une
--   seule fois en clair à §6.9 puis NULL.
-- - `role` : 3 valeurs enum + flag `can_purchase` séparé. Cohérent
--   PRD §6.2 + brief §5.5 + US-AUTH-004 critère 2 (clarif Bruno T-CL-01).
-- - `secondary_email` : NOT NULL DEFAULT '' transitoire le temps que la
--   phase 1 (§6.5 saisie email secondaire) soit terminée. À renforcer
--   en NOT NULL strict via PRD v1.4 sprint-03 (cf. trace.md sprint-02).

BEGIN;

CREATE TABLE users (
  id                            UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id                   UUID         NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  email                         TEXT         NOT NULL UNIQUE,
  password_hash                 TEXT         NOT NULL,
  mfa_secret                    BYTEA,
  mfa_mode                      TEXT         NOT NULL DEFAULT 'none'
                                             CHECK (mfa_mode IN ('none', 'email', 'totp')),
  mfa_enrolled_at               TIMESTAMPTZ,
  recovery_codes_hashed         TEXT[],
  role                          TEXT         NOT NULL
                                             CHECK (role IN ('deposit_simple', 'deposit_states', 'full')),
  can_purchase                  BOOLEAN      NOT NULL DEFAULT FALSE,
  email_verified_at             TIMESTAMPTZ,
  secondary_email               TEXT         NOT NULL DEFAULT '',
  secondary_email_verified_at   TIMESTAMPTZ,
  last_login_at                 TIMESTAMPTZ,
  created_at                    TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  updated_at                    TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  deleted_at                    TIMESTAMPTZ
);

CREATE INDEX users_customer_id_idx ON users (customer_id);
CREATE INDEX users_customer_role_idx ON users (customer_id, role);

CREATE TRIGGER users_set_updated_at
  BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

COMMIT;
