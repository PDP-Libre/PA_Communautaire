-- Migration: create_otp_codes
-- Generated: 20260430T120000 UTC
--
-- One-Time Password codes (stateful) — used for:
--   - phase1_mfa_setup     : OTP envoyé pendant §6.7 activation MFA email
--   - login_mfa            : OTP envoyé pendant §6.11 login récurrent MFA email
--   - phase1_email_verify  : magic link / OTP §6.4 (T-CL-04 Scaleway TEM)
--   - phase1_secondary_verify : OTP §6.5b email secondaire (T-CL-04)
--
-- Stateful chosen over stateless JWT:
--   - single-use réel via consume (UPDATE consumed_at) — sans blocklist
--   - anti-bruteforce (3 tentatives → pause 30s) via attempts counter serveur
--   - audit/debug : on peut requêter "OTP envoyé non consommé" en support
--
-- Cleanup différé en `[DEBT]` (cron T-CW sprint-03, partagé avec
-- signup_pending). Pour T-CL-03 la table grossit ; en pratique chaque code
-- est consommé ou expire en 5 min, volume négligeable.
--
-- CHECK exactly_one : un code OTP est rattaché soit à un user (login_mfa),
-- soit à un signup_pending (phase 1), jamais aux deux.

BEGIN;

CREATE TABLE otp_codes (
  id                   UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id              UUID         REFERENCES users(id) ON DELETE CASCADE,
  signup_pending_id    UUID         REFERENCES signup_pending(id) ON DELETE CASCADE,
  code_hash            TEXT         NOT NULL,
  purpose              TEXT         NOT NULL
                                    CHECK (purpose IN (
                                      'phase1_mfa_setup',
                                      'login_mfa',
                                      'phase1_email_verify',
                                      'phase1_secondary_verify'
                                    )),
  attempts             INTEGER      NOT NULL DEFAULT 0,
  expires_at           TIMESTAMPTZ  NOT NULL,
  consumed_at          TIMESTAMPTZ,
  created_at           TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  CONSTRAINT otp_codes_owner_xor CHECK (
    num_nonnulls(user_id, signup_pending_id) = 1
  )
);

CREATE INDEX otp_codes_user_active_idx
  ON otp_codes (user_id, purpose, expires_at)
  WHERE consumed_at IS NULL;
CREATE INDEX otp_codes_signup_active_idx
  ON otp_codes (signup_pending_id, purpose, expires_at)
  WHERE consumed_at IS NULL;
CREATE INDEX otp_codes_expires_at_idx ON otp_codes (expires_at);

COMMIT;
