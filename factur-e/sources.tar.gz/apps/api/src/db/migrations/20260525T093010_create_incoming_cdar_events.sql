-- T-CL-RECV-API sprint-05 W2 — table `incoming_cdar_events` (timeline CDAR
-- des factures REÇUES). Table distincte de `cdar_events` (factures ÉMISES,
-- FK logique `invoices.id`) pour éviter l'ambiguïté de FK sur une colonne
-- `invoice_id` partagée (cf. §7.5 Z11 — arbitrage Bruno : table dédiée).
--
-- Events :
--  - fr:204 auto à la réception (worker, source 'polling').
--  - fr:205 / fr:210 posés par l'utilisateur via POST /:id/cdar (source
--    'app') — propagés à SuperPDP via POST /v1.beta/invoice_events.
--
-- Idempotence ADR-009 D4 : UNIQUE `(received_invoice_id, code, occurred_at)`
-- → `INSERT … ON CONFLICT DO NOTHING`.

BEGIN;

CREATE TABLE incoming_cdar_events (
  id                  uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  received_invoice_id uuid        NOT NULL REFERENCES received_invoices(id) ON DELETE CASCADE,
  -- Code natif PA (`fr:204`, `fr:205`, `fr:210`...). Stocké tel quel pour
  -- la timeline détaillée mode UI avancé (sprint-06+).
  code                text        NOT NULL,
  label               text,
  occurred_at         timestamptz NOT NULL,
  payload             jsonb       NOT NULL DEFAULT '{}'::jsonb,
  -- Motif de refus 210 — code Annexe E PRD (01..11) + texte libre
  -- (obligatoire si reason_code = '11').
  reason_code         text,
  reason_text         text,
  -- Source de l'event : 'polling' (worker, fr:204 auto), 'app' (pose
  -- utilisateur 205/210), 'webhook' (réservé V2 si AFNOR Flow déployé).
  source              text        NOT NULL DEFAULT 'polling',
  created_at          timestamptz NOT NULL DEFAULT NOW()
);

-- ADR-009 D4 — idempotence clé naturelle.
CREATE UNIQUE INDEX uq_incoming_cdar_events_natural_key
  ON incoming_cdar_events (received_invoice_id, code, occurred_at);

-- Timeline par facture reçue (GET /:id cdarEvents, ASC occurred_at).
CREATE INDEX idx_incoming_cdar_events_received_invoice
  ON incoming_cdar_events (received_invoice_id, occurred_at DESC);

-- Guard ceinture/bretelles (valeurs normalisées côté code).
ALTER TABLE incoming_cdar_events
  ADD CONSTRAINT incoming_cdar_events_source_check
  CHECK (source IN ('webhook', 'polling', 'app'));

COMMENT ON TABLE incoming_cdar_events IS
  'Timeline CDAR des factures reçues (received_invoices). Distincte de cdar_events (émission). T-CL-RECV-API sprint-05 W2.';

COMMIT;
