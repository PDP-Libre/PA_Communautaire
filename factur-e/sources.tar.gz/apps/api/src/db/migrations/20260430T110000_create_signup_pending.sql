-- Migration: create_signup_pending
-- Generated: 20260430T110000 UTC
--
-- État transitoire de la phase 1 d'onboarding (brief Design §5.1, plan
-- T-CL-02). Persisté pendant que l'utilisateur enchaîne signup → SIREN
-- → vérif email → email secondaire → MFA → recovery codes. À la fin
-- de la phase 1, transaction atomique (T-CL-03 `POST /auth/phase1/
-- complete`) : INSERT customers + INSERT users + DELETE signup_pending.
--
-- `email` n'est PAS UNIQUE — plusieurs sessions partielles peuvent
-- coexister pour le même email (anti-énumération via decoy + reprise
-- multi-onglets). Le cookie HttpOnly `signup_session` (JWT signé
-- contenant `signup_pending.id`) lie une session à une row précise.
--
-- `is_decoy = true` quand l'email est déjà utilisé par un user existant
-- (anti-énumération brief §6.1) : on crée la row mais on n'enverra pas
-- le lien de vérification, on enverra un lien reset à la place (T-CL-04
-- Scaleway TEM). Le frontend ne distingue pas decoy / non-decoy.
--
-- `current_step` énumère textuellement les sous-étapes — pas de CHECK
-- enum pour faciliter l'ajout de steps sans migration.
-- Valeurs attendues : siren, siret, email_verify, secondary_email,
-- mfa_choice, mfa_setup, recovery_codes.
--
-- TTL 7 jours (`expires_at`). Cleanup différé (`[DEBT]` cron T-CW
-- sprint-03).

BEGIN;

CREATE TABLE signup_pending (
  id                           UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
  email                        TEXT         NOT NULL,
  password_hash                TEXT         NOT NULL,
  terms_accepted_at            TIMESTAMPTZ  NOT NULL,
  siren                        CHAR(9),
  siret                        CHAR(14),
  customer_data_prefilled      JSONB,
  email_verified_at            TIMESTAMPTZ,
  secondary_email              TEXT,
  secondary_email_verified_at  TIMESTAMPTZ,
  mfa_mode_choice              TEXT
                               CHECK (mfa_mode_choice IS NULL OR mfa_mode_choice IN ('email', 'totp')),
  mfa_secret_pending           BYTEA,
  mfa_setup_completed_at       TIMESTAMPTZ,
  recovery_codes_pending       TEXT[],
  recovery_codes_acked_at      TIMESTAMPTZ,
  current_step                 TEXT         NOT NULL DEFAULT 'siren',
  is_decoy                     BOOLEAN      NOT NULL DEFAULT FALSE,
  created_at                   TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  expires_at                   TIMESTAMPTZ  NOT NULL DEFAULT (NOW() + INTERVAL '7 days')
);

CREATE INDEX signup_pending_email_idx ON signup_pending (email);
CREATE INDEX signup_pending_expires_at_idx ON signup_pending (expires_at);

COMMIT;
