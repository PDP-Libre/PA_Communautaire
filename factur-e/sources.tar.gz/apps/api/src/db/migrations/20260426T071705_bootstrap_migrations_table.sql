-- Migration: bootstrap_migrations_table
-- Generated: 20260426T071705 UTC
--
-- Crée la table de suivi des migrations appliquées. Idempotent : la même
-- DDL est exécutée par `runMigrations()` au démarrage avant le scan, donc
-- cette migration est essentiellement un marqueur explicite dans l'historique.

BEGIN;

CREATE TABLE IF NOT EXISTS _migrations_applied (
  name        TEXT        PRIMARY KEY,
  applied_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMIT;
