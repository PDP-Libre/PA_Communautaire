-- Migration: add_users_profile_fields
-- Generated: 20260501T100000 UTC
--
-- Phase 2 onboarding — brief Design §6.16 user profile fields. Nullable
-- because rows created before T-CL-06 don't have these (and signup phase
-- 1 doesn't collect them — they're recovered at §6.16 phase 2).
--
-- `function_title` (not `function`) because `function` is reserved in
-- some SQL dialects + ambiguous with the SQL keyword.

BEGIN;

ALTER TABLE users
  ADD COLUMN first_name      TEXT,
  ADD COLUMN last_name       TEXT,
  ADD COLUMN function_title  TEXT;

COMMIT;
