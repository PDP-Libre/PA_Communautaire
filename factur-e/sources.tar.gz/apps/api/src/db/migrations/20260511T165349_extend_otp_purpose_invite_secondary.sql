-- Migration: extend_otp_purpose_invite_secondary
-- Generated: 20260511T165349 UTC
-- Convention CLAUDE.md §7 :
--   - une migration ne se modifie jamais une fois mergée (corrections par compensation)
--   - pas de DROP TABLE / DROP COLUMN / RENAME sans expand-then-contract
--   - colonnes NOT NULL → valeur par défaut ou backfill dans la même migration
--
-- T-CL-15 sprint-03 — ajoute la valeur `invite_secondary_verify` au CHECK
-- de `otp_codes.purpose` pour permettre les OTP émis par
-- `/auth/accept-invitation/secondary-email/{set,verify}` (funnel invité
-- 5 étapes, brief Design sprint-02 ligne 775).
--
-- Le CHECK constraint d'origine (migration `20260430T120000_create_otp_codes.sql`)
-- est inline donc auto-nommé `otp_codes_purpose_check` par Postgres
-- (convention `<table>_<column>_check`). On le DROP + ADD avec la même
-- structure étendue. Idempotent via `IF EXISTS`.

BEGIN;

ALTER TABLE otp_codes DROP CONSTRAINT IF EXISTS otp_codes_purpose_check;

ALTER TABLE otp_codes ADD CONSTRAINT otp_codes_purpose_check
  CHECK (purpose IN (
    'phase1_mfa_setup',
    'login_mfa',
    'phase1_email_verify',
    'phase1_secondary_verify',
    'invite_secondary_verify'
  ));

COMMIT;
