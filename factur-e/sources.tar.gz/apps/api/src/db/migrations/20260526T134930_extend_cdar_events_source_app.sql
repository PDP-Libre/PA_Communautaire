-- Migration: extend_cdar_events_source_app
-- Generated: 20260526T134930 UTC
-- Convention CLAUDE.md §7 :
--   - une migration ne se modifie jamais une fois mergée (corrections par compensation)
--   - pas de DROP TABLE / DROP COLUMN / RENAME sans expand-then-contract
--   - colonnes NOT NULL → valeur par défaut ou backfill dans la même migration

-- T-CL-API-INVOICE-MARK-PAID sprint-06 — étend le CHECK `cdar_events_source_check`
-- pour autoriser la source 'app' (CDAR posé par l'utilisateur via l'app, ici la
-- pose 212 Encaissée côté Émission). Aligne la sémantique sur `incoming_cdar_events`
-- (Réception) qui autorise déjà 'app' depuis sprint-05. Source reste `text` libre
-- côté schéma (ADR-009) ; le CHECK est une ceinture/bretelles contre les drifts.

BEGIN;

ALTER TABLE cdar_events DROP CONSTRAINT cdar_events_source_check;

ALTER TABLE cdar_events
  ADD CONSTRAINT cdar_events_source_check
  CHECK (source IN ('webhook', 'polling', 'synthetic', 'app'));

COMMIT;
