-- Migration: create_invitations
-- Generated: 20260430T100030 UTC
--
-- Invitations utilisateur ("donner l'accès à une autre personne", brief
-- design sprint-02 §5.5). TTL 7 j, single-use, token bcrypt côté serveur.
--
-- Notes :
-- - `token_hash` : bcrypt cost 12 du token brut envoyé par email. Le
--   token brut n'est jamais persisté côté serveur.
-- - `inviter_id` : Responsable (rôle 'full') qui a émis l'invitation.
--   ON DELETE CASCADE car si le Responsable est supprimé, les
--   invitations en cours n'ont plus de sens.
-- - `accepted_at` : NULL = en attente, NOT NULL = consommée (single-use,
--   l'app refuse une 2e acceptation).
-- - `can_purchase` : flag cumulable au rôle (brief §5.5).

BEGIN;

CREATE TABLE invitations (
  id            UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id   UUID         NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  inviter_id    UUID         NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  email         TEXT         NOT NULL,
  role          TEXT         NOT NULL
                             CHECK (role IN ('deposit_simple', 'deposit_states', 'full')),
  can_purchase  BOOLEAN      NOT NULL DEFAULT FALSE,
  token_hash    TEXT         NOT NULL UNIQUE,
  expires_at    TIMESTAMPTZ  NOT NULL,
  accepted_at   TIMESTAMPTZ,
  created_at    TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE INDEX invitations_customer_id_idx ON invitations (customer_id);
CREATE INDEX invitations_expires_at_idx ON invitations (expires_at)
  WHERE accepted_at IS NULL;

COMMIT;
