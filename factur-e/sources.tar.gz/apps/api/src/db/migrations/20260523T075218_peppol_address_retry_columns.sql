-- T-CL-PA-DIRECTORY-PEPPOL sprint-05 — Colonnes BDD retry pour le job
-- `enrich-customer-peppol-address` (backoff 5/30/60/360/1440 min, 5
-- retries max). Arbitrage Bruno récap pré-code Q2 : colonnes dédiées
-- sur `customers` (au lieu de table générique `pa_polling_state`).
--
-- Cohérent ADR-009 fail-safe degradation : si `searchSiren` échoue à
-- l'onboarding callback (`not_found` / `5xx` / `disabled`), le job
-- background retry l'enrichira en arrière-plan sans bloquer l'UX user.
--
-- Idempotence : `IF NOT EXISTS` sur les ADD COLUMN.

BEGIN;

ALTER TABLE customers
  ADD COLUMN IF NOT EXISTS peppol_address_retry_count INTEGER NOT NULL DEFAULT 0;

ALTER TABLE customers
  ADD COLUMN IF NOT EXISTS peppol_address_next_retry_at TIMESTAMPTZ NULL;

-- Index partiel pour optimiser le SELECT du job cron (rows à retry).
CREATE INDEX IF NOT EXISTS customers_peppol_retry_pending_idx
  ON customers (peppol_address_next_retry_at)
  WHERE deleted_at IS NULL
    AND (directory_address IS NULL OR directory_address NOT LIKE '0225:%');

COMMIT;
