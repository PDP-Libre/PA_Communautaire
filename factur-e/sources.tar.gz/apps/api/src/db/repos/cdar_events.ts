import type postgres from "postgres";

/**
 * `cdar_events` repository — thin SQL layer pour la table créée par
 * `20260516T071234_create_cdar_events.sql` (T-CL-PA-EXT sprint-04).
 *
 * Convention T-CL-01 (cf. `docs/engineering/db-access.md`).
 *
 * cf. ADR-009 D4 — idempotence via UNIQUE `(invoice_id, code, occurred_at)`
 * + `INSERT … ON CONFLICT DO NOTHING`. Le `inserted` retourné par le
 * repo indique si la ligne est nouvelle (true) ou un duplicate ignoré
 * (false) — utile pour le caller qui doit décider d'émettre un audit
 * ou un SSE seulement sur insert effectif.
 *
 * Périmètre :
 *  - INSERT idempotent + lookup invoice par flow_id + updateStatus +
 *    findOpenForPolling — posés par T-CL-PA-EXT (webhook + polling job).
 *  - Fonctions de lecture (find by invoiceId + since cursor) — ajoutées
 *    par T-CL-API-INVOICE pour `GET /api/invoices/:id` + SSE
 *    `useInvoiceEvents`. Adaptées à la table T-CL-PA-EXT (pas de
 *    `received_at` séparé — on cursor sur `created_at`).
 */

// 'app' = CDAR posé par l'utilisateur via l'app (ex. pose 212 Encaissée
// mark-paid, T-CL-API-INVOICE-MARK-PAID sprint-06). CHECK BDD étendu par la
// migration 20260526T134930_extend_cdar_events_source_app.sql.
export type CdarEventSource = "webhook" | "polling" | "synthetic" | "app";

export interface CdarEventInsertInput {
  invoice_id: string;
  code: string;
  occurred_at: string | Date;
  label?: string | null;
  payload?: unknown;
  reason?: string | null;
  source: CdarEventSource;
}

export interface CdarEventInsertResult {
  /** `true` si une nouvelle ligne a été insérée ; `false` si un
   *  duplicate a été ignoré (ON CONFLICT DO NOTHING — ADR-009 D4). */
  inserted: boolean;
  /** ID de la ligne insérée (uniquement si `inserted = true`). */
  id: string | null;
}

/**
 * Insert idempotent — ADR-009 D4. Retourne `inserted = false` si la
 * clé naturelle `(invoice_id, code, occurred_at)` existe déjà.
 */
export async function insertCdarEvent(
  sql: postgres.Sql,
  input: CdarEventInsertInput,
): Promise<CdarEventInsertResult> {
  const payloadJson = sql.json((input.payload ?? {}) as postgres.JSONValue);
  const rows = await sql<{ id: string }[]>`
    INSERT INTO cdar_events (
      invoice_id, code, label, occurred_at, payload, reason, source
    ) VALUES (
      ${input.invoice_id},
      ${input.code},
      ${input.label ?? null},
      ${input.occurred_at instanceof Date ? input.occurred_at : new Date(input.occurred_at)},
      ${payloadJson},
      ${input.reason ?? null},
      ${input.source}
    )
    ON CONFLICT (invoice_id, code, occurred_at) DO NOTHING
    RETURNING id
  `;
  const first = rows[0];
  if (first === undefined) return { inserted: false, id: null };
  return { inserted: true, id: first.id };
}

/**
 * Supprime la (les) ligne(s) placeholder `source='synthetic'` pour la clé
 * `(invoice_id, code)`. Appelé par le job polling quand le vrai event CDAR
 * du même code arrive de SuperPDP (timestamp réel `occurred_at`), afin de
 * dédoublonner le doublon Déposée synthetic/polling — finding C
 * T-CL-W3-A-CYCLE-VIE-FIXS (recette Sc.6/Sc.11.3 sprint-06).
 *
 * Le synthetic est posé immédiatement à l'envoi (`create.ts`, ADR-009 D4
 * fail-safe). La clé naturelle `(invoice_id, code, occurred_at)` ne
 * dédoublonne pas car `occurred_at` diffère (`new Date()` synthetic vs
 * `event.occurredAt` SuperPDP) — d'où ce drop ciblé du placeholder une fois
 * le vrai event persisté. Tant que le polling n'a pas livré l'event, le
 * synthetic reste seul (ADR-009 D4 préservé strict). Idempotent : retourne
 * le nombre de lignes supprimées (0 au re-polling, le synthetic ayant déjà
 * été superseded).
 */
export async function deleteSyntheticCdarEvent(
  sql: postgres.Sql,
  args: { invoiceId: string; code: string },
): Promise<number> {
  const rows = await sql<{ id: string }[]>`
    DELETE FROM cdar_events
    WHERE invoice_id = ${args.invoiceId}
      AND code = ${args.code}
      AND source = 'synthetic'
    RETURNING id
  `;
  return rows.length;
}

/**
 * Look up an active invoice (not soft-deleted) by its PA invoice id.
 * Used by le job polling pour router chaque event CDAR retourné par
 * `driver.pollCdarEvents` vers la bonne facture Factur-E.
 *
 * **Rename T-CL-PA-INVOICE-FIX 2026-05-17** (ADR-010 v2 D7) :
 * `findActiveInvoiceByPaFlowId` → `findActiveInvoiceByPaInvoiceId`. Le
 * `pa_invoice_id` est l'`invoice.id integer` SuperPDP stringifié (V1b :
 * AFNOR `flowId` string).
 *
 * **Scoping tenant T-CL-REGISTRE-AFNORDRIVER sprint-10 (invariant R1)** :
 * `pa_invoice_id` est un id assigné par la PA — unique seulement au sein
 * d'un compte PA, PAS globalement. Sous plusieurs `customers` partageant
 * un même compte SuperPDP, un lookup non scopé retrouverait/écraserait la
 * facture d'un autre tenant (fuite cross-tenant). Le filtre `customer_id`
 * est donc **obligatoire** (cf. invariant scoping tenant, finding R1
 * sprint-07). Le namespace AFNOR (`flowId` `i_<n>`) renforce le besoin :
 * deux familles d'id externes dans la même colonne.
 */
export interface ActiveInvoiceLookupRow {
  id: string;
  customer_id: string;
  pa_invoice_id: string;
  status_current: string;
}

export async function findActiveInvoiceByPaInvoiceId(
  sql: postgres.Sql,
  customerId: string,
  paInvoiceId: string,
): Promise<ActiveInvoiceLookupRow | undefined> {
  const rows = await sql<ActiveInvoiceLookupRow[]>`
    SELECT id, customer_id, pa_invoice_id, status_current
    FROM invoices
    WHERE customer_id = ${customerId}
      AND pa_invoice_id = ${paInvoiceId}
      AND deleted_at IS NULL
    LIMIT 1
  `;
  return rows[0];
}

/**
 * Update `invoices.status_current` to the latest CDAR code received.
 * Idempotent at the SQL level (UPDATE with same value is a noop). The
 * caller decides whether to UPDATE — typically only on insert effectif
 * (cf. `insertCdarEvent.inserted`).
 *
 * Posé par T-CL-PA-EXT — consommé par webhook + job polling 15 min.
 * NB : `invoices.ts` (T-CL-API-INVOICE) expose une signature symétrique
 * `updateInvoiceStatusCurrent(sql, {id, statusCurrent})` côté repo
 * invoices ; les 2 cohabitent pour ne pas casser les callers respectifs.
 */
export async function updateInvoiceStatusCurrent(
  sql: postgres.Sql,
  invoiceId: string,
  statusCurrent: string,
): Promise<void> {
  await sql`
    UPDATE invoices
    SET status_current = ${statusCurrent}
    WHERE id = ${invoiceId}
  `;
}

// `findOpenInvoicesForCdarPolling` / `OpenInvoiceForPollingRow` —
// supprimées T-CL-PA-INVOICE-FIX (arbitrage Bruno Z6). Le job polling ne
// boucle plus per-invoice mais per-customer avec cursor global SuperPDP
// (cf. ADR-010 v2 D4 `GET /v1.beta/invoice_events?starting_after_id=`).
// Le routing event → invoice se fait via `findActiveInvoiceByPaInvoiceId`
// pour chaque event retourné par le batch.

// ─────────────────────────────────────────────────────────────────────
// SELECT — fonctions de lecture ajoutées par T-CL-API-INVOICE
// ─────────────────────────────────────────────────────────────────────

/** Shape complète d'une ligne `cdar_events` retournée par les fonctions
 *  de lecture (consommée par `GET /api/invoices/:id` + SSE +
 *  `toCdarEventResponse`). Cf. migration `20260516T071234_create_cdar_events.sql`. */
export interface CdarEventRow {
  id: string;
  invoice_id: string;
  code: string;
  label: string | null;
  occurred_at: Date;
  payload: Record<string, unknown>;
  reason: string | null;
  source: CdarEventSource;
  created_at: Date;
}

const CDAR_COLS = `
  id, invoice_id, code, label, occurred_at, payload, reason, source, created_at
`;

/** Tous les events d'une invoice ordered ASC par `occurred_at`
 *  (timeline UI §6.11 brief — du plus ancien au plus récent). */
export async function findCdarEventsByInvoiceId(
  sql: postgres.Sql,
  invoiceId: string,
): Promise<CdarEventRow[]> {
  return sql<CdarEventRow[]>`
    SELECT ${sql.unsafe(CDAR_COLS)}
    FROM cdar_events
    WHERE invoice_id = ${invoiceId}
    ORDER BY occurred_at ASC, created_at ASC
  `;
}

/** Dernier event reçu (par `created_at`) — utile pour patcher
 *  `invoices.status_current` ou pour la sondes UI (KPI dashboard). */
export async function findLatestCdarEventByInvoiceId(
  sql: postgres.Sql,
  invoiceId: string,
): Promise<CdarEventRow | undefined> {
  const rows = await sql<CdarEventRow[]>`
    SELECT ${sql.unsafe(CDAR_COLS)}
    FROM cdar_events
    WHERE invoice_id = ${invoiceId}
    ORDER BY created_at DESC
    LIMIT 1
  `;
  return rows[0];
}

/** Events depuis un curseur — SSE polling 3s côté serveur
 *  (endpoint `GET /api/invoices/:id/events`). Retourne l'incrément
 *  depuis le dernier `created_at` vu par la connexion SSE.
 *
 *  Si `sinceCreatedAt === null` → renvoie le backlog complet ordered
 *  ASC par `occurred_at` (premier envoi à l'ouverture du stream).
 *  Sinon → strictement plus récents par `created_at` ordered ASC par
 *  `created_at` (delta depuis le dernier tick). */
export async function findCdarEventsByInvoiceIdSince(
  sql: postgres.Sql,
  args: { invoiceId: string; sinceCreatedAt: Date | null },
): Promise<CdarEventRow[]> {
  if (args.sinceCreatedAt === null) {
    return findCdarEventsByInvoiceId(sql, args.invoiceId);
  }
  return sql<CdarEventRow[]>`
    SELECT ${sql.unsafe(CDAR_COLS)}
    FROM cdar_events
    WHERE invoice_id = ${args.invoiceId}
      AND created_at > ${args.sinceCreatedAt}
    ORDER BY created_at ASC
  `;
}
