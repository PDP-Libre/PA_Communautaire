import type postgres from "postgres";

/**
 * `invoices` repository — sprint-04 T-CL-API-INVOICE.
 * Cf. migration `20260516T064718_create_invoices.sql`.
 *
 * Convention T-CL-01 :
 *  - SELECTs filtrent `deleted_at IS NULL` systématiquement (soft-delete).
 *  - `customerId` exigé dans tous les SELECTs/UPDATEs/DELETEs (anti-leak
 *    inter-tenant — `findInvoiceByIdAndCustomer` retourne 404 plutôt que
 *    403 pour ne pas révéler l'existence d'une invoice cross-tenant).
 *
 * Pattern UPDATE pour `submitted_at`/`pa_invoice_id`/`status_current` :
 *  l'INSERT initial pose les colonnes obligatoires (totaux, type, etc.)
 *  PUIS `updateInvoicePaSubmission(tx, ...)` patche le bloc PA dans la
 *  même transaction `withTransaction` (cohérent ADR-009 D1 — si fail,
 *  ROLLBACK complet).
 *
 * **Rename T-CL-PA-INVOICE-FIX 2026-05-17** (ADR-010 v2 D7) : la colonne
 *  historique `pa_flow_id` (posée T-CL-API-INVOICE en supposant que les
 *  paths SuperPDP `/v1.beta/flows*` existaient) est renommée
 *  `pa_invoice_id` car l'API réelle expose `POST /v1.beta/invoices` avec
 *  un `invoice.id` integer SuperPDP — cf. migration
 *  `20260517T085553_rename_pa_flow_id_to_pa_invoice_id.sql`.
 */

export interface InvoiceRow {
  id: string;
  customer_id: string;
  number: string;
  issue_date: Date;
  tracking_id: string;
  /** Précision 2 décimales BT-106..115 (totaux EN 16931). String pour
   *  préserver la précision (postgres.js retourne `numeric` en string). */
  total_ht: string;
  total_vat: string;
  total_ttc: string;
  currency: string;
  processing_rule: "B2B" | "B2BInt";
  type_code: string;
  /** BG-3 (BR-55) — UUID de la facture d'origine pour un avoir (381) /
   *  rectificative (384). NULL pour une facture standard. */
  preceding_invoice_id: string | null;
  pa_invoice_id: string | null;
  pa_provider: string;
  sha256: string | null;
  submitted_at: Date | null;
  status_current: string | null;
  /** F8 — horodatage de la copie immuable du PDF transmis sur le stockage
   *  objet (fenêtre de conservation 180 j). NULL = brouillon/preview ou
   *  facture legacy envoyée avant le fix → fallback reconstruction. */
  pdf_archived_at: Date | null;
  payload_extended: Record<string, unknown>;
  deleted_at: Date | null;
  created_at: Date;
  updated_at: Date;
}

const INVOICE_COLS = `
  id, customer_id, number, issue_date, tracking_id,
  total_ht, total_vat, total_ttc, currency,
  processing_rule, type_code, preceding_invoice_id,
  pa_invoice_id, pa_provider, sha256, submitted_at, status_current,
  pdf_archived_at, payload_extended, deleted_at, created_at, updated_at
`;

// ─────────────────────────────────────────────────────────────────────
// SELECT
// ─────────────────────────────────────────────────────────────────────

/** Lookup par id global — pas filtré customer. Réservé à l'admin /
 *  jobs background (poll-cdar-events T-CL-PA-EXT). Pour les routes
 *  user, utiliser `findInvoiceByIdAndCustomer`. */
export async function findActiveInvoiceById(
  sql: postgres.Sql,
  id: string,
): Promise<InvoiceRow | undefined> {
  const rows = await sql<InvoiceRow[]>`
    SELECT ${sql.unsafe(INVOICE_COLS)}
    FROM invoices
    WHERE id = ${id} AND deleted_at IS NULL
  `;
  return rows[0];
}

/** Lookup par id + customer — inter-tenant safe. Retourne `undefined`
 *  si pas du customer (route fait 404 pour ne pas leak l'existence). */
export async function findInvoiceByIdAndCustomer(
  sql: postgres.Sql,
  args: { id: string; customerId: string },
): Promise<InvoiceRow | undefined> {
  const rows = await sql<InvoiceRow[]>`
    SELECT ${sql.unsafe(INVOICE_COLS)}
    FROM invoices
    WHERE id = ${args.id}
      AND customer_id = ${args.customerId}
      AND deleted_at IS NULL
  `;
  return rows[0];
}

export interface ListInvoicesByCustomerArgs {
  /** Match exact sur `status_current` (ex `Déposée`, `205 Approuvée`...). */
  status?: string;
  /** Filtre type document BT-3 (CSV `381,384` → `ANY(text[])`). Pills L11
   *  "Avoirs" (381) / "Rectificatives" (384). */
  typeCode?: string;
  /** SIREN client — match sur `payload_extended->>buyer.siren`
   *  (mode avancé) ou suffit pour MVP via search. */
  client?: string;
  /** Date émission ≥ (ISO YYYY-MM-DD). */
  dateFrom?: string;
  /** Date émission ≤ (ISO YYYY-MM-DD). */
  dateTo?: string;
  /** Total TTC ≥ (number — caster côté caller depuis query string). */
  minAmount?: number;
  /** Total TTC ≤. */
  maxAmount?: number;
  /** Recherche ILIKE sur `number` (mono pattern UI §6.2 toolbar). */
  search?: string;
  /**
   * Filtre rétention (sprint-07 T-CL-W3-C finding S). `"expiring"` =
   * `exported_at IS NULL` et `created_at + 6 mois <= NOW() + 30 jours` (même
   * ancre purge que `GET /api/dashboard/retention-alerts`). Lien
   * `ExportRappelBanner` "Voir les factures pour lancer l'export".
   */
  retention?: "expiring";
  /** Default 50, max 200. */
  limit?: number;
  /** Default 0. */
  offset?: number;
}

/** Liste filtrée + paginée des factures du customer. Ordering :
 *  `issue_date DESC, created_at DESC` (le plus récent d'abord, brief §6.2). */
export async function findActiveInvoicesByCustomerId(
  sql: postgres.Sql,
  customerId: string,
  args: ListInvoicesByCustomerArgs = {},
): Promise<InvoiceRow[]> {
  const limit = args.limit ?? 50;
  const offset = args.offset ?? 0;
  return sql<InvoiceRow[]>`
    SELECT ${sql.unsafe(INVOICE_COLS)}
    FROM invoices
    WHERE customer_id = ${customerId}
      AND deleted_at IS NULL
      ${
        args.status !== undefined
          ? sql`AND status_current = ANY(${args.status.split(",")}::text[])`
          : sql``
      }
      ${
        args.typeCode !== undefined && args.typeCode !== ""
          ? sql`AND type_code = ANY(${args.typeCode.split(",")}::text[])`
          : sql``
      }
      ${args.dateFrom !== undefined ? sql`AND issue_date >= ${args.dateFrom}` : sql``}
      ${args.dateTo !== undefined ? sql`AND issue_date <= ${args.dateTo}` : sql``}
      ${args.minAmount !== undefined ? sql`AND total_ttc >= ${args.minAmount}` : sql``}
      ${args.maxAmount !== undefined ? sql`AND total_ttc <= ${args.maxAmount}` : sql``}
      ${
        args.search !== undefined && args.search !== ""
          ? sql`AND number ILIKE ${"%" + args.search + "%"}`
          : sql``
      }
      ${
        args.client !== undefined && args.client !== ""
          ? sql`AND payload_extended->'parties'->'buyer'->>'siren' = ${args.client}`
          : sql``
      }
      ${
        args.retention === "expiring"
          ? sql`AND exported_at IS NULL
                AND (created_at + INTERVAL '6 months') <= NOW() + INTERVAL '30 days'`
          : sql``
      }
    ORDER BY issue_date DESC, created_at DESC
    LIMIT ${limit} OFFSET ${offset}
  `;
}

/** Count miroir de `findActiveInvoicesByCustomerId` pour pagination
 *  (renvoie le `total` à côté des `items` paginated). Filtres
 *  identiques. */
export async function countActiveInvoicesByCustomerId(
  sql: postgres.Sql,
  customerId: string,
  args: ListInvoicesByCustomerArgs = {},
): Promise<number> {
  const rows = await sql<{ count: string }[]>`
    SELECT COUNT(*)::text AS count
    FROM invoices
    WHERE customer_id = ${customerId}
      AND deleted_at IS NULL
      ${
        args.status !== undefined
          ? sql`AND status_current = ANY(${args.status.split(",")}::text[])`
          : sql``
      }
      ${
        args.typeCode !== undefined && args.typeCode !== ""
          ? sql`AND type_code = ANY(${args.typeCode.split(",")}::text[])`
          : sql``
      }
      ${args.dateFrom !== undefined ? sql`AND issue_date >= ${args.dateFrom}` : sql``}
      ${args.dateTo !== undefined ? sql`AND issue_date <= ${args.dateTo}` : sql``}
      ${args.minAmount !== undefined ? sql`AND total_ttc >= ${args.minAmount}` : sql``}
      ${args.maxAmount !== undefined ? sql`AND total_ttc <= ${args.maxAmount}` : sql``}
      ${
        args.search !== undefined && args.search !== ""
          ? sql`AND number ILIKE ${"%" + args.search + "%"}`
          : sql``
      }
      ${
        args.client !== undefined && args.client !== ""
          ? sql`AND payload_extended->'parties'->'buyer'->>'siren' = ${args.client}`
          : sql``
      }
      ${
        args.retention === "expiring"
          ? sql`AND exported_at IS NULL
                AND (created_at + INTERVAL '6 months') <= NOW() + INTERVAL '30 days'`
          : sql``
      }
  `;
  return Number(rows[0]?.count ?? "0");
}

/** Compte total des invoices actives du customer (sans filtre) — utilisé
 *  par UI pour décider d'afficher la modal "Comment commencer ?" (≥ 2
 *  invoices acté T-CW-09 §10.1 #1). */
export async function countActiveInvoicesByCustomer(
  sql: postgres.Sql,
  customerId: string,
): Promise<number> {
  const rows = await sql<{ count: string }[]>`
    SELECT COUNT(*)::text AS count
    FROM invoices
    WHERE customer_id = ${customerId} AND deleted_at IS NULL
  `;
  return Number(rows[0]?.count ?? "0");
}

/** Détection du dernier numéro émis pour suggestion auto-incrémentée
 *  via POST /api/invoices/check-number-unique (Q6 acté Bruno : algo
 *  côté backend, regex `^(.+?)(\d+)$` + increment zfill conservé). */
export async function findLatestInvoiceNumberByCustomer(
  sql: postgres.Sql,
  customerId: string,
): Promise<string | undefined> {
  const rows = await sql<{ number: string }[]>`
    SELECT number
    FROM invoices
    WHERE customer_id = ${customerId} AND deleted_at IS NULL
    ORDER BY issue_date DESC, created_at DESC
    LIMIT 1
  `;
  return rows[0]?.number;
}

/** Dernier numéro émis commençant par un préfixe donné — séquençage local
 *  des avoirs (`AV-`) / rectificatives (`R-`) L11, distinct de la séquence
 *  facture standard (`F-`). Alimente la suggestion auto-incrémentée du
 *  brouillon credit-note (Z11). */
export async function findLatestInvoiceNumberByCustomerAndPrefix(
  sql: postgres.Sql,
  args: { customerId: string; prefix: string },
): Promise<string | undefined> {
  const rows = await sql<{ number: string }[]>`
    SELECT number
    FROM invoices
    WHERE customer_id = ${args.customerId}
      AND deleted_at IS NULL
      AND number LIKE ${args.prefix + "%"}
    ORDER BY issue_date DESC, created_at DESC
    LIMIT 1
  `;
  return rows[0]?.number;
}

/** Détection de collision sur un numéro précis (US-EMIT-002 validation
 *  unicité à la perte de focus). */
export async function findInvoiceIdByCustomerAndNumber(
  sql: postgres.Sql,
  args: { customerId: string; number: string },
): Promise<string | undefined> {
  const rows = await sql<{ id: string }[]>`
    SELECT id
    FROM invoices
    WHERE customer_id = ${args.customerId}
      AND number = ${args.number}
      AND deleted_at IS NULL
    LIMIT 1
  `;
  return rows[0]?.id;
}

// ─────────────────────────────────────────────────────────────────────
// SELECT — liens BG-3 (L11 avoirs/rectificatives)
// ─────────────────────────────────────────────────────────────────────

/** Résumé compact d'une facture liée (origine ou enfant) — projection pour
 *  `LinkedInvoiceBanner` (GET /api/invoices/:id) et l'icône "Lien" liste. */
export interface LinkedInvoiceSummaryRow {
  id: string;
  number: string;
  issue_date: Date;
  type_code: string;
  status_current: string | null;
}

const LINKED_SUMMARY_COLS = `id, number, issue_date, type_code, status_current`;

/** Documents enfants (avoirs/rectificatives) pointant cette facture d'origine
 *  via `preceding_invoice_id`. Inter-tenant safe. Le plus récent d'abord. */
export async function findLinkedChildrenByPrecedingId(
  sql: postgres.Sql,
  args: { originId: string; customerId: string },
): Promise<LinkedInvoiceSummaryRow[]> {
  return sql<LinkedInvoiceSummaryRow[]>`
    SELECT ${sql.unsafe(LINKED_SUMMARY_COLS)}
    FROM invoices
    WHERE preceding_invoice_id = ${args.originId}
      AND customer_id = ${args.customerId}
      AND deleted_at IS NULL
    ORDER BY issue_date DESC, created_at DESC
  `;
}

/** Résolution batch `id → number` pour enrichir les lignes liste avec le
 *  numéro de la facture d'origine sans N+1. Vide si `ids` vide. */
export async function findInvoiceNumbersByIds(
  sql: postgres.Sql,
  args: { customerId: string; ids: readonly string[] },
): Promise<{ id: string; number: string }[]> {
  if (args.ids.length === 0) return [];
  return sql<{ id: string; number: string }[]>`
    SELECT id, number
    FROM invoices
    WHERE id = ANY(${args.ids as string[]}::uuid[])
      AND customer_id = ${args.customerId}
      AND deleted_at IS NULL
  `;
}

/** Comptage batch des enfants par `preceding_invoice_id` pour l'icône "Lien"
 *  côté facture d'origine (liste). Vide si `originIds` vide. */
export async function countChildrenByPrecedingIds(
  sql: postgres.Sql,
  args: { customerId: string; originIds: readonly string[] },
): Promise<{ preceding_invoice_id: string; count: number }[]> {
  if (args.originIds.length === 0) return [];
  const rows = await sql<{ preceding_invoice_id: string; count: string }[]>`
    SELECT preceding_invoice_id, COUNT(*)::text AS count
    FROM invoices
    WHERE preceding_invoice_id = ANY(${args.originIds as string[]}::uuid[])
      AND customer_id = ${args.customerId}
      AND deleted_at IS NULL
    GROUP BY preceding_invoice_id
  `;
  return rows.map((r) => ({
    preceding_invoice_id: r.preceding_invoice_id,
    count: Number(r.count),
  }));
}

// ─────────────────────────────────────────────────────────────────────
// INSERT
// ─────────────────────────────────────────────────────────────────────

export interface CreateInvoiceArgs {
  customerId: string;
  number: string;
  /** ISO YYYY-MM-DD. */
  issueDate: string;
  trackingId: string;
  /** Totaux pré-calculés depuis les lignes (re-vérifiés côté
   *  formToModel / monetary-summation factur-x-model). */
  totalHt: string;
  totalVat: string;
  totalTtc: string;
  currency?: string;
  processingRule?: "B2B" | "B2BInt";
  typeCode?: string;
  /** BG-3 (BR-55) — UUID de la facture d'origine (avoir 381 / rectificative
   *  384). NULL/absent pour une facture standard. */
  precedingInvoiceId?: string | null;
  /** Pour le mode UI avancé : 39 champs additionnels (BT-13/14, BG-13
   *  shipping, BG-20 doc-level allowance, VATEX, 4 zones commentaires,
   *  ICS, acompte, pénalités custom...). */
  payloadExtended?: Record<string, unknown>;
}

export async function insertInvoice(
  sql: postgres.Sql,
  args: CreateInvoiceArgs,
): Promise<InvoiceRow> {
  const rows = await sql<InvoiceRow[]>`
    INSERT INTO invoices (
      customer_id, number, issue_date, tracking_id,
      total_ht, total_vat, total_ttc, currency,
      processing_rule, type_code, preceding_invoice_id, payload_extended
    )
    VALUES (
      ${args.customerId},
      ${args.number},
      ${args.issueDate},
      ${args.trackingId},
      ${args.totalHt},
      ${args.totalVat},
      ${args.totalTtc},
      ${args.currency ?? "EUR"},
      ${args.processingRule ?? "B2B"},
      ${args.typeCode ?? "380"},
      ${args.precedingInvoiceId ?? null},
      ${sql.json((args.payloadExtended ?? {}) as postgres.JSONValue)}
    )
    RETURNING ${sql.unsafe(INVOICE_COLS)}
  `;
  const row = rows[0];
  if (row === undefined) throw new Error("[invoices] insert returned no row");
  return row;
}

// ─────────────────────────────────────────────────────────────────────
// UPDATE
// ─────────────────────────────────────────────────────────────────────

/** Bloc PA + cryptographique — patché après `paAdapter.submitInvoice` OK.
 *  Tx atomique : ROLLBACK si la submission fail (cf. ADR-009 D1).
 *
 *  `paInvoiceId` (renommé T-CL-PA-INVOICE-FIX depuis `paFlowId`) =
 *  SuperPDP `invoice.id integer` stringifié (ADR-010 v2 D7). Persisté
 *  dans `invoices.pa_invoice_id TEXT` pour portabilité multi-PA.
 *
 *  `statusCurrent` = valeur `FacturEStatusCode` (ADR-012 D2) normalisée
 *  par le driver — pas le raw status_code natif PA (qui vit dans
 *  `cdar_events.code`). */
export async function updateInvoicePaSubmission(
  sql: postgres.Sql,
  args: {
    id: string;
    paInvoiceId: string;
    sha256: string;
    statusCurrent: string;
  },
): Promise<number> {
  const result = await sql`
    UPDATE invoices
    SET pa_invoice_id = ${args.paInvoiceId},
        sha256 = ${args.sha256},
        status_current = ${args.statusCurrent},
        submitted_at = NOW(),
        updated_at = NOW()
    WHERE id = ${args.id} AND deleted_at IS NULL
  `;
  return result.count;
}

/** Patch de `status_current` après webhook/polling CDAR (T-CL-PA-EXT). */
export async function updateInvoiceStatusCurrent(
  sql: postgres.Sql,
  args: { id: string; statusCurrent: string },
): Promise<number> {
  const result = await sql`
    UPDATE invoices
    SET status_current = ${args.statusCurrent},
        updated_at = NOW()
    WHERE id = ${args.id} AND deleted_at IS NULL
  `;
  return result.count;
}

/** F8 — marque la copie immuable du PDF transmis comme réussie
 *  (`pdf_archived_at = NOW()`). Scopé `customer_id` (anti-leak inter-tenant).
 *  Appelé post-commit après l'upload sur le stockage objet ; un échec
 *  d'upload laisse `pdf_archived_at` NULL → `GET /pdf` retombe sur la
 *  reconstruction (fail-safe ADR-009). */
export async function updateInvoicePdfArchived(
  sql: postgres.Sql,
  args: { id: string; customerId: string },
): Promise<number> {
  const result = await sql`
    UPDATE invoices
    SET pdf_archived_at = NOW(),
        updated_at = NOW()
    WHERE id = ${args.id}
      AND customer_id = ${args.customerId}
      AND deleted_at IS NULL
  `;
  return result.count;
}

// ─────────────────────────────────────────────────────────────────────
// SOFT-DELETE
// ─────────────────────────────────────────────────────────────────────

/** Soft-delete — `deleted_at = NOW()`. L'invoice disparaît des SELECTs
 *  user. Réservé : admin RGPD ou cas exceptionnel (pas de DELETE
 *  utilisateur d'une invoice émise, qui est légalement à conserver
 *  10 ans). */
export async function softDeleteInvoiceById(
  sql: postgres.Sql,
  args: { id: string; customerId: string },
): Promise<number> {
  const result = await sql`
    UPDATE invoices
    SET deleted_at = NOW(), updated_at = NOW()
    WHERE id = ${args.id}
      AND customer_id = ${args.customerId}
      AND deleted_at IS NULL
  `;
  return result.count;
}

// `findInvoicesPendingCdarPolling` — supprimée T-CL-PA-INVOICE-FIX
// (arbitrage Bruno Z6). Le job polling ne boucle plus per-invoice mais
// per-customer avec un cursor global `pa_polling_state` (ADR-010 v2 D4
// cursor Stripe-like). La liste des customers à poller est extraite via
// `pa_connections` repo (provider='superpdp', actifs). Les events PA
// retournés portent leur propre `paInvoiceId` → join `invoices.pa_invoice_id`
// pour router vers la bonne facture Factur-E.
