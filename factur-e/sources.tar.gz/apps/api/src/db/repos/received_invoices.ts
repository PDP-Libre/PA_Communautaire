import type postgres from "postgres";

import type { FacturEStatusCode } from "@factur-e/pa-adapter";

/**
 * `received_invoices` repository — thin SQL layer pour la table créée par
 * `20260525T093000_create_received_invoices.sql` (T-CL-RECV-API sprint-05
 * W2). Convention T-CL-01 (cf. `docs/engineering/db-access.md`).
 *
 * Factures REÇUES via SuperPDP polling `GET /v1.beta/invoices?direction=in`
 * (ADR-010 v2 — pas de `/flows/*`). Colonnes alimentées par le worker
 * `poll-received-invoices.ts` depuis `expand[]=en_invoice`.
 *
 * Idempotence ADR-009 D4 : `insertReceivedInvoice` fait `ON CONFLICT
 * (customer_id, pa_invoice_id_in) WHERE deleted_at IS NULL DO NOTHING` →
 * retourne `null` si le flux est déjà connu *pour ce client* (re-vu au tick
 * suivant). La clé est scopée tenant : `pa_invoice_id_in` (= `invoice.id`
 * SuperPDP) n'est unique qu'au sein d'un compte SuperPDP, deux clients
 * partageant un compte reçoivent chacun leur copie
 * (T-CL-HOTFIX-RECV-UNIQUE-TENANT).
 *
 * RBAC scope : toutes les lectures user-facing (`getReceivedInvoiceById`)
 * filtrent `customer_id` → 404 inter-tenant (pas de leak d'existence).
 */

export interface ReceivedInvoiceRow {
  id: string;
  customer_id: string;
  pa_invoice_id_in: string;
  pa_provider: string;
  seller_siren: string;
  seller_name_cached: string | null;
  supplier_matched: boolean;
  invoice_number_extracted: string | null;
  issue_date: Date | null;
  due_date: Date | null;
  total_ttc_cents: number | null;
  currency: string | null;
  format: string | null;
  status_current: string;
  read_at: Date | null;
  received_at: Date;
  deleted_at: Date | null;
  created_at: Date;
  updated_at: Date;
}

const RECV_COLS = `
  id, customer_id, pa_invoice_id_in, pa_provider, seller_siren,
  seller_name_cached, supplier_matched, invoice_number_extracted,
  issue_date, due_date, total_ttc_cents, currency, format, status_current,
  read_at, received_at, deleted_at, created_at, updated_at
`;

// ─────────────────────────────────────────────────────────────────────
// SELECT
// ─────────────────────────────────────────────────────────────────────

/** Curseur keyset `(received_at, id)` — robuste aux timestamps égaux.
 *  La route encode/décode `${received_at ISO}__${id}`. */
export interface ReceivedInvoiceCursor {
  receivedAt: string;
  id: string;
}

export interface ListReceivedInvoicesArgs {
  /** Filtre exact sur `status_current` (un ou plusieurs séparés `,`). */
  status?: string;
  /** Filtre SIREN fournisseur (US-RECV-002 filtre "fournisseur"). */
  sellerSiren?: string;
  /** Période réception (received_at) ≥ / ≤ (ISO date). */
  dateFrom?: string;
  dateTo?: string;
  /** Curseur keyset — page suivante = strictement avant ce point. */
  cursor?: ReceivedInvoiceCursor;
  /** Default 50, max 100 (clamp côté route). */
  limit?: number;
}

/**
 * Liste filtrable + paginée (keyset) des factures reçues du customer.
 * Ordering `received_at DESC, id DESC` (plus récent d'abord, brief §4.1).
 * Retourne `limit + 1` lignes max pour permettre au caller de calculer
 * `nextCursor` (s'il y a un débordement). Le caller tronque à `limit`.
 */
/** T-CL-SIREN-RECONCILIATION sprint-06 W1 — nombre de factures reçues
 *  actives du customer. Consommé par la règle de blocage du changement de
 *  SIREN (réconciliation interdite si historique de factures émises OU
 *  reçues en base). */
export async function countReceivedInvoicesByCustomer(
  sql: postgres.Sql,
  customerId: string,
): Promise<number> {
  const rows = await sql<{ count: string }[]>`
    SELECT COUNT(*)::text AS count
    FROM received_invoices
    WHERE customer_id = ${customerId} AND deleted_at IS NULL
  `;
  return Number(rows[0]?.count ?? "0");
}

export async function findActiveReceivedInvoicesByCustomerId(
  sql: postgres.Sql,
  customerId: string,
  args: ListReceivedInvoicesArgs = {},
): Promise<ReceivedInvoiceRow[]> {
  const limit = args.limit ?? 50;
  return sql<ReceivedInvoiceRow[]>`
    SELECT ${sql.unsafe(RECV_COLS)}
    FROM received_invoices
    WHERE customer_id = ${customerId}
      AND deleted_at IS NULL
      ${
        args.status !== undefined && args.status !== ""
          ? sql`AND status_current = ANY(${args.status.split(",")}::text[])`
          : sql``
      }
      ${args.sellerSiren !== undefined && args.sellerSiren !== "" ? sql`AND seller_siren = ${args.sellerSiren}` : sql``}
      ${args.dateFrom !== undefined ? sql`AND received_at >= ${args.dateFrom}` : sql``}
      ${args.dateTo !== undefined ? sql`AND received_at <= ${args.dateTo}` : sql``}
      ${
        args.cursor !== undefined
          ? sql`AND (received_at, id) < (${args.cursor.receivedAt}::timestamptz, ${args.cursor.id}::uuid)`
          : sql``
      }
    ORDER BY received_at DESC, id DESC
    LIMIT ${limit + 1}
  `;
}

/** Lookup par id + customer — inter-tenant safe (404 si autre customer). */
export async function getReceivedInvoiceById(
  sql: postgres.Sql,
  id: string,
  customerId: string,
): Promise<ReceivedInvoiceRow | undefined> {
  const rows = await sql<ReceivedInvoiceRow[]>`
    SELECT ${sql.unsafe(RECV_COLS)}
    FROM received_invoices
    WHERE id = ${id}
      AND customer_id = ${customerId}
      AND deleted_at IS NULL
  `;
  return rows[0];
}

/**
 * Matching local origine AVOIR-10 (T-CL-RECV-WEB-211-209 sprint-07). Pour un
 * avoir reçu (BT-3 = 381), retrouve la facture d'origine dans la Réception du
 * customer via la clé naturelle `seller_siren` (BT-29 émetteur) +
 * `invoice_number_extracted` (= `precedingInvoiceNumber` BT-25 de l'avoir).
 * `undefined` si l'origine n'est pas (ou plus) dans la Réception → variant UI
 * dégradé « Avoir lié à la facture {n} (non retrouvée) ». Scope customer (RBAC).
 */
export async function findReceivedInvoiceByPrecedingNumber(
  sql: postgres.Sql,
  customerId: string,
  sellerSiren: string,
  precedingInvoiceNumber: string,
): Promise<ReceivedInvoiceRow | undefined> {
  const rows = await sql<ReceivedInvoiceRow[]>`
    SELECT ${sql.unsafe(RECV_COLS)}
    FROM received_invoices
    WHERE customer_id = ${customerId}
      AND seller_siren = ${sellerSiren}
      AND invoice_number_extracted = ${precedingInvoiceNumber}
      AND deleted_at IS NULL
    ORDER BY received_at DESC
    LIMIT 1
  `;
  return rows[0];
}

/** Lookup par flux PA *scopé client* — utilisé par le worker (sanity,
 *  l'idempotence réelle est portée par `ON CONFLICT` de l'INSERT). Le scope
 *  `customer_id` est obligatoire : la clé `pa_invoice_id_in` n'étant unique
 *  que par tenant (T-CL-HOTFIX-RECV-UNIQUE-TENANT), un lookup global pourrait
 *  retourner la ligne d'un autre client partageant le même compte SuperPDP. */
export async function findReceivedInvoiceByPaInvoiceIdIn(
  sql: postgres.Sql,
  customerId: string,
  paInvoiceIdIn: string,
): Promise<ReceivedInvoiceRow | undefined> {
  const rows = await sql<ReceivedInvoiceRow[]>`
    SELECT ${sql.unsafe(RECV_COLS)}
    FROM received_invoices
    WHERE customer_id = ${customerId}
      AND pa_invoice_id_in = ${paInvoiceIdIn}
      AND deleted_at IS NULL
    LIMIT 1
  `;
  return rows[0];
}

// ─────────────────────────────────────────────────────────────────────
// INSERT (idempotent — ADR-009 D4)
// ─────────────────────────────────────────────────────────────────────

export interface NewReceivedInvoiceRow {
  customer_id: string;
  pa_invoice_id_in: string;
  pa_provider?: string;
  seller_siren: string;
  seller_name_cached?: string | null;
  supplier_matched?: boolean;
  invoice_number_extracted?: string | null;
  issue_date?: string | null;
  due_date?: string | null;
  total_ttc_cents?: number | null;
  currency?: string | null;
  format?: string | null;
  status_current?: FacturEStatusCode;
  received_at?: string | Date | null;
}

/**
 * Insert idempotent — ADR-009 D4. Retourne `null` si la clé naturelle
 * scopée tenant `(customer_id, pa_invoice_id_in)` (lignes vivantes) existe
 * déjà → le worker ne ré-insère pas un flux déjà reçu *par ce client*.
 */
export async function insertReceivedInvoice(
  sql: postgres.Sql,
  row: NewReceivedInvoiceRow,
): Promise<ReceivedInvoiceRow | null> {
  const receivedAt =
    row.received_at === undefined || row.received_at === null
      ? null
      : row.received_at instanceof Date
        ? row.received_at
        : new Date(row.received_at);
  const rows = await sql<ReceivedInvoiceRow[]>`
    INSERT INTO received_invoices (
      customer_id, pa_invoice_id_in, pa_provider, seller_siren,
      seller_name_cached, supplier_matched, invoice_number_extracted,
      issue_date, due_date, total_ttc_cents, currency, format,
      status_current, received_at
    ) VALUES (
      ${row.customer_id},
      ${row.pa_invoice_id_in},
      ${row.pa_provider ?? "superpdp"},
      ${row.seller_siren},
      ${row.seller_name_cached ?? null},
      ${row.supplier_matched ?? false},
      ${row.invoice_number_extracted ?? null},
      ${row.issue_date ?? null},
      ${row.due_date ?? null},
      ${row.total_ttc_cents ?? null},
      ${row.currency ?? "EUR"},
      ${row.format ?? null},
      ${row.status_current ?? "in_process"},
      ${receivedAt ?? sql`NOW()`}
    )
    ON CONFLICT (customer_id, pa_invoice_id_in) WHERE deleted_at IS NULL DO NOTHING
    RETURNING ${sql.unsafe(RECV_COLS)}
  `;
  return rows[0] ?? null;
}

// ─────────────────────────────────────────────────────────────────────
// UPDATE
// ─────────────────────────────────────────────────────────────────────

/** Met à jour `status_current` (pose CDAR 205/210). Idempotent SQL. */
export async function markReceivedInvoiceStatus(
  sql: postgres.Sql,
  id: string,
  newStatus: FacturEStatusCode,
): Promise<void> {
  await sql`
    UPDATE received_invoices
    SET status_current = ${newStatus}, updated_at = NOW()
    WHERE id = ${id} AND deleted_at IS NULL
  `;
}

/** Mark-as-read (badge unread). Scope customer pour RBAC. No-op si déjà lu. */
export async function markReceivedInvoiceAsRead(
  sql: postgres.Sql,
  id: string,
  customerId: string,
): Promise<void> {
  await sql`
    UPDATE received_invoices
    SET read_at = COALESCE(read_at, NOW()), updated_at = NOW()
    WHERE id = ${id} AND customer_id = ${customerId} AND deleted_at IS NULL
  `;
}
