import type postgres from "postgres";

/**
 * `product_categories` repository — thin SQL access layer (T-CL-11
 * sprint-03). Catégories d'articles, isolation multi-tenant via
 * `customer_id`. Cf. migration `20260511T075634_create_product_categories.sql`.
 *
 * Convention T-CL-01. Tous les SELECTs filtrent `deleted_at IS NULL`
 * (hard-delete admin uniquement, jamais exposé en API user).
 *
 * UI dit "Catégories d'articles" mais la table BDD reste
 * `product_categories` pour cohérence EN 16931 (glossaire T-CW-11).
 */

export interface ProductCategoryRow {
  id: string;
  customer_id: string;
  label: string;
  created_at: Date;
  updated_at: Date;
}

// ─────────────────────────────────────────────────────────────────────────
// SELECT
// ─────────────────────────────────────────────────────────────────────────

/** Liste les catégories actives d'un customer, ordre alphabétique. */
export async function listProductCategoriesByCustomer(
  sql: postgres.Sql,
  customerId: string,
): Promise<ProductCategoryRow[]> {
  return sql<ProductCategoryRow[]>`
    SELECT id, customer_id, label, created_at, updated_at
    FROM product_categories
    WHERE customer_id = ${customerId}
      AND deleted_at IS NULL
    ORDER BY label ASC
  `;
}

/** Lookup une catégorie par id, filtré par customer pour empêcher la
 *  fuite d'IDs inter-tenant. Retourne `undefined` si absente / hard-delete. */
export async function findProductCategoryById(
  sql: postgres.Sql,
  args: { id: string; customerId: string },
): Promise<ProductCategoryRow | undefined> {
  const rows = await sql<ProductCategoryRow[]>`
    SELECT id, customer_id, label, created_at, updated_at
    FROM product_categories
    WHERE id = ${args.id}
      AND customer_id = ${args.customerId}
      AND deleted_at IS NULL
  `;
  return rows[0];
}

// ─────────────────────────────────────────────────────────────────────────
// INSERT / UPDATE
// ─────────────────────────────────────────────────────────────────────────

export interface CreateProductCategoryArgs {
  customerId: string;
  label: string;
}

export async function createProductCategory(
  sql: postgres.Sql,
  args: CreateProductCategoryArgs,
): Promise<ProductCategoryRow> {
  const rows = await sql<ProductCategoryRow[]>`
    INSERT INTO product_categories (customer_id, label)
    VALUES (${args.customerId}, ${args.label})
    RETURNING id, customer_id, label, created_at, updated_at
  `;
  const row = rows[0];
  if (row === undefined) throw new Error("[product_categories] insert returned no row");
  return row;
}

export interface UpdateProductCategoryArgs {
  id: string;
  customerId: string;
  label: string;
}

/** Update le label. Returns le nombre de rows touchées (0 si absent
 *  ou hard-deleted). */
export async function updateProductCategory(
  sql: postgres.Sql,
  args: UpdateProductCategoryArgs,
): Promise<number> {
  const result = await sql`
    UPDATE product_categories
    SET label = ${args.label}, updated_at = NOW()
    WHERE id = ${args.id}
      AND customer_id = ${args.customerId}
      AND deleted_at IS NULL
  `;
  return result.count;
}

// ─────────────────────────────────────────────────────────────────────────
// HARD-DELETE (admin uniquement, RGPD)
// ─────────────────────────────────────────────────────────────────────────

/** Soft-deletes the row by stamping `deleted_at`. Hard-delete admin
 *  uniquement (jamais routé en API user). Les products liés voient
 *  leur `category_id` passer à NULL via la FK ON DELETE SET NULL. */
export async function deleteProductCategory(
  sql: postgres.Sql,
  args: { id: string; customerId: string },
): Promise<number> {
  const result = await sql`
    UPDATE product_categories
    SET deleted_at = NOW()
    WHERE id = ${args.id}
      AND customer_id = ${args.customerId}
      AND deleted_at IS NULL
  `;
  return result.count;
}
