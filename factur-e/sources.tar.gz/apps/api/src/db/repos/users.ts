import type postgres from "postgres";

/**
 * `users` repository — thin SQL access layer for the `users` table.
 *
 * Conventions (T-CL-01 sprint-03 + retro sprint-02 §"Repository pattern thin") :
 *  - Every function takes `sql: postgres.Sql` (or a transaction `tx`) as its
 *    first parameter so callers control the connection / transaction scope.
 *  - `findActive*` selects encode the `deleted_at IS NULL` guard so the
 *    soft-delete invariant is impossible to forget at the call site.
 *  - `findById*` makes the lack-of-guard explicit (rare cases : decoy,
 *    invitation collision check on email regardless of state).
 *  - `mark<Action>` performs a targeted UPDATE on a single column or a
 *    cohesive set of columns.
 *  - `insert<Entity>` returns the new id (RETURNING).
 *
 * Centralized `UserRow` covers the *full* superset of columns the application
 * reads. Each `findActive*` returns a typed sub-projection so call sites
 * type-check exhaustively.
 *
 * ─────────────────────────────────────────────────────────────────────
 * Invariant T-CL-15 sprint-03 — détection invité en milieu d'onboarding :
 *
 *   `secondary_email_verified_at IS NULL`  ⇒  user créé par invitation,
 *                                              email de secours non vérifié.
 *
 * Le router SPA combine ce marqueur avec `mfa_reset_required = TRUE` pour
 * envoyer le user vers `/onboarding/invite/secondary-email` (brief Design
 * sprint-02 ligne 775, 5 étapes invité). Le seul code path qui INSERT
 * dans `users` sans set `secondary_email_verified_at` est
 * `insertUserFromInvitation` (T-CL-07 sprint-03). Tout autre INSERT qui
 * ne SET pas ce champ casserait le routeur post-mfa_reset_required.
 *
 * Pour ajouter un nouveau code path qui INSERT users (Stripe webhook,
 * import CSV admin V2, etc.) : SOIT set `secondary_email_verified_at = NOW()`
 * quand l'email est garanti par construction, SOIT documenter
 * explicitement ici le nouveau cas + ajuster le router SPA.
 *
 * Défense en profondeur côté backend : `/auth/mfa/setup-recovery-ack`
 * refuse 409 reason='secondary_email_pending' si ce marqueur est vrai,
 * pour bloquer un bypass SPA via JS console (T-CL-15 §C3).
 * ─────────────────────────────────────────────────────────────────────
 */

export type UserRole = "deposit_simple" | "deposit_states" | "full";
export type MfaMode = "none" | "email" | "totp";

export interface UserRow {
  id: string;
  customer_id: string;
  email: string;
  password_hash: string;
  mfa_secret: Buffer | null;
  mfa_mode: MfaMode;
  mfa_enrolled_at: Date | null;
  mfa_reset_required: boolean;
  recovery_codes_hashed: string[] | null;
  role: UserRole;
  can_purchase: boolean;
  email_verified_at: Date | null;
  secondary_email: string;
  secondary_email_verified_at: Date | null;
  first_name: string | null;
  last_name: string | null;
  function_title: string | null;
  terms_accepted_at: Date;
  last_login_at: Date | null;
  created_at: Date;
  updated_at: Date;
  deleted_at: Date | null;
}

// ─────────────────────────────────────────────────────────────────────────
// SELECT
// ─────────────────────────────────────────────────────────────────────────

export interface UserAuthRow {
  id: string;
  customer_id: string;
  password_hash: string;
  role: UserRole;
  mfa_mode: MfaMode;
  mfa_reset_required: boolean;
}

/** Login lookup — returns undefined for unknown / soft-deleted accounts. */
export async function findActiveUserByEmail(
  sql: postgres.Sql,
  email: string,
): Promise<UserAuthRow | undefined> {
  const rows = await sql<UserAuthRow[]>`
    SELECT id, customer_id, password_hash, role, mfa_mode, mfa_reset_required
    FROM users
    WHERE email = ${email} AND deleted_at IS NULL
  `;
  return rows[0];
}

export interface UserCredentialsRow {
  id: string;
  password_hash: string;
}

/** Password-reset request + signup decoy detection — returns id + hash only. */
export async function findActiveUserCredentialsByEmail(
  sql: postgres.Sql,
  email: string,
): Promise<UserCredentialsRow | undefined> {
  const rows = await sql<UserCredentialsRow[]>`
    SELECT id, password_hash
    FROM users
    WHERE email = ${email} AND deleted_at IS NULL
  `;
  return rows[0];
}

/** Password-reset complete — same shape, lookup by id. */
export async function findActiveUserCredentialsById(
  sql: postgres.Sql,
  id: string,
): Promise<UserCredentialsRow | undefined> {
  const rows = await sql<UserCredentialsRow[]>`
    SELECT id, password_hash
    FROM users
    WHERE id = ${id} AND deleted_at IS NULL
  `;
  return rows[0];
}

export interface UserCustomerRow {
  id: string;
  customer_id: string;
}

/** Refresh-token rotation — returns id + customer_id only. */
export async function findActiveUserCustomerById(
  sql: postgres.Sql,
  id: string,
): Promise<UserCustomerRow | undefined> {
  const rows = await sql<UserCustomerRow[]>`
    SELECT id, customer_id
    FROM users
    WHERE id = ${id} AND deleted_at IS NULL
  `;
  return rows[0];
}

export interface UserMfaStateRow {
  id: string;
  customer_id: string;
  email: string;
  mfa_secret: Buffer | null;
  mfa_mode: MfaMode;
  mfa_reset_required: boolean;
  role: UserRole;
  can_purchase: boolean;
}

/** Used by `/auth/mfa/setup-*` to verify the reset_token target. T-CL-15
 *  sprint-03 a étendu la projection avec `role`, `can_purchase`, `mfa_mode`
 *  pour appliquer la politique TOTP-only (ADR-006 §C3, helper
 *  `mfa-policy.ts:requiresTotp`) + déterminer `is_first_time` (mfa_mode === 'none')
 *  pour le wording SetupMfa "Configurez" vs "Reconfigurez". */
export async function findActiveUserMfaStateById(
  sql: postgres.Sql,
  id: string,
): Promise<UserMfaStateRow | undefined> {
  const rows = await sql<UserMfaStateRow[]>`
    SELECT id, customer_id, email, mfa_secret, mfa_mode, mfa_reset_required,
           role, can_purchase
    FROM users
    WHERE id = ${id} AND deleted_at IS NULL
  `;
  return rows[0];
}

export interface UserMfaVerifyRow {
  mfa_mode: MfaMode;
  mfa_secret: Buffer | null;
  recovery_codes_hashed: string[] | null;
}

/** Used by `/auth/mfa/verify` (login flow second factor). */
export async function findActiveUserMfaForVerifyById(
  sql: postgres.Sql,
  id: string,
): Promise<UserMfaVerifyRow | undefined> {
  const rows = await sql<UserMfaVerifyRow[]>`
    SELECT mfa_mode, mfa_secret, recovery_codes_hashed
    FROM users
    WHERE id = ${id} AND deleted_at IS NULL
  `;
  return rows[0];
}

export interface UserRecoveryCodesRow {
  recovery_codes_hashed: string[] | null;
}

/** Used by `/auth/mfa/reset-via-recovery` (authenticated user bypass). */
export async function findActiveUserRecoveryCodesById(
  sql: postgres.Sql,
  id: string,
): Promise<UserRecoveryCodesRow | undefined> {
  const rows = await sql<UserRecoveryCodesRow[]>`
    SELECT recovery_codes_hashed
    FROM users
    WHERE id = ${id} AND deleted_at IS NULL
  `;
  return rows[0];
}

/** Used by `requireFullRole` — single-column role probe. */
export async function findActiveUserRoleById(
  sql: postgres.Sql,
  id: string,
): Promise<{ role: UserRole } | undefined> {
  const rows = await sql<{ role: UserRole }[]>`
    SELECT role
    FROM users
    WHERE id = ${id} AND deleted_at IS NULL
  `;
  return rows[0];
}

/** Used by the `mfa_reset_required` preHandler guard (T-CL-03 sprint-03) —
 *  fired on every protected request so it stays lean (1 column). */
export async function findActiveUserMfaResetRequiredById(
  sql: postgres.Sql,
  id: string,
): Promise<{ mfa_reset_required: boolean } | undefined> {
  const rows = await sql<{ mfa_reset_required: boolean }[]>`
    SELECT mfa_reset_required
    FROM users
    WHERE id = ${id} AND deleted_at IS NULL
  `;
  return rows[0];
}

export interface AuthMeJoinRow {
  user_id: string;
  email: string;
  role: UserRole;
  can_purchase: boolean;
  email_verified_at: Date | null;
  mfa_mode: MfaMode;
  mfa_reset_required: boolean;
  /** T-CL-15 sprint-03 — précondition routeur invité onboarding. */
  secondary_email_verified_at: Date | null;
  customer_id: string;
  siren: string;
  legal_name: string;
  trading_name: string | null;
  primary_color: string;
  profile_unverified: boolean;
}

/** Composite read for `GET /auth/me` — joins `users` + `customers`. */
export async function findActiveAuthMeJoinByUserId(
  sql: postgres.Sql,
  userId: string,
): Promise<AuthMeJoinRow | undefined> {
  const rows = await sql<AuthMeJoinRow[]>`
    SELECT
      u.id          AS user_id,
      u.email       AS email,
      u.role        AS role,
      u.can_purchase AS can_purchase,
      u.email_verified_at AS email_verified_at,
      u.mfa_mode    AS mfa_mode,
      u.mfa_reset_required AS mfa_reset_required,
      u.secondary_email_verified_at AS secondary_email_verified_at,
      c.id          AS customer_id,
      c.siren       AS siren,
      c.legal_name  AS legal_name,
      c.trading_name AS trading_name,
      c.primary_color AS primary_color,
      c.profile_unverified AS profile_unverified
    FROM users u
    JOIN customers c ON c.id = u.customer_id
    WHERE u.id = ${userId} AND u.deleted_at IS NULL
  `;
  return rows[0];
}

export interface UserListItemRow {
  id: string;
  email: string;
  role: UserRole;
  can_purchase: boolean;
  mfa_mode: MfaMode;
  last_login_at: Date | null;
  created_at: Date;
}

/** GET /users — list active members of a customer (Full only). */
export async function findActiveUsersByCustomerForList(
  sql: postgres.Sql,
  customerId: string,
): Promise<UserListItemRow[]> {
  return sql<UserListItemRow[]>`
    SELECT id, email, role, can_purchase, mfa_mode, last_login_at, created_at
    FROM users
    WHERE customer_id = ${customerId} AND deleted_at IS NULL
    ORDER BY created_at ASC
  `;
}

export interface UserAdminRow {
  id: string;
  customer_id: string;
  role: UserRole;
  can_purchase: boolean;
  deleted_at: Date | null;
}

/** Lookup for admin mutations (PATCH role / can_purchase / DELETE).
 * Note: no `deleted_at IS NULL` guard — the caller checks `deleted_at` to
 * differentiate "unknown id" from "soft-deleted user". Stays consistent
 * with the legacy `loadUserForCustomer` semantics. */
export async function findUserForCustomerAdmin(
  sql: postgres.Sql,
  userId: string,
  customerId: string,
): Promise<UserAdminRow | undefined> {
  const rows = await sql<UserAdminRow[]>`
    SELECT id, customer_id, role, can_purchase, deleted_at
    FROM users
    WHERE id = ${userId} AND customer_id = ${customerId}
  `;
  return rows[0];
}

/** COUNT active Full admins for a customer (last-Full guard). */
export async function countActiveFullsByCustomer(
  sql: postgres.Sql,
  customerId: string,
): Promise<number> {
  const rows = await sql<{ n: string }[]>`
    SELECT COUNT(*)::text AS n
    FROM users
    WHERE customer_id = ${customerId}
      AND role = 'full'
      AND deleted_at IS NULL
  `;
  return Number(rows[0]?.n ?? "0");
}

/** Existence probe regardless of soft-delete state. Used by:
 *  - signup decoy detection  (anti-énumération)
 *  - invitation create / accept (collision check)
 *  - phase1 email-verify-trigger decoy resolution */
export async function findUserIdByEmailAnyState(
  sql: postgres.Sql,
  email: string,
): Promise<{ id: string } | undefined> {
  const rows = await sql<{ id: string }[]>`
    SELECT id FROM users WHERE email = ${email}
  `;
  return rows[0];
}

/** Variant returning id+password_hash regardless of soft-delete (decoy
 *  resolution at signup + phase1 email-verify-trigger). */
export async function findUserCredentialsByEmailAnyState(
  sql: postgres.Sql,
  email: string,
): Promise<UserCredentialsRow | undefined> {
  const rows = await sql<UserCredentialsRow[]>`
    SELECT id, password_hash FROM users WHERE email = ${email}
  `;
  return rows[0];
}

/** Used by invitations.ts to render the invite email body. */
export async function findUserEmailById(
  sql: postgres.Sql,
  id: string,
): Promise<{ email: string } | undefined> {
  const rows = await sql<{ email: string }[]>`
    SELECT email FROM users WHERE id = ${id}
  `;
  return rows[0];
}

// ─────────────────────────────────────────────────────────────────────────
// UPDATE
// ─────────────────────────────────────────────────────────────────────────

export async function markLastLogin(sql: postgres.Sql, id: string): Promise<void> {
  await sql`UPDATE users SET last_login_at = NOW() WHERE id = ${id}`;
}

export async function markPasswordHash(
  sql: postgres.Sql,
  id: string,
  passwordHash: string,
): Promise<void> {
  await sql`UPDATE users SET password_hash = ${passwordHash} WHERE id = ${id}`;
}

export async function markRole(sql: postgres.Sql, id: string, role: UserRole): Promise<void> {
  await sql`UPDATE users SET role = ${role} WHERE id = ${id}`;
}

export async function markCanPurchase(
  sql: postgres.Sql,
  id: string,
  canPurchase: boolean,
): Promise<void> {
  await sql`UPDATE users SET can_purchase = ${canPurchase} WHERE id = ${id}`;
}

export async function markMfaSecret(
  sql: postgres.Sql,
  id: string,
  secret: Buffer | null,
): Promise<void> {
  await sql`UPDATE users SET mfa_secret = ${secret} WHERE id = ${id}`;
}

export async function markMfaResetRequired(
  sql: postgres.Sql,
  id: string,
  value: boolean,
): Promise<void> {
  await sql`UPDATE users SET mfa_reset_required = ${value} WHERE id = ${id}`;
}

/** Atomic clear-and-set after a successful MFA setup post-reset. */
export async function markMfaSetupComplete(
  sql: postgres.Sql,
  id: string,
  args: { mode: "email" | "totp"; recovery_codes_hashed: string[] },
): Promise<void> {
  await sql`
    UPDATE users
    SET mfa_mode = ${args.mode},
        mfa_enrolled_at = NOW(),
        recovery_codes_hashed = ${args.recovery_codes_hashed}
    WHERE id = ${id}
  `;
}

/** Recovery-code consume (login MFA + standalone reset).
 * Replaces the stored array with the remaining hashes, clears the MFA
 * secret, drops `mfa_mode` to `none`, and forces re-setup. Atomic UPDATE. */
export async function consumeRecoveryCode(
  sql: postgres.Sql,
  id: string,
  remainingHashes: string[],
): Promise<void> {
  await sql`
    UPDATE users
    SET recovery_codes_hashed = ${remainingHashes},
        mfa_mode = ${"none"},
        mfa_secret = NULL,
        mfa_reset_required = TRUE
    WHERE id = ${id}
  `;
}

// ─────────────────────────────────────────────────────────────────────
// T-CL-15 sprint-03 — invitation accept secondary-email funnel
// ─────────────────────────────────────────────────────────────────────

export interface UserSecondaryEmailRow {
  id: string;
  customer_id: string;
  /** Email primaire (sert au refine `≠ secondary` côté endpoint). */
  email: string;
  /** Empty string `''` tant que pas saisi ; non-vide post-`set`. */
  secondary_email: string;
  /** NULL ⇒ pas encore vérifié (user invité mid-onboarding). */
  secondary_email_verified_at: Date | null;
}

/** Projection T-CL-15 : utilisée par `/auth/accept-invitation/secondary-email/*`
 *  + défense en profondeur de `/auth/mfa/setup-recovery-ack`. */
export async function findActiveUserSecondaryEmailById(
  sql: postgres.Sql,
  id: string,
): Promise<UserSecondaryEmailRow | undefined> {
  const rows = await sql<UserSecondaryEmailRow[]>`
    SELECT id, customer_id, email, secondary_email, secondary_email_verified_at
    FROM users
    WHERE id = ${id} AND deleted_at IS NULL
  `;
  return rows[0];
}

/** SET secondary_email = candidate (pas encore vérifié — `verified_at`
 *  reste NULL jusqu'au consume de l'OTP via `markSecondaryEmailVerified`). */
export async function markSecondaryEmailCandidate(
  sql: postgres.Sql,
  id: string,
  email: string,
): Promise<void> {
  await sql`
    UPDATE users
    SET secondary_email = ${email}
    WHERE id = ${id}
  `;
}

/** SET secondary_email_verified_at = NOW(). Termine la transition de
 *  l'étape « Email de secours » du funnel invité (brief ligne 775). */
export async function markSecondaryEmailVerified(sql: postgres.Sql, id: string): Promise<void> {
  await sql`
    UPDATE users
    SET secondary_email_verified_at = NOW()
    WHERE id = ${id}
  `;
}

/** PATCH /users/me/profile — first/last name + function title. */
export async function markUserProfile(
  sql: postgres.Sql,
  id: string,
  args: { first_name: string; last_name: string; function_title: string | null },
): Promise<void> {
  await sql`
    UPDATE users
    SET first_name = ${args.first_name},
        last_name = ${args.last_name},
        function_title = ${args.function_title}
    WHERE id = ${id}
  `;
}

/** Soft-delete (DELETE /users/:id). Caller is expected to also drop
 *  related sessions — see `deleteSessionsByUser` in `sessions` repo. */
export async function markUserDeleted(sql: postgres.Sql, id: string): Promise<void> {
  await sql`UPDATE users SET deleted_at = NOW() WHERE id = ${id}`;
}

// ─────────────────────────────────────────────────────────────────────────
// INSERT
// ─────────────────────────────────────────────────────────────────────────

export interface InsertUserFromPhase1 {
  customerId: string;
  email: string;
  passwordHash: string;
  mfaSecret: Buffer | null;
  mfaMode: MfaMode;
  mfaEnrolledAt: Date | null;
  recoveryCodesHashed: string[] | null;
  role: UserRole;
  canPurchase: boolean;
  emailVerifiedAt: Date | null;
  secondaryEmail: string;
  secondaryEmailVerifiedAt: Date | null;
  termsAcceptedAt: Date;
}

/** Used by `finalizePhase1` inside a transaction — full INSERT, returns id. */
export async function insertUserFromPhase1(
  sql: postgres.Sql,
  args: InsertUserFromPhase1,
): Promise<{ id: string }> {
  const rows = await sql<{ id: string }[]>`
    INSERT INTO users (
      customer_id, email, password_hash,
      mfa_secret, mfa_mode, mfa_enrolled_at,
      recovery_codes_hashed,
      role, can_purchase,
      email_verified_at,
      secondary_email, secondary_email_verified_at,
      terms_accepted_at
    ) VALUES (
      ${args.customerId},
      ${args.email},
      ${args.passwordHash},
      ${args.mfaSecret},
      ${args.mfaMode},
      ${args.mfaEnrolledAt},
      ${args.recoveryCodesHashed},
      ${args.role},
      ${args.canPurchase},
      ${args.emailVerifiedAt},
      ${args.secondaryEmail},
      ${args.secondaryEmailVerifiedAt},
      ${args.termsAcceptedAt}
    )
    RETURNING id
  `;
  const r = rows[0];
  if (r === undefined) throw new Error("user insert failed");
  return r;
}

export interface InsertUserFromInvitation {
  id: string;
  customerId: string;
  email: string;
  passwordHash: string;
  role: UserRole;
  canPurchase: boolean;
}

/** Used by invitations.accept inside a transaction. mfa_mode='none' +
 *  mfa_reset_required=TRUE so the next login forces MFA setup
 *  (cf. ADR-006 sprint-03 + brief 5-step invitee flow). */
export async function insertUserFromInvitation(
  sql: postgres.Sql,
  args: InsertUserFromInvitation,
): Promise<void> {
  await sql`
    INSERT INTO users (
      id, customer_id, email, password_hash, role, can_purchase,
      mfa_mode, mfa_reset_required, email_verified_at, terms_accepted_at,
      secondary_email
    ) VALUES (
      ${args.id},
      ${args.customerId},
      ${args.email},
      ${args.passwordHash},
      ${args.role},
      ${args.canPurchase},
      'none',
      TRUE,
      NOW(),
      NOW(),
      ''
    )
  `;
}
