import type postgres from "postgres";

/**
 * `invoice_drafts` repository — sprint-04 T-CL-API-INVOICE.
 * Cf. migration `20260516T064720_create_invoice_drafts.sql`.
 *
 * Brouillons de saisie en cours, alimentés par auto-save 5s côté UI
 * (US-EMIT-008-bis acté T-CW-09 §10.1 #4). Multi-tenant strict.
 *
 * `payload` : JSON permissif (état partiel/cassé du formulaire à n'importe
 * quelle étape Stepper). La validation stricte n'a lieu qu'au moment de
 * l'envoi effectif (POST /api/invoices) avec `InvoiceFormSchema`.
 *
 * Pas de soft-delete : un draft est éphémère. À l'envoi, le draft est
 * supprimé physiquement (DELETE) après création de l'invoice définitive.
 */

export interface InvoiceDraftRow {
  id: string;
  customer_id: string;
  payload: Record<string, unknown>;
  step_completed: Record<string, unknown>;
  last_modified_at: Date;
  created_at: Date;
}

const DRAFT_COLS = `id, customer_id, payload, step_completed, last_modified_at, created_at`;

// ─────────────────────────────────────────────────────────────────────
// SELECT
// ─────────────────────────────────────────────────────────────────────

/** Liste brouillons du customer ordered par fraîcheur (le plus récemment
 *  modifié d'abord). Consommé par filtre pills "Brouillons" liste
 *  Émission §6.2 brief + onglet retrieve.
 *
 *  `limit`/`offset` optionnels — défaut 50/0 (aligné avec
 *  `findActiveInvoicesByCustomerId`). */
export async function findActiveDraftsByCustomerId(
  sql: postgres.Sql,
  customerId: string,
  args: { limit?: number; offset?: number } = {},
): Promise<InvoiceDraftRow[]> {
  return sql<InvoiceDraftRow[]>`
    SELECT ${sql.unsafe(DRAFT_COLS)}
    FROM invoice_drafts
    WHERE customer_id = ${customerId}
    ORDER BY last_modified_at DESC
    LIMIT ${args.limit ?? 50} OFFSET ${args.offset ?? 0}
  `;
}

/** Retrieve d'un draft (inter-tenant safe). 404 côté route si pas du
 *  customer. */
export async function findDraftByIdAndCustomer(
  sql: postgres.Sql,
  args: { id: string; customerId: string },
): Promise<InvoiceDraftRow | undefined> {
  const rows = await sql<InvoiceDraftRow[]>`
    SELECT ${sql.unsafe(DRAFT_COLS)}
    FROM invoice_drafts
    WHERE id = ${args.id} AND customer_id = ${args.customerId}
  `;
  return rows[0];
}

// ─────────────────────────────────────────────────────────────────────
// INSERT / UPDATE / DELETE
// ─────────────────────────────────────────────────────────────────────

export interface CreateDraftArgs {
  customerId: string;
  payload: Record<string, unknown>;
  stepCompleted?: Record<string, unknown>;
}

export async function insertDraft(
  sql: postgres.Sql,
  args: CreateDraftArgs,
): Promise<InvoiceDraftRow> {
  const rows = await sql<InvoiceDraftRow[]>`
    INSERT INTO invoice_drafts (customer_id, payload, step_completed)
    VALUES (
      ${args.customerId},
      ${sql.json(args.payload as postgres.JSONValue)},
      ${sql.json((args.stepCompleted ?? {}) as postgres.JSONValue)}
    )
    RETURNING ${sql.unsafe(DRAFT_COLS)}
  `;
  const row = rows[0];
  if (row === undefined) throw new Error("[invoice_drafts] insert returned no row");
  return row;
}

export interface UpdateDraftArgs {
  id: string;
  customerId: string;
  /** Patch partiel : `undefined` = pas de modif, valeur = overwrite total
   *  du jsonb. (Pas de merge partiel jsonb — le caller route fait le merge
   *  côté applicatif s'il en a besoin, mais pour auto-save l'UI envoie
   *  le payload complet de toute façon.) */
  payload?: Record<string, unknown>;
  stepCompleted?: Record<string, unknown>;
}

/** UPDATE atomique d'un draft + `last_modified_at = NOW()`. Si ni
 *  `payload` ni `stepCompleted` fournis, retourne 0 (no-op). */
export async function updateDraft(sql: postgres.Sql, args: UpdateDraftArgs): Promise<number> {
  if (args.payload === undefined && args.stepCompleted === undefined) return 0;
  const result = await sql`
    UPDATE invoice_drafts
    SET ${
      args.payload !== undefined
        ? sql`payload = ${sql.json(args.payload as postgres.JSONValue)},`
        : sql``
    }
        ${
          args.stepCompleted !== undefined
            ? sql`step_completed = ${sql.json(args.stepCompleted as postgres.JSONValue)},`
            : sql``
        }
        last_modified_at = NOW()
    WHERE id = ${args.id} AND customer_id = ${args.customerId}
  `;
  return result.count;
}

export async function deleteDraftById(
  sql: postgres.Sql,
  args: { id: string; customerId: string },
): Promise<number> {
  const result = await sql`
    DELETE FROM invoice_drafts
    WHERE id = ${args.id} AND customer_id = ${args.customerId}
  `;
  return result.count;
}
