import type postgres from "postgres";

/**
 * `directory_cache` repository — thin SQL access layer for the table
 * created in T-CL-09 sprint-03 (`20260506T193144_create_directory_cache.sql`).
 *
 * Convention T-CL-01. Cache 7 jours des appels annuaire SuperPDP cascade
 * `companies → entries`. Cache aussi les outcomes négatifs (`not_found`,
 * `disabled`) pour limiter le rate-limit. PAS les `unavailable` transients
 * (5xx / timeout) — pattern T-CL-05 sprint-02 INSEE.
 *
 * Le filtre `expires_at > NOW()` est encodé dans `findFresh*` — les rows
 * périmés sont silencieusement ignorés ; la purge disque viendra dans une
 * extension de `cleanup-expired` (T-CL-10+ ou plus tard, pattern T-CL-03).
 *
 * cf. PRD v1.4 §5.5 critère 7 + audit T-CW-08 §3.
 */

/** Adresse Peppol filtrée (is_replyto=false) issue de
 *  `french_directory_entry` SuperPDP. */
export interface CachedDirectoryAddress {
  /** Identifier Peppol complet. Ex `0225:123456789_dgfip`. */
  party_id: string;
  /** SchemeID Peppol — `0225` pour la France. Stocké séparément pour
   *  faciliter le mapping BT-49 (sprint-04+ émission). */
  scheme_id: string;
  /** Vrai si l'entrée est active (`is_active=true` côté SuperPDP). */
  is_active: boolean;
  /** Nom de la PA hôte si fourni (ex "SuperPDP"). UI sélecteur radio. */
  pa_name: string | null;
}

export interface DirectoryCachedRow {
  siren: string;
  /** Raw `french_directory_company` ou null si negative cache. */
  payload: Record<string, unknown> | null;
  addresses: CachedDirectoryAddress[];
  fetched_at: Date;
  expires_at: Date;
}

// ─────────────────────────────────────────────────────────────────────────
// SELECT
// ─────────────────────────────────────────────────────────────────────────

/** Hit cache pour `searchSiren(siren)` — uniquement les rows non expirées
 *  (TTL 7 j cf. migration). Returns `undefined` si miss / périmé. */
export async function findFreshDirectoryCacheBySiren(
  sql: postgres.Sql,
  siren: string,
): Promise<DirectoryCachedRow | undefined> {
  const rows = await sql<DirectoryCachedRow[]>`
    SELECT siren, payload, addresses, fetched_at, expires_at
    FROM directory_cache
    WHERE siren = ${siren} AND expires_at > NOW()
  `;
  return rows[0];
}

// ─────────────────────────────────────────────────────────────────────────
// UPSERT
// ─────────────────────────────────────────────────────────────────────────

export interface UpsertDirectoryCacheArgs {
  siren: string;
  payload: postgres.JSONValue | null;
  addresses: CachedDirectoryAddress[];
  /** Override TTL (default 7 days from migration). Tests pass a tighter
   *  window to verify expiration. */
  ttlSeconds?: number;
}

/** Cache hit pour la recherche annuaire — INSERT ou UPDATE selon présence
 *  préalable. ON CONFLICT renvoie sur `(siren)` PK. `expires_at` re-stamp
 *  à chaque écriture (pas une preservation du cache antérieur). */
export async function upsertDirectoryCache(
  sql: postgres.Sql,
  args: UpsertDirectoryCacheArgs,
): Promise<void> {
  const ttl = args.ttlSeconds ?? 7 * 24 * 3600;
  await sql`
    INSERT INTO directory_cache (siren, payload, addresses, fetched_at, expires_at)
    VALUES (
      ${args.siren},
      ${args.payload === null ? null : sql.json(args.payload)},
      ${sql.json(args.addresses as unknown as postgres.JSONValue)},
      NOW(),
      NOW() + INTERVAL '1 second' * ${ttl}
    )
    ON CONFLICT (siren) DO UPDATE SET
      payload    = EXCLUDED.payload,
      addresses  = EXCLUDED.addresses,
      fetched_at = EXCLUDED.fetched_at,
      expires_at = EXCLUDED.expires_at
  `;
}

// ─────────────────────────────────────────────────────────────────────────
// PURGE (cleanup-expired job — T-CL-10 sprint-03)
// ─────────────────────────────────────────────────────────────────────────

/** Hard-delete des rows périmées. Appelé par `cleanupExpired` (cron horaire,
 *  cf. `apps/api/src/jobs/cleanup-expired.ts`). TTL 15 min en T-CL-10
 *  → accumulation rapide, purge nécessaire. Returns nombre de lignes
 *  supprimées pour le log de fin de tick. */
export async function deleteExpiredDirectoryCache(sql: postgres.Sql): Promise<number> {
  const r = await sql`DELETE FROM directory_cache WHERE expires_at < NOW()`;
  return r.count;
}
