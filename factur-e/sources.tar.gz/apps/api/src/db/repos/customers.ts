import type postgres from "postgres";

/**
 * `customers` repository — thin SQL access layer for the `customers` table.
 *
 * Conventions: cf. `users.ts` header. customers is a write-mostly profile
 * surface — most call sites are PATCH /customers/me/* operations, plus
 * an INSERT inside the phase-1 finalization transaction.
 */

export type VatRegime = "real" | "franchise_293b" | "reverse_charge_eu" | "simplified";
export type UiModeDefault = "basic" | "advanced";

export interface CustomerRow {
  id: string;
  siren: string;
  legal_name: string;
  trading_name: string | null;
  address: Record<string, unknown>;
  naf_code: string | null;
  rcs: string | null;
  juridique_code: string | null;
  capital_social: string | null;
  vat_number: string | null;
  vat_regime: VatRegime;
  vat_on_encashment: boolean;
  iban: string | null;
  bic: string | null;
  logo_s3_key: string | null;
  primary_color: string;
  legal_mentions: string | null;
  directory_address: string | null;
  /** T-CL-PA-DIRECTORY-PEPPOL sprint-05 — compteur retry job
   *  `enrich-customer-peppol-address` (backoff 5/30/60/360/1440 min).
   *  Reset à 0 par `updateCustomerDirectoryAddress` post-success. */
  peppol_address_retry_count: number;
  /** T-CL-PA-DIRECTORY-PEPPOL sprint-05 — prochaine fenêtre retry. NULL
   *  = pas de retry programmé (état initial OU success). */
  peppol_address_next_retry_at: Date | null;
  default_invoice_values: Record<string, unknown>;
  ui_mode_default: UiModeDefault;
  profile_unverified: boolean;
  /** T-CL-SIREN-RECONCILIATION sprint-06 W1 — flags champ-spécifiques
   *  (Mécanisme 1, ADR-007ter D1 candidat). Généralisent le badge global
   *  `profile_unverified` par attribut réconciliable. Default TRUE à
   *  l'onboarding INSEE, cleared à `verified` (callback + polling) et
   *  pour `siren` par la réconciliation silencieuse (Mécanisme 3). V1 :
   *  seul `siren_unverified` est cleared indépendamment ; les 3 autres
   *  basculent avec le profil global (Z6). */
  siren_unverified: boolean;
  legal_name_unverified: boolean;
  address_unverified: boolean;
  vat_number_unverified: boolean;
  created_at: Date;
  updated_at: Date;
  deleted_at: Date | null;
}

// ─────────────────────────────────────────────────────────────────────────
// SELECT
// ─────────────────────────────────────────────────────────────────────────

/** Read-only — used to gate `capital_social` validation by juridique. */
export async function findCustomerJuridiqueCodeById(
  sql: postgres.Sql,
  id: string,
): Promise<{ juridique_code: string | null } | undefined> {
  const rows = await sql<{ juridique_code: string | null }[]>`
    SELECT juridique_code FROM customers WHERE id = ${id}
  `;
  return rows[0];
}

/** capital_social is numeric(15,2) — cast to text to keep precision client-side. */
export async function findCustomerCapitalSocialById(
  sql: postgres.Sql,
  id: string,
): Promise<{ capital_social: string | null } | undefined> {
  const rows = await sql<{ capital_social: string | null }[]>`
    SELECT capital_social::text AS capital_social FROM customers WHERE id = ${id}
  `;
  return rows[0];
}

/** Used by /customers/me/logo to detect the previous key for replacement. */
export async function findCustomerLogoKeyById(
  sql: postgres.Sql,
  id: string,
): Promise<{ logo_s3_key: string | null } | undefined> {
  const rows = await sql<{ logo_s3_key: string | null }[]>`
    SELECT logo_s3_key FROM customers WHERE id = ${id}
  `;
  return rows[0];
}

/** Used by invitations to render the invite email body. */
export async function findCustomerLegalNameById(
  sql: postgres.Sql,
  id: string,
): Promise<{ legal_name: string } | undefined> {
  const rows = await sql<{ legal_name: string }[]>`
    SELECT legal_name FROM customers WHERE id = ${id}
  `;
  return rows[0];
}

/** Charge le row complet du customer — utilisé par le pipeline
 *  d'émission sprint-04 T-CL-API-INVOICE pour fournir le seller context
 *  à `formToModel` (raison sociale, SIREN, adresse, TVA, IBAN, BIC,
 *  mentions, vat_on_encashment, ui_mode_default). Inter-tenant safe :
 *  appelé depuis routes authentifiées avec `ctx.customer_id`. */
export async function findActiveCustomerById(
  sql: postgres.Sql,
  id: string,
): Promise<CustomerRow | undefined> {
  const rows = await sql<CustomerRow[]>`
    SELECT id, siren, legal_name, trading_name, address,
           naf_code, rcs, juridique_code, capital_social::text AS capital_social,
           vat_number, vat_regime, vat_on_encashment, iban, bic,
           logo_s3_key, primary_color, legal_mentions, directory_address,
           peppol_address_retry_count, peppol_address_next_retry_at,
           default_invoice_values, ui_mode_default, profile_unverified,
           siren_unverified, legal_name_unverified, address_unverified,
           vat_number_unverified,
           created_at, updated_at, deleted_at
    FROM customers
    WHERE id = ${id} AND deleted_at IS NULL
  `;
  return rows[0];
}

// ─────────────────────────────────────────────────────────────────────────
// UPDATE — single-column setters (pattern dicté par PATCH /customers/me/profile
// qui accepte des champs partiels — cf. customer-profile.ts)
// ─────────────────────────────────────────────────────────────────────────

export async function markCustomerTradingName(
  sql: postgres.Sql,
  id: string,
  value: string | null,
): Promise<void> {
  await sql`UPDATE customers SET trading_name = ${value} WHERE id = ${id}`;
}

export async function markCustomerIban(
  sql: postgres.Sql,
  id: string,
  value: string | null,
): Promise<void> {
  await sql`UPDATE customers SET iban = ${value} WHERE id = ${id}`;
}

export async function markCustomerBic(
  sql: postgres.Sql,
  id: string,
  value: string | null,
): Promise<void> {
  await sql`UPDATE customers SET bic = ${value} WHERE id = ${id}`;
}

export async function markCustomerCapitalSocial(
  sql: postgres.Sql,
  id: string,
  value: number | null,
): Promise<void> {
  await sql`UPDATE customers SET capital_social = ${value} WHERE id = ${id}`;
}

export async function markCustomerLegalMentions(
  sql: postgres.Sql,
  id: string,
  value: string | null,
): Promise<void> {
  await sql`UPDATE customers SET legal_mentions = ${value} WHERE id = ${id}`;
}

export async function markCustomerPrimaryColor(
  sql: postgres.Sql,
  id: string,
  value: string,
): Promise<void> {
  await sql`UPDATE customers SET primary_color = ${value} WHERE id = ${id}`;
}

export async function markCustomerLogoKey(
  sql: postgres.Sql,
  id: string,
  value: string | null,
): Promise<void> {
  await sql`UPDATE customers SET logo_s3_key = ${value} WHERE id = ${id}`;
}

export async function markCustomerDefaultInvoiceValues(
  sql: postgres.Sql,
  id: string,
  values: postgres.JSONValue,
): Promise<void> {
  await sql`
    UPDATE customers
    SET default_invoice_values = ${sql.json(values)}
    WHERE id = ${id}
  `;
}

/** T-CL-WEB-SETTINGS-ENTREPRISE-V1 sprint-05 — numéro de TVA intracom FR
 *  validé regex côté Zod (`FR[0-9A-HJ-NP-Z]{2}\d{9}`). Consommé par le
 *  pipeline d'émission `services/invoice-form-to-model.ts` comme `BT-31
 *  Seller VAT Identifier` (Schematron BR-FR strict, lève NC-17 BR-S-02). */
export async function markCustomerVatNumber(
  sql: postgres.Sql,
  id: string,
  value: string | null,
): Promise<void> {
  await sql`UPDATE customers SET vat_number = ${value} WHERE id = ${id}`;
}

/** T-CL-WEB-SETTINGS-ENTREPRISE-V1 sprint-05 — TVA sur encaissement
 *  (régime spécifique prestataires de services). Colonne BDD propre
 *  (sprint-02 schéma initial) — ignore le champ dupliqué dans le JSONB
 *  `default_invoice_values.vat_on_encashment` (legacy, non-consommé). */
export async function markCustomerVatOnEncashment(
  sql: postgres.Sql,
  id: string,
  value: boolean,
): Promise<void> {
  await sql`UPDATE customers SET vat_on_encashment = ${value} WHERE id = ${id}`;
}

/** T-CL-WEB-SETTINGS-ENTREPRISE-V1 sprint-05 — mode UI préféré de l'user
 *  (basic|advanced). Lève la dette `[DEBT-low T-CL-WEB-EMIT-LIST]` :
 *  bascule localStorage → backend pour cross-device. Consommé au boot
 *  par `<UiModeProvider>` via GET /customers/me/settings. */
export async function markCustomerUiModeDefault(
  sql: postgres.Sql,
  id: string,
  value: UiModeDefault,
): Promise<void> {
  await sql`UPDATE customers SET ui_mode_default = ${value} WHERE id = ${id}`;
}

/** T-CL-PA-DIRECTORY-PEPPOL sprint-05 — UPDATE `customers.directory_address`
 *  avec valeur Peppol annuaire (format `0225:<SIREN>[_<suffix>]`) post-OAuth
 *  callback success ou via job retry `enrich-customer-peppol-address`.
 *
 *  Reset les colonnes retry (count + next_retry_at) à valeurs neutres une
 *  fois l'adresse résolue avec succès. */
export async function updateCustomerDirectoryAddress(
  sql: postgres.Sql,
  id: string,
  directoryAddress: string,
): Promise<number> {
  const result = await sql`
    UPDATE customers
    SET directory_address = ${directoryAddress},
        peppol_address_retry_count = 0,
        peppol_address_next_retry_at = NULL
    WHERE id = ${id}
  `;
  return result.count;
}

/** T-CL-PA-DIRECTORY-PEPPOL sprint-05 — incrémente le compteur retry et
 *  set la prochaine fenêtre d'essai. Backoff 5/30/60/360/1440 min géré
 *  côté caller `enrich-customer-peppol-address.ts`. */
export async function bumpCustomerPeppolRetry(
  sql: postgres.Sql,
  id: string,
  nextRetryAt: Date | null,
): Promise<void> {
  await sql`
    UPDATE customers
    SET peppol_address_retry_count = peppol_address_retry_count + 1,
        peppol_address_next_retry_at = ${nextRetryAt}
    WHERE id = ${id}
  `;
}

/** Liste les customers dont l'adresse Peppol est manquante ou invalide
 *  et dont la fenêtre retry est arrivée. Consommé par le job cron
 *  `enrich-customer-peppol-address.ts`.
 *
 *  Filtre `created_at > NOW() - INTERVAL '7 days'` pour limiter le scope
 *  aux onboardings récents (évite de re-traiter indéfiniment les comptes
 *  anciens qui n'ont jamais été enrôlés annuaire — audit giveup au
 *  bout de 5 retries via colonne `peppol_address_retry_count >= 5`). */
export async function findCustomersPendingPeppolEnrichment(
  sql: postgres.Sql,
  maxRetries: number,
): Promise<readonly { id: string; siren: string; peppol_address_retry_count: number }[]> {
  return await sql<{ id: string; siren: string; peppol_address_retry_count: number }[]>`
    SELECT id, siren, peppol_address_retry_count
    FROM customers
    WHERE deleted_at IS NULL
      AND created_at > NOW() - INTERVAL '7 days'
      AND peppol_address_retry_count < ${maxRetries}
      AND (peppol_address_next_retry_at IS NULL OR peppol_address_next_retry_at <= NOW())
      AND (directory_address IS NULL OR directory_address NOT LIKE '0225:%')
  `;
}

/** T-CL-06 sprint-03 — flip `profile_unverified` from TRUE → FALSE
 *  when both SuperPDP identity statuses transition to `verified` (cf.
 *  ADR-007 D2). Called from the OAuth callback (immediate, T-CL-SIREN-
 *  RECONCILIATION sprint-06 — répare le gap F2 / ADR-007 D2 "bascule
 *  immédiate") AND from the polling sub-job (différé, needs_review →
 *  verified).
 *
 *  Non-régression (D1 ADR-007bis + ADR-007ter D1 candidat) : la garde
 *  `AND profile_unverified = TRUE` est *load-bearing* — l'UPDATE est
 *  no-op (count=0) si le flag est déjà FALSE, donc aucune transition
 *  régressive `FALSE → TRUE` n'est jamais émise par ce code path, ni
 *  pour le flag global ni pour les flags champ-spécifiques. Aucune
 *  fonction symétrique `markCustomerProfileUnverified` n'existe.
 *
 *  Sprint-06 W1 (Z6) : clear simultané des 4 flags champ-spécifiques
 *  (Mécanisme 1) en même temps que le flag global — un KYC `verified`
 *  atteste l'ensemble du profil. La granularité de clearing indépendant
 *  par champ est réservée V1.1 (réconciliation `legal_name`/`address`/
 *  `vat_number`, backlog sprint-07+). `siren_unverified` peut par
 *  ailleurs être cleared indépendamment par `markCustomerSirenReconciled`
 *  (Mécanisme 3) même hors transition de profil.
 *
 *  Returns the number of rows actually updated (0 if the flag was
 *  already FALSE). Caller emits the `pa_profile_verified` audit only
 *  when count > 0 to avoid pollution after a
 *  `verified → needs_review → verified` cycle. T-CL-07 expert review
 *  [low] #5. */
export async function markCustomerProfileVerified(sql: postgres.Sql, id: string): Promise<number> {
  const result = await sql`
    UPDATE customers
    SET profile_unverified = FALSE,
        siren_unverified = FALSE,
        legal_name_unverified = FALSE,
        address_unverified = FALSE,
        vat_number_unverified = FALSE
    WHERE id = ${id} AND profile_unverified = TRUE
  `;
  return result.count;
}

/** T-CL-SIREN-RECONCILIATION sprint-06 W1 — lecture ciblée du SIREN
 *  courant pour la réconciliation silencieuse (Mécanisme 3). Plus léger
 *  que `findActiveCustomerById`. Ne filtre pas `deleted_at` : appelé au
 *  callback OAuth / polling sur un customer actif par construction. */
export async function findCustomerSirenById(
  sql: postgres.Sql,
  id: string,
): Promise<{ siren: string } | undefined> {
  const rows = await sql<{ siren: string }[]>`
    SELECT siren FROM customers WHERE id = ${id}
  `;
  return rows[0];
}

export interface ReconciledCompanyInput {
  /** SIREN attesté (companies/me, normalisé 9 chiffres). */
  newSiren: string;
  /** Raison sociale attestée (`company.formal_name`). NOT NULL côté BDD. */
  legalName: string;
  /** Adresse attestée mappée au format `customers.address`, ou `null` si
   *  la PA ne la retourne pas (→ adresse réinitialisée à `{}`). */
  address: postgres.JSONValue | null;
}

/** T-CL-SIREN-RECONCILIATION sprint-06 W1 — Mécanisme 3 (Option B Bruno) :
 *  réconciliation SIREN priorité KYC (Z2 hard-switch) + **réinitialisation
 *  des informations de description d'entreprise** liées à l'ancien SIREN,
 *  pour éviter toute incohérence (la société attestée par la PA diffère de
 *  celle saisie à l'onboarding). N'est appelée QUE si aucune facture
 *  (émise/reçue) n'existe — la règle de blocage est portée par le service.
 *
 *  - `siren` ← SIREN attesté ; `legal_name` ← `formal_name` ; `address`
 *    ← adresse attestée (ou `{}` si absente).
 *  - `trading_name` / `naf_code` / `rcs` / `juridique_code` /
 *    `capital_social` / `vat_number` → NULL (réinitialisés — non
 *    ré-attestables par `companies/me` ; re-saisie / re-fetch INSEE V1.1).
 *  - `directory_address` → NULL + reset retry → force la re-résolution
 *    Peppol avec le NOUVEAU SIREN (lève le blocage émission 7.3).
 *  - flags : `siren`/`legal_name`/`address` attestés (FALSE) ;
 *    `vat_number_unverified` = TRUE (réinitialisé, à re-confirmer).
 *
 *  Returns the number of rows updated. */
export async function applyReconciledCompany(
  sql: postgres.Sql,
  id: string,
  input: ReconciledCompanyInput,
): Promise<number> {
  const result = await sql`
    UPDATE customers
    SET siren = ${input.newSiren},
        legal_name = ${input.legalName},
        address = ${sql.json(input.address ?? {})},
        trading_name = NULL,
        naf_code = NULL,
        rcs = NULL,
        juridique_code = NULL,
        capital_social = NULL,
        vat_number = NULL,
        directory_address = NULL,
        peppol_address_retry_count = 0,
        peppol_address_next_retry_at = NOW(),
        siren_unverified = FALSE,
        legal_name_unverified = FALSE,
        address_unverified = ${input.address === null},
        vat_number_unverified = TRUE
    WHERE id = ${id}
  `;
  return result.count;
}

// ─────────────────────────────────────────────────────────────────────────
// INSERT — phase 1 finalization transaction
// ─────────────────────────────────────────────────────────────────────────

export interface InsertCustomerFromPhase1 {
  siren: string;
  legalName: string;
  address: postgres.JSONValue;
  nafCode: string | null;
  juridiqueCode: string | null;
  directoryAddress: string;
  profileUnverified: boolean;
}

/** Used by `finalizePhase1` inside a transaction — returns the new id. */
export async function insertCustomerFromPhase1(
  sql: postgres.Sql,
  args: InsertCustomerFromPhase1,
): Promise<{ id: string }> {
  const rows = await sql<{ id: string }[]>`
    INSERT INTO customers (
      siren, legal_name, address, naf_code, juridique_code,
      directory_address, profile_unverified
    ) VALUES (
      ${args.siren},
      ${args.legalName},
      ${sql.json(args.address)},
      ${args.nafCode},
      ${args.juridiqueCode},
      ${args.directoryAddress},
      ${args.profileUnverified}
    )
    RETURNING id
  `;
  const r = rows[0];
  if (r === undefined) throw new Error("customer insert failed");
  return r;
}
