import type postgres from "postgres";

/**
 * `invoice_lines` repository — sprint-04 T-CL-API-INVOICE.
 * Cf. migration `20260516T064719_create_invoice_lines.sql`.
 *
 * **Pas de FK products** (mécanique Article = initialiseur T-CW-11) :
 * une ligne est créée soit en saisie libre soit pré-remplie via
 * `LineItemPicker` mais reste INDÉPENDANTE de l'article source après
 * initialisation.
 *
 * Pas de soft-delete : la ligne suit l'invoice (CASCADE).
 */

export interface InvoiceLineRow {
  id: string;
  invoice_id: string;
  line_number: number;
  label: string;
  description: string | null;
  /** Précision 4 décimales BT-129. String pour préserver précision. */
  quantity: string;
  unit_code: string;
  /** Précision 4 décimales BT-146. */
  unit_price_ht: string;
  /** Null pour AE/Z/E/K/G/O. */
  vat_rate: string | null;
  vat_category: "S" | "AE" | "Z" | "E" | "K" | "G" | "O";
  total_ht: string;
  period_start: Date | null;
  period_end: Date | null;
  allowance_amount: string | null;
  charge_amount: string | null;
  payload_extended: Record<string, unknown>;
}

const LINE_COLS = `
  id, invoice_id, line_number, label, description,
  quantity, unit_code, unit_price_ht, vat_rate, vat_category, total_ht,
  period_start, period_end, allowance_amount, charge_amount, payload_extended
`;

// ─────────────────────────────────────────────────────────────────────
// SELECT
// ─────────────────────────────────────────────────────────────────────

/** Lignes d'une invoice ordered ASC par `line_number` (ordre fiche). */
export async function findLinesByInvoiceId(
  sql: postgres.Sql,
  invoiceId: string,
): Promise<InvoiceLineRow[]> {
  return sql<InvoiceLineRow[]>`
    SELECT ${sql.unsafe(LINE_COLS)}
    FROM invoice_lines
    WHERE invoice_id = ${invoiceId}
    ORDER BY line_number ASC
  `;
}

// ─────────────────────────────────────────────────────────────────────
// INSERT (bulk dans la même tx que insertInvoice)
// ─────────────────────────────────────────────────────────────────────

export interface CreateInvoiceLineArgs {
  lineNumber: number;
  label: string;
  description?: string | null;
  quantity: string;
  unitCode?: string;
  unitPriceHt: string;
  vatRate?: string | null;
  vatCategory: "S" | "AE" | "Z" | "E" | "K" | "G" | "O";
  totalHt: string;
  periodStart?: string | null;
  periodEnd?: string | null;
  allowanceAmount?: string | null;
  chargeAmount?: string | null;
  payloadExtended?: Record<string, unknown>;
}

/** Insert bulk de N lignes pour une invoice — appelé dans la
 *  `withTransaction` du POST /api/invoices après `insertInvoice`. */
export async function insertInvoiceLines(
  sql: postgres.Sql,
  invoiceId: string,
  lines: CreateInvoiceLineArgs[],
): Promise<InvoiceLineRow[]> {
  if (lines.length === 0) return [];
  const result: InvoiceLineRow[] = [];
  // postgres.js gère mal le bulk INSERT typé avec valeurs jsonb hétérogènes
  // dans un tableau de tuples. On INSERT en boucle dans la même tx —
  // performance acceptable pour ≤ 100 lignes (cas TPE), pas de N+1 visible
  // car même connection.
  for (const l of lines) {
    const rows = await sql<InvoiceLineRow[]>`
      INSERT INTO invoice_lines (
        invoice_id, line_number, label, description,
        quantity, unit_code, unit_price_ht, vat_rate, vat_category, total_ht,
        period_start, period_end, allowance_amount, charge_amount, payload_extended
      )
      VALUES (
        ${invoiceId},
        ${l.lineNumber},
        ${l.label},
        ${l.description ?? null},
        ${l.quantity},
        ${l.unitCode ?? "C62"},
        ${l.unitPriceHt},
        ${l.vatRate ?? null},
        ${l.vatCategory},
        ${l.totalHt},
        ${l.periodStart ?? null},
        ${l.periodEnd ?? null},
        ${l.allowanceAmount ?? null},
        ${l.chargeAmount ?? null},
        ${sql.json((l.payloadExtended ?? {}) as postgres.JSONValue)}
      )
      RETURNING ${sql.unsafe(LINE_COLS)}
    `;
    const row = rows[0];
    if (row === undefined) throw new Error("[invoice_lines] insert returned no row");
    result.push(row);
  }
  return result;
}
