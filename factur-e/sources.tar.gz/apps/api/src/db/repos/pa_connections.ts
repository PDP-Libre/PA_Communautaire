import type postgres from "postgres";

/**
 * `pa_connections` repository — thin SQL access layer for the table created
 * in T-CL-04 sprint-03 (`20260506T053134_create_pa_connections.sql`).
 *
 * Convention T-CL-01 (cf. `docs/engineering/db-access.md`) :
 *  - `<X>Row` superset typed once, lean projections per call site.
 *  - `findActive*` encodes the `deleted_at IS NULL` guard so soft-delete
 *    invariants can't be forgotten at the call site.
 *  - `mark<Action>` mutates a small cohesive set of columns.
 *  - `insert*` returns the new id.
 *
 * Multi-PA forward-compat. The table's UNIQUE PARTIAL constraint is on
 * `(customer_id, provider) WHERE deleted_at IS NULL`. In MVP every row
 * is `provider='superpdp'` so it behaves like `customer_id UNIQUE`. The
 * scaffolding here defaults `provider='superpdp'` everywhere a function
 * doesn't take it as argument, so V2 multi-PA only needs to widen
 * signatures, not migrate the schema.
 *
 * Tokens are not stored here. `secret_ref` points to Scaleway Secret
 * Manager (prod) or Keychain (dev) — cf. ADR-005 D9.
 */

export type IdentityStatus = "verified" | "needs_review" | "rejected";

export interface PaConnectionRow {
  id: string;
  customer_id: string;
  provider: string;
  pa_user_id: string | null;
  secret_ref: string;
  user_identity_verification_status: IdentityStatus;
  company_verification_status: IdentityStatus;
  scopes: string[];
  connected_at: Date;
  last_refreshed_at: Date | null;
  refresh_failures_count: number;
  revoked_at: Date | null;
  deleted_at: Date | null;
}

// ─────────────────────────────────────────────────────────────────────────
// SELECT
// ─────────────────────────────────────────────────────────────────────────

export interface PaConnectionStatusRow {
  id: string;
  pa_user_id: string | null;
  user_identity_verification_status: IdentityStatus;
  company_verification_status: IdentityStatus;
  last_refreshed_at: Date | null;
  connected_at: Date;
}

/** Used by `GET /api/pa/status` (T-CL-06) — returns the active connection
 *  for the customer or `undefined` when none is connected (UI shows the
 *  "Connecter" CTA). MVP : provider hard-coded `'superpdp'` here. V2
 *  multi-PA will widen to `(customerId, provider)` args. */
export async function findActivePaConnectionStatusByCustomerId(
  sql: postgres.Sql,
  customerId: string,
): Promise<PaConnectionStatusRow | undefined> {
  const rows = await sql<PaConnectionStatusRow[]>`
    SELECT id, pa_user_id,
           user_identity_verification_status,
           company_verification_status,
           last_refreshed_at, connected_at
    FROM pa_connections
    WHERE customer_id = ${customerId}
      AND provider = ${"superpdp"}
      AND deleted_at IS NULL
  `;
  return rows[0];
}

export interface PaConnectionDisconnectRow {
  id: string;
  secret_ref: string;
  refresh_failures_count: number;
}

/** Used by `POST /oauth/superpdp/disconnect` (T-CL-06) — needs the id to
 *  pivot the soft-delete and the `secret_ref` to drive the secret manager
 *  cleanup + revoke call. */
export async function findActivePaConnectionForDisconnectByCustomerId(
  sql: postgres.Sql,
  customerId: string,
): Promise<PaConnectionDisconnectRow | undefined> {
  const rows = await sql<PaConnectionDisconnectRow[]>`
    SELECT id, secret_ref, refresh_failures_count
    FROM pa_connections
    WHERE customer_id = ${customerId}
      AND provider = ${"superpdp"}
      AND deleted_at IS NULL
  `;
  return rows[0];
}

export interface PaConnectionRefreshDueRow {
  id: string;
  customer_id: string;
  secret_ref: string;
  refresh_failures_count: number;
}

/** Used by the refresh-pa-tokens job (T-CL-06) — every 5 min sweeps the
 *  rows whose access token is approaching the 1800 s expiration window.
 *  Threshold passed as argument so the job can tune (default ~25 min in
 *  the call site). Rows already revoked or soft-deleted are excluded. */
export async function findPaConnectionsForRefresh(
  sql: postgres.Sql,
  thresholdSeconds: number,
): Promise<PaConnectionRefreshDueRow[]> {
  return sql<PaConnectionRefreshDueRow[]>`
    SELECT id, customer_id, secret_ref, refresh_failures_count
    FROM pa_connections
    WHERE deleted_at IS NULL
      AND revoked_at IS NULL
      AND (last_refreshed_at IS NULL
           OR last_refreshed_at < NOW() - INTERVAL '1 second' * ${thresholdSeconds})
  `;
}

export interface PaConnectionPollingRow {
  id: string;
  customer_id: string;
  secret_ref: string;
  user_identity_verification_status: IdentityStatus;
  company_verification_status: IdentityStatus;
}

/** Used by the poll-pa-identity-status sub-job (T-CL-06) — every 30 min
 *  sweeps the rows still pending a SuperPDP human KYC review. Rows that
 *  are already `verified` on both axes are skipped (see ADR-005 D6).
 *  Rejected rows are also skipped (they need manual support, not polling). */
export async function findPaConnectionsForIdentityPolling(
  sql: postgres.Sql,
): Promise<PaConnectionPollingRow[]> {
  return sql<PaConnectionPollingRow[]>`
    SELECT id, customer_id, secret_ref,
           user_identity_verification_status,
           company_verification_status
    FROM pa_connections
    WHERE deleted_at IS NULL
      AND revoked_at IS NULL
      AND (user_identity_verification_status = ${"needs_review"}
           OR company_verification_status = ${"needs_review"})
  `;
}

export interface PaConnectionForCdarPollingRow {
  id: string;
  customer_id: string;
  secret_ref: string;
}

/** T-CL-PA-INVOICE-FIX sprint-04 — utilisé par le job `poll-cdar-events`
 *  refondu (ADR-010 v2 D4 cursor global per-customer, plus per-invoice).
 *  Liste tous les customers ayant une connexion PA active pour le
 *  provider donné. Filtre soft-delete + revocation.
 *
 *  V1 : appelé uniquement avec `provider='superpdp'` (arbitrage Bruno
 *  Z2 — EsaLink stubbé V1 donc pas dans la boucle polling). V2 : appel
 *  pour chaque provider activé via `listEnabledProviders()`. */
export async function findActivePaConnectionsByProvider(
  sql: postgres.Sql,
  provider: string,
): Promise<PaConnectionForCdarPollingRow[]> {
  return sql<PaConnectionForCdarPollingRow[]>`
    SELECT id, customer_id, secret_ref
    FROM pa_connections
    WHERE provider = ${provider}
      AND deleted_at IS NULL
      AND revoked_at IS NULL
  `;
}

// ─────────────────────────────────────────────────────────────────────────
// INSERT
// ─────────────────────────────────────────────────────────────────────────

export interface InsertPaConnectionArgs {
  customerId: string;
  provider?: string;
  paUserId: string | null;
  secretRef: string;
  userIdentityStatus: IdentityStatus;
  companyStatus: IdentityStatus;
  scopes?: string[];
}

/** OAuth callback path (T-CL-06) — INSERT a fresh active connection.
 *  Defaults `provider='superpdp'` and `scopes={}` to keep call sites
 *  free of MVP-specific noise. */
export async function insertPaConnection(
  sql: postgres.Sql,
  args: InsertPaConnectionArgs,
): Promise<{ id: string }> {
  const provider = args.provider ?? "superpdp";
  const scopes = args.scopes ?? [];
  const rows = await sql<{ id: string }[]>`
    INSERT INTO pa_connections (
      customer_id, provider, pa_user_id, secret_ref,
      user_identity_verification_status, company_verification_status,
      scopes
    ) VALUES (
      ${args.customerId},
      ${provider},
      ${args.paUserId},
      ${args.secretRef},
      ${args.userIdentityStatus},
      ${args.companyStatus},
      ${scopes}
    )
    RETURNING id
  `;
  const r = rows[0];
  if (r === undefined) throw new Error("pa_connections insert failed");
  return r;
}

// ─────────────────────────────────────────────────────────────────────────
// UPDATE
// ─────────────────────────────────────────────────────────────────────────

/** Polling sub-job (T-CL-06) — UPDATE both identity statuses. The
 *  `customers.profile_unverified` flip from TRUE to FALSE on transition
 *  to `verified` is the caller's responsibility (ADR-007). */
export async function markPaConnectionIdentityStatuses(
  sql: postgres.Sql,
  id: string,
  args: { user: IdentityStatus; company: IdentityStatus },
): Promise<void> {
  await sql`
    UPDATE pa_connections
    SET user_identity_verification_status = ${args.user},
        company_verification_status = ${args.company}
    WHERE id = ${id}
  `;
}

/** Refresh job tick (T-CL-06) — successful refresh resets the failure
 *  counter and stamps `last_refreshed_at`. */
export async function markPaConnectionRefreshed(sql: postgres.Sql, id: string): Promise<void> {
  await sql`
    UPDATE pa_connections
    SET last_refreshed_at = NOW(),
        refresh_failures_count = 0
    WHERE id = ${id}
  `;
}

/** Refresh job failure tick (T-CL-06) — INCREMENT and return the new
 *  count so the caller can decide whether to soft-delete on the third
 *  consecutive failure (ADR-005 D8). */
export async function markPaConnectionRefreshFailureIncrement(
  sql: postgres.Sql,
  id: string,
): Promise<number> {
  const rows = await sql<{ refresh_failures_count: number }[]>`
    UPDATE pa_connections
    SET refresh_failures_count = refresh_failures_count + 1
    WHERE id = ${id}
    RETURNING refresh_failures_count
  `;
  return rows[0]?.refresh_failures_count ?? 0;
}

/** Disconnect path (T-CL-06) — soft-delete + RFC 7009 revoke timestamp.
 *  `deleted_at` makes the partial UNIQUE index release the slot so a
 *  fresh re-connect can INSERT a new row. */
export async function markPaConnectionRevoked(sql: postgres.Sql, id: string): Promise<void> {
  await sql`
    UPDATE pa_connections
    SET revoked_at = NOW(),
        deleted_at = NOW()
    WHERE id = ${id}
  `;
}
