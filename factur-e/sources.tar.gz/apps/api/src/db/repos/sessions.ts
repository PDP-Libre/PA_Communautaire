import type postgres from "postgres";

/**
 * `sessions` repository — thin SQL access layer for the `sessions` table.
 *
 * The INSERT helper lives in `db/tx.ts` (with the `INTERVAL '<TTL>'` build)
 * since 4 sites call it from inside a transaction and the TTL constant
 * comes from `auth/jwt.ts`.
 */

export interface SessionRow {
  id: string;
  user_id: string;
  ip: string | null;
  user_agent: string | null;
  expires_at: Date;
  revoked_at: Date | null;
  created_at: Date;
}

// ─────────────────────────────────────────────────────────────────────────
// SELECT
// ─────────────────────────────────────────────────────────────────────────

/** Refresh-token check : session must still exist, not be revoked, not expired. */
export async function findActiveSessionForRefresh(
  sql: postgres.Sql,
  args: { sessionId: string; userId: string },
): Promise<{ id: string } | undefined> {
  const rows = await sql<{ id: string }[]>`
    SELECT id FROM sessions
    WHERE id = ${args.sessionId}
      AND user_id = ${args.userId}
      AND revoked_at IS NULL
      AND expires_at > NOW()
  `;
  return rows[0];
}

// ─────────────────────────────────────────────────────────────────────────
// UPDATE / DELETE
// ─────────────────────────────────────────────────────────────────────────

/** Logout — soft revoke the matching session row. */
export async function revokeSessionById(sql: postgres.Sql, sessionId: string): Promise<void> {
  await sql`
    UPDATE sessions
    SET revoked_at = NOW()
    WHERE id = ${sessionId} AND revoked_at IS NULL
  `;
}

/** Hard delete — used by `DELETE /users/:id` to drop all live sessions of
 *  a user being deactivated (single transaction with the user soft-delete). */
export async function deleteSessionsByUserId(sql: postgres.Sql, userId: string): Promise<void> {
  await sql`DELETE FROM sessions WHERE user_id = ${userId}`;
}
