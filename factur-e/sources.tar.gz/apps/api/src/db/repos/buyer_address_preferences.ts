import type postgres from "postgres";

/**
 * `buyer_address_preferences` repository — thin SQL access layer
 * (T-CL-09 sprint-03). Mémorise la préférence d'adresse Peppol par
 * couple `(customer_id, buyer_siren)` quand le user a choisi parmi
 * plusieurs `french_directory_entry` actives (tuilage entre PA, cf.
 * PRD v1.4 §5.5 critère 4 + T-CW-09 sprint-02 Q3).
 *
 * Convention T-CL-01. La PK est composite ; une seule préférence par
 * couple. UPSERT sur conflit pour gérer le cas où le user change
 * d'avis et reclique sur une autre adresse.
 */

export interface BuyerAddressPreferenceRow {
  customer_id: string;
  buyer_siren: string;
  preferred_party_id: string;
  last_used_at: Date;
}

// ─────────────────────────────────────────────────────────────────────────
// SELECT
// ─────────────────────────────────────────────────────────────────────────

/** Read pour `POST /api/directory/search` (T-CL-10) — applique la
 *  préférence au lieu d'afficher le sélecteur si présente. */
export async function findBuyerAddressPreference(
  sql: postgres.Sql,
  args: { customerId: string; buyerSiren: string },
): Promise<BuyerAddressPreferenceRow | undefined> {
  const rows = await sql<BuyerAddressPreferenceRow[]>`
    SELECT customer_id, buyer_siren, preferred_party_id, last_used_at
    FROM buyer_address_preferences
    WHERE customer_id = ${args.customerId}
      AND buyer_siren = ${args.buyerSiren}
  `;
  return rows[0];
}

// ─────────────────────────────────────────────────────────────────────────
// UPSERT / UPDATE
// ─────────────────────────────────────────────────────────────────────────

export interface UpsertBuyerAddressPreferenceArgs {
  customerId: string;
  buyerSiren: string;
  preferredPartyId: string;
}

/** Set or replace the preference (`POST /api/directory/preference`
 *  T-CL-10). `last_used_at` reset à NOW() à chaque write. */
export async function upsertBuyerAddressPreference(
  sql: postgres.Sql,
  args: UpsertBuyerAddressPreferenceArgs,
): Promise<void> {
  await sql`
    INSERT INTO buyer_address_preferences (customer_id, buyer_siren, preferred_party_id, last_used_at)
    VALUES (${args.customerId}, ${args.buyerSiren}, ${args.preferredPartyId}, NOW())
    ON CONFLICT (customer_id, buyer_siren) DO UPDATE SET
      preferred_party_id = EXCLUDED.preferred_party_id,
      last_used_at       = EXCLUDED.last_used_at
  `;
}

/** Touch `last_used_at` only — used when the cached preference is
 *  re-applied silently (no UI sélecteur shown). */
export async function markBuyerAddressPreferenceUsed(
  sql: postgres.Sql,
  args: { customerId: string; buyerSiren: string },
): Promise<void> {
  await sql`
    UPDATE buyer_address_preferences
    SET last_used_at = NOW()
    WHERE customer_id = ${args.customerId}
      AND buyer_siren = ${args.buyerSiren}
  `;
}
