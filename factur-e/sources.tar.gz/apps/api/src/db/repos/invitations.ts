import type postgres from "postgres";

import type { UserRole } from "./users.js";

/**
 * `invitations` repository — thin SQL access layer for the `invitations`
 * table. cf. brief design sprint-02 §5.5, plan T-CL-07.
 *
 * Token storage convention (cf. `users/invitation-token.ts`) :
 *  - the brut token = `<id>.<32-hex-secret>`,
 *  - `id` is in clear (selected to fetch the row),
 *  - `secret` is verified bcrypt-side against `token_hash` (cost 12).
 *
 * The TTL constant lives at the call site (7 days, cf. invitations.ts route)
 * because the SQL needs to format `INTERVAL '<N> days'` with `unsafe()`.
 * We expose `insertInvitation` taking a `ttlDays` argument for clarity.
 */

export interface InvitationRow {
  id: string;
  customer_id: string;
  inviter_id: string;
  email: string;
  role: UserRole;
  can_purchase: boolean;
  token_hash: string;
  expires_at: Date;
  accepted_at: Date | null;
  created_at: Date;
}

// ─────────────────────────────────────────────────────────────────────────
// SELECT
// ─────────────────────────────────────────────────────────────────────────

/** GET /invitations — pending non-expired invitations for a customer. */
export interface PendingInvitationListRow {
  id: string;
  email: string;
  role: UserRole;
  can_purchase: boolean;
  inviter_id: string;
  expires_at: Date;
  created_at: Date;
}

export async function findPendingInvitationsByCustomer(
  sql: postgres.Sql,
  customerId: string,
): Promise<PendingInvitationListRow[]> {
  return sql<PendingInvitationListRow[]>`
    SELECT id, email, role, can_purchase, inviter_id, expires_at, created_at
    FROM invitations
    WHERE customer_id = ${customerId}
      AND accepted_at IS NULL
      AND expires_at > NOW()
    ORDER BY created_at DESC
  `;
}

/** Used right after insert to surface the computed `expires_at` timestamp
 *  (since the route doesn't compute it locally — INTERVAL is server-side). */
export async function findInvitationExpiresAtById(
  sql: postgres.Sql,
  id: string,
): Promise<{ expires_at: Date } | undefined> {
  const rows = await sql<{ expires_at: Date }[]>`
    SELECT expires_at FROM invitations WHERE id = ${id}
  `;
  return rows[0];
}

/** Public preview — joins customer legal name + inviter email so the
 *  invitee sees who invited them and to which company. */
export interface InvitationPreviewRow {
  email: string;
  role: UserRole;
  can_purchase: boolean;
  token_hash: string;
  accepted_at: Date | null;
  expires_at: Date;
  customer_legal_name: string;
  inviter_email: string;
}

export async function findInvitationPreviewById(
  sql: postgres.Sql,
  id: string,
): Promise<InvitationPreviewRow | undefined> {
  const rows = await sql<InvitationPreviewRow[]>`
    SELECT i.email, i.role, i.can_purchase, i.token_hash, i.accepted_at, i.expires_at,
           c.legal_name AS customer_legal_name,
           u.email AS inviter_email
    FROM invitations i
    JOIN customers c ON c.id = i.customer_id
    JOIN users u ON u.id = i.inviter_id
    WHERE i.id = ${id}
  `;
  return rows[0];
}

/** Accept-flow lookup — full row needed to bcrypt-verify the secret and
 *  pull `customer_id` / `email` / `role` / `can_purchase` for the user
 *  insert + session insert. */
export interface InvitationAcceptRow {
  id: string;
  customer_id: string;
  email: string;
  role: UserRole;
  can_purchase: boolean;
  token_hash: string;
  accepted_at: Date | null;
  expires_at: Date;
}

export async function findInvitationForAcceptById(
  sql: postgres.Sql,
  id: string,
): Promise<InvitationAcceptRow | undefined> {
  const rows = await sql<InvitationAcceptRow[]>`
    SELECT id, customer_id, email, role, can_purchase, token_hash, accepted_at, expires_at
    FROM invitations
    WHERE id = ${id}
  `;
  return rows[0];
}

// ─────────────────────────────────────────────────────────────────────────
// INSERT / UPDATE / DELETE
// ─────────────────────────────────────────────────────────────────────────

export interface InsertInvitationArgs {
  id: string;
  customerId: string;
  inviterId: string;
  email: string;
  role: UserRole;
  canPurchase: boolean;
  tokenHash: string;
  ttlDays: number;
}

/** POST /users/invite — INSERT row with a server-side computed expiry. */
export async function insertInvitation(
  sql: postgres.Sql,
  args: InsertInvitationArgs,
): Promise<void> {
  await sql`
    INSERT INTO invitations (id, customer_id, inviter_id, email, role, can_purchase, token_hash, expires_at)
    VALUES (
      ${args.id},
      ${args.customerId},
      ${args.inviterId},
      ${args.email},
      ${args.role},
      ${args.canPurchase},
      ${args.tokenHash},
      NOW() + INTERVAL '${sql.unsafe(String(args.ttlDays))} days'
    )
  `;
}

/** Replace any existing pending invitation for the same (customer, email)
 *  before issuing a new one (Q5 brief sprint-02). */
export async function deletePendingInvitationByCustomerAndEmail(
  sql: postgres.Sql,
  args: { customerId: string; email: string },
): Promise<void> {
  await sql`
    DELETE FROM invitations
    WHERE customer_id = ${args.customerId}
      AND email = ${args.email}
      AND accepted_at IS NULL
  `;
}

/** DELETE /invitations/:id — revoke a pending invitation. Returns the
 *  number of affected rows so the route can reply 404 vs 204. */
export async function deletePendingInvitationByIdAndCustomer(
  sql: postgres.Sql,
  args: { id: string; customerId: string },
): Promise<number> {
  const result = await sql`
    DELETE FROM invitations
    WHERE id = ${args.id}
      AND customer_id = ${args.customerId}
      AND accepted_at IS NULL
  `;
  return result.count;
}

/** Mark an invitation as consumed inside the accept-flow transaction. */
export async function markInvitationAccepted(sql: postgres.Sql, id: string): Promise<void> {
  await sql`UPDATE invitations SET accepted_at = NOW() WHERE id = ${id}`;
}

/** Hourly cleanup job (T-CL-03 sprint-03) — drops invitations whose TTL
 *  is past **and** that were never accepted. An accepted invitation is
 *  audit history and stays. Returns the row count for structured logging. */
export async function deleteInvitationsExpiredUnaccepted(sql: postgres.Sql): Promise<number> {
  const res = await sql`
    DELETE FROM invitations
    WHERE expires_at < NOW() AND accepted_at IS NULL
  `;
  return res.count;
}
