import type postgres from "postgres";

/**
 * `incoming_cdar_events` repository — thin SQL layer pour la table créée
 * par `20260525T093010_create_incoming_cdar_events.sql` (T-CL-RECV-API
 * sprint-05 W2). Convention T-CL-01.
 *
 * Timeline CDAR des factures REÇUES (`received_invoices`), distincte de
 * `cdar_events` (factures émises, §7.5 Z11). Events :
 *  - `fr:204` auto à la réception (worker, source `'polling'`).
 *  - `fr:205` / `fr:210` posés par l'utilisateur (source `'app'`),
 *    propagés à SuperPDP via `POST /v1.beta/invoice_events`.
 *
 * Idempotence ADR-009 D4 : `INSERT … ON CONFLICT (received_invoice_id,
 * code, occurred_at) DO NOTHING`. Le `inserted` retourné indique si la
 * ligne est nouvelle (caller décide d'émettre audit / UPDATE status).
 */

export type IncomingCdarEventSource = "webhook" | "polling" | "app";

export interface IncomingCdarEventInsertInput {
  received_invoice_id: string;
  code: string;
  occurred_at: string | Date;
  label?: string | null;
  payload?: unknown;
  reason_code?: string | null;
  reason_text?: string | null;
  source: IncomingCdarEventSource;
}

export interface IncomingCdarEventInsertResult {
  /** `true` si nouvelle ligne ; `false` si duplicate ignoré (ADR-009 D4). */
  inserted: boolean;
  id: string | null;
}

export async function insertIncomingCdarEvent(
  sql: postgres.Sql,
  input: IncomingCdarEventInsertInput,
): Promise<IncomingCdarEventInsertResult> {
  const payloadJson = sql.json((input.payload ?? {}) as postgres.JSONValue);
  const rows = await sql<{ id: string }[]>`
    INSERT INTO incoming_cdar_events (
      received_invoice_id, code, label, occurred_at, payload,
      reason_code, reason_text, source
    ) VALUES (
      ${input.received_invoice_id},
      ${input.code},
      ${input.label ?? null},
      ${input.occurred_at instanceof Date ? input.occurred_at : new Date(input.occurred_at)},
      ${payloadJson},
      ${input.reason_code ?? null},
      ${input.reason_text ?? null},
      ${input.source}
    )
    ON CONFLICT (received_invoice_id, code, occurred_at) DO NOTHING
    RETURNING id
  `;
  const first = rows[0];
  if (first === undefined) return { inserted: false, id: null };
  return { inserted: true, id: first.id };
}

export interface IncomingCdarEventRow {
  id: string;
  received_invoice_id: string;
  code: string;
  label: string | null;
  occurred_at: Date;
  payload: Record<string, unknown>;
  reason_code: string | null;
  reason_text: string | null;
  source: IncomingCdarEventSource;
  created_at: Date;
}

const INCOMING_CDAR_COLS = `
  id, received_invoice_id, code, label, occurred_at, payload,
  reason_code, reason_text, source, created_at
`;

/** Tous les events d'une facture reçue, ASC par `occurred_at` (timeline
 *  UI — du plus ancien au plus récent). */
export async function findIncomingCdarEventsByReceivedInvoiceId(
  sql: postgres.Sql,
  receivedInvoiceId: string,
): Promise<IncomingCdarEventRow[]> {
  return sql<IncomingCdarEventRow[]>`
    SELECT ${sql.unsafe(INCOMING_CDAR_COLS)}
    FROM incoming_cdar_events
    WHERE received_invoice_id = ${receivedInvoiceId}
    ORDER BY occurred_at ASC, created_at ASC
  `;
}
