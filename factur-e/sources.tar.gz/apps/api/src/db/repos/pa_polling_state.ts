import type postgres from "postgres";

/**
 * `pa_polling_state` repository — thin SQL layer pour la table créée par
 * `20260517T085553_create_pa_polling_state.sql` (T-CL-PA-INVOICE-FIX
 * sprint-04, ADR-012 D5).
 *
 * Convention T-CL-01 (cf. `docs/engineering/db-access.md`).
 *
 * Sémantique cursor portable (`text`) : interprétation côté driver.
 *   - SuperPDP : `event.id` integer stringifié (ADR-010 v2 D4 cursor
 *     Stripe-like). Initial : `'0'`.
 *   - EsaLink V2 : ISO8601 timestamp `max(results[].updatedAt)`
 *     (ADR-011 D7 pull-only). Initial : epoch ou `now() - lookback`.
 *
 * Consommé par `apps/api/src/jobs/poll-cdar-events.ts` :
 *   1. `getCursor(sql, customer_id, provider)` — récupère le dernier
 *      curseur persisté (ou `undefined` au premier tick).
 *   2. Appel `driver.pollCdarEvents({cursor, limit: 100}, ctx)`.
 *   3. Sur succès : `upsertCursor(sql, customer_id, provider, nextCursor)`.
 *   4. Sur fail (5xx épuisé) : **pas d'upsert** — pattern fail-safe
 *      ADR-009 D1 (le tick suivant retry avec le même cursor, pas de
 *      perte d'events).
 */

/** Direction du flux pollé — scope le cursor (§7.5 Z9, T-CL-RECV-API
 *  sprint-05 W2). `'out'` = émission (`invoice_events`), `'in'` =
 *  réception (`invoices?direction=in`). */
export type PollingDirection = "in" | "out";

/** Direction par défaut — `'out'` préserve le comportement
 *  `poll-cdar-events.ts` (sprint-04) qui n'a pas conscience de la
 *  direction. */
const DEFAULT_DIRECTION: PollingDirection = "out";

export interface PaPollingStateRow {
  customer_id: string;
  provider: string;
  /** Scope du cursor — ajouté T-CL-RECV-API sprint-05 W2 (§7.5 Z9). */
  direction: PollingDirection;
  cursor: string;
  last_polled_at: Date;
}

// ─────────────────────────────────────────────────────────────────────
// SELECT
// ─────────────────────────────────────────────────────────────────────

/** Lecture du cursor courant. Retourne `undefined` si aucun tick n'a
 *  encore été persisté pour ce triplet (customer, provider, direction) —
 *  le caller doit alors passer un cursor initial driver-spécifique
 *  (SuperPDP : `'0'`). `direction` défaut `'out'` (compat sprint-04). */
export async function getCursor(
  sql: postgres.Sql,
  customerId: string,
  provider: string,
  direction: PollingDirection = DEFAULT_DIRECTION,
): Promise<PaPollingStateRow | undefined> {
  const rows = await sql<PaPollingStateRow[]>`
    SELECT customer_id, provider, direction, cursor, last_polled_at
    FROM pa_polling_state
    WHERE customer_id = ${customerId}
      AND provider = ${provider}
      AND direction = ${direction}
  `;
  return rows[0];
}

// ─────────────────────────────────────────────────────────────────────
// UPSERT
// ─────────────────────────────────────────────────────────────────────

/** UPSERT atomique du cursor + last_polled_at (NOW) scopé par direction.
 *  Pattern ON CONFLICT pour gérer le premier tick (INSERT) et les ticks
 *  suivants (UPDATE) sans transaction explicite côté caller.
 *  `direction` défaut `'out'` (compat sprint-04 `poll-cdar-events.ts`). */
export async function upsertCursor(
  sql: postgres.Sql,
  args: { customerId: string; provider: string; cursor: string; direction?: PollingDirection },
): Promise<void> {
  const direction = args.direction ?? DEFAULT_DIRECTION;
  await sql`
    INSERT INTO pa_polling_state (customer_id, provider, direction, cursor, last_polled_at)
    VALUES (${args.customerId}, ${args.provider}, ${direction}, ${args.cursor}, NOW())
    ON CONFLICT (customer_id, provider, direction) DO UPDATE
      SET cursor = EXCLUDED.cursor,
          last_polled_at = EXCLUDED.last_polled_at
  `;
}
