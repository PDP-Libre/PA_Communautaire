import type postgres from "postgres";

/**
 * `products` repository — thin SQL access layer (T-CL-11 sprint-03).
 * Catalogue d'articles, isolation multi-tenant via `customer_id`.
 * Cf. migration `20260511T075634_create_products.sql`.
 *
 * Convention T-CL-01 :
 *  - SELECTs filtrent `deleted_at IS NULL` systématiquement (hard-delete
 *    admin uniquement).
 *  - `is_archived` est UN champ utilisateur (soft-delete UI). Les SELECTs
 *    listing l'excluent par défaut sauf si `includeArchived: true`.
 *  - Le `customerId` est exigé dans tous les SELECTs/UPDATEs/DELETEs
 *    pour empêcher la fuite d'IDs inter-tenant.
 *
 * UI dit "Articles" mais la table BDD reste `products` pour cohérence
 * EN 16931 (glossaire T-CW-11). Commentaires/code peuvent dire "product".
 */

export interface ProductRow {
  id: string;
  customer_id: string;
  label: string;
  description: string | null;
  internal_code: string | null;
  /** Précision 4 décimales BT-146. Retourné en `string` par postgres.js
   *  pour préserver la précision décimale exacte (pas de cast number). */
  unit_price_ht: string;
  unit: string;
  vat_category: "S" | "AE" | "Z" | "E" | "K" | "G" | "O";
  /** `string` (numeric) si présent, `null` sinon. */
  vat_rate: string | null;
  category_id: string | null;
  is_archived: boolean;
  created_at: Date;
  updated_at: Date;
}

// ─────────────────────────────────────────────────────────────────────────
// SELECT
// ─────────────────────────────────────────────────────────────────────────

export interface ListProductsByCustomerArgs {
  /** Inclure les articles archivés. Défaut `false` (vue utilisateur). */
  includeArchived?: boolean;
  /** Recherche full-text simple sur `label` ILIKE `%search%`. Pour
   *  T-CL-11 on reste sur ILIKE — la table est petite (≤ quelques
   *  centaines d'items par customer), pas besoin de tsvector. */
  search?: string;
  /** Filtre catégorie. `null` explicite = articles sans catégorie. */
  categoryId?: string | null;
}

/** Liste les articles d'un customer avec filtres optionnels. Ordre :
 *  label ASC (UI listing). */
export async function listProductsByCustomer(
  sql: postgres.Sql,
  customerId: string,
  args: ListProductsByCustomerArgs = {},
): Promise<ProductRow[]> {
  const includeArchived = args.includeArchived === true;
  return sql<ProductRow[]>`
    SELECT id, customer_id, label, description, internal_code,
           unit_price_ht, unit, vat_category, vat_rate, category_id,
           is_archived, created_at, updated_at
    FROM products
    WHERE customer_id = ${customerId}
      AND deleted_at IS NULL
      ${includeArchived ? sql`` : sql`AND is_archived = FALSE`}
      ${
        args.search !== undefined && args.search !== ""
          ? sql`AND label ILIKE ${"%" + args.search + "%"}`
          : sql``
      }
      ${
        args.categoryId === null
          ? sql`AND category_id IS NULL`
          : args.categoryId !== undefined
            ? sql`AND category_id = ${args.categoryId}`
            : sql``
      }
    ORDER BY label ASC
  `;
}

/** Lookup par id, filtré customer (inter-tenant safe). Retourne
 *  `undefined` si absent / archivé NE filtre PAS — un caller qui veut
 *  consulter un article archivé y accède toujours (UI "désarchiver"). */
export async function findProductById(
  sql: postgres.Sql,
  args: { id: string; customerId: string },
): Promise<ProductRow | undefined> {
  const rows = await sql<ProductRow[]>`
    SELECT id, customer_id, label, description, internal_code,
           unit_price_ht, unit, vat_category, vat_rate, category_id,
           is_archived, created_at, updated_at
    FROM products
    WHERE id = ${args.id}
      AND customer_id = ${args.customerId}
      AND deleted_at IS NULL
  `;
  return rows[0];
}

/** Lookup par internal_code — retourne un **array** car les doublons
 *  sont autorisés (cf. T-CW-10 Q5 acté Bruno). L'UI badge la collision
 *  côté formulaire mais ne bloque pas. Vide si aucun match. */
export async function findProductsByInternalCode(
  sql: postgres.Sql,
  args: { customerId: string; internalCode: string },
): Promise<ProductRow[]> {
  return sql<ProductRow[]>`
    SELECT id, customer_id, label, description, internal_code,
           unit_price_ht, unit, vat_category, vat_rate, category_id,
           is_archived, created_at, updated_at
    FROM products
    WHERE customer_id = ${args.customerId}
      AND internal_code = ${args.internalCode}
      AND deleted_at IS NULL
    ORDER BY label ASC
  `;
}

// ─────────────────────────────────────────────────────────────────────────
// INSERT / UPDATE
// ─────────────────────────────────────────────────────────────────────────

export interface CreateProductArgs {
  customerId: string;
  label: string;
  description?: string | null;
  internalCode?: string | null;
  /** String pour préserver la précision décimale (BT-146 4 chiffres). */
  unitPriceHt: string;
  /** Défaut `"unité"` si non fourni. */
  unit?: string;
  vatCategory: "S" | "AE" | "Z" | "E" | "K" | "G" | "O";
  /** String numeric ou null pour les catégories sans taux applicable. */
  vatRate?: string | null;
  categoryId?: string | null;
}

export async function createProduct(
  sql: postgres.Sql,
  args: CreateProductArgs,
): Promise<ProductRow> {
  const rows = await sql<ProductRow[]>`
    INSERT INTO products (
      customer_id, label, description, internal_code,
      unit_price_ht, unit, vat_category, vat_rate, category_id
    )
    VALUES (
      ${args.customerId},
      ${args.label},
      ${args.description ?? null},
      ${args.internalCode ?? null},
      ${args.unitPriceHt},
      ${args.unit ?? "unité"},
      ${args.vatCategory},
      ${args.vatRate ?? null},
      ${args.categoryId ?? null}
    )
    RETURNING id, customer_id, label, description, internal_code,
              unit_price_ht, unit, vat_category, vat_rate, category_id,
              is_archived, created_at, updated_at
  `;
  const row = rows[0];
  if (row === undefined) throw new Error("[products] insert returned no row");
  return row;
}

export interface UpdateProductArgs {
  id: string;
  customerId: string;
  label: string;
  description: string | null;
  internalCode: string | null;
  unitPriceHt: string;
  unit: string;
  vatCategory: "S" | "AE" | "Z" | "E" | "K" | "G" | "O";
  vatRate: string | null;
  categoryId: string | null;
}

/** Update full row (sauf is_archived qui a ses propres mutators). Returns
 *  le nombre de rows touchées (0 = id absent ou hard-deleted). */
export async function updateProduct(sql: postgres.Sql, args: UpdateProductArgs): Promise<number> {
  const result = await sql`
    UPDATE products
    SET label = ${args.label},
        description = ${args.description},
        internal_code = ${args.internalCode},
        unit_price_ht = ${args.unitPriceHt},
        unit = ${args.unit},
        vat_category = ${args.vatCategory},
        vat_rate = ${args.vatRate},
        category_id = ${args.categoryId},
        updated_at = NOW()
    WHERE id = ${args.id}
      AND customer_id = ${args.customerId}
      AND deleted_at IS NULL
  `;
  return result.count;
}

// ─────────────────────────────────────────────────────────────────────────
// ARCHIVE / UNARCHIVE (soft-delete UI)
// ─────────────────────────────────────────────────────────────────────────

export async function archiveProduct(
  sql: postgres.Sql,
  args: { id: string; customerId: string },
): Promise<number> {
  const result = await sql`
    UPDATE products
    SET is_archived = TRUE, updated_at = NOW()
    WHERE id = ${args.id}
      AND customer_id = ${args.customerId}
      AND deleted_at IS NULL
  `;
  return result.count;
}

export async function unarchiveProduct(
  sql: postgres.Sql,
  args: { id: string; customerId: string },
): Promise<number> {
  const result = await sql`
    UPDATE products
    SET is_archived = FALSE, updated_at = NOW()
    WHERE id = ${args.id}
      AND customer_id = ${args.customerId}
      AND deleted_at IS NULL
  `;
  return result.count;
}

// ─────────────────────────────────────────────────────────────────────────
// HARD-DELETE (admin uniquement, RGPD)
// ─────────────────────────────────────────────────────────────────────────

/** Stamp `deleted_at` — l'article disparaît de toute API user. Jamais
 *  routé en API utilisateur ; réservé back-office admin / suppression
 *  customer cascade. Le caller doit avoir validé qu'aucune ligne de
 *  facture en cours ne référence ce product. */
export async function hardDeleteProduct(
  sql: postgres.Sql,
  args: { id: string; customerId: string },
): Promise<number> {
  const result = await sql`
    UPDATE products
    SET deleted_at = NOW()
    WHERE id = ${args.id}
      AND customer_id = ${args.customerId}
      AND deleted_at IS NULL
  `;
  return result.count;
}
