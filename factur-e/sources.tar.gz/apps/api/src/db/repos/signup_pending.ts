import type postgres from "postgres";

/**
 * `signup_pending` repository — thin SQL access layer for the transitional
 * phase-1 onboarding row. cf. brief design sprint-02 §5.1, plan T-CL-02.
 *
 * Two read shapes coexist:
 *  - `SignupPendingDigest` — small projection used by `findActivePendingDigestById`
 *    (cookie resolution from /auth/me). Fits the public `AuthMeResponse` shape.
 *  - `SignupPendingFullRow` — every column needed by `finalizePhase1` to
 *    decide between success / decoy / incomplete / expired and build the
 *    inserts.
 *
 * Most mutations are tiny `mark*` UPDATEs touching a couple of columns at
 * a time. The transitional row is short-lived (TTL 7 days) and never
 * grouped in a transaction except for the final atomic delete inside
 * `finalizePhase1`.
 */

export type MfaModeChoice = "email" | "totp";

export interface SignupPendingDigest {
  id: string;
  email: string;
  current_step: string;
  expires_at: Date;
  is_decoy: boolean;
}

export interface SignupPendingFullRow {
  id: string;
  email: string;
  password_hash: string;
  terms_accepted_at: Date;
  siren: string | null;
  customer_data_prefilled: Record<string, unknown> | null;
  email_verified_at: Date | null;
  secondary_email: string | null;
  secondary_email_verified_at: Date | null;
  mfa_mode_choice: MfaModeChoice | null;
  mfa_secret_pending: Buffer | null;
  mfa_setup_completed_at: Date | null;
  recovery_codes_pending: string[] | null;
  recovery_codes_acked_at: Date | null;
  current_step: string;
  is_decoy: boolean;
  expires_at: Date;
}

// ─────────────────────────────────────────────────────────────────────────
// SELECT
// ─────────────────────────────────────────────────────────────────────────

/** Cookie resolution — only the small digest, expiry-guarded. */
export async function findActivePendingDigestById(
  sql: postgres.Sql,
  id: string,
): Promise<SignupPendingDigest | undefined> {
  const rows = await sql<SignupPendingDigest[]>`
    SELECT id, email, current_step, expires_at, is_decoy
    FROM signup_pending
    WHERE id = ${id} AND expires_at > NOW()
  `;
  return rows[0];
}

/** finalizePhase1 — every column. No expires_at guard (the caller decides
 *  how to react to expiry). */
export async function findPendingFullById(
  sql: postgres.Sql,
  id: string,
): Promise<SignupPendingFullRow | undefined> {
  const rows = await sql<SignupPendingFullRow[]>`
    SELECT id, email, password_hash, terms_accepted_at, siren,
           customer_data_prefilled, email_verified_at,
           secondary_email, secondary_email_verified_at,
           mfa_mode_choice, mfa_secret_pending,
           mfa_setup_completed_at, recovery_codes_pending,
           recovery_codes_acked_at, current_step, is_decoy, expires_at
    FROM signup_pending
    WHERE id = ${id}
  `;
  return rows[0];
}

/** email-verify magic-link consume — minimal projection (no expiry guard:
 *  caller checks `expires_at` to map to 410 / 409 / 200). */
export async function findPendingEmailVerifyContextById(
  sql: postgres.Sql,
  id: string,
): Promise<
  | {
      id: string;
      email_verified_at: Date | null;
      current_step: string;
      expires_at: Date;
    }
  | undefined
> {
  const rows = await sql<
    { id: string; email_verified_at: Date | null; current_step: string; expires_at: Date }[]
  >`
    SELECT id, email_verified_at, current_step, expires_at
    FROM signup_pending
    WHERE id = ${id}
  `;
  return rows[0];
}

/** email-verify-trigger — needs `is_decoy` to branch reset vs verify. */
export async function findActivePendingEmailDecoyById(
  sql: postgres.Sql,
  id: string,
): Promise<{ id: string; email: string; is_decoy: boolean; expires_at: Date } | undefined> {
  const rows = await sql<{ id: string; email: string; is_decoy: boolean; expires_at: Date }[]>`
    SELECT id, email, is_decoy, expires_at
    FROM signup_pending
    WHERE id = ${id} AND expires_at > NOW()
  `;
  return rows[0];
}

/** mfa-choose / mfa-verify / secondary-email-set — small id+email digest. */
export async function findActivePendingEmailById(
  sql: postgres.Sql,
  id: string,
): Promise<{ id: string; email: string; expires_at: Date } | undefined> {
  const rows = await sql<{ id: string; email: string; expires_at: Date }[]>`
    SELECT id, email, expires_at
    FROM signup_pending
    WHERE id = ${id} AND expires_at > NOW()
  `;
  return rows[0];
}

/** phase1 mfa-verify — needs MFA mode choice + pending secret. */
export async function findActivePendingMfaContextById(
  sql: postgres.Sql,
  id: string,
): Promise<
  | {
      id: string;
      mfa_mode_choice: MfaModeChoice | null;
      mfa_secret_pending: Buffer | null;
      expires_at: Date;
    }
  | undefined
> {
  const rows = await sql<
    {
      id: string;
      mfa_mode_choice: MfaModeChoice | null;
      mfa_secret_pending: Buffer | null;
      expires_at: Date;
    }[]
  >`
    SELECT id, mfa_mode_choice, mfa_secret_pending, expires_at
    FROM signup_pending
    WHERE id = ${id} AND expires_at > NOW()
  `;
  return rows[0];
}

/** secondary-email-verify — needs the candidate email to consume OTP against. */
export async function findActivePendingSecondaryEmailById(
  sql: postgres.Sql,
  id: string,
): Promise<{ id: string; secondary_email: string | null } | undefined> {
  const rows = await sql<{ id: string; secondary_email: string | null }[]>`
    SELECT id, secondary_email
    FROM signup_pending
    WHERE id = ${id} AND expires_at > NOW()
  `;
  return rows[0];
}

/** siret — needs the SIREN + the cached prefilled bundle to resolve the
 *  chosen establishment without a second INSEE call. */
export async function findActivePendingSiretContextById(
  sql: postgres.Sql,
  id: string,
): Promise<
  | {
      id: string;
      siren: string | null;
      customer_data_prefilled: Record<string, unknown> | null;
      expires_at: Date;
    }
  | undefined
> {
  const rows = await sql<
    {
      id: string;
      siren: string | null;
      customer_data_prefilled: Record<string, unknown> | null;
      expires_at: Date;
    }[]
  >`
    SELECT id, siren, customer_data_prefilled, expires_at
    FROM signup_pending
    WHERE id = ${id} AND expires_at > NOW()
  `;
  return rows[0];
}

// ─────────────────────────────────────────────────────────────────────────
// INSERT / DELETE
// ─────────────────────────────────────────────────────────────────────────

/** Signup — anti-énumération applies:
 *  - non-decoy: dedupe ghost rows for the same email (multi-tab retry).
 *  - decoy: never dedupe; row is purely an audit / anti-enumeration breadcrumb.
 *  Caller decides which behavior to invoke. */
export async function deletePendingByEmailNonDecoy(
  sql: postgres.Sql,
  email: string,
): Promise<void> {
  await sql`
    DELETE FROM signup_pending
    WHERE email = ${email} AND is_decoy = FALSE
  `;
}

export interface InsertPendingArgs {
  email: string;
  passwordHash: string;
  isDecoy: boolean;
}

export async function insertPending(
  sql: postgres.Sql,
  args: InsertPendingArgs,
): Promise<{ id: string; current_step: string }> {
  const rows = await sql<{ id: string; current_step: string }[]>`
    INSERT INTO signup_pending (email, password_hash, terms_accepted_at, is_decoy)
    VALUES (${args.email}, ${args.passwordHash}, NOW(), ${args.isDecoy})
    RETURNING id, current_step
  `;
  const r = rows[0];
  if (r === undefined) throw new Error("signup_pending insert failed");
  return r;
}

/** Used inside `finalizePhase1` (transaction) and the decoy-blocked
 *  silent delete. Single-id DELETE. */
export async function deletePendingById(sql: postgres.Sql, id: string): Promise<void> {
  await sql`DELETE FROM signup_pending WHERE id = ${id}`;
}

/** Hourly cleanup job (T-CL-03 sprint-03) — drops every row whose TTL
 *  (`expires_at`) is past, decoy or not. ON DELETE CASCADE on
 *  `otp_codes.signup_pending_id` ripples through automatically.
 *  Returns the row count for structured logging. */
export async function deletePendingExpired(sql: postgres.Sql): Promise<number> {
  const res = await sql`DELETE FROM signup_pending WHERE expires_at < NOW()`;
  return res.count;
}

// ─────────────────────────────────────────────────────────────────────────
// UPDATE — phase1 progression markers
// ─────────────────────────────────────────────────────────────────────────

/** /auth/phase1/siren — persist the SIREN + prefilled INSEE bundle, advance
 *  the step. */
export async function markPendingSirenChosen(
  sql: postgres.Sql,
  id: string,
  args: { siren: string; prefilled: postgres.JSONValue },
): Promise<void> {
  await sql`
    UPDATE signup_pending
    SET siren = ${args.siren},
        customer_data_prefilled = ${sql.json(args.prefilled)},
        current_step = ${"siret"}
    WHERE id = ${id}
  `;
}

/** /auth/phase1/siret — store the chosen SIRET + merged prefilled bundle
 *  (with address + optional manual legal_name override + is_manual flag). */
export async function markPendingSiretChosen(
  sql: postgres.Sql,
  id: string,
  args: { siret: string | null; prefilled: postgres.JSONValue },
): Promise<void> {
  await sql`
    UPDATE signup_pending
    SET siret = ${args.siret},
        customer_data_prefilled = ${sql.json(args.prefilled)},
        current_step = ${"email_verify"}
    WHERE id = ${id}
  `;
}

/** /auth/phase1/email/verify — magic-link consume → mark verified + advance. */
export async function markPendingEmailVerified(sql: postgres.Sql, id: string): Promise<void> {
  await sql`
    UPDATE signup_pending
    SET email_verified_at = NOW(),
        current_step = ${"secondary_email"}
    WHERE id = ${id}
  `;
}

/** /auth/phase1/secondary-email/set — store candidate, reset prior
 *  verification (in case the user retries with a different email). */
export async function markPendingSecondaryEmailSet(
  sql: postgres.Sql,
  id: string,
  email: string,
): Promise<void> {
  await sql`
    UPDATE signup_pending
    SET secondary_email = ${email},
        secondary_email_verified_at = NULL,
        current_step = ${"secondary_email"}
    WHERE id = ${id}
  `;
}

/** /auth/phase1/secondary-email/verify — OTP consumed → mark verified + advance. */
export async function markPendingSecondaryEmailVerified(
  sql: postgres.Sql,
  id: string,
): Promise<void> {
  await sql`
    UPDATE signup_pending
    SET secondary_email_verified_at = NOW(),
        current_step = ${"mfa_choice"}
    WHERE id = ${id}
  `;
}

/** /auth/phase1/mfa/choose (totp) — store encrypted secret + mode + advance. */
export async function markPendingMfaChoiceTotp(
  sql: postgres.Sql,
  id: string,
  ciphertext: Buffer,
): Promise<void> {
  await sql`
    UPDATE signup_pending
    SET mfa_mode_choice = ${"totp"},
        mfa_secret_pending = ${ciphertext},
        current_step = ${"mfa_setup"}
    WHERE id = ${id}
  `;
}

/** /auth/phase1/mfa/choose (email) — clear any pending secret + advance. */
export async function markPendingMfaChoiceEmail(sql: postgres.Sql, id: string): Promise<void> {
  await sql`
    UPDATE signup_pending
    SET mfa_mode_choice = ${"email"},
        mfa_secret_pending = NULL,
        current_step = ${"mfa_setup"}
    WHERE id = ${id}
  `;
}

/** /auth/phase1/mfa/verify — code accepted → store hashed recovery codes
 *  + completion timestamp + advance to recovery_codes step. */
export async function markPendingMfaSetupCompleted(
  sql: postgres.Sql,
  id: string,
  recoveryCodesHashed: string[],
): Promise<void> {
  await sql`
    UPDATE signup_pending
    SET mfa_setup_completed_at = NOW(),
        recovery_codes_pending = ${recoveryCodesHashed},
        current_step = ${"recovery_codes"}
    WHERE id = ${id}
  `;
}

/** /auth/phase1/recovery-codes/ack — set the ack timestamp before
 *  invoking finalizePhase1. The guarded WHERE prevents a double ack
 *  when the user hits the route twice (network retry). */
export async function markPendingRecoveryCodesAcked(sql: postgres.Sql, id: string): Promise<void> {
  await sql`
    UPDATE signup_pending
    SET recovery_codes_acked_at = NOW()
    WHERE id = ${id}
      AND recovery_codes_pending IS NOT NULL
      AND recovery_codes_acked_at IS NULL
  `;
}
