import type postgres from "postgres";

import type { ExportFilters, ExportScope, ExportStatus } from "@factur-e/shared-schemas";

/**
 * `export_requests` repository — T-CL-EXPORT-ZIP-RETENTION sprint-06 L12.
 * Cf. migration `20260527T132146_create_export_requests.sql`.
 *
 * Convention T-CL-01 :
 *  - lectures user-facing filtrent `customer_id` (anti-leak inter-tenant →
 *    `findExportRequestByIdAndCustomer` retourne undefined, route 404).
 *  - `findExportRequestById` (global) réservé au worker pgboss.
 *  - les rows ne sont JAMAIS supprimées (purge = `status='purged'` + file_key
 *    NULL pour auditabilité RGPD, RET-6).
 */

export interface ExportRequestRow {
  id: string;
  customer_id: string;
  requested_by_user_id: string;
  scope: ExportScope;
  filters: ExportFilters;
  invoice_ids: string[];
  invoice_count: number;
  status: ExportStatus;
  file_key: string | null;
  file_size_bytes: number | null;
  purge_at: Date;
  reminder_sent_at: Date | null;
  error_message: string | null;
  correlation_id: string;
  created_at: Date;
  updated_at: Date;
}

const COLS = `
  id, customer_id, requested_by_user_id, scope, filters, invoice_ids,
  invoice_count, status, file_key, file_size_bytes, purge_at,
  reminder_sent_at, error_message, correlation_id, created_at, updated_at
`;

// ─────────────────────────────────────────────────────────────────────
// INSERT
// ─────────────────────────────────────────────────────────────────────

export interface InsertExportRequestInput {
  customer_id: string;
  requested_by_user_id: string;
  scope: ExportScope;
  filters: ExportFilters;
  invoice_ids: string[];
  invoice_count: number;
}

/** Crée la demande en `pending` + `purge_at = NOW() + 6 mois` (RGPD strict
 *  non configurable, RET-6). Retourne la row (id + correlation_id). */
export async function insertExportRequest(
  sql: postgres.Sql,
  input: InsertExportRequestInput,
): Promise<ExportRequestRow> {
  const rows = await sql<ExportRequestRow[]>`
    INSERT INTO export_requests (
      customer_id, requested_by_user_id, scope, filters,
      invoice_ids, invoice_count, purge_at
    ) VALUES (
      ${input.customer_id},
      ${input.requested_by_user_id},
      ${input.scope},
      ${sql.json(input.filters)},
      ${input.invoice_ids}::uuid[],
      ${input.invoice_count},
      NOW() + INTERVAL '6 months'
    )
    RETURNING ${sql.unsafe(COLS)}
  `;
  const row = rows[0];
  if (row === undefined) throw new Error("insertExportRequest returned no row");
  return row;
}

// ─────────────────────────────────────────────────────────────────────
// SELECT
// ─────────────────────────────────────────────────────────────────────

/** Lookup global — réservé worker pgboss (pas de filtre customer). */
export async function findExportRequestById(
  sql: postgres.Sql,
  id: string,
): Promise<ExportRequestRow | undefined> {
  const rows = await sql<ExportRequestRow[]>`
    SELECT ${sql.unsafe(COLS)} FROM export_requests WHERE id = ${id}
  `;
  return rows[0];
}

/** Lookup inter-tenant safe (undefined si autre customer → route 404). */
export async function findExportRequestByIdAndCustomer(
  sql: postgres.Sql,
  id: string,
  customerId: string,
): Promise<ExportRequestRow | undefined> {
  const rows = await sql<ExportRequestRow[]>`
    SELECT ${sql.unsafe(COLS)}
    FROM export_requests
    WHERE id = ${id} AND customer_id = ${customerId}
  `;
  return rows[0];
}

/** Liste paginée Mes exports — le plus récent d'abord. */
export async function listExportRequestsByCustomer(
  sql: postgres.Sql,
  customerId: string,
  args: { limit: number; offset: number },
): Promise<ExportRequestRow[]> {
  return sql<ExportRequestRow[]>`
    SELECT ${sql.unsafe(COLS)}
    FROM export_requests
    WHERE customer_id = ${customerId}
    ORDER BY created_at DESC
    LIMIT ${args.limit} OFFSET ${args.offset}
  `;
}

export async function countExportRequestsByCustomer(
  sql: postgres.Sql,
  customerId: string,
): Promise<number> {
  const rows = await sql<{ count: string }[]>`
    SELECT COUNT(*)::text AS count
    FROM export_requests WHERE customer_id = ${customerId}
  `;
  return Number(rows[0]?.count ?? "0");
}

/** Exports expirés à purger (job `export-zip-purge`). */
export async function findCompletedExportsToPurge(sql: postgres.Sql): Promise<ExportRequestRow[]> {
  return sql<ExportRequestRow[]>`
    SELECT ${sql.unsafe(COLS)}
    FROM export_requests
    WHERE status = 'completed' AND purge_at <= NOW()
  `;
}

/** Exports approchant la purge (≤ 30j) sans rappel envoyé (job rappel J-30). */
export async function findExportsForReminder(sql: postgres.Sql): Promise<ExportRequestRow[]> {
  return sql<ExportRequestRow[]>`
    SELECT ${sql.unsafe(COLS)}
    FROM export_requests
    WHERE status = 'completed'
      AND reminder_sent_at IS NULL
      AND purge_at <= NOW() + INTERVAL '30 days'
    ORDER BY customer_id, purge_at ASC
  `;
}

// ─────────────────────────────────────────────────────────────────────
// UPDATE (transitions de statut)
// ─────────────────────────────────────────────────────────────────────

export async function markExportProcessing(sql: postgres.Sql, id: string): Promise<void> {
  await sql`
    UPDATE export_requests
    SET status = 'processing', updated_at = NOW()
    WHERE id = ${id}
  `;
}

export async function markExportCompleted(
  sql: postgres.Sql,
  args: { id: string; fileKey: string; fileSizeBytes: number },
): Promise<void> {
  await sql`
    UPDATE export_requests
    SET status = 'completed', file_key = ${args.fileKey},
        file_size_bytes = ${args.fileSizeBytes}, updated_at = NOW()
    WHERE id = ${args.id}
  `;
}

export async function markExportFailed(
  sql: postgres.Sql,
  args: { id: string; errorMessage: string },
): Promise<void> {
  await sql`
    UPDATE export_requests
    SET status = 'failed', error_message = ${args.errorMessage.slice(0, 1000)},
        updated_at = NOW()
    WHERE id = ${args.id}
  `;
}

/** Purge : statut `purged` + file_key/size NULL. Row PRÉSERVÉE (RET-6). */
export async function markExportPurged(sql: postgres.Sql, id: string): Promise<void> {
  await sql`
    UPDATE export_requests
    SET status = 'purged', file_key = NULL, file_size_bytes = NULL,
        updated_at = NOW()
    WHERE id = ${id}
  `;
}

export async function markExportReminderSent(sql: postgres.Sql, id: string): Promise<void> {
  await sql`
    UPDATE export_requests
    SET reminder_sent_at = NOW(), updated_at = NOW()
    WHERE id = ${id}
  `;
}
