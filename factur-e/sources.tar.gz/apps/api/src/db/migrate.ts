import { readdir, readFile } from "node:fs/promises";
import { join } from "node:path";
import postgres from "postgres";

/**
 * Sequential SQL migration runner per CLAUDE.md §7.
 *
 * - Acquires Postgres advisory lock 4242 to serialize concurrent runners
 *   (multi-replica deploys, parallel CI jobs, dev + worker race).
 * - Idempotently ensures `_migrations_applied` exists.
 * - Lists `*.sql` files in the migrations dir, sorted alphabetically (= UTC
 *   timestamp prefix → chronological).
 * - Applies missing migrations one by one, each in its own transaction with
 *   the corresponding `_migrations_applied` insert. Rollback on failure
 *   keeps the file unmarked, so the next run retries it.
 */

export interface MigrateOptions {
  /** Postgres connection string (e.g. `postgresql://user:pass@host:5432/db`). */
  readonly connectionString: string;
  /** Absolute path to the directory holding `*.sql` migration files. */
  readonly migrationsDir: string;
  /** Optional logger; defaults to no-op. */
  readonly logger?: { info: (msg: string) => void };
}

export interface MigrateResult {
  readonly applied: readonly string[];
}

const ADVISORY_LOCK_KEY = 4242;

export async function runMigrations(opts: MigrateOptions): Promise<MigrateResult> {
  const log = opts.logger ?? { info: () => undefined };
  const sql = postgres(opts.connectionString, { max: 1, onnotice: () => undefined });
  const applied: string[] = [];

  try {
    await sql`SELECT pg_advisory_lock(${ADVISORY_LOCK_KEY})`;

    await sql`
      CREATE TABLE IF NOT EXISTS _migrations_applied (
        name        TEXT        PRIMARY KEY,
        applied_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
      )
    `;

    const files = (await readdir(opts.migrationsDir)).filter((f) => f.endsWith(".sql")).sort();

    const rows = await sql<{ name: string }[]>`SELECT name FROM _migrations_applied`;
    const alreadyApplied = new Set(rows.map((r) => r.name));

    for (const file of files) {
      if (alreadyApplied.has(file)) continue;

      const content = await readFile(join(opts.migrationsDir, file), "utf8");

      await sql.begin(async (tx) => {
        await tx.unsafe(content);
        await tx`INSERT INTO _migrations_applied (name) VALUES (${file})`;
      });

      log.info(`[migrate] applied ${file}`);
      applied.push(file);
    }

    return { applied };
  } finally {
    try {
      await sql`SELECT pg_advisory_unlock(${ADVISORY_LOCK_KEY})`;
    } finally {
      await sql.end();
    }
  }
}
