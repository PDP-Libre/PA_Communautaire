import type { FastifyInstance } from "fastify";
import fp from "fastify-plugin";
import postgres from "postgres";

declare module "fastify" {
  interface FastifyInstance {
    sql: postgres.Sql;
    sqlRead: postgres.Sql;
  }
}

export interface DbPluginOptions {
  connectionString: string;
  /**
   * Optional read replica connection string. If absent, empty, or equal to
   * `connectionString`, `app.sqlRead` aliases `app.sql` (single pool — dev / MVP).
   *
   * Convention (cf. T-CL-01 sprint-03 + retro sprint-02 §"Décoration multi-clients") :
   *  - `app.sql`     → writes / transactions
   *  - `app.sqlRead` → reads pures
   *
   * Provisioning a read replica V2 (PRD §7.4) means setting `POSTGRES_READ_URL`.
   * No route rewrite needed thanks to the convention.
   */
  readConnectionString?: string;
}

/**
 * Fastify plugin exposing the shared `postgres.js` clients :
 *  - `app.sql`     — primary pool, used for writes and transactions
 *  - `app.sqlRead` — read pool, used for pure reads (alias of `app.sql` in MVP)
 *
 * Both pools are closed on Fastify shutdown so test suites that
 * build / listen / close don't leak handles.
 */
function dbPluginInner(app: FastifyInstance, opts: DbPluginOptions): void {
  const writeSql = postgres(opts.connectionString, {
    max: 10,
    onnotice: () => undefined,
  });

  const readUrl = opts.readConnectionString;
  const useSeparateReadPool =
    readUrl !== undefined && readUrl !== "" && readUrl !== opts.connectionString;
  const readSql = useSeparateReadPool
    ? postgres(readUrl, { max: 20, onnotice: () => undefined })
    : writeSql;

  app.decorate("sql", writeSql);
  app.decorate("sqlRead", readSql);

  app.addHook("onClose", async () => {
    await writeSql.end();
    if (readSql !== writeSql) {
      await readSql.end();
    }
  });
}

export const dbPlugin = fp(dbPluginInner, { name: "db-plugin" });
