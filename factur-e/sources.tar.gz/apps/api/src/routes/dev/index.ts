import { createHash, randomUUID } from "node:crypto";

import type { FastifyInstance, FastifyReply } from "fastify";
import type postgres from "postgres";

import {
  allFixtures,
  FX_ORIGIN_INVOICE_ID,
  getFixture,
  getReceptionFixture,
} from "@factur-e/factur-x-fixtures";
import { mapSuperPDPStatusCode } from "@factur-e/pa-adapter";
import { MockPADriver } from "@factur-e/shared-fakes";

import { customerRowFromFixtureSeller } from "../../dev-support/fixture-seller.js";
import {
  downloadResultForFixture,
  paInvoiceIdForFixture,
  seedReceivedRowFromFixture,
} from "../../dev-support/reception-fixtures.js";

import { hashPassword } from "../../auth/argon2.js";
import { writeAuthAudit } from "../../auth/audit.js";
import { setRefreshSessionCookie } from "../../auth/cookies.js";
import { decrypt, encrypt } from "../../auth/encryption.js";
import { signAccessToken, signRefreshToken } from "../../auth/jwt.js";
import { currentTotpCode } from "../../auth/totp.js";
import {
  insertCdarEvent,
  updateInvoiceStatusCurrent as updateInvoiceStatusCurrentViaCdarRepo,
} from "../../db/repos/cdar_events.js";
import * as customersRepo from "../../db/repos/customers.js";
import * as paRepo from "../../db/repos/pa_connections.js";
import { deleteCursor, type PollingDirection } from "../../db/repos/pa_polling_state.js";
import { insertSession } from "../../db/tx.js";
import * as usersRepo from "../../db/repos/users.js";
import { MockEmailSender } from "../../email/sender.js";
import { PresetInseeClient } from "../../onboarding/insee-plugin.js";
import { paSecretRef } from "../../pa/secret-ref.js";
import { resolveActivePaConfig } from "../../pa/registry.js";

/**
 * Dev-only HTTP surface used by Playwright E2E tests + ad-hoc curl-driven
 * debugging. Registered ONLY when `NODE_ENV !== "production"` — see
 * `server.ts`. The routes never ship in a deployed build.
 *
 * Sprint-02 (T-CL-10) provided 3 endpoints (`last-email`, `insee/preset`,
 * `reset`). Sprint-03 (T-CL-16) extends with PA / directory / products /
 * TOTP helpers to cover the 4 new E2E parcours (PA OAuth, annuaire,
 * catalogue articles + LineItemPicker, invitation 5 étapes TOTP-only).
 *
 * Anti-misuse: each handler 404s if the relevant adapter isn't the mock
 * version (e.g. someone wired Scaleway TEM by mistake — we won't expose
 * "last email" because it'd be empty/misleading anyway). The PA / directory
 * helpers similarly 409 if `app.paDriver` isn't a `MockPADriver`.
 */
export function registerDevRoutes(app: FastifyInstance): void {
  // ───────────────────────────────────────────────────────────────────
  // Sprint-02 — email / INSEE / reset
  // ───────────────────────────────────────────────────────────────────

  app.get<{ Querystring: { to?: string } }>("/__dev/last-email", async (req, reply) => {
    const sender = app.email;
    if (!(sender instanceof MockEmailSender)) {
      return reply.code(404).send({ message: "Email adapter is not Mock — endpoint disabled." });
    }
    const to = req.query.to;
    if (typeof to !== "string" || to.length === 0) {
      return reply.code(400).send({ message: "Missing ?to=email" });
    }
    const item = sender.lastSentTo(to.toLowerCase());
    if (item === undefined) {
      return reply.code(404).send({ message: "No mail captured for this recipient yet." });
    }
    return reply.code(200).send(item);
  });

  // Config PA active résolue au boot (T-CL-REGISTRE-AFNORDRIVER follow-up) —
  // consommée par le préflight du harness pour échouer dur si `--pa` ne
  // correspond pas à la config bootée du serveur (anti-faux-vert : l'env
  // `PA_ACTIVE_CONFIG` va sur l'app, pas sur le harness). `driver` = nom de
  // classe réel (détecte Stub/Mock no-creds).
  app.get("/__dev/pa/active-config", async (_req, reply) => {
    const active = resolveActivePaConfig();
    return reply.code(200).send({
      paId: active.paId,
      family: active.family,
      driver: app.paDriver.constructor.name,
    });
  });

  app.post<{
    Body: { siren?: unknown; result?: unknown };
  }>("/__dev/insee/preset", async (req, reply) => {
    const insee = app.insee;
    if (!(insee instanceof PresetInseeClient)) {
      return reply.code(404).send({ message: "INSEE adapter is not Preset — endpoint disabled." });
    }
    const siren = typeof req.body.siren === "string" ? req.body.siren : "";
    if (!/^\d{9}$/.test(siren)) {
      return reply.code(400).send({ message: "siren must be a 9-digit string." });
    }
    if (typeof req.body.result !== "object" || req.body.result === null) {
      return reply.code(400).send({ message: "result must be a SirenLookupResult object." });
    }
    // We trust the test driver to send the correct shape — the consumer
    // (`resolveSiren` → `lookupSiren`) will branch on `kind` and surface
    // user-facing errors if the shape is wrong. Strictly validating here
    // would duplicate the schema, which is overkill for a dev endpoint.
    insee.setPreset(siren, req.body.result as never);
    return reply.code(204).send();
  });

  app.post("/__dev/reset", async (_req, reply) => {
    if (process.env.NODE_ENV === "production") {
      return reply.code(404).send({ message: "Disabled in production." });
    }
    // T-CL-16 sprint-03 — extended to TRUNCATE the sprint-03 tables so
    // E2E specs can re-run from a clean slate (PA / directory / products).
    // `customers` cascades to most tables but explicit listing makes the
    // wipe surface obvious + protects from a future column type change
    // that would silently disable cascade.
    await app.sql`
      TRUNCATE TABLE
        auth_audit, sessions, otp_codes, signup_pending, invitations,
        pa_connections, directory_cache, buyer_address_preferences,
        products, product_categories,
        users, customers, insee_cache
      RESTART IDENTITY CASCADE
    `;
    if (app.email instanceof MockEmailSender) app.email.reset();
    if (app.insee instanceof PresetInseeClient) app.insee.reset();
    if (app.paDriver instanceof MockPADriver) app.paDriver.reset();
    return reply.code(204).send();
  });

  // ───────────────────────────────────────────────────────────────────
  // T-CL-16 sprint-03 — PA connections
  // ───────────────────────────────────────────────────────────────────

  app.post<{
    Body: { user_email?: unknown; identity_status?: unknown; pa_user_id?: unknown };
  }>("/__dev/pa/seed", async (req, reply) => {
    const email = parseEmail(req.body.user_email);
    if (email === null) {
      return reply.code(400).send({ message: "user_email must be a string." });
    }
    const status = parseIdentityStatus(req.body.identity_status);
    if (status === null) {
      return reply
        .code(400)
        .send({ message: "identity_status must be 'verified' | 'needs_review' | 'rejected'." });
    }
    const paUserId =
      typeof req.body.pa_user_id === "string" && req.body.pa_user_id !== ""
        ? req.body.pa_user_id
        : "pa-user-e2e";

    const userRow = await findUserAndCustomer(app, email);
    if (userRow === undefined) {
      return reply.code(404).send({ message: `No user found for email ${email}.` });
    }

    // Court-circuite l'OAuth flow : INSERT pa_connections + put secret_store
    // mock bundle + audit pa_connection_completed. Si `identity_status ===
    // 'verified'`, flip profile_unverified comme le ferait callback OAuth
    // sur le happy path (ADR-007).
    const secretRef = paSecretRef({ customerId: userRow.customer_id });
    await app.secrets.put(secretRef, {
      accessToken: `e2e-access-${Date.now().toString()}`,
      refreshToken: `e2e-refresh-${Date.now().toString()}`,
      accessExpiresAt: new Date(Date.now() + 1800 * 1000).toISOString(),
    });
    const { id: connectionId } = await paRepo.insertPaConnection(app.sql, {
      customerId: userRow.customer_id,
      paUserId,
      secretRef,
      userIdentityStatus: status,
      companyStatus: status,
    });
    await writeAuthAudit(app.sql, {
      event_type: "pa_connection_completed",
      success: true,
      user_id: userRow.id,
      customer_id: userRow.customer_id,
      metadata: {
        user_identity_verification_status: status,
        company_verification_status: status,
        source: "dev_seed",
      },
    });
    if (status === "verified") {
      const cleared = await customersRepo.markCustomerProfileVerified(app.sql, userRow.customer_id);
      if (cleared > 0) {
        await writeAuthAudit(app.sql, {
          event_type: "pa_profile_verified",
          success: true,
          customer_id: userRow.customer_id,
          metadata: { source: "dev_seed" },
        });
      }
    }
    return reply.code(200).send({ id: connectionId, identity_status: status });
  });

  app.post<{
    Body: { user_email?: unknown; identity_status?: unknown };
  }>("/__dev/pa/status", async (req, reply) => {
    const email = parseEmail(req.body.user_email);
    if (email === null) {
      return reply.code(400).send({ message: "user_email must be a string." });
    }
    const status = parseIdentityStatus(req.body.identity_status);
    if (status === null) {
      return reply
        .code(400)
        .send({ message: "identity_status must be 'verified' | 'needs_review' | 'rejected'." });
    }
    const userRow = await findUserAndCustomer(app, email);
    if (userRow === undefined) {
      return reply.code(404).send({ message: `No user found for email ${email}.` });
    }
    const conn = await paRepo.findActivePaConnectionStatusByCustomerId(
      app.sql,
      userRow.customer_id,
    );
    if (conn === undefined) {
      return reply.code(404).send({ message: "No active PA connection for this user." });
    }
    const from = {
      user: conn.user_identity_verification_status,
      company: conn.company_verification_status,
    };
    await paRepo.markPaConnectionIdentityStatuses(app.sql, conn.id, {
      user: status,
      company: status,
    });
    await writeAuthAudit(app.sql, {
      event_type: "pa_identity_status_changed",
      success: true,
      customer_id: userRow.customer_id,
      metadata: { from, to: { user: status, company: status }, source: "dev_status" },
    });
    if (status === "verified") {
      const cleared = await customersRepo.markCustomerProfileVerified(app.sql, userRow.customer_id);
      if (cleared > 0) {
        await writeAuthAudit(app.sql, {
          event_type: "pa_profile_verified",
          success: true,
          customer_id: userRow.customer_id,
          metadata: { source: "dev_status" },
        });
      }
    }
    return reply.code(200).send({ identity_status: status });
  });

  app.post<{
    Body: { user_email?: unknown };
  }>("/__dev/pa/reset", async (req, reply) => {
    const email = parseEmail(req.body.user_email);
    if (email === null) {
      return reply.code(400).send({ message: "user_email must be a string." });
    }
    const userRow = await findUserAndCustomer(app, email);
    if (userRow === undefined) {
      return reply.code(404).send({ message: `No user found for email ${email}.` });
    }
    // Hard-delete pa_connections rows for this customer + drop bundle from
    // secret_store. Hard rather than soft-delete because tests want a true
    // clean slate (partial UNIQUE constraint also accepts soft-deleted
    // rows, so a fresh seed after `pa/reset` doesn't conflict either way).
    await app.sql`DELETE FROM pa_connections WHERE customer_id = ${userRow.customer_id}`;
    const secretRef = paSecretRef({ customerId: userRow.customer_id });
    await app.secrets.delete(secretRef);
    return reply.code(204).send();
  });

  // ───────────────────────────────────────────────────────────────────
  // T-CL-W5 EMIT-FIXS — Reset curseur de polling (remplace la procédure
  // SQL manuelle du hotfix R1 ZG-1). DELETE scopé `customer_id` (invariant
  // tenant) sur la direction demandée → re-poll idempotent rattrape.
  // ───────────────────────────────────────────────────────────────────

  app.post<{
    Body: { user_email?: unknown; direction?: unknown };
  }>("/__dev/pa/reset-cursor", async (req, reply) => {
    if (process.env.NODE_ENV === "production") {
      return reply.code(404).send({ message: "Disabled in production." });
    }
    const email = parseEmail(req.body.user_email);
    if (email === null) {
      return reply.code(400).send({ message: "user_email must be a string." });
    }
    const direction = parsePollingDirection(req.body.direction);
    if (direction === null) {
      return reply.code(400).send({ message: "direction must be 'in' | 'out'." });
    }
    const userRow = await findUserAndCustomer(app, email);
    if (userRow === undefined) {
      return reply.code(404).send({ message: `No user found for email ${email}.` });
    }
    const deleted = await deleteCursor(app.sql, userRow.customer_id, direction);
    return reply.code(200).send({ deleted, direction });
  });

  // ───────────────────────────────────────────────────────────────────
  // T-CL-16 sprint-03 — Annuaire
  // ───────────────────────────────────────────────────────────────────

  app.post<{
    Body: { siren?: unknown; result?: unknown };
  }>("/__dev/directory/preset", async (req, reply) => {
    if (!(app.paDriver instanceof MockPADriver)) {
      return reply
        .code(409)
        .send({ message: "paDriver is not Mock — set PA_ADAPTER=mock to enable." });
    }
    const siren = typeof req.body.siren === "string" ? req.body.siren : "";
    if (!/^\d{9}$/.test(siren)) {
      return reply.code(400).send({ message: "siren must be a 9-digit string." });
    }
    if (typeof req.body.result !== "object" || req.body.result === null) {
      return reply.code(400).send({ message: "result must be a DirectorySearchResult object." });
    }
    app.paDriver.setSearchSirenOutcome(siren, req.body.result as never);
    return reply.code(204).send();
  });

  // ───────────────────────────────────────────────────────────────────
  // T-CL-16 sprint-03 — Products catalogue
  // ───────────────────────────────────────────────────────────────────

  app.post<{
    Body: { user_email?: unknown; products?: unknown };
  }>("/__dev/products/seed", async (req, reply) => {
    const email = parseEmail(req.body.user_email);
    if (email === null) {
      return reply.code(400).send({ message: "user_email must be a string." });
    }
    if (!Array.isArray(req.body.products)) {
      return reply.code(400).send({ message: "products must be an array." });
    }
    const userRow = await findUserAndCustomer(app, email);
    if (userRow === undefined) {
      return reply.code(404).send({ message: `No user found for email ${email}.` });
    }
    interface SeedProductInput {
      label: string;
      description?: string | null;
      internal_code?: string | null;
      unit_price_ht: string;
      unit?: string;
      vat_category: string;
      vat_rate?: string | null;
    }
    const products = req.body.products as SeedProductInput[];
    const inserted: string[] = [];
    for (const p of products) {
      const rows = await app.sql<{ id: string }[]>`
        INSERT INTO products (
          customer_id, label, description, internal_code,
          unit_price_ht, unit, vat_category, vat_rate
        ) VALUES (
          ${userRow.customer_id},
          ${p.label},
          ${p.description ?? null},
          ${p.internal_code ?? null},
          ${p.unit_price_ht},
          ${p.unit ?? "unité"},
          ${p.vat_category},
          ${p.vat_rate ?? null}
        )
        RETURNING id
      `;
      const r = rows[0];
      if (r !== undefined) inserted.push(r.id);
    }
    return reply.code(200).send({ inserted });
  });

  // ───────────────────────────────────────────────────────────────────
  // T-CL-16 sprint-03 — TOTP helper (lift [DEBT] retro sprint-02 spec #2)
  // ───────────────────────────────────────────────────────────────────

  app.post<{
    Body: { user_email?: unknown };
  }>("/__dev/totp-now", async (req, reply) => {
    const email = parseEmail(req.body.user_email);
    if (email === null) {
      return reply.code(400).send({ message: "user_email must be a string." });
    }
    // Read mfa_secret directly — the auth repo's projections don't expose
    // raw bytes, but this is a dev-only path so we inline the query.
    const rows = await app.sql<{ mfa_secret: Buffer | null }[]>`
      SELECT mfa_secret FROM users WHERE email = ${email} AND deleted_at IS NULL
    `;
    const r = rows[0];
    if (r === undefined) {
      return reply.code(404).send({ message: `No user found for email ${email}.` });
    }
    if (r.mfa_secret === null) {
      return reply.code(409).send({ message: "User has no mfa_secret set yet." });
    }
    const secret = decrypt(r.mfa_secret);
    const code = currentTotpCode(secret);
    return reply.code(200).send({ code });
  });

  // ───────────────────────────────────────────────────────────────────
  // T-CL-16 sprint-03 — Bridge fakeSuperPdp.simulateUserConsent (Bruno c)
  //
  // Posée pour symétrie avec l'ajustement (c) du prompt T-CL-16. Le code
  // émis n'est consommable que si `fakeSuperPdp` tourne en sidecar
  // (`/oauth2/token` accepte le code dans le même process). Sans sidecar,
  // le call OAuth réel (driver SuperPDP → SuperPDP sandbox) rejettera. Le
  // wiring sidecar est différé sprint-04+ (cf. trace T-CL-16 §"décisions").
  // ───────────────────────────────────────────────────────────────────

  app.post<{
    Body: { state?: unknown; scenario?: unknown };
  }>("/__fake/superpdp/consent", async (req, reply) => {
    if (process.env.NODE_ENV === "production") {
      return reply.code(404).send({ message: "Disabled in production." });
    }
    const state = typeof req.body.state === "string" ? req.body.state : "";
    if (state === "") {
      return reply.code(400).send({ message: "state must be a non-empty string." });
    }
    const scenario = req.body.scenario === "consent_denied" ? "consent_denied" : "consent_granted";
    if (scenario === "consent_denied") {
      return reply.code(200).send({ error: "access_denied", state });
    }
    const code = `c-${state.slice(0, 8)}-${Date.now().toString()}`;
    return reply.code(200).send({ code, state });
  });

  // ───────────────────────────────────────────────────────────────────
  // T-CL-TEST-E2E sprint-04 — Émission / cycle de vie helpers
  // ───────────────────────────────────────────────────────────────────

  /** Seed un brouillon de facture (`invoice_drafts`) ou une facture
   *  émise (`invoices` + event `api:uploaded` initial) côté BDD. Skip
   *  le pipeline complet (factur-x-builder + driver.submitInvoice) pour
   *  rester rapide et déterministe — le pipeline réel reste couvert par
   *  T-CL-TEST-INTEGRATION (393 tests apps/api). Utilisé par parcours 2
   *  pour provisionner ≥ 2 factures émises (déclenche NewInvoiceStartModal)
   *  et parcours 3 pour préparer une facture émise dont on observe le
   *  cycle de vie SSE.
   *
   *  Body :
   *    - `user_email` (string, requis)
   *    - `emitted` (bool, default false) → si true : INSERT invoices +
   *      cdar_events initial `api:uploaded` ; sinon : INSERT invoice_drafts.
   *    - `buyer` (optionnel, override defaults pour brouillon).
   *    - `lines` (optionnel, future use — current ignored).
   *
   *  Réponse : `{ invoiceId? (uuid si emitted), draftId (uuid sinon) }`. */
  app.post<{
    Body: {
      user_email?: unknown;
      emitted?: unknown;
      buyer?: unknown;
      lines?: unknown;
      number?: unknown;
      fixtureId?: unknown;
    };
  }>("/__dev/invoice-drafts/seed", async (req, reply) => {
    const email = parseEmail(req.body.user_email);
    if (email === null) {
      return reply.code(400).send({ message: "user_email must be a string." });
    }
    const userRow = await findUserAndCustomer(app, email);
    if (userRow === undefined) {
      return reply.code(404).send({ message: `No user found for email ${email}.` });
    }

    // ── Levier 2 — seed nommé depuis le corpus de fixtures ───────────────
    // `{ fixtureId }` → brouillon dont le payload = `getFixture(id).form`, +
    // customer aligné sur `fixture.seller` (identités sandbox ADR-010 D6).
    // Chaînage BG-3 : pour fx-381/fx-384 (precedingInvoiceId =
    // FX_ORIGIN_INVOICE_ID), on crée d'abord l'origine fx-380-base-iban avec
    // cet id fixe pour que le lookup (pose 209 / encart lien) fonctionne.
    // Limite recette : l'origine porte un id GLOBAL fixe → mono-compte (le
    // premier seed réserve l'origine ; suffisant pour la recette T-BR BQ).
    if (typeof req.body.fixtureId === "string" && req.body.fixtureId !== "") {
      return seedFromFixture(app, reply, userRow.customer_id, req.body.fixtureId);
    }

    const emitted = req.body.emitted === true;

    if (!emitted) {
      // Brouillon — INSERT minimal dans invoice_drafts. Le payload reste
      // libre côté shape (cf. InvoiceFormDraftPayloadSchema passthrough).
      const payloadJson = app.sql.json({
        ui_mode: "base",
        document: { number: "F-2026-DRAFT", issueDate: new Date().toISOString().slice(0, 10) },
      });
      const emptyJson = app.sql.json({});
      const rows = await app.sql<{ id: string }[]>`
        INSERT INTO invoice_drafts (customer_id, payload, step_completed)
        VALUES (${userRow.customer_id}, ${payloadJson}, ${emptyJson})
        RETURNING id
      `;
      const draftId = rows[0]?.id;
      if (draftId === undefined) {
        return reply.code(500).send({ message: "Failed to seed invoice draft." });
      }
      return reply.code(200).send({ draftId });
    }

    // Facture émise — INSERT direct invoices + cdar_event initial.
    // Le numéro est calculé pour rester unique par customer (préfixe
    // `F-2026-SEED-<short-uuid>` pour éviter toute collision avec une
    // facture créée via le formulaire pendant le même test).
    const explicitNumber =
      typeof req.body.number === "string" && req.body.number !== "" ? req.body.number : null;
    const seedNumber = explicitNumber ?? `F-2026-SEED-${randomUUID().slice(0, 8)}`;
    const trackingId = randomUUID();
    const paInvoiceId = String(Math.floor(Date.now() / 1000) + Math.floor(Math.random() * 1000));
    const issueDate = new Date().toISOString().slice(0, 10);
    const submittedAt = new Date();
    const sha256Placeholder = createHash("sha256").update(`seed-${trackingId}`).digest("hex");

    const buyerRaw = req.body.buyer;
    const buyer =
      typeof buyerRaw === "object" && buyerRaw !== null
        ? (buyerRaw as { siren?: unknown; legalName?: unknown })
        : {};
    // Default Luhn-valide (cf. docs/guides/test-playwright.md §"Validation
    // Luhn"). Stocké uniquement en `payload_extended` jsonb, donc pas de
    // validation Zod côté insert — mais on garde Luhn-valide pour la
    // cohérence avec les helpers d'annuaire.
    const buyerSiren = typeof buyer.siren === "string" ? buyer.siren : "303174304";
    const buyerLegalName =
      typeof buyer.legalName === "string" ? buyer.legalName : "ACME BUYER E2E SAS";

    // payload_extended jsonb minimal — reproduit le shape stocké par
    // create.ts pour qu'un appel `GET /api/invoices/:id` reconstruit
    // ne crashe pas (le reconstructor parcourt buyer/lines/payment).
    const payloadExtendedJson = app.sql.json({
      buyer: { siren: buyerSiren, legalName: buyerLegalName },
      seed: true,
    });

    const inserted = await app.sql<{ id: string }[]>`
      INSERT INTO invoices (
        customer_id, number, issue_date, tracking_id,
        total_ht, total_vat, total_ttc,
        currency, processing_rule, type_code,
        pa_invoice_id, pa_provider, sha256, submitted_at, status_current,
        payload_extended
      ) VALUES (
        ${userRow.customer_id},
        ${seedNumber},
        ${issueDate},
        ${trackingId},
        ${"100.00"},
        ${"20.00"},
        ${"120.00"},
        ${"EUR"},
        ${"B2B"},
        ${"380"},
        ${paInvoiceId},
        ${"superpdp"},
        ${sha256Placeholder},
        ${submittedAt},
        ${"submitted"},
        ${payloadExtendedJson}
      )
      RETURNING id
    `;
    const invoiceId = inserted[0]?.id;
    if (invoiceId === undefined) {
      return reply.code(500).send({ message: "Failed to seed emitted invoice." });
    }

    // Event initial `api:uploaded` — équivalent à ce qu'insère
    // create.ts post-submit (source `synthetic` pour disambiguer).
    await insertCdarEvent(app.sql, {
      invoice_id: invoiceId,
      code: "api:uploaded",
      label: "Déposée",
      occurred_at: submittedAt,
      payload: { seed: true },
      source: "synthetic",
    });

    return reply.code(200).send({ invoiceId, paInvoiceId, number: seedNumber });
  });

  /** Injecte un event CDAR sur une facture émise existante. Body :
   *  `{ invoice_id, code (raw native ex 'fr:200'), occurred_at?,
   *  reason? { code, text } }`.
   *  Effet : INSERT idempotent `cdar_events` (source `synthetic`) +
   *  UPDATE `invoices.status_current` avec la valeur normalisée
   *  FacturEStatusCode.
   *
   *  Wiring T-CL-FIXTURES-RECV-WIRING (GAP-8) : le `STATUS_MAP` inline 5 codes
   *  est remplacé par `mapSuperPDPStatusCode` (table 43 codes) — fr:205/209/210
   *  désormais supportés (parcours acheteur / finding B). Convention motif V1
   *  (02-contrat-consommation.md §4.4) : `reason.code` → colonne `reason`
   *  (= `data.reason` SuperPDP) ; `reason.text` → `payload.data` (⚠ H-REASON-TEXT
   *  GAP-T2-1, à confirmer au smoke G1). */
  app.post<{
    Body: {
      invoice_id?: unknown;
      code?: unknown;
      occurred_at?: unknown;
      reason?: unknown;
    };
  }>("/__dev/cdar/inject", async (req, reply) => {
    const invoiceId = typeof req.body.invoice_id === "string" ? req.body.invoice_id : "";
    if (invoiceId === "") {
      return reply.code(400).send({ message: "invoice_id must be a non-empty string." });
    }
    const code = typeof req.body.code === "string" ? req.body.code : "";
    if (code === "") {
      return reply.code(400).send({ message: "code must be a non-empty string." });
    }
    const occurredAt =
      typeof req.body.occurred_at === "string" && req.body.occurred_at !== ""
        ? new Date(req.body.occurred_at)
        : new Date();
    if (Number.isNaN(occurredAt.getTime())) {
      return reply.code(400).send({ message: "occurred_at must be a valid ISO timestamp." });
    }

    const rawReason = req.body.reason;
    const reason =
      typeof rawReason === "object" && rawReason !== null && "code" in rawReason
        ? (rawReason as { code: unknown; text?: unknown })
        : null;
    const reasonCode = reason !== null && typeof reason.code === "string" ? reason.code : null;
    const reasonText =
      reason !== null && typeof reason.text === "string" && reason.text !== "" ? reason.text : null;

    const mappedStatus = mapSuperPDPStatusCode(code).status;

    const insertRes = await insertCdarEvent(app.sql, {
      invoice_id: invoiceId,
      code,
      label: code,
      occurred_at: occurredAt,
      payload: reasonText !== null ? { seed: true, data: reasonText } : { seed: true },
      reason: reasonCode,
      source: "synthetic",
    });
    if (insertRes.inserted) {
      await updateInvoiceStatusCurrentViaCdarRepo(app.sql, invoiceId, mappedStatus);
    }
    return reply.code(200).send({ inserted: insertRes.inserted, status: mappedStatus });
  });

  /** Seed nommé d'une facture REÇUE depuis le corpus réception (Levier 2,
   *  GAP-2). Body `{ user_email, fixtureId }`. DB-direct (PAS via worker) :
   *  déterministe, miroir du seed émission. Si `originFixtureId`, seede
   *  l'ORIGINE d'abord (idempotent) pour que le matching BT-25 fonctionne.
   *  Si `PA_ADAPTER=mock`, pré-configure `downloadInvoiceFile` avec le
   *  document (dérivé pour `kind:"emission"`, statique pour `kind:"xml"`)
   *  sinon la fiche (/pdf, /xml, parsedMetadata) reste vide (R2).
   *
   *  Limite V1 : le mock ne porte qu'UN download → configuré pour la fixture
   *  principale (pas l'origine chaînée). Suffisant pour la recette T-BR. */
  app.post<{
    Body: { user_email?: unknown; fixtureId?: unknown };
  }>("/__dev/received-invoices/seed", async (req, reply) => {
    const email = parseEmail(req.body.user_email);
    if (email === null) {
      return reply.code(400).send({ message: "user_email must be a string." });
    }
    const userRow = await findUserAndCustomer(app, email);
    if (userRow === undefined) {
      return reply.code(404).send({ message: `No user found for email ${email}.` });
    }
    const fixtureId = typeof req.body.fixtureId === "string" ? req.body.fixtureId : "";
    if (fixtureId === "") {
      return reply.code(400).send({ message: "fixtureId must be a non-empty string." });
    }

    let rx;
    try {
      rx = getReceptionFixture(fixtureId);
    } catch {
      return reply.code(404).send({ message: `Unknown reception fixture "${fixtureId}".` });
    }

    const originRx =
      rx.originFixtureId !== undefined ? getReceptionFixture(rx.originFixtureId) : undefined;
    if (originRx !== undefined) {
      await seedReceivedRowFromFixture(app.sql, userRow.customer_id, originRx);
    }
    const row = await seedReceivedRowFromFixture(app.sql, userRow.customer_id, rx);

    let downloadConfigured = false;
    if (app.paDriver instanceof MockPADriver) {
      const driver = app.paDriver;
      // Document de la pièce principale : servi par défaut ET ciblé sur son
      // paInvoiceId.
      driver.setDownloadInvoiceFileResult(await downloadResultForFixture(rx));
      driver.setDownloadInvoiceFileResultFor(
        row.pa_invoice_id_in,
        await downloadResultForFixture(rx),
      );
      // Document PROPRE de l'origine chaînée → sa fiche parse son vrai document
      // (sinon elle hériterait du doc de la rectificative = faux bandeau).
      if (originRx !== undefined) {
        driver.setDownloadInvoiceFileResultFor(
          paInvoiceIdForFixture(originRx),
          await downloadResultForFixture(originRx),
        );
      }
      downloadConfigured = true;
    }
    return reply.code(200).send({
      id: row.id,
      pa_invoice_id_in: row.pa_invoice_id_in,
      fixtureId,
      originSeeded: rx.originFixtureId ?? null,
      downloadConfigured,
    });
  });

  /** Update `customers.ui_mode_default` pour le user identifié par
   *  email. Utilisé par parcours 2 (Sophie démarre en mode UI avancé). */
  app.patch<{
    Body: { user_email?: unknown; mode?: unknown };
  }>("/__dev/customer/ui-mode-default", async (req, reply) => {
    const email = parseEmail(req.body.user_email);
    if (email === null) {
      return reply.code(400).send({ message: "user_email must be a string." });
    }
    const mode = req.body.mode === "advanced" || req.body.mode === "basic" ? req.body.mode : null;
    if (mode === null) {
      return reply.code(400).send({ message: "mode must be 'basic' | 'advanced'." });
    }
    const userRow = await findUserAndCustomer(app, email);
    if (userRow === undefined) {
      return reply.code(404).send({ message: `No user found for email ${email}.` });
    }
    await app.sql`
      UPDATE customers SET ui_mode_default = ${mode} WHERE id = ${userRow.customer_id}
    `;
    return reply.code(204).send();
  });

  /** Set `customers.iban` / `customers.bic` pour permettre au pipeline
   *  émission (`apps/api/src/routes/invoices/create.ts` →
   *  `services/invoice-form-to-model.ts`) de valider le mode de
   *  paiement Virement default — sinon erreur typée
   *  `INVALID_PAYMENT_METHOD_MISSING_IBAN`. Couvre la dette
   *  `T-CL-WEB-SETTINGS-ENTREPRISE-V1` sprint-05+ pour les E2E
   *  sprint-04. */
  app.patch<{
    Body: { user_email?: unknown; iban?: unknown; bic?: unknown; vat_number?: unknown };
  }>("/__dev/customer/invoicing-defaults", async (req, reply) => {
    const email = parseEmail(req.body.user_email);
    if (email === null) {
      return reply.code(400).send({ message: "user_email must be a string." });
    }
    const iban = typeof req.body.iban === "string" && req.body.iban !== "" ? req.body.iban : null;
    const bic = typeof req.body.bic === "string" && req.body.bic !== "" ? req.body.bic : null;
    // BT-31 (n° TVA vendeur) : requis par BR-S-02 dès qu'une ligne est au taux
    // standard (S). Sans lui, la cascade Schematron bloque l'émission (422).
    const vatNumber =
      typeof req.body.vat_number === "string" && req.body.vat_number !== ""
        ? req.body.vat_number
        : null;
    const userRow = await findUserAndCustomer(app, email);
    if (userRow === undefined) {
      return reply.code(404).send({ message: `No user found for email ${email}.` });
    }
    await app.sql`
      UPDATE customers SET iban = ${iban}, bic = ${bic}, vat_number = ${vatNumber}
      WHERE id = ${userRow.customer_id}
    `;
    return reply.code(204).send();
  });

  // ───────────────────────────────────────────────────────────────────
  // T-CL-HARNESS-SUPERPDP-PROP sprint-10 W0-A — form de fixture émission
  //
  // Sert le `form` (InvoiceForm) d'une fixture du corpus `factur-x-fixtures`
  // au harness PA (`scripts/dev/harness-pa.mjs`). Le harness est un script Node
  // PUR (exécuté hors Docker, sans pnpm/workspace) : il ne peut pas importer le
  // paquet TS, il récupère donc le form via cet endpoint — source unique du
  // corpus (aucun SIREN/numéro en littéral côté script). Le harness surcharge
  // `document.number` (unicité par run, anti-collision sandbox) avant d'appeler
  // `POST /api/invoices`. Lecture seule, dev-only (registerDevRoutes gated).
  // ───────────────────────────────────────────────────────────────────

  app.get("/__dev/emission-fixtures", async (_req, reply) => {
    return reply.code(200).send({ ids: allFixtures().map((f) => f.meta.id) });
  });

  app.get<{ Params: { id: string } }>("/__dev/emission-fixtures/:id", async (req, reply) => {
    let fixture;
    try {
      fixture = getFixture(req.params.id);
    } catch {
      return reply.code(404).send({
        message: `Unknown emission fixture "${req.params.id}".`,
        ids: allFixtures().map((f) => f.meta.id),
      });
    }
    return reply.code(200).send({ id: fixture.meta.id, form: fixture.form });
  });

  // ───────────────────────────────────────────────────────────────────
  // T-CL-TEST-E2E sprint-04 — Quick login (Bruno manual UI debug)
  //
  // GET /__dev/quick-login?email=...&siren=...&with_pa=true&ui_mode=basic
  //   → Crée customer + user (MFA email pré-enrôlée, recovery codes
  //     hashés) + pa_connection verified si `with_pa=true` (default).
  //     Skip le signup phase 1 complet (5 étapes).
  //   → Sign access_token + refresh_token + INSERT session.
  //   → setRefreshSessionCookie sur la response.
  //   → 302 vers /dashboard (servi par le SPA `vite preview` ou `dev`).
  //
  // Bruno colle l'URL dans son navigateur → connecté direct, peut
  // explorer toutes les pages /emission, /articles, etc. Le SPA
  // `AuthProvider` mount → POST `/auth/refresh` avec le cookie posé →
  // récupère un access_token frais → state="authenticated".
  // ───────────────────────────────────────────────────────────────────
  app.get<{
    Querystring: {
      email?: string;
      siren?: string;
      with_pa?: string;
      ui_mode?: string;
    };
  }>("/__dev/quick-login", async (req, reply) => {
    if (process.env.NODE_ENV === "production") {
      return reply.code(404).send({ message: "Disabled in production." });
    }
    const email = (req.query.email ?? "bruno-test@factur-e.test").toLowerCase();
    const siren = req.query.siren ?? "552120222";
    const withPa = req.query.with_pa !== "false";
    const uiMode = req.query.ui_mode === "advanced" ? "advanced" : "basic";
    const password = "TestPassword12!";

    // 0. Si le user existe déjà → court-circuite la création + reconnecte.
    const existing = await app.sql<{ id: string; customer_id: string }[]>`
      SELECT id, customer_id FROM users WHERE email = ${email} AND deleted_at IS NULL
    `;
    let userId: string;
    let customerId: string;

    if (existing[0] !== undefined) {
      userId = existing[0].id;
      customerId = existing[0].customer_id;
    } else {
      // 1. INSERT customer minimal — pré-rempli pour parcours d'émission
      //    (directory_address = siren brut, comme phase 1 sprint-02).
      //    IBAN/BIC peuplés en parallèle pour que le pipeline émission
      //    (formToModel.ts) valide le mode de paiement Virement par
      //    défaut — sinon `INVALID_PAYMENT_METHOD_MISSING_IBAN`. Sprint-04
      //    n'expose pas l'IBAN au front (DEBT sprint-05+), mais le
      //    backend l'utilise pour générer le PDF + XML CII.
      const customerInsert = await app.sql<{ id: string }[]>`
        INSERT INTO customers (
          siren, legal_name, address, juridique_code, naf_code,
          directory_address, profile_unverified, ui_mode_default,
          iban, bic
        ) VALUES (
          ${siren},
          ${"ACME E2E QUICK SAS"},
          ${app.sql.json({
            line_one: "10 RUE DE TEST",
            postcode: "75002",
            city: "PARIS",
            country_code: "FR",
          })},
          ${"5710"},
          ${"6201Z"},
          ${siren},
          ${false},
          ${uiMode},
          ${"FR7630006000011234567890189"},
          ${"BNPAFRPPXXX"}
        )
        RETURNING id
      `;
      const cRow = customerInsert[0];
      if (cRow === undefined) {
        return reply.code(500).send({ message: "customer insert failed" });
      }
      customerId = cRow.id;

      // 2. INSERT user — MFA email pré-enrôlée, primary/secondary
      //    verified. Le user peut se logger via /auth/login normal
      //    (mfa_mode='email' → OTP envoyé → consulter /__dev/last-email).
      //    Ou court-circuit via le cookie posé ci-dessous.
      const passwordHash = await hashPassword(password);
      // MFA secret bidon mais valide (32 bytes random encrypted).
      // Le user peut générer TOTP via /__dev/totp-now si besoin.
      const mfaSecretRaw = Buffer.alloc(32);
      for (let i = 0; i < 32; i++) {
        mfaSecretRaw[i] = Math.floor(Math.random() * 256);
      }
      const mfaSecretEnc = encrypt(mfaSecretRaw);
      // Recovery codes : 10 codes hashés bidon (l'user ne les consommera
      // pas en quick-login — seulement pour respecter le schéma).
      const recoveryCodesHashed: string[] = [];
      for (let i = 0; i < 10; i++) {
        recoveryCodesHashed.push(await hashPassword(`recovery-${String(i)}`));
      }
      const inserted = await usersRepo.insertUserFromPhase1(app.sql, {
        customerId,
        email,
        passwordHash,
        mfaSecret: mfaSecretEnc,
        mfaMode: "email",
        mfaEnrolledAt: new Date(),
        recoveryCodesHashed,
        role: "full",
        canPurchase: true,
        emailVerifiedAt: new Date(),
        secondaryEmail: email.replace("@", "-secours@"),
        secondaryEmailVerifiedAt: new Date(),
        termsAcceptedAt: new Date(),
      });
      userId = inserted.id;

      await writeAuthAudit(app.sql, {
        event_type: "dev_quick_login_user_created",
        success: true,
        user_id: userId,
        customer_id: customerId,
        metadata: { source: "quick_login" },
      });
    }

    // 3. PA connection verified (optionnel).
    if (withPa) {
      const existingPa = await paRepo.findActivePaConnectionStatusByCustomerId(app.sql, customerId);
      if (existingPa === undefined) {
        const secretRef = paSecretRef({ customerId });
        await app.secrets.put(secretRef, {
          accessToken: `quick-access-${Date.now().toString()}`,
          refreshToken: `quick-refresh-${Date.now().toString()}`,
          accessExpiresAt: new Date(Date.now() + 1800 * 1000).toISOString(),
        });
        await paRepo.insertPaConnection(app.sql, {
          customerId,
          paUserId: "pa-user-quick",
          secretRef,
          userIdentityStatus: "verified",
          companyStatus: "verified",
        });
        await customersRepo.markCustomerProfileVerified(app.sql, customerId);
      }
    }

    // 4. Session + cookie. Le AuthProvider du SPA fera /auth/refresh
    //    automatiquement au mount → rotation du refresh token + access
    //    token frais.
    const sessionId = randomUUID();
    await insertSession(app.sql, {
      id: sessionId,
      userId,
      ip: req.ip,
      userAgent: req.headers["user-agent"] ?? null,
    });
    const refreshToken = await signRefreshToken({ session_id: sessionId, user_id: userId });
    const accessToken = await signAccessToken({ user_id: userId, customer_id: customerId });
    setRefreshSessionCookie(reply, refreshToken);

    // 5. Redirige vers le SPA. URL configurée via env
    //    `DEV_QUICK_LOGIN_REDIRECT_URL` (default localhost:5174/dashboard).
    const spaUrl = process.env.DEV_QUICK_LOGIN_REDIRECT_URL ?? "http://localhost:5174/dashboard";
    return reply.code(302).header("location", spaUrl).send({
      email,
      password,
      access_token: accessToken,
      user_id: userId,
      customer_id: customerId,
    });
  });
}

// ───────────────────────────────────────────────────────────────────
// Helpers locaux
// ───────────────────────────────────────────────────────────────────

function parseEmail(raw: unknown): string | null {
  if (typeof raw !== "string" || raw === "") return null;
  return raw.toLowerCase();
}

/** Levier 2 — provisionne un brouillon depuis une fixture du corpus, aligne
 *  le customer sur `fixture.seller` et crée l'origine BG-3 si nécessaire. */
async function seedFromFixture(
  app: FastifyInstance,
  reply: FastifyReply,
  customerId: string,
  fixtureId: string,
): Promise<FastifyReply> {
  let fixture;
  try {
    fixture = getFixture(fixtureId);
  } catch {
    return reply.code(400).send({ message: `Unknown fixtureId "${fixtureId}".` });
  }

  // 1. Aligne le customer sur le seller de la fixture (identités sandbox).
  const seller = customerRowFromFixtureSeller(fixture.seller);
  await app.sql`
    UPDATE customers SET
      siren = ${seller.siren},
      legal_name = ${seller.legal_name},
      trading_name = ${seller.trading_name},
      address = ${app.sql.json(seller.address as postgres.JSONValue)},
      naf_code = ${seller.naf_code},
      rcs = ${seller.rcs},
      juridique_code = ${seller.juridique_code},
      capital_social = ${seller.capital_social},
      vat_number = ${seller.vat_number},
      vat_regime = ${seller.vat_regime},
      vat_on_encashment = ${seller.vat_on_encashment},
      iban = ${seller.iban},
      bic = ${seller.bic},
      legal_mentions = ${seller.legal_mentions},
      directory_address = ${seller.directory_address},
      default_invoice_values = ${app.sql.json(seller.default_invoice_values as postgres.JSONValue)}
    WHERE id = ${customerId}
  `;

  // 2. Chaînage BG-3 — origine fx-380-base-iban à l'id fixe FX_ORIGIN_INVOICE_ID.
  const preceding = (fixture.form as { precedingInvoiceId?: string | null }).precedingInvoiceId;
  let originInvoiceId: string | undefined;
  if (preceding === FX_ORIGIN_INVOICE_ID) {
    originInvoiceId = await ensureOriginInvoice(app, customerId);
  }

  // 3. Brouillon = payload de la fixture, mais `document.issueDate` forcé à
  //    AUJOURD'HUI. La fixture fige une date (ex. 2026-06-01) pour ses
  //    assertions XML ; émise telle quelle, la facture serait antidatée et se
  //    classerait bas dans la liste émission (tri `issue_date DESC`). Pour la
  //    recette, on veut une émission « du jour » qui remonte en tête.
  const todayIso = new Date().toISOString().slice(0, 10);
  const seededForm = {
    ...fixture.form,
    document: { ...fixture.form.document, issueDate: todayIso },
  };
  const rows = await app.sql<{ id: string }[]>`
    INSERT INTO invoice_drafts (customer_id, payload, step_completed)
    VALUES (${customerId}, ${app.sql.json(seededForm)}, ${app.sql.json({})})
    RETURNING id
  `;
  const draftId = rows[0]?.id;
  if (draftId === undefined) {
    return reply.code(500).send({ message: "Failed to seed fixture draft." });
  }
  return reply.code(200).send({ draftId, fixtureId, originInvoiceId });
}

/** Crée (idempotent) la facture d'origine du chaînage BG-3 = fx-380-base-iban
 *  à l'id fixe FX_ORIGIN_INVOICE_ID, état émis, pour `customerId`. */
async function ensureOriginInvoice(app: FastifyInstance, customerId: string): Promise<string> {
  const origin = getFixture("fx-380-base-iban");
  const lines = origin.form.lines;
  const totalHt = lines.reduce((acc, l) => acc + Number(l.totalHt), 0);
  const totalVat = lines.reduce(
    (acc, l) => acc + (l.vatRate === null ? 0 : (Number(l.totalHt) * Number(l.vatRate)) / 100),
    0,
  );
  const trackingId = randomUUID();
  const paInvoiceId = String(Math.floor(Date.now() / 1000));
  const submittedAt = new Date();
  const sha256 = createHash("sha256").update(`seed-origin-${FX_ORIGIN_INVOICE_ID}`).digest("hex");

  await app.sql`
    INSERT INTO invoices (
      id, customer_id, number, issue_date, tracking_id,
      total_ht, total_vat, total_ttc,
      currency, processing_rule, type_code,
      pa_invoice_id, pa_provider, sha256, submitted_at, status_current,
      payload_extended
    ) VALUES (
      ${FX_ORIGIN_INVOICE_ID}, ${customerId}, ${origin.form.document.number},
      ${origin.form.document.issueDate}, ${trackingId},
      ${totalHt.toFixed(2)}, ${totalVat.toFixed(2)}, ${(totalHt + totalVat).toFixed(2)},
      ${"EUR"}, ${"B2B"}, ${"380"},
      ${paInvoiceId}, ${"superpdp"}, ${sha256}, ${submittedAt}, ${"submitted"},
      ${app.sql.json({ buyer: origin.form.parties.buyer, seed: true })}
    )
    ON CONFLICT (id) DO NOTHING
  `;
  await insertCdarEvent(app.sql, {
    invoice_id: FX_ORIGIN_INVOICE_ID,
    code: "api:uploaded",
    label: "Déposée",
    occurred_at: submittedAt,
    payload: { seed: true },
    source: "synthetic",
  });
  return FX_ORIGIN_INVOICE_ID;
}

function parseIdentityStatus(raw: unknown): "verified" | "needs_review" | "rejected" | null {
  return raw === "verified" || raw === "needs_review" || raw === "rejected" ? raw : null;
}

function parsePollingDirection(raw: unknown): PollingDirection | null {
  return raw === "in" || raw === "out" ? raw : null;
}

async function findUserAndCustomer(
  app: FastifyInstance,
  email: string,
): Promise<{ id: string; customer_id: string } | undefined> {
  const rows = await app.sql<{ id: string; customer_id: string }[]>`
    SELECT id, customer_id FROM users WHERE email = ${email} AND deleted_at IS NULL
  `;
  return rows[0];
}
