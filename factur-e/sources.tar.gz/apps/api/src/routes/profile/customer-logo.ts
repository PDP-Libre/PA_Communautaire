import type { Buffer } from "node:buffer";

import type { FastifyInstance } from "fastify";

import { writeAuthAudit } from "../../auth/audit.js";
import { resolveAuthContext } from "../../auth/context.js";
import * as customersRepo from "../../db/repos/customers.js";
import { requireFullRole } from "../../profile/role-guard.js";

const MAX_LOGO_SIZE = 2 * 1024 * 1024; // 2 MiB
const ALLOWED_TYPES = new Set(["image/png", "image/svg+xml"]);

const NEUTRAL = "Vérifiez vos informations.";

export function registerCustomerLogoRoutes(app: FastifyInstance): void {
  app.post("/customers/me/logo", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: NEUTRAL });
    }
    if ((await requireFullRole(app, reply, ctx)) === null) return;

    const file = await req.file({ limits: { fileSize: MAX_LOGO_SIZE } });
    if (file === undefined) {
      return reply.code(400).send({ message: "Fichier manquant." });
    }
    if (!ALLOWED_TYPES.has(file.mimetype)) {
      return reply.code(415).send({ message: "Format non supporté. Utilisez PNG ou SVG." });
    }

    let body: Buffer;
    try {
      body = await file.toBuffer();
    } catch {
      return reply.code(413).send({ message: "Fichier supérieur à 2 Mo." });
    }
    // Defense in depth — `file.toBuffer()` may not always throw on
    // limit overflow depending on stream buffering.
    if (body.length > MAX_LOGO_SIZE) {
      return reply.code(413).send({ message: "Fichier supérieur à 2 Mo." });
    }
    if (body.length === 0) {
      return reply.code(400).send({ message: "Fichier vide." });
    }

    const ext = file.mimetype === "image/png" ? "png" : "svg";
    const key = `customers/${ctx.customer_id}/logo.${ext}`;

    await app.storage.uploadObject({
      key,
      body,
      contentType: file.mimetype,
    });

    // Replace any previous logo key (different extension is possible).
    const previous = await customersRepo.findCustomerLogoKeyById(app.sql, ctx.customer_id);
    const previousKey = previous?.logo_s3_key ?? null;
    if (previousKey !== null && previousKey !== key) {
      await app.storage.deleteObject(previousKey);
    }

    await customersRepo.markCustomerLogoKey(app.sql, ctx.customer_id, key);

    await writeAuthAudit(app.sql, {
      event_type: "customer_logo_uploaded",
      success: true,
      user_id: ctx.user_id,
      customer_id: ctx.customer_id,
      ip: req.ip,
      user_agent: req.headers["user-agent"] ?? null,
      metadata: { logo_s3_key: key, size_bytes: body.length },
    });

    return reply.code(200).send({ logo_url: app.storage.getObjectUrl(key) });
  });

  app.delete("/customers/me/logo", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: NEUTRAL });
    }
    if ((await requireFullRole(app, reply, ctx)) === null) return;

    const row = await customersRepo.findCustomerLogoKeyById(app.sql, ctx.customer_id);
    const key = row?.logo_s3_key ?? null;
    if (key !== null) {
      await app.storage.deleteObject(key);
    }
    await customersRepo.markCustomerLogoKey(app.sql, ctx.customer_id, null);

    await writeAuthAudit(app.sql, {
      event_type: "customer_logo_deleted",
      success: true,
      user_id: ctx.user_id,
      customer_id: ctx.customer_id,
      ip: req.ip,
      user_agent: req.headers["user-agent"] ?? null,
      metadata: { previous_key: key },
    });

    return reply.code(204).send();
  });
}
