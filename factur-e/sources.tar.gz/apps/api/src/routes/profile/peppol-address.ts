import type { FastifyInstance } from "fastify";

import { writeAuthAudit } from "../../auth/audit.js";
import { resolveAuthContext } from "../../auth/context.js";
import * as customersRepo from "../../db/repos/customers.js";
import * as paRepo from "../../db/repos/pa_connections.js";
import { requireFullRole } from "../../profile/role-guard.js";

/**
 * T-CL-PA-DIRECTORY-PEPPOL sprint-05 — Routes `customers/me/peppol-address`.
 *
 *  - `GET /api/customers/me/peppol-address` — lecture seule, retourne
 *    `directory_address` du customer + flag de statut (`enrolled` /
 *    `pending` / `disabled`). Pas de role guard (lecture personnelle).
 *
 *  - `POST /api/customers/me/peppol-address/refresh` — re-fetch annuaire
 *    SuperPDP via `searchSiren` et UPDATE `customers.directory_address`.
 *    **Rôle Responsable (Full) requis** — action sensible qui modifie
 *    les données entreprise consommées par le pipeline d'émission.
 *
 *  Le composant UI `<PeppolAddressDisplay>` côté brief
 *  T-CL-WEB-SETTINGS-ENTREPRISE-V1 §9 consomme `/refresh` (sémantique
 *  lecture annuaire non-mutative, audit `peppol_address_refreshed`).
 *
 *  Cf. ADR-009 D2 fail-safe (l'erreur annuaire ne casse pas l'UX user) +
 *  ADR-012 D3 inchangé (réutilisation `superpdp-oauth-cc` ctx dummy via
 *  `SuperPDPDriver.fetchOwnPeppolAddresses`).
 */
const NEUTRAL = "Vérifiez vos informations.";

type PeppolAddressStatus = "enrolled" | "pending" | "disabled";

interface PeppolAddressResponse {
  directory_address: string | null;
  status: PeppolAddressStatus;
  retry_count: number;
}

function deriveStatus(directoryAddress: string | null): PeppolAddressStatus {
  if (directoryAddress === null) return "pending";
  if (directoryAddress.startsWith("0225:")) return "enrolled";
  return "pending";
}

export function registerPeppolAddressRoutes(app: FastifyInstance): void {
  app.get("/customers/me/peppol-address", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: NEUTRAL });
    }

    const customer = await customersRepo.findActiveCustomerById(app.sqlRead, ctx.customer_id);
    if (customer === undefined) {
      return reply.code(404).send({ message: NEUTRAL });
    }

    const response: PeppolAddressResponse = {
      directory_address: customer.directory_address,
      status: deriveStatus(customer.directory_address),
      retry_count: customer.peppol_address_retry_count,
    };
    return reply.code(200).send(response);
  });

  app.post("/customers/me/peppol-address/refresh", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: NEUTRAL });
    }
    if ((await requireFullRole(app, reply, ctx)) === null) return;

    const customer = await customersRepo.findActiveCustomerById(app.sqlRead, ctx.customer_id);
    if (customer === undefined) {
      return reply.code(404).send({ message: NEUTRAL });
    }

    // T-CL-PA-OWN-DIRECTORY-ENTRIES sprint-06 — adresse propre via
    // `directory_entries` (authentifié) → token PA du customer.
    const conn = await paRepo.findActivePaConnectionForDisconnectByCustomerId(
      app.sqlRead,
      ctx.customer_id,
    );
    const bundle =
      conn === undefined ? null : await app.secrets.get(conn.secret_ref).catch(() => null);
    if (bundle === null) {
      // Pas de connexion PA active → adresse non résolvable : statut courant.
      return reply.code(200).send({
        directory_address: customer.directory_address,
        status: deriveStatus(customer.directory_address),
        retry_count: customer.peppol_address_retry_count,
      } satisfies PeppolAddressResponse);
    }

    try {
      const result = await app.paDriver.getOwnDirectoryEntries({ accessToken: bundle.accessToken });
      if (result.kind === "found_one_address" || result.kind === "found_multi_address") {
        const address = result.kind === "found_one_address" ? result.address : result.addresses[0];
        if (address === undefined) {
          // Defensive — found_multi_address sans addresses[] est exclu par
          // le contrat DirectorySearchResult, mais le narrowing TS le veut.
          await writeAuthAudit(app.sql, {
            event_type: "peppol_address_disabled",
            success: false,
            user_id: ctx.user_id,
            customer_id: ctx.customer_id,
            ip: req.ip,
            user_agent: req.headers["user-agent"] ?? null,
          });
          return await reply.code(200).send({
            directory_address: customer.directory_address,
            status: deriveStatus(customer.directory_address),
            retry_count: customer.peppol_address_retry_count,
          } satisfies PeppolAddressResponse);
        }
        await customersRepo.updateCustomerDirectoryAddress(
          app.sql,
          ctx.customer_id,
          address.party_id,
        );
        await writeAuthAudit(app.sql, {
          event_type: "peppol_address_refreshed",
          success: true,
          user_id: ctx.user_id,
          customer_id: ctx.customer_id,
          ip: req.ip,
          user_agent: req.headers["user-agent"] ?? null,
          metadata: { directory_address: address.party_id, kind: result.kind },
        });
        return await reply.code(200).send({
          directory_address: address.party_id,
          status: "enrolled",
          retry_count: 0,
        } satisfies PeppolAddressResponse);
      }

      // not_found / disabled / unavailable → pas d'UPDATE, audit + 200
      // avec status pending (UX cohérent EmptyState côté UI).
      const auditEvent =
        result.kind === "not_found"
          ? "peppol_address_not_enrolled_yet"
          : result.kind === "disabled"
            ? "peppol_address_disabled"
            : "peppol_address_lookup_5xx";
      await writeAuthAudit(app.sql, {
        event_type: auditEvent,
        success: false,
        user_id: ctx.user_id,
        customer_id: ctx.customer_id,
        ip: req.ip,
        user_agent: req.headers["user-agent"] ?? null,
        metadata: { kind: result.kind },
      });
      return await reply.code(200).send({
        directory_address: customer.directory_address,
        status: deriveStatus(customer.directory_address),
        retry_count: customer.peppol_address_retry_count,
      } satisfies PeppolAddressResponse);
    } catch (err) {
      app.log.error(
        { err, customer_id: ctx.customer_id },
        "[customers/me/peppol-address/refresh] fetchOwnPeppolAddresses threw",
      );
      await writeAuthAudit(app.sql, {
        event_type: "peppol_address_lookup_5xx",
        success: false,
        user_id: ctx.user_id,
        customer_id: ctx.customer_id,
        ip: req.ip,
        user_agent: req.headers["user-agent"] ?? null,
        metadata: { error: err instanceof Error ? err.message : "unknown" },
      });
      // Non-blocking : 200 avec status pending (UI gère via empty state).
      return reply.code(200).send({
        directory_address: customer.directory_address,
        status: "pending",
        retry_count: customer.peppol_address_retry_count,
      } satisfies PeppolAddressResponse);
    }
  });
}
