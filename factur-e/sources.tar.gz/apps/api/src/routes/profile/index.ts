import type { FastifyInstance } from "fastify";

import { registerCustomerLogoRoutes } from "./customer-logo.js";
import { registerCustomerProfileRoute } from "./customer-profile.js";
import { registerCustomerSettingsRoutes } from "./customer-settings.js";
import { registerDefaultInvoiceValuesRoute } from "./default-invoice-values.js";
import { registerPeppolAddressRoutes } from "./peppol-address.js";
import { registerUserProfileRoute } from "./user-profile.js";

export function registerProfileRoutes(app: FastifyInstance): void {
  registerUserProfileRoute(app);
  registerCustomerProfileRoute(app);
  registerCustomerLogoRoutes(app);
  registerCustomerSettingsRoutes(app);
  registerDefaultInvoiceValuesRoute(app);
  registerPeppolAddressRoutes(app);
}
