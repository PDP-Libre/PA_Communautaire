import type { FastifyInstance } from "fastify";

import { capitalRequiredFor, CustomerProfilePatchBodySchema } from "@factur-e/shared-schemas";

import { writeAuthAudit } from "../../auth/audit.js";
import { resolveAuthContext } from "../../auth/context.js";
import { encrypt } from "../../auth/encryption.js";
import * as customersRepo from "../../db/repos/customers.js";
import { isValidBic, isValidIban, normalizeIban } from "../../profile/iban.js";
import { requireFullRole } from "../../profile/role-guard.js";

const NEUTRAL = "Vérifiez vos informations.";
const IBAN_VERSION_PREFIX = "v1:";

export function registerCustomerProfileRoute(app: FastifyInstance): void {
  app.patch("/customers/me/profile", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: NEUTRAL });
    }
    if ((await requireFullRole(app, reply, ctx)) === null) return;

    const parsed = CustomerProfilePatchBodySchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ message: NEUTRAL });
    }
    const body = parsed.data;
    const ip = req.ip;
    const ua = req.headers["user-agent"] ?? null;

    if (body.iban !== undefined && !isValidIban(body.iban)) {
      return reply.code(400).send({ message: "IBAN invalide." });
    }
    if (body.bic !== undefined && !isValidBic(body.bic)) {
      return reply.code(400).send({ message: "BIC invalide." });
    }

    // Conditional capital_social check based on `juridique_code`. Pure
    // reads → app.sqlRead (alias of app.sql in MVP, replica V2 ready).
    if (body.capital_social === undefined) {
      const cust = await customersRepo.findCustomerJuridiqueCodeById(app.sqlRead, ctx.customer_id);
      const code = cust?.juridique_code ?? null;
      if (capitalRequiredFor(code)) {
        // Only blocking when the user is *finishing* the profile —
        // partial updates without `capital_social` are allowed if the
        // value was set before. Detect "first time" by checking the
        // current customers.capital_social.
        const current = await customersRepo.findCustomerCapitalSocialById(
          app.sqlRead,
          ctx.customer_id,
        );
        if (current?.capital_social === null) {
          return reply
            .code(400)
            .send({ message: "Capital social requis pour cette forme juridique." });
        }
      }
    }

    // Encrypt IBAN before storage.
    const ibanCipher =
      body.iban === undefined
        ? null
        : `${IBAN_VERSION_PREFIX}${encrypt(normalizeIban(body.iban)).toString("base64")}`;

    const capitalNumber =
      body.capital_social === undefined
        ? null
        : typeof body.capital_social === "number"
          ? body.capital_social
          : Number(body.capital_social);

    // Build a SET clause that only touches provided fields. postgres.js
    // doesn't support dynamic SET, so we update each field individually
    // when defined.
    if (body.trading_name !== undefined) {
      await customersRepo.markCustomerTradingName(app.sql, ctx.customer_id, body.trading_name);
    }
    if (ibanCipher !== null) {
      await customersRepo.markCustomerIban(app.sql, ctx.customer_id, ibanCipher);
    }
    if (body.bic !== undefined) {
      await customersRepo.markCustomerBic(
        app.sql,
        ctx.customer_id,
        body.bic.toUpperCase().replace(/\s+/g, ""),
      );
    }
    if (capitalNumber !== null) {
      await customersRepo.markCustomerCapitalSocial(app.sql, ctx.customer_id, capitalNumber);
    }
    if (body.mentions_legales !== undefined) {
      await customersRepo.markCustomerLegalMentions(
        app.sql,
        ctx.customer_id,
        body.mentions_legales,
      );
    }
    if (body.primary_color !== undefined) {
      await customersRepo.markCustomerPrimaryColor(app.sql, ctx.customer_id, body.primary_color);
    }

    await writeAuthAudit(app.sql, {
      event_type: "customer_profile_updated",
      success: true,
      user_id: ctx.user_id,
      customer_id: ctx.customer_id,
      ip,
      user_agent: ua,
      metadata: {
        // Field names only, never values (IBAN/legal_mentions are PII).
        fields_updated: Object.keys(body),
      },
    });

    return reply.code(204).send();
  });
}
