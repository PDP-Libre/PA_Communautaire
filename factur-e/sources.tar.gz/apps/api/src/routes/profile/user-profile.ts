import type { FastifyInstance } from "fastify";

import { UserProfilePatchBodySchema } from "@factur-e/shared-schemas";

import { writeAuthAudit } from "../../auth/audit.js";
import { resolveAuthContext } from "../../auth/context.js";
import * as usersRepo from "../../db/repos/users.js";

const NEUTRAL = "Vérifiez vos informations.";

export function registerUserProfileRoute(app: FastifyInstance): void {
  app.patch("/users/me/profile", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: NEUTRAL });
    }
    const parsed = UserProfilePatchBodySchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ message: NEUTRAL });
    }
    const { first_name, last_name, function_title } = parsed.data;
    const ip = req.ip;
    const ua = req.headers["user-agent"] ?? null;

    await usersRepo.markUserProfile(app.sql, ctx.user_id, {
      first_name,
      last_name,
      function_title: function_title ?? null,
    });

    await writeAuthAudit(app.sql, {
      event_type: "user_profile_updated",
      success: true,
      user_id: ctx.user_id,
      customer_id: ctx.customer_id,
      ip,
      user_agent: ua,
    });

    return reply.code(204).send();
  });
}
