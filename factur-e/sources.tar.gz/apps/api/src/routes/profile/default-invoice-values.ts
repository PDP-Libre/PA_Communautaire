import type { FastifyInstance } from "fastify";
import type postgres from "postgres";

import { DefaultInvoiceValuesPutBodySchema } from "@factur-e/shared-schemas";

import { writeAuthAudit } from "../../auth/audit.js";
import { resolveAuthContext } from "../../auth/context.js";
import * as customersRepo from "../../db/repos/customers.js";
import { requireFullRole } from "../../profile/role-guard.js";

const NEUTRAL = "Vérifiez vos informations.";

export function registerDefaultInvoiceValuesRoute(app: FastifyInstance): void {
  app.put("/customers/me/default-invoice-values", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: NEUTRAL });
    }
    if ((await requireFullRole(app, reply, ctx)) === null) return;

    const parsed = DefaultInvoiceValuesPutBodySchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ message: NEUTRAL });
    }
    const values = parsed.data as unknown as postgres.JSONValue;

    await customersRepo.markCustomerDefaultInvoiceValues(app.sql, ctx.customer_id, values);

    await writeAuthAudit(app.sql, {
      event_type: "customer_default_invoice_values_updated",
      success: true,
      user_id: ctx.user_id,
      customer_id: ctx.customer_id,
      ip: req.ip,
      user_agent: req.headers["user-agent"] ?? null,
    });

    return reply.code(204).send();
  });
}
