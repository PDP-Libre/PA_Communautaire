import type { FastifyInstance } from "fastify";

import {
  CustomerSettingsPatchBodySchema,
  apiError,
  zodIssuesToApiIssues,
  type CustomerSettingsResponse,
} from "@factur-e/shared-schemas";

import { writeAuthAudit } from "../../auth/audit.js";
import { resolveAuthContext } from "../../auth/context.js";
import * as customersRepo from "../../db/repos/customers.js";
import { decryptStoredIban, maskIban } from "../../profile/iban.js";
import { requireFullRole } from "../../profile/role-guard.js";

/**
 * T-CL-WEB-SETTINGS-ENTREPRISE-V1 sprint-05 — Routes `/customers/me/settings`.
 *
 *  - `GET /customers/me/settings` — vue consolidée pour la page
 *    Paramètres > Entreprise. INSEE lecture seule + champs éditables
 *    exposés par les 4 endpoints existants + 3 champs sprint-05.
 *    Lecture personnelle, pas de role guard.
 *
 *  - `PATCH /customers/me/settings` — édite les 3 champs sprint-05 que les
 *    endpoints `/profile`, `/logo`, `/default-invoice-values` ne couvrent
 *    pas : `vat_number`, `vat_on_encashment`, `ui_mode_default`.
 *    **Rôle Responsable (Full) requis** sur les 2 premiers (modifient les
 *    données entreprise consommées par le pipeline d'émission). Le 3ᵉ
 *    (`ui_mode_default`) est une préférence personnelle, traité avec le
 *    même guard pour cohérence d'endpoint (un user dépôt n'a de toute
 *    façon pas accès à la page Paramètres > Entreprise côté UI).
 *
 *  Cohérent pattern routes `profile/` sprint-05 (PA-DIRECTORY-PEPPOL
 *  apprentissage trace [PMO] J+1 #3). Audit text libre cohérent acquis
 *  sprint-05 (pas d'enum centralisé).
 */
const NEUTRAL = "Vérifiez vos informations.";

export function registerCustomerSettingsRoutes(app: FastifyInstance): void {
  app.get("/customers/me/settings", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: NEUTRAL });
    }

    const customer = await customersRepo.findActiveCustomerById(app.sqlRead, ctx.customer_id);
    if (customer === undefined) {
      return reply.code(404).send({ message: NEUTRAL });
    }

    // `capital_social` est numeric(15,2) — `findActiveCustomerById` le
    // retourne déjà cast en text. On rafraîchit défensivement pour les
    // lignes anciennes où le cast ne s'applique pas (ex. tests).
    const capital = await customersRepo.findCustomerCapitalSocialById(app.sqlRead, ctx.customer_id);

    const logoUrl =
      customer.logo_s3_key === null ? null : app.storage.getObjectUrl(customer.logo_s3_key);

    // IBAN masqué pour affichage lecture seule (émission / aperçu PDF,
    // NC-3). On déchiffre uniquement pour calculer le masque (4 derniers) ;
    // l'IBAN complet ne quitte jamais le serveur via cette route.
    const ibanDisplay = customer.iban === null ? null : maskIban(decryptStoredIban(customer.iban));

    const body: CustomerSettingsResponse = {
      siren: customer.siren,
      legal_name: customer.legal_name,
      naf_code: customer.naf_code,
      juridique_code: customer.juridique_code,
      rcs: customer.rcs,
      capital_social: capital?.capital_social ?? null,
      address: customer.address,
      profile_unverified: customer.profile_unverified,
      siren_unverified: customer.siren_unverified,
      legal_name_unverified: customer.legal_name_unverified,
      address_unverified: customer.address_unverified,
      vat_number_unverified: customer.vat_number_unverified,
      trading_name: customer.trading_name,
      vat_number: customer.vat_number,
      has_iban: customer.iban !== null,
      iban_display: ibanDisplay,
      bic: customer.bic,
      logo_url: logoUrl,
      primary_color: customer.primary_color,
      legal_mentions: customer.legal_mentions,
      default_invoice_values: customer.default_invoice_values,
      vat_on_encashment: customer.vat_on_encashment,
      ui_mode_default: customer.ui_mode_default,
      directory_address: customer.directory_address,
    };
    return reply.code(200).send(body);
  });

  app.patch("/customers/me/settings", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: NEUTRAL });
    }
    if ((await requireFullRole(app, reply, ctx)) === null) return;

    const parsed = CustomerSettingsPatchBodySchema.safeParse(req.body);
    if (!parsed.success) {
      // Enveloppe d'erreur standard (NC-15) : issues Zod à plat sous
      // `issues` (et non plus imbriquées sous `error.issues`). Le front
      // affiche l'erreur sous le champ concerné via `parseApiError`.
      return reply
        .code(400)
        .send(apiError(NEUTRAL, { issues: zodIssuesToApiIssues(parsed.error.issues) }));
    }
    const body = parsed.data;

    if (body.vat_number !== undefined) {
      await customersRepo.markCustomerVatNumber(app.sql, ctx.customer_id, body.vat_number);
    }
    if (body.vat_on_encashment !== undefined) {
      await customersRepo.markCustomerVatOnEncashment(
        app.sql,
        ctx.customer_id,
        body.vat_on_encashment,
      );
    }
    if (body.ui_mode_default !== undefined) {
      await customersRepo.markCustomerUiModeDefault(app.sql, ctx.customer_id, body.ui_mode_default);
    }

    await writeAuthAudit(app.sql, {
      event_type: "customer_settings_updated",
      success: true,
      user_id: ctx.user_id,
      customer_id: ctx.customer_id,
      ip: req.ip,
      user_agent: req.headers["user-agent"] ?? null,
      metadata: {
        fields_updated: Object.keys(body),
      },
    });

    return reply.code(204).send();
  });
}
