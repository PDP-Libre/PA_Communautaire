import type { FastifyPluginAsync } from "fastify";

interface HealthResponse {
  readonly status: "ok";
  readonly version: string;
  readonly service: "factur-e-api";
}

/**
 * GET /health
 *
 * Liveness probe. Returns 200 with build metadata. Lightweight on purpose:
 * does not query the database or external services so it can be polled
 * frequently without side-effects.
 */
// eslint-disable-next-line @typescript-eslint/require-await -- Fastify plugin signature requires async even when no await is needed; this is the canonical shape.
export const healthRoute: FastifyPluginAsync = async (app) => {
  app.get("/health", (): HealthResponse => {
    return {
      status: "ok",
      service: "factur-e-api",
      version: process.env.GIT_SHA ?? process.env.npm_package_version ?? "dev",
    };
  });
};
