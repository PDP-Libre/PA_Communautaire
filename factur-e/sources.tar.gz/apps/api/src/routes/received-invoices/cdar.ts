import type { FastifyInstance, FastifyReply } from "fastify";

import {
  InvoiceRejectedXsdException,
  PaAccessTokenExpiredException,
  PaForbiddenException,
  PaRateLimitException,
  PaSubmissionFailedException,
  PaUnavailableException,
} from "@factur-e/pa-adapter";

import { resolveAuthContext } from "../../auth/context.js";
import { writeAuthAudit } from "../../auth/audit.js";
import { withTransaction } from "../../db/tx.js";
import {
  findIncomingCdarEventsByReceivedInvoiceId,
  insertIncomingCdarEvent,
} from "../../db/repos/incoming_cdar_events.js";
import {
  getReceivedInvoiceById,
  markReceivedInvoiceStatus,
} from "../../db/repos/received_invoices.js";

import { loadPaCustomerContext, toIncomingCdarEventResponse } from "./_shared.js";
import { PostCdarBodySchema, RECEPTION_CDAR_AFNOR } from "./_schemas.js";

/** Libellé stocké en timeline selon le code posé (cohérent glossaire §2.5). */
const CDAR_LABELS: Record<"205" | "210" | "211", string> = {
  "205": "Approuvée",
  "210": "Refusée",
  "211": "Paiement transmis",
};

/**
 * `POST /api/received-invoices/:id/cdar` — pose un statut CDAR sur une
 * facture reçue (205 Approuvée / 210 Refusée, sprint-05). Pipeline :
 *  1. Zod (code 205|210 + reason_code Annexe E si 210 + reason_text si 11).
 *  2. RBAC scope customer (404 si pas owned).
 *  3. `driver.createInvoiceEvent` → POST /v1.beta/invoice_events.
 *  4. Sur succès : INSERT incoming_cdar_events (source 'app') + UPDATE
 *     status_current + audit, en transaction (ADR-009 D4 idempotent).
 *
 * Erreurs (format NC-15 `{message, ...}`) : 422 Zod / PA refuse (4xx),
 * 401 token expiré, 403 forbidden, 429 rate limit, 502 PA indisponible.
 */
export function registerReceivedInvoicesCdarRoute(app: FastifyInstance): void {
  app.post<{ Params: { id: string } }>("/api/received-invoices/:id/cdar", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: "Authentification requise." });
    }

    const parsed = PostCdarBodySchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(422).send({
        message: "Requête de pose de statut invalide.",
        issues: parsed.error.issues,
      });
    }
    const body = parsed.data;

    const row = await getReceivedInvoiceById(app.sqlRead, req.params.id, ctx.customer_id);
    if (row === undefined) {
      return reply.code(404).send({ message: "Facture reçue introuvable." });
    }

    // Pré-condition 211 Paiement transmis : la facture doit être Approuvée
    // (205) au préalable (PRD §5.11 — on ne paie pas une facture non validée).
    if (body.code === "211" && row.status_current !== "accepted_business") {
      return reply.code(422).send({
        message: "Pose 211 impossible : la facture doit d'abord être approuvée (205).",
      });
    }

    const paCtx = await loadPaCustomerContext(app, ctx);
    if (!paCtx.ok) {
      return reply.code(paCtx.code).send({ message: paCtx.message });
    }

    const statusCode = RECEPTION_CDAR_AFNOR[body.code];

    // Pose à la PA d'abord (source de vérité). Sur échec → pas d'écriture
    // BDD (cohérence : on ne marque pas un statut non transmis).
    let event;
    try {
      event = await app.paDriver.createInvoiceEvent(
        { paInvoiceId: row.pa_invoice_id_in, statusCode, reasonCode: body.reason_code },
        paCtx.ctx,
      );
    } catch (e) {
      return handleDriverError(app, reply, e, {
        userId: ctx.user_id,
        customerId: ctx.customer_id,
        receivedInvoiceId: row.id,
        code: body.code,
      });
    }

    // Persistance atomique : event timeline + status + audit.
    await withTransaction(app.sql, async (tx) => {
      await insertIncomingCdarEvent(tx, {
        received_invoice_id: row.id,
        code: event.rawStatusCode,
        label: CDAR_LABELS[body.code],
        occurred_at: event.occurredAt,
        reason_code: body.reason_code ?? null,
        reason_text: body.reason_text ?? null,
        source: "app",
      });
      await markReceivedInvoiceStatus(tx, row.id, event.status);
      await writeAuthAudit(tx, {
        event_type: "received_invoice_cdar_posted",
        success: true,
        user_id: ctx.user_id,
        customer_id: ctx.customer_id,
        ip: req.ip,
        user_agent: req.headers["user-agent"] ?? null,
        metadata: {
          received_invoice_id: row.id,
          pa_invoice_id_in: row.pa_invoice_id_in,
          code: body.code,
          reason_code: body.reason_code ?? null,
          status: event.status,
        },
      });
    });

    // Re-fetch la timeline pour retourner l'event sérialisé (shape BDD
    // complète, post-commit).
    const events = await findIncomingCdarEventsByReceivedInvoiceId(app.sqlRead, row.id);
    const posted = [...events].reverse().find((e) => e.code === event.rawStatusCode);
    return reply.code(200).send({
      cdarEvent: posted !== undefined ? toIncomingCdarEventResponse(posted) : null,
      status_current: event.status,
    });
  });
}

interface DriverErrorMeta {
  userId: string;
  customerId: string;
  receivedInvoiceId: string;
  code: string;
}

/** Mappe une exception driver → HTTP (NC-15) + audit `pa_*` (ADR-009 D5). */
function handleDriverError(
  app: FastifyInstance,
  reply: FastifyReply,
  e: unknown,
  meta: DriverErrorMeta,
): FastifyReply {
  let httpCode = 502;
  let userMessage =
    "Votre Plateforme Agréée est momentanément indisponible. Réessayez dans quelques minutes.";

  if (e instanceof PaAccessTokenExpiredException) {
    httpCode = 401;
    userMessage = "Votre connexion à la Plateforme Agréée a expiré. Reconnectez-vous.";
  } else if (e instanceof InvoiceRejectedXsdException) {
    httpCode = 422;
    userMessage = "La Plateforme Agréée a rejeté la pose de statut.";
  } else if (e instanceof PaForbiddenException) {
    httpCode = 403;
    userMessage = "La Plateforme Agréée refuse cette opération.";
  } else if (e instanceof PaRateLimitException) {
    httpCode = 429;
    userMessage = "Trop de requêtes vers la Plateforme Agréée. Réessayez dans quelques instants.";
  } else if (e instanceof PaUnavailableException || e instanceof PaSubmissionFailedException) {
    httpCode = 502;
  }

  const detail =
    typeof e === "object" &&
    e !== null &&
    "detail" in e &&
    typeof (e as { detail?: unknown }).detail === "string"
      ? (e as { detail: string }).detail
      : null;

  void writeAuthAudit(app.sql, {
    event_type: "received_invoice_cdar_failed",
    success: false,
    user_id: meta.userId,
    customer_id: meta.customerId,
    metadata: {
      received_invoice_id: meta.receivedInvoiceId,
      code: meta.code,
      error: e instanceof Error ? e.message : String(e),
    },
  });

  return reply.code(httpCode).send({
    message: userMessage,
    ...(detail !== null && detail.length > 0 ? { detail } : {}),
  });
}
