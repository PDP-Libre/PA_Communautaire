import type { FastifyInstance } from "fastify";

import { resolveAuthContext } from "../../auth/context.js";
import { getReceivedInvoiceById } from "../../db/repos/received_invoices.js";

import { isPdfContentType, loadPaCustomerContext, requireRoleIn } from "./_shared.js";

/**
 * `GET /api/received-invoices/:id/pdf` — proxy du PDF lisible (Factur-X).
 * RBAC : rôle ∈ {full, deposit_states} (Full+ ; Restreint refusé).
 *
 * Z6 (validé Bruno) : `GET /v1.beta/invoices/:id/download` n'a pas de param
 * `docType` et renvoie le fichier brut. Si la source est un PDF Factur-X →
 * passthrough. Si la source est un XML pur (UBL/CII) → **415** : SuperPDP
 * ne fournit pas de vue lisible via cet endpoint (readable-view conversion
 * reportée sprint-06+, cf. `[NOTE-COWORK]`). Le front gère l'empty state
 * "PDF non disponible — télécharger le XML brut" (brief §6.3).
 */
export function registerReceivedInvoicesPdfRoute(app: FastifyInstance): void {
  app.get<{ Params: { id: string } }>("/api/received-invoices/:id/pdf", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: "Authentification requise." });
    }
    if ((await requireRoleIn(app, reply, ctx, ["full", "deposit_states"])) === null) return;

    const row = await getReceivedInvoiceById(app.sqlRead, req.params.id, ctx.customer_id);
    if (row === undefined) {
      return reply.code(404).send({ message: "Facture reçue introuvable." });
    }

    const paCtx = await loadPaCustomerContext(app, ctx);
    if (!paCtx.ok) {
      return reply.code(paCtx.code).send({ message: paCtx.message });
    }

    let file;
    try {
      file = await app.paDriver.downloadInvoiceFile(
        { paInvoiceId: row.pa_invoice_id_in },
        paCtx.ctx,
      );
    } catch (err) {
      app.log.error({ err, id: row.id }, "[received-invoices/pdf] download failed");
      return reply.code(502).send({
        message: "Impossible de récupérer le document depuis la Plateforme Agréée.",
      });
    }

    if (!isPdfContentType(file.contentType)) {
      return reply.code(415).send({
        message:
          "Cette facture n'a pas de version PDF lisible (format XML pur). Téléchargez le XML original.",
      });
    }

    const filename = `${(row.invoice_number_extracted ?? row.id).replace(/[^\w\-/.]+/g, "_")}.pdf`;
    return reply
      .header("Content-Type", "application/pdf")
      .header("Content-Disposition", `inline; filename="${filename}"`)
      .send(file.bytes);
  });
}
