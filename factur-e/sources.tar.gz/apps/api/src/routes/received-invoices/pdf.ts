import type { FastifyInstance } from "fastify";

import { renderPdfFromXml } from "@factur-e/factur-x-builder";

import { resolveAuthContext } from "../../auth/context.js";
import { getReceivedInvoiceById } from "../../db/repos/received_invoices.js";

import {
  isPdfContentType,
  loadPaCustomerContext,
  requireRoleIn,
  xmlFromDownload,
} from "./_shared.js";

/**
 * `GET /api/received-invoices/:id/pdf` — PDF lisible d'une facture reçue.
 * RBAC : rôle ∈ {full, deposit_states} (Full+ ; Restreint refusé).
 *
 * `GET /v1.beta/invoices/:id/download` (ADR-010 v2) renvoie le fichier brut :
 *  - PDF Factur-X → passthrough.
 *  - XML pur (UBL/CII), pas de `docType=ReadableView` PA → **rendu maison
 *    réduit** via `renderPdfFromXml` (T-CL-RECV-READABLE-VIEW-CONVERSION
 *    sprint-07, Axe B post-W1 ; Z8 : PDF lisible reconstitué, PAS PDF/A-3b).
 *    Fallback transparent → zéro 415 sur la fiche. Si le XML est illisible
 *    (parser échoue), on retombe sur le 415 historique (front propose le XML
 *    brut, brief §6.3).
 */
export function registerReceivedInvoicesPdfRoute(app: FastifyInstance): void {
  app.get<{ Params: { id: string } }>("/api/received-invoices/:id/pdf", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: "Authentification requise." });
    }
    if ((await requireRoleIn(app, reply, ctx, ["full", "deposit_states"])) === null) return;

    const row = await getReceivedInvoiceById(app.sqlRead, req.params.id, ctx.customer_id);
    if (row === undefined) {
      return reply.code(404).send({ message: "Facture reçue introuvable." });
    }

    const paCtx = await loadPaCustomerContext(app, ctx);
    if (!paCtx.ok) {
      return reply.code(paCtx.code).send({ message: paCtx.message });
    }

    let file;
    try {
      file = await app.paDriver.downloadInvoiceFile(
        { paInvoiceId: row.pa_invoice_id_in },
        paCtx.ctx,
      );
    } catch (err) {
      app.log.error({ err, id: row.id }, "[received-invoices/pdf] download failed");
      return reply.code(502).send({
        message: "Impossible de récupérer le document depuis la Plateforme Agréée.",
      });
    }

    const filename = `${(row.invoice_number_extracted ?? row.id).replace(/[^\w\-/.]+/g, "_")}.pdf`;

    // XML pur (pas de PDF lisible PA) → rendu maison réduit (Axe B, Z8).
    if (!isPdfContentType(file.contentType)) {
      const xml = await xmlFromDownload(file);
      if (xml !== null) {
        try {
          const rendered = await renderPdfFromXml(xml);
          return await reply
            .header("Content-Type", "application/pdf")
            .header("Content-Disposition", `inline; filename="${filename}"`)
            .send(rendered);
        } catch (err) {
          app.log.warn({ err, id: row.id }, "[received-invoices/pdf] readable-view render failed");
        }
      }
      // XML illisible / rendu échoué → 415 historique (front propose le XML brut).
      return reply.code(415).send({
        message:
          "Cette facture n'a pas de version PDF lisible (format XML pur). Téléchargez le XML original.",
      });
    }

    return reply
      .header("Content-Type", "application/pdf")
      .header("Content-Disposition", `inline; filename="${filename}"`)
      .send(file.bytes);
  });
}
