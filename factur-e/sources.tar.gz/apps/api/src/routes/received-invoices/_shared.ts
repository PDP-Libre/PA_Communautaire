import type { FastifyInstance, FastifyReply } from "fastify";

import { extractEmbeddedXml } from "@factur-e/factur-x-builder";
import type { CustomerContext, DownloadInvoiceFileResult } from "@factur-e/pa-adapter";

import type { AuthenticatedContext } from "../../auth/context.js";
import { findActivePaConnectionForDisconnectByCustomerId } from "../../db/repos/pa_connections.js";
import type { IncomingCdarEventRow } from "../../db/repos/incoming_cdar_events.js";
import type {
  ReceivedInvoiceRow,
  ReceivedInvoiceCursor,
} from "../../db/repos/received_invoices.js";
import * as usersRepo from "../../db/repos/users.js";
import type { UserRole } from "../../db/repos/users.js";

/**
 * Helpers partagés des routes `/api/received-invoices/*` (T-CL-RECV-API
 * sprint-05 W2) : sérialiseurs BDD → API, RBAC rôle, cursor keyset.
 */

// ─────────────────────────────────────────────────────────────────────
// Sérialiseurs
// ─────────────────────────────────────────────────────────────────────

export interface ReceivedInvoiceListItem {
  id: string;
  seller_siren: string;
  seller_name_cached: string | null;
  supplier_matched: boolean;
  invoice_number_extracted: string | null;
  /** BT-3 type de pièce (380/381/384), cache liste — `null` si indéterminé
   *  au poll (AVOIR-11 / R5). */
  type_code: string | null;
  issue_date: string | null;
  due_date: string | null;
  total_ttc_cents: number | null;
  currency: string | null;
  status_current: string;
  format: string | null;
  read_at: string | null;
  received_at: string;
  /** 209 posée par MOI (acheteur, `source='app'`) plutôt que subie du
   *  fournisseur. Dérivé en liste (`ReceivedInvoiceListRow`) ; `false` sur la
   *  fiche (qui dispose des events bruts). Pilote le libellé du badge statut
   *  liste « Annulée par vous » vs « par le fournisseur ». */
  cancelled_by_self: boolean;
}

const isoDate = (d: Date | null): string | null =>
  d === null ? null : d.toISOString().slice(0, 10);

export function toReceivedInvoiceListItem(
  row: ReceivedInvoiceRow & { cancelled_by_self?: boolean },
): ReceivedInvoiceListItem {
  return {
    id: row.id,
    seller_siren: row.seller_siren,
    seller_name_cached: row.seller_name_cached,
    supplier_matched: row.supplier_matched,
    invoice_number_extracted: row.invoice_number_extracted,
    type_code: row.type_code,
    issue_date: isoDate(row.issue_date),
    due_date: isoDate(row.due_date),
    total_ttc_cents: row.total_ttc_cents,
    currency: row.currency,
    status_current: row.status_current,
    format: row.format,
    read_at: row.read_at?.toISOString() ?? null,
    received_at: row.received_at.toISOString(),
    cancelled_by_self: row.cancelled_by_self ?? false,
  };
}

export interface IncomingCdarEventResponse {
  id: string;
  code: string;
  label: string | null;
  occurred_at: string;
  reason_code: string | null;
  reason_text: string | null;
  source: string;
  created_at: string;
}

export function toIncomingCdarEventResponse(row: IncomingCdarEventRow): IncomingCdarEventResponse {
  return {
    id: row.id,
    code: row.code,
    label: row.label,
    occurred_at: row.occurred_at.toISOString(),
    reason_code: row.reason_code,
    reason_text: row.reason_text,
    source: row.source,
    created_at: row.created_at.toISOString(),
  };
}

// ─────────────────────────────────────────────────────────────────────
// Cursor keyset `(received_at, id)` — encodé `${iso}__${uuid}`
// ─────────────────────────────────────────────────────────────────────

const CURSOR_SEP = "__";

export function encodeCursor(row: ReceivedInvoiceRow): string {
  return `${row.received_at.toISOString()}${CURSOR_SEP}${row.id}`;
}

/** Décode un cursor. Retourne `undefined` si malformé (la route l'ignore
 *  alors → première page, pas d'erreur 400 bloquante). */
export function decodeCursor(raw: string | undefined): ReceivedInvoiceCursor | undefined {
  if (raw === undefined) return undefined;
  const idx = raw.indexOf(CURSOR_SEP);
  if (idx === -1) return undefined;
  const receivedAt = raw.slice(0, idx);
  const id = raw.slice(idx + CURSOR_SEP.length);
  if (receivedAt === "" || id === "" || Number.isNaN(Date.parse(receivedAt))) return undefined;
  return { receivedAt, id };
}

// ─────────────────────────────────────────────────────────────────────
// RBAC — proxy PDF/XML (le contexte auth n'expose pas le rôle, recharge BDD)
// ─────────────────────────────────────────────────────────────────────

/**
 * Recharge le rôle du user et vérifie qu'il est dans `allowed`. Sinon 403
 * + retourne `null` (le caller court-circuite). Mappe les libellés produit
 * (Full/Responsable/Restreint) vers les rôles techniques :
 *  - `full`           = Full
 *  - `deposit_states` = Responsable
 *  - `deposit_simple` = Restreint
 *
 * PDF readable → `['full', 'deposit_states']` (Full+). XML original →
 * `['full']` (Full only — donnée la plus sensible).
 */
export async function requireRoleIn(
  app: FastifyInstance,
  reply: FastifyReply,
  ctx: AuthenticatedContext,
  allowed: readonly UserRole[],
): Promise<UserRole | null> {
  const r = await usersRepo.findActiveUserRoleById(app.sql, ctx.user_id);
  if (r === undefined || !allowed.includes(r.role)) {
    reply.code(403).send({ message: "Permission insuffisante pour accéder à ce document." });
    return null;
  }
  return r.role;
}

// ─────────────────────────────────────────────────────────────────────
// Classification du fichier téléchargé (Z6 — download sans param docType)
// ─────────────────────────────────────────────────────────────────────

export function isPdfContentType(contentType: string): boolean {
  return contentType.toLowerCase().includes("pdf");
}

export function isXmlContentType(contentType: string): boolean {
  return contentType.toLowerCase().includes("xml");
}

/**
 * Extrait le XML structuré d'un fichier téléchargé :
 *  - XML pur (UBL/CII) → passthrough décodé UTF-8.
 *  - PDF Factur-X → extraction de la pièce jointe `factur-x.xml` embarquée.
 *  - autre → `null` (le caller dégrade).
 */
export async function xmlFromDownload(result: DownloadInvoiceFileResult): Promise<string | null> {
  if (isXmlContentType(result.contentType)) {
    return result.bytes.toString("utf8");
  }
  if (isPdfContentType(result.contentType)) {
    return extractEmbeddedXml(new Uint8Array(result.bytes));
  }
  return null;
}

// ─────────────────────────────────────────────────────────────────────
// Contexte PA customer — credentials SecretStore (pattern create.ts)
// ─────────────────────────────────────────────────────────────────────

export type PaContextResult =
  | { ok: true; ctx: CustomerContext }
  | { ok: false; code: number; message: string };

/**
 * Charge la connexion PA active + le bundle de tokens SecretStore et
 * construit un `CustomerContext` (`superpdp-oauth-ac`). Mirroir du pattern
 * `routes/invoices/create.ts` : 503 si non connecté, 401 si token expiré.
 */
export async function loadPaCustomerContext(
  app: FastifyInstance,
  authCtx: AuthenticatedContext,
): Promise<PaContextResult> {
  const conn = await findActivePaConnectionForDisconnectByCustomerId(
    app.sqlRead,
    authCtx.customer_id,
  );
  if (conn === undefined) {
    return {
      ok: false,
      code: 503,
      message:
        "Votre Plateforme Agréée n'est pas connectée. Connectez-vous depuis Paramètres > Connexion à ma Plateforme Agréée.",
    };
  }
  const bundle = await app.secrets.get(conn.secret_ref);
  if (bundle === null) {
    return {
      ok: false,
      code: 401,
      message:
        "Votre connexion à la Plateforme Agréée a expiré. Reconnectez-vous depuis Paramètres > Connexion à ma Plateforme Agréée.",
    };
  }
  return {
    ok: true,
    ctx: {
      customerId: authCtx.customer_id,
      credentials: {
        kind: "superpdp-oauth-ac",
        accessToken: bundle.accessToken,
        refreshToken: bundle.refreshToken,
        accessExpiresAt: new Date(bundle.accessExpiresAt),
        paUserId: null,
      },
    },
  };
}
