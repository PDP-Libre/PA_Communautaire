import type { FastifyInstance } from "fastify";

import { registerReceivedInvoicesCdarRoute } from "./cdar.js";
import { registerReceivedInvoicesGetRoute } from "./get.js";
import { registerReceivedInvoicesListRoute } from "./list.js";
import { registerReceivedInvoicesPdfRoute } from "./pdf.js";
import { registerReceivedInvoicesXmlRoute } from "./xml.js";

/**
 * Routes `/api/received-invoices/*` — L10 Réception (T-CL-RECV-API
 * sprint-05 W2) :
 *   GET  /api/received-invoices            (liste filtrable + cursor)
 *   GET  /api/received-invoices/:id        (fiche + cdarEvents + parsedMetadata)
 *   POST /api/received-invoices/:id/cdar   (pose 205/210, Zod Annexe E)
 *   GET  /api/received-invoices/:id/pdf    (proxy PDF lisible — rôle Full+)
 *   GET  /api/received-invoices/:id/xml    (proxy XML original — rôle Full)
 *
 * Auth résolue par route via `resolveAuthContext` (pattern routes/invoices).
 */
export function registerReceivedInvoicesRoutes(app: FastifyInstance): void {
  registerReceivedInvoicesListRoute(app);
  registerReceivedInvoicesGetRoute(app);
  registerReceivedInvoicesCdarRoute(app);
  registerReceivedInvoicesPdfRoute(app);
  registerReceivedInvoicesXmlRoute(app);
}
