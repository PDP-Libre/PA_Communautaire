import type { FastifyInstance } from "fastify";

import { parseInvoiceMetadata, type InvoiceMetadata } from "@factur-e/factur-x-builder";

import { resolveAuthContext } from "../../auth/context.js";
import { findIncomingCdarEventsByReceivedInvoiceId } from "../../db/repos/incoming_cdar_events.js";
import {
  getReceivedInvoiceById,
  markReceivedInvoiceAsRead,
} from "../../db/repos/received_invoices.js";

import {
  loadPaCustomerContext,
  toIncomingCdarEventResponse,
  toReceivedInvoiceListItem,
  xmlFromDownload,
} from "./_shared.js";

/**
 * `GET /api/received-invoices/:id` — fiche détaillée d'une facture reçue.
 * RBAC scope `customer_id` (404 inter-tenant). Marque la facture lue.
 *
 * Réponse : `{ invoice, supplierMatched, cdarEvents, parsedMetadata }`.
 *  - `invoice` : colonnes BDD (alimentées worker depuis `en_invoice`).
 *  - `parsedMetadata` : **best-effort** (Q3 hybride) — fetch XML on-demand
 *    (`download` → `parseInvoiceMetadata`). Dégrade à `null` si PA
 *    indisponible / XML illisible (brief §6 : la fiche reste affichable
 *    depuis les colonnes BDD, pas de blocage).
 */
export function registerReceivedInvoicesGetRoute(app: FastifyInstance): void {
  app.get<{ Params: { id: string } }>("/api/received-invoices/:id", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: "Authentification requise." });
    }

    const row = await getReceivedInvoiceById(app.sqlRead, req.params.id, ctx.customer_id);
    if (row === undefined) {
      return reply.code(404).send({ message: "Facture reçue introuvable." });
    }

    await markReceivedInvoiceAsRead(app.sql, row.id, ctx.customer_id);
    const cdarEvents = await findIncomingCdarEventsByReceivedInvoiceId(app.sqlRead, row.id);

    const parsedMetadata = await tryParseMetadata(app, ctx, row.pa_invoice_id_in);

    return reply.code(200).send({
      invoice: toReceivedInvoiceListItem(row),
      supplierMatched: row.supplier_matched,
      cdarEvents: cdarEvents.map(toIncomingCdarEventResponse),
      parsedMetadata,
    });
  });
}

/** Best-effort : download + parse. Toute erreur (PA down, XML illisible,
 *  pas de connexion) → `null` (dégradation non bloquante, ADR-009 D1). */
async function tryParseMetadata(
  app: FastifyInstance,
  ctx: { customer_id: string; user_id: string; state: "authenticated" },
  paInvoiceIdIn: string,
): Promise<InvoiceMetadata | null> {
  try {
    const paCtx = await loadPaCustomerContext(app, ctx);
    if (!paCtx.ok) return null;
    const file = await app.paDriver.downloadInvoiceFile({ paInvoiceId: paInvoiceIdIn }, paCtx.ctx);
    const xml = await xmlFromDownload(file);
    if (xml === null) return null;
    return parseInvoiceMetadata(xml);
  } catch (err) {
    app.log.warn(
      { err, pa_invoice_id_in: paInvoiceIdIn },
      "[received-invoices/get] parsedMetadata best-effort failed — dégradation null",
    );
    return null;
  }
}
