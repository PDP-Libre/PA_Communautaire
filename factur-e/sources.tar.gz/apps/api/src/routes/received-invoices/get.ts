import type { FastifyInstance } from "fastify";

import type { CustomerContext } from "@factur-e/pa-adapter";

import { parseInvoiceMetadata, type InvoiceMetadata } from "@factur-e/factur-x-builder";

import { resolveAuthContext } from "../../auth/context.js";
import { findIncomingCdarEventsByReceivedInvoiceId } from "../../db/repos/incoming_cdar_events.js";
import {
  findReceivedCreditNotesBySeller,
  findReceivedInvoiceByPrecedingNumber,
  getReceivedInvoiceById,
  markReceivedInvoiceAsRead,
  type ReceivedInvoiceRow,
} from "../../db/repos/received_invoices.js";

import {
  loadPaCustomerContext,
  toIncomingCdarEventResponse,
  toReceivedInvoiceListItem,
  xmlFromDownload,
} from "./_shared.js";

/**
 * `GET /api/received-invoices/:id` — fiche détaillée d'une facture reçue.
 * RBAC scope `customer_id` (404 inter-tenant). Marque la facture lue.
 *
 * Réponse : `{ invoice, supplierMatched, cdarEvents, parsedMetadata }`.
 *  - `invoice` : colonnes BDD (alimentées worker depuis `en_invoice`).
 *  - `parsedMetadata` : **best-effort** (Q3 hybride) — fetch XML on-demand
 *    (`download` → `parseInvoiceMetadata`). Dégrade à `null` si PA
 *    indisponible / XML illisible (brief §6 : la fiche reste affichable
 *    depuis les colonnes BDD, pas de blocage).
 */
export function registerReceivedInvoicesGetRoute(app: FastifyInstance): void {
  app.get<{ Params: { id: string } }>("/api/received-invoices/:id", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: "Authentification requise." });
    }

    const row = await getReceivedInvoiceById(app.sqlRead, req.params.id, ctx.customer_id);
    if (row === undefined) {
      return reply.code(404).send({ message: "Facture reçue introuvable." });
    }

    await markReceivedInvoiceAsRead(app.sql, row.id, ctx.customer_id);
    const cdarEvents = await findIncomingCdarEventsByReceivedInvoiceId(app.sqlRead, row.id);

    const parsedMetadata = await tryParseMetadata(app, ctx, row.pa_invoice_id_in);

    // AVOIR-10/AVOIR-11 (T-CL-RECV-RECTIF-AFNOR) — si la pièce reçue porte
    // une référence d'origine (avoir 381 OU rectificative 384), on tente de
    // retrouver la facture d'origine dans la Réception (BT-29 seller_siren +
    // BT-25 precedingInvoiceNumber) pour piloter le bandeau de lien (R6) et,
    // pour un avoir, le CTA « Marquer remboursée ».
    const creditNote = await resolveCreditNoteOrigin(app, ctx.customer_id, row, parsedMetadata);

    // R4 (T-CL-RECV-FICHE-FIXS) — sens retour de R6 : depuis une facture
    // d'ORIGINE, liste les rectificatives/avoirs reçus qui la visent (BG-3).
    // Permet à la fiche origine d'afficher le lien vers la pièce qui l'a
    // annulée. Best-effort + scopé tenant (cf. resolveLinkedRectifications).
    const linkedRectifications = await resolveLinkedRectifications(app, ctx, row);

    return reply.code(200).send({
      invoice: toReceivedInvoiceListItem(row),
      supplierMatched: row.supplier_matched,
      cdarEvents: cdarEvents.map(toIncomingCdarEventResponse),
      parsedMetadata,
      creditNote,
      linkedRectifications,
    });
  });
}

interface CreditNoteOrigin {
  /** `true` uniquement pour un avoir 381 (remboursable → CTA « Marquer
   *  remboursée », pose 211). Une rectificative 384 résout aussi son origine
   *  mais n'est PAS un avoir : `false` (oracle rx-384 : pas de CTA 211). */
  readonly isCreditNote: boolean;
  readonly precedingInvoiceNumber: string | null;
  readonly originFound: boolean;
  readonly originReceivedInvoiceId: string | null;
  /** `status_current` de l'origine retrouvée — `null` si non retrouvée. Permet
   *  à la fiche de masquer le CTA « Accepter la rectification » quand l'origine
   *  est déjà annulée (évite la double pose 209). */
  readonly originStatus: string | null;
}

/** Résout le rattachement à la facture d'origine pour une pièce porteuse de
 *  BG-3 — avoir 381 (AVOIR-10) ET rectificative 384 (AVOIR-11/R6). Retourne
 *  `null` si la pièce n'est ni un avoir ni une rectificative (BT-3 ∉ {381,
 *  384}). Le matching alimente le bandeau de lien + `originReceivedInvoiceId`
 *  (cible de la pose 209 côté acheteur, R3). */
async function resolveCreditNoteOrigin(
  app: FastifyInstance,
  customerId: string,
  row: { seller_siren: string },
  parsed: InvoiceMetadata | null,
): Promise<CreditNoteOrigin | null> {
  if (parsed === null) return null;
  const documentType = parsed.document.documentType;
  if (documentType !== "381" && documentType !== "384") return null;
  const isCreditNote = documentType === "381";
  const precedingInvoiceNumber = parsed.document.precedingInvoiceReference?.invoiceNumber ?? null;
  if (precedingInvoiceNumber === null) {
    return {
      isCreditNote,
      precedingInvoiceNumber: null,
      originFound: false,
      originReceivedInvoiceId: null,
      originStatus: null,
    };
  }
  const origin = await findReceivedInvoiceByPrecedingNumber(
    app.sqlRead,
    customerId,
    row.seller_siren,
    precedingInvoiceNumber,
  );
  return {
    isCreditNote,
    precedingInvoiceNumber,
    originStatus: origin?.status_current ?? null,
    originFound: origin !== undefined,
    originReceivedInvoiceId: origin?.id ?? null,
  };
}

/** Best-effort : download + parse. Toute erreur (PA down, XML illisible,
 *  pas de connexion) → `null` (dégradation non bloquante, ADR-009 D1). */
async function tryParseMetadata(
  app: FastifyInstance,
  ctx: { customer_id: string; user_id: string; state: "authenticated" },
  paInvoiceIdIn: string,
): Promise<InvoiceMetadata | null> {
  const paCtx = await loadPaCustomerContext(app, ctx);
  if (!paCtx.ok) return null;
  return parseMetadataForPaId(app, paCtx.ctx, paInvoiceIdIn);
}

/** Download + parse pour un flux PA donné en réutilisant un `CustomerContext`
 *  déjà chargé (évite N `loadPaCustomerContext` quand on parse plusieurs
 *  candidats, R4). Best-effort : toute erreur → `null`. */
async function parseMetadataForPaId(
  app: FastifyInstance,
  paCtx: CustomerContext,
  paInvoiceIdIn: string,
): Promise<InvoiceMetadata | null> {
  try {
    const file = await app.paDriver.downloadInvoiceFile({ paInvoiceId: paInvoiceIdIn }, paCtx);
    const xml = await xmlFromDownload(file);
    if (xml === null) return null;
    return parseInvoiceMetadata(xml);
  } catch (err) {
    app.log.warn(
      { err, pa_invoice_id_in: paInvoiceIdIn },
      "[received-invoices/get] parse best-effort failed — dégradation null",
    );
    return null;
  }
}

/** Une pièce (avoir 381 / rectificative 384) reçue qui vise la facture courante
 *  comme origine (R4). Pilote le bandeau `LinkedInvoiceBanner linkType="origin"`
 *  côté fiche origine. */
interface LinkedRectification {
  readonly receivedInvoiceId: string;
  readonly number: string | null;
  /** BT-3 — "381" (avoir) ou "384" (rectificative). */
  readonly typeCode: string | null;
}

/**
 * Sens retour de R6 (R4, T-CL-RECV-FICHE-FIXS) : pour une facture d'ORIGINE,
 * retrouve les rectificatives/avoirs reçus qui la référencent (BG-3 BT-25). Le
 * numéro d'origine n'étant pas stocké sur la pièce enfant, on confirme le lien
 * par parsing best-effort des seuls candidats (381/384 du même fournisseur) —
 * symétrique de `resolveCreditNoteOrigin`.
 *
 * Gardes coût/correction :
 *  - on ne traite que les origines (BT-3 = 380) ; une pièce 381/384 est un
 *    enfant (son lien est porté par `creditNote`, sens aller) → `null` direct ;
 *  - sans numéro d'origine ou sans candidat, aucun parsing → `null` ;
 *  - scope `customer_id` (invariant tenant) porté par la requête candidats.
 *
 * Retourne `null` (pas `[]`) quand il n'y a aucun lien — la fiche n'affiche le
 * bandeau que si la liste est présente et non vide.
 */
async function resolveLinkedRectifications(
  app: FastifyInstance,
  ctx: { customer_id: string; user_id: string; state: "authenticated" },
  row: ReceivedInvoiceRow,
): Promise<LinkedRectification[] | null> {
  // Une pièce qui est elle-même un avoir/rectificative n'est pas une origine.
  if (row.type_code === "381" || row.type_code === "384") return null;
  const originNumber = row.invoice_number_extracted;
  if (originNumber === null) return null;

  const candidates = await findReceivedCreditNotesBySeller(
    app.sqlRead,
    ctx.customer_id,
    row.seller_siren,
  );
  if (candidates.length === 0) return null;
  if (candidates.length >= 25) {
    app.log.warn(
      { id: row.id, seller_siren: row.seller_siren },
      "[received-invoices/get] R4 candidats plafonnés à 25 — liens potentiellement tronqués",
    );
  }

  const paCtx = await loadPaCustomerContext(app, ctx);
  if (!paCtx.ok) return null;

  const matches = await Promise.all(
    candidates.map(async (candidate): Promise<LinkedRectification | null> => {
      const parsed = await parseMetadataForPaId(app, paCtx.ctx, candidate.pa_invoice_id_in);
      const ref = parsed?.document.precedingInvoiceReference?.invoiceNumber ?? null;
      if (ref !== originNumber) return null;
      return {
        receivedInvoiceId: candidate.id,
        number: candidate.invoice_number_extracted,
        typeCode: candidate.type_code,
      };
    }),
  );
  const linked = matches.filter((m): m is LinkedRectification => m !== null);
  return linked.length > 0 ? linked : null;
}
