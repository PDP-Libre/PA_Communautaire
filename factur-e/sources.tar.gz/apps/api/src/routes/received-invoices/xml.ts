import type { FastifyInstance } from "fastify";

import { resolveAuthContext } from "../../auth/context.js";
import { getReceivedInvoiceById } from "../../db/repos/received_invoices.js";

import { loadPaCustomerContext, requireRoleIn, xmlFromDownload } from "./_shared.js";

/**
 * `GET /api/received-invoices/:id/xml` — proxy du XML original (donnée la
 * plus sensible). RBAC : rôle === `full` uniquement (Responsable + Restreint
 * refusés).
 *
 * Source `GET /v1.beta/invoices/:id/download` (Z6) :
 *  - XML pur (UBL/CII) → passthrough.
 *  - PDF Factur-X → extraction de la pièce jointe `factur-x.xml` embarquée.
 *  - extraction impossible → 502.
 */
export function registerReceivedInvoicesXmlRoute(app: FastifyInstance): void {
  app.get<{ Params: { id: string } }>("/api/received-invoices/:id/xml", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: "Authentification requise." });
    }
    if ((await requireRoleIn(app, reply, ctx, ["full"])) === null) return;

    const row = await getReceivedInvoiceById(app.sqlRead, req.params.id, ctx.customer_id);
    if (row === undefined) {
      return reply.code(404).send({ message: "Facture reçue introuvable." });
    }

    const paCtx = await loadPaCustomerContext(app, ctx);
    if (!paCtx.ok) {
      return reply.code(paCtx.code).send({ message: paCtx.message });
    }

    let xml: string | null;
    try {
      const file = await app.paDriver.downloadInvoiceFile(
        { paInvoiceId: row.pa_invoice_id_in },
        paCtx.ctx,
      );
      xml = await xmlFromDownload(file);
    } catch (err) {
      app.log.error({ err, id: row.id }, "[received-invoices/xml] download failed");
      return reply.code(502).send({
        message: "Impossible de récupérer le document depuis la Plateforme Agréée.",
      });
    }

    if (xml === null) {
      return reply.code(502).send({
        message: "Impossible d'extraire le XML structuré de ce document.",
      });
    }

    const filename = `${(row.invoice_number_extracted ?? row.id).replace(/[^\w\-/.]+/g, "_")}.xml`;
    return reply
      .header("Content-Type", "application/xml")
      .header("Content-Disposition", `attachment; filename="${filename}"`)
      .send(xml);
  });
}
