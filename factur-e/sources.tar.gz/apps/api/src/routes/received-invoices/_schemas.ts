import { REFUSAL_REASON_CODES } from "@factur-e/shared-schemas";
import { z } from "zod";

/**
 * Schémas Zod locaux des routes `/api/received-invoices/*` (T-CL-RECV-API
 * sprint-05 W2). Définis ici (dossier MUTEX de la tâche) plutôt que dans
 * `shared-schemas` pour garder la MR cohésive — promotion vers
 * `shared-schemas` candidate à W2 RECV-WEB (`[NOTE-COWORK]`).
 *
 * `REFUSAL_REASON_CODES` (codes Annexe E) est désormais la source unique
 * `shared-schemas/constants/annexe-e-motifs` (T-CL-RECV-CDAR-MOTIF, finding B,
 * dédup) — re-exporté ici pour back-compat des consommateurs existants.
 */

export { REFUSAL_REASON_CODES } from "@factur-e/shared-schemas";

/** Query `GET /api/received-invoices` — filtres US-RECV-002 (période /
 *  fournisseur / statut) + pagination cursor. Tous optionnels. */
export const ListReceivedQuerySchema = z.object({
  status: z.string().min(1).optional(),
  seller_siren: z.string().min(1).optional(),
  date_from: z.string().min(1).optional(),
  date_to: z.string().min(1).optional(),
  cursor: z.string().min(1).optional(),
  limit: z.coerce.number().int().min(1).max(100).optional(),
});

export type ListReceivedQuery = z.infer<typeof ListReceivedQuerySchema>;

/**
 * Body `POST /api/received-invoices/:id/cdar`. Pose Réception :
 *  - 205 Approuvée / 210 Refusée (sprint-05).
 *  - 211 Paiement transmis Acquéreur (sprint-07 T-CL-RECV-WEB-211-209 — pose
 *    « Marquer payée » facture standard / « Marquer remboursée » avoir reçu
 *    AVOIR-10, même code, distinction visuelle UI seule).
 *  - 209 Annulée par l'Acquéreur (sprint-09 T-CL-RECV-RECTIF-AFNOR — AVOIR-11) :
 *    l'acheteur annule une facture d'origine en acceptant la rectificative 384
 *    qui la remplace. Posé sur l'ORIGINE, pas sur la rectificative. Conforme
 *    AFNOR XP Z12-013 (le PRD v1.9 AVOIR-11 prime sur l'ancienne doctrine
 *    « 209 entrant uniquement »). 212 reste entrant seul (paiement constaté PA).
 * Règles :
 *  - `code` ∈ {205, 209, 210, 211} (212 entrant, non posé par l'Acquéreur).
 *  - si `code === '210'` : `reason_code` ∈ Annexe E obligatoire.
 *  - si `reason_code === '11'` (Autre) : `reason_text` (≤ 500c) obligatoire.
 *  - `reason_code` non applicable à 205 / 209 / 211.
 */
export const PostCdarBodySchema = z
  .object({
    code: z.enum(["205", "209", "210", "211"]),
    reason_code: z.enum(REFUSAL_REASON_CODES).optional(),
    reason_text: z.string().max(500).optional(),
  })
  .superRefine((val, ctx) => {
    if (val.code === "210" && val.reason_code === undefined) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["reason_code"],
        message: "Le motif de refus (reason_code) est obligatoire pour une facture refusée (210).",
      });
    }
    if (val.code !== "210" && val.reason_code !== undefined) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["reason_code"],
        message: "reason_code n'est applicable qu'à un refus (210).",
      });
    }
    if (
      val.reason_code === "11" &&
      (val.reason_text === undefined || val.reason_text.trim() === "")
    ) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["reason_text"],
        message: "Le texte libre (reason_text) est obligatoire pour le motif 11 (Autre).",
      });
    }
  });

export type PostCdarBody = z.infer<typeof PostCdarBodySchema>;

/** Mapping code Réception → code AFNOR natif PA (`POST /v1.beta/invoice_events`). */
export const RECEPTION_CDAR_AFNOR: Record<"205" | "209" | "210" | "211", string> = {
  "205": "fr:205",
  "209": "fr:209",
  "210": "fr:210",
  "211": "fr:211",
};
