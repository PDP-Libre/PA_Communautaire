import { z } from "zod";

/**
 * Schémas Zod locaux des routes `/api/received-invoices/*` (T-CL-RECV-API
 * sprint-05 W2). Définis ici (dossier MUTEX de la tâche) plutôt que dans
 * `shared-schemas` pour garder la MR cohésive — promotion vers
 * `shared-schemas` candidate à W2 RECV-WEB (`[NOTE-COWORK]`).
 */

/** Query `GET /api/received-invoices` — filtres US-RECV-002 (période /
 *  fournisseur / statut) + pagination cursor. Tous optionnels. */
export const ListReceivedQuerySchema = z.object({
  status: z.string().min(1).optional(),
  seller_siren: z.string().min(1).optional(),
  date_from: z.string().min(1).optional(),
  date_to: z.string().min(1).optional(),
  cursor: z.string().min(1).optional(),
  limit: z.coerce.number().int().min(1).max(100).optional(),
});

export type ListReceivedQuery = z.infer<typeof ListReceivedQuerySchema>;

/** 11 codes motifs de refus 210 — Annexe E PRD v1.6. */
export const REFUSAL_REASON_CODES = [
  "01", // Données fournisseur erronées
  "02", // Données acheteur erronées
  "03", // Montant incorrect
  "04", // Taux de TVA incorrect
  "05", // Prestation non conforme
  "06", // Produit non conforme
  "07", // Doublon
  "08", // Conditions de paiement inadéquates
  "09", // Référence commande manquante ou erronée
  "10", // Bon de livraison manquant
  "11", // Autre (texte libre obligatoire)
] as const;

/**
 * Body `POST /api/received-invoices/:id/cdar`. Réception sprint-05 :
 * pose 205 (Approuvée) ou 210 (Refusée). Règles :
 *  - `code` ∈ {205, 210} (211/209/212 hors scope sprint-05).
 *  - si `code === '210'` : `reason_code` ∈ Annexe E obligatoire.
 *  - si `reason_code === '11'` (Autre) : `reason_text` (≤ 500c) obligatoire.
 */
export const PostCdarBodySchema = z
  .object({
    code: z.enum(["205", "210"]),
    reason_code: z.enum(REFUSAL_REASON_CODES).optional(),
    reason_text: z.string().max(500).optional(),
  })
  .superRefine((val, ctx) => {
    if (val.code === "210" && val.reason_code === undefined) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["reason_code"],
        message: "Le motif de refus (reason_code) est obligatoire pour une facture refusée (210).",
      });
    }
    if (val.code === "205" && val.reason_code !== undefined) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["reason_code"],
        message: "reason_code n'est pas applicable à une approbation (205).",
      });
    }
    if (
      val.reason_code === "11" &&
      (val.reason_text === undefined || val.reason_text.trim() === "")
    ) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["reason_text"],
        message: "Le texte libre (reason_text) est obligatoire pour le motif 11 (Autre).",
      });
    }
  });

export type PostCdarBody = z.infer<typeof PostCdarBodySchema>;

/** Mapping code Réception → code AFNOR natif PA (`POST /v1.beta/invoice_events`). */
export const RECEPTION_CDAR_AFNOR: Record<"205" | "210", string> = {
  "205": "fr:205",
  "210": "fr:210",
};
