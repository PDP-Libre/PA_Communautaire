import type { FastifyInstance } from "fastify";

import { resolveAuthContext } from "../../auth/context.js";
import { findActiveReceivedInvoicesByCustomerId } from "../../db/repos/received_invoices.js";

import {
  decodeCursor,
  encodeCursor,
  toReceivedInvoiceListItem,
  type ReceivedInvoiceListItem,
} from "./_shared.js";
import { ListReceivedQuerySchema } from "./_schemas.js";

/**
 * `GET /api/received-invoices` — liste paginée (cursor keyset) des factures
 * reçues du customer. Filtres US-RECV-002 : `status`, `seller_siren`,
 * `date_from`/`date_to` (sur `received_at`). Tri `received_at DESC`.
 *
 * Réponse : `{ items, nextCursor }`. `nextCursor` est `null` quand il n'y a
 * plus de page (consommé par W2 RECV-WEB infinite scroll / pagination).
 */
export function registerReceivedInvoicesListRoute(app: FastifyInstance): void {
  app.get("/api/received-invoices", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: "Authentification requise." });
    }

    const parsed = ListReceivedQuerySchema.safeParse(req.query);
    if (!parsed.success) {
      return reply
        .code(400)
        .send({ message: "Paramètres invalides.", issues: parsed.error.issues });
    }
    const q = parsed.data;
    const limit = q.limit ?? 50;

    const rows = await findActiveReceivedInvoicesByCustomerId(app.sqlRead, ctx.customer_id, {
      status: q.status,
      sellerSiren: q.seller_siren,
      dateFrom: q.date_from,
      dateTo: q.date_to,
      cursor: decodeCursor(q.cursor),
      limit,
    });

    // Keyset : on a demandé `limit + 1`. S'il y a débordement → page
    // suivante existe, `nextCursor` = cursor de la dernière ligne retenue.
    const hasMore = rows.length > limit;
    const page = hasMore ? rows.slice(0, limit) : rows;
    const lastRow = page[page.length - 1];
    const nextCursor = hasMore && lastRow !== undefined ? encodeCursor(lastRow) : null;

    const items: ReceivedInvoiceListItem[] = page.map(toReceivedInvoiceListItem);
    return reply.code(200).send({ items, nextCursor });
  });
}
