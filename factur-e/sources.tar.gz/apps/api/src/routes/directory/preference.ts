import type { FastifyInstance } from "fastify";

import { DirectoryPreferenceBodySchema } from "@factur-e/shared-schemas";

import { resolveAuthContext } from "../../auth/context.js";
import * as preferencesRepo from "../../db/repos/buyer_address_preferences.js";

/**
 * `POST /api/directory/preference` — mémorise le choix utilisateur
 * d'une adresse Peppol parmi un `found_multi_address`. Le `customer_id`
 * vient de l'auth context, pas du body.
 *
 * En T-CL-10 cet endpoint stocke uniquement, sans application au 2e
 * search (différé sprint-04+ — décision Bruno chat : on déroge à
 * l'optim 2e affichage, sélecteur ré-affiché à chaque recherche). La
 * persistance reste utile downstream pour l'émission BT-49 (sprint-04+)
 * et pour ré-activer l'optim plus tard sans nouveau modèle.
 *
 * Cf. PRD v1.4 §5.5 critère 4 + plan T-CL-10 sprint-03.
 */

const NEUTRAL = "Vérifiez les informations.";

export function registerDirectoryPreferenceRoute(app: FastifyInstance): void {
  app.post("/api/directory/preference", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: "Authentification requise." });
    }

    const parsed = DirectoryPreferenceBodySchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ message: NEUTRAL });
    }
    const { buyer_siren, party_id } = parsed.data;

    await preferencesRepo.upsertBuyerAddressPreference(app.sql, {
      customerId: ctx.customer_id,
      buyerSiren: buyer_siren,
      preferredPartyId: party_id,
    });

    return reply.code(204).send();
  });
}
