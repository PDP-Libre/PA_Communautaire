import type { FastifyInstance } from "fastify";
import type postgres from "postgres";

import type { DirectoryCompany } from "@factur-e/pa-adapter";
import {
  DirectorySearchBodySchema,
  type DirectoryAddressDto,
  type DirectoryCompanyDto,
  type DirectorySearchResponse,
} from "@factur-e/shared-schemas";

import { resolveAuthContext } from "../../auth/context.js";
import * as directoryCacheRepo from "../../db/repos/directory_cache.js";
import type { CachedDirectoryAddress, DirectoryCachedRow } from "../../db/repos/directory_cache.js";

/**
 * `POST /api/directory/search` — recherche un acheteur par SIREN dans
 * l'annuaire SuperPDP.
 *
 * Cache local à TTL différencié (NC-4 sprint-05) :
 *  - **positifs** (`found_one_address`, `found_multi_address`) → 7 j.
 *    L'adresse Peppol d'une entreprise inscrite est stable ; on évite
 *    de retaper SuperPDP à chaque recherche (anti-burst rate-limit).
 *  - **négatifs/volatils** (`not_found`, `disabled`) → 15 min. Un SIREN
 *    pas encore inscrit (réforme sept. 2026) ou une adresse désactivée
 *    peut basculer "atteignable" rapidement ; un faux négatif ne doit
 *    pas bloquer l'utilisateur pendant des jours (cf. recette sprint-04).
 *  - `unavailable` n'est jamais caché (transient, propagé tel quel).
 *
 * Auth : tout user authentifié (les 3 rôles `full`, `deposit_simple`,
 * `deposit_states` ont besoin de l'annuaire pour émettre B2B —
 * décision Bruno chat).
 *
 * Cf. PRD v1.4 §5.5 + plan T-CL-10 sprint-03 + NC-4 trace sprint-04 §3.
 */

const CACHE_TTL_POSITIVE_SECONDS = 7 * 24 * 60 * 60;
const CACHE_TTL_NEGATIVE_SECONDS = 15 * 60;
const NEUTRAL = "Vérifiez le SIREN saisi.";

export function registerDirectorySearchRoute(app: FastifyInstance): void {
  app.post("/api/directory/search", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: "Authentification requise." });
    }

    const parsed = DirectorySearchBodySchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ message: NEUTRAL });
    }
    const { siren } = parsed.data;

    // 1. Cache hit fresh → respond from cache.
    const cached = await directoryCacheRepo.findFreshDirectoryCacheBySiren(app.sqlRead, siren);
    if (cached !== undefined) {
      return reply.code(200).send(buildResponseFromCache(cached));
    }

    // 2. Cache miss → ask the adapter. SuperPDP annuaire ne requiert pas
    //    d'auth (security: [] côté OpenAPI) — `paCtx` ignoré côté
    //    SuperPDPDriver.searchSiren. Maintenu pour cohérence multi-PA
    //    (ADR-012 D1 — méthode Core uniforme ; EsaLink V2 utilisera le
    //    `paCtx.credentials` distributeur).
    const paCtx = {
      customerId: "directory-search-no-customer",
      credentials: {
        kind: "superpdp-oauth-cc" as const,
        accessToken: "",
        accessExpiresAt: new Date(0),
      },
    };
    const result = await app.paDriver.searchSiren({ siren }, paCtx);

    // 3. unavailable → propagate without caching (transient).
    if (result.kind === "unavailable") {
      const body: DirectorySearchResponse = { kind: "unavailable" };
      return reply.code(200).send(body);
    }

    // 4. Stable outcomes → cache + respond.
    if (result.kind === "not_found") {
      await directoryCacheRepo.upsertDirectoryCache(app.sql, {
        siren,
        payload: null,
        addresses: [],
        ttlSeconds: CACHE_TTL_NEGATIVE_SECONDS,
      });
      const body: DirectorySearchResponse = { kind: "not_found" };
      return reply.code(200).send(body);
    }

    if (result.kind === "disabled") {
      await directoryCacheRepo.upsertDirectoryCache(app.sql, {
        siren,
        payload: companyToJson(result.company),
        addresses: [],
        ttlSeconds: CACHE_TTL_NEGATIVE_SECONDS,
      });
      const body: DirectorySearchResponse = {
        kind: "disabled",
        company: companyToDto(result.company),
      };
      return reply.code(200).send(body);
    }

    if (result.kind === "found_one_address") {
      const addresses: CachedDirectoryAddress[] = [result.address];
      await directoryCacheRepo.upsertDirectoryCache(app.sql, {
        siren,
        payload: companyToJson(result.company),
        addresses,
        ttlSeconds: CACHE_TTL_POSITIVE_SECONDS,
      });
      const body: DirectorySearchResponse = {
        kind: "found_one_address",
        company: companyToDto(result.company),
        address: toAddressDto(result.address),
      };
      return reply.code(200).send(body);
    }

    // result.kind === "found_multi_address"
    await directoryCacheRepo.upsertDirectoryCache(app.sql, {
      siren,
      payload: companyToJson(result.company),
      addresses: result.addresses,
      ttlSeconds: CACHE_TTL_POSITIVE_SECONDS,
    });
    const body: DirectorySearchResponse = {
      kind: "found_multi_address",
      company: companyToDto(result.company),
      addresses: result.addresses.map(toAddressDto),
    };
    return reply.code(200).send(body);
  });
}

/** Reconstruit l'outcome `DirectorySearchResponse` à partir d'une row
 *  `directory_cache` fresh. Mirroir inverse du switch `result.kind`. */
function buildResponseFromCache(row: DirectoryCachedRow): DirectorySearchResponse {
  if (row.payload === null) return { kind: "not_found" };
  const company = jsonToCompanyDto(row.payload);
  if (row.addresses.length === 0) {
    return { kind: "disabled", company };
  }
  if (row.addresses.length === 1) {
    const only = row.addresses[0];
    if (only === undefined) return { kind: "disabled", company };
    return { kind: "found_one_address", company, address: toAddressDto(only) };
  }
  return {
    kind: "found_multi_address",
    company,
    addresses: row.addresses.map(toAddressDto),
  };
}

/** `DirectoryCompany` est une interface (pas d'index signature), donc TS la
 *  refuse comme `JSONValue` au moment du `sql.json(...)`. On passe par un
 *  cast typé `postgres.JSONValue` — la forme est structurellement valide. */
function companyToJson(c: DirectoryCompany): postgres.JSONValue {
  return c as unknown as postgres.JSONValue;
}

function companyToDto(c: DirectoryCompany): DirectoryCompanyDto {
  return {
    number: c.number,
    formal_name: c.formal_name,
    address: c.address,
    postcode: c.postcode,
    city: c.city,
    country: c.country,
  };
}

/** Le payload cache vient en `Record<string, unknown>` JSONB ; on revalide
 *  les champs un par un pour rester strict (et garder tomber sur `""` si
 *  le shape a changé entre deux versions). */
function jsonToCompanyDto(c: Record<string, unknown>): DirectoryCompanyDto {
  return {
    number: typeof c.number === "string" ? c.number : "",
    formal_name: typeof c.formal_name === "string" ? c.formal_name : "",
    address: typeof c.address === "string" ? c.address : "",
    postcode: typeof c.postcode === "string" ? c.postcode : "",
    city: typeof c.city === "string" ? c.city : "",
    country: typeof c.country === "string" ? c.country : "",
  };
}

function toAddressDto(a: CachedDirectoryAddress): DirectoryAddressDto {
  return {
    party_id: a.party_id,
    scheme_id: a.scheme_id,
    is_active: a.is_active,
    pa_name: a.pa_name,
  };
}
