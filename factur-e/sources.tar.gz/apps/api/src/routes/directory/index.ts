import type { FastifyInstance } from "fastify";

import { registerDirectoryPreferenceRoute } from "./preference.js";
import { registerDirectorySearchRoute } from "./search.js";

export function registerDirectoryRoutes(app: FastifyInstance): void {
  registerDirectorySearchRoute(app);
  registerDirectoryPreferenceRoute(app);
}
