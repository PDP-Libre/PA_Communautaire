import "@fastify/cookie";

import type { FastifyInstance } from "fastify";
import type { LoginResponse } from "@factur-e/shared-schemas";

import { writeAuthAudit } from "../../auth/audit.js";
import { REFRESH_SESSION_COOKIE, setRefreshSessionCookie } from "../../auth/cookies.js";
import {
  signAccessToken,
  signRefreshToken,
  TTL_SECONDS,
  verifyRefreshToken,
} from "../../auth/jwt.js";
import * as sessionsRepo from "../../db/repos/sessions.js";
import * as usersRepo from "../../db/repos/users.js";

const NEUTRAL = "Vérifiez vos informations.";

/**
 * `POST /auth/refresh` — exchange the HttpOnly refresh cookie for a new
 * access token. The browser sends the cookie automatically; the SPA only
 * needs to know the new `access_token` to attach as `Authorization: Bearer`
 * on subsequent calls.
 *
 * Refresh-token rotation: every successful call mints a *new* refresh JWT
 * for the same `session_id` and resets the cookie. The session row in
 * `sessions` is unchanged. Stolen-token reuse detection is out of scope
 * here (would need a `last_refreshed_at` column + an anomaly threshold).
 */
export function registerRefreshRoute(app: FastifyInstance): void {
  app.post("/auth/refresh", async (req, reply) => {
    const cookie = req.cookies[REFRESH_SESSION_COOKIE];
    if (typeof cookie !== "string" || cookie.length === 0) {
      return reply.code(401).send({ message: NEUTRAL });
    }

    let payload;
    try {
      payload = await verifyRefreshToken(cookie);
    } catch {
      return reply.code(401).send({ message: NEUTRAL });
    }

    // Session must still exist + not revoked + not expired. Pure reads,
    // app.sqlRead (alias of app.sql in MVP, replica V2 ready).
    const session = await sessionsRepo.findActiveSessionForRefresh(app.sqlRead, {
      sessionId: payload.session_id,
      userId: payload.user_id,
    });
    if (session === undefined) {
      return reply.code(401).send({ message: NEUTRAL });
    }

    // User must still be active (not soft-deleted).
    const user = await usersRepo.findActiveUserCustomerById(app.sqlRead, payload.user_id);
    if (user === undefined) {
      return reply.code(401).send({ message: NEUTRAL });
    }

    // Rotate the refresh cookie + emit a fresh access token.
    const newRefresh = await signRefreshToken({
      session_id: payload.session_id,
      user_id: payload.user_id,
    });
    setRefreshSessionCookie(reply, newRefresh);

    const accessToken = await signAccessToken({
      user_id: user.id,
      customer_id: user.customer_id,
    });

    await writeAuthAudit(app.sql, {
      event_type: "session_refreshed",
      success: true,
      user_id: user.id,
      customer_id: user.customer_id,
      ip: req.ip,
      user_agent: req.headers["user-agent"] ?? null,
      metadata: { session_id: payload.session_id },
    });

    const body: LoginResponse = {
      access_token: accessToken,
      expires_in: TTL_SECONDS.access,
    };
    return reply.code(200).send(body);
  });
}
