import type { FastifyInstance } from "fastify";

import { registerInviteSecondaryEmailSetRoute } from "./invite-secondary-email-set.js";
import { registerInviteSecondaryEmailVerifyRoute } from "./invite-secondary-email-verify.js";
import { registerLoginRoute } from "./login.js";
import { registerLogoutRoute } from "./logout.js";
import { registerMeRoute } from "./me.js";
import { registerMfaResetViaRecoveryRoute } from "./mfa-reset-via-recovery.js";
import { registerMfaSetupRoutes } from "./mfa-setup.js";
import { registerMfaVerifyRoute } from "./mfa-verify.js";
import { registerPasswordResetCompleteRoute } from "./password-reset-complete.js";
import { registerPasswordResetRequestRoute } from "./password-reset-request.js";
import { registerRefreshRoute } from "./refresh.js";
import { registerPhase1EmailVerifyRoute } from "./phase1/email-verify.js";
import { registerPhase1EmailVerifyTriggerRoute } from "./phase1/email-verify-trigger.js";
import { registerPhase1MfaChooseRoute } from "./phase1/mfa-choose.js";
import { registerPhase1MfaVerifyRoute } from "./phase1/mfa-verify.js";
import { registerPhase1RecoveryCodesAckRoute } from "./phase1/recovery-codes-ack.js";
import { registerPhase1SecondaryEmailSetRoute } from "./phase1/secondary-email-set.js";
import { registerPhase1SecondaryEmailVerifyRoute } from "./phase1/secondary-email-verify.js";
import { registerPhase1SirenRoute } from "./phase1/siren.js";
import { registerPhase1SiretRoute } from "./phase1/siret.js";
import { registerSignupRoute } from "./signup.js";

export function registerAuthRoutes(app: FastifyInstance): void {
  registerSignupRoute(app);
  registerLoginRoute(app);
  registerLogoutRoute(app);
  registerRefreshRoute(app);
  registerMeRoute(app);
  registerMfaVerifyRoute(app);
  registerMfaResetViaRecoveryRoute(app);
  registerMfaSetupRoutes(app);
  registerPasswordResetRequestRoute(app);
  registerPasswordResetCompleteRoute(app);
  // T-CL-15 sprint-03 — invitee onboarding secondary email funnel.
  registerInviteSecondaryEmailSetRoute(app);
  registerInviteSecondaryEmailVerifyRoute(app);
  registerPhase1EmailVerifyTriggerRoute(app);
  registerPhase1EmailVerifyRoute(app);
  registerPhase1MfaChooseRoute(app);
  registerPhase1MfaVerifyRoute(app);
  registerPhase1RecoveryCodesAckRoute(app);
  registerPhase1SecondaryEmailSetRoute(app);
  registerPhase1SecondaryEmailVerifyRoute(app);
  registerPhase1SirenRoute(app);
  registerPhase1SiretRoute(app);
}
