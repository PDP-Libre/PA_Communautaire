import type { FastifyInstance } from "fastify";

import { PasswordResetCompleteBodySchema } from "@factur-e/shared-schemas";

import { hashPassword } from "../../auth/argon2.js";
import { writeAuthAudit } from "../../auth/audit.js";
import { passwordHashMarker, verifyMagicLink } from "../../auth/magic-link.js";
import * as usersRepo from "../../db/repos/users.js";

const NEUTRAL = "Lien invalide ou expiré.";

/**
 * Brief §5.4 — consume the password-reset magic link and set a new password.
 *
 * Single-use enforcement: the JWT carries `hash_marker` of the user's
 * stored `password_hash` at issuance time. After this route updates the
 * password hash, any further verify for the same token fails the marker
 * comparison → 410.
 *
 * Brief §5.4 also requires a "password changed" notification email; we
 * fire it after the update.
 *
 * Per Bruno's note (T-CL-03 §3d), reset password does NOT touch MFA —
 * the MFA flag and recovery codes are preserved.
 */
export function registerPasswordResetCompleteRoute(app: FastifyInstance): void {
  app.post("/auth/password-reset/complete", async (req, reply) => {
    const parsed = PasswordResetCompleteBodySchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ message: "Vérifiez vos informations." });
    }
    const { token, password } = parsed.data;
    const ip = req.ip;
    const ua = req.headers["user-agent"] ?? null;

    let payload;
    try {
      payload = await verifyMagicLink(token);
    } catch {
      return reply.code(410).send({ message: NEUTRAL });
    }
    if (payload.purpose !== "password_reset") {
      return reply.code(410).send({ message: NEUTRAL });
    }

    const user = await usersRepo.findActiveUserCredentialsById(app.sql, payload.target_id);
    if (user === undefined) {
      return reply.code(410).send({ message: NEUTRAL });
    }
    if (passwordHashMarker(user.password_hash) !== payload.hash_marker) {
      // Token was already used (or password changed otherwise).
      return reply.code(410).send({ message: NEUTRAL });
    }

    const newHash = await hashPassword(password);
    await usersRepo.markPasswordHash(app.sql, user.id, newHash);

    // Notification email (best-effort; failure should not roll back the
    // reset). Brief §5.4 doesn't mandate the notification block path.
    try {
      await app.email.send({
        to: payload.email,
        purpose: "password_changed",
        payload: {},
      });
    } catch {
      // swallowed
    }

    await writeAuthAudit(app.sql, {
      event_type: "password_reset_complete",
      success: true,
      user_id: user.id,
      ip,
      user_agent: ua,
      metadata: { email: payload.email },
    });

    return reply.code(204).send();
  });
}
