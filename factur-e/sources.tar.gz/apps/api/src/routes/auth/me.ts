import type { FastifyInstance } from "fastify";
import type { AuthMeResponse } from "@factur-e/shared-schemas";

import { resolveAuthContext } from "../../auth/context.js";
import { SignupStepSchema } from "@factur-e/shared-schemas";
import * as signupPendingRepo from "../../db/repos/signup_pending.js";
import * as usersRepo from "../../db/repos/users.js";

export function registerMeRoute(app: FastifyInstance): void {
  app.get("/auth/me", async (req, reply) => {
    const ctx = await resolveAuthContext(req);

    if (ctx.state === "anon") {
      return reply.code(401).send({ message: "Non authentifié." });
    }

    if (ctx.state === "pending") {
      // Pure read → app.sqlRead (alias of app.sql in MVP, replica V2 ready).
      const row = await signupPendingRepo.findActivePendingDigestById(
        app.sqlRead,
        ctx.signup_pending_id,
      );
      if (row === undefined) {
        // Cookie referenced a row that's been deleted (phase 1 finalized
        // or expired). Treat as anonymous.
        return reply.code(401).send({ message: "Non authentifié." });
      }
      const step = SignupStepSchema.safeParse(row.current_step);
      const current_step = step.success ? step.data : "siren";
      const body: AuthMeResponse = {
        state: "pending",
        current_step,
        email: row.email,
      };
      return reply.code(200).send(body);
    }

    // Pure read → app.sqlRead.
    const row = await usersRepo.findActiveAuthMeJoinByUserId(app.sqlRead, ctx.user_id);
    if (row === undefined) {
      return reply.code(401).send({ message: "Non authentifié." });
    }

    const body: AuthMeResponse = {
      state: "authenticated",
      user: {
        id: row.user_id,
        email: row.email,
        role: row.role,
        can_purchase: row.can_purchase,
        email_verified_at:
          row.email_verified_at === null ? null : row.email_verified_at.toISOString(),
        mfa_mode: row.mfa_mode,
        mfa_reset_required: row.mfa_reset_required,
        // T-CL-15 sprint-03 — boolean (pas l'email lui-même, PII). SPA
        // combine ce flag + `mfa_reset_required` pour router le funnel invité.
        secondary_email_set: row.secondary_email_verified_at !== null,
      },
      customer: {
        id: row.customer_id,
        siren: row.siren,
        legal_name: row.legal_name,
        trading_name: row.trading_name,
        primary_color: row.primary_color,
        profile_unverified: row.profile_unverified,
      },
    };
    return reply.code(200).send(body);
  });
}
