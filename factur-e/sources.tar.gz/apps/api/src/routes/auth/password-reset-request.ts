import type { FastifyInstance } from "fastify";

import { PasswordResetRequestBodySchema } from "@factur-e/shared-schemas";

import { writeAuthAudit } from "../../auth/audit.js";
import { isEmailRecentlyThrottled } from "../../auth/email-throttle.js";
import { passwordHashMarker, signMagicLink } from "../../auth/magic-link.js";
import * as usersRepo from "../../db/repos/users.js";

function webBaseUrl(): string {
  return process.env.WEB_BASE_URL ?? "http://localhost:5174";
}

/**
 * Brief §5.4 password reset request. **Anti-énumération** : returns 204
 * unconditionally. If a matching user exists, a magic link is mailed; if
 * not, nothing is sent (the response is identical).
 */
export function registerPasswordResetRequestRoute(app: FastifyInstance): void {
  app.post("/auth/password-reset/request", async (req, reply) => {
    const parsed = PasswordResetRequestBodySchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(204).send();
    }
    const email = parsed.data.email.toLowerCase();
    const ip = req.ip;
    const ua = req.headers["user-agent"] ?? null;

    const user = await usersRepo.findActiveUserCredentialsByEmail(app.sql, email);

    if (user === undefined) {
      // Silent no-op + audit so support can investigate brute scans.
      await writeAuthAudit(app.sql, {
        event_type: "password_reset_request",
        success: false,
        ip,
        user_agent: ua,
        metadata: { email, reason: "no_user" },
      });
      return reply.code(204).send();
    }

    // Email throttle (T-CL-02 sprint-03) : if this email already received
    // a transactional message in the last 5 min, audit the attempt and
    // 204 silently — same shape as a no_user case (anti-énumération).
    if (await isEmailRecentlyThrottled(app.sql, email)) {
      await writeAuthAudit(app.sql, {
        event_type: "password_reset_request",
        success: false,
        user_id: user.id,
        ip,
        user_agent: ua,
        metadata: { email, reason: "throttled" },
      });
      return reply.code(204).send();
    }

    const token = await signMagicLink({
      purpose: "password_reset",
      target_id: user.id,
      email,
      hash_marker: passwordHashMarker(user.password_hash),
    });
    const url = `${webBaseUrl()}/reset-password?token=${encodeURIComponent(token)}`;
    await app.email.send({
      to: email,
      purpose: "password_reset",
      payload: { magic_link: url },
    });
    await writeAuthAudit(app.sql, {
      event_type: "password_reset_request",
      success: true,
      user_id: user.id,
      ip,
      user_agent: ua,
      metadata: { email },
    });

    return reply.code(204).send();
  });
}
