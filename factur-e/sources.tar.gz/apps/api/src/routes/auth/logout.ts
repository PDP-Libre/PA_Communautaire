import "@fastify/cookie";

import type { FastifyInstance } from "fastify";

import { writeAuthAudit } from "../../auth/audit.js";
import {
  REFRESH_SESSION_COOKIE,
  clearRefreshSessionCookie,
  clearSignupSessionCookie,
} from "../../auth/cookies.js";
import { verifyRefreshToken } from "../../auth/jwt.js";
import * as sessionsRepo from "../../db/repos/sessions.js";

export function registerLogoutRoute(app: FastifyInstance): void {
  app.post("/auth/logout", async (req, reply) => {
    const refreshCookie = req.cookies[REFRESH_SESSION_COOKIE];

    if (typeof refreshCookie === "string" && refreshCookie.length > 0) {
      try {
        const { session_id, user_id } = await verifyRefreshToken(refreshCookie);
        await sessionsRepo.revokeSessionById(app.sql, session_id);
        await writeAuthAudit(app.sql, {
          event_type: "logout",
          success: true,
          user_id,
          ip: req.ip,
          user_agent: req.headers["user-agent"] ?? null,
          metadata: { session_id },
        });
      } catch {
        // Invalid or expired cookie — still wipe the cookies and 204.
      }
    }

    clearRefreshSessionCookie(reply);
    clearSignupSessionCookie(reply);
    return reply.code(204).send();
  });
}
