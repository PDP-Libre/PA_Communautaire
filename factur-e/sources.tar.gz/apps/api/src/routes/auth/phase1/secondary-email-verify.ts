import "@fastify/cookie";

import type { FastifyInstance } from "fastify";

import { Phase1SecondaryEmailVerifyBodySchema } from "@factur-e/shared-schemas";

import { writeAuthAudit } from "../../../auth/audit.js";
import { resolveAuthContext } from "../../../auth/context.js";
import { consumeOtp } from "../../../auth/otp.js";
import * as signupPendingRepo from "../../../db/repos/signup_pending.js";

const NEUTRAL = "Vérifiez vos informations.";

/**
 * Phase 1 step 5b (brief §6.5b): verify the OTP sent to the secondary
 * email. On success, set `secondary_email_verified_at` and advance
 * `current_step` to `mfa_choice`.
 */
export function registerPhase1SecondaryEmailVerifyRoute(app: FastifyInstance): void {
  app.post("/auth/phase1/secondary-email/verify", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "pending") {
      return reply.code(401).send({ message: NEUTRAL });
    }
    const parsed = Phase1SecondaryEmailVerifyBodySchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ message: NEUTRAL });
    }
    const ip = req.ip;
    const ua = req.headers["user-agent"] ?? null;

    const row = await signupPendingRepo.findActivePendingSecondaryEmailById(
      app.sql,
      ctx.signup_pending_id,
    );
    if (!row?.secondary_email) {
      return reply.code(401).send({ message: NEUTRAL });
    }

    const result = await consumeOtp(
      app.sql,
      { signup_pending_id: row.id },
      "phase1_secondary_verify",
      parsed.data.code,
    );
    if (result.kind !== "ok") {
      await writeAuthAudit(app.sql, {
        event_type: "mfa_failed",
        success: false,
        ip,
        user_agent: ua,
        metadata: {
          signup_pending_id: row.id,
          phase: "phase1_secondary_email",
          consume_kind: result.kind,
        },
      });
      return reply.code(401).send({ message: NEUTRAL });
    }

    await signupPendingRepo.markPendingSecondaryEmailVerified(app.sql, row.id);
    await writeAuthAudit(app.sql, {
      event_type: "email_secondary_verified",
      success: true,
      ip,
      user_agent: ua,
      metadata: { signup_pending_id: row.id, secondary_email: row.secondary_email },
    });

    return reply.code(204).send();
  });
}
