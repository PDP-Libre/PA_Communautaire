import "@fastify/cookie";

import type { FastifyInstance } from "fastify";

import {
  RecoveryCodesAckBodySchema,
  type RecoveryCodesAckResponse,
} from "@factur-e/shared-schemas";

import { writeAuthAudit } from "../../../auth/audit.js";
import { resolveAuthContext } from "../../../auth/context.js";
import { clearSignupSessionCookie, setRefreshSessionCookie } from "../../../auth/cookies.js";
import { finalizePhase1 } from "../../../auth/phase1.js";
import * as signupPendingRepo from "../../../db/repos/signup_pending.js";

const NEUTRAL = "Vérifiez vos informations.";

export function registerPhase1RecoveryCodesAckRoute(app: FastifyInstance): void {
  app.post("/auth/phase1/recovery-codes/ack", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "pending") {
      return reply.code(401).send({ message: NEUTRAL });
    }
    const parsed = RecoveryCodesAckBodySchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ message: NEUTRAL });
    }
    const ip = req.ip;
    const ua = req.headers["user-agent"] ?? null;

    // Optimistically mark the ack — finalizePhase1 will validate the rest of
    // the prerequisites (email verified, secondary email verified, MFA setup
    // completed). If something is missing the row stays put with the ack
    // timestamp and the user can resume from the missing step.
    await signupPendingRepo.markPendingRecoveryCodesAcked(app.sql, ctx.signup_pending_id);

    const result = await finalizePhase1(app.sql, ctx.signup_pending_id, {
      ip,
      user_agent: ua,
    });

    if (result.kind === "success") {
      setRefreshSessionCookie(reply, result.refresh_token);
      clearSignupSessionCookie(reply);
      const body: RecoveryCodesAckResponse = {
        access_token: result.access_token,
        expires_in: result.access_ttl_seconds,
      };
      return reply.code(200).send(body);
    }

    if (result.kind === "decoy" || result.kind === "expired") {
      // Anti-énumération + cookie chasing: identical neutral 401.
      clearSignupSessionCookie(reply);
      return reply.code(401).send({ message: NEUTRAL });
    }

    // incomplete — surface the step the frontend should resume on.
    await writeAuthAudit(app.sql, {
      event_type: "signup_incomplete",
      success: false,
      ip,
      user_agent: ua,
      metadata: {
        signup_pending_id: ctx.signup_pending_id,
        current_step: result.current_step,
        missing: result.missing,
      },
    });
    return reply.code(400).send({ message: "Étape manquante.", current_step: result.current_step });
  });
}
