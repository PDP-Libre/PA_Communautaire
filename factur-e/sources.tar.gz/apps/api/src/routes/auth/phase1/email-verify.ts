import type { FastifyInstance } from "fastify";
import { z } from "zod";

import { writeAuthAudit } from "../../../auth/audit.js";
import { verifyMagicLink } from "../../../auth/magic-link.js";
import * as signupPendingRepo from "../../../db/repos/signup_pending.js";

const NEUTRAL = "Vérifiez vos informations.";

const BodySchema = z.object({ token: z.string().min(1) }).strict();

/**
 * Consume the magic link sent at signup. Stateless — single-use is
 * enforced by the `email_verified_at` column (already set → return 410
 * gone, not a 200, so the frontend can show "lien déjà utilisé" rather
 * than a misleading success).
 */
export function registerPhase1EmailVerifyRoute(app: FastifyInstance): void {
  app.post("/auth/phase1/email/verify", async (req, reply) => {
    const parsed = BodySchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ message: NEUTRAL });
    }
    const { token } = parsed.data;
    const ip = req.ip;
    const ua = req.headers["user-agent"] ?? null;

    let payload;
    try {
      payload = await verifyMagicLink(token);
    } catch {
      return reply.code(410).send({ message: "Lien invalide ou expiré." });
    }
    if (payload.purpose !== "email_verify") {
      return reply.code(410).send({ message: "Lien invalide ou expiré." });
    }

    const row = await signupPendingRepo.findPendingEmailVerifyContextById(
      app.sql,
      payload.target_id,
    );
    if (row === undefined || row.expires_at.getTime() < Date.now()) {
      return reply.code(410).send({ message: "Lien invalide ou expiré." });
    }
    if (row.email_verified_at !== null) {
      // Already consumed.
      return reply.code(410).send({ message: "Lien invalide ou expiré." });
    }

    // Brief design §5.1 : §6.2 SIREN + §6.3 SIRET doivent être complétés
    // AVANT la consommation du magic link (§6.4 = écran d'attente après
    // SIRET). Si l'utilisateur clique le lien trop tôt, on refuse plutôt
    // que de sauter §6.2/§6.3 silencieusement.
    if (row.current_step === "siren" || row.current_step === "siret") {
      await writeAuthAudit(app.sql, {
        event_type: "email_verify_premature",
        success: false,
        ip,
        user_agent: ua,
        metadata: { signup_pending_id: row.id, current_step: row.current_step },
      });
      return reply.code(409).send({
        message: "Reprenez l'inscription depuis le navigateur, votre SIREN n'est pas encore saisi.",
        current_step: row.current_step,
      });
    }

    await signupPendingRepo.markPendingEmailVerified(app.sql, row.id);
    await writeAuthAudit(app.sql, {
      event_type: "email_verified",
      success: true,
      ip,
      user_agent: ua,
      metadata: { signup_pending_id: row.id, email: payload.email },
    });

    return reply.code(200).send({ state: "verified", next_step: "secondary_email" });
  });
}
