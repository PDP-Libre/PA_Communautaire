import "@fastify/cookie";

import type { FastifyInstance } from "fastify";
import type postgres from "postgres";

import { SiretChooseBodySchema } from "@factur-e/shared-schemas";

import { writeAuthAudit } from "../../../auth/audit.js";
import { resolveAuthContext } from "../../../auth/context.js";
import * as signupPendingRepo from "../../../db/repos/signup_pending.js";

const NEUTRAL = "Vérifiez vos informations.";

interface PersistedAddress {
  street: string;
  zip: string;
  city: string;
  country_code: string;
}

interface PersistedEstablishment {
  siret: string;
  is_siege?: boolean;
  address?: PersistedAddress;
}

/**
 * Phase 1 §6.3 — user picks an establishment from the INSEE list, OR
 * provides a manual address. We persist the chosen address into
 * `signup_pending.customer_data_prefilled.address` so finalize can write
 * it straight to `customers.address`.
 *
 * `kind = 'siret'` resolves the address from the establishments cached
 * at the previous step (`/auth/phase1/siren`). No second INSEE call.
 */
export function registerPhase1SiretRoute(app: FastifyInstance): void {
  app.post("/auth/phase1/siret", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "pending") {
      return reply.code(401).send({ message: NEUTRAL });
    }
    const parsed = SiretChooseBodySchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ message: NEUTRAL });
    }
    const ip = req.ip;
    const ua = req.headers["user-agent"] ?? null;

    const row = await signupPendingRepo.findActivePendingSiretContextById(
      app.sql,
      ctx.signup_pending_id,
    );
    if (!row?.siren) {
      return reply.code(409).send({ message: "SIREN non sélectionné." });
    }
    const prefilled = row.customer_data_prefilled ?? {};

    let siret: string | null = null;
    let address: PersistedAddress;
    let legalNameOverride: string | null = null;

    if (parsed.data.kind === "siret") {
      siret = parsed.data.siret;
      if (!siret.startsWith(row.siren)) {
        return reply.code(400).send({ message: "SIRET incohérent avec le SIREN." });
      }
      const establishments = Array.isArray(prefilled.establishments)
        ? (prefilled.establishments as PersistedEstablishment[])
        : [];
      const match = establishments.find((e) => e.siret === siret);
      if (!match?.address) {
        return reply
          .code(400)
          .send({ message: "SIRET introuvable parmi les établissements proposés." });
      }
      address = match.address;
    } else {
      address = parsed.data.address;
      // Diffusion partielle : INSEE a masqué la dénomination, l'utilisateur
      // l'a saisie à la main sur l'écran §6.3. On l'écrase dans le prefilled.
      if (parsed.data.legal_name !== undefined) {
        legalNameOverride = parsed.data.legal_name;
      }
    }

    const merged = {
      ...prefilled,
      address,
      ...(legalNameOverride !== null ? { legal_name: legalNameOverride } : {}),
      // Marqueur consommé par finalizePhase1 → customers.profile_unverified.
      // Vrai dès que l'utilisateur saisit l'adresse à la main : soit choix
      // explicite "Saisir manuellement", soit forçage par diffusion partielle
      // INSEE (legalNameOverride non null).
      is_manual: parsed.data.kind === "manual",
    } as unknown as postgres.JSONValue;
    await signupPendingRepo.markPendingSiretChosen(app.sql, row.id, {
      siret,
      prefilled: merged,
    });
    await writeAuthAudit(app.sql, {
      event_type: "onboarding_siret_chosen",
      success: true,
      ip,
      user_agent: ua,
      metadata: {
        signup_pending_id: row.id,
        siret,
        manual_address: parsed.data.kind === "manual",
      },
    });

    return reply.code(204).send();
  });
}
