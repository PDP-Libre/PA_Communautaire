import "@fastify/cookie";

import type { FastifyInstance } from "fastify";

import { MfaChooseBodySchema, type MfaChooseResponse } from "@factur-e/shared-schemas";

import { writeAuthAudit } from "../../../auth/audit.js";
import { resolveAuthContext } from "../../../auth/context.js";
import { encrypt } from "../../../auth/encryption.js";
import { issueOtp } from "../../../auth/otp.js";
import { generateTotpSecret, totpQrSvgFromUri, totpUriFromSecret } from "../../../auth/totp.js";
import * as signupPendingRepo from "../../../db/repos/signup_pending.js";

const NEUTRAL = "Vérifiez vos informations.";

export function registerPhase1MfaChooseRoute(app: FastifyInstance): void {
  app.post("/auth/phase1/mfa/choose", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "pending") {
      return reply.code(401).send({ message: NEUTRAL });
    }

    const parsed = MfaChooseBodySchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ message: NEUTRAL });
    }
    const { mode } = parsed.data;
    const ip = req.ip;
    const ua = req.headers["user-agent"] ?? null;

    const row = await signupPendingRepo.findActivePendingEmailById(app.sql, ctx.signup_pending_id);
    if (row === undefined) {
      return reply.code(401).send({ message: NEUTRAL });
    }

    if (mode === "totp") {
      const secret = generateTotpSecret();
      const uri = totpUriFromSecret(secret, row.email);
      const qrSvg = await totpQrSvgFromUri(uri);
      const ciphertext = encrypt(secret);

      await signupPendingRepo.markPendingMfaChoiceTotp(app.sql, row.id, ciphertext);
      await writeAuthAudit(app.sql, {
        event_type: "mfa_setup",
        success: true,
        ip,
        user_agent: ua,
        metadata: { signup_pending_id: row.id, mode: "totp" },
      });
      const body: MfaChooseResponse = { mode: "totp", otpauth_uri: uri, qr_svg: qrSvg };
      return reply.code(200).send(body);
    }

    // email mode
    const otp = await issueOtp(app.sql, { signup_pending_id: row.id }, "phase1_mfa_setup");
    await app.email.send({
      to: row.email,
      purpose: "phase1_mfa_setup_otp",
      payload: { otp_code: otp.code },
    });
    await signupPendingRepo.markPendingMfaChoiceEmail(app.sql, row.id);
    await writeAuthAudit(app.sql, {
      event_type: "mfa_setup",
      success: true,
      ip,
      user_agent: ua,
      metadata: { signup_pending_id: row.id, mode: "email", otp_id: otp.id },
    });
    const body: MfaChooseResponse = { mode: "email", otp_sent_to: row.email };
    return reply.code(200).send(body);
  });
}
