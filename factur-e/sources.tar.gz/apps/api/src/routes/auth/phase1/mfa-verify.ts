import "@fastify/cookie";

import type { FastifyInstance } from "fastify";

import { Phase1MfaVerifyBodySchema, type Phase1MfaVerifyResponse } from "@factur-e/shared-schemas";

import { writeAuthAudit } from "../../../auth/audit.js";
import { resolveAuthContext } from "../../../auth/context.js";
import { decrypt } from "../../../auth/encryption.js";
import { consumeOtp } from "../../../auth/otp.js";
import { generateRecoveryCodes } from "../../../auth/recovery.js";
import { verifyTotpCode } from "../../../auth/totp.js";
import * as signupPendingRepo from "../../../db/repos/signup_pending.js";

const NEUTRAL = "Vérifiez vos informations.";

export function registerPhase1MfaVerifyRoute(app: FastifyInstance): void {
  app.post("/auth/phase1/mfa/verify", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "pending") {
      return reply.code(401).send({ message: NEUTRAL });
    }
    const parsed = Phase1MfaVerifyBodySchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ message: NEUTRAL });
    }
    const { code } = parsed.data;
    const ip = req.ip;
    const ua = req.headers["user-agent"] ?? null;

    const row = await signupPendingRepo.findActivePendingMfaContextById(
      app.sql,
      ctx.signup_pending_id,
    );
    if (!row?.mfa_mode_choice) {
      return reply.code(401).send({ message: NEUTRAL });
    }

    let verified = false;
    if (row.mfa_mode_choice === "totp") {
      if (row.mfa_secret_pending === null) {
        return reply.code(401).send({ message: NEUTRAL });
      }
      const secret = decrypt(row.mfa_secret_pending);
      verified = verifyTotpCode(secret, code);
    } else {
      // mfa_mode_choice === "email" — null was filtered above by the
      // !row?.mfa_mode_choice guard.
      const result = await consumeOtp(
        app.sql,
        { signup_pending_id: row.id },
        "phase1_mfa_setup",
        code,
      );
      verified = result.kind === "ok";
    }

    if (!verified) {
      await writeAuthAudit(app.sql, {
        event_type: "mfa_failed",
        success: false,
        ip,
        user_agent: ua,
        metadata: {
          signup_pending_id: row.id,
          phase: "phase1",
          mode: row.mfa_mode_choice,
        },
      });
      return reply.code(401).send({ message: NEUTRAL });
    }

    const { plain, hashed } = await generateRecoveryCodes();
    await signupPendingRepo.markPendingMfaSetupCompleted(app.sql, row.id, hashed);
    await writeAuthAudit(app.sql, {
      event_type: "mfa_verified",
      success: true,
      ip,
      user_agent: ua,
      metadata: { signup_pending_id: row.id, phase: "phase1", mode: row.mfa_mode_choice },
    });

    const body: Phase1MfaVerifyResponse = { recovery_codes: plain };
    return reply.code(200).send(body);
  });
}
