import "@fastify/cookie";

import type { FastifyInstance } from "fastify";
import type postgres from "postgres";
import {
  isValidSirenLuhn,
  SirenLookupBodySchema,
  type PublicEtablissement,
  type SirenLookupResponse,
} from "@factur-e/shared-schemas";

import { writeAuthAudit } from "../../../auth/audit.js";
import { resolveAuthContext } from "../../../auth/context.js";
import * as signupPendingRepo from "../../../db/repos/signup_pending.js";
import { juridiqueLabel } from "../../../onboarding/juridique-codes.js";
import { resolveSiren } from "../../../onboarding/service.js";

const NEUTRAL = "Vérifiez vos informations.";

export function registerPhase1SirenRoute(app: FastifyInstance): void {
  app.post("/auth/phase1/siren", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "pending") {
      return reply.code(401).send({ message: NEUTRAL });
    }
    const parsed = SirenLookupBodySchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ message: NEUTRAL });
    }
    const { siren } = parsed.data;
    const ip = req.ip;
    const ua = req.headers["user-agent"] ?? null;

    if (!isValidSirenLuhn(siren)) {
      return reply.code(200).send({ kind: "not_found" } satisfies SirenLookupResponse);
    }

    const result = await resolveSiren(app.sql, app.insee, siren);

    await writeAuthAudit(app.sql, {
      event_type: "onboarding_siren_lookup",
      success: result.kind === "found",
      ip,
      user_agent: ua,
      metadata: {
        signup_pending_id: ctx.signup_pending_id,
        siren,
        kind: result.kind,
      },
    });

    if (result.kind === "found") {
      // Persist on signup_pending so the next step (siret) and the
      // ultimate finalize can read the prefilled customer data without
      // requerying INSEE.
      const prefilledPayload = {
        legal_name: result.payload.unite.legal_name,
        juridique_code: result.payload.unite.juridique_code,
        naf_code: result.payload.unite.naf_code,
        creation_date: result.payload.unite.creation_date,
        // Persist establishments so /auth/phase1/siret can resolve the
        // chosen SIRET → address without a second INSEE call.
        establishments: result.payload.etablissements,
        raw: result.payload.raw,
      } as unknown as postgres.JSONValue;
      await signupPendingRepo.markPendingSirenChosen(app.sql, ctx.signup_pending_id, {
        siren,
        prefilled: prefilledPayload,
      });

      // Sirene returns establishments unsorted; the brief §6.3 wants
      // siège first, then by creation_date desc.
      const establishments: PublicEtablissement[] = [...result.payload.etablissements]
        .sort((a, b) => {
          if (a.is_siege !== b.is_siege) return a.is_siege ? -1 : 1;
          const da = a.creation_date ?? "";
          const db = b.creation_date ?? "";
          return db.localeCompare(da);
        })
        .map((e) => ({
          siret: e.siret,
          is_siege: e.is_siege,
          creation_date: e.creation_date,
          address: e.address,
        }));

      const body: SirenLookupResponse = {
        kind: "found",
        legal_name: result.payload.unite.legal_name,
        juridique_code: result.payload.unite.juridique_code,
        juridique_label: juridiqueLabel(result.payload.unite.juridique_code),
        naf_code: result.payload.unite.naf_code,
        creation_date: result.payload.unite.creation_date,
        establishments,
      };
      return reply.code(200).send(body);
    }

    if (result.kind === "already_bound") {
      return reply.code(200).send({ kind: "already_bound" } satisfies SirenLookupResponse);
    }
    if (result.kind === "not_found") {
      return reply.code(200).send({ kind: "not_found" } satisfies SirenLookupResponse);
    }
    if (result.kind === "restricted") {
      return reply.code(200).send({ kind: "restricted" } satisfies SirenLookupResponse);
    }
    return reply.code(503).send({ kind: "unavailable" } satisfies SirenLookupResponse);
  });
}
