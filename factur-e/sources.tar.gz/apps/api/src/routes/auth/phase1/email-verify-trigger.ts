import "@fastify/cookie";

import type { FastifyInstance } from "fastify";

import { writeAuthAudit } from "../../../auth/audit.js";
import { resolveAuthContext } from "../../../auth/context.js";
import {
  signMagicLink,
  passwordHashMarker,
  type MagicLinkPurpose,
} from "../../../auth/magic-link.js";
import * as signupPendingRepo from "../../../db/repos/signup_pending.js";
import * as usersRepo from "../../../db/repos/users.js";

const NEUTRAL = "Vérifiez vos informations.";

function webBaseUrl(): string {
  return process.env.WEB_BASE_URL ?? "http://localhost:5174";
}

/**
 * Re-trigger the magic link sent at signup. Brief §6.4 — "Renvoyer le lien"
 * with a 60s cooldown (cooldown enforced front-side; rate limiter on this
 * route would be the back-side guarantee — out of scope T-CL-04 minimal).
 *
 * Anti-énumération: if the signup_pending row is a decoy (email already a
 * confirmed user), we send a password-reset link to the existing user
 * instead of a verify link. The HTTP response is identical either way.
 */
export function registerPhase1EmailVerifyTriggerRoute(app: FastifyInstance): void {
  app.post("/auth/phase1/email/verify-trigger", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "pending") {
      return reply.code(401).send({ message: NEUTRAL });
    }
    const ip = req.ip;
    const ua = req.headers["user-agent"] ?? null;

    const row = await signupPendingRepo.findActivePendingEmailDecoyById(
      app.sql,
      ctx.signup_pending_id,
    );
    if (row === undefined) {
      return reply.code(401).send({ message: NEUTRAL });
    }

    if (row.is_decoy) {
      const user = await usersRepo.findActiveUserCredentialsByEmail(app.sql, row.email);
      if (user !== undefined) {
        const purpose: MagicLinkPurpose = "password_reset";
        const token = await signMagicLink({
          purpose,
          target_id: user.id,
          email: row.email,
          hash_marker: passwordHashMarker(user.password_hash),
        });
        const url = `${webBaseUrl()}/reset-password?token=${encodeURIComponent(token)}`;
        await app.email.send({
          to: row.email,
          purpose: "password_reset",
          payload: { magic_link: url },
        });
        await writeAuthAudit(app.sql, {
          event_type: "password_reset_request",
          success: true,
          user_id: user.id,
          ip,
          user_agent: ua,
          metadata: { email: row.email, via: "signup_decoy" },
        });
      }
      // If the decoy reference doesn't resolve to a user (race condition),
      // we still respond 200 — anti-enumeration.
      return reply.code(204).send();
    }

    const token = await signMagicLink({
      purpose: "email_verify",
      target_id: row.id,
      email: row.email,
      hash_marker: "",
    });
    const url = `${webBaseUrl()}/onboarding/email-verify?token=${encodeURIComponent(token)}`;
    await app.email.send({
      to: row.email,
      purpose: "phase1_email_verify_otp",
      payload: { magic_link: url },
    });
    await writeAuthAudit(app.sql, {
      event_type: "email_verify_link_sent",
      success: true,
      ip,
      user_agent: ua,
      metadata: { signup_pending_id: row.id, email: row.email },
    });
    return reply.code(204).send();
  });
}
