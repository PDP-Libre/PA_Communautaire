import "@fastify/cookie";

import type { FastifyInstance } from "fastify";

import { Phase1SecondaryEmailSetBodySchema } from "@factur-e/shared-schemas";

import { writeAuthAudit } from "../../../auth/audit.js";
import { resolveAuthContext } from "../../../auth/context.js";
import { issueOtp } from "../../../auth/otp.js";
import * as signupPendingRepo from "../../../db/repos/signup_pending.js";

const NEUTRAL = "Vérifiez vos informations.";

/**
 * Phase 1 step 5a (brief §6.5a): set the secondary email and trigger an
 * OTP to it. The OTP is verified at §6.5b (`secondary-email/verify`).
 *
 * Validation: secondary email must differ from the principal email.
 */
export function registerPhase1SecondaryEmailSetRoute(app: FastifyInstance): void {
  app.post("/auth/phase1/secondary-email/set", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "pending") {
      return reply.code(401).send({ message: NEUTRAL });
    }
    const parsed = Phase1SecondaryEmailSetBodySchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ message: NEUTRAL });
    }
    const candidate = parsed.data.email.toLowerCase();
    const ip = req.ip;
    const ua = req.headers["user-agent"] ?? null;

    const row = await signupPendingRepo.findActivePendingEmailById(app.sql, ctx.signup_pending_id);
    if (row === undefined) {
      return reply.code(401).send({ message: NEUTRAL });
    }

    if (candidate === row.email) {
      return reply.code(400).send({
        message: "L'email de secours doit être différent de l'email principal.",
      });
    }

    await signupPendingRepo.markPendingSecondaryEmailSet(app.sql, row.id, candidate);

    const otp = await issueOtp(app.sql, { signup_pending_id: row.id }, "phase1_secondary_verify");
    await app.email.send({
      to: candidate,
      purpose: "phase1_secondary_email_verify_otp",
      payload: { otp_code: otp.code },
    });
    await writeAuthAudit(app.sql, {
      event_type: "email_secondary_changed",
      success: true,
      ip,
      user_agent: ua,
      metadata: { signup_pending_id: row.id, secondary_email: candidate, otp_id: otp.id },
    });

    return reply.code(204).send();
  });
}
