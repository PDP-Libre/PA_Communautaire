import type { FastifyInstance } from "fastify";

import { MfaResetViaRecoveryBodySchema } from "@factur-e/shared-schemas";

import { writeAuthAudit } from "../../auth/audit.js";
import { resolveAuthContext } from "../../auth/context.js";
import { findMatchingRecoveryHash } from "../../auth/recovery.js";
import * as usersRepo from "../../db/repos/users.js";

const NEUTRAL = "Vérifiez vos informations.";

/**
 * Authenticated user with valid bearer + a recovery code → consume the
 * code, clear MFA secret, mark `mfa_reset_required=true`. Used when the
 * user wants to deliberately bypass MFA (lost authenticator, etc.) from
 * within an already authenticated session — distinct from the login
 * recovery flow which lives in `/auth/mfa/verify`.
 */
export function registerMfaResetViaRecoveryRoute(app: FastifyInstance): void {
  app.post("/auth/mfa/reset-via-recovery", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: NEUTRAL });
    }
    const parsed = MfaResetViaRecoveryBodySchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ message: NEUTRAL });
    }
    const { recovery_code } = parsed.data;
    const ip = req.ip;
    const ua = req.headers["user-agent"] ?? null;

    const user = await usersRepo.findActiveUserRecoveryCodesById(app.sql, ctx.user_id);
    if (user === undefined) {
      return reply.code(401).send({ message: NEUTRAL });
    }

    const idx = await findMatchingRecoveryHash(user.recovery_codes_hashed ?? [], recovery_code);
    if (idx < 0) {
      await writeAuthAudit(app.sql, {
        event_type: "mfa_failed",
        success: false,
        user_id: ctx.user_id,
        customer_id: ctx.customer_id,
        ip,
        user_agent: ua,
        metadata: { phase: "reset_via_recovery", reason: "no_match" },
      });
      return reply.code(401).send({ message: NEUTRAL });
    }

    const remaining = (user.recovery_codes_hashed ?? []).filter((_, i) => i !== idx);
    await usersRepo.consumeRecoveryCode(app.sql, ctx.user_id, remaining);
    await writeAuthAudit(app.sql, {
      event_type: "mfa_recovery_used",
      success: true,
      user_id: ctx.user_id,
      customer_id: ctx.customer_id,
      ip,
      user_agent: ua,
      metadata: { phase: "reset_via_recovery", remaining: remaining.length },
    });

    return reply.code(204).send();
  });
}
