import { randomUUID } from "node:crypto";

import type { FastifyInstance } from "fastify";
import {
  LoginBodySchema,
  type LoginMfaRequiredResponse,
  type LoginMfaResetRequiredResponse,
  type LoginResponse,
} from "@factur-e/shared-schemas";

import { verifyPassword } from "../../auth/argon2.js";
import { writeAuthAudit } from "../../auth/audit.js";
import { setRefreshSessionCookie } from "../../auth/cookies.js";
import {
  signAccessToken,
  signMfaChallengeToken,
  signMfaResetToken,
  signRefreshToken,
  TTL_SECONDS,
} from "../../auth/jwt.js";
import { isEmailLockedOut, isIpLockedOut } from "../../auth/lockout.js";
import { issueOtp } from "../../auth/otp.js";
import * as usersRepo from "../../db/repos/users.js";
import { insertSession } from "../../db/tx.js";

const NEUTRAL_AUTH_ERROR = "Vérifiez vos informations.";

export function registerLoginRoute(app: FastifyInstance): void {
  app.post("/auth/login", async (req, reply) => {
    const parsed = LoginBodySchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ message: NEUTRAL_AUTH_ERROR });
    }
    const { email, password } = parsed.data;
    const normalizedEmail = email.toLowerCase();
    const ip = req.ip;
    const ua = req.headers["user-agent"] ?? null;

    // Two independent lockout gates (T-CL-02 sprint-03) :
    //  - per-email : 5 fails / 30 min on the targeted account
    //  - per-IP    : 20 fails / 30 min from this IP across any email
    // Either match returns the same neutral 401 (anti-énumération).
    if (await isIpLockedOut(app.sql, ip)) {
      await writeAuthAudit(app.sql, {
        event_type: "login_failed",
        success: false,
        ip,
        user_agent: ua,
        metadata: { email: normalizedEmail, reason: "ip_lockout" },
      });
      return reply.code(401).send({ message: NEUTRAL_AUTH_ERROR });
    }
    if (await isEmailLockedOut(app.sql, normalizedEmail)) {
      await writeAuthAudit(app.sql, {
        event_type: "login_failed",
        success: false,
        ip,
        user_agent: ua,
        metadata: { email: normalizedEmail, reason: "lockout" },
      });
      return reply.code(401).send({ message: NEUTRAL_AUTH_ERROR });
    }

    const user = await usersRepo.findActiveUserByEmail(app.sql, normalizedEmail);

    if (user === undefined) {
      await writeAuthAudit(app.sql, {
        event_type: "login_failed",
        success: false,
        ip,
        user_agent: ua,
        metadata: { email: normalizedEmail, reason: "no_user" },
      });
      return reply.code(401).send({ message: NEUTRAL_AUTH_ERROR });
    }

    const ok = await verifyPassword(user.password_hash, password);
    if (!ok) {
      await writeAuthAudit(app.sql, {
        event_type: "login_failed",
        success: false,
        user_id: user.id,
        customer_id: user.customer_id,
        ip,
        user_agent: ua,
        metadata: { email: normalizedEmail, reason: "bad_password" },
      });
      return reply.code(401).send({ message: NEUTRAL_AUTH_ERROR });
    }

    // Branch on MFA state.
    if (user.mfa_mode === "email" || user.mfa_mode === "totp") {
      // Issue MFA challenge — no session, no cookies, no access token.
      // Email mode also fires off an OTP through the email sender.
      if (user.mfa_mode === "email") {
        const otp = await issueOtp(app.sql, { user_id: user.id }, "login_mfa");
        await app.email.send({
          to: normalizedEmail,
          purpose: "login_mfa_otp",
          payload: { otp_code: otp.code },
        });
      }

      const challengeToken = await signMfaChallengeToken({
        user_id: user.id,
        customer_id: user.customer_id,
        mfa_mode: user.mfa_mode,
      });

      await writeAuthAudit(app.sql, {
        event_type: "login_password_ok_mfa_pending",
        success: true,
        user_id: user.id,
        customer_id: user.customer_id,
        ip,
        user_agent: ua,
        metadata: { mfa_mode: user.mfa_mode },
      });

      const body: LoginMfaRequiredResponse = {
        state: "mfa_required",
        mfa_challenge_token: challengeToken,
        mfa_mode: user.mfa_mode,
      };
      return reply.code(200).send(body);
    }

    // mfa_mode === "none"
    if (user.mfa_reset_required) {
      // User came back from a recovery-code consume → must re-setup MFA
      // before getting a real access token. Issue a short-lived reset
      // token instead.
      const resetToken = await signMfaResetToken({ user_id: user.id });
      await writeAuthAudit(app.sql, {
        event_type: "login_mfa_reset_required",
        success: true,
        user_id: user.id,
        customer_id: user.customer_id,
        ip,
        user_agent: ua,
      });
      const body: LoginMfaResetRequiredResponse = {
        state: "mfa_reset_required",
        reset_token: resetToken,
      };
      return reply.code(200).send(body);
    }

    // Invariant: a Full role with mfa_mode='none' && mfa_reset_required=false
    // is data corruption (PRD §5.1 US-AUTH-003: MFA mandatory for Full).
    if (user.role === "full") {
      await writeAuthAudit(app.sql, {
        event_type: "invariant_violation",
        success: false,
        user_id: user.id,
        customer_id: user.customer_id,
        ip,
        user_agent: ua,
        metadata: {
          email: normalizedEmail,
          invariant: "full_user_without_mfa",
        },
      });
      return reply.code(500).send({ message: "Erreur interne." });
    }

    // Non-Full user with `none`: issue access directly (AUTH-3 — MFA
    // optional for non-Full).
    const sessionId = randomUUID();
    await insertSession(app.sql, { id: sessionId, userId: user.id, ip, userAgent: ua });

    const accessToken = await signAccessToken({
      user_id: user.id,
      customer_id: user.customer_id,
    });
    const refreshToken = await signRefreshToken({
      session_id: sessionId,
      user_id: user.id,
    });
    setRefreshSessionCookie(reply, refreshToken);

    await usersRepo.markLastLogin(app.sql, user.id);
    await writeAuthAudit(app.sql, {
      event_type: "login_success",
      success: true,
      user_id: user.id,
      customer_id: user.customer_id,
      ip,
      user_agent: ua,
      metadata: { session_id: sessionId },
    });

    const body: LoginResponse = {
      access_token: accessToken,
      expires_in: TTL_SECONDS.access,
    };
    return reply.code(200).send(body);
  });
}
