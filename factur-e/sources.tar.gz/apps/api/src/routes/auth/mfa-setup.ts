import { randomUUID } from "node:crypto";

import type { FastifyInstance } from "fastify";
import { z } from "zod";

import {
  type LoginResponse,
  type MfaChooseResponse,
  type Phase1MfaVerifyResponse,
} from "@factur-e/shared-schemas";

import { writeAuthAudit } from "../../auth/audit.js";
import { setRefreshSessionCookie } from "../../auth/cookies.js";
import { decrypt, encrypt } from "../../auth/encryption.js";
import {
  signAccessToken,
  signRefreshToken,
  TTL_SECONDS,
  verifyMfaResetToken,
} from "../../auth/jwt.js";
import { requiresTotp } from "../../auth/mfa-policy.js";
import { consumeOtp, issueOtp } from "../../auth/otp.js";
import { generateRecoveryCodes } from "../../auth/recovery.js";
import {
  generateTotpSecret,
  totpQrSvgFromUri,
  totpUriFromSecret,
  verifyTotpCode,
} from "../../auth/totp.js";
import * as usersRepo from "../../db/repos/users.js";
import { insertSession, withTransaction } from "../../db/tx.js";

/**
 * MFA setup post-reset (T-CL-09 §B). When a user's `mfa_reset_required` is
 * TRUE (after using a recovery code, or for an invitee logging in for the
 * first time once we tighten the brief design 5-step flow), `/auth/login`
 * returns a `mfa_reset_required` state with a short-lived `reset_token`.
 * The SPA then walks the user through a 3-step setup that mirrors phase 1
 * (choose mode → verify code → ack recovery codes), but operates on the
 * `users` row instead of `signup_pending`.
 *
 * Routes:
 *   POST /auth/mfa/setup-choose     { reset_token, mode } → qr_svg | otp_sent_to
 *   POST /auth/mfa/setup-verify     { reset_token, code } → recovery_codes (clear)
 *   POST /auth/mfa/setup-recovery-ack { reset_token, ack } → access_token + cookie
 *
 * Auth: every route validates `reset_token` (audience factur-e:mfa-reset)
 * and refuses if `users.mfa_reset_required` is FALSE — mirror of the
 * phase-1 cookie check. No `Authorization: Bearer` is needed; the user
 * has no live session yet.
 */

const NEUTRAL = "Vérifiez vos informations.";

const ChooseBody = z
  .object({ reset_token: z.string().min(1), mode: z.enum(["email", "totp"]) })
  .strict();

const VerifyBody = z
  .object({ reset_token: z.string().min(1), code: z.string().regex(/^\d{6}$/) })
  .strict();

const AckBody = z.object({ reset_token: z.string().min(1), ack: z.literal(true) }).strict();

async function loadUserForReset(
  app: FastifyInstance,
  reset_token: string,
): Promise<usersRepo.UserMfaStateRow | null> {
  let payload: { user_id: string };
  try {
    payload = await verifyMfaResetToken(reset_token);
  } catch {
    return null;
  }
  const u = await usersRepo.findActiveUserMfaStateById(app.sql, payload.user_id);
  if (!u?.mfa_reset_required) return null;
  return u;
}

export function registerMfaSetupRoutes(app: FastifyInstance): void {
  // ─────────────────────────────────────────────────────────────────────
  // POST /auth/mfa/setup-choose
  // ─────────────────────────────────────────────────────────────────────
  app.post("/auth/mfa/setup-choose", async (req, reply) => {
    const parsed = ChooseBody.safeParse(req.body);
    if (!parsed.success) return reply.code(400).send({ message: NEUTRAL });
    const { reset_token, mode } = parsed.data;
    const ip = req.ip;
    const ua = req.headers["user-agent"] ?? null;

    const user = await loadUserForReset(app, reset_token);
    if (user === null) return reply.code(401).send({ message: NEUTRAL });

    // T-CL-15 sprint-03 §ADR-006 D3 — politique TOTP-only pour les rôles
    // privilégiés (Full ou can_purchase=true). Le SPA ne propose pas l'option
    // email pour ces users (cf. SetupMfa.tsx + endpoint setup-context), mais
    // on enforce serveur-side au cas où un attaquant bypasse via JS console.
    if (mode === "email" && requiresTotp(user)) {
      await writeAuthAudit(app.sql, {
        event_type: "mfa_setup",
        success: false,
        user_id: user.id,
        customer_id: user.customer_id,
        ip,
        user_agent: ua,
        metadata: { phase: "post_reset", reason: "totp_required" },
      });
      return reply.code(403).send({
        reason: "totp_required",
        message:
          "Pour votre rôle (gestion d'équipe ou achat de packs), seule l'application authenticator est autorisée.",
      });
    }

    if (mode === "totp") {
      const secret = generateTotpSecret();
      const uri = totpUriFromSecret(secret, user.email);
      const qrSvg = await totpQrSvgFromUri(uri);
      const ciphertext = encrypt(secret);
      // Stash candidate secret directly in users.mfa_secret. mfa_mode stays
      // 'none' (and mfa_reset_required stays TRUE) until ack — the secret
      // alone doesn't grant access.
      await usersRepo.markMfaSecret(app.sql, user.id, ciphertext);
      await writeAuthAudit(app.sql, {
        event_type: "mfa_setup",
        success: true,
        user_id: user.id,
        customer_id: user.customer_id,
        ip,
        user_agent: ua,
        metadata: { phase: "post_reset", mode: "totp" },
      });
      const body: MfaChooseResponse = { mode: "totp", otpauth_uri: uri, qr_svg: qrSvg };
      return reply.code(200).send(body);
    }

    // email mode — clear any previous TOTP candidate, send a fresh OTP.
    await usersRepo.markMfaSecret(app.sql, user.id, null);
    const otp = await issueOtp(app.sql, { user_id: user.id }, "phase1_mfa_setup");
    await app.email.send({
      to: user.email,
      purpose: "phase1_mfa_setup_otp",
      payload: { otp_code: otp.code },
    });
    await writeAuthAudit(app.sql, {
      event_type: "mfa_setup",
      success: true,
      user_id: user.id,
      customer_id: user.customer_id,
      ip,
      user_agent: ua,
      metadata: { phase: "post_reset", mode: "email", otp_id: otp.id },
    });
    const body: MfaChooseResponse = { mode: "email", otp_sent_to: user.email };
    return reply.code(200).send(body);
  });

  // ─────────────────────────────────────────────────────────────────────
  // POST /auth/mfa/setup-verify
  // ─────────────────────────────────────────────────────────────────────
  app.post("/auth/mfa/setup-verify", async (req, reply) => {
    const parsed = VerifyBody.safeParse(req.body);
    if (!parsed.success) return reply.code(400).send({ message: NEUTRAL });
    const { reset_token, code } = parsed.data;
    const ip = req.ip;
    const ua = req.headers["user-agent"] ?? null;

    const user = await loadUserForReset(app, reset_token);
    if (user === null) return reply.code(401).send({ message: NEUTRAL });

    // Mode is inferred from `users.mfa_secret`: TOTP candidate present →
    // totp; null → email (consume an active OTP).
    const totpSecret = user.mfa_secret;
    const isTotp = totpSecret !== null;
    let verified = false;
    if (totpSecret !== null) {
      verified = verifyTotpCode(decrypt(totpSecret), code);
    } else {
      const result = await consumeOtp(app.sql, { user_id: user.id }, "phase1_mfa_setup", code);
      verified = result.kind === "ok";
    }
    if (!verified) {
      await writeAuthAudit(app.sql, {
        event_type: "mfa_failed",
        success: false,
        user_id: user.id,
        customer_id: user.customer_id,
        ip,
        user_agent: ua,
        metadata: { phase: "post_reset", mode: isTotp ? "totp" : "email" },
      });
      return reply.code(401).send({ message: NEUTRAL });
    }

    const { plain, hashed } = await generateRecoveryCodes();
    // Hold the new mode + recovery hashes server-side. mfa_reset_required
    // stays TRUE — only the `setup-recovery-ack` call clears it (mirrors
    // the phase-1 ack discipline).
    await usersRepo.markMfaSetupComplete(app.sql, user.id, {
      mode: isTotp ? "totp" : "email",
      recovery_codes_hashed: hashed,
    });
    await writeAuthAudit(app.sql, {
      event_type: "mfa_verified",
      success: true,
      user_id: user.id,
      customer_id: user.customer_id,
      ip,
      user_agent: ua,
      metadata: { phase: "post_reset", mode: isTotp ? "totp" : "email" },
    });
    const body: Phase1MfaVerifyResponse = { recovery_codes: plain };
    return reply.code(200).send(body);
  });

  // ─────────────────────────────────────────────────────────────────────
  // POST /auth/mfa/setup-recovery-ack
  // ─────────────────────────────────────────────────────────────────────
  app.post("/auth/mfa/setup-recovery-ack", async (req, reply) => {
    const parsed = AckBody.safeParse(req.body);
    if (!parsed.success) return reply.code(400).send({ message: NEUTRAL });
    const { reset_token } = parsed.data;
    const ip = req.ip;
    const ua = req.headers["user-agent"] ?? null;

    const user = await loadUserForReset(app, reset_token);
    if (user === null) return reply.code(401).send({ message: NEUTRAL });

    // T-CL-15 sprint-03 §C3 — defense in depth invitee funnel.
    // Un user invité ne peut pas finaliser MFA sans avoir d'abord vérifié
    // son email de secours (brief Design sprint-02 ligne 775, 5 étapes
    // invité). Mitigation contre un bypass SPA via JS console qui appellerait
    // directement /auth/mfa/setup-* en sautant /auth/accept-invitation/
    // secondary-email/*. Le SPA reçoit 409 → re-navigate vers le funnel
    // secondary email.
    const secondary = await usersRepo.findActiveUserSecondaryEmailById(app.sqlRead, user.id);
    if (secondary?.secondary_email_verified_at === null) {
      return reply.code(409).send({
        reason: "secondary_email_pending",
        message: "Email de secours requis avant finalisation.",
      });
    }

    // Final flip: clear mfa_reset_required + open a fresh session. The
    // refresh cookie + access token mirror a regular login.
    const sessionId = randomUUID();
    await withTransaction(app.sql, async (tx) => {
      await usersRepo.markMfaResetRequired(tx, user.id, false);
      await insertSession(tx, { id: sessionId, userId: user.id, ip, userAgent: ua });
    });

    const accessToken = await signAccessToken({
      user_id: user.id,
      customer_id: user.customer_id,
    });
    const refreshToken = await signRefreshToken({ session_id: sessionId, user_id: user.id });
    setRefreshSessionCookie(reply, refreshToken);

    await writeAuthAudit(app.sql, {
      event_type: "mfa_setup_completed",
      success: true,
      user_id: user.id,
      customer_id: user.customer_id,
      ip,
      user_agent: ua,
      metadata: { phase: "post_reset", session_id: sessionId },
    });

    const body: LoginResponse = {
      access_token: accessToken,
      expires_in: TTL_SECONDS.access,
    };
    return reply.code(200).send(body);
  });

  // ─────────────────────────────────────────────────────────────────────
  // POST /auth/mfa/setup-context (T-CL-15 sprint-03)
  // ─────────────────────────────────────────────────────────────────────
  // Retourne les hints de policy MFA pour le SPA SetupMfa :
  //   - `requires_totp` : ADR-006 §D3, masque l'option email côté SPA
  //   - `is_first_time` : wording "Configurez" (invité, mfa_mode='none')
  //                       vs "Reconfigurez" (post recovery-code, mfa_mode existait)
  // Le SPA appelle ce endpoint au mount de SetupMfa avant d'afficher les
  // choix. POST plutôt que GET pour transmettre le reset_token en body
  // (cohérent avec /auth/mfa/setup-choose) et éviter le token en query
  // string (logs serveur + history navigateur).
  const ContextBody = z.object({ reset_token: z.string().min(1) }).strict();
  app.post("/auth/mfa/setup-context", async (req, reply) => {
    const parsed = ContextBody.safeParse(req.body);
    if (!parsed.success) return reply.code(400).send({ message: NEUTRAL });
    const user = await loadUserForReset(app, parsed.data.reset_token);
    if (user === null) return reply.code(401).send({ message: NEUTRAL });
    return reply.code(200).send({
      requires_totp: requiresTotp(user),
      is_first_time: user.mfa_mode === "none",
    });
  });
}
