import { randomUUID } from "node:crypto";

import type { FastifyInstance } from "fastify";
import { AuthMfaVerifyBodySchema, type LoginResponse } from "@factur-e/shared-schemas";

import { writeAuthAudit } from "../../auth/audit.js";
import { setRefreshSessionCookie } from "../../auth/cookies.js";
import { decrypt } from "../../auth/encryption.js";
import {
  signAccessToken,
  signRefreshToken,
  TTL_SECONDS,
  verifyMfaChallengeToken,
} from "../../auth/jwt.js";
// TTL_SECONDS retained for the LoginResponse `expires_in` field (access TTL).
import { consumeOtp } from "../../auth/otp.js";
import { findMatchingRecoveryHash } from "../../auth/recovery.js";
import { verifyTotpCode } from "../../auth/totp.js";
import * as usersRepo from "../../db/repos/users.js";
import { insertSession } from "../../db/tx.js";

const NEUTRAL = "Vérifiez vos informations.";

export function registerMfaVerifyRoute(app: FastifyInstance): void {
  app.post("/auth/mfa/verify", async (req, reply) => {
    const parsed = AuthMfaVerifyBodySchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ message: NEUTRAL });
    }
    const { mfa_challenge_token, code, recovery_code } = parsed.data;
    const ip = req.ip;
    const ua = req.headers["user-agent"] ?? null;

    let challenge;
    try {
      challenge = await verifyMfaChallengeToken(mfa_challenge_token);
    } catch {
      return reply.code(401).send({ message: NEUTRAL });
    }

    const user = await usersRepo.findActiveUserMfaForVerifyById(app.sql, challenge.user_id);
    if (user === undefined) {
      return reply.code(401).send({ message: NEUTRAL });
    }

    let usedRecovery = false;
    let verified = false;

    if (recovery_code !== undefined) {
      const idx = await findMatchingRecoveryHash(user.recovery_codes_hashed ?? [], recovery_code);
      if (idx >= 0) {
        // Consume: drop the matched hash, force re-setup MFA, clear secret.
        const remaining = (user.recovery_codes_hashed ?? []).filter((_, i) => i !== idx);
        await usersRepo.consumeRecoveryCode(app.sql, challenge.user_id, remaining);
        usedRecovery = true;
        verified = true;
      }
    } else if (code !== undefined) {
      if (challenge.mfa_mode === "totp" && user.mfa_secret !== null) {
        const secret = decrypt(user.mfa_secret);
        verified = verifyTotpCode(secret, code);
      } else if (challenge.mfa_mode === "email") {
        const result = await consumeOtp(app.sql, { user_id: challenge.user_id }, "login_mfa", code);
        verified = result.kind === "ok";
      }
    }

    if (!verified) {
      await writeAuthAudit(app.sql, {
        event_type: "mfa_failed",
        success: false,
        user_id: challenge.user_id,
        customer_id: challenge.customer_id,
        ip,
        user_agent: ua,
        metadata: {
          phase: "login",
          mode: challenge.mfa_mode,
          attempted_recovery: recovery_code !== undefined,
        },
      });
      return reply.code(401).send({ message: NEUTRAL });
    }

    const sessionId = randomUUID();
    await insertSession(app.sql, {
      id: sessionId,
      userId: challenge.user_id,
      ip,
      userAgent: ua,
    });
    const accessToken = await signAccessToken({
      user_id: challenge.user_id,
      customer_id: challenge.customer_id,
    });
    const refreshToken = await signRefreshToken({
      session_id: sessionId,
      user_id: challenge.user_id,
    });
    setRefreshSessionCookie(reply, refreshToken);

    await usersRepo.markLastLogin(app.sql, challenge.user_id);
    await writeAuthAudit(app.sql, {
      event_type: usedRecovery ? "mfa_recovery_used" : "mfa_verified",
      success: true,
      user_id: challenge.user_id,
      customer_id: challenge.customer_id,
      ip,
      user_agent: ua,
      metadata: {
        session_id: sessionId,
        mode: challenge.mfa_mode,
      },
    });

    const body: LoginResponse = {
      access_token: accessToken,
      expires_in: TTL_SECONDS.access,
    };
    return reply.code(200).send(body);
  });
}
