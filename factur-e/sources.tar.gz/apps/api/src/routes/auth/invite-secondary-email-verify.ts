import type { FastifyInstance } from "fastify";

import {
  type InviteSecondaryEmailVerifyResponse,
  InviteSecondaryEmailVerifyBodySchema,
} from "@factur-e/shared-schemas";

import { writeAuthAudit } from "../../auth/audit.js";
import { resolveAuthContext } from "../../auth/context.js";
import { signMfaResetToken, TTL_SECONDS } from "../../auth/jwt.js";
import { consumeOtp } from "../../auth/otp.js";
import * as usersRepo from "../../db/repos/users.js";

const NEUTRAL = "Vérifiez vos informations.";

/**
 * `POST /auth/accept-invitation/secondary-email/verify` — T-CL-15 sprint-03.
 *
 * Consomme l'OTP émis par `/set` et termine l'étape « Email de secours »
 * du funnel invité (brief Design sprint-02 ligne 775). À succès :
 *  - `users.secondary_email_verified_at = NOW()` (closes l'invariant
 *    T-CL-15, cf. header `users.repo.ts`).
 *  - Audit `invite_secondary_email_verified`.
 *  - Émission d'un `reset_token` (aud `factur-e:mfa-reset`) qui permet
 *    au SPA d'enchaîner sur `/auth/setup-mfa` (T-CL-09 sprint-02) sans
 *    repasser par `/auth/login`.
 *
 * Cas dégradés :
 *  - OTP wrong / expired / locked → 401 NEUTRAL + audit `mfa_failed`
 *    (réutilise le même event que phase1 pour cohérence métriques).
 *  - `secondary_email_verified_at` déjà set (replay) → 409
 *    `already_verified` (le SPA navigue alors directement vers setup-mfa).
 */
export function registerInviteSecondaryEmailVerifyRoute(app: FastifyInstance): void {
  app.post("/auth/accept-invitation/secondary-email/verify", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: NEUTRAL });
    }
    const parsed = InviteSecondaryEmailVerifyBodySchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ message: NEUTRAL });
    }
    const ip = req.ip;
    const ua = req.headers["user-agent"] ?? null;

    const user = await usersRepo.findActiveUserSecondaryEmailById(app.sql, ctx.user_id);
    if (user === undefined) {
      return reply.code(401).send({ message: NEUTRAL });
    }

    if (user.secondary_email_verified_at !== null) {
      return reply.code(409).send({
        reason: "already_verified",
        message: "Email de secours déjà confirmé.",
      });
    }

    if (user.secondary_email.length === 0) {
      // `/set` n'a pas été appelé. SPA navigue à `/verify` directement.
      return reply.code(409).send({
        reason: "set_required",
        message: "Saisissez d'abord votre email de secours.",
      });
    }

    const result = await consumeOtp(
      app.sql,
      { user_id: ctx.user_id },
      "invite_secondary_verify",
      parsed.data.code,
    );
    if (result.kind !== "ok") {
      await writeAuthAudit(app.sql, {
        event_type: "mfa_failed",
        success: false,
        user_id: ctx.user_id,
        customer_id: user.customer_id,
        ip,
        user_agent: ua,
        metadata: {
          phase: "invite_secondary_email",
          consume_kind: result.kind,
        },
      });
      return reply.code(401).send({ message: NEUTRAL });
    }

    await usersRepo.markSecondaryEmailVerified(app.sql, ctx.user_id);
    await writeAuthAudit(app.sql, {
      event_type: "email_secondary_verified",
      success: true,
      user_id: ctx.user_id,
      customer_id: user.customer_id,
      ip,
      user_agent: ua,
      metadata: { phase: "invite_accept", secondary_email: user.secondary_email },
    });

    // Émission du reset_token pour enchaîner sur /auth/setup-mfa.
    // Le user reste `mfa_reset_required=TRUE` jusqu'au `setup-recovery-ack`.
    const resetToken = await signMfaResetToken({ user_id: ctx.user_id });
    const body: InviteSecondaryEmailVerifyResponse = {
      reset_token: resetToken,
      expires_in: TTL_SECONDS.mfaReset,
    };
    return reply.code(200).send(body);
  });
}
