import type { FastifyInstance } from "fastify";
import { SignupBodySchema, type SignupResponse } from "@factur-e/shared-schemas";

import { hashPassword } from "../../auth/argon2.js";
import { writeAuthAudit } from "../../auth/audit.js";
import { setSignupSessionCookie } from "../../auth/cookies.js";
import { isEmailRecentlyThrottled } from "../../auth/email-throttle.js";
import { signSignupSessionToken } from "../../auth/jwt.js";
import { passwordHashMarker, signMagicLink } from "../../auth/magic-link.js";
import * as signupPendingRepo from "../../db/repos/signup_pending.js";
import * as usersRepo from "../../db/repos/users.js";

function webBaseUrl(): string {
  return process.env.WEB_BASE_URL ?? "http://localhost:5174";
}

export function registerSignupRoute(app: FastifyInstance): void {
  app.post("/auth/signup", async (req, reply) => {
    const parsed = SignupBodySchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ message: "Vérifiez vos informations." });
    }
    const { email, password } = parsed.data;
    const normalizedEmail = email.toLowerCase();
    const ip = req.ip;
    const ua = req.headers["user-agent"] ?? null;

    const password_hash = await hashPassword(password);

    // Anti-enumeration (brief §6.1): if the email already belongs to a user,
    // still create a signup_pending row marked `is_decoy=true`. The HTTP
    // response is identical; we send a *reset password* link to the existing
    // user instead of a verify link.
    const decoyTarget = await usersRepo.findActiveUserCredentialsByEmail(app.sql, normalizedEmail);
    const isDecoy = decoyTarget !== undefined;

    // Avoid accumulating ghost rows when a user retries signup in the same
    // browser (cookie écrasé) ou depuis 2 onglets : on supprime tout
    // signup_pending non-décoy non finalisé pour ce même email avant
    // d'insérer le nouveau. On ne touche pas aux rows is_decoy=true (elles
    // n'existent que pour l'anti-énumération côté audit, pas de fuite).
    if (!isDecoy) {
      await signupPendingRepo.deletePendingByEmailNonDecoy(app.sql, normalizedEmail);
    }

    const row = await signupPendingRepo.insertPending(app.sql, {
      email: normalizedEmail,
      passwordHash: password_hash,
      isDecoy,
    });

    const token = await signSignupSessionToken({ signup_pending_id: row.id });
    setSignupSessionCookie(reply, token);

    // Email throttle (T-CL-02 sprint-03) : if a transactional email has
    // already been sent to this address in the last 5 min (signup or
    // password-reset), skip the send to defeat per-email spam from an
    // attacker rotating IPs. The signup_pending row is still persisted +
    // cookie set so the legit user retry (cookie loss) keeps working —
    // they can re-trigger via /auth/phase1/email/verify-trigger.
    const throttled = await isEmailRecentlyThrottled(app.sql, normalizedEmail);

    // Magic link side-effect: verify email for non-decoy, reset password
    // for decoy. Failures are swallowed — the signup row is already
    // persisted and the user can re-trigger via /auth/phase1/email/
    // verify-trigger.
    if (throttled) {
      req.log.info(
        { email: normalizedEmail },
        "[signup] email throttled (recent send within 5 min) — skipping",
      );
    } else {
      try {
        if (decoyTarget !== undefined) {
          const linkToken = await signMagicLink({
            purpose: "password_reset",
            target_id: decoyTarget.id,
            email: normalizedEmail,
            hash_marker: passwordHashMarker(decoyTarget.password_hash),
          });
          const url = `${webBaseUrl()}/reset-password?token=${encodeURIComponent(linkToken)}`;
          await app.email.send({
            to: normalizedEmail,
            purpose: "password_reset",
            payload: { magic_link: url },
          });
        } else {
          const linkToken = await signMagicLink({
            purpose: "email_verify",
            target_id: row.id,
            email: normalizedEmail,
            hash_marker: "",
          });
          const url = `${webBaseUrl()}/onboarding/email-verify?token=${encodeURIComponent(linkToken)}`;
          await app.email.send({
            to: normalizedEmail,
            purpose: "phase1_email_verify_otp",
            payload: { magic_link: url },
          });
        }
      } catch (err) {
        // Email send failure must not break signup (the row is persisted and
        // the user can re-trigger via /auth/phase1/email/verify-trigger). We
        // do log it though — silent swallows in transactional code paths
        // make production diagnostics impossible.
        req.log.error(
          { err: err instanceof Error ? err.message : String(err) },
          "[signup] email send failed",
        );
      }
    }

    await writeAuthAudit(app.sql, {
      event_type: isDecoy ? "signup_failed" : "signup_success",
      success: !isDecoy,
      ip,
      user_agent: ua,
      metadata: isDecoy
        ? { email: normalizedEmail, reason: "email_exists" }
        : { email: normalizedEmail, signup_pending_id: row.id },
    });

    const body: SignupResponse = {
      state: "pending",
      current_step: "siren",
    };
    return reply.code(201).send(body);
  });
}
