import type { FastifyInstance } from "fastify";

import { InviteSecondaryEmailSetBodySchema } from "@factur-e/shared-schemas";

import { writeAuthAudit } from "../../auth/audit.js";
import { resolveAuthContext } from "../../auth/context.js";
import { isInviteSecondaryEmailRecentlyIssued } from "../../auth/email-throttle.js";
import { issueOtp } from "../../auth/otp.js";
import * as usersRepo from "../../db/repos/users.js";

const NEUTRAL = "Vérifiez vos informations.";

/**
 * `POST /auth/accept-invitation/secondary-email/set` — T-CL-15 sprint-03.
 *
 * Le user invité (authentifié Bearer post-`/invitations/:token/accept`)
 * saisit son email de secours. On émet un OTP 6-digit vers cet email,
 * stocké hashé bcrypt en `otp_codes` avec `purpose='invite_secondary_verify'`.
 *
 * Garde-fous (cf. arbitrage Bruno A bis §C2) :
 *  - Email throttle 1/5min par `user_id` (anti-spam contre la victime).
 *  - Refus si `secondary_email_verified_at IS NOT NULL` (déjà fait — cas
 *    re-replay du SPA, pas une faute mais on évite de re-émettre l'OTP).
 *  - Refus si `candidate === primary_email` (Zod refine côté serveur).
 *
 * Le `users.secondary_email` est mis à jour avec le candidat **sans**
 * set `secondary_email_verified_at` — celui-ci sera positionné par
 * `/verify` une fois l'OTP consommé.
 */
export function registerInviteSecondaryEmailSetRoute(app: FastifyInstance): void {
  app.post("/auth/accept-invitation/secondary-email/set", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: NEUTRAL });
    }
    const parsed = InviteSecondaryEmailSetBodySchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ message: NEUTRAL });
    }
    const candidate = parsed.data.email.toLowerCase();
    const ip = req.ip;
    const ua = req.headers["user-agent"] ?? null;

    const user = await usersRepo.findActiveUserSecondaryEmailById(app.sql, ctx.user_id);
    if (user === undefined) {
      return reply.code(401).send({ message: NEUTRAL });
    }

    if (user.secondary_email_verified_at !== null) {
      // Idempotent — pas une erreur métier, juste pas d'action.
      return reply.code(409).send({
        reason: "already_verified",
        message: "Email de secours déjà confirmé.",
      });
    }

    if (candidate === user.email) {
      return reply.code(400).send({
        message: "L'email de secours doit être différent de l'email principal.",
      });
    }

    if (await isInviteSecondaryEmailRecentlyIssued(app.sql, ctx.user_id)) {
      // Throttle silencieux — on garde un 429 explicite pour signaler au
      // SPA qu'il faut attendre, plutôt qu'un 204 trompeur.
      await writeAuthAudit(app.sql, {
        event_type: "invite_secondary_email_set",
        success: false,
        user_id: ctx.user_id,
        customer_id: user.customer_id,
        ip,
        user_agent: ua,
        metadata: { reason: "throttled" },
      });
      return reply.code(429).send({
        reason: "throttled",
        message: "Trop de tentatives. Réessayez dans quelques minutes.",
      });
    }

    await usersRepo.markSecondaryEmailCandidate(app.sql, ctx.user_id, candidate);

    const otp = await issueOtp(app.sql, { user_id: ctx.user_id }, "invite_secondary_verify");
    await app.email.send({
      to: candidate,
      purpose: "invite_secondary_email_verify_otp",
      payload: {
        otp_code: otp.code,
        vars: { code: otp.code },
      },
    });

    await writeAuthAudit(app.sql, {
      event_type: "invite_secondary_email_set",
      success: true,
      user_id: ctx.user_id,
      customer_id: user.customer_id,
      ip,
      user_agent: ua,
      // `email` en metadata pour traçabilité ; le throttle email-based
      // existant tape sur `metadata.email` lui aussi.
      metadata: { email: candidate },
    });

    return reply.code(204).send();
  });
}
