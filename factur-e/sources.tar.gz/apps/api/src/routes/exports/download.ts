import type { FastifyInstance } from "fastify";

import { writeAuthAudit } from "../../auth/audit.js";
import { resolveAuthContext } from "../../auth/context.js";
import { resolveSseAuthContext } from "../../auth/sse-auth.js";
import { findExportRequestByIdAndCustomer } from "../../db/repos/export_requests.js";

import { isDownloadAvailable, requireFull } from "./_shared.js";

/** Durée de validité de l'URL presignée S3 (Z5 — 1 heure). */
const PRESIGNED_EXPIRES_SEC = 3600;

/**
 * `GET /api/exports/:id/download` — génère une URL presignée S3 fraîche (1h)
 * et redirige 302 (Z5). L'endpoint app est accessible 7 jours après création
 * (le lien email pointe ici) ; au-delà → 410 Gone. RBAC rôle Full (RET-7) +
 * scope customer (404 inter-tenant).
 *
 * Statuts :
 *  - `completed` + < 7j → 302 vers presigned URL
 *  - `completed` + ≥ 7j → 410 Gone (lien expiré)
 *  - `purged`           → 404 (archive supprimée — RGPD 6 mois)
 *  - `pending`/`processing`/`failed` → 409 (pas encore / jamais disponible)
 */
export function registerExportsDownloadRoute(app: FastifyInstance): void {
  app.get<{ Params: { id: string } }>("/api/exports/:id/download", async (req, reply) => {
    // Auth Bearer (fetch SPA) OU fallback cookie HttpOnly `_session` : ce
    // endpoint est navigable au navigateur (lien email Z5, ancre download) où
    // aucun header Authorization ne peut être posé (pattern resolveSseAuth).
    let ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      ctx = await resolveSseAuthContext(req, app.sql);
    }
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: "Authentification requise." });
    }
    if (!(await requireFull(app, reply, ctx))) return;

    const row = await findExportRequestByIdAndCustomer(app.sqlRead, req.params.id, ctx.customer_id);
    if (row === undefined) {
      return reply.code(404).send({ message: "Export introuvable." });
    }
    if (row.status === "purged") {
      return reply.code(404).send({ message: "Cette archive a été supprimée." });
    }
    if (row.status !== "completed" || row.file_key === null) {
      return reply
        .code(409)
        .send({ message: "Cet export n'est pas disponible au téléchargement." });
    }
    if (!isDownloadAvailable(row, new Date())) {
      return reply.code(410).send({ message: "Ce lien de téléchargement a expiré." });
    }

    const url = await app.exportsStorage.getPresignedUrl(row.file_key, PRESIGNED_EXPIRES_SEC);

    await writeAuthAudit(app.sql, {
      event_type: "export_zip_downloaded",
      success: true,
      user_id: ctx.user_id,
      customer_id: ctx.customer_id,
      ip: req.ip,
      user_agent: req.headers["user-agent"] ?? null,
      metadata: { export_id: row.id },
    });

    return reply.redirect(url);
  });
}
