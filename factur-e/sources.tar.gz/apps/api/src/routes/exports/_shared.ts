import type { FastifyInstance, FastifyReply } from "fastify";

import type { ExportRequestDto } from "@factur-e/shared-schemas";

import type { AuthenticatedContext } from "../../auth/context.js";
import type { ExportRequestRow } from "../../db/repos/export_requests.js";
import { findActiveUserRoleById } from "../../db/repos/users.js";

/**
 * Helpers partagés `/api/exports/*` (T-CL-EXPORT-ZIP-RETENTION L12).
 * RBAC rôle Full exclusif (PRD §3.12 RET-7) + sérialiseur BDD → DTO.
 */

/** Fenêtre de disponibilité du lien download (Z5 — endpoint 7 jours). */
export const DOWNLOAD_WINDOW_DAYS = 7;
const DOWNLOAD_WINDOW_MS = DOWNLOAD_WINDOW_DAYS * 24 * 60 * 60 * 1000;

/**
 * Vérifie le rôle Full. 403 + `false` sinon (le caller court-circuite).
 * Export ZIP réservé au Responsable du compte (rôle `full`) — les autres
 * rôles voient le badge rétention mais ne déclenchent pas d'export.
 */
export async function requireFull(
  app: FastifyInstance,
  reply: FastifyReply,
  ctx: AuthenticatedContext,
): Promise<boolean> {
  const r = await findActiveUserRoleById(app.sql, ctx.user_id);
  if (r?.role !== "full") {
    reply.code(403).send({ message: "Réservé au Responsable du compte." });
    return false;
  }
  return true;
}

export function isDownloadAvailable(row: ExportRequestRow, now: Date): boolean {
  return (
    row.status === "completed" && now.getTime() - row.created_at.getTime() < DOWNLOAD_WINDOW_MS
  );
}

export function toExportRequestDto(row: ExportRequestRow, now: Date): ExportRequestDto {
  return {
    id: row.id,
    scope: row.scope,
    filters: row.filters,
    invoice_count: row.invoice_count,
    status: row.status,
    file_size_bytes: row.file_size_bytes,
    purge_at: row.purge_at.toISOString(),
    created_at: row.created_at.toISOString(),
    download_available: isDownloadAvailable(row, now),
  };
}
