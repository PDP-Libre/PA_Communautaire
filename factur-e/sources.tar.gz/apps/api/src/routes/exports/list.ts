import type { FastifyInstance } from "fastify";

import type { ExportListResponse } from "@factur-e/shared-schemas";

import { resolveAuthContext } from "../../auth/context.js";
import {
  countExportRequestsByCustomer,
  listExportRequestsByCustomer,
} from "../../db/repos/export_requests.js";

import { requireFull, toExportRequestDto } from "./_shared.js";

const PAGE_SIZE = 20;

/**
 * `GET /api/exports?page=N` — liste paginée des demandes d'export du customer
 * (Paramètres > Mes exports). RBAC rôle Full (RET-7). 20 par page.
 */
export function registerExportsListRoute(app: FastifyInstance): void {
  app.get<{ Querystring: { page?: string } }>("/api/exports", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: "Authentification requise." });
    }
    if (!(await requireFull(app, reply, ctx))) return;

    const page = Math.max(1, Number(req.query.page ?? "1") || 1);
    const offset = (page - 1) * PAGE_SIZE;
    const now = new Date();

    const [rows, total] = await Promise.all([
      listExportRequestsByCustomer(app.sqlRead, ctx.customer_id, { limit: PAGE_SIZE, offset }),
      countExportRequestsByCustomer(app.sqlRead, ctx.customer_id),
    ]);

    const body: ExportListResponse = {
      items: rows.map((r) => toExportRequestDto(r, now)),
      total,
      page,
      page_size: PAGE_SIZE,
    };
    return reply.send(body);
  });
}
