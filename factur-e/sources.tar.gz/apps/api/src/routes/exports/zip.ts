import type { FastifyInstance } from "fastify";

import { CreateExportRequestSchema, type CreateExportResponse } from "@factur-e/shared-schemas";

import { writeAuthAudit } from "../../auth/audit.js";
import { resolveAuthContext } from "../../auth/context.js";
import { insertExportRequest } from "../../db/repos/export_requests.js";
import { findActiveInvoicesByCustomerId } from "../../db/repos/invoices.js";
import { findActiveReceivedInvoicesByCustomerId } from "../../db/repos/received_invoices.js";
import { JOB_EXPORT_ZIP_GENERATE } from "../../jobs/job-queue.js";

import { requireFull } from "./_shared.js";

/** Limite de sécurité (TPE ≤ 100 factures/mois — large marge V1). */
const MAX_EXPORT_INVOICES = 100_000;

/**
 * `POST /api/exports/zip` — déclenche un export ZIP asynchrone.
 *
 * RBAC rôle Full (RET-7). Compte les factures matchant les filtres (selon le
 * scope), refuse si 0 (RET — rien à exporter), persiste la demande `pending`
 * + enqueue le worker pgboss `export-zip-generate`. Réponse 202 Accepted (la
 * génération est asynchrone — l'utilisateur reçoit un email + voit la demande
 * dans Paramètres > Mes exports).
 */
export function registerExportsZipRoute(app: FastifyInstance): void {
  app.post("/api/exports/zip", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: "Authentification requise." });
    }
    if (!(await requireFull(app, reply, ctx))) return;

    const parsed = CreateExportRequestSchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ message: "Données invalides." });
    }
    const { scope, filters } = parsed.data;

    const invoiceIds: string[] = [];
    if (scope === "emission" || scope === "all") {
      const rows = await findActiveInvoicesByCustomerId(app.sqlRead, ctx.customer_id, {
        status: filters.status,
        dateFrom: filters.dateFrom,
        dateTo: filters.dateTo,
        search: filters.search,
        limit: MAX_EXPORT_INVOICES,
      });
      for (const r of rows) invoiceIds.push(r.id);
    }
    if (scope === "reception" || scope === "all") {
      const rows = await findActiveReceivedInvoicesByCustomerId(app.sqlRead, ctx.customer_id, {
        status: filters.status,
        dateFrom: filters.dateFrom,
        dateTo: filters.dateTo,
        limit: MAX_EXPORT_INVOICES,
      });
      for (const r of rows) invoiceIds.push(r.id);
    }

    if (invoiceIds.length === 0) {
      return reply.code(400).send({ message: "Aucune facture à exporter." });
    }

    const request = await insertExportRequest(app.sql, {
      customer_id: ctx.customer_id,
      requested_by_user_id: ctx.user_id,
      scope,
      filters,
      invoice_ids: invoiceIds,
      invoice_count: invoiceIds.length,
    });

    await app.jobQueue.enqueue(JOB_EXPORT_ZIP_GENERATE, { export_request_id: request.id });

    await writeAuthAudit(app.sql, {
      event_type: "export_zip_requested",
      success: true,
      user_id: ctx.user_id,
      customer_id: ctx.customer_id,
      ip: req.ip,
      user_agent: req.headers["user-agent"] ?? null,
      metadata: { export_id: request.id, scope, count: invoiceIds.length },
    });

    const body: CreateExportResponse = {
      export_id: request.id,
      correlation_id: request.correlation_id,
    };
    return reply.code(202).send(body);
  });
}
