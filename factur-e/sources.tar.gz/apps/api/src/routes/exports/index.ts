import type { FastifyInstance } from "fastify";

import { registerExportsDownloadRoute } from "./download.js";
import { registerExportsListRoute } from "./list.js";
import { registerExportsZipRoute } from "./zip.js";

/** Routes Export ZIP + rétention (T-CL-EXPORT-ZIP-RETENTION sprint-06 L12). */
export function registerExportsRoutes(app: FastifyInstance): void {
  registerExportsZipRoute(app);
  registerExportsListRoute(app);
  registerExportsDownloadRoute(app);
}
