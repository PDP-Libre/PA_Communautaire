import type { FastifyInstance } from "fastify";

import { registerProductsCreateRoute } from "./create.js";
import { registerProductsDeleteRoute } from "./delete.js";
import { registerProductsGetRoute } from "./get.js";
import { registerProductsListRoute } from "./list.js";
import { registerProductsUpdateRoute } from "./update.js";

export function registerProductsRoutes(app: FastifyInstance): void {
  registerProductsListRoute(app);
  registerProductsGetRoute(app);
  registerProductsCreateRoute(app);
  registerProductsUpdateRoute(app);
  registerProductsDeleteRoute(app);
}
