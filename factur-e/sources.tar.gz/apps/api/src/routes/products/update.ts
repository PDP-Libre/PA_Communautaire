import type { FastifyInstance } from "fastify";

import {
  ProductUpdateBodySchema,
  VatCategorySchema,
  type ProductUpdateResponse,
  type ProductWarning,
  type VatCategory,
} from "@factur-e/shared-schemas";

import { writeAuthAudit } from "../../auth/audit.js";
import { resolveAuthContext } from "../../auth/context.js";
import * as productsRepo from "../../db/repos/products.js";
import { toProductResponse } from "./list.js";

/**
 * `PATCH /api/products/:id` — update partiel.
 *
 * Auth : Bearer requis, tous rôles authentifiés. 404 si l'id n'est pas
 * dans le tenant ou est hard-deleted.
 *
 * Update partiel : on charge le row existant puis on merge les champs
 * du payload avant validation cohérence `vat_category ↔ vat_rate`
 * (Standard exige rate non-null, autres exigent null). C'est plus
 * stable que `superRefine` sur le body partial qui ne voit pas
 * l'état actuel du row.
 *
 * Warning `duplicate_internal_code` (non bloquant) si on change
 * `internal_code` vers une valeur déjà utilisée par un autre article.
 * On exclut le row courant du match pour ne pas se signaler soi-même.
 *
 * Audit `product_updated` avec `{product_id, label}` en metadata.
 */
export function registerProductsUpdateRoute(app: FastifyInstance): void {
  app.patch<{ Params: { id: string } }>("/api/products/:id", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: "Authentification requise." });
    }

    const parsed = ProductUpdateBodySchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ message: "Données invalides." });
    }
    const body = parsed.data;

    const existing = await productsRepo.findProductById(app.sql, {
      id: req.params.id,
      customerId: ctx.customer_id,
    });
    if (existing === undefined) {
      return reply.code(404).send({ message: "Article introuvable." });
    }

    // Merge body fields onto existing row.
    const next = {
      label: body.label ?? existing.label,
      description: body.description === undefined ? existing.description : body.description,
      internal_code: body.internal_code === undefined ? existing.internal_code : body.internal_code,
      unit_price_ht: body.unit_price_ht ?? existing.unit_price_ht,
      unit: body.unit ?? existing.unit,
      vat_category: body.vat_category ?? existing.vat_category,
      vat_rate: body.vat_rate === undefined ? existing.vat_rate : body.vat_rate,
      category_id: body.category_id === undefined ? existing.category_id : body.category_id,
    };

    // Re-vérifie la cohérence vat_category ↔ vat_rate sur le row mergé.
    const vatCheck = checkVatCoherence(next.vat_category, next.vat_rate);
    if (vatCheck !== null) {
      return reply.code(400).send({ message: vatCheck });
    }

    // Warning duplicate_internal_code (exclut le row courant).
    const warnings: ProductWarning[] = [];
    if (
      typeof next.internal_code === "string" &&
      next.internal_code.length > 0 &&
      next.internal_code !== existing.internal_code
    ) {
      const matches = await productsRepo.findProductsByInternalCode(app.sqlRead, {
        customerId: ctx.customer_id,
        internalCode: next.internal_code,
      });
      const others = matches.filter((r) => r.id !== existing.id);
      const first = others[0];
      if (first !== undefined) {
        warnings.push({
          code: "duplicate_internal_code",
          existing_id: first.id,
          existing_label: first.label,
        });
      }
    }

    const count = await productsRepo.updateProduct(app.sql, {
      id: existing.id,
      customerId: ctx.customer_id,
      label: next.label,
      description: next.description,
      internalCode: next.internal_code,
      unitPriceHt: next.unit_price_ht,
      unit: next.unit,
      vatCategory: next.vat_category,
      vatRate: next.vat_rate,
      categoryId: next.category_id,
    });
    if (count === 0) {
      // Race condition entre findById et updateProduct : le row a été
      // hard-deleted entre temps. Comportement = 404 cohérent.
      return reply.code(404).send({ message: "Article introuvable." });
    }

    const updated = await productsRepo.findProductById(app.sqlRead, {
      id: existing.id,
      customerId: ctx.customer_id,
    });
    if (updated === undefined) {
      return reply.code(404).send({ message: "Article introuvable." });
    }

    await writeAuthAudit(app.sql, {
      event_type: "product_updated",
      success: true,
      user_id: ctx.user_id,
      customer_id: ctx.customer_id,
      ip: req.ip,
      user_agent: req.headers["user-agent"] ?? null,
      metadata: { product_id: updated.id, label: updated.label },
    });

    const response: ProductUpdateResponse = {
      product: toProductResponse(updated),
      warnings,
    };
    return reply.code(200).send(response);
  });
}

function checkVatCoherence(category: VatCategory, rate: string | null): string | null {
  if (!VatCategorySchema.options.includes(category)) {
    return "Catégorie de TVA invalide.";
  }
  if (category === "S" && rate === null) {
    return "Le taux TVA est requis pour la catégorie standard (S).";
  }
  if (category !== "S" && rate !== null) {
    return "Le taux TVA doit être null pour cette catégorie de TVA.";
  }
  return null;
}
