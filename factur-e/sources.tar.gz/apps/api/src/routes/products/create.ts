import type { FastifyInstance } from "fastify";

import {
  ProductCreateBodySchema,
  type ProductCreateResponse,
  type ProductWarning,
} from "@factur-e/shared-schemas";

import { writeAuthAudit } from "../../auth/audit.js";
import { resolveAuthContext } from "../../auth/context.js";
import * as productsRepo from "../../db/repos/products.js";
import { toProductResponse } from "./list.js";

/**
 * `POST /api/products` — création d'un article.
 *
 * Auth : Bearer requis, tous rôles authentifiés peuvent créer un
 * article (décision T-CL-12 — un déposant TPE solo crée ses propres
 * articles, cohérent avec usage cible).
 *
 * Warnings non bloquants : si `internal_code` matche un article
 * existant du même customer, on renvoie 201 + warnings avec
 * `duplicate_internal_code` (cf. T-CW-10 Q5 acté Bruno). L'UI badge
 * la collision côté formulaire mais ne bloque pas.
 *
 * Audit `product_created` (success/failure) avec `{product_id, label}`
 * en metadata. Pas de PII (label = nom commercial, pas un nom personne).
 */
export function registerProductsCreateRoute(app: FastifyInstance): void {
  app.post("/api/products", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: "Authentification requise." });
    }

    const parsed = ProductCreateBodySchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ message: "Données invalides." });
    }
    const body = parsed.data;

    // Detect duplicate internal_code BEFORE insert pour pouvoir
    // retourner le warning avec l'existing match. Doublons autorisés
    // donc on ne bloque pas.
    const warnings: ProductWarning[] = [];
    if (typeof body.internal_code === "string" && body.internal_code.length > 0) {
      const existing = await productsRepo.findProductsByInternalCode(app.sqlRead, {
        customerId: ctx.customer_id,
        internalCode: body.internal_code,
      });
      if (existing.length > 0) {
        const first = existing[0];
        if (first !== undefined) {
          warnings.push({
            code: "duplicate_internal_code",
            existing_id: first.id,
            existing_label: first.label,
          });
        }
      }
    }

    const created = await productsRepo.createProduct(app.sql, {
      customerId: ctx.customer_id,
      label: body.label,
      description: body.description ?? null,
      internalCode: body.internal_code ?? null,
      unitPriceHt: body.unit_price_ht,
      unit: body.unit,
      vatCategory: body.vat_category,
      vatRate: body.vat_rate ?? null,
      categoryId: body.category_id ?? null,
    });

    await writeAuthAudit(app.sql, {
      event_type: "product_created",
      success: true,
      user_id: ctx.user_id,
      customer_id: ctx.customer_id,
      ip: req.ip,
      user_agent: req.headers["user-agent"] ?? null,
      metadata: { product_id: created.id, label: created.label },
    });

    const response: ProductCreateResponse = {
      product: toProductResponse(created),
      warnings,
    };
    return reply.code(201).send(response);
  });
}
