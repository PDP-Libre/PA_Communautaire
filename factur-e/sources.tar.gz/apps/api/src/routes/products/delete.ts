import type { FastifyInstance } from "fastify";

import { writeAuthAudit } from "../../auth/audit.js";
import { resolveAuthContext } from "../../auth/context.js";
import * as productsRepo from "../../db/repos/products.js";
import * as usersRepo from "../../db/repos/users.js";

interface DeleteQuery {
  hard?: string;
}

/**
 * `DELETE /api/products/:id` — suppression d'un article.
 *
 * Comportement par défaut (sans query param) : soft-delete UI =
 * `is_archived = TRUE` via `archiveProduct`. Action utilisateur
 * réversible (UI "désarchiver"). Décision T-CW-09 sprint-02 Q7.
 *
 * `?hard=true` : hard-delete = stamp `deleted_at` via
 * `hardDeleteProduct`. Action admin RGPD irréversible côté API.
 * **Réservé rôle `full`** (les autres rôles n'ont pas accès à la
 * suppression définitive, même pour leurs propres articles).
 *
 * Pas de cascade sur `invoice_lines` (les lignes facture déjà émises
 * sont décorrélées du catalogue — Article = initialiseur, pas binding
 * persistant, cf. T-CW-11).
 *
 * Audit `product_archived` (soft) ou `product_hard_deleted` (hard)
 * avec `{product_id, label}` en metadata. 404 si l'id n'est pas dans
 * le tenant ou déjà hard-deleted.
 */
export function registerProductsDeleteRoute(app: FastifyInstance): void {
  app.delete<{ Params: { id: string }; Querystring: DeleteQuery }>(
    "/api/products/:id",
    async (req, reply) => {
      const ctx = await resolveAuthContext(req);
      if (ctx.state !== "authenticated") {
        return reply.code(401).send({ message: "Authentification requise." });
      }

      const hard = req.query.hard === "true";

      // Hard-delete = role check `full`. Soft-delete (par défaut) =
      // tous rôles authentifiés.
      if (hard) {
        const role = await usersRepo.findActiveUserRoleById(app.sqlRead, ctx.user_id);
        if (role?.role !== "full") {
          return reply.code(403).send({ message: "Permission insuffisante." });
        }
      }

      // Charge le row pour avoir le label dans l'audit (avant suppression).
      const existing = await productsRepo.findProductById(app.sqlRead, {
        id: req.params.id,
        customerId: ctx.customer_id,
      });
      if (existing === undefined) {
        return reply.code(404).send({ message: "Article introuvable." });
      }

      const count = hard
        ? await productsRepo.hardDeleteProduct(app.sql, {
            id: existing.id,
            customerId: ctx.customer_id,
          })
        : await productsRepo.archiveProduct(app.sql, {
            id: existing.id,
            customerId: ctx.customer_id,
          });

      if (count === 0) {
        // Race condition entre findById et delete : 404 cohérent.
        return reply.code(404).send({ message: "Article introuvable." });
      }

      await writeAuthAudit(app.sql, {
        event_type: hard ? "product_hard_deleted" : "product_archived",
        success: true,
        user_id: ctx.user_id,
        customer_id: ctx.customer_id,
        ip: req.ip,
        user_agent: req.headers["user-agent"] ?? null,
        metadata: { product_id: existing.id, label: existing.label },
      });

      return reply.code(204).send();
    },
  );
}
