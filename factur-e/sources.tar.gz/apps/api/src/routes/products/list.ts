import type { FastifyInstance } from "fastify";

import {
  ProductListQuerySchema,
  type ProductListResponse,
  type ProductResponse,
} from "@factur-e/shared-schemas";

import { resolveAuthContext } from "../../auth/context.js";
import type { ProductRow } from "../../db/repos/products.js";

/**
 * `GET /api/products` — liste paginée filtrable des articles d'un customer.
 *
 * Query params (cf. `ProductListQuerySchema`) :
 *  - `search` : ILIKE %label%.
 *  - `category_id` : filtre catégorie (UUID).
 *  - `include_archived` : `"true"` pour inclure les articles archivés
 *    (défaut `false`).
 *  - `cursor` : opaque, renvoyé tel quel pour aller à la page suivante.
 *  - `limit` : défaut 50, max 200.
 *
 * Pagination : cursor composite `(label, id)` base64url-encodé. Ordre
 * `label ASC, id ASC`. Postgres supporte la comparaison de tuples
 * nativement (`WHERE (label, id) > (?, ?)`).
 *
 * Auth : Bearer requis, tous rôles authentifiés (full + deposit_simple
 * + deposit_states peuvent consulter le catalogue — décision T-CL-12).
 *
 * Cf. plan T-CL-12 sprint-03 + repos T-CL-11.
 */
export function registerProductsListRoute(app: FastifyInstance): void {
  app.get("/api/products", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: "Authentification requise." });
    }

    const parsed = ProductListQuerySchema.safeParse(req.query);
    if (!parsed.success) {
      return reply.code(400).send({ message: "Paramètres invalides." });
    }
    const { search, category_id, include_archived, cursor, limit } = parsed.data;
    const effectiveLimit = limit ?? 50;

    const decoded = cursor !== undefined ? decodeCursor(cursor) : null;
    if (cursor !== undefined && decoded === null) {
      return reply.code(400).send({ message: "Cursor invalide." });
    }

    // On query `limit + 1` rows pour détecter s'il y a une page suivante
    // sans nécessiter un COUNT séparé. Si on récupère exactement
    // `limit + 1`, le 1er des `limit` reste la page courante et le dernier
    // sert à construire le `next_cursor`.
    const rows = await app.sqlRead<ProductRow[]>`
      SELECT id, customer_id, label, description, internal_code,
             unit_price_ht, unit, vat_category, vat_rate, category_id,
             is_archived, created_at, updated_at
      FROM products
      WHERE customer_id = ${ctx.customer_id}
        AND deleted_at IS NULL
        ${include_archived ? app.sqlRead`` : app.sqlRead`AND is_archived = FALSE`}
        ${
          search !== undefined && search !== ""
            ? app.sqlRead`AND label ILIKE ${"%" + search + "%"}`
            : app.sqlRead``
        }
        ${category_id !== undefined ? app.sqlRead`AND category_id = ${category_id}` : app.sqlRead``}
        ${
          decoded !== null
            ? app.sqlRead`AND (label, id) > (${decoded.label}, ${decoded.id})`
            : app.sqlRead``
        }
      ORDER BY label ASC, id ASC
      LIMIT ${effectiveLimit + 1}
    `;

    const hasMore = rows.length > effectiveLimit;
    const page = hasMore ? rows.slice(0, effectiveLimit) : rows;
    const last = page[page.length - 1];
    const nextCursor =
      hasMore && last !== undefined ? encodeCursor({ label: last.label, id: last.id }) : null;

    const body: ProductListResponse = {
      items: page.map(toProductResponse),
      next_cursor: nextCursor,
    };
    return reply.code(200).send(body);
  });
}

interface CursorPayload {
  label: string;
  id: string;
}

function encodeCursor(payload: CursorPayload): string {
  return Buffer.from(JSON.stringify(payload), "utf8").toString("base64url");
}

function decodeCursor(raw: string): CursorPayload | null {
  try {
    const json = Buffer.from(raw, "base64url").toString("utf8");
    const parsed = JSON.parse(json) as unknown;
    if (
      parsed === null ||
      typeof parsed !== "object" ||
      !("label" in parsed) ||
      !("id" in parsed) ||
      typeof (parsed as { label: unknown }).label !== "string" ||
      typeof (parsed as { id: unknown }).id !== "string"
    ) {
      return null;
    }
    return { label: (parsed as CursorPayload).label, id: (parsed as CursorPayload).id };
  } catch {
    return null;
  }
}

export function toProductResponse(row: ProductRow): ProductResponse {
  return {
    id: row.id,
    label: row.label,
    description: row.description,
    internal_code: row.internal_code,
    unit_price_ht: row.unit_price_ht,
    unit: row.unit,
    vat_category: row.vat_category,
    vat_rate: row.vat_rate,
    category_id: row.category_id,
    is_archived: row.is_archived,
    created_at: row.created_at.toISOString(),
    updated_at: row.updated_at.toISOString(),
  };
}
