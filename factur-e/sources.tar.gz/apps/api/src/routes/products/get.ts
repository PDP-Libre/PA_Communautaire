import type { FastifyInstance } from "fastify";

import { resolveAuthContext } from "../../auth/context.js";
import * as productsRepo from "../../db/repos/products.js";
import { toProductResponse } from "./list.js";

/**
 * `GET /api/products/:id` — fiche unique d'un article.
 *
 * Auth : Bearer requis, tous rôles authentifiés.
 * 404 si l'id n'est pas dans le tenant ou est hard-deleted. Les
 * articles archivés (`is_archived=true`) restent accessibles (UI
 * "désarchiver" doit pouvoir les consulter).
 */
export function registerProductsGetRoute(app: FastifyInstance): void {
  app.get<{ Params: { id: string } }>("/api/products/:id", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: "Authentification requise." });
    }
    const row = await productsRepo.findProductById(app.sqlRead, {
      id: req.params.id,
      customerId: ctx.customer_id,
    });
    if (row === undefined) {
      return reply.code(404).send({ message: "Article introuvable." });
    }
    return reply.code(200).send(toProductResponse(row));
  });
}
