import type { FastifyInstance } from "fastify";

import {
  type InvoiceDraftCreateBody,
  type InvoiceDraftListResponse,
  type InvoiceDraftResponse,
  type InvoiceDraftUpdateBody,
  InvoiceDraftCreateBodySchema,
  InvoiceDraftUpdateBodySchema,
} from "@factur-e/shared-schemas";

import { resolveAuthContext } from "../../auth/context.js";
import {
  type InvoiceDraftRow,
  deleteDraftById,
  findActiveDraftsByCustomerId,
  findDraftByIdAndCustomer,
  insertDraft,
  updateDraft,
} from "../../db/repos/invoice_drafts.js";

/**
 * CRUD `/api/invoice-drafts/*` sprint-04 T-CL-API-INVOICE.
 *
 * Consommé par auto-save 5s côté UI formulaire (US-EMIT-008-bis acté
 * T-CW-09 §10.1 #4). Hook React `useInvoiceDraftAutoSave(formValues)` :
 *   - POST initial au 1er onBlur d'un champ rempli.
 *   - PATCH ensuite (débounce 5s d'inactivité + à chaque
 *     `onSectionChange` Stepper).
 *
 * Tous endpoints requièrent auth + tenant isolation (404 si pas du
 * customer pour GET/PATCH/DELETE).
 */

function toDraftResponse(row: InvoiceDraftRow): InvoiceDraftResponse {
  return {
    id: row.id,
    customer_id: row.customer_id,
    payload: row.payload,
    step_completed: row.step_completed,
    last_modified_at: row.last_modified_at.toISOString(),
    created_at: row.created_at.toISOString(),
  };
}

export function registerInvoiceDraftsRoutes(app: FastifyInstance): void {
  // POST /api/invoice-drafts
  app.post("/api/invoice-drafts", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: "Authentification requise." });
    }
    const parsed = InvoiceDraftCreateBodySchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ message: "Brouillon invalide.", issues: parsed.error.issues });
    }
    const body: InvoiceDraftCreateBody = parsed.data;
    const row = await insertDraft(app.sql, {
      customerId: ctx.customer_id,
      payload: body.payload,
      stepCompleted: body.step_completed,
    });
    return reply.code(201).send(toDraftResponse(row));
  });

  // GET /api/invoice-drafts
  app.get("/api/invoice-drafts", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: "Authentification requise." });
    }
    const rows = await findActiveDraftsByCustomerId(app.sqlRead, ctx.customer_id);
    const response: InvoiceDraftListResponse = {
      items: rows.map(toDraftResponse),
    };
    return reply.code(200).send(response);
  });

  // GET /api/invoice-drafts/:id
  app.get<{ Params: { id: string } }>("/api/invoice-drafts/:id", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: "Authentification requise." });
    }
    const row = await findDraftByIdAndCustomer(app.sqlRead, {
      id: req.params.id,
      customerId: ctx.customer_id,
    });
    if (row === undefined) {
      return reply.code(404).send({ message: "Brouillon introuvable." });
    }
    return reply.code(200).send(toDraftResponse(row));
  });

  // PATCH /api/invoice-drafts/:id
  app.patch<{ Params: { id: string } }>("/api/invoice-drafts/:id", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: "Authentification requise." });
    }
    const parsed = InvoiceDraftUpdateBodySchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({
        message: "Brouillon invalide.",
        issues: parsed.error.issues,
      });
    }
    const body: InvoiceDraftUpdateBody = parsed.data;
    const count = await updateDraft(app.sql, {
      id: req.params.id,
      customerId: ctx.customer_id,
      payload: body.payload,
      stepCompleted: body.step_completed,
    });
    if (count === 0) {
      return reply.code(404).send({ message: "Brouillon introuvable." });
    }
    const row = await findDraftByIdAndCustomer(app.sqlRead, {
      id: req.params.id,
      customerId: ctx.customer_id,
    });
    if (row === undefined) {
      return reply.code(404).send({ message: "Brouillon introuvable." });
    }
    return reply.code(200).send(toDraftResponse(row));
  });

  // DELETE /api/invoice-drafts/:id
  app.delete<{ Params: { id: string } }>("/api/invoice-drafts/:id", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: "Authentification requise." });
    }
    const count = await deleteDraftById(app.sql, {
      id: req.params.id,
      customerId: ctx.customer_id,
    });
    if (count === 0) {
      return reply.code(404).send({ message: "Brouillon introuvable." });
    }
    return reply.code(204).send();
  });
}
