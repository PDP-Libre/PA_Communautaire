import { type CascadeResult, schematronRuleLabel } from "@factur-e/factur-x-builder";
import type {
  CdarEventResponse,
  InvoiceLineResponse,
  InvoiceResponse,
  LinkedInvoiceSummary,
  SchematronAnomaly,
} from "@factur-e/shared-schemas";

import type { CdarEventRow } from "../../db/repos/cdar_events.js";
import type { InvoiceLineRow } from "../../db/repos/invoice_lines.js";
import type { InvoiceRow, LinkedInvoiceSummaryRow } from "../../db/repos/invoices.js";

/** Sérialise un `InvoiceRow` BDD en `InvoiceResponse` API. */
export function toInvoiceResponse(row: InvoiceRow): InvoiceResponse {
  return {
    id: row.id,
    customer_id: row.customer_id,
    number: row.number,
    issue_date: row.issue_date.toISOString().slice(0, 10),
    tracking_id: row.tracking_id,
    total_ht: row.total_ht,
    total_vat: row.total_vat,
    total_ttc: row.total_ttc,
    currency: row.currency,
    processing_rule: row.processing_rule,
    type_code: row.type_code,
    preceding_invoice_id: row.preceding_invoice_id,
    pa_invoice_id: row.pa_invoice_id,
    pa_provider: row.pa_provider,
    sha256: row.sha256,
    submitted_at: row.submitted_at?.toISOString() ?? null,
    status_current: row.status_current,
    payload_extended: row.payload_extended,
    created_at: row.created_at.toISOString(),
    updated_at: row.updated_at.toISOString(),
  };
}

export function toInvoiceLineResponse(row: InvoiceLineRow): InvoiceLineResponse {
  return {
    id: row.id,
    invoice_id: row.invoice_id,
    line_number: row.line_number,
    label: row.label,
    description: row.description,
    quantity: row.quantity,
    unit_code: row.unit_code,
    unit_price_ht: row.unit_price_ht,
    vat_rate: row.vat_rate,
    vat_category: row.vat_category,
    total_ht: row.total_ht,
    period_start: row.period_start?.toISOString().slice(0, 10) ?? null,
    period_end: row.period_end?.toISOString().slice(0, 10) ?? null,
    allowance_amount: row.allowance_amount,
    charge_amount: row.charge_amount,
    payload_extended: row.payload_extended,
  };
}

/** Sérialise un résumé de facture liée (BG-3) pour `LinkedInvoiceBanner`. */
export function toLinkedInvoiceSummary(row: LinkedInvoiceSummaryRow): LinkedInvoiceSummary {
  return {
    id: row.id,
    number: row.number,
    issue_date: row.issue_date.toISOString().slice(0, 10),
    type_code: row.type_code,
    status_current: row.status_current,
  };
}

export function toCdarEventResponse(row: CdarEventRow): CdarEventResponse {
  return {
    id: row.id,
    invoice_id: row.invoice_id,
    code: row.code,
    label: row.label,
    occurred_at: row.occurred_at.toISOString(),
    payload: row.payload,
    source: row.source,
    reason: row.reason,
    created_at: row.created_at.toISOString(),
  };
}

/** Détection du prochain numéro depuis un pattern existant (regex
 *  `^(.+?)(\d+)$` → +1 zfill conservé). Q6 acté Bruno : algo backend. */
export function suggestNextInvoiceNumber(latestNumber: string | undefined): string {
  const year = String(new Date().getUTCFullYear());
  if (latestNumber === undefined || latestNumber === "") {
    return `F-${year}-0001`;
  }
  const match = /^(.+?)(\d+)$/.exec(latestNumber);
  if (match === null) {
    return `F-${year}-0001`;
  }
  const prefix = match[1] ?? "";
  const numStr = match[2] ?? "0";
  const next = (Number(numStr) + 1).toString().padStart(numStr.length, "0");
  return `${prefix}${next}`;
}

/** S1 — aplatit les assertions Schematron d'une `CascadeResult` (par sévérité)
 *  en anomalies API (avec l'étape de la cascade). Consommé à l'émission pour le
 *  corps 422 (fatales) et les avertissements 201 (warnings). */
export function toSchematronAnomalies(
  cascade: CascadeResult,
  severity: "fatal" | "warning",
): SchematronAnomaly[] {
  return cascade.steps.flatMap((s) =>
    (severity === "fatal" ? s.fatals : s.warnings).map((a) => ({
      rule_id: a.ruleId,
      severity,
      message: a.message,
      label_fr: schematronRuleLabel(a.ruleId) ?? null,
      xpath: a.xpath,
      step: s.step,
    })),
  );
}
