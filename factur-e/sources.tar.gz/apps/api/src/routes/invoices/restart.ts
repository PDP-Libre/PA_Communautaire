import type { FastifyInstance } from "fastify";

import type { InvoiceRestartResponse } from "@factur-e/shared-schemas";

import { writeAuthAudit } from "../../auth/audit.js";
import { resolveAuthContext } from "../../auth/context.js";
import { insertDraft } from "../../db/repos/invoice_drafts.js";
import { findLinesByInvoiceId } from "../../db/repos/invoice_lines.js";
import {
  findInvoiceByIdAndCustomer,
  findLatestInvoiceNumberByCustomer,
} from "../../db/repos/invoices.js";

import { suggestNextInvoiceNumber } from "./_shared.js";

/**
 * `POST /api/invoices/:id/restart` — clone une facture émise vers un
 * NOUVEAU brouillon (acté US-EMIT-009-bis sprint-04, T-CW-09 §10.1).
 *
 * **Mécanique Article = initialiseur (T-CW-11)** : les lignes copiées
 * sont **indépendantes** de l'invoice source. Modifier une ligne du
 * clone ne modifie pas l'invoice source ni les `products` catalogue.
 * Test négatif obligatoire dans `apps/api/tests/http/invoices/`.
 *
 * Pré-remplissage du brouillon :
 *   - `number` = auto-suggéré via `suggestNextInvoiceNumber(latest)`
 *   - `issueDate` = aujourd'hui
 *   - `buyer` = clone identique (siren + adresse depuis annuaire)
 *   - `lines` = clone profond, sans référence à la source
 *   - `payment` = défauts customer (pas reprise source)
 *
 * Audit `invoice_restarted_from` avec `{source_invoice_id,
 * new_draft_id}`.
 */
export function registerInvoicesRestartRoute(app: FastifyInstance): void {
  app.post<{ Params: { id: string } }>("/api/invoices/:id/restart", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: "Authentification requise." });
    }

    const source = await findInvoiceByIdAndCustomer(app.sqlRead, {
      id: req.params.id,
      customerId: ctx.customer_id,
    });
    if (source === undefined) {
      return reply.code(404).send({ message: "Facture introuvable." });
    }

    const lines = await findLinesByInvoiceId(app.sqlRead, source.id);
    const latest = await findLatestInvoiceNumberByCustomer(app.sqlRead, ctx.customer_id);
    const suggestedNumber = suggestNextInvoiceNumber(latest);
    const today = new Date().toISOString().slice(0, 10);

    // Construit le payload draft permissif — l'UI re-validera contre
    // InvoiceFormSchema avant POST /api/invoices (envoi effectif).
    // `restartedFromInvoiceId` est conservé en métadonnée pour
    // afficher le `<RestartedFromBanner>` côté UI (T-CL-UI-01).
    const buyerSnapshot = (source.payload_extended.buyer ?? null) as Record<string, unknown> | null;
    const payload: Record<string, unknown> = {
      ui_mode: "base",
      restartedFromInvoiceId: source.id,
      restartedFromNumber: source.number,
      document: {
        number: suggestedNumber,
        issueDate: today,
        notes: null,
      },
      parties: {
        buyer: buyerSnapshot,
      },
      // Clone profond des lignes — référence Article supprimée
      // (mécanique initialiseur T-CW-11).
      lines: lines.map((l) => ({
        label: l.label,
        description: l.description,
        quantity: l.quantity,
        unitCode: l.unit_code,
        unitPriceHt: l.unit_price_ht,
        vatCategory: l.vat_category,
        vatRate: l.vat_rate,
        totalHt: l.total_ht,
      })),
      payment: {
        paymentTerms: { kind: "days", days: 30 },
        paymentMethodKind: "transfer",
        mentionsLegales: null,
      },
    };

    const draft = await insertDraft(app.sql, {
      customerId: ctx.customer_id,
      payload,
      stepCompleted: { document: 100, parties: 100, lines: 100, payment: 0 },
    });

    await writeAuthAudit(app.sql, {
      event_type: "invoice_restarted_from",
      success: true,
      user_id: ctx.user_id,
      customer_id: ctx.customer_id,
      ip: req.ip,
      user_agent: req.headers["user-agent"] ?? null,
      metadata: { source_invoice_id: source.id, new_draft_id: draft.id },
    });

    const response: InvoiceRestartResponse = { newDraftId: draft.id };
    return reply.code(201).send(response);
  });
}
