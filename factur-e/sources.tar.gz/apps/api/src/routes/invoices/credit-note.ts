import type { FastifyInstance } from "fastify";

import { type CreditNoteResponse, CreditNoteRequestSchema } from "@factur-e/shared-schemas";

import { writeAuthAudit } from "../../auth/audit.js";
import { resolveAuthContext } from "../../auth/context.js";
import { insertDraft } from "../../db/repos/invoice_drafts.js";
import { findLinesByInvoiceId } from "../../db/repos/invoice_lines.js";
import {
  findInvoiceByIdAndCustomer,
  findLatestInvoiceNumberByCustomerAndPrefix,
} from "../../db/repos/invoices.js";
import { findActiveUserRoleById, type UserRole } from "../../db/repos/users.js";

import { suggestNextInvoiceNumber } from "./_shared.js";

/**
 * `POST /api/invoices/:id/credit-note` — crée un brouillon **avoir total
 * (381)** ou **rectificative (384)** à partir d'une facture émise (L11
 * sprint-06, brief §3.1.1 / §3.1.2 + PRD §3.11 AVOIR-5/6).
 *
 * **Modèle brouillon (arbitrage Bruno D-A)** : comme `POST /:id/restart`, on
 * crée une ligne `invoice_drafts` pré-remplie (PAS de ligne `invoices` — une
 * facture définitive n'existe qu'après envoi PA via `POST /api/invoices`).
 * Le brouillon porte `document.typeCode` (381/384) + les métadonnées BG-3
 * (`precedingInvoiceId/Number/IssueDate`) ; `formToModel` les sérialise en
 * `tradeSettlement.precedingInvoices` (BR-55) à l'envoi, et la pose 209 auto
 * sur l'origine (384) est gérée dans `create.ts`. Réponse 201 `{ newDraftId,
 * type_code }` → le frontend redirige vers `/emission/new?draft_id={id}`.
 *
 * Pipeline (RBAC calqué sur `mark-paid.ts`, clone calqué sur `restart.ts`) :
 *  1. Auth (401) + RBAC `['full','deposit_states']` (403).
 *  2. Lookup scope customer (404 si pas owned).
 *  3. Gate type : origine doit être une facture standard 380 — refus 381/384
 *     (chaînage non supporté MVP, AVOIR-9) → 409.
 *  4. Gate statut : origine doit être post-envoi (transmise, non annulée) →
 *     409 sinon.
 *  5. Body Zod `{ type_code: '381' | '384' }`.
 *  6. Clone lignes (montants positifs identiques — c'est le BT-3 qui change la
 *     nature fiscale, pas le signe, brief §3.1.1) + numéro suggéré AV-/R- +
 *     métadonnées BG-3 → `insertDraft`.
 *  7. Audit `invoice.credit_note_created` + 201.
 */

// Z3 — Full + Responsable, cohérent mark-paid.ts (autres CTA cycle Émission).
const ALLOWED_ROLES: readonly UserRole[] = ["full", "deposit_states"];

// Statuts post-envoi éligibles à une action corrective (brief §3.1.1 + §4.1).
const ELIGIBLE_STATUSES: ReadonlySet<string> = new Set([
  "available_to_recipient",
  "in_process",
  "accepted_business",
  "refused_business",
  "paid",
]);

const NUMBER_PREFIX: Record<"381" | "384", string> = {
  "381": "AV-",
  "384": "R-",
};

export function registerInvoicesCreditNoteRoute(app: FastifyInstance): void {
  app.post<{ Params: { id: string } }>("/api/invoices/:id/credit-note", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: "Authentification requise." });
    }

    // RBAC : le contexte auth ne porte pas le rôle, on le recharge (ADR-006).
    const roleRow = await findActiveUserRoleById(app.sql, ctx.user_id);
    if (roleRow === undefined || !ALLOWED_ROLES.includes(roleRow.role)) {
      return reply.code(403).send({
        message: "Permission insuffisante pour créer un avoir ou une rectificative.",
      });
    }

    const parsed = CreditNoteRequestSchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({
        message: "Type de document invalide.",
        issues: parsed.error.issues,
      });
    }
    const { type_code: typeCode } = parsed.data;

    const origin = await findInvoiceByIdAndCustomer(app.sqlRead, {
      id: req.params.id,
      customerId: ctx.customer_id,
    });
    if (origin === undefined) {
      return reply.code(404).send({ message: "Facture introuvable." });
    }

    // Gate type : pas de chaînage avoir→avoir / rectificative→rectificative
    // (AVOIR-9 hors scope MVP — cohérent masquage CTA côté UI sur fiches 381/384).
    if (origin.type_code !== "380") {
      return reply.code(409).send({
        message: "Création d'un avoir à partir d'un avoir ou d'une rectificative non supportée.",
      });
    }

    // Gate statut : origine déjà annulée (209) → aucune action possible ;
    // sinon doit être dans un statut post-envoi.
    if (origin.status_current === "cancelled") {
      return reply.code(409).send({
        message: "Cette facture est déjà annulée. Aucune action corrective possible.",
      });
    }
    if (origin.status_current === null || !ELIGIBLE_STATUSES.has(origin.status_current)) {
      return reply.code(409).send({
        message: "Aucune action corrective possible sur cette facture dans son statut actuel.",
      });
    }

    // Clone des lignes — montants positifs identiques à l'origine (BT-3 = 381/384
    // change la nature fiscale, pas le signe). Pour une rectificative, éditables
    // ensuite dans le formulaire. Référence Article supprimée (lignes
    // indépendantes, mécanique initialiseur T-CW-11, cohérent restart.ts).
    const lines = await findLinesByInvoiceId(app.sqlRead, origin.id);

    const prefix = NUMBER_PREFIX[typeCode];
    const latest = await findLatestInvoiceNumberByCustomerAndPrefix(app.sqlRead, {
      customerId: ctx.customer_id,
      prefix,
    });
    const suggestedNumber =
      latest !== undefined
        ? suggestNextInvoiceNumber(latest)
        : `${prefix}${String(new Date().getUTCFullYear())}-001`;
    const today = new Date().toISOString().slice(0, 10);
    const originIssueDate = origin.issue_date.toISOString().slice(0, 10);

    const buyerSnapshot = (origin.payload_extended.buyer ?? null) as Record<string, unknown> | null;

    const payload: Record<string, unknown> = {
      ui_mode: "base",
      // Métadonnées lien BG-3 (consommées par formToModel + bandeau UI).
      precedingInvoiceId: origin.id,
      precedingInvoiceNumber: origin.number,
      precedingIssueDate: originIssueDate,
      document: {
        number: suggestedNumber,
        issueDate: today,
        typeCode, // BT-3 — 381 / 384
        notes: null,
      },
      parties: {
        buyer: buyerSnapshot,
      },
      lines: lines.map((l) => ({
        label: l.label,
        description: l.description,
        quantity: l.quantity,
        unitCode: l.unit_code,
        unitPriceHt: l.unit_price_ht,
        vatCategory: l.vat_category,
        vatRate: l.vat_rate,
        totalHt: l.total_ht,
      })),
      payment: {
        paymentTerms: { kind: "days", days: 30 },
        paymentMethodKind: "transfer",
        mentionsLegales: null,
      },
    };

    const draft = await insertDraft(app.sql, {
      customerId: ctx.customer_id,
      payload,
      stepCompleted: { document: 100, parties: 100, lines: 100, payment: 0 },
    });

    await writeAuthAudit(app.sql, {
      event_type: "invoice.credit_note_created",
      success: true,
      user_id: ctx.user_id,
      customer_id: ctx.customer_id,
      ip: req.ip,
      user_agent: req.headers["user-agent"] ?? null,
      metadata: { source_invoice_id: origin.id, new_draft_id: draft.id, type_code: typeCode },
    });

    const response: CreditNoteResponse = { newDraftId: draft.id, type_code: typeCode };
    return reply.code(201).send(response);
  });
}
