import type { FastifyInstance } from "fastify";

import {
  type InvoiceListItem,
  type InvoiceListResponse,
  InvoiceListQuerySchema,
} from "@factur-e/shared-schemas";

import { resolveAuthContext } from "../../auth/context.js";
import {
  countActiveInvoicesByCustomerId,
  countChildrenByPrecedingIds,
  findActiveInvoicesByCustomerId,
  findInvoiceNumbersByIds,
} from "../../db/repos/invoices.js";

import { toInvoiceResponse } from "./_shared.js";

/**
 * `GET /api/invoices` — liste des factures du customer, filtrable +
 * paginée. Consommé par la page Émission §6.2 brief.
 *
 * Query params (Zod-validated, tous optionnels) :
 *   - status (match exact sur status_current)
 *   - type_code (CSV BT-3 — pills L11 "Avoirs" 381 / "Rectificatives" 384)
 *   - client (SIREN — match sur payload_extended->buyer.siren)
 *   - date_from / date_to (issue_date >= / <=)
 *   - min_amount / max_amount (total_ttc >= / <=)
 *   - search (ILIKE %number% — mono pattern UI)
 *   - limit / offset (pagination cursor-less MVP)
 *
 * Chaque item est enrichi L11 (sans N+1) : `preceding_invoice_number`
 * (numéro origine pour un avoir/rectificative) + `linked_children_count`
 * (nb d'avoirs/rectificatives pointant cette facture) → icône "Lien" +
 * badge "Type" liste sans re-fetch (brief §3.2.4 / §4.7).
 *
 * Retour : `{ items, total, limit, offset }`.
 */
export function registerInvoicesListRoute(app: FastifyInstance): void {
  app.get("/api/invoices", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: "Authentification requise." });
    }

    const parsed = InvoiceListQuerySchema.safeParse(req.query);
    if (!parsed.success) {
      return reply.code(400).send({
        message: "Paramètres invalides.",
        issues: parsed.error.issues,
      });
    }
    const q = parsed.data;

    const filters = {
      status: q.status,
      typeCode: q.type_code,
      client: q.client,
      dateFrom: q.date_from,
      dateTo: q.date_to,
      minAmount: q.min_amount,
      maxAmount: q.max_amount,
      search: q.search,
      retention: q.retention,
      limit: q.limit,
      offset: q.offset,
    };

    const [rows, total] = await Promise.all([
      findActiveInvoicesByCustomerId(app.sqlRead, ctx.customer_id, filters),
      countActiveInvoicesByCustomerId(app.sqlRead, ctx.customer_id, filters),
    ]);

    // Enrichissement BG-3 batch (2 requêtes, pas de N+1).
    const precedingIds = [
      ...new Set(rows.map((r) => r.preceding_invoice_id).filter((id): id is string => id !== null)),
    ];
    const pageIds = rows.map((r) => r.id);
    const [precedingNumbers, childCounts] = await Promise.all([
      findInvoiceNumbersByIds(app.sqlRead, { customerId: ctx.customer_id, ids: precedingIds }),
      countChildrenByPrecedingIds(app.sqlRead, { customerId: ctx.customer_id, originIds: pageIds }),
    ]);
    const numberById = new Map(precedingNumbers.map((n) => [n.id, n.number]));
    const childCountByOrigin = new Map(childCounts.map((c) => [c.preceding_invoice_id, c.count]));

    const items: InvoiceListItem[] = rows.map((row) => ({
      ...toInvoiceResponse(row),
      preceding_invoice_number:
        row.preceding_invoice_id !== null
          ? (numberById.get(row.preceding_invoice_id) ?? null)
          : null,
      linked_children_count: childCountByOrigin.get(row.id) ?? 0,
    }));

    const response: InvoiceListResponse = {
      items,
      total,
      limit: q.limit,
      offset: q.offset,
    };
    return reply.code(200).send(response);
  });
}
