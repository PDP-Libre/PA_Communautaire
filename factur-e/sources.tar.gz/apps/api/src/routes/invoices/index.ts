import type { FastifyInstance } from "fastify";

import { registerInvoicesCheckNumberUniqueRoute } from "./check-number-unique.js";
import { registerInvoicesCreateRoute } from "./create.js";
import { registerInvoicesCreditNoteRoute } from "./credit-note.js";
import { registerInvoicesEventsRoute } from "./events.js";
import { registerInvoicesGetRoute } from "./get.js";
import { registerInvoicesListRoute } from "./list.js";
import { registerInvoicesMarkPaidRoute } from "./mark-paid.js";
import { registerInvoicesPdfRoute } from "./pdf.js";
import { registerInvoicesPreviewRoute } from "./preview.js";
import { registerInvoicesRestartRoute } from "./restart.js";
import { registerInvoicesXmlRoute } from "./xml.js";

/**
 * Routes `/api/invoices/*` sprint-04 T-CL-API-INVOICE :
 *   POST /api/invoices/preview               (sans persist)
 *   POST /api/invoices                       (pipeline transactionnel)
 *   GET  /api/invoices                       (liste filtrée)
 *   GET  /api/invoices/:id                   (fiche)
 *   POST /api/invoices/:id/restart           (clone draft)
 *   POST /api/invoices/:id/mark-paid         (pose 212 Encaissée — sprint-06)
 *   POST /api/invoices/:id/credit-note       (brouillon avoir 381 / rectif 384 — L11)
 *   GET  /api/invoices/:id/pdf               (re-généré)
 *   GET  /api/invoices/:id/xml               (re-généré)
 *   GET  /api/invoices/:id/events            (SSE polling 3s)
 *   POST /api/invoices/check-number-unique   (unicité + suggestion)
 *
 * NB : la route `POST /api/invoices/check-number-unique` est enregistrée
 * AVANT `POST /api/invoices/:id/restart` pour que Fastify route matche
 * `check-number-unique` comme path littéral, pas comme `:id=check-number-unique`.
 * (Fastify supporte mais les routes statiques ont la priorité dans
 * l'enregistrement.)
 */
export function registerInvoicesRoutes(app: FastifyInstance): void {
  registerInvoicesCheckNumberUniqueRoute(app);
  registerInvoicesPreviewRoute(app);
  registerInvoicesListRoute(app);
  registerInvoicesCreateRoute(app);
  registerInvoicesGetRoute(app);
  registerInvoicesRestartRoute(app);
  registerInvoicesMarkPaidRoute(app);
  registerInvoicesCreditNoteRoute(app);
  registerInvoicesPdfRoute(app);
  registerInvoicesXmlRoute(app);
  registerInvoicesEventsRoute(app);
}
