import type { FastifyInstance } from "fastify";

import type { InvoiceDetailResponse } from "@factur-e/shared-schemas";

import { resolveAuthContext } from "../../auth/context.js";
import { findCdarEventsByInvoiceId } from "../../db/repos/cdar_events.js";
import { findLinesByInvoiceId } from "../../db/repos/invoice_lines.js";
import {
  findInvoiceByIdAndCustomer,
  findLinkedChildrenByPrecedingId,
} from "../../db/repos/invoices.js";

import {
  toCdarEventResponse,
  toInvoiceLineResponse,
  toInvoiceResponse,
  toLinkedInvoiceSummary,
} from "./_shared.js";

/**
 * `GET /api/invoices/:id` — fiche détaillée d'une facture émise.
 *
 * Inter-tenant safe : 404 si pas du customer (ne leak pas l'existence
 * d'une invoice cross-tenant).
 *
 * Retour : `{ invoice, lines, cdar_events, preceding_invoice, linked_invoices }`
 *  — alimente §6.11 brief (timeline CDAR) + L11 `LinkedInvoiceBanner` :
 *    - `preceding_invoice` : facture d'origine (avoir/rectificative) ;
 *    - `linked_invoices` : documents enfants (facture d'origine ayant des
 *      avoirs/rectificatives — variant multi-children).
 */
export function registerInvoicesGetRoute(app: FastifyInstance): void {
  app.get<{ Params: { id: string } }>("/api/invoices/:id", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: "Authentification requise." });
    }

    const invoice = await findInvoiceByIdAndCustomer(app.sqlRead, {
      id: req.params.id,
      customerId: ctx.customer_id,
    });
    if (invoice === undefined) {
      return reply.code(404).send({ message: "Facture introuvable." });
    }

    const [lines, cdarEvents, children] = await Promise.all([
      findLinesByInvoiceId(app.sqlRead, invoice.id),
      findCdarEventsByInvoiceId(app.sqlRead, invoice.id),
      findLinkedChildrenByPrecedingId(app.sqlRead, {
        originId: invoice.id,
        customerId: ctx.customer_id,
      }),
    ]);

    // BG-3 — résolution de la facture d'origine (avoir/rectificative).
    const precedingRow =
      invoice.preceding_invoice_id !== null
        ? await findInvoiceByIdAndCustomer(app.sqlRead, {
            id: invoice.preceding_invoice_id,
            customerId: ctx.customer_id,
          })
        : undefined;

    const response: InvoiceDetailResponse = {
      invoice: toInvoiceResponse(invoice),
      lines: lines.map(toInvoiceLineResponse),
      cdar_events: cdarEvents.map(toCdarEventResponse),
      preceding_invoice: precedingRow !== undefined ? toLinkedInvoiceSummary(precedingRow) : null,
      linked_invoices: children.map(toLinkedInvoiceSummary),
    };
    return reply.code(200).send(response);
  });
}
