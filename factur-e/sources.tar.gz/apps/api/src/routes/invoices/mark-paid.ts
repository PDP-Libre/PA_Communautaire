import type { FastifyInstance, FastifyReply } from "fastify";

import {
  InvoiceRejectedXsdException,
  PaAccessTokenExpiredException,
  PaForbiddenException,
  PaRateLimitException,
  PaSubmissionFailedException,
  PaUnavailableException,
} from "@factur-e/pa-adapter";

import { writeAuthAudit } from "../../auth/audit.js";
import { resolveAuthContext } from "../../auth/context.js";
import { findCdarEventsByInvoiceId, insertCdarEvent } from "../../db/repos/cdar_events.js";
import { findActiveCustomerById } from "../../db/repos/customers.js";
import { findInvoiceByIdAndCustomer, updateInvoiceStatusCurrent } from "../../db/repos/invoices.js";
import { findActivePaConnectionForDisconnectByCustomerId } from "../../db/repos/pa_connections.js";
import { findActiveUserRoleById, type UserRole } from "../../db/repos/users.js";
import { withTransaction } from "../../db/tx.js";

import { toCdarEventResponse, toInvoiceResponse } from "./_shared.js";

/**
 * `POST /api/invoices/:id/mark-paid` — pose le statut 212 Encaissée côté
 * Émetteur (US-CDAR-008 PRD §5.11, sortie backlog sprint-06 W3). Déclenche la
 * remontée TVA fiscale (TVA sur encaissement) ou clôt le cycle commercial.
 *
 * Pipeline (calqué sur reception `POST /received-invoices/:id/cdar`) :
 *  1. Auth (401) + RBAC Full/Responsable `['full','deposit_states']` (403, Z3).
 *  2. Lookup scope customer (404 si pas owned).
 *  3. Gate statut : seul 205 Approuvée (= `accepted_business`) autorise la pose
 *     212 (PRD §5.11 ligne 1371 + Z4) → 409 sinon.
 *  4. `driver.createInvoiceEvent` statusCode `fr:212` (POST /v1.beta/invoice_events
 *     — le `/cdar` du PRD §5.11 est une approximation, l'impl driver V1 acquise
 *     sprint-04/05 est `invoice_events`). Échec PA → 4xx/5xx (NC-15), pas
 *     d'écriture BDD (on ne marque pas un statut non transmis).
 *  5. Succès : INSERT cdar_events (source 'app') + UPDATE status_current + audit
 *     `invoice.marked_paid`, en transaction (ADR-009 D4 idempotent).
 */

const STATUS_CODE_PAID = "fr:212";
// 205 Approuvée, stockée en code unifié `accepted_business` (map-status-code).
const REQUIRED_STATUS = "accepted_business";
// Z3 — Full + Responsable (cohérent autres CTA cycle de vie Émission sprint-04).
const ALLOWED_ROLES: readonly UserRole[] = ["full", "deposit_states"];

export function registerInvoicesMarkPaidRoute(app: FastifyInstance): void {
  app.post<{ Params: { id: string } }>("/api/invoices/:id/mark-paid", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: "Authentification requise." });
    }

    // RBAC : le contexte auth ne porte pas le rôle, on le recharge (ADR-006).
    const roleRow = await findActiveUserRoleById(app.sql, ctx.user_id);
    if (roleRow === undefined || !ALLOWED_ROLES.includes(roleRow.role)) {
      return reply
        .code(403)
        .send({ message: "Permission insuffisante pour marquer une facture encaissée." });
    }

    const invoice = await findInvoiceByIdAndCustomer(app.sqlRead, {
      id: req.params.id,
      customerId: ctx.customer_id,
    });
    if (invoice === undefined) {
      return reply.code(404).send({ message: "Facture introuvable." });
    }

    // Seul le statut 205 Approuvée autorise la pose 212 (PRD §5.11 + Z4).
    if (invoice.status_current !== REQUIRED_STATUS) {
      return reply.code(409).send({
        message: "Cette facture ne peut pas être marquée encaissée dans son statut actuel.",
      });
    }
    if (invoice.pa_invoice_id === null) {
      return reply.code(409).send({
        message: "Cette facture n'a pas encore été transmise à votre Plateforme Agréée.",
      });
    }

    // Charge la connexion PA + bundle tokens (cohérent invoices/create.ts).
    const paConn = await findActivePaConnectionForDisconnectByCustomerId(
      app.sqlRead,
      ctx.customer_id,
    );
    if (paConn === undefined) {
      return reply.code(503).send({
        message:
          "Votre Plateforme Agréée n'est pas connectée. Connectez-vous depuis Paramètres > Connexion à ma Plateforme Agréée.",
      });
    }
    const bundle = await app.secrets.get(paConn.secret_ref);
    if (bundle === null) {
      return reply.code(401).send({
        message:
          "Votre connexion à la Plateforme Agréée a expiré. Reconnectez-vous depuis Paramètres > Connexion à ma Plateforme Agréée.",
      });
    }

    // `vat_on_encashment` pour l'audit (déclenche la remontée TVA fiscale).
    const customer = await findActiveCustomerById(app.sqlRead, ctx.customer_id);
    const vatOnEncashment = customer?.vat_on_encashment ?? false;

    // Pose à la PA d'abord (source de vérité). Échec → pas d'écriture BDD.
    let event;
    try {
      event = await app.paDriver.createInvoiceEvent(
        { paInvoiceId: invoice.pa_invoice_id, statusCode: STATUS_CODE_PAID },
        {
          customerId: ctx.customer_id,
          credentials: {
            kind: "superpdp-oauth-ac",
            accessToken: bundle.accessToken,
            refreshToken: bundle.refreshToken,
            accessExpiresAt: new Date(bundle.accessExpiresAt),
            paUserId: null,
          },
        },
      );
    } catch (e) {
      return handleDriverError(app, reply, e, {
        userId: ctx.user_id,
        customerId: ctx.customer_id,
        invoiceId: invoice.id,
      });
    }

    // Persistance atomique : event timeline + status courant + audit.
    await withTransaction(app.sql, async (tx) => {
      await insertCdarEvent(tx, {
        invoice_id: invoice.id,
        code: event.rawStatusCode,
        label: "Encaissée",
        occurred_at: event.occurredAt,
        source: "app",
      });
      await updateInvoiceStatusCurrent(tx, { id: invoice.id, statusCurrent: event.status });
      await writeAuthAudit(tx, {
        event_type: "invoice.marked_paid",
        success: true,
        user_id: ctx.user_id,
        customer_id: ctx.customer_id,
        ip: req.ip,
        user_agent: req.headers["user-agent"] ?? null,
        metadata: {
          invoice_id: invoice.id,
          vat_on_encashment_flag: vatOnEncashment,
          marked_by: ctx.user_id,
          occurred_at: event.occurredAt,
        },
      });
    });

    // Re-fetch post-commit : statut basculé `paid` + event sérialisé.
    const updated = await findInvoiceByIdAndCustomer(app.sqlRead, {
      id: invoice.id,
      customerId: ctx.customer_id,
    });
    const events = await findCdarEventsByInvoiceId(app.sqlRead, invoice.id);
    const posted = [...events].reverse().find((e) => e.code === event.rawStatusCode);
    return reply.code(200).send({
      invoice: toInvoiceResponse(updated ?? invoice),
      cdarEvent: posted !== undefined ? toCdarEventResponse(posted) : null,
    });
  });
}

interface DriverErrorMeta {
  userId: string;
  customerId: string;
  invoiceId: string;
}

/** Mappe une exception driver → HTTP (NC-15) + audit `invoice.marked_paid_failed`
 *  (cohérent reception cdar.ts + ADR-009 D5). PA refuse → 422. */
function handleDriverError(
  app: FastifyInstance,
  reply: FastifyReply,
  e: unknown,
  meta: DriverErrorMeta,
): FastifyReply {
  let httpCode = 502;
  let userMessage =
    "Votre Plateforme Agréée est momentanément indisponible. Réessayez dans quelques minutes.";

  if (e instanceof PaAccessTokenExpiredException) {
    httpCode = 401;
    userMessage = "Votre connexion à la Plateforme Agréée a expiré. Reconnectez-vous.";
  } else if (e instanceof InvoiceRejectedXsdException) {
    httpCode = 422;
    userMessage = "La Plateforme Agréée a rejeté la pose du statut Encaissée.";
  } else if (e instanceof PaForbiddenException) {
    httpCode = 403;
    userMessage = "La Plateforme Agréée refuse cette opération.";
  } else if (e instanceof PaRateLimitException) {
    httpCode = 429;
    userMessage = "Trop de requêtes vers la Plateforme Agréée. Réessayez dans quelques instants.";
  } else if (e instanceof PaUnavailableException || e instanceof PaSubmissionFailedException) {
    httpCode = 502;
  }

  const detail =
    typeof e === "object" &&
    e !== null &&
    "detail" in e &&
    typeof (e as { detail?: unknown }).detail === "string"
      ? (e as { detail: string }).detail
      : null;

  void writeAuthAudit(app.sql, {
    event_type: "invoice.marked_paid_failed",
    success: false,
    user_id: meta.userId,
    customer_id: meta.customerId,
    metadata: {
      invoice_id: meta.invoiceId,
      error: e instanceof Error ? e.message : String(e),
    },
  });

  return reply.code(httpCode).send({
    message: userMessage,
    ...(detail !== null && detail.length > 0 ? { detail } : {}),
  });
}
