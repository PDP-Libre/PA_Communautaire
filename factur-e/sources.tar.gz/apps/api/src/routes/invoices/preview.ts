import type { FastifyInstance } from "fastify";

import { type InvoicePreviewResponse, InvoiceFormSchema } from "@factur-e/shared-schemas";
import {
  generateCII,
  renderInvoicePdfFromModel,
  validateExtendedXsd,
} from "@factur-e/factur-x-builder";
import { FX_CONFORMANCE_LEVELS } from "@factur-e/factur-x-model";

import { resolveAuthContext } from "../../auth/context.js";
import { findActiveCustomerById } from "../../db/repos/customers.js";
import { formToModel } from "../../services/invoice-form-to-model.js";
import { buildPdfEnrichment, footerLineFor } from "../../services/pdf-enrichment.js";

/**
 * `POST /api/invoices/preview` — pipeline complet **sans persist** :
 * `formToModel → generateCII → validateExtendedXsd → assembleFacturXPdfA3`.
 *
 * Consommé par la page Aperçu PDF avant envoi (§6.9 brief). Retourne le
 * PDF Factur-X bytes encodés base64 + (mode avancé) XML preview +
 * warnings non bloquants.
 *
 * Erreurs typées :
 *   - 400 Zod (form invalide)
 *   - 422 mapping formToModel échoue (lignes vides, IBAN manquant, etc.)
 *   - 422 XSD échoue (XML CII invalide vs Factur-X EXTENDED XSD)
 *   - 500 assemble PDF/A-3 fail (bug interne, rarissime ADR-004 sprint-01)
 */
export function registerInvoicesPreviewRoute(app: FastifyInstance): void {
  app.post("/api/invoices/preview", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: "Authentification requise." });
    }

    const parsed = InvoiceFormSchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({
        message: "Formulaire invalide.",
        issues: parsed.error.issues,
      });
    }
    const form = parsed.data;

    const seller = await findActiveCustomerById(app.sqlRead, ctx.customer_id);
    if (seller === undefined) {
      return reply.code(404).send({ message: "Entreprise introuvable." });
    }

    // Mapping form → modèle EN 16931.
    const mapping = formToModel(form, seller);
    if (!mapping.ok) {
      return reply.code(422).send({
        message: "Le formulaire contient des incohérences.",
        errors: mapping.errors,
      });
    }
    const invoice = mapping.value;

    // Sérialisation XML CII.
    const xml = generateCII(invoice);

    // Validation XSD silencieuse — preview = on retourne les warnings
    // sans bloquer (l'utilisateur a un panneau "À vérifier" + on bloque
    // côté POST /api/invoices final).
    const xsdResult = await validateExtendedXsd(xml);
    const warnings: { code: string; message: string; field: string | null }[] = [];
    if (!xsdResult.ok) {
      for (const e of xsdResult.errors) {
        warnings.push({
          code: "xsd_error",
          message: e.message,
          field: e.code !== undefined ? String(e.code) : null,
        });
      }
    }

    // Assemblage PDF/A-3 Factur-X via moteur de template (ADR-004 préservé).
    const enrichment = await buildPdfEnrichment(seller, app.storage, app.log);
    const pdfBytes = await renderInvoicePdfFromModel({
      invoice,
      xmlBytes: Buffer.from(xml, "utf8"),
      conformanceLevel: FX_CONFORMANCE_LEVELS.EXTENDED,
      enrichment,
      footerLine: footerLineFor(seller),
    });

    const response: InvoicePreviewResponse = {
      pdfBytes: Buffer.from(pdfBytes).toString("base64"),
      xmlPreview: form.ui_mode === "advanced" ? xml : null,
      warnings,
    };
    return reply.code(200).send(response);
  });
}
