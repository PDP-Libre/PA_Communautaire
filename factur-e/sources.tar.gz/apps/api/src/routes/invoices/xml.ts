import type { FastifyInstance } from "fastify";

import { generateCII } from "@factur-e/factur-x-builder";

import { resolveAuthContext } from "../../auth/context.js";
import { findActiveCustomerById } from "../../db/repos/customers.js";
import { findLinesByInvoiceId } from "../../db/repos/invoice_lines.js";
import { findInvoiceByIdAndCustomer } from "../../db/repos/invoices.js";

import { reconstructFormFromPersisted, reconstructInvoiceModel } from "./_reconstruct.js";

/**
 * `GET /api/invoices/:id/xml` — XML CII brut Factur-X EXTENDED.
 * Re-généré à la volée (cohérent avec /pdf).
 *
 * Le bouton "Voir l'XML" est visible côté UI en **mode avancé
 * uniquement** (§6.9 brief, §6.11 fiche). L'endpoint reste accessible
 * pour tout user ayant accès à l'invoice — le contrôle de mode UI est
 * côté front (pas de leak fonctionnel).
 */
export function registerInvoicesXmlRoute(app: FastifyInstance): void {
  app.get<{ Params: { id: string } }>("/api/invoices/:id/xml", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: "Authentification requise." });
    }
    const invoice = await findInvoiceByIdAndCustomer(app.sqlRead, {
      id: req.params.id,
      customerId: ctx.customer_id,
    });
    if (invoice === undefined) {
      return reply.code(404).send({ message: "Facture introuvable." });
    }
    const [lines, seller] = await Promise.all([
      findLinesByInvoiceId(app.sqlRead, invoice.id),
      findActiveCustomerById(app.sqlRead, ctx.customer_id),
    ]);
    if (seller === undefined) {
      return reply.code(404).send({ message: "Entreprise introuvable." });
    }
    const form = reconstructFormFromPersisted(invoice, lines);
    const mapping = reconstructInvoiceModel(form, seller);
    if (!mapping.ok) {
      return reply.code(500).send({
        message: "Impossible de reconstruire la facture.",
        errors: mapping.errors,
      });
    }
    const xml = generateCII(mapping.value);
    reply
      .header("Content-Type", "application/xml; charset=utf-8")
      .header(
        "Content-Disposition",
        `attachment; filename="${invoice.number.replace(/[^\w\-/.]+/g, "_")}.xml"`,
      )
      .send(xml);
  });
}
