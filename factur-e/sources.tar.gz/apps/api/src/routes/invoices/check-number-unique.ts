import type { FastifyInstance } from "fastify";

import {
  type CheckNumberUniqueResponse,
  CheckNumberUniqueRequestSchema,
} from "@factur-e/shared-schemas";

import { resolveAuthContext } from "../../auth/context.js";
import {
  findInvoiceIdByCustomerAndNumber,
  findLatestInvoiceNumberByCustomer,
} from "../../db/repos/invoices.js";

import { suggestNextInvoiceNumber } from "./_shared.js";

/**
 * `POST /api/invoices/check-number-unique` — vérifie l'unicité d'un
 * numéro facture (US-EMIT-002 critère 2) ET retourne une suggestion
 * auto-incrémentée pour le prochain numéro disponible (Q6 acté Bruno :
 * algo backend, regex `^(.+?)(\d+)$` → +1 zfill conservé).
 *
 * Consommé côté UI Section Document avec débounce 400ms (§6.4 brief).
 *
 * POST plutôt que GET pour passer le numéro en body (caractères
 * spéciaux `_`, `/`, `-` autorisés mais nécessitent encoding URL fragile).
 */
export function registerInvoicesCheckNumberUniqueRoute(app: FastifyInstance): void {
  app.post("/api/invoices/check-number-unique", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: "Authentification requise." });
    }
    const parsed = CheckNumberUniqueRequestSchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({
        message: "Numéro invalide.",
        issues: parsed.error.issues,
      });
    }

    const [existingId, latest] = await Promise.all([
      findInvoiceIdByCustomerAndNumber(app.sqlRead, {
        customerId: ctx.customer_id,
        number: parsed.data.number,
      }),
      findLatestInvoiceNumberByCustomer(app.sqlRead, ctx.customer_id),
    ]);

    const response: CheckNumberUniqueResponse = {
      available: existingId === undefined,
      suggestion: suggestNextInvoiceNumber(latest),
      existingInvoiceId: existingId ?? null,
    };
    return reply.code(200).send(response);
  });
}
