import type { CrossIndustryInvoice, Result } from "@factur-e/factur-x-model";
import type {
  InvoiceForm,
  InvoiceFormAdvanced,
  InvoiceFormBase,
  LineItemAdvanced,
  LineItemBase,
} from "@factur-e/shared-schemas";

import type { CustomerRow } from "../../db/repos/customers.js";
import type { InvoiceLineRow } from "../../db/repos/invoice_lines.js";
import type { InvoiceRow } from "../../db/repos/invoices.js";
import { type FormToModelError, formToModel } from "../../services/invoice-form-to-model.js";

/**
 * Reconstruit un `InvoiceForm` à partir des rows BDD persistées — utilisé
 * par `GET /api/invoices/:id/{pdf,xml}` et l'export ZIP émission pour
 * re-générer le document à la volée (brouillon/preview ; et fallback du
 * service de copie immuable F8 quand l'objet 180 j a été purgé).
 *
 * **Reconstruction fidèle (T-CL-RECONSTRUCT-FIDELE-F8)** : la forme du form
 * reconstruit suit le `ui_mode` réellement émis, persisté dans
 * `payload_extended.ui_mode` :
 *  - `advanced` → form avancé complet (le schéma base ne peut PAS porter
 *    `documentLevelAllowance` BG-20, frais de port BG-21, `incoterm`,
 *    `prepaidAmount` BT-113, `generalComments`/`footerMentions`,
 *    `parties.shipping` BG-13…) → fidélité totale.
 *  - `base` → form base enrichi de `notes` (BT-22, F3) + BG-3 (BT-25/26),
 *    tous deux portés par le schéma base.
 *
 * Fallback legacy fail-safe (ADR-009) : une row persistée AVANT ce fix n'a
 * pas `ui_mode` → reconstruction `base` (comportement historique, pas de
 * crash, pas de migration de données). Un document avancé legacy y perd ses
 * champs avancés exactement comme avant — sans 500.
 *
 * Note : les commentaires privés (`payload_extended.privateComments`) ne sont
 * JAMAIS re-injectés (invariant — pas dans le XML CII ni le PDF). Aucun
 * IBAN/BIC ici : ré-sourcé depuis `seller` (ADR-008).
 */
export function reconstructFormFromPersisted(
  invoice: InvoiceRow,
  lines: InvoiceLineRow[],
): InvoiceForm {
  const payload = invoice.payload_extended;
  if (payload.ui_mode === "advanced") {
    return reconstructAdvancedForm(invoice, lines, payload);
  }
  return reconstructBaseForm(invoice, lines, payload);
}

/** Snapshot acheteur (BG-7) persisté `payload_extended.buyer` (tous modes
 *  depuis recette FORM 2026-05-19) — fallback "Inconnu" pour les rows très
 *  anciennes sans snapshot (jamais en pratique post sprint-05). */
function reconstructBuyer(payload: Record<string, unknown>): InvoiceFormBase["parties"]["buyer"] {
  const snapshot = (payload.buyer ?? payload.parties ?? null) as Record<string, unknown> | null;
  return (snapshot ?? {
    siren: "000000000",
    legalName: "Inconnu",
    address: { postcode: "00000", city: "Inconnu", countryCode: "FR" },
    electronicAddress: "0225:000000000",
    electronicAddressScheme: "0225",
  }) as InvoiceFormBase["parties"]["buyer"];
}

/** Métadonnées BG-3 (BR-55) — `preceding_invoice_id` est en colonne ; le
 *  numéro (BT-25) / la date (BT-26) d'origine sont persistés dans
 *  `payload_extended` (ZG-4) pour réinjection sans lookup de l'origine. */
function reconstructPreceding(
  invoice: InvoiceRow,
  payload: Record<string, unknown>,
): Pick<InvoiceFormBase, "precedingInvoiceId" | "precedingInvoiceNumber" | "precedingIssueDate"> {
  return {
    precedingInvoiceId: invoice.preceding_invoice_id ?? undefined,
    precedingInvoiceNumber:
      (payload.precedingInvoiceNumber as string | null | undefined) ?? undefined,
    precedingIssueDate: (payload.precedingIssueDate as string | null | undefined) ?? undefined,
  };
}

function reconstructBaseForm(
  invoice: InvoiceRow,
  lines: InvoiceLineRow[],
  payload: Record<string, unknown>,
): InvoiceFormBase {
  return {
    ui_mode: "base",
    document: {
      number: invoice.number,
      issueDate: invoice.issue_date.toISOString().slice(0, 10),
      // BT-3 — réinjecté depuis `type_code` pour conserver avoir (381) /
      // rectificative (384) au lieu du défaut 380 (template/titre PDF).
      typeCode: invoice.type_code as InvoiceFormBase["document"]["typeCode"],
      // BT-22 zone publique (F3) — persistée + réinjectée (était `null` codé
      // en dur → la note disparaissait du PDF/XML régénéré).
      notes: (payload.notes as string | null | undefined) ?? null,
    },
    parties: { buyer: reconstructBuyer(payload) },
    lines: lines.map(reconstructBaseLine),
    payment: reconstructCorePayment(payload.payment),
    ...reconstructPreceding(invoice, payload),
  };
}

function reconstructAdvancedForm(
  invoice: InvoiceRow,
  lines: InvoiceLineRow[],
  payload: Record<string, unknown>,
): InvoiceFormAdvanced {
  const str = (k: string): string | null => (payload[k] as string | null | undefined) ?? null;
  return {
    ui_mode: "advanced",
    document: {
      number: invoice.number,
      issueDate: invoice.issue_date.toISOString().slice(0, 10),
      typeCode: invoice.type_code as InvoiceFormAdvanced["document"]["typeCode"],
      // Devise (BT-5) + règle de traitement : depuis les colonnes (source de
      // vérité), pas le payload.
      currency: invoice.currency,
      processingRule: invoice.processing_rule,
      buyerOrderRef: str("buyerOrderRef"),
      sellerOrderRef: str("sellerOrderRef"),
      contractRef: str("contractRef"),
      projectRef: str("projectRef"),
      billingPeriod:
        (payload.billingPeriod as InvoiceFormAdvanced["document"]["billingPeriod"]) ?? null,
      notes: str("notes"),
      privateComments: str("privateComments"),
      footerMentions: str("footerMentions"),
      generalComments: str("generalComments"),
    },
    parties: {
      buyer: reconstructBuyer(payload),
      shipping: (payload.shipping as InvoiceFormAdvanced["parties"]["shipping"]) ?? null,
      deliveryDate: str("deliveryDate"),
      clientTaxRegime:
        (payload.clientTaxRegime as
          | InvoiceFormAdvanced["parties"]["clientTaxRegime"]
          | undefined) ?? "default",
      transporter: str("transporter"),
      trackingNumber: str("trackingNumber"),
    },
    lines: lines.map(reconstructAdvancedLine),
    documentLevelAllowance:
      (payload.documentLevelAllowance as InvoiceFormAdvanced["documentLevelAllowance"]) ?? null,
    shippingCostHt: str("shippingCostHt"),
    shippingCostVatCategory:
      (payload.shippingCostVatCategory as InvoiceFormAdvanced["shippingCostVatCategory"]) ?? null,
    shippingCostVatRate: str("shippingCostVatRate"),
    incoterm: (payload.incoterm as InvoiceFormAdvanced["incoterm"]) ?? null,
    payment: reconstructAdvancedPayment(payload),
    ...reconstructPreceding(invoice, payload),
  };
}

function reconstructBaseLine(l: InvoiceLineRow): LineItemBase {
  return {
    label: l.label,
    description: l.description,
    quantity: l.quantity,
    unitCode: l.unit_code,
    unitPriceHt: l.unit_price_ht,
    vatCategory: l.vat_category,
    vatRate: l.vat_rate,
    totalHt: l.total_ht,
  };
}

/** Ligne avancée : base + champs EXTENDED persistés sans perte (colonnes
 *  période + `invoice_lines.payload_extended` : vatex/longDescription/note/
 *  basisQuantity). `allowance` ligne (BG-27/28) N'est PAS reconstruite : seul
 *  le montant est colonné (`allowance_amount`/`charge_amount`), pas l'objet
 *  complet (reason/reasonCode/vatCategory) — réinjecter un objet partiel
 *  casserait la validation BR-42/43. Limite V1 assumée (le total ligne
 *  `totalHt` reste fidèle ; cf. test.md). */
function reconstructAdvancedLine(l: InvoiceLineRow): LineItemAdvanced {
  const ext = l.payload_extended;
  const line: LineItemAdvanced = {
    label: l.label,
    description: l.description,
    quantity: l.quantity,
    unitCode: l.unit_code,
    unitPriceHt: l.unit_price_ht,
    vatCategory: l.vat_category,
    vatRate: l.vat_rate,
    totalHt: l.total_ht,
    vatex: (ext.vatex as LineItemAdvanced["vatex"]) ?? null,
    longDescription: (ext.longDescription as string | null | undefined) ?? null,
    note: (ext.note as string | null | undefined) ?? null,
    basisQuantity: (ext.basisQuantity as string | null | undefined) ?? null,
    allowance: null,
  };
  const period = reconstructLinePeriod(l);
  line.period = period;
  return line;
}

function reconstructLinePeriod(l: InvoiceLineRow): LineItemAdvanced["period"] {
  if (l.period_start === null && l.period_end === null) return null;
  return {
    startDate: l.period_start === null ? null : l.period_start.toISOString().slice(0, 10),
    endDate: l.period_end === null ? null : l.period_end.toISOString().slice(0, 10),
  };
}

/** Défaut legacy fail-safe (ADR-009) — rows persistées AVANT finding G
 *  sprint-07 sans `payload_extended.payment`. */
const LEGACY_PAYMENT_FALLBACK: InvoiceFormBase["payment"] = {
  paymentTerms: { kind: "days", days: 30 },
  paymentMethodKind: "transfer",
  mentionsLegales: null,
};

/**
 * Réinjecte le bloc paiement cœur persisté (`payload_extended.payment`) — 3
 * champs portés par le schéma base (`paymentTerms` / `paymentMethodKind` /
 * `mentionsLegales`). Fallback legacy fail-safe si absent/malformé (row pré
 * finding G). La variante de l'union discriminée `paymentTerms` est préservée
 * telle quelle.
 */
function reconstructCorePayment(persisted: unknown): InvoiceFormBase["payment"] {
  if (persisted === null || typeof persisted !== "object") {
    return LEGACY_PAYMENT_FALLBACK;
  }
  const p = persisted as Record<string, unknown>;
  const paymentTerms = p.paymentTerms as InvoiceFormBase["payment"]["paymentTerms"] | undefined;
  const paymentMethodKind = p.paymentMethodKind as
    | InvoiceFormBase["payment"]["paymentMethodKind"]
    | undefined;
  if (paymentTerms === undefined || paymentMethodKind === undefined) {
    return LEGACY_PAYMENT_FALLBACK;
  }
  return {
    paymentTerms,
    paymentMethodKind,
    mentionsLegales: (p.mentionsLegales as string | null | undefined) ?? null,
  };
}

/** Paiement mode avancé : cœur (réutilise `reconstructCorePayment`) + extras
 *  persistés à plat dans `payload_extended` (BT-81 `paymentMeansCode`, BT-90
 *  `creditorReference`, BT-113 `prepaidAmount`, `customPenalties`). */
function reconstructAdvancedPayment(
  payload: Record<string, unknown>,
): InvoiceFormAdvanced["payment"] {
  const core = reconstructCorePayment(payload.payment);
  return {
    paymentTerms: core.paymentTerms,
    paymentMethodKind: core.paymentMethodKind,
    mentionsLegales: core.mentionsLegales ?? null,
    paymentMeansCode:
      (payload.paymentMeansCode as InvoiceFormAdvanced["payment"]["paymentMeansCode"]) ?? null,
    creditorReference: (payload.creditorReference as string | null | undefined) ?? null,
    prepaidAmount: (payload.prepaidAmount as string | null | undefined) ?? null,
    customPenalties: (payload.customPenalties as string | null | undefined) ?? null,
  };
}

export function reconstructInvoiceModel(
  form: InvoiceForm,
  seller: CustomerRow,
): Result<CrossIndustryInvoice, FormToModelError> {
  return formToModel(form, seller);
}
