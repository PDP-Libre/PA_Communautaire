import type { CrossIndustryInvoice, Result } from "@factur-e/factur-x-model";
import type { InvoiceForm, InvoiceFormBase, LineItemBase } from "@factur-e/shared-schemas";

import type { CustomerRow } from "../../db/repos/customers.js";
import type { InvoiceLineRow } from "../../db/repos/invoice_lines.js";
import type { InvoiceRow } from "../../db/repos/invoices.js";
import { type FormToModelError, formToModel } from "../../services/invoice-form-to-model.js";

/**
 * Reconstruit un `InvoiceForm` (forme minimale base) à partir des rows
 * BDD persistées — utilisé par `GET /api/invoices/:id/pdf` et
 * `/xml` pour re-générer le document à la volée (Q3 acté Bruno, pas de
 * cache S3 MVP).
 *
 * Stratégie pragmatique : on reconstruit en mode `base` toujours
 * (suffisant pour la re-génération XML CII et PDF — tous les champs
 * avancé non-modélisés en colonnes sont dans `payload_extended` et
 * peuvent être réinjectés via un `formToModel` étendu si nécessaire en
 * V1). MVP : mode base couvre 95% des factures TPE.
 *
 * Note : les commentaires privés (`payload_extended.privateComments`)
 * ne sont JAMAIS re-injectés dans le XML CII (cf. invariants §4 #8).
 */
export function reconstructFormFromPersisted(
  invoice: InvoiceRow,
  lines: InvoiceLineRow[],
): InvoiceForm {
  const buyerSnapshot = (invoice.payload_extended.buyer ??
    invoice.payload_extended.parties ??
    null) as Record<string, unknown> | null;

  const payment = reconstructPayment(invoice.payload_extended.payment);

  const formBase: InvoiceFormBase = {
    ui_mode: "base",
    document: {
      number: invoice.number,
      issueDate: invoice.issue_date.toISOString().slice(0, 10),
      // BT-3 — réinjecté depuis la colonne `type_code` pour que la
      // régénération PDF/XML d'un avoir (381) / rectificative (384) conserve
      // son type. Sans ça, `formToModel` applique le défaut 380 → le moteur
      // de template choisit `invoice-default.njk` et titre "Facture …" au
      // lieu de "Avoir …" / "Facture rectificative …" (régression révélée par
      // le moteur de template PDF W1 — finding titre avoir T-BR sprint-07).
      typeCode: invoice.type_code as InvoiceFormBase["document"]["typeCode"],
      notes: null,
    },
    parties: {
      buyer: (buyerSnapshot ?? {
        siren: "000000000",
        legalName: "Inconnu",
        address: {
          postcode: "00000",
          city: "Inconnu",
          countryCode: "FR",
        },
        electronicAddress: "0225:000000000",
        electronicAddressScheme: "0225",
      }) as InvoiceFormBase["parties"]["buyer"],
    },
    lines: lines.map(
      (l): LineItemBase => ({
        label: l.label,
        description: l.description,
        quantity: l.quantity,
        unitCode: l.unit_code,
        unitPriceHt: l.unit_price_ht,
        vatCategory: l.vat_category,
        vatRate: l.vat_rate,
        totalHt: l.total_ht,
      }),
    ),
    payment,
  };
  return formBase;
}

/** Défaut legacy fail-safe (ADR-009) — factures persistées AVANT finding G
 *  sprint-07 n'ont pas `payload_extended.payment`. On retombe sur le moyen
 *  / les termes historiquement hardcodés plutôt que de crasher la
 *  reconstruction `/pdf` `/xml` `export-zip`. */
const LEGACY_PAYMENT_FALLBACK: InvoiceFormBase["payment"] = {
  paymentTerms: { kind: "days", days: 30 },
  paymentMethodKind: "transfer",
  mentionsLegales: null,
};

/**
 * Réinjecte le bloc paiement persisté (`extractPayloadExtended` →
 * `payload_extended.payment`) dans le form reconstruit. Limité aux 3 champs
 * cœur portés par le schéma `base` (`paymentTerms` / `paymentMethodKind` /
 * `mentionsLegales`). Fallback legacy fail-safe si absent ou malformé (row
 * pré finding G). La variante de l'union discriminée `paymentTerms`
 * (`onSight` / `days` / `endOfMonth` / `fixedDate`) est préservée telle
 * quelle — pas de coercition vers `days`.
 *
 * Note : les extras avancés persistés à plat (`prepaidAmount` BT-113,
 * `paymentMeansCode` BT-81, `creditorReference`, `customPenalties`) NE sont
 * PAS réinjectés — la reconstruction reste `ui_mode:"base"`. Cf. backlog
 * sprint-08 « reconstruction fidèle mode avancé » (totaux BT-115 / BG-20
 * / charges ligne).
 */
function reconstructPayment(persisted: unknown): InvoiceFormBase["payment"] {
  if (persisted === null || typeof persisted !== "object") {
    return LEGACY_PAYMENT_FALLBACK;
  }
  const p = persisted as Record<string, unknown>;
  const paymentTerms = p.paymentTerms as InvoiceFormBase["payment"]["paymentTerms"] | undefined;
  const paymentMethodKind = p.paymentMethodKind as
    | InvoiceFormBase["payment"]["paymentMethodKind"]
    | undefined;
  if (paymentTerms === undefined || paymentMethodKind === undefined) {
    return LEGACY_PAYMENT_FALLBACK;
  }
  return {
    paymentTerms,
    paymentMethodKind,
    mentionsLegales: (p.mentionsLegales as string | null | undefined) ?? null,
  };
}

export function reconstructInvoiceModel(
  form: InvoiceForm,
  seller: CustomerRow,
): Result<CrossIndustryInvoice, FormToModelError> {
  return formToModel(form, seller);
}
