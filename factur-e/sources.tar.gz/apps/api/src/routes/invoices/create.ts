import { createHash, randomUUID } from "node:crypto";

import type { FastifyInstance } from "fastify";

import {
  type InvoiceCreateResponse,
  InvoiceFormSchema,
  type PrecedingCancellation,
} from "@factur-e/shared-schemas";
import {
  generateCII,
  renderInvoicePdfFromModel,
  validateExtendedXsd,
} from "@factur-e/factur-x-builder";
import { FX_CONFORMANCE_LEVELS } from "@factur-e/factur-x-model";
import {
  InvoiceRejectedXsdException,
  PaAccessTokenExpiredException,
  PaForbiddenException,
  PaRateLimitException,
  PaSubmissionFailedException,
  PaUnavailableException,
} from "@factur-e/pa-adapter";

import { writeAuthAudit } from "../../auth/audit.js";
import { resolveAuthContext } from "../../auth/context.js";
import { insertCdarEvent } from "../../db/repos/cdar_events.js";
import { findActiveCustomerById } from "../../db/repos/customers.js";
import { type CreateInvoiceLineArgs, insertInvoiceLines } from "../../db/repos/invoice_lines.js";
import {
  findInvoiceByIdAndCustomer,
  findInvoiceIdByCustomerAndNumber,
  insertInvoice,
  updateInvoicePaSubmission,
  updateInvoiceStatusCurrent,
} from "../../db/repos/invoices.js";
import { findActivePaConnectionForDisconnectByCustomerId } from "../../db/repos/pa_connections.js";
import { withTransaction } from "../../db/tx.js";
import { extractPayloadExtended, formToModel } from "../../services/invoice-form-to-model.js";
import { buildPdfEnrichment, footerLineFor } from "../../services/pdf-enrichment.js";

import { toCdarEventResponse, toInvoiceLineResponse, toInvoiceResponse } from "./_shared.js";

/**
 * `POST /api/invoices` — pipeline complet **transactionnel** d'émission.
 *
 * Flux :
 *   1. Auth + Zod safeParse + formToModel.
 *   2. generateCII → validateExtendedXsd (bloquant si erreur XSD).
 *   3. assembleFacturXPdfA3 → SHA256 + tracking_id UUIDv4 Factur-E.
 *   4. Récupère `pa_connection` + bundle tokens (accessToken) du
 *      customer via `findActivePaConnectionForDisconnectByCustomerId`
 *      + `app.secrets.get(secret_ref)`. 503 si non connectée ; 401 si
 *      bundle absent (à reconnecter).
 *   5. `withTransaction` :
 *      - insertInvoice → insertInvoiceLines
 *      - `app.paDriver.submitInvoice({...})` (T-CL-PA-EXT)
 *      - updateInvoicePaSubmission
 *      - insertCdarEvent initial `Déposée` source='synthetic' (ADR-009 D4
 *        idempotence garantie + premier event timeline T-CW-11 cycle vie
 *        3 surfaces).
 *      - audit `pa_invoice_submitted`.
 *
 * Erreurs ADR-009 D1 — fail-safe degradation :
 *   - 4xx PA (XSD rejeté, doublon flowId, etc.) → ROLLBACK + 422 +
 *     audit `pa_submission_failed_4xx`.
 *   - 5xx PA retry plafonné dépassé / unavailable → ROLLBACK + 503 +
 *     audit `pa_submission_failed_max_retries`. Le brouillon UI reste
 *     sauvegardé côté front (auto-save 5s) — pas de statut intermédiaire
 *     `pending_pa_response` côté invoices pour MVP.
 *   - 429 PA rate limit → ROLLBACK + 429 + audit `pa_rate_limited`.
 *   - Token PA expiré → ROLLBACK + 401 + audit
 *     `pa_token_expired_during_submission` (UI: "Reconnectez-vous à
 *     votre Plateforme Agréée").
 */
export function registerInvoicesCreateRoute(app: FastifyInstance): void {
  app.post("/api/invoices", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: "Authentification requise." });
    }

    const parsed = InvoiceFormSchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({
        message: "Formulaire invalide.",
        issues: parsed.error.issues,
      });
    }
    const form = parsed.data;

    const seller = await findActiveCustomerById(app.sqlRead, ctx.customer_id);
    if (seller === undefined) {
      return reply.code(404).send({ message: "Entreprise introuvable." });
    }

    // Détection unicité numéro AVANT pipeline (filtre rapide — la
    // contrainte UNIQUE BDD est la défense ultime).
    const collision = await findInvoiceIdByCustomerAndNumber(app.sqlRead, {
      customerId: ctx.customer_id,
      number: form.document.number,
    });
    if (collision !== undefined) {
      return reply.code(409).send({
        message: "Ce numéro a déjà été utilisé.",
        existingInvoiceId: collision,
      });
    }

    // ── 1. Mapping form → modèle EN 16931 ────────────────────────────
    const mapping = formToModel(form, seller);
    if (!mapping.ok) {
      return reply.code(422).send({
        message: "Le formulaire contient des incohérences.",
        errors: mapping.errors,
      });
    }
    const invoiceModel = mapping.value;

    // ── 2. Sérialisation XML CII + validation XSD bloquante ──────────
    const xml = generateCII(invoiceModel);
    const xsdResult = await validateExtendedXsd(xml);
    if (!xsdResult.ok) {
      return reply.code(422).send({
        message: "La facture comporte des erreurs techniques.",
        errors: xsdResult.errors,
      });
    }

    // ── 3. Assemblage PDF/A-3 (moteur de template) + SHA256 + tracking_id ─
    const enrichment = await buildPdfEnrichment(seller, app.storage, app.log);
    const pdfBytes = await renderInvoicePdfFromModel({
      invoice: invoiceModel,
      xmlBytes: Buffer.from(xml, "utf8"),
      conformanceLevel: FX_CONFORMANCE_LEVELS.EXTENDED,
      enrichment,
      footerLine: footerLineFor(seller),
    });
    const sha256 = createHash("sha256").update(pdfBytes).digest("hex");
    const trackingId = randomUUID();

    // ── 4. Récupère pa_connection + bundle tokens ───────────────────
    const paConn = await findActivePaConnectionForDisconnectByCustomerId(
      app.sqlRead,
      ctx.customer_id,
    );
    if (paConn === undefined) {
      return reply.code(503).send({
        message:
          "Votre Plateforme Agréée n'est pas connectée. Connectez-vous depuis Paramètres > Connexion à ma Plateforme Agréée.",
      });
    }
    const bundle = await app.secrets.get(paConn.secret_ref);
    if (bundle === null) {
      return reply.code(401).send({
        message:
          "Votre connexion à la Plateforme Agréée a expiré. Reconnectez-vous depuis Paramètres > Connexion à ma Plateforme Agréée.",
      });
    }
    // Construction Peppol IDs (cf. SubmitInvoiceInput pa-adapter) :
    //   - recipientPeppolId = scheme:value (ex `0225:987654321_dgfip`)
    //   - senderPeppolId    = customers.directory_address (déjà au
    //     format Peppol depuis l'annuaire SuperPDP sprint-03).
    const recipientPeppolId = `${form.parties.buyer.electronicAddressScheme}:${form.parties.buyer.electronicAddress}`;
    if (seller.directory_address === null || seller.directory_address === "") {
      return reply.code(412).send({
        message:
          "Votre entreprise n'a pas d'adresse électronique Plateforme Agréée. Re-connectez-vous à votre PA.",
      });
    }
    const senderPeppolId = seller.directory_address;
    const processingRule = form.ui_mode === "advanced" ? form.document.processingRule : "B2B";

    // ── 5. Pipeline transactionnel ──────────────────────────────────
    const ms = invoiceModel.tradeTransaction.tradeSettlement.monetarySummation;
    const payloadExtended = extractPayloadExtended(form);

    try {
      const result = await withTransaction(app.sql, async (tx) => {
        const invoiceRow = await insertInvoice(tx, {
          customerId: ctx.customer_id,
          number: form.document.number,
          issueDate: form.document.issueDate,
          trackingId,
          totalHt: ms.taxBasisTotalAmount.toFixed(2),
          totalVat: (ms.vatTotalAmount?.value ?? 0).toFixed(2),
          totalTtc: ms.grandTotalAmount.toFixed(2),
          currency: form.ui_mode === "advanced" ? form.document.currency : "EUR",
          processingRule,
          // BT-3 — type document désormais lu dans les 2 modes (L11 : 381 avoir
          // / 384 rectificative ; base reste 380 par défaut).
          typeCode: form.document.typeCode,
          // BG-3 (BR-55) — lien facture d'origine (avoir/rectificative).
          precedingInvoiceId: form.precedingInvoiceId ?? null,
          payloadExtended,
        });

        const lineArgs: CreateInvoiceLineArgs[] = form.lines.map((line, idx) => {
          const args: CreateInvoiceLineArgs = {
            lineNumber: idx + 1,
            label: line.label,
            description: line.description ?? null,
            quantity: line.quantity,
            unitCode: line.unitCode,
            unitPriceHt: line.unitPriceHt,
            vatRate: line.vatRate,
            vatCategory: line.vatCategory,
            totalHt: line.totalHt,
          };
          if (form.ui_mode === "advanced") {
            const adv = line as (typeof form.lines)[number];
            if ("period" in adv && adv.period !== null && adv.period !== undefined) {
              if (adv.period.startDate !== null && adv.period.startDate !== undefined) {
                args.periodStart = adv.period.startDate;
              }
              if (adv.period.endDate !== null && adv.period.endDate !== undefined) {
                args.periodEnd = adv.period.endDate;
              }
            }
            if ("allowance" in adv && adv.allowance !== null && adv.allowance !== undefined) {
              if (adv.allowance.chargeIndicator) {
                args.chargeAmount = adv.allowance.amount;
              } else {
                args.allowanceAmount = adv.allowance.amount;
              }
            }
            const linePayload: Record<string, unknown> = {};
            if (
              "longDescription" in adv &&
              adv.longDescription !== null &&
              adv.longDescription !== undefined
            ) {
              linePayload.longDescription = adv.longDescription;
            }
            if ("note" in adv && adv.note !== null && adv.note !== undefined) {
              linePayload.note = adv.note;
            }
            if (
              "basisQuantity" in adv &&
              adv.basisQuantity !== null &&
              adv.basisQuantity !== undefined
            ) {
              linePayload.basisQuantity = adv.basisQuantity;
            }
            if ("vatex" in adv && adv.vatex !== null && adv.vatex !== undefined) {
              linePayload.vatex = adv.vatex;
            }
            if (Object.keys(linePayload).length > 0) args.payloadExtended = linePayload;
          }
          return args;
        });
        const lineRows = await insertInvoiceLines(tx, invoiceRow.id, lineArgs);

        // ── PA driver submitInvoice (T-CL-PA-INVOICE-FIX — refactor
        //    ADR-010 v2 D3 : POST /v1.beta/invoices body application/pdf
        //    direct + external_id query = trackingId UUID v7 Factur-E
        //    pour idempotence). Construction CustomerContext +
        //    PaCredentials.superpdp-oauth-ac depuis le bundle SecretStore
        //    (cohérent ADR-012 D3).
        const submission = await app.paDriver.submitInvoice(
          {
            pdfBytes: Buffer.from(pdfBytes),
            trackingId,
            sha256,
            processingRule,
            profile: "EXTENDED",
            invoiceNumber: form.document.number,
            recipientPeppolId,
            senderPeppolId,
            // Default false en prod (Schematron BR-FR appliqué côté PA).
            // Les tests d'intégration peuvent setter true via override
            // si le sample factur-x-builder ne passe pas BR-FR (Z3).
            disablePreCheck: false,
          },
          {
            customerId: ctx.customer_id,
            credentials: {
              kind: "superpdp-oauth-ac",
              accessToken: bundle.accessToken,
              refreshToken: bundle.refreshToken,
              accessExpiresAt: new Date(bundle.accessExpiresAt),
              paUserId: null,
            },
          },
        );

        await updateInvoicePaSubmission(tx, {
          id: invoiceRow.id,
          paInvoiceId: submission.paInvoiceId,
          sha256,
          statusCurrent: submission.status,
        });

        // INSERT cdar_events initial source='synthetic' avec le rawStatusCode
        // SuperPDP (`api:uploaded` typiquement). Stocke le raw en BDD
        // pour timeline UI détaillée — l'UPDATE invoices.status_current
        // ci-dessus utilise la valeur normalisée FacturEStatusCode.
        // ADR-009 D4 idempotent — premier event timeline §6.11 brief.
        await insertCdarEvent(tx, {
          invoice_id: invoiceRow.id,
          code: submission.rawStatusCode,
          label: "Déposée",
          occurred_at: new Date(),
          source: "synthetic",
        });

        await writeAuthAudit(tx, {
          event_type: "pa_invoice_submitted",
          success: true,
          user_id: ctx.user_id,
          customer_id: ctx.customer_id,
          ip: req.ip,
          user_agent: req.headers["user-agent"] ?? null,
          metadata: {
            invoice_id: invoiceRow.id,
            pa_invoice_id: submission.paInvoiceId,
            tracking_id: trackingId,
            number: form.document.number,
          },
        });

        return {
          invoice: {
            ...invoiceRow,
            pa_invoice_id: submission.paInvoiceId,
            sha256,
            status_current: submission.status,
          },
          lines: lineRows,
          paInvoiceId: submission.paInvoiceId,
        };
      });

      // Re-fetch les cdar events pour les retourner au client (le INSERT
      // synthetic était dans la tx mais sa shape complète vit en
      // `findCdarEventsByInvoiceId` post-commit).
      const { findCdarEventsByInvoiceId } = await import("../../db/repos/cdar_events.js");
      const cdarEvents = await findCdarEventsByInvoiceId(app.sqlRead, result.invoice.id);

      // L11 — pose automatique 209 Annulée sur la facture d'origine à l'envoi
      // d'une rectificative 384 (brief §3.1.2). POST-commit + try/catch isolé :
      // l'envoi de la rectificative est déjà réussi, son succès ne dépend pas
      // de la pose 209 (Z2 arbitrage Bruno — non bloquant, ADR-009 D1). Pour
      // un avoir 381 : PAS de 209 (l'origine reste dans son statut courant).
      const precedingCancellation =
        form.document.typeCode === "384" &&
        form.precedingInvoiceId !== null &&
        form.precedingInvoiceId !== undefined
          ? await tryAutoCancelPreceding(app, {
              precedingInvoiceId: form.precedingInvoiceId,
              rectificationNumber: form.document.number,
              userId: ctx.user_id,
              customerId: ctx.customer_id,
              credentials: {
                accessToken: bundle.accessToken,
                refreshToken: bundle.refreshToken,
                accessExpiresAt: bundle.accessExpiresAt,
              },
              ip: req.ip,
              userAgent: req.headers["user-agent"] ?? null,
            })
          : null;

      const response: InvoiceCreateResponse = {
        invoice: toInvoiceResponse({
          ...result.invoice,
          submitted_at: new Date(),
          updated_at: new Date(),
        }),
        lines: result.lines.map(toInvoiceLineResponse),
        cdar_events: cdarEvents.map(toCdarEventResponse),
        pa_invoice_id: result.paInvoiceId,
        preceding_cancellation: precedingCancellation,
      };
      return await reply.code(201).send(response);
    } catch (e) {
      // Mapping fail-safe ADR-009 D5 — exception typée pa-adapter
      // → HTTP code + audit event_type approprié.
      let eventType = "pa_submission_failed_max_retries";
      let httpCode = 503;
      let userMessage =
        "Votre Plateforme Agréée est momentanément indisponible. Réessayez dans quelques minutes.";

      if (e instanceof PaAccessTokenExpiredException) {
        eventType = "pa_token_expired_during_submission";
        httpCode = 401;
        userMessage =
          "Votre connexion à la Plateforme Agréée a expiré. Reconnectez-vous depuis Paramètres > Connexion à ma Plateforme Agréée.";
      } else if (e instanceof InvoiceRejectedXsdException) {
        eventType = "pa_submission_failed_4xx";
        httpCode = 422;
        userMessage = "La Plateforme Agréée a rejeté la facture (validation XSD).";
      } else if (e instanceof PaForbiddenException) {
        eventType = "pa_submission_failed_4xx";
        httpCode = 403;
        userMessage = "La Plateforme Agréée refuse cette opération.";
      } else if (e instanceof PaRateLimitException) {
        eventType = "pa_rate_limited";
        httpCode = 429;
        userMessage =
          "Trop de requêtes vers la Plateforme Agréée. Réessayez dans quelques instants.";
      } else if (e instanceof PaSubmissionFailedException) {
        eventType = "pa_submission_failed_max_retries";
        httpCode = 503;
      } else if (e instanceof PaUnavailableException) {
        eventType = "pa_submission_failed_max_retries";
        httpCode = 503;
      }

      const msg = e instanceof Error ? e.message : String(e);
      await writeAuthAudit(app.sql, {
        event_type: eventType,
        success: false,
        user_id: ctx.user_id,
        customer_id: ctx.customer_id,
        ip: req.ip,
        user_agent: req.headers["user-agent"] ?? null,
        metadata: { tracking_id: trackingId, error: msg },
      });
      // Propage le `detail` SuperPDP côté frontend pour les exceptions
      // qui le portent (`InvoiceRejectedXsdException`, `PaForbiddenException`,
      // `PaSubmissionFailedException`). Sans ça l'utilisateur voit juste
      // un message générique sans savoir QUEL BR-FR / XSD a échoué — il
      // est obligé de fouiller `auth_audit` pour trouver la cause.
      const detail =
        typeof e === "object" &&
        e !== null &&
        "detail" in e &&
        typeof (e as { detail?: unknown }).detail === "string"
          ? (e as { detail: string }).detail
          : null;
      return reply.code(httpCode).send({
        message: userMessage,
        ...(detail !== null && detail.length > 0 ? { detail } : {}),
      });
    }
  });
}

interface AutoCancelArgs {
  precedingInvoiceId: string;
  rectificationNumber: string;
  userId: string;
  customerId: string;
  credentials: { accessToken: string; refreshToken: string; accessExpiresAt: string };
  ip: string;
  userAgent: string | null;
}

/**
 * Pose 209 Annulée sur la facture d'origine après l'envoi PA réussi d'une
 * rectificative 384 (brief §3.1.2 + §4.3). **Non bloquant** (Z2) :
 *  - origine introuvable / cross-tenant → `null` (pas de cancellation).
 *  - origine jamais transmise (`pa_invoice_id === null`) → dégradé
 *    `cancelled: false` + audit `invoice.auto_cancel_209_skipped`.
 *  - PA refuse la pose 209 → dégradé `cancelled: false` + audit
 *    `invoice.auto_cancel_209_failed` (la rectificative reste envoyée ; le
 *    lien BG-3 matérialise la relation, ADR-009 D1).
 *  - succès → `cancelled: true` + cdar_events 209 (source 'app', motif
 *    standardisé) + `status_current = cancelled` + audit
 *    `invoice.auto_cancelled_by_rectification`, transaction atomique.
 */
async function tryAutoCancelPreceding(
  app: FastifyInstance,
  args: AutoCancelArgs,
): Promise<PrecedingCancellation | null> {
  const origin = await findInvoiceByIdAndCustomer(app.sqlRead, {
    id: args.precedingInvoiceId,
    customerId: args.customerId,
  });
  if (origin === undefined) return null;

  const auditBase = {
    user_id: args.userId,
    customer_id: args.customerId,
    ip: args.ip,
    user_agent: args.userAgent,
  };
  const degraded: PrecedingCancellation = {
    preceding_invoice_id: origin.id,
    preceding_number: origin.number,
    cancelled: false,
  };

  if (origin.pa_invoice_id === null) {
    await writeAuthAudit(app.sql, {
      ...auditBase,
      event_type: "invoice.auto_cancel_209_skipped",
      success: false,
      metadata: { preceding_invoice_id: origin.id, reason: "origin_not_transmitted" },
    });
    return degraded;
  }

  const reason = `Remplacée par facture rectificative ${args.rectificationNumber}`;
  try {
    const event = await app.paDriver.createInvoiceEvent(
      { paInvoiceId: origin.pa_invoice_id, statusCode: "fr:209" },
      {
        customerId: args.customerId,
        credentials: {
          kind: "superpdp-oauth-ac",
          accessToken: args.credentials.accessToken,
          refreshToken: args.credentials.refreshToken,
          accessExpiresAt: new Date(args.credentials.accessExpiresAt),
          paUserId: null,
        },
      },
    );
    await withTransaction(app.sql, async (tx) => {
      await insertCdarEvent(tx, {
        invoice_id: origin.id,
        code: event.rawStatusCode,
        label: "Annulée",
        occurred_at: event.occurredAt,
        reason,
        source: "app",
      });
      await updateInvoiceStatusCurrent(tx, { id: origin.id, statusCurrent: event.status });
      await writeAuthAudit(tx, {
        ...auditBase,
        event_type: "invoice.auto_cancelled_by_rectification",
        success: true,
        metadata: {
          original_id: origin.id,
          rectification_number: args.rectificationNumber,
          occurred_at: event.occurredAt,
        },
      });
    });
    return { preceding_invoice_id: origin.id, preceding_number: origin.number, cancelled: true };
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    app.log.warn(
      { preceding_invoice_id: origin.id, error: msg },
      "[credit-note] pose 209 auto échouée — rectificative envoyée, origine inchangée",
    );
    await writeAuthAudit(app.sql, {
      ...auditBase,
      event_type: "invoice.auto_cancel_209_failed",
      success: false,
      metadata: { preceding_invoice_id: origin.id, error: msg },
    });
    return degraded;
  }
}
