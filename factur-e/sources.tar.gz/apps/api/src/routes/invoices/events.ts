import type { FastifyInstance } from "fastify";

import { resolveSseAuthContext } from "../../auth/sse-auth.js";
import { findCdarEventsByInvoiceIdSince } from "../../db/repos/cdar_events.js";
import { findInvoiceByIdAndCustomer } from "../../db/repos/invoices.js";

import { toCdarEventResponse } from "./_shared.js";

/**
 * `GET /api/invoices/:id/events` — flux SSE (Server-Sent Events) push
 * temps-réel des CDAR events. Consommé par `useInvoiceEvents(invoiceId)`
 * côté UI (T-CL-WEB-CDAR sprint-04 §6.11 brief).
 *
 * **Stratégie (Q4 acté Bruno 2026-05-16)** : polling court 3s côté
 * serveur sur `findCdarEventsByInvoiceIdSince(received_at > lastSent)`.
 * Pas de LISTEN/NOTIFY Postgres en MVP — simple, suffisant pour la
 * latence cible (3-5s), pas de plomberie de connection long-lived
 * côté pool. Migration LISTEN/NOTIFY reportée V1 si volume.
 *
 * Pattern SSE : `Content-Type: text/event-stream`,
 * `Cache-Control: no-cache`, `Connection: keep-alive`. Chaque event :
 * `data: <JSON>\n\n`.
 *
 * Heartbeat : ligne `: ping\n\n` toutes les 25s pour empêcher les
 * proxies de fermer la connexion.
 *
 * Auth : EventSource ne supporte pas les headers custom. Depuis
 * T-CL-AUTH-SSE-COOKIE-HTTPONLY (sprint-06), l'auth passe **uniquement** par
 * le cookie HttpOnly `_session` via `resolveSseAuthContext` — plus de bearer
 * en `?token=` query (hard cut Z1 : supprime l'exposition du token dans les
 * logs reverse-proxy / Referer / historique navigateur, ADR-006/008). Le
 * cookie est envoyé automatiquement par `EventSource(url, {withCredentials})`
 * en same-origin via le proxy Vite (ADR-014).
 */
export function registerInvoicesEventsRoute(app: FastifyInstance): void {
  app.get<{ Params: { id: string } }>("/api/invoices/:id/events", async (req, reply) => {
    const ctx = await resolveSseAuthContext(req, app.sqlRead);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: "Authentification requise." });
    }

    const invoice = await findInvoiceByIdAndCustomer(app.sqlRead, {
      id: req.params.id,
      customerId: ctx.customer_id,
    });
    if (invoice === undefined) {
      return reply.code(404).send({ message: "Facture introuvable." });
    }

    // `@fastify/cors` pose `access-control-allow-origin` + `…-credentials`
    // sur le reply Fastify dans le hook `onRequest`. `reply.raw.writeHead`
    // bypass cette couche, donc on relit explicitement les headers CORS
    // pour les fusionner dans le writeHead — sans ça la SPA dev
    // (localhost:5174) se prend un blocage CORS sur la réponse SSE.
    const corsHeaders: Record<string, string> = {};
    for (const name of [
      "access-control-allow-origin",
      "access-control-allow-credentials",
      "access-control-expose-headers",
      "vary",
    ] as const) {
      const value = reply.getHeader(name);
      if (typeof value === "string") corsHeaders[name] = value;
      else if (Array.isArray(value)) corsHeaders[name] = value.join(", ");
    }
    reply.raw.writeHead(200, {
      ...corsHeaders,
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    });

    // Initial : envoyer tous les events existants en backlog (le client
    // peut re-souscrire et avoir l'état initial sans race condition).
    // T-CL-PA-EXT a posé la table sans `received_at` — on cursor sur
    // `created_at` à la place (cohérent ADR-009 + idempotence D4).
    let lastCreatedAt: Date | null = null;

    const sendEvents = async (since: Date | null): Promise<Date | null> => {
      const events = await findCdarEventsByInvoiceIdSince(app.sqlRead, {
        invoiceId: invoice.id,
        sinceCreatedAt: since,
      });
      let newLast = since;
      for (const ev of events) {
        const payload = JSON.stringify(toCdarEventResponse(ev));
        reply.raw.write(`data: ${payload}\n\n`);
        newLast = ev.created_at;
      }
      return newLast;
    };

    // Premier batch (backlog complet).
    lastCreatedAt = await sendEvents(null);

    const pollInterval = setInterval(() => {
      sendEvents(lastCreatedAt)
        .then((next) => {
          if (next !== null) lastCreatedAt = next;
        })
        .catch((err: unknown) => {
          app.log.error({ err, invoiceId: invoice.id }, "SSE poll error");
        });
    }, 3000);

    const heartbeatInterval = setInterval(() => {
      reply.raw.write(": ping\n\n");
    }, 25000);

    req.raw.on("close", () => {
      clearInterval(pollInterval);
      clearInterval(heartbeatInterval);
      if (!reply.raw.writableEnded) reply.raw.end();
    });
  });
}
