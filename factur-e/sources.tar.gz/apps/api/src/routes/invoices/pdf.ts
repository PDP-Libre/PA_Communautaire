import type { FastifyInstance } from "fastify";

import { generateCII, renderInvoicePdfFromModel } from "@factur-e/factur-x-builder";
import { FX_CONFORMANCE_LEVELS } from "@factur-e/factur-x-model";

import { resolveAuthContext } from "../../auth/context.js";
import { findActiveCustomerById } from "../../db/repos/customers.js";
import { findLinesByInvoiceId } from "../../db/repos/invoice_lines.js";
import { findInvoiceByIdAndCustomer } from "../../db/repos/invoices.js";
import { buildPdfEnrichment, footerLineFor } from "../../services/pdf-enrichment.js";
import { reconstructFormFromPersisted, reconstructInvoiceModel } from "./_reconstruct.js";

/**
 * `GET /api/invoices/:id/pdf` — télécharge le PDF Factur-X (re-généré
 * à la volée — Q3 acté Bruno, pas de cache S3 MVP).
 *
 * Stratégie : reconstruit un `CrossIndustryInvoice` depuis les rows BDD
 * (colonnes invoice + lines + payload_extended) puis `generateCII →
 * assembleFacturXPdfA3`. Le PDF re-généré est byte-équivalent à l'envoi
 * initial **à la `generationDate` près** (trailer ID MD5 calculé sur
 * (invoiceNumber, sellerName, generationDate) — cf. retro sprint-01
 * `[DEBT-medium]` byte-identique). On utilise `submitted_at` côté row
 * pour reproduire la date d'origine.
 *
 * Header `Content-Disposition: attachment; filename="<number>.pdf"`.
 */
export function registerInvoicesPdfRoute(app: FastifyInstance): void {
  app.get<{ Params: { id: string } }>("/api/invoices/:id/pdf", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: "Authentification requise." });
    }
    const invoice = await findInvoiceByIdAndCustomer(app.sqlRead, {
      id: req.params.id,
      customerId: ctx.customer_id,
    });
    if (invoice === undefined) {
      return reply.code(404).send({ message: "Facture introuvable." });
    }
    const [lines, seller] = await Promise.all([
      findLinesByInvoiceId(app.sqlRead, invoice.id),
      findActiveCustomerById(app.sqlRead, ctx.customer_id),
    ]);
    if (seller === undefined) {
      return reply.code(404).send({ message: "Entreprise introuvable." });
    }

    const form = reconstructFormFromPersisted(invoice, lines);
    const mapping = reconstructInvoiceModel(form, seller);
    if (!mapping.ok) {
      return reply.code(500).send({
        message: "Impossible de reconstruire la facture.",
        errors: mapping.errors,
      });
    }
    const xml = generateCII(mapping.value);
    const enrichment = await buildPdfEnrichment(seller, app.storage, app.log);
    const pdfBytes = await renderInvoicePdfFromModel({
      invoice: mapping.value,
      xmlBytes: Buffer.from(xml, "utf8"),
      conformanceLevel: FX_CONFORMANCE_LEVELS.EXTENDED,
      generationDate: invoice.submitted_at ?? invoice.created_at,
      enrichment,
      footerLine: footerLineFor(seller),
    });

    reply
      .header("Content-Type", "application/pdf")
      .header(
        "Content-Disposition",
        `attachment; filename="${invoice.number.replace(/[^\w\-/.]+/g, "_")}.pdf"`,
      )
      .send(Buffer.from(pdfBytes));
  });
}
