import type { FastifyInstance } from "fastify";

import { generateCII, renderInvoicePdfFromModel } from "@factur-e/factur-x-builder";
import { FX_CONFORMANCE_LEVELS } from "@factur-e/factur-x-model";

import { resolveAuthContext } from "../../auth/context.js";
import { findActiveCustomerById } from "../../db/repos/customers.js";
import { findLinesByInvoiceId } from "../../db/repos/invoice_lines.js";
import { findInvoiceByIdAndCustomer } from "../../db/repos/invoices.js";
import {
  buildPdfEnrichment,
  footerLineFor,
  headerMentionFromPayload,
} from "../../services/pdf-enrichment.js";
import { invoicePdfArchiveKey } from "../../services/invoice-pdf-archive.js";
import { reconstructFormFromPersisted, reconstructInvoiceModel } from "./_reconstruct.js";

/**
 * `GET /api/invoices/:id/pdf` — télécharge le PDF Factur-X.
 *
 * Deux chemins (F8 — T-CL-RECONSTRUCT-FIDELE-F8) :
 *  1. **Facture envoyée avec copie immuable** (`pdf_archived_at != null`) →
 *     sert les bytes transmis tels quels depuis le stockage objet
 *     (conservation 180 j). Intégrité : bytes stables entre deux GET. Si la
 *     copie a été purgée (lifecycle 180 j) → fallback reconstruction
 *     (fail-safe ADR-009).
 *  2. **Brouillon/preview ou facture legacy** (`pdf_archived_at == null`) →
 *     reconstruit un `CrossIndustryInvoice` depuis les rows BDD (colonnes
 *     invoice + lines + payload_extended, reconstruction désormais fidèle au
 *     mode avancé) puis `generateCII → assembleFacturXPdfA3`. Le PDF
 *     re-généré est byte-équivalent à l'envoi initial **à la `generationDate`
 *     près** (trailer ID MD5) ; on utilise `submitted_at` pour reproduire la
 *     date d'origine.
 *
 * Header `Content-Disposition: attachment; filename="<number>.pdf"`.
 */
export function registerInvoicesPdfRoute(app: FastifyInstance): void {
  app.get<{ Params: { id: string } }>("/api/invoices/:id/pdf", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: "Authentification requise." });
    }
    const invoice = await findInvoiceByIdAndCustomer(app.sqlRead, {
      id: req.params.id,
      customerId: ctx.customer_id,
    });
    if (invoice === undefined) {
      return reply.code(404).send({ message: "Facture introuvable." });
    }

    const filename = `${invoice.number.replace(/[^\w\-/.]+/g, "_")}.pdf`;

    // F8 — facture envoyée avec copie immuable (conservation 180 j) : on sert
    // les bytes transmis tels quels (intégrité — pas de re-génération). Si la
    // copie a été purgée par le lifecycle 180 j (`downloadObject` KO alors que
    // `pdf_archived_at != null`), on retombe sur la reconstruction fidèle
    // (fail-safe ADR-009, pas de 500). `pdf_archived_at` NULL (brouillon /
    // preview / facture legacy) → reconstruction directement.
    let archivedBody: Buffer | null = null;
    if (invoice.pdf_archived_at !== null) {
      try {
        const archived = await app.exportsStorage.downloadObject(
          invoicePdfArchiveKey(ctx.customer_id, invoice.id),
        );
        archivedBody = archived.body;
      } catch (err) {
        app.log.warn(
          { invoice_id: invoice.id, err },
          "[invoices] copie immuable introuvable (purgée 180 j ?) — reconstruction fidèle (fail-safe)",
        );
      }
    }
    if (archivedBody !== null) {
      return reply
        .header("Content-Type", "application/pdf")
        .header("Content-Disposition", `attachment; filename="${filename}"`)
        .send(archivedBody);
    }

    const [lines, seller] = await Promise.all([
      findLinesByInvoiceId(app.sqlRead, invoice.id),
      findActiveCustomerById(app.sqlRead, ctx.customer_id),
    ]);
    if (seller === undefined) {
      return reply.code(404).send({ message: "Entreprise introuvable." });
    }

    const form = reconstructFormFromPersisted(invoice, lines);
    const mapping = reconstructInvoiceModel(form, seller);
    if (!mapping.ok) {
      return reply.code(500).send({
        message: "Impossible de reconstruire la facture.",
        errors: mapping.errors,
      });
    }
    const xml = generateCII(mapping.value);
    const enrichment = await buildPdfEnrichment(seller, app.storage, app.log);
    // F7 — mention d'en-tête depuis le payload persisté (régénération, sans
    // passer par la reconstruction de form qui reste mode base).
    enrichment.headerMention = headerMentionFromPayload(invoice.payload_extended);
    const pdfBytes = await renderInvoicePdfFromModel({
      invoice: mapping.value,
      xmlBytes: Buffer.from(xml, "utf8"),
      conformanceLevel: FX_CONFORMANCE_LEVELS.EXTENDED,
      generationDate: invoice.submitted_at ?? invoice.created_at,
      enrichment,
      footerLine: footerLineFor(seller),
    });

    reply
      .header("Content-Type", "application/pdf")
      .header("Content-Disposition", `attachment; filename="${filename}"`)
      .send(Buffer.from(pdfBytes));
  });
}
