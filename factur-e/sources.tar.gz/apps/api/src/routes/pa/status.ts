import type { FastifyInstance } from "fastify";

import { resolveAuthContext } from "../../auth/context.js";
import * as paRepo from "../../db/repos/pa_connections.js";
import type { IdentityStatus } from "@factur-e/pa-adapter";

interface PaStatusConnectedResponse {
  connected: true;
  /** Worst-case derivation of the two SuperPDP statuses — what the SPA
   *  shows in the dashboard pill (verified / needs_review / rejected). */
  identity_status: IdentityStatus;
  user_identity_verification_status: IdentityStatus;
  company_verification_status: IdentityStatus;
  last_refreshed_at: string | null;
  connected_at: string;
  pa_user_id: string | null;
}

interface PaStatusDisconnectedResponse {
  connected: false;
}

/**
 * `GET /pa/status` — read the active PA connection status for the
 * customer's TPE. PA-agnostic surface (V2 will return more rows in a
 * `connections` array if multi-PA is enabled).
 *
 * Auth Bearer required. Returned as JSON to the SPA dashboard pill +
 * the brief sprint-03 §6.4 "Detail technique" expander.
 *
 * Cf. PRD v1.4 §5.3 + plan T-CL-06 sprint-03.
 */
export function registerPaStatusRoute(app: FastifyInstance): void {
  app.get("/pa/status", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: "Authentification requise." });
    }
    const row = await paRepo.findActivePaConnectionStatusByCustomerId(app.sqlRead, ctx.customer_id);
    if (row === undefined) {
      const body: PaStatusDisconnectedResponse = { connected: false };
      return reply.code(200).send(body);
    }
    const identityStatus: IdentityStatus =
      row.user_identity_verification_status === "rejected" ||
      row.company_verification_status === "rejected"
        ? "rejected"
        : row.user_identity_verification_status === "needs_review" ||
            row.company_verification_status === "needs_review"
          ? "needs_review"
          : "verified";
    const body: PaStatusConnectedResponse = {
      connected: true,
      identity_status: identityStatus,
      user_identity_verification_status: row.user_identity_verification_status,
      company_verification_status: row.company_verification_status,
      last_refreshed_at: row.last_refreshed_at?.toISOString() ?? null,
      connected_at: row.connected_at.toISOString(),
      pa_user_id: row.pa_user_id,
    };
    return reply.code(200).send(body);
  });
}
