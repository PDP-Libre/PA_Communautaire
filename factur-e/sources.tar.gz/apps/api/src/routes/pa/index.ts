import type { FastifyInstance } from "fastify";

import { registerPaProvidersRoute } from "./providers.js";
import { registerPaStatusRoute } from "./status.js";

export function registerPaRoutes(app: FastifyInstance): void {
  registerPaStatusRoute(app);
  registerPaProvidersRoute(app);
}
