import type { FastifyInstance } from "fastify";

import { listEnabledProviders, type ProviderDescriptor } from "../../pa/registry.js";

/**
 * `GET /api/pa/providers` — liste publique des providers PA activés
 * (T-CL-PA-INVOICE-FIX sprint-04, ADR-012 D8).
 *
 * Consommé par l'UI Bloc 3 frontend onboarding pour proposer un choix
 * de PA au customer (V1 : uniquement SuperPDP visible — EsaLink gated
 * par `ENABLE_ESALINK_PROVIDER=false` default).
 *
 * **Pas d'auth requise** : la liste des PA disponibles est une
 * information publique du produit (pas de fuite tenant-cross). L'UI
 * peut l'appeler en pré-login pour pré-construire le sélecteur.
 *
 * **Note convention path** : préfixé `/api/pa/...` per brief (cohérent
 * T-CL-DEV-01 dev-env LAN). L'endpoint sprint-03 `GET /pa/status` ne
 * porte historiquement pas le préfixe `/api/` — `[NOTE-COWORK]`
 * harmonisation sprint-05+.
 */

interface ProvidersResponse {
  providers: ProviderDescriptor[];
}

export function registerPaProvidersRoute(app: FastifyInstance): void {
  app.get("/api/pa/providers", (_req, reply) => {
    const body: ProvidersResponse = { providers: listEnabledProviders() };
    return reply.code(200).send(body);
  });
}
