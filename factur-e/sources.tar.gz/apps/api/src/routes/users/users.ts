import type { FastifyInstance } from "fastify";
import {
  PatchUserCanPurchaseBodySchema,
  PatchUserRoleBodySchema,
  type UserListItem,
  type UserListResponse,
} from "@factur-e/shared-schemas";

import { writeAuthAudit } from "../../auth/audit.js";
import { resolveAuthContext } from "../../auth/context.js";
import * as sessionsRepo from "../../db/repos/sessions.js";
import * as usersRepo from "../../db/repos/users.js";
import { withTransaction } from "../../db/tx.js";
import { requireFullRole } from "../../profile/role-guard.js";
import { loadUserForCustomer, wouldDropLastFull } from "../../users/role-rules.js";

const NEUTRAL = "Vérifiez vos informations.";

export function registerUsersAdminRoutes(app: FastifyInstance): void {
  // ─────────────────────────────────────────────────────────────────────
  // GET /users — Full only — list active users of the customer
  // ─────────────────────────────────────────────────────────────────────
  app.get("/users", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: NEUTRAL });
    }
    if ((await requireFullRole(app, reply, ctx)) === null) return;

    // Pure read → app.sqlRead (alias of app.sql in MVP, replica V2 ready).
    const rows = await usersRepo.findActiveUsersByCustomerForList(app.sqlRead, ctx.customer_id);
    const users: UserListItem[] = rows.map((r) => ({
      id: r.id,
      email: r.email,
      role: r.role,
      can_purchase: r.can_purchase,
      mfa_mode: r.mfa_mode,
      last_login_at: r.last_login_at?.toISOString() ?? null,
      created_at: r.created_at.toISOString(),
    }));
    const body: UserListResponse = { users };
    return reply.code(200).send(body);
  });

  // ─────────────────────────────────────────────────────────────────────
  // PATCH /users/:id/role — Full only — change role
  // ─────────────────────────────────────────────────────────────────────
  app.patch<{ Params: { id: string } }>("/users/:id/role", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: NEUTRAL });
    }
    if ((await requireFullRole(app, reply, ctx)) === null) return;

    if (req.params.id === ctx.user_id) {
      return reply.code(400).send({ message: "Vous ne pouvez pas modifier votre propre rôle." });
    }

    const parsed = PatchUserRoleBodySchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ message: NEUTRAL });
    }

    const target = await loadUserForCustomer(app.sql, req.params.id, ctx.customer_id);
    if (target?.deleted_at !== null) {
      return reply.code(404).send({ message: "Utilisateur introuvable." });
    }

    const newRole = parsed.data.role;
    if (newRole !== "full" && (await wouldDropLastFull(app.sql, target))) {
      return reply.code(400).send({
        message: "Impossible : il doit rester au moins un Responsable actif.",
      });
    }

    await usersRepo.markRole(app.sql, target.id, newRole);
    await writeAuthAudit(app.sql, {
      event_type: "user_role_changed",
      success: true,
      user_id: ctx.user_id,
      customer_id: ctx.customer_id,
      ip: req.ip,
      user_agent: req.headers["user-agent"] ?? null,
      metadata: { target_user_id: target.id, from: target.role, to: newRole },
    });
    return reply.code(204).send();
  });

  // ─────────────────────────────────────────────────────────────────────
  // PATCH /users/:id/can-purchase — Full only — toggle pack-purchase flag
  // ─────────────────────────────────────────────────────────────────────
  app.patch<{ Params: { id: string } }>("/users/:id/can-purchase", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: NEUTRAL });
    }
    if ((await requireFullRole(app, reply, ctx)) === null) return;

    if (req.params.id === ctx.user_id) {
      return reply
        .code(400)
        .send({ message: "Vous ne pouvez pas modifier votre propre droit d'achat." });
    }

    const parsed = PatchUserCanPurchaseBodySchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ message: NEUTRAL });
    }

    const target = await loadUserForCustomer(app.sql, req.params.id, ctx.customer_id);
    if (target?.deleted_at !== null) {
      return reply.code(404).send({ message: "Utilisateur introuvable." });
    }

    await usersRepo.markCanPurchase(app.sql, target.id, parsed.data.can_purchase);
    await writeAuthAudit(app.sql, {
      event_type: "user_can_purchase_changed",
      success: true,
      user_id: ctx.user_id,
      customer_id: ctx.customer_id,
      ip: req.ip,
      user_agent: req.headers["user-agent"] ?? null,
      metadata: { target_user_id: target.id, can_purchase: parsed.data.can_purchase },
    });
    return reply.code(204).send();
  });

  // ─────────────────────────────────────────────────────────────────────
  // DELETE /users/:id — Full only — soft-delete (deleted_at = NOW)
  // ─────────────────────────────────────────────────────────────────────
  app.delete<{ Params: { id: string } }>("/users/:id", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: NEUTRAL });
    }
    if ((await requireFullRole(app, reply, ctx)) === null) return;

    if (req.params.id === ctx.user_id) {
      return reply.code(400).send({ message: "Vous ne pouvez pas vous supprimer vous-même." });
    }

    const target = await loadUserForCustomer(app.sql, req.params.id, ctx.customer_id);
    if (target?.deleted_at !== null) {
      return reply.code(404).send({ message: "Utilisateur introuvable." });
    }

    if (await wouldDropLastFull(app.sql, target)) {
      return reply.code(400).send({
        message: "Impossible : il doit rester au moins un Responsable actif.",
      });
    }

    await withTransaction(app.sql, async (tx) => {
      await usersRepo.markUserDeleted(tx, target.id);
      // Revoke all live sessions of this user — they get logged out at once.
      await sessionsRepo.deleteSessionsByUserId(tx, target.id);
    });
    await writeAuthAudit(app.sql, {
      event_type: "user_deactivated",
      success: true,
      user_id: ctx.user_id,
      customer_id: ctx.customer_id,
      ip: req.ip,
      user_agent: req.headers["user-agent"] ?? null,
      metadata: { target_user_id: target.id, role: target.role },
    });
    return reply.code(204).send();
  });
}
