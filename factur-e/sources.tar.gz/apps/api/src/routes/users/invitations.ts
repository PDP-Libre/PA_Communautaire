import { randomUUID } from "node:crypto";

import type { FastifyInstance } from "fastify";
import {
  AcceptInvitationBodySchema,
  type AcceptInvitationResponse,
  type InvitationCreateResponse,
  InvitationCreateBodySchema,
  type InvitationPreview,
  type PendingInvitation,
  type PendingInvitationsResponse,
} from "@factur-e/shared-schemas";

import { hashPassword } from "../../auth/argon2.js";
import { writeAuthAudit } from "../../auth/audit.js";
import { resolveAuthContext } from "../../auth/context.js";
import { setRefreshSessionCookie } from "../../auth/cookies.js";
import { signAccessToken, signRefreshToken, TTL_SECONDS } from "../../auth/jwt.js";
import * as customersRepo from "../../db/repos/customers.js";
import * as invitationsRepo from "../../db/repos/invitations.js";
import * as usersRepo from "../../db/repos/users.js";
import { insertSession, withTransaction } from "../../db/tx.js";
import { requireFullRole } from "../../profile/role-guard.js";
import {
  buildInvitationToken,
  generateInvitationSecret,
  hashInvitationSecret,
  parseInvitationToken,
  verifyInvitationSecret,
} from "../../users/invitation-token.js";

const INVITATION_TTL_DAYS = 7;
const NEUTRAL = "Vérifiez vos informations.";
const INVITATION_INVALID = "Invitation invalide ou expirée.";

function inviteUrl(token: string): string {
  const base = process.env.WEB_BASE_URL ?? "http://localhost:5174";
  return `${base}/invite/${token}`;
}

export function registerInvitationRoutes(app: FastifyInstance): void {
  // ─────────────────────────────────────────────────────────────────────
  // POST /users/invite — Full only — issue an invitation
  // ─────────────────────────────────────────────────────────────────────
  app.post("/users/invite", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: NEUTRAL });
    }
    if ((await requireFullRole(app, reply, ctx)) === null) return;

    const parsed = InvitationCreateBodySchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ message: NEUTRAL });
    }
    const { email, role, can_purchase } = parsed.data;
    const normalizedEmail = email.toLowerCase();
    const ip = req.ip;
    const ua = req.headers["user-agent"] ?? null;

    // Refuse if a user with this email already exists (active or deleted —
    // we don't reveal soft-deletes either, return the same neutral 409).
    const existing = await usersRepo.findUserIdByEmailAnyState(app.sql, normalizedEmail);
    if (existing !== undefined) {
      await writeAuthAudit(app.sql, {
        event_type: "user_invite_failed",
        success: false,
        user_id: ctx.user_id,
        customer_id: ctx.customer_id,
        ip,
        user_agent: ua,
        metadata: { reason: "email_exists" },
      });
      return reply.code(409).send({ message: "Cet email est déjà utilisé." });
    }

    // Replace any pending invitation for the same email + customer (Q5).
    await invitationsRepo.deletePendingInvitationByCustomerAndEmail(app.sql, {
      customerId: ctx.customer_id,
      email: normalizedEmail,
    });

    const id = randomUUID();
    const secret = generateInvitationSecret();
    const tokenHash = await hashInvitationSecret(secret);

    await invitationsRepo.insertInvitation(app.sql, {
      id,
      customerId: ctx.customer_id,
      inviterId: ctx.user_id,
      email: normalizedEmail,
      role,
      canPurchase: can_purchase,
      tokenHash,
      ttlDays: INVITATION_TTL_DAYS,
    });

    // Inviter name + customer legal name for the email body.
    const customer = await customersRepo.findCustomerLegalNameById(app.sql, ctx.customer_id);
    const inviter = await usersRepo.findUserEmailById(app.sql, ctx.user_id);

    const fullToken = buildInvitationToken(id, secret);
    await app.email.send({
      to: normalizedEmail,
      purpose: "invitation",
      payload: {
        magic_link: inviteUrl(fullToken),
        vars: {
          inviter_name: inviter?.email ?? "Un collaborateur",
          customer_name: customer?.legal_name ?? "votre entreprise",
        },
      },
    });

    const expiresRow = await invitationsRepo.findInvitationExpiresAtById(app.sql, id);
    const expiresAt = expiresRow?.expires_at ?? new Date();

    await writeAuthAudit(app.sql, {
      event_type: "user_invited",
      success: true,
      user_id: ctx.user_id,
      customer_id: ctx.customer_id,
      ip,
      user_agent: ua,
      metadata: { invitation_id: id, role, can_purchase },
    });

    const body: InvitationCreateResponse = {
      invitation_id: id,
      expires_at: expiresAt.toISOString(),
    };
    return reply.code(201).send(body);
  });

  // ─────────────────────────────────────────────────────────────────────
  // GET /invitations — Full only — list pending invitations
  // ─────────────────────────────────────────────────────────────────────
  app.get("/invitations", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: NEUTRAL });
    }
    if ((await requireFullRole(app, reply, ctx)) === null) return;

    // Pure read → app.sqlRead.
    const rows = await invitationsRepo.findPendingInvitationsByCustomer(
      app.sqlRead,
      ctx.customer_id,
    );
    const invitations: PendingInvitation[] = rows.map((r) => ({
      id: r.id,
      email: r.email,
      role: r.role,
      can_purchase: r.can_purchase,
      inviter_id: r.inviter_id,
      expires_at: r.expires_at.toISOString(),
      created_at: r.created_at.toISOString(),
    }));
    const body: PendingInvitationsResponse = { invitations };
    return reply.code(200).send(body);
  });

  // ─────────────────────────────────────────────────────────────────────
  // DELETE /invitations/:id — Full only — revoke
  // ─────────────────────────────────────────────────────────────────────
  app.delete<{ Params: { id: string } }>("/invitations/:id", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: NEUTRAL });
    }
    if ((await requireFullRole(app, reply, ctx)) === null) return;

    const count = await invitationsRepo.deletePendingInvitationByIdAndCustomer(app.sql, {
      id: req.params.id,
      customerId: ctx.customer_id,
    });
    if (count === 0) {
      return reply.code(404).send({ message: "Invitation introuvable." });
    }
    await writeAuthAudit(app.sql, {
      event_type: "user_invitation_revoked",
      success: true,
      user_id: ctx.user_id,
      customer_id: ctx.customer_id,
      ip: req.ip,
      user_agent: req.headers["user-agent"] ?? null,
      metadata: { invitation_id: req.params.id },
    });
    return reply.code(204).send();
  });

  // ─────────────────────────────────────────────────────────────────────
  // GET /invitations/:token/preview — public — returns metadata for the
  // accept page (so the invitee sees who invited them and which role).
  // ─────────────────────────────────────────────────────────────────────
  app.get<{ Params: { token: string } }>("/invitations/:token/preview", async (req, reply) => {
    const parsed = parseInvitationToken(req.params.token);
    if (parsed === null) {
      return reply.code(404).send({ message: INVITATION_INVALID });
    }
    const r = await invitationsRepo.findInvitationPreviewById(app.sqlRead, parsed.id);
    if (
      r?.accepted_at !== null ||
      r.expires_at.getTime() < Date.now() ||
      !(await verifyInvitationSecret(parsed.secret, r.token_hash))
    ) {
      return reply.code(404).send({ message: INVITATION_INVALID });
    }
    const body: InvitationPreview = {
      email: r.email,
      role: r.role,
      can_purchase: r.can_purchase,
      customer_legal_name: r.customer_legal_name,
      inviter_email: r.inviter_email,
    };
    return reply.code(200).send(body);
  });

  // ─────────────────────────────────────────────────────────────────────
  // POST /invitations/:token/accept — public — create user + sign in.
  // MFA setup deferred to first login (mfa_reset_required = true).
  // ─────────────────────────────────────────────────────────────────────
  app.post<{ Params: { token: string } }>("/invitations/:token/accept", async (req, reply) => {
    const ip = req.ip;
    const ua = req.headers["user-agent"] ?? null;

    const parsedToken = parseInvitationToken(req.params.token);
    if (parsedToken === null) {
      return reply.code(404).send({ message: INVITATION_INVALID });
    }

    const parsedBody = AcceptInvitationBodySchema.safeParse(req.body);
    if (!parsedBody.success) {
      return reply.code(400).send({ message: NEUTRAL });
    }
    const { password } = parsedBody.data;

    const inv = await invitationsRepo.findInvitationForAcceptById(app.sql, parsedToken.id);
    if (
      inv?.accepted_at !== null ||
      inv.expires_at.getTime() < Date.now() ||
      !(await verifyInvitationSecret(parsedToken.secret, inv.token_hash))
    ) {
      return reply.code(404).send({ message: INVITATION_INVALID });
    }

    // Race-condition guard: someone could have signed up directly with
    // this email between invite creation and acceptance.
    const collision = await usersRepo.findUserIdByEmailAnyState(app.sql, inv.email);
    if (collision !== undefined) {
      await writeAuthAudit(app.sql, {
        event_type: "user_invitation_accept_failed",
        success: false,
        customer_id: inv.customer_id,
        ip,
        user_agent: ua,
        metadata: { invitation_id: inv.id, reason: "email_exists" },
      });
      return reply.code(409).send({ message: "Cet email est déjà utilisé." });
    }

    const passwordHash = await hashPassword(password);
    const userId = randomUUID();
    const sessionId = randomUUID();

    await withTransaction(app.sql, async (tx) => {
      await usersRepo.insertUserFromInvitation(tx, {
        id: userId,
        customerId: inv.customer_id,
        email: inv.email,
        passwordHash,
        role: inv.role,
        canPurchase: inv.can_purchase,
      });
      await invitationsRepo.markInvitationAccepted(tx, inv.id);
      await insertSession(tx, { id: sessionId, userId, ip, userAgent: ua });
    });

    const accessToken = await signAccessToken({
      user_id: userId,
      customer_id: inv.customer_id,
    });
    const refreshToken = await signRefreshToken({
      session_id: sessionId,
      user_id: userId,
    });
    setRefreshSessionCookie(reply, refreshToken);

    await writeAuthAudit(app.sql, {
      event_type: "user_invitation_accepted",
      success: true,
      user_id: userId,
      customer_id: inv.customer_id,
      ip,
      user_agent: ua,
      metadata: { invitation_id: inv.id, role: inv.role, can_purchase: inv.can_purchase },
    });

    const body: AcceptInvitationResponse = {
      access_token: accessToken,
      expires_in: TTL_SECONDS.access,
      mfa_setup_required: true,
    };
    return reply.code(200).send(body);
  });
}
