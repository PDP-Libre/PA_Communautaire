import type { FastifyInstance } from "fastify";

import { registerInvitationRoutes } from "./invitations.js";
import { registerUsersAdminRoutes } from "./users.js";

export function registerUsersRoutes(app: FastifyInstance): void {
  registerInvitationRoutes(app);
  registerUsersAdminRoutes(app);
}
