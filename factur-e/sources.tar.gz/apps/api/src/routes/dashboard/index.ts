import type { FastifyInstance } from "fastify";

import { registerRetentionAlertsRoute } from "./retention-alerts.js";

/** Routes dashboard (T-CL-EXPORT-ZIP-RETENTION sprint-06 L12). */
export function registerDashboardRoutes(app: FastifyInstance): void {
  registerRetentionAlertsRoute(app);
}
