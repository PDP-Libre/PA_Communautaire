import type { FastifyInstance } from "fastify";

import type { RetentionAlert } from "@factur-e/shared-schemas";

import { resolveAuthContext } from "../../auth/context.js";

/**
 * `GET /api/dashboard/retention-alerts` — counts de factures approchant leur
 * date de conservation (6 mois) sans avoir été archivées (`exported_at IS
 * NULL`). Alimente `ExportRappelBanner` (severity `blocked > j7 > j30` côté
 * front).
 *
 * NOTE-COWORK (C6) : l'ancre de rétention retenue est `created_at + 6 mois`
 * (date d'entrée de la facture sur Factur-e). La purge effective des factures
 * (vs. des archives ZIP) est hors scope sprint-06 — ces counts sont un signal
 * pédagogique "exportez avant la suppression", pas un déclencheur de purge.
 *
 * Accessible à tous les rôles authentifiés (le badge/bandeau sont visibles
 * aussi aux rôles non-Full, RET-7 — seul le déclenchement d'export est Full).
 */
export function registerRetentionAlertsRoute(app: FastifyInstance): void {
  app.get("/api/dashboard/retention-alerts", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: "Authentification requise." });
    }

    const rows = await app.sqlRead<{ blocked: string; j7: string; j30: string }[]>`
      WITH base AS (
        SELECT (created_at + INTERVAL '6 months') AS purge_at
        FROM invoices
        WHERE customer_id = ${ctx.customer_id}
          AND deleted_at IS NULL AND exported_at IS NULL
        UNION ALL
        SELECT (created_at + INTERVAL '6 months') AS purge_at
        FROM received_invoices
        WHERE customer_id = ${ctx.customer_id}
          AND deleted_at IS NULL AND exported_at IS NULL
      )
      SELECT
        COUNT(*) FILTER (WHERE purge_at <= NOW())::text AS blocked,
        COUNT(*) FILTER (
          WHERE purge_at > NOW() AND purge_at <= NOW() + INTERVAL '7 days'
        )::text AS j7,
        COUNT(*) FILTER (
          WHERE purge_at > NOW() + INTERVAL '7 days' AND purge_at <= NOW() + INTERVAL '30 days'
        )::text AS j30
      FROM base
    `;
    const r = rows[0];
    const body: RetentionAlert = {
      blockedCount: Number(r?.blocked ?? "0"),
      j7Count: Number(r?.j7 ?? "0"),
      j30Count: Number(r?.j30 ?? "0"),
    };
    return reply.send(body);
  });
}
