import type { FastifyInstance, FastifyReply } from "fastify";

import { PaInvalidStateException } from "@factur-e/pa-adapter";

import { writeAuthAudit } from "../../auth/audit.js";
import {
  OAUTH_STATE_COOKIE,
  clearOAuthStateCookieOptions,
  verifyOAuthStateToken,
  type OAuthStatePayload,
} from "../../auth/oauth-state.js";
import * as customersRepo from "../../db/repos/customers.js";
import * as paRepo from "../../db/repos/pa_connections.js";
import { paConnectionUiUrl, paSecretRef, superpdpRedirectUri } from "../../pa/secret-ref.js";
import { reconcileCustomerIdentity } from "../../services/identity-reconciliation.js";

interface CallbackQuery {
  code?: string;
  state?: string;
  error?: string;
  error_description?: string;
}

/**
 * `GET /oauth/superpdp/callback` — SuperPDP redirects the user here
 * after consent. We:
 *  1. Read the `oauth_state` cookie (5-min JWT signed in /authorize).
 *  2. Validate `state` query === claim and exchange `code` for tokens.
 *  3. Store the bundle in SecretStore + INSERT pa_connections.
 *  4. Audit + clear cookie + 302 to the SPA with a `status=` query param.
 *
 * Anon: yes (the user comes back from SuperPDP without a Bearer). The
 * cookie is the resume mechanism. The mfa-reset-guard's anon-bypass
 * lets it through (cf. mfa-reset-guard.ts file header T-CL-06 patch).
 *
 * Cookie cleared systematically (success OR failure) to avoid leaving
 * a consumable JWT in the browser. CLAUDE.md §11 defense in depth.
 *
 * Cf. ADR-005 D1+D5+D7+D8, plan T-CL-06 sprint-03.
 */
export function registerOAuthCallbackRoute(app: FastifyInstance): void {
  app.get<{ Querystring: CallbackQuery }>("/oauth/superpdp/callback", async (req, reply) => {
    const cookieRaw = req.cookies[OAUTH_STATE_COOKIE];
    if (typeof cookieRaw !== "string" || cookieRaw === "") {
      // No cookie → the user didn't come from /oauth/superpdp/authorize
      // (or cookie expired). Clear defensively + 401.
      reply.clearCookie(OAUTH_STATE_COOKIE, clearOAuthStateCookieOptions());
      return reply.code(401).send({ message: "Session OAuth expirée." });
    }

    let payload: OAuthStatePayload;
    try {
      payload = await verifyOAuthStateToken(cookieRaw);
    } catch {
      reply.clearCookie(OAUTH_STATE_COOKIE, clearOAuthStateCookieOptions());
      return reply.code(401).send({ message: "Session OAuth invalide." });
    }

    // Helper to clean up + audit failure + redirect.
    const failReply = async (
      reason: string,
      uiStatus: "rejected" | "error",
    ): Promise<FastifyReply> => {
      reply.clearCookie(OAUTH_STATE_COOKIE, clearOAuthStateCookieOptions());
      await writeAuthAudit(app.sql, {
        event_type: "pa_connection_failed",
        success: false,
        user_id: payload.user_id,
        customer_id: payload.customer_id,
        ip: req.ip,
        user_agent: req.headers["user-agent"] ?? null,
        metadata: { reason },
      });
      return reply
        .code(302)
        .header("location", paConnectionUiUrl({ status: uiStatus, reason }))
        .send();
    };

    // SuperPDP returned an OAuth error (user denied, scope insufficient, etc.).
    if (typeof req.query.error === "string" && req.query.error !== "") {
      return failReply(req.query.error, "error");
    }

    // Validate state explicitly here (the driver also validates, but
    // this lets us produce a typed audit reason without throwing).
    if (req.query.state !== payload.state) {
      reply.clearCookie(OAUTH_STATE_COOKIE, clearOAuthStateCookieOptions());
      await writeAuthAudit(app.sql, {
        event_type: "pa_connection_failed",
        success: false,
        user_id: payload.user_id,
        customer_id: payload.customer_id,
        ip: req.ip,
        user_agent: req.headers["user-agent"] ?? null,
        metadata: { reason: "state_mismatch" },
      });
      return reply.code(401).send({ message: "État OAuth invalide." });
    }

    if (typeof req.query.code !== "string" || req.query.code === "") {
      return failReply("missing_code", "error");
    }

    // Exchange the code for tokens.
    let tokens;
    try {
      tokens = await app.paDriver.exchangeCode({
        code: req.query.code,
        state: req.query.state,
        expectedState: payload.state,
        codeVerifier: payload.code_verifier,
        redirectUri: superpdpRedirectUri(),
      });
    } catch (err) {
      if (err instanceof PaInvalidStateException) {
        return failReply("state_mismatch", "error");
      }
      app.log.error({ err }, "[oauth/callback] exchangeCode failed");
      return failReply("exchange_failed", "error");
    }

    // Fetch the identity status snapshot — used to populate pa_connections
    // INSERT. If SuperPDP returns 5xx (transient), we degrade gracefully:
    // INSERT with `needs_review` defaults so the connection exists and the
    // polling sub-job catches up within 30 min (cf. T-CL-07 expert review
    // [low] #3 — preferred mitigation b). Avoids a re-tunnel SuperPDP for
    // a transient post-exchange error since the OAuth code is one-shot.
    let identity;
    try {
      identity = await app.paDriver.getIdentityStatus({ accessToken: tokens.accessToken });
    } catch (err) {
      app.log.warn(
        { err, customer_id: payload.customer_id },
        "[oauth/callback] getIdentityStatus failed, defaulting to needs_review (polling will catch up)",
      );
      identity = {
        paUserId: null,
        user: "needs_review" as const,
        company: "needs_review" as const,
        siren: null,
      };
    }

    // INSERT pa_connections BEFORE writing the secret bundle. If a
    // concurrent /authorize click landed first (UNIQUE PARTIAL on
    // `(customer_id, provider) WHERE deleted_at IS NULL`), this throws
    // and we fail-reply WITHOUT touching the secret store — leaving the
    // first concurrent connection clean. Cf. T-CL-07 expert review
    // [medium] #2.
    const secretRef = paSecretRef({ customerId: payload.customer_id });
    try {
      await paRepo.insertPaConnection(app.sql, {
        customerId: payload.customer_id,
        paUserId: identity.paUserId,
        secretRef,
        userIdentityStatus: identity.user,
        companyStatus: identity.company,
      });
    } catch (err) {
      app.log.error({ err }, "[oauth/callback] insertPaConnection failed");
      // The most common failure here is the partial-UNIQUE conflict on
      // a concurrent authorize click. Other DB errors get the same
      // surface UX-wise — the user retries.
      return failReply("concurrent_or_db_failed", "error");
    }

    // INSERT succeeded — now persist the bundle. If SecretStore.put
    // fails, soft-delete the row we just created so we don't leave a
    // pa_connections row pointing at a missing secret_ref.
    try {
      await app.secrets.put(secretRef, {
        accessToken: tokens.accessToken,
        refreshToken: tokens.refreshToken,
        accessExpiresAt: tokens.accessExpiresAt.toISOString(),
      });
    } catch (err) {
      app.log.error({ err }, "[oauth/callback] secret_store.put failed — rolling back row");
      const existing = await paRepo.findActivePaConnectionForDisconnectByCustomerId(
        app.sqlRead,
        payload.customer_id,
      );
      if (existing !== undefined) {
        await paRepo.markPaConnectionRevoked(app.sql, existing.id).catch(() => undefined);
      }
      return failReply("secret_store_unavailable", "error");
    }

    await writeAuthAudit(app.sql, {
      event_type: "pa_connection_completed",
      success: true,
      user_id: payload.user_id,
      customer_id: payload.customer_id,
      ip: req.ip,
      user_agent: req.headers["user-agent"] ?? null,
      metadata: {
        user_identity_verification_status: identity.user,
        company_verification_status: identity.company,
      },
    });

    // T-CL-SIREN-RECONCILIATION sprint-06 W1 — au callback `verified/
    // verified`, on clear `profile_unverified` + les flags champ-
    // spécifiques IMMÉDIATEMENT (ADR-007 D2 "bascule immédiate" — répare
    // le gap où seul le polling 30 min le faisait), puis on réconcilie
    // silencieusement le SIREN (Mécanisme 3, priorité KYC). Permet aux
    // recettes T-BR-EMIT-V3 d'émettre sans attendre un tick de polling
    // et lève le workaround psql historique (NC-13 sprint-04).
    // Issue de la réconciliation SIREN → portée jusqu'à la redirection SPA
    // (message Toast/Alert). L'adresse Peppol émetteur est résolue plus bas
    // via `getOwnDirectoryEntries` (indépendant du SIREN).
    let sirenOutcome: "reconciled" | "blocked" | undefined;

    if (identity.user === "verified" && identity.company === "verified") {
      const cleared = await customersRepo.markCustomerProfileVerified(app.sql, payload.customer_id);
      // `pa_profile_verified` conditionnel count>0 — pas de pollution sur
      // un profil déjà vérifié (cohérent T-CL-07 F4 + polling sub-job).
      if (cleared > 0) {
        await writeAuthAudit(app.sql, {
          event_type: "pa_profile_verified",
          success: true,
          user_id: payload.user_id,
          customer_id: payload.customer_id,
          ip: req.ip,
          user_agent: req.headers["user-agent"] ?? null,
        });
      }

      // Réconciliation idempotente + fail-safe : le SIREN attesté vient de
      // `GET /v1.beta/companies/me` (`oauth2_sessions/me` n'expose pas de
      // SIREN). Mismatch + factures → blocage ; mismatch sans facture →
      // réconciliation + réinitialisation infos entreprise (Option B).
      // Non-bloquant pour le callback (ADR-009 D2).
      try {
        const company = await app.paDriver.getConnectedCompany({
          accessToken: tokens.accessToken,
        });
        const reconcile = await reconcileCustomerIdentity({
          sql: app.sql,
          customerId: payload.customer_id,
          company,
        });
        if (reconcile.status === "reconciled") sirenOutcome = "reconciled";
        else if (reconcile.status === "blocked") {
          sirenOutcome = "blocked";
          // ADR-017 D5 / finding F recette Sc.7.5 — déconnexion programmatique
          // PA sur blocage SIREN historique. Le SIREN attesté KYC diverge du
          // SIREN ayant déjà émis/reçu des factures : la réforme interdit le
          // changement (intégrité archivage 10 ans + CDAR). On retire la
          // pa_connection tout juste créée pour ne pas afficher "Connecté" en
          // coexistence avec l'Alert bloquante et écarter tout risque
          // d'émission cross-identité. Recours user : nouveau compte OU
          // suppression de l'historique puis re-connexion. Best-effort
          // revoke + secret cleanup (mêmes invariants que /disconnect,
          // ADR-005 D10) — la soft-delete locale est la garantie load-bearing.
          const blockedConn = await paRepo.findActivePaConnectionForDisconnectByCustomerId(
            app.sqlRead,
            payload.customer_id,
          );
          if (blockedConn !== undefined) {
            await app.secrets.delete(blockedConn.secret_ref).catch(() => undefined);
            await app.paDriver.revoke({ refreshToken: tokens.refreshToken }).catch(() => undefined);
            await paRepo.markPaConnectionRevoked(app.sql, blockedConn.id);
          }
          await writeAuthAudit(app.sql, {
            event_type: "pa_connection_blocked_cleanup",
            success: true,
            user_id: payload.user_id,
            customer_id: payload.customer_id,
            ip: req.ip,
            user_agent: req.headers["user-agent"] ?? null,
            metadata: {
              blocked_reason: "has_invoice_history",
              kyc_siren: reconcile.blocked?.kycSiren,
              customer_siren: reconcile.blocked?.customerSiren,
              invoices_emitted_count: reconcile.blocked?.emittedInvoices,
              invoices_received_count: reconcile.blocked?.receivedInvoices,
            },
          });
        }
      } catch (err) {
        app.log.warn(
          { err, customer_id: payload.customer_id },
          "[oauth/callback] siren reconciliation failed (non-blocking)",
        );
      }
    }

    // T-CL-PA-OWN-DIRECTORY-ENTRIES sprint-06 — résolution de l'adresse
    // Peppol ÉMETTEUR via les entrées PROPRES du compte
    // (`GET /v1.beta/directory_entries`, authentifié), PAS l'annuaire public
    // `french_directory` (qui sert au lookup de TIERS/acheteurs et ne
    // référence pas les comptes sandbox → cause du "en cours d'enregistrement"
    // persistant). Indépendant du SIREN → robuste après réconciliation.
    // Non-blocking (ADR-009 D2) : le job `enrich-customer-peppol-address`
    // retry en arrière-plan si l'appel échoue.
    try {
      const customer = await customersRepo.findActiveCustomerById(app.sqlRead, payload.customer_id);
      if (customer !== undefined) {
        const result = await app.paDriver.getOwnDirectoryEntries({
          accessToken: tokens.accessToken,
        });
        if (result.kind === "found_one_address" || result.kind === "found_multi_address") {
          const address =
            result.kind === "found_one_address" ? result.address : result.addresses[0];
          if (address !== undefined) {
            await customersRepo.updateCustomerDirectoryAddress(
              app.sql,
              payload.customer_id,
              address.party_id,
            );
            await writeAuthAudit(app.sql, {
              event_type:
                result.kind === "found_one_address"
                  ? "peppol_address_enrolled"
                  : "peppol_address_multi_selected",
              success: true,
              user_id: payload.user_id,
              customer_id: payload.customer_id,
              ip: req.ip,
              user_agent: req.headers["user-agent"] ?? null,
              metadata: { directory_address: address.party_id, kind: result.kind },
            });
          }
        } else {
          const auditEvent =
            result.kind === "not_found"
              ? "peppol_address_not_enrolled_yet"
              : result.kind === "disabled"
                ? "peppol_address_disabled"
                : "peppol_address_lookup_5xx";
          await writeAuthAudit(app.sql, {
            event_type: auditEvent,
            success: false,
            user_id: payload.user_id,
            customer_id: payload.customer_id,
            ip: req.ip,
            user_agent: req.headers["user-agent"] ?? null,
            metadata: { kind: result.kind },
          });
          // Schedule first retry à T+5min (backoff initial du job).
          await customersRepo.bumpCustomerPeppolRetry(
            app.sql,
            payload.customer_id,
            new Date(Date.now() + 5 * 60 * 1000),
          );
        }
      }
    } catch (err) {
      app.log.warn(
        { err, customer_id: payload.customer_id },
        "[oauth/callback] peppol address lookup failed (non-blocking, job retry will handle)",
      );
      await writeAuthAudit(app.sql, {
        event_type: "peppol_address_lookup_5xx",
        success: false,
        user_id: payload.user_id,
        customer_id: payload.customer_id,
        ip: req.ip,
        user_agent: req.headers["user-agent"] ?? null,
        metadata: { error: err instanceof Error ? err.message : "unknown" },
      });
      await customersRepo
        .bumpCustomerPeppolRetry(app.sql, payload.customer_id, new Date(Date.now() + 5 * 60 * 1000))
        .catch(() => undefined);
    }

    reply.clearCookie(OAUTH_STATE_COOKIE, clearOAuthStateCookieOptions());

    // Map the identity status to the SPA query param. Blocage SIREN
    // historique (finding F) → `disconnected` : la pa_connection a été
    // retirée programmatiquement, la SPA ne doit pas afficher "Connexion
    // active" (le subtitle s'appuie sur ce param) — seule l'Alert bloquante
    // `siren=blocked` reste visible.
    const uiStatus =
      sirenOutcome === "blocked"
        ? ("disconnected" as const)
        : identity.user === "rejected" || identity.company === "rejected"
          ? "rejected"
          : identity.user === "needs_review" || identity.company === "needs_review"
            ? "needs_review"
            : "connected";

    return reply
      .code(302)
      .header("location", paConnectionUiUrl({ status: uiStatus, siren: sirenOutcome }))
      .send();
  });
}
