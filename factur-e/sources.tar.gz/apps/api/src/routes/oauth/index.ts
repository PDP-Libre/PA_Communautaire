import type { FastifyInstance } from "fastify";

import { registerOAuthAuthorizeRoute } from "./authorize.js";
import { registerOAuthAuthorizeInitRoute } from "./authorize-init.js";
import { registerOAuthCallbackRoute } from "./callback.js";
import { registerOAuthDisconnectRoute } from "./disconnect.js";

export function registerOAuthRoutes(app: FastifyInstance): void {
  registerOAuthAuthorizeRoute(app);
  registerOAuthAuthorizeInitRoute(app);
  registerOAuthCallbackRoute(app);
  registerOAuthDisconnectRoute(app);
}
