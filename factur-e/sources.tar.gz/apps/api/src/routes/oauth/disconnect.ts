import type { FastifyInstance } from "fastify";

import { writeAuthAudit } from "../../auth/audit.js";
import { resolveAuthContext } from "../../auth/context.js";
import * as paRepo from "../../db/repos/pa_connections.js";
import * as usersRepo from "../../db/repos/users.js";

/**
 * `POST /oauth/superpdp/disconnect` — user-initiated disconnect from
 * SuperPDP. RFC 7009 revoke + soft-delete + secret cleanup. Idempotent
 * (no active connection → 204 silently).
 *
 * Auth Bearer + role=`full` (US-PA-001 disconnect symmetry).
 *
 * Cf. ADR-005 D10, plan T-CL-06 sprint-03.
 */
export function registerOAuthDisconnectRoute(app: FastifyInstance): void {
  app.post("/oauth/superpdp/disconnect", async (req, reply) => {
    const ctx = await resolveAuthContext(req);
    if (ctx.state !== "authenticated") {
      return reply.code(401).send({ message: "Authentification requise." });
    }
    const role = await usersRepo.findActiveUserRoleById(app.sqlRead, ctx.user_id);
    if (role?.role !== "full") {
      return reply.code(403).send({ message: "Permission insuffisante." });
    }

    const conn = await paRepo.findActivePaConnectionForDisconnectByCustomerId(
      app.sqlRead,
      ctx.customer_id,
    );
    if (conn === undefined) {
      // Idempotent — already disconnected (or never connected).
      return reply.code(204).send();
    }

    // Best-effort revoke. We DO NOT short-circuit on revoke failure —
    // the local soft-delete must succeed so the user sees the UI move
    // to "disconnected", and the partner-side cleanup is observable
    // via audit. Cf. ADR-005 D10 (idempotent RFC 7009).
    let revokeOk = true;
    const bundle = await app.secrets.get(conn.secret_ref).catch((err: unknown) => {
      app.log.error({ err }, "[oauth/disconnect] secrets.get failed");
      return null;
    });
    if (bundle !== null) {
      try {
        await app.paDriver.revoke({ refreshToken: bundle.refreshToken });
      } catch (err) {
        app.log.error({ err }, "[oauth/disconnect] driver.revoke failed");
        revokeOk = false;
      }
    }

    // Cleanup secret (idempotent). Continue even on failure (orphan secret
    // is harmless — picked up by manual rotation or expires naturally).
    await app.secrets.delete(conn.secret_ref).catch((err: unknown) => {
      app.log.error({ err }, "[oauth/disconnect] secrets.delete failed");
    });

    await paRepo.markPaConnectionRevoked(app.sql, conn.id);

    await writeAuthAudit(app.sql, {
      event_type: "pa_connection_disconnected",
      success: true,
      user_id: ctx.user_id,
      customer_id: ctx.customer_id,
      ip: req.ip,
      user_agent: req.headers["user-agent"] ?? null,
      metadata: { revoke_ok: revokeOk, pa_code: "superpdp" },
    });

    return reply.code(204).send();
  });
}
