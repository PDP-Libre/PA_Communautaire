import type { FastifyInstance } from "fastify";

import { prepareOAuthAuthorize } from "./authorize.js";

/**
 * `POST /oauth/superpdp/authorize-init` — variante JSON du GET 302.
 *
 * Pourquoi (T-CL-08 sprint-03 différé D4) : la SPA en cross-origin
 * (5174 → 3001) ne peut pas faire `window.location.href` vers le GET
 * 302 parce que les redirections navigateur ne portent pas le header
 * `Authorization: Bearer`. Cette variante POST :
 *
 *  1. accepte le Bearer dans le header (XHR / fetch côté SPA),
 *  2. génère le challenge + set le cookie `oauth_state` côté API,
 *  3. retourne `{ authorize_url }` en JSON.
 *
 * Le SPA fait ensuite `window.location.href = data.authorize_url` —
 * la redirection navigateur vers SuperPDP est externe (pas cross-origin
 * vers notre API), pas de problème Authorization.
 *
 * À reconsolider avec l'expert post-T-CL-08 : soit garder ce double
 * endpoint comme pattern propre, soit accepter le cookie `_session`
 * sur le GET 302 pour éliminer la duplication.
 */
export function registerOAuthAuthorizeInitRoute(app: FastifyInstance): void {
  app.post("/oauth/superpdp/authorize-init", async (req, reply) => {
    const prep = await prepareOAuthAuthorize(app, req, reply);
    if (prep.kind === "denied") return prep.reply;
    return reply.code(200).send({ authorize_url: prep.authorizeUrl });
  });
}
