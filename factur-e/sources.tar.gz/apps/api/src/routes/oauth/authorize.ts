import type { FastifyInstance, FastifyReply, FastifyRequest } from "fastify";

import { resolveAuthContext } from "../../auth/context.js";
import {
  OAUTH_STATE_COOKIE,
  oauthStateCookieOptions,
  signOAuthStateToken,
} from "../../auth/oauth-state.js";
import { writeAuthAudit } from "../../auth/audit.js";
import * as usersRepo from "../../db/repos/users.js";
import { superpdpRedirectUri } from "../../pa/secret-ref.js";

/**
 * `GET /oauth/superpdp/authorize` — initiate the OAuth dance with SuperPDP.
 *
 * Flow :
 *  1. Auth Bearer required, role=`full` (US-PA-001).
 *  2. Driver builds the URL + PKCE verifier + CSRF state.
 *  3. We sign a 5-min cookie (HttpOnly Lax Path=/oauth/superpdp/) with
 *     {state, code_verifier, customer_id, user_id, pa_code} so the
 *     callback can resume even if the main session expired during the
 *     SuperPDP tunnel (5–10 min).
 *  4. Audit `pa_connection_authorized` + 302 to SuperPDP.
 *
 * Cf. ADR-005 D1, plan T-CL-06 sprint-03.
 *
 * T-CL-08 sprint-03 (différé D4) : la SPA ne peut pas suivre ce GET en
 * `window.location.href = ...` parce qu'une redirection cross-origin ne
 * porte pas le header `Authorization`. La SPA appelle donc
 * `POST /oauth/superpdp/authorize-init` (cf. `authorize-init.ts`) qui
 * réutilise le même helper et retourne l'URL en JSON. À reconsolider
 * avec l'expert post-T-CL-08 (option : accepter le cookie `_session`
 * sur ce GET pour éliminer le double endpoint).
 */
export function registerOAuthAuthorizeRoute(app: FastifyInstance): void {
  app.get("/oauth/superpdp/authorize", async (req, reply) => {
    const prep = await prepareOAuthAuthorize(app, req, reply);
    if (prep.kind === "denied") return prep.reply;
    return reply.code(302).header("location", prep.authorizeUrl).send();
  });
}

/**
 * Helper exposé pour `authorize-init.ts` (T-CL-08). Effectue l'auth, le
 * role check, l'appel driver, le set-cookie et l'audit. Le caller
 * choisit comment répondre (302 redirect vs 200 JSON).
 *
 * Retourne `{ kind: "ok", authorizeUrl }` quand tout est OK ; sinon
 * `{ kind: "denied", reply }` où `reply` est déjà `.code(...).send(...)`
 * — le caller doit le retourner tel quel.
 */
export async function prepareOAuthAuthorize(
  app: FastifyInstance,
  req: FastifyRequest,
  reply: FastifyReply,
): Promise<{ kind: "ok"; authorizeUrl: string } | { kind: "denied"; reply: FastifyReply }> {
  const ctx = await resolveAuthContext(req);
  if (ctx.state !== "authenticated") {
    return {
      kind: "denied",
      reply: reply.code(401).send({ message: "Authentification requise." }),
    };
  }
  const role = await usersRepo.findActiveUserRoleById(app.sqlRead, ctx.user_id);
  if (role?.role !== "full") {
    return { kind: "denied", reply: reply.code(403).send({ message: "Permission insuffisante." }) };
  }

  let challenge;
  try {
    challenge = await app.paDriver.authorize({
      customerId: ctx.customer_id,
      redirectUri: superpdpRedirectUri(),
    });
  } catch (err) {
    app.log.error({ err }, "[oauth/authorize] driver.authorize failed");
    await writeAuthAudit(app.sql, {
      event_type: "pa_connection_authorized",
      success: false,
      user_id: ctx.user_id,
      customer_id: ctx.customer_id,
      ip: req.ip,
      user_agent: req.headers["user-agent"] ?? null,
      metadata: { reason: "driver_unavailable" },
    });
    return {
      kind: "denied",
      reply: reply.code(503).send({ message: "Plateforme Agréée momentanément indisponible." }),
    };
  }

  const stateToken = await signOAuthStateToken({
    state: challenge.state,
    code_verifier: challenge.codeVerifier,
    customer_id: ctx.customer_id,
    user_id: ctx.user_id,
    pa_code: "superpdp",
  });
  reply.setCookie(OAUTH_STATE_COOKIE, stateToken, oauthStateCookieOptions());

  await writeAuthAudit(app.sql, {
    event_type: "pa_connection_authorized",
    success: true,
    user_id: ctx.user_id,
    customer_id: ctx.customer_id,
    ip: req.ip,
    user_agent: req.headers["user-agent"] ?? null,
  });

  return { kind: "ok", authorizeUrl: challenge.authorizeUrl };
}
