import type { FastifyInstance, FastifyReply, FastifyRequest } from "fastify";

import { writeAuthAudit } from "../../auth/audit.js";

/**
 * `POST /api/v1/webhooks/pa` — endpoint webhook PA **désactivé V1**
 * (T-CL-PA-INVOICE-FIX sprint-04, ADR-010 v2 + ADR-011 + ADR-012 D8).
 *
 * Justification de la désactivation :
 *  - **SuperPDP API propriétaire** (ADR-010 v2) ne livre pas de
 *    mécanisme webhook côté `/v1.beta/*`. Le cycle de vie facture est
 *    consommé exclusivement via polling cursor global Stripe-like
 *    `GET /v1.beta/invoice_events?starting_after_id=` (D4).
 *  - **EsaLink** (ADR-011 D7) est pull-only — pas de webhook côté
 *    Hubtimize pour l'instant.
 *
 * Route conservée (pas supprimée) pour 2 raisons :
 *  1. **URL stable** : si SuperPDP envoie quand même un webhook (legacy
 *     T-CL-PA-EXT mergée avant le pivot Option D, ou config résiduelle),
 *     on lui répond 503 explicite plutôt qu'un 404 silencieux.
 *  2. **Forward-compat V2** : si SuperPDP propriétaire ou EsaLink livre
 *     un webhook signé HMAC en V2, on réactivera ce handler en
 *     consommant le helper `verifyWebhookSignature` (`pa-adapter/webhook.ts`)
 *     toujours présent dormant.
 *
 * Audit `pa_webhook_received_but_disabled` émis sur chaque appel pour
 * détecter les requêtes résiduelles côté observabilité (ADR-009 D5).
 *
 * cf. plan.md sprint-04 + trace.md T-CL-PA-INVOICE-FIX.
 */

const ROUTE_PATH = "/api/v1/webhooks/pa";
const DISABLED_REASON_MESSAGE =
  "Webhook entrant désactivé V1 (polling cursor unique canal SuperPDP + EsaLink pull-only). Voir ADR-010 v2 D4 + ADR-011 D7.";

export function registerPaWebhookRoute(app: FastifyInstance): void {
  app.post(ROUTE_PATH, async (req: FastifyRequest, reply: FastifyReply) => {
    // Audit best-effort — on capture le minimum d'info (ip, signature
    // header présence) pour détecter d'éventuelles requêtes résiduelles.
    // Pas de parsing du body : route désactivée, on ne consomme pas le
    // contenu.
    const sigHeader = req.headers["x-superpdp-signature"];
    const hasSignature = typeof sigHeader === "string" && sigHeader !== "";
    // Audit best-effort — ne doit pas faire échouer la réponse 503
    // (ADR-009 D5 : audit trail observability, pas critical path).
    try {
      await writeAuthAudit(app.sql, {
        event_type: "pa_webhook_received_but_disabled",
        success: false,
        ip: req.ip,
        metadata: {
          path: ROUTE_PATH,
          had_signature_header: hasSignature,
          user_agent: req.headers["user-agent"] ?? null,
        },
      });
    } catch (err) {
      app.log.warn({ err }, "[webhook-pa-disabled] audit write failed (non-blocking)");
    }
    return reply.code(503).send({
      error: "webhook_disabled_v1",
      message: DISABLED_REASON_MESSAGE,
    });
  });
}
