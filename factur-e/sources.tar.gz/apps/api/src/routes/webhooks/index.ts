import type { FastifyInstance } from "fastify";

import { registerPaWebhookRoute } from "./pa.js";

export function registerWebhookRoutes(app: FastifyInstance): void {
  registerPaWebhookRoute(app);
}
