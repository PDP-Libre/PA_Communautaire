# Smoke tests sandbox SuperPDP — opt-in

Tests d'intégration **réels** contre `api.superpdp.tech` — opt-in via `SANDBOX_SMOKE=true`. Par défaut, tous les `it()` sont skippés silencieusement (CI standard verte sans rien faire).

## Rationale

T-CL-PA-SANDBOX-SMOKE sprint-04. Post-validation du refactor `SuperPDPDriver` (T-CL-PA-INVOICE-FIX, paths `/v1.beta/invoices` + `/v1.beta/invoice_events` + mapping enum 47 → 17) face au serveur réel — attrape les divergences entre nos types TS et le comportement runtime (parsing surprise, codes erreur inattendus, drift de spec partenaire SuperPDP).

Les tests unitaires `apps/api/tests/integration/superpdp-driver-*.test.ts` couvrent déjà le contrat avec `fakeSuperPdp`. Ces smoke tests vérifient en plus que `fakeSuperPdp` ne diverge pas du vrai serveur, et détectent les changements de spec côté SuperPDP entre 2 sprints.

## Dérogation CLAUDE.md §11.3

CLAUDE.md §11.3 interdit "tout appel HTTP vers un service externe depuis un test". Cette dérogation est **explicitement actée** par le brief T-CL-PA-SANDBOX-SMOKE :
- isolation dans `apps/api/tests/sandbox/` (un seul fichier);
- opt-in `SANDBOX_SMOKE=true`, skippé par défaut;
- secrets Keychain dev en local, variables CI/CD GitLab masked en pipeline (jamais dans le code);
- pas d'envoi Peppol réel (sandbox SuperPDP isolée).

## Prérequis

1. T-CL-PA-INVOICE-FIX mergée sur `main` (signatures `SuperPDPDriver` refactorées + types).
2. Secrets Keychain dev provisionnés (local) :
   ```bash
   security add-generic-password -a factur-e -s superpdp-sandbox-client-id -w
   security add-generic-password -a factur-e -s superpdp-sandbox-client-secret -w
   ```
   En CI ces credentials sont fournis via les variables d'env
   `SUPERPDP_SANDBOX_CLIENT_ID` / `SUPERPDP_SANDBOX_CLIENT_SECRET` (lues en
   priorité ; fallback Keychain `security` uniquement en local macOS).
3. PDF Factur-X test généré :
   ```bash
   pnpm factur-x:generate-sample
   ```
4. Réseau Internet (api.superpdp.tech joignable, IP non bloquée).

## Exécution

```bash
cd ~/Projet_PDP/factur-e/src/factur-e
source ~/.nvm/nvm.sh && nvm use   # Node 22 LTS via .nvmrc
SANDBOX_SMOKE=true pnpm --filter @factur-e/api test:sandbox
```

Ou équivalent direct :

```bash
SANDBOX_SMOKE=true pnpm --filter @factur-e/api test -- tests/sandbox/
```

## Variables d'environnement

| Variable | Default | Description |
|---|---|---|
| `SANDBOX_SMOKE` | `(non défini → skip)` | `true` pour exécuter les tests. |
| `SUPERPDP_SANDBOX_CLIENT_ID` | `(fallback Keychain `superpdp-sandbox-client-id`)` | Client ID OAuth sandbox. Lu en priorité depuis l'env (CI). |
| `SUPERPDP_SANDBOX_CLIENT_SECRET` | `(fallback Keychain `superpdp-sandbox-client-secret`)` | Client secret OAuth sandbox. Lu en priorité depuis l'env (CI). |
| `SUPERPDP_BASE_URL` | `https://api.superpdp.tech` | Override pour pointer une autre instance SuperPDP. |
| `FACTURX_PDF_PATH` | `packages/factur-x-builder/samples/extended-ctc-fr-sample-001.pdf` | Chemin du PDF Factur-X de test (régénéré par `pnpm factur-x:generate-sample`). |

## Intégration CI — nightly (sprint-06 T-CL-CI-E2E-SUPERPDP-SANDBOX)

Job `test:sandbox:smoke` dans `.gitlab-ci.yml` (stage `test`). Déclenché
**uniquement** sur les pipelines planifiés (`rules: $CI_PIPELINE_SOURCE ==
"schedule"`) — zéro coût/latence sur les pushes et MRs. `allow_failure: true`
(sandbox externe : flakiness réseau et dedup PDF tolérés, l'échec alerte sans
bloquer). Le job régénère le sample (`pnpm factur-x:generate-sample`) puis lance
`pnpm --filter @factur-e/api test:sandbox`.

Planification : GitLab → Settings → CI/CD → Schedules, cron `0 3 * * *` UTC.
Variables `SUPERPDP_SANDBOX_CLIENT_ID` + `SUPERPDP_SANDBOX_CLIENT_SECRET` à
configurer (masked + protected) dans Settings → CI/CD → Variables. Grant
`client_credentials` → pas de refresh token requis. Cf. `docs/operations/ci.md`.

## Quand lancer

- **Post-merge T-CL-PA-INVOICE-FIX** — validation contre sandbox réelle après refactor du driver.
- **Pré-promotion T-BR-EMIT staging** — checkpoint avant cutover.
- **1× par sprint** si on veut détecter un drift SuperPDP côté serveur.
- **Sur alerte `pa_status_code_unmapped` > 0** en prod — vérifier en sandbox quels nouveaux raw codes apparaissent (cf. cas D3).

## Couverture — 10 cas (5 catégories)

| Cas | Endpoint / méthode | Vérifie |
|---|---|---|
| **A1** | `POST /oauth2/token` `grant_type=client_credentials` (fetch direct) | Token opaque, `expires_in ~1800s`, `scope=""`, pas de `refresh_token`. |
| **A2** | `GET /v1.beta/companies/me` (fetch direct) | Compte sandbox Burger Queen (`formal_name`, `env`, `number_scheme`). |
| **B1** | `driver.searchSiren({siren: '000000002'})` | Annuaire — assertion souple (kind ∈ union légitime). |
| **B2** | `driver.searchSiren({siren: '999999999'})` | `kind === 'not_found'`. |
| **C1** | `driver.submitInvoice({disablePreCheck: true})` | `InvoiceRejectedXsdException` — validation structurelle BT-34 hard non bypassable. |
| **C2** | `driver.submitInvoice` 2× même `trackingId` | Cohérence type d'erreur + `detail` (idempotence sur rejet 400). |
| **C3** | `driver.submitInvoice({disablePreCheck: false})` | `InvoiceRejectedXsdException` — Schematron BR-FR ou structurel. |
| **D1** | `driver.pollCdarEvents({cursor: '0', limit: 10})` | Batch events parsés, `nextCursor` numérique, mapping enum valide. |
| **D2** | `driver.pollCdarEvents` — fallback invoice arbitraire | Au moins 1 invoice avec pipeline ≥ 2 events dont `submitted`/`validated`. |
| **D3** | `driver.pollCdarEvents` — mapping forward-compat | Codes `'unknown'` loggés en `console.warn` (pas d'échec — ADR-012 D7). |
| **E1** | `POST /v1.beta/validation_reports` multipart (fetch direct) | 3 subreports (XSD + Factur-X + BR-FR). |

## Limitation actuelle — PDF sample non conforme

Historiquement le PDF `extended-sample-001.pdf` ne contenait pas BT-34/BT-49 (Seller.ElectronicAddress) : la validation structurelle SuperPDP hard rejette en 400 même avec `disable_pre_check=true` (cf. ADR-010 v2 D6). Conséquence possible : **C1 et C3 vérifient tous deux le rejet** plutôt que C1 happy + C3 rejet ; C2 vérifie la cohérence des 2 rejets plutôt qu'une idempotence d'un `paInvoiceId` stable. Les cas tolèrent les deux issues (happy path OU dedup/rejet).

→ **NOTE-COWORK (sprint-06 W1)** : le sample par défaut a été renommé `extended-ctc-fr-sample-001.input.ts` par T-CL-FACTURX-BUILDER-REFACTOR-CTC-FR. Sa conformité BT-34/BT-49 et son SIREN vendeur (compte sandbox Burger Queen `000000002`) sont **à re-confirmer par le premier run nightly** — c'est précisément le type de drift que ce job détecte.

## Effets de bord sandbox

- C1/C2/C3 POSTent ~3 invoices sur sandbox compte Burger Queen sous `external_id=smoke-test-<uuid>`. Comme le sample rejette en 400, **SuperPDP ne stocke probablement aucune invoice** (rejets pré-stockage côté validation hard).
- Si C1 commence à produire des invoices créées (sample devenu conforme), SuperPDP n'expose pas `DELETE /v1.beta/invoices/{id}` côté propriétaire → invoices restent en sandbox (pas de fuite cross-tenant, sandbox isolée).
- Pas d'envoi Peppol réel (sandbox isolée, pas de routage destinataire).

## En cas d'échec

| Symptôme | Cause probable | Action |
|---|---|---|
| A1/A2 → `401` | Secrets Keychain KO ou rotated côté portail SuperPDP. | Reprovisionner via `security add-generic-password`. |
| Timeout > 30 s | Latence sandbox, rate limit non documenté, ou IP bloquée. | Réessayer ; espacer les cas avec `setTimeout` si récidive. |
| D2 → 0 invoice pipelined | Sandbox récemment réinitialisée ou compte sans events. | Demander à SuperPDP de seeder quelques invoices, ou skip ponctuellement. |
| D3 → warn « unknown raw codes » | Nouveau `status_code` SuperPDP non encore mappé. | Étendre `packages/pa-adapter/src/superpdp/map-status-code.ts` avec les codes listés. Pas un échec test. |
| E1 → `subreports.length !== 3` | Spec SuperPDP a évolué (nouveau validator ajouté/retiré). | Adapter l'assertion + signaler à l'équipe Cowork (drift partenaire). |
| C1 → succès au lieu de rejet | Sample PDF devenu conforme (BT-34 ajouté). | Renommer C1 en happy path, étendre l'assertion sur `paInvoiceId`. |
