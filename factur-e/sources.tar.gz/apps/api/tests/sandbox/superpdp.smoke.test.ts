import { spawn } from "node:child_process";
import { createHash, randomUUID } from "node:crypto";
import { readFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

import { beforeAll, describe, expect, it } from "vitest";

import {
  FACTUR_E_STATUS_CODES,
  PaProtocolException,
  SuperPDPDriver,
  type CdarEvent,
  type CustomerContext,
  type FacturEStatusCode,
  type SubmitInvoiceOutput,
} from "@factur-e/pa-adapter";

/**
 * T-CL-PA-SANDBOX-SMOKE sprint-04 — 10 mini tests d'intégration **opt-in**
 * contre la sandbox SuperPDP réelle (`api.superpdp.tech`). Post-validation
 * du refactor `SuperPDPDriver` livré par T-CL-PA-INVOICE-FIX (ADR-010 v2)
 * face au serveur réel — détecte les divergences entre nos types TS et le
 * comportement runtime (parsing surprise, codes erreur inattendus, drift
 * de spec partenaire).
 *
 * **Opt-in** : `SANDBOX_SMOKE=true` requis. Par défaut tous les `it()`
 * sont skippés (sandbox externe, secrets Keychain requis, latence ~30-60s,
 * appels HTTP réels qui contreviennent à CLAUDE.md §11.3 dans le cas
 * général mais sont explicitement autorisés ici via cette mécanique opt-in
 * et l'isolation dans `tests/sandbox/`).
 *
 * **Sample sandbox-compatible (T-CL-FACTURX-SAMPLE-FIX 2026-05-17 ;
 * renommé `extended-ctc-fr-sample-001` sprint-06 W1)** :
 * sample refondu pour matcher le compte sandbox
 * SuperPDP (seller SIREN 000000002 = Burger Queen, sinon SuperPDP rejette
 * en 400 « L'entreprise liée à cette session ne correspond pas au
 * vendeur »). BT-34/BT-49 portent les adresses Peppol sandbox
 * (`0225:315143296_3686` Burger Queen, `0225:315143296_3685` Tricatel).
 * veraPDF 146/146 préservé, validation_reports SuperPDP `is_valid: true`
 * (7 warnings BR-FR non bloquants).
 *
 * **Dedup contenu SuperPDP** : SuperPDP dedup les POSTs sur hash du PDF.
 * Le sample étant statique, un 1er POST de la sandbox CI/CD retourne 200
 * OK avec un `paInvoiceId` frais ; les POSTs suivants (même contenu)
 * retournent 400 « La facture est déjà existante (id N) » → mappé en
 * `PaProtocolException` côté driver (ADR-010 v2 D5 catch-all 400). C1/C2/C3
 * acceptent les 2 outcomes (happy path OU dedup déjà existante) — les 2
 * démontrent que SuperPDP accepte la structure du sample. NOTE-COWORK
 * pour T-CL-FACTURX-SAMPLE-FIX-BIS : générer un PDF avec invoiceNumber
 * runtime-randomized pour garantir un happy path déterministe.
 *
 * **Effets de bord** : C1/C2/C3 POSTent des invoices sur sandbox Burger
 * Queen. La 1ère exécution stocke 1 invoice sandbox, les suivantes
 * retombent sur le dedup. Pas d'envoi Peppol (sandbox isolée).
 *
 * cf. brief T-CL-PA-SANDBOX-SMOKE sprint-04, brief T-CL-FACTURX-SAMPLE-FIX
 *     sprint-04, ADR-010 v2 D3/D4/D5/D6, ADR-012 D2/D7, ADR-009 D1.
 */

const SANDBOX_ENABLED = process.env.SANDBOX_SMOKE === "true";
const SUPERPDP_BASE = process.env.SUPERPDP_BASE_URL ?? "https://api.superpdp.tech";
// Chemin relatif au worktree courant (pas au repo main) — `__dirname`
// équivalent ESM via import.meta.url. Sinon les worktrees ne testent pas
// les modifs locales du sample.
const SMOKE_DIR = dirname(fileURLToPath(import.meta.url));
const FACTURX_PDF_PATH =
  process.env.FACTURX_PDF_PATH ??
  resolve(
    SMOKE_DIR,
    "..",
    "..",
    "..",
    "..",
    "packages",
    "factur-x-builder",
    "samples",
    // Sprint-06 W1 T-CL-FACTURX-BUILDER-REFACTOR-CTC-FR a renommé le sample
    // par défaut `extended-sample-001` → `extended-ctc-fr-sample-001` (profil
    // émission V2). Le PDF n'est pas versionné : `pnpm factur-x:generate-sample`
    // le régénère à côté de l'input (cf. CI job test:sandbox:smoke + README).
    "extended-ctc-fr-sample-001.pdf",
  );

const SMOKE_TIMEOUT_MS = 30_000;
const BURGER_QUEEN_SIREN = "000000002";
const UNKNOWN_SIREN = "999999999";

interface ClientCredentialsTokenResponse {
  access_token: string;
  expires_in: number;
  scope: string;
  token_type: string;
  refresh_token?: string;
}

interface CompaniesMeResponse {
  id: number;
  env: string;
  number_scheme: string;
  number: string;
  formal_name: string;
}

interface ValidationReportSubreport {
  validator: string;
  checks_count: number;
  messages: { message: string }[];
  failures: unknown[];
}

interface ValidationReportEntry {
  file_name: string;
  is_valid: boolean;
  format: string;
  conformance_level?: string;
  subreports: ValidationReportSubreport[];
}

interface ValidationReportResponse {
  data: ValidationReportEntry[];
}

/** Lit un secret Keychain via `security find-generic-password -a factur-e
 *  -s <service> -w`. Helper interne au test (scope local — pas d'export). */
async function readKeychainSecret(service: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const child = spawn("security", [
      "find-generic-password",
      "-a",
      "factur-e",
      "-s",
      service,
      "-w",
    ]);
    let out = "";
    let err = "";
    child.stdout.on("data", (chunk: Buffer) => {
      out += chunk.toString("utf8");
    });
    child.stderr.on("data", (chunk: Buffer) => {
      err += chunk.toString("utf8");
    });
    child.on("error", reject);
    child.on("close", (code) => {
      if (code === 0) {
        resolve(out.trim());
        return;
      }
      reject(
        new Error(`Keychain '${service}' lookup failed (exit ${String(code)}): ${err.trim()}`),
      );
    });
  });
}

/** Lit un secret sandbox : variable d'env d'abord (CI GitLab — le Keychain
 *  macOS n'existe pas sur un runner Linux), fallback Keychain en dev local
 *  (cf. CLAUDE.md §11.1, convention `-a factur-e -s <service>`). */
async function readSandboxSecret(envName: string, keychainService: string): Promise<string> {
  const fromEnv = process.env[envName];
  if (fromEnv !== undefined && fromEnv.length > 0) {
    return fromEnv;
  }
  return readKeychainSecret(keychainService);
}

async function getSuperPDPClientCredentials(): Promise<{ clientId: string; clientSecret: string }> {
  const [clientId, clientSecret] = await Promise.all([
    readSandboxSecret("SUPERPDP_SANDBOX_CLIENT_ID", "superpdp-sandbox-client-id"),
    readSandboxSecret("SUPERPDP_SANDBOX_CLIENT_SECRET", "superpdp-sandbox-client-secret"),
  ]);
  return { clientId, clientSecret };
}

/** Fetch direct sur `POST /oauth2/token` avec `grant_type=client_credentials`.
 *  Le `SuperPDPDriver` n'expose pas de méthode publique pour CC (le flow
 *  V1 cœur est Authorization Code per-customer, cf. ADR-005), donc smoke
 *  tests `A1/A2/E1` font fetch direct plutôt que d'amender l'interface
 *  juste pour ces 3 cas. Arbitrage Bruno 2026-05-17. */
async function fetchClientCredentialsToken(
  baseUrl: string,
  clientId: string,
  clientSecret: string,
): Promise<ClientCredentialsTokenResponse> {
  const body = new URLSearchParams({
    grant_type: "client_credentials",
    client_id: clientId,
    client_secret: clientSecret,
  });
  const res = await fetch(`${baseUrl}/oauth2/token`, {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body: body.toString(),
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`OAuth Client Credentials failed (status ${String(res.status)}): ${text}`);
  }
  return (await res.json()) as ClientCredentialsTokenResponse;
}

describe.skipIf(!SANDBOX_ENABLED)("SuperPDP sandbox smoke (opt-in SANDBOX_SMOKE)", () => {
  let driver: SuperPDPDriver;
  let clientId: string;
  let clientSecret: string;
  let accessToken: string;
  let tokenExpiresInSec: number;
  let pdfBytes: Buffer;
  let ctx: CustomerContext;

  const baseTrackingId = `smoke-test-${randomUUID()}`;

  beforeAll(async () => {
    const creds = await getSuperPDPClientCredentials();
    clientId = creds.clientId;
    clientSecret = creds.clientSecret;

    const token = await fetchClientCredentialsToken(SUPERPDP_BASE, clientId, clientSecret);
    accessToken = token.access_token;
    tokenExpiresInSec = token.expires_in;

    pdfBytes = await readFile(FACTURX_PDF_PATH);

    driver = new SuperPDPDriver({
      clientId,
      clientSecret,
      baseUrl: SUPERPDP_BASE,
    });

    ctx = {
      customerId: "smoke-test",
      credentials: {
        kind: "superpdp-oauth-cc",
        accessToken,
        accessExpiresAt: new Date(Date.now() + tokenExpiresInSec * 1000),
      },
    };
  }, SMOKE_TIMEOUT_MS);

  // ───────────────────────────────────────────────────────────────────
  // Catégorie A — Auth + identity
  // ───────────────────────────────────────────────────────────────────

  it(
    "A1: POST /oauth2/token grant=client_credentials retourne token opaque ~30 min sans refresh",
    { timeout: SMOKE_TIMEOUT_MS },
    async () => {
      const token = await fetchClientCredentialsToken(SUPERPDP_BASE, clientId, clientSecret);
      expect(token.access_token).toMatch(/^[A-Za-z0-9_-]+$/);
      expect(token.access_token.length).toBeGreaterThan(20);
      expect(token.token_type.toLowerCase()).toBe("bearer");
      expect(token.scope).toBe("");
      expect(token.expires_in).toBeGreaterThan(1700);
      expect(token.expires_in).toBeLessThan(1900);
      expect(token.refresh_token).toBeUndefined();
    },
  );

  it(
    "A2: GET /v1.beta/companies/me retourne le compte sandbox Burger Queen",
    { timeout: SMOKE_TIMEOUT_MS },
    async () => {
      const res = await fetch(`${SUPERPDP_BASE}/v1.beta/companies/me`, {
        method: "GET",
        headers: {
          authorization: `Bearer ${accessToken}`,
          accept: "application/json",
        },
      });
      expect(res.status).toBe(200);
      const body = (await res.json()) as CompaniesMeResponse;
      expect(body.formal_name).toBe("Burger Queen");
      expect(body.env).toBe("sandbox");
      expect(body.number_scheme).toBe("sandbox");
      expect(body.number).toBe(BURGER_QUEEN_SIREN);
    },
  );

  // ───────────────────────────────────────────────────────────────────
  // Catégorie B — Annuaire propriétaire (T-CL-09 sprint-03)
  // ───────────────────────────────────────────────────────────────────

  it(
    `B1: searchSiren ${BURGER_QUEEN_SIREN} (Burger Queen) — assertion souple sur kind`,
    { timeout: SMOKE_TIMEOUT_MS },
    async () => {
      const result = await driver.searchSiren({ siren: BURGER_QUEEN_SIREN }, ctx);
      // Assertion souple — l'annuaire `french_directory` sandbox SuperPDP
      // n'expose pas forcément le compte Burger Queen lui-même. On vérifie
      // juste que le driver retourne un kind valide de l'union
      // `DirectorySearchResult` sans crasher.
      expect([
        "found_one_address",
        "found_multi_address",
        "not_found",
        "disabled",
        "unavailable",
      ]).toContain(result.kind);
      if (result.kind === "found_one_address" || result.kind === "found_multi_address") {
        expect(result.company.number).toBe(BURGER_QUEEN_SIREN);
        // eslint-disable-next-line no-console
        console.info(`[smoke B1] Burger Queen found in directory: ${result.company.formal_name}`);
      } else {
        // eslint-disable-next-line no-console
        console.info(
          `[smoke B1] NOTE-COWORK: SIREN ${BURGER_QUEEN_SIREN} returned kind='${result.kind}' — sandbox directory probably doesn't list the test account itself. Provision a dedicated test SIREN for B1 happy path if needed.`,
        );
      }
    },
  );

  it(
    `B2: searchSiren ${UNKNOWN_SIREN} (inexistant) retourne not_found`,
    { timeout: SMOKE_TIMEOUT_MS },
    async () => {
      const result = await driver.searchSiren({ siren: UNKNOWN_SIREN }, ctx);
      expect(result.kind).toBe("not_found");
    },
  );

  // ───────────────────────────────────────────────────────────────────
  // Catégorie C — Émission (POST /v1.beta/invoices body PDF direct)
  //
  // Post-T-CL-FACTURX-SAMPLE-FIX : le sample est désormais sandbox-
  // compatible (seller SIREN 000000002 Burger Queen + BT-34/BT-49 Peppol).
  // Le PDF est structurellement accepté par SuperPDP — donc soit happy
  // path 200 + paInvoiceId (1ère soumission de la sandbox), soit
  // PaProtocolException « La facture est déjà existante » (POSTs
  // suivants : dedup par hash contenu côté SuperPDP). Les 2 outcomes
  // démontrent la conformité structurelle du sample. NOTE-COWORK pour
  // T-CL-FACTURX-SAMPLE-FIX-BIS : générer un PDF avec invoiceNumber
  // runtime-randomized pour garantir un happy path déterministe à chaque
  // run et lever cette ambiguïté.
  // ───────────────────────────────────────────────────────────────────

  /** Helper local : asserte que la soumission a soit réussi (`paInvoiceId`
   *  retourné) soit échoué avec le dedup `PaProtocolException` « déjà
   *  existante ». Retourne le `paInvoiceId` observé pour log. */
  async function assertSubmitOkOrDedup(
    input: Parameters<SuperPDPDriver["submitInvoice"]>[0],
  ): Promise<{ paInvoiceId: string; via: "happy" | "dedup" }> {
    let result: SubmitInvoiceOutput | Error;
    try {
      result = await driver.submitInvoice(input, ctx);
    } catch (e) {
      result = e as Error;
    }
    if (result instanceof Error) {
      expect(result).toBeInstanceOf(PaProtocolException);
      expect(result.message).toMatch(/déjà existante/);
      // Extract id from message — pattern : « (id 53828) ».
      const match = /\(id (\d+)\)/.exec(result.message);
      if (match?.[1] === undefined) {
        throw new Error(`Expected '(id N)' pattern in dedup message, got: ${result.message}`);
      }
      return { paInvoiceId: match[1], via: "dedup" };
    }
    expect(result.paInvoiceId).toMatch(/^\d+$/);
    expect(result.status).toBe("submitted");
    expect(result.rawStatusCode).toBe("api:uploaded");
    return { paInvoiceId: result.paInvoiceId, via: "happy" };
  }

  it(
    "C1: submitInvoice disablePreCheck=true — sample accepté (happy path OU dedup)",
    { timeout: SMOKE_TIMEOUT_MS },
    async () => {
      const sha256 = createHash("sha256").update(pdfBytes).digest("hex");
      const out = await assertSubmitOkOrDedup({
        pdfBytes,
        trackingId: `${baseTrackingId}-c1`,
        sha256,
        processingRule: "B2B",
        profile: "EXTENDED",
        invoiceNumber: "SMOKE-C1",
        recipientPeppolId: "0225:315143296_3685",
        senderPeppolId: "0225:315143296_3686",
        disablePreCheck: true,
      });
      // eslint-disable-next-line no-console
      console.info(`[smoke C1] outcome=${out.via} paInvoiceId=${out.paInvoiceId}`);
    },
  );

  it(
    "C2: submitInvoice idempotence — 2 POSTs même trackingId → même paInvoiceId (happy ou dedup)",
    { timeout: SMOKE_TIMEOUT_MS },
    async () => {
      const sha256 = createHash("sha256").update(pdfBytes).digest("hex");
      const sameTrackingId = `${baseTrackingId}-c2`;
      const common = {
        pdfBytes,
        trackingId: sameTrackingId,
        sha256,
        processingRule: "B2B" as const,
        profile: "EXTENDED" as const,
        invoiceNumber: "SMOKE-C2",
        recipientPeppolId: "0225:315143296_3685",
        senderPeppolId: "0225:315143296_3686",
        disablePreCheck: true,
      };
      const out1 = await assertSubmitOkOrDedup(common);
      const out2 = await assertSubmitOkOrDedup(common);
      // Idempotence : même paInvoiceId quel que soit le path (happy 200
      // sur 1er, dedup sur 2e ; ou dedup sur les 2 si la sandbox a déjà
      // vu ce hash).
      expect(out2.paInvoiceId).toBe(out1.paInvoiceId);
    },
  );

  it(
    "C3: submitInvoice disablePreCheck=false — Schematron BR-FR passe (sample accepté happy ou dedup)",
    { timeout: SMOKE_TIMEOUT_MS },
    async () => {
      const sha256 = createHash("sha256").update(pdfBytes).digest("hex");
      const out = await assertSubmitOkOrDedup({
        pdfBytes,
        trackingId: `${baseTrackingId}-c3`,
        sha256,
        processingRule: "B2B",
        profile: "EXTENDED",
        invoiceNumber: "SMOKE-C3",
        recipientPeppolId: "0225:315143296_3685",
        senderPeppolId: "0225:315143296_3686",
        disablePreCheck: false,
      });
      // eslint-disable-next-line no-console
      console.info(`[smoke C3] outcome=${out.via} paInvoiceId=${out.paInvoiceId}`);
    },
  );

  // ───────────────────────────────────────────────────────────────────
  // Catégorie D — Polling CDAR (GET /v1.beta/invoice_events cursor)
  // ───────────────────────────────────────────────────────────────────

  it(
    "D1: pollCdarEvents cursor='0' retourne batch events parsés + nextCursor",
    { timeout: SMOKE_TIMEOUT_MS },
    async () => {
      const out = await driver.pollCdarEvents({ cursor: "0", limit: 10 }, ctx);
      expect(out.events.length).toBeGreaterThan(0);
      expect(out.nextCursor).toMatch(/^\d+$/);
      expect(typeof out.hasMore).toBe("boolean");
      for (const event of out.events) {
        expect(event.paEventId).toMatch(/^\d+$/);
        expect(event.paInvoiceId).toMatch(/^\d+$/);
        expect(typeof event.rawStatusCode).toBe("string");
        expect(event.rawStatusCode.length).toBeGreaterThan(0);
        expect(FACTUR_E_STATUS_CODES.has(event.status)).toBe(true);
        expect(typeof event.occurredAt).toBe("string");
        expect(new Date(event.occurredAt).toString()).not.toBe("Invalid Date");
      }
    },
  );

  it(
    "D2: pollCdarEvents — pipeline observable sur au moins une invoice (fallback : invoice arbitraire du batch)",
    { timeout: SMOKE_TIMEOUT_MS },
    async () => {
      // Fallback brief §3.4 : le sample PDF n'autorise pas la création
      // d'une invoice happy path en C1, donc on ne peut pas filtrer
      // sur l'invoice de C1. On groupe les events par paInvoiceId et
      // on vérifie qu'il existe au moins une invoice avec un pipeline
      // typique (au moins 2 events dont un rawStatusCode pré-transmission
      // mappé `submitted` ou `validated`).
      const out = await driver.pollCdarEvents({ cursor: "0", limit: 50 }, ctx);
      const eventsByInvoice = new Map<string, CdarEvent[]>();
      for (const event of out.events) {
        const list = eventsByInvoice.get(event.paInvoiceId) ?? [];
        list.push(event);
        eventsByInvoice.set(event.paInvoiceId, list);
      }
      const pipelinedInvoices = Array.from(eventsByInvoice.values()).filter((events) => {
        if (events.length < 2) return false;
        return events.some((e) => e.status === "submitted" || e.status === "validated");
      });
      expect(pipelinedInvoices.length).toBeGreaterThan(0);
    },
  );

  it(
    "D3: pollCdarEvents — mapping enum forward-compat ('unknown' n'échoue pas le test, log seulement)",
    { timeout: SMOKE_TIMEOUT_MS },
    async () => {
      const out = await driver.pollCdarEvents({ cursor: "0", limit: 50 }, ctx);
      const unknownEvents = out.events.filter(
        (e): e is CdarEvent & { status: FacturEStatusCode } => e.status === "unknown",
      );
      // Forward-compat ADR-012 D7 : un nouveau status_code SuperPDP non
      // encore mappé tombe sur 'unknown' sans crash. On log la liste des
      // raw codes pour pouvoir étendre `mapSuperPDPStatusCode` plus tard
      // — pas d'échec du test sur des codes inconnus.
      if (unknownEvents.length > 0) {
        const rawCodes = Array.from(new Set(unknownEvents.map((e) => e.rawStatusCode)));
        console.warn(
          `[smoke D3] NOTE-COWORK: ${String(unknownEvents.length)} event(s) mapped to 'unknown'. Raw codes to add to mapSuperPDPStatusCode: ${rawCodes.join(", ")}`,
        );
      }
      // Test passe quel que soit le nombre de 'unknown' — la seule
      // contrainte stricte est que le batch ne soit pas vide.
      expect(out.events.length).toBeGreaterThan(0);
    },
  );

  // ───────────────────────────────────────────────────────────────────
  // Catégorie E — Pré-validation
  // ───────────────────────────────────────────────────────────────────

  it(
    "E1: POST /v1.beta/validation_reports multipart retourne validation_report 3 subreports",
    { timeout: SMOKE_TIMEOUT_MS },
    async () => {
      const form = new FormData();
      form.append(
        "file_name",
        new Blob([new Uint8Array(pdfBytes)], { type: "application/pdf" }),
        "extended-sample-001.pdf",
      );
      const res = await fetch(`${SUPERPDP_BASE}/v1.beta/validation_reports`, {
        method: "POST",
        headers: {
          authorization: `Bearer ${accessToken}`,
          accept: "application/json",
        },
        body: form,
      });
      expect(res.status).toBe(200);
      const body = (await res.json()) as ValidationReportResponse;
      expect(body.data).toHaveLength(1);
      const report = body.data[0];
      if (report === undefined) throw new Error("validation_reports: data[0] undefined");
      expect(report.format).toContain("CrossIndustryInvoice");
      expect(report.subreports).toHaveLength(3);
      const validators = report.subreports.map((s) => s.validator);
      expect(validators.some((v) => v.includes("XSD") || v.includes("xsd"))).toBe(true);
      expect(validators.some((v) => v.includes("Factur-X") || v.includes("FACTUR-X"))).toBe(true);
      expect(validators.some((v) => v.includes("BR-FR"))).toBe(true);
    },
  );
});
