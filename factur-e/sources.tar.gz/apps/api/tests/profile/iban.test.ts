import { describe, expect, it } from "vitest";

import { isValidBic, isValidIban, maskIban, normalizeIban } from "../../src/profile/iban.js";

describe("isValidIban (MOD 97)", () => {
  it("accepts the canonical FR test IBAN", () => {
    // Test IBAN from ISO 13616 examples — MOD 97 valid by construction.
    expect(isValidIban("FR1420041010050500013M02606")).toBe(true);
  });

  it("accepts an IBAN written with spaces", () => {
    expect(isValidIban("FR14 2004 1010 0505 0001 3M02 606")).toBe(true);
  });

  it("rejects an IBAN with a flipped check digit", () => {
    // Same number, last digit changed → MOD 97 != 1.
    expect(isValidIban("FR1420041010050500013M02607")).toBe(false);
  });

  it("rejects strings outside [15, 34]", () => {
    expect(isValidIban("FR140")).toBe(false);
    expect(isValidIban("FR" + "1".repeat(40))).toBe(false);
  });

  it("rejects strings with invalid characters", () => {
    expect(isValidIban("FR14$#$#$#$#$#$#$")).toBe(false);
  });
});

describe("normalizeIban", () => {
  it("strips spaces and uppercases", () => {
    expect(normalizeIban("fr14 2004 1010 0505 0001 3m02 606")).toBe("FR1420041010050500013M02606");
  });
});

describe("maskIban (NC-3 affichage masqué)", () => {
  it("conserve code pays + clé + 4 derniers, masque le milieu par blocs de 4", () => {
    const masked = maskIban("FR1420041010050500013M02606");
    expect(masked.startsWith("FR14 ")).toBe(true);
    expect(masked.endsWith(" 2606")).toBe(true);
    // Aucun chiffre du milieu ne fuit (hors FR14 + 2606).
    expect(masked).not.toContain("2004");
    expect(masked).toContain("••••");
  });

  it("tolère les espaces en entrée (normalise avant masquage)", () => {
    expect(maskIban("FR14 2004 1010 0505 0001 3M02 606")).toBe(
      maskIban("FR1420041010050500013M02606"),
    );
  });

  it("retourne la valeur telle quelle si trop courte pour masquer", () => {
    expect(maskIban("FR1420")).toBe("FR1420");
  });
});

describe("isValidBic", () => {
  it("accepts an 8-char BIC", () => {
    expect(isValidBic("BNPAFRPP")).toBe(true);
  });
  it("accepts an 11-char BIC", () => {
    expect(isValidBic("BNPAFRPPXXX")).toBe(true);
  });
  it("rejects a 7-char BIC", () => {
    expect(isValidBic("BNPAFRP")).toBe(false);
  });
  it("rejects a BIC with non-alphanumeric chars", () => {
    expect(isValidBic("BNPA-FR-PP")).toBe(false);
  });
});
