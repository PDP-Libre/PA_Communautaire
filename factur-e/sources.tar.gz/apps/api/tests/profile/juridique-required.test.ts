import { describe, expect, it } from "vitest";

import { capitalRequiredFor } from "@factur-e/shared-schemas";

/**
 * T-CL-WEB-EMIT-CAPITAL-SOCIAL sprint-06 W1 — couverture des 35 codes INSEE
 * recensés (Code de commerce L210-2/L223-2/L227-1/L210-3) + non-requérants.
 * Le helper a été extrait de `apps/api/src/profile/juridique-required.ts`
 * vers `shared-schemas` (source unique consommée par l'API et le form web).
 */

// Les 35 codes `categorieJuridiqueUniteLegale` qui exigent un capital social.
const REQUIRED = [
  // SARL et dérivés (11)
  "5410",
  "5415",
  "5422",
  "5426",
  "5430",
  "5431",
  "5432",
  "5442",
  "5485",
  "5498", // EURL
  "5499", // SARL générique
  // SA — Conseil d'administration (11)
  "5505",
  "5510",
  "5515",
  "5520",
  "5522",
  "5525",
  "5530",
  "5531",
  "5532",
  "5585",
  "5599",
  // SA — Directoire (9)
  "5605",
  "5610",
  "5615",
  "5625",
  "5630",
  "5631",
  "5632",
  "5685",
  "5699",
  // SAS et dérivés (3)
  "5710",
  "5720", // SASU
  "5785", // SELAS
  // Société européenne (1)
  "5800",
];

// Échantillon de formes juridiques hors-liste — capital non requis.
const NOT_REQUIRED = [
  "1000", // Entrepreneur individuel (EI)
  "1100", // Artisan-commerçant
  "6540", // SCI
  "9220", // Association déclarée
  "5191", // Société coopérative
  "0000", // code inconnu/inexistant
];

describe("capitalRequiredFor", () => {
  it("recense exactement 35 codes requérant un capital social", () => {
    expect(REQUIRED).toHaveLength(35);
    expect(new Set(REQUIRED).size).toBe(35);
  });

  it.each(REQUIRED)("exige un capital pour le code %s", (code) => {
    expect(capitalRequiredFor(code)).toBe(true);
  });

  it.each(NOT_REQUIRED)("n'exige pas de capital pour le code %s", (code) => {
    expect(capitalRequiredFor(code)).toBe(false);
  });

  it("retourne false quand juridique_code est null", () => {
    expect(capitalRequiredFor(null)).toBe(false);
  });
});
