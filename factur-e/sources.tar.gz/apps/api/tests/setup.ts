/**
 * Vitest setup — runs once before any test file.
 *
 * - `ARGON2_MODE=test` drops Argon2 cost so login/signup tests stay fast
 *   (~10 ms hash vs ~700 ms in prod params).
 * - `JWT_SIGNING_KEY` provides a fixed dummy 64-char string so JWT helpers
 *   don't need a real Keychain entry to sign / verify in CI.
 * - `ENCRYPTION_KEY_HEX` provides a fixed dummy 64-char hex (32 bytes) for
 *   AES-256-GCM (TOTP secret encryption — T-CL-03).
 * - `NODE_ENV=test` disables `@fastify/rate-limit` registration in
 *   `buildApp` so test loops can fire many requests without 429s.
 */

process.env.NODE_ENV = "test";
process.env.ARGON2_MODE = "test";
if (process.env.JWT_SIGNING_KEY === undefined || process.env.JWT_SIGNING_KEY === "") {
  process.env.JWT_SIGNING_KEY = "test-jwt-secret-do-not-use-in-prod-must-be-32-chars-or-more";
}
if (process.env.ENCRYPTION_KEY_HEX === undefined || process.env.ENCRYPTION_KEY_HEX === "") {
  // 64 hex chars = 32 bytes for AES-256-GCM. Fixed dummy for tests only.
  process.env.ENCRYPTION_KEY_HEX =
    "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef";
}
