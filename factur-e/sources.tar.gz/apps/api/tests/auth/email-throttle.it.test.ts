import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { isEmailRecentlyThrottled } from "../../src/auth/email-throttle.js";
import { setupTestDb, type TestDb } from "../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("auth/email-throttle", () => {
  let db: TestDb;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
  });

  afterAll(async () => {
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  async function seedAuditEvent(args: {
    eventType: string;
    email: string;
    ageMinutes?: number;
  }): Promise<void> {
    const ageMinutes = args.ageMinutes ?? 0;
    await sql`
      INSERT INTO auth_audit (event_type, success, metadata, occurred_at)
      VALUES (
        ${args.eventType},
        ${args.eventType !== "signup_failed"},
        ${sql.json({ email: args.email })},
        NOW() - INTERVAL '${sql.unsafe(String(ageMinutes))} minutes'
      )
    `;
  }

  it("returns false when no recent transactional email for that address", async () => {
    expect(await isEmailRecentlyThrottled(sql, "po@acme.fr")).toBe(false);
  });

  it("returns true after a fresh signup_success on that address", async () => {
    await seedAuditEvent({ eventType: "signup_success", email: "po@acme.fr" });
    expect(await isEmailRecentlyThrottled(sql, "po@acme.fr")).toBe(true);
  });

  it("returns true after a signup_failed (decoy) — decoy still triggers a mail", async () => {
    await seedAuditEvent({ eventType: "signup_failed", email: "po@acme.fr" });
    expect(await isEmailRecentlyThrottled(sql, "po@acme.fr")).toBe(true);
  });

  it("returns true after a password_reset_request on that address", async () => {
    await seedAuditEvent({ eventType: "password_reset_request", email: "po@acme.fr" });
    expect(await isEmailRecentlyThrottled(sql, "po@acme.fr")).toBe(true);
  });

  it("ignores events outside the 5-min window", async () => {
    await seedAuditEvent({
      eventType: "signup_success",
      email: "po@acme.fr",
      ageMinutes: 10,
    });
    expect(await isEmailRecentlyThrottled(sql, "po@acme.fr")).toBe(false);
  });

  it("isolates per email — other emails are unaffected", async () => {
    await seedAuditEvent({ eventType: "signup_success", email: "po@acme.fr" });
    expect(await isEmailRecentlyThrottled(sql, "alice@acme.fr")).toBe(false);
  });

  it("ignores irrelevant event types (e.g. login_failed)", async () => {
    await seedAuditEvent({ eventType: "login_failed", email: "po@acme.fr" });
    expect(await isEmailRecentlyThrottled(sql, "po@acme.fr")).toBe(false);
  });
});
