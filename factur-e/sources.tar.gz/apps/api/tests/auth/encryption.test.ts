import { createCipheriv, randomBytes } from "node:crypto";

import { describe, expect, it } from "vitest";

import { decrypt, encrypt } from "../../src/auth/encryption.js";

/**
 * Helper that produces a *legacy* (pre-T-CL-02) AES-256-GCM blob layout
 * `[12 IV][16 TAG][N CIPHERTEXT]` so the decrypt cascade can be exercised
 * on rows that pre-date the version-byte refactor.
 */
function encryptLegacy(plain: Buffer | string, opts: { firstIvByte?: number } = {}): Buffer {
  const hex = process.env.ENCRYPTION_KEY_HEX;
  if (hex === undefined) throw new Error("ENCRYPTION_KEY_HEX must be set in test setup");
  const key = Buffer.from(hex, "hex");
  const iv =
    opts.firstIvByte === undefined
      ? randomBytes(12)
      : Buffer.from([opts.firstIvByte, ...randomBytes(11)]);
  const cipher = createCipheriv("aes-256-gcm", key, iv);
  const plainBuf = typeof plain === "string" ? Buffer.from(plain, "utf8") : plain;
  const ciphertext = Buffer.concat([cipher.update(plainBuf), cipher.final()]);
  const tag = cipher.getAuthTag();
  return Buffer.concat([iv, tag, ciphertext]);
}

describe("auth/encryption", () => {
  it("encrypt() produces a v1 blob (leading byte 0x01)", () => {
    const blob = encrypt("hello world");
    expect(blob[0]).toBe(0x01);
    // length = 1 (version) + 12 (IV) + 16 (tag) + 11 (ciphertext same len as plaintext)
    expect(blob.length).toBe(1 + 12 + 16 + 11);
  });

  it("encrypt + decrypt v1 roundtrip", () => {
    const blob = encrypt("hello world");
    expect(decrypt(blob).toString("utf8")).toBe("hello world");
  });

  it("decrypt accepts a legacy blob (no version prefix)", () => {
    const legacy = encryptLegacy("legacy secret");
    expect(decrypt(legacy).toString("utf8")).toBe("legacy secret");
  });

  it("decrypt resolves the 1/256 collision: legacy blob whose IV starts with 0x01", () => {
    // Force the IV's first byte to 0x01 so the cascade tries v1 first,
    // gets an auth-tag mismatch, and falls back to legacy.
    const legacy = encryptLegacy("collision case", { firstIvByte: 0x01 });
    expect(legacy[0]).toBe(0x01);
    expect(decrypt(legacy).toString("utf8")).toBe("collision case");
  });

  it("decrypt throws on a truncated blob", () => {
    expect(() => decrypt(Buffer.from([0x01, 0x02]))).toThrow();
  });

  it("decrypt detects tampering (auth tag mismatch on both formats)", () => {
    const blob = encrypt("something");
    // Flip a byte in the ciphertext region (after version + iv + tag).
    const lastIdx = blob.length - 1;
    blob.writeUInt8((blob.readUInt8(lastIdx) ^ 0xff) & 0xff, lastIdx);
    expect(() => decrypt(blob)).toThrow();
  });
});
