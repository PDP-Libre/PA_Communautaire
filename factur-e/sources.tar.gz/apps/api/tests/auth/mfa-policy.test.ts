import { describe, expect, it } from "vitest";

import { requiresTotp } from "../../src/auth/mfa-policy.js";

/**
 * Test unitaire ADR-006 §D3 — règle TOTP-only pour rôles privilégiés.
 * Function pure, pas de fixture BDD requise.
 */

describe("requiresTotp(user)", () => {
  it("Full sans can_purchase → TRUE (rôle privilégié)", () => {
    expect(requiresTotp({ role: "full", can_purchase: false })).toBe(true);
  });

  it("deposit_simple + can_purchase=true → TRUE (peut acheter des packs)", () => {
    expect(requiresTotp({ role: "deposit_simple", can_purchase: true })).toBe(true);
  });

  it("deposit_states + can_purchase=true → TRUE (peut acheter des packs)", () => {
    expect(requiresTotp({ role: "deposit_states", can_purchase: true })).toBe(true);
  });

  it("deposit_simple sans can_purchase → FALSE (rôle non privilégié)", () => {
    expect(requiresTotp({ role: "deposit_simple", can_purchase: false })).toBe(false);
  });

  it("deposit_states sans can_purchase → FALSE", () => {
    expect(requiresTotp({ role: "deposit_states", can_purchase: false })).toBe(false);
  });

  it("Full + can_purchase=true → TRUE (les deux flags se combinent)", () => {
    expect(requiresTotp({ role: "full", can_purchase: true })).toBe(true);
  });
});
