import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { LOCKOUT_CONFIG, isEmailLockedOut, isIpLockedOut } from "../../src/auth/lockout.js";
import { setupTestDb, type TestDb } from "../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("auth/lockout", () => {
  let db: TestDb;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
  });

  afterAll(async () => {
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  async function seedFails(count: number, args: { email?: string; ip?: string }): Promise<void> {
    const email = args.email ?? "po@acme.fr";
    const ip = args.ip ?? "10.0.0.1";
    for (let i = 0; i < count; i += 1) {
      await sql`
        INSERT INTO auth_audit (event_type, success, ip, metadata)
        VALUES ('login_failed', FALSE, ${ip}::inet, ${sql.json({ email })})
      `;
    }
  }

  describe("isEmailLockedOut", () => {
    it("returns false below the threshold", async () => {
      await seedFails(LOCKOUT_CONFIG.failThreshold - 1, { email: "po@acme.fr" });
      expect(await isEmailLockedOut(sql, "po@acme.fr")).toBe(false);
    });

    it("returns true at or above the threshold", async () => {
      await seedFails(LOCKOUT_CONFIG.failThreshold, { email: "po@acme.fr" });
      expect(await isEmailLockedOut(sql, "po@acme.fr")).toBe(true);
    });

    it("isolates per email — other emails are unaffected", async () => {
      await seedFails(LOCKOUT_CONFIG.failThreshold + 5, { email: "po@acme.fr" });
      expect(await isEmailLockedOut(sql, "alice@acme.fr")).toBe(false);
    });
  });

  describe("isIpLockedOut", () => {
    it("returns false below the IP threshold", async () => {
      await seedFails(LOCKOUT_CONFIG.ipFailThreshold - 1, { ip: "10.0.0.1" });
      expect(await isIpLockedOut(sql, "10.0.0.1")).toBe(false);
    });

    it("returns true at or above the IP threshold", async () => {
      // Cycle through 21 distinct emails so the per-email lockout never
      // fires — only the per-IP counter does.
      for (let i = 0; i < LOCKOUT_CONFIG.ipFailThreshold; i += 1) {
        await seedFails(1, { email: `victim-${String(i)}@acme.fr`, ip: "10.0.0.1" });
      }
      expect(await isIpLockedOut(sql, "10.0.0.1")).toBe(true);
      // Not lockoutd per-email because each got a single fail.
      expect(await isEmailLockedOut(sql, "victim-0@acme.fr")).toBe(false);
    });

    it("isolates per IP — other IPs are unaffected", async () => {
      await seedFails(LOCKOUT_CONFIG.ipFailThreshold + 5, { ip: "10.0.0.1" });
      expect(await isIpLockedOut(sql, "192.168.1.42")).toBe(false);
    });
  });
});
