import type { FastifyRequest } from "fastify";
import { beforeEach, describe, expect, it, vi } from "vitest";

/**
 * Tests unitaires `resolveAuthContext`.
 *
 * T-CL-AUTH-SSE-COOKIE-HTTPONLY (sprint-06, hard cut Z1) — le fallback bearer
 * via `?token=` query (ajouté T-CL-WEB-CDAR sprint-04 pour EventSource) a été
 * **supprimé** : aucun bearer ne transite plus dans une URL. Le SSE
 * s'authentifie via le cookie HttpOnly `_session` (`resolveSseAuthContext`,
 * cf. `tests/http/invoices/events-auth.it.test.ts`). On garde ici un test
 * négatif garde-fou : `?token=` ne doit jamais authentifier.
 *
 * Fixture : FastifyRequest minimal cast — pas de Fastify ni Postgres requis.
 */

vi.mock("../../src/auth/jwt.js", () => ({
  verifyAccessToken: vi.fn(),
  verifySignupSessionToken: vi.fn(),
}));

const { verifyAccessToken, verifySignupSessionToken } = await import("../../src/auth/jwt.js");
const { resolveAuthContext } = await import("../../src/auth/context.js");

interface FakeReqInput {
  headers?: Record<string, string | undefined>;
  query?: Record<string, unknown> | undefined;
  cookies?: Record<string, string | undefined>;
}

function fakeReq(input: FakeReqInput = {}): FastifyRequest {
  return {
    headers: input.headers ?? {},
    query: input.query ?? {},
    cookies: input.cookies ?? {},
  } as unknown as FastifyRequest;
}

beforeEach(() => {
  vi.mocked(verifyAccessToken).mockReset();
  vi.mocked(verifySignupSessionToken).mockReset();
});

describe("resolveAuthContext — auth bearer header (query `?token=` supprimé)", () => {
  it("authentifie via header `Authorization: Bearer …`", async () => {
    vi.mocked(verifyAccessToken).mockResolvedValue({
      user_id: "user-1",
      customer_id: "customer-1",
    });

    const ctx = await resolveAuthContext(fakeReq({ headers: { authorization: "Bearer good" } }));

    expect(ctx).toEqual({ state: "authenticated", user_id: "user-1", customer_id: "customer-1" });
    expect(verifyAccessToken).toHaveBeenCalledWith("good");
  });

  it("NÉGATIF (Z1) — `?token=<bearer>` query est ignoré → anon, jamais vérifié", async () => {
    const ctx = await resolveAuthContext(fakeReq({ query: { token: "would-be-valid-bearer" } }));

    expect(ctx).toEqual({ state: "anon" });
    // Le token query ne doit même pas être présenté à la vérification.
    expect(verifyAccessToken).not.toHaveBeenCalled();
  });

  it("NÉGATIF (Z1) — header absent mais `?token=` présent → anon (pas de fallback)", async () => {
    const ctx = await resolveAuthContext(
      fakeReq({ headers: {}, query: { token: "x".repeat(40) } }),
    );

    expect(ctx).toEqual({ state: "anon" });
    expect(verifyAccessToken).not.toHaveBeenCalled();
  });

  it("header bearer invalide → anon", async () => {
    vi.mocked(verifyAccessToken).mockRejectedValue(new Error("invalid jwt"));

    const ctx = await resolveAuthContext(fakeReq({ headers: { authorization: "Bearer bad" } }));

    expect(ctx).toEqual({ state: "anon" });
  });

  it("aucune auth → anon, verify non appelé", async () => {
    const ctx = await resolveAuthContext(fakeReq());

    expect(ctx).toEqual({ state: "anon" });
    expect(verifyAccessToken).not.toHaveBeenCalled();
  });
});
