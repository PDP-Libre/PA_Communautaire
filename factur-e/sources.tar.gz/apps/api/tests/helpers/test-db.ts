import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

import postgres from "postgres";

import { runMigrations } from "../../src/db/migrate.js";

const __dirname = dirname(fileURLToPath(import.meta.url));
const migrationsDir = join(__dirname, "..", "..", "src", "db", "migrations");

export interface TestDb {
  /** Connection string the tested code should use. */
  readonly url: string;
  /** Drop the throwaway database. */
  readonly drop: () => Promise<void>;
  /** Truncate auth-relevant tables to isolate test cases. */
  readonly resetAuthTables: () => Promise<void>;
}

/**
 * Spin up a throwaway database against the admin URL given by
 * `TEST_POSTGRES_URL`, run all migrations, return helpers.
 *
 * Caller must `await drop()` in `afterAll`. Returns `null` if the env var
 * is unset — callers `describe.skipIf` on that.
 *
 * Both dev (Postgres docker-compose) and CI (Postgres mac permanent
 * accessed via `host.docker.internal`) use the same throwaway-DB pattern.
 * Suites run in parallel — each gets its own DB, isolation is total.
 *
 * The CI user `factur_e_ci` must have CREATEDB (cf. `docs/operations/ci-postgres.md`).
 */
export async function setupTestDb(): Promise<TestDb | null> {
  const adminUrl = process.env.TEST_POSTGRES_URL;
  if (adminUrl === undefined || adminUrl === "") return null;

  const dbName = `factur_e_auth_test_${Math.random().toString(36).slice(2, 10)}`;

  const admin = postgres(adminUrl, { max: 1, onnotice: () => undefined });
  try {
    await admin.unsafe(`CREATE DATABASE "${dbName}"`);
  } finally {
    await admin.end();
  }

  const url = new URL(adminUrl);
  url.pathname = `/${dbName}`;
  const testUrl = url.toString();

  await runMigrations({ connectionString: testUrl, migrationsDir });

  const sql = postgres(testUrl, { max: 1, onnotice: () => undefined });

  return {
    url: testUrl,
    async drop() {
      await sql.end();
      const adm = postgres(adminUrl, { max: 1, onnotice: () => undefined });
      try {
        await adm.unsafe(
          `SELECT pg_terminate_backend(pid) FROM pg_stat_activity
           WHERE datname = '${dbName}' AND pid <> pg_backend_pid()`,
        );
        await adm.unsafe(`DROP DATABASE IF EXISTS "${dbName}"`);
      } finally {
        await adm.end();
      }
    },
    async resetAuthTables() {
      await sql`
        TRUNCATE TABLE
          auth_audit, sessions, otp_codes, signup_pending, invitations, users, customers,
          insee_cache, pa_connections, directory_cache, buyer_address_preferences,
          products, product_categories,
          cdar_events, invoice_lines, invoice_drafts, invoices
        RESTART IDENTITY CASCADE
      `;
    },
  };
}
