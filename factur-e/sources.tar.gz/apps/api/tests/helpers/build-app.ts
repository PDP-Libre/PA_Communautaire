import type { AddressInfo } from "node:net";

import { buildApp, type BuildAppOptions } from "../../src/server.js";

export interface TestApp {
  /** Base URL like `http://127.0.0.1:54321` (random port). */
  readonly url: string;
  /** Tear down — closes the server cleanly. */
  readonly stop: () => Promise<void>;
}

/**
 * Spin up a real Fastify server on a random free port.
 *
 * CLAUDE.md §6.1 — Fastify 5 has subtle bugs with `app.inject()` so we always
 * `.listen({ port: 0 })` and exercise routes via real `fetch` calls. Slower
 * than inject but representative.
 */
export async function buildTestApp(opts: BuildAppOptions = {}): Promise<TestApp> {
  const app = await buildApp(opts);
  await app.listen({ port: 0, host: "127.0.0.1" });

  const addr: AddressInfo | string | null = app.server.address();
  if (addr === null || typeof addr === "string") {
    await app.close();
    throw new Error("[buildTestApp] expected AddressInfo from server.address()");
  }
  const { port } = addr;
  const url = `http://127.0.0.1:${String(port)}`;

  return {
    url,
    stop: async (): Promise<void> => {
      await app.close();
    },
  };
}
