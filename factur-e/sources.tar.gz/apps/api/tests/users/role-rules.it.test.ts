import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { hashPassword } from "../../src/auth/argon2.js";
import { countActiveFullsByCustomer } from "../../src/db/repos/users.js";
import { wouldDropLastFull } from "../../src/users/role-rules.js";
import { setupTestDb, type TestDb } from "../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

interface SeedResult {
  customerId: string;
  full1: string;
  full2: string;
  light: string;
}

async function seedTeam(sql: postgres.Sql): Promise<SeedResult> {
  const customer = await sql<{ id: string }[]>`
    INSERT INTO customers (siren, legal_name) VALUES (${"123456789"}, ${"Acme"}) RETURNING id
  `;
  const customerId = customer[0]?.id ?? "";
  const hash = await hashPassword("Password123!");
  const f1 = await sql<{ id: string }[]>`
    INSERT INTO users (customer_id, email, password_hash, role)
    VALUES (${customerId}, ${"f1@acme.fr"}, ${hash}, ${"full"}) RETURNING id
  `;
  const f2 = await sql<{ id: string }[]>`
    INSERT INTO users (customer_id, email, password_hash, role)
    VALUES (${customerId}, ${"f2@acme.fr"}, ${hash}, ${"full"}) RETURNING id
  `;
  const light = await sql<{ id: string }[]>`
    INSERT INTO users (customer_id, email, password_hash, role)
    VALUES (${customerId}, ${"l@acme.fr"}, ${hash}, ${"deposit_simple"}) RETURNING id
  `;
  return {
    customerId,
    full1: f1[0]?.id ?? "",
    full2: f2[0]?.id ?? "",
    light: light[0]?.id ?? "",
  };
}

describe.skipIf(!enabled)("role-rules", () => {
  let db: TestDb;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
  });

  afterAll(async () => {
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  it("countActiveFullsByCustomer counts only role=full + deleted_at IS NULL", async () => {
    const team = await seedTeam(sql);
    expect(await countActiveFullsByCustomer(sql, team.customerId)).toBe(2);

    await sql`UPDATE users SET deleted_at = NOW() WHERE id = ${team.full1}`;
    expect(await countActiveFullsByCustomer(sql, team.customerId)).toBe(1);
  });

  it("wouldDropLastFull true when target is the lone active Full", async () => {
    const team = await seedTeam(sql);

    // Soft-delete full2 → only full1 remains as Full.
    await sql`UPDATE users SET deleted_at = NOW() WHERE id = ${team.full2}`;
    const target = {
      id: team.full1,
      customer_id: team.customerId,
      role: "full" as const,
      can_purchase: false,
      deleted_at: null,
    };
    expect(await wouldDropLastFull(sql, target)).toBe(true);
  });

  it("wouldDropLastFull false when ≥2 active Fulls", async () => {
    const team = await seedTeam(sql);
    const target = {
      id: team.full1,
      customer_id: team.customerId,
      role: "full" as const,
      can_purchase: false,
      deleted_at: null,
    };
    expect(await wouldDropLastFull(sql, target)).toBe(false);
  });

  it("wouldDropLastFull false for a non-Full target", async () => {
    const team = await seedTeam(sql);
    await sql`UPDATE users SET deleted_at = NOW() WHERE id = ${team.full2}`;
    const target = {
      id: team.light,
      customer_id: team.customerId,
      role: "deposit_simple" as const,
      can_purchase: false,
      deleted_at: null,
    };
    expect(await wouldDropLastFull(sql, target)).toBe(false);
  });
});
