import { describe, expect, it } from "vitest";

import {
  buildInvitationToken,
  generateInvitationSecret,
  hashInvitationSecret,
  parseInvitationToken,
  verifyInvitationSecret,
} from "../../src/users/invitation-token.js";

describe("invitation-token", () => {
  it("generateInvitationSecret returns 32-hex string", () => {
    const s = generateInvitationSecret();
    expect(s).toMatch(/^[0-9a-f]{32}$/);
  });

  it("buildInvitationToken / parseInvitationToken roundtrips", () => {
    const id = "11111111-2222-3333-4444-555555555555";
    const secret = "abcd".repeat(8); // 32 hex chars
    const token = buildInvitationToken(id, secret);
    const parsed = parseInvitationToken(token);
    expect(parsed?.id).toBe(id);
    expect(parsed?.secret).toBe(secret);
  });

  it("parseInvitationToken rejects malformed tokens", () => {
    expect(parseInvitationToken("garbage")).toBeNull();
    expect(parseInvitationToken("11111111-2222-3333-4444-555555555555")).toBeNull();
    expect(parseInvitationToken("not-a-uuid.0123456789abcdef0123456789abcdef")).toBeNull();
    expect(parseInvitationToken("11111111-2222-3333-4444-555555555555.tooshort")).toBeNull();
  });

  it("hashInvitationSecret + verifyInvitationSecret roundtrips", async () => {
    const secret = generateInvitationSecret();
    const hashed = await hashInvitationSecret(secret);
    expect(await verifyInvitationSecret(secret, hashed)).toBe(true);
    expect(await verifyInvitationSecret("wrong", hashed)).toBe(false);
  });
});
