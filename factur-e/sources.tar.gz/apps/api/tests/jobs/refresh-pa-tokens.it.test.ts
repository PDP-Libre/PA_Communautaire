import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { MockPADriver } from "@factur-e/shared-fakes";

import { hashPassword } from "../../src/auth/argon2.js";
import type { EmailPurpose } from "../../src/email/sender.js";
import { runRefreshPaTokens } from "../../src/jobs/refresh-pa-tokens.js";
import { MemorySecretStore } from "../../src/secrets/index.js";
import { setupTestDb, type TestDb } from "../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

interface RecordedEmail {
  to: string;
  purpose: string;
}

class CapturingEmailSender {
  readonly sent: RecordedEmail[] = [];
  send(args: { to: string; purpose: EmailPurpose }): Promise<void> {
    this.sent.push({ to: args.to, purpose: args.purpose });
    return Promise.resolve();
  }
}

describe.skipIf(!enabled)("refresh-pa-tokens job (T-CL-06 sprint-03)", () => {
  let db: TestDb;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 5, onnotice: () => undefined });
  });

  afterAll(async () => {
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  async function seed(): Promise<{ customerId: string; userId: string }> {
    const customerRows = await sql<{ id: string }[]>`
      INSERT INTO customers (siren, legal_name) VALUES (${"100000001"}, ${"Acme"}) RETURNING id
    `;
    const customerId = customerRows[0]?.id ?? "";
    const hash = await hashPassword("Password123!");
    const userRows = await sql<{ id: string }[]>`
      INSERT INTO users (customer_id, email, password_hash, role)
      VALUES (${customerId}, ${"alice@acme.fr"}, ${hash}, ${"full"})
      RETURNING id
    `;
    return { customerId, userId: userRows[0]?.id ?? "" };
  }

  it("refreshes a due connection: rotates bundle, resets failures, audit pa_token_refreshed", async () => {
    const seed_ = await seed();
    const secrets = new MemorySecretStore();
    const driver = new MockPADriver({ scenario: "verified" });
    const email = new CapturingEmailSender();

    const ref = `superpdp-bundle-${seed_.customerId}`;
    await secrets.put(ref, {
      accessToken: "old-access",
      refreshToken: "old-refresh",
      accessExpiresAt: new Date().toISOString(),
    });
    // Connection ripe for refresh: last_refreshed_at is far in the past.
    await sql`
      INSERT INTO pa_connections (customer_id, secret_ref,
                                   user_identity_verification_status,
                                   company_verification_status,
                                   last_refreshed_at)
      VALUES (${seed_.customerId}, ${ref}, ${"verified"}, ${"verified"},
              NOW() - INTERVAL '30 minutes')
    `;

    const result = await runRefreshPaTokens({ sql, driver, secrets, email });
    expect(result).toMatchObject({ skipped: false, refreshed: 1, failed: 0, lost: 0 });
    expect(driver.counts.refresh).toBe(1);
    const stored = await secrets.get(ref);
    expect(stored?.accessToken).not.toBe("old-access");

    const audit = await sql<{ event_type: string }[]>`
      SELECT event_type FROM auth_audit
      WHERE customer_id = ${seed_.customerId}
      ORDER BY occurred_at ASC, id ASC
    `;
    expect(audit.map((a) => a.event_type)).toEqual(["pa_token_refreshed"]);
  });

  it("3rd RefreshExpiredException → soft-delete + delete secret + email pa_token_lost", async () => {
    const seed_ = await seed();
    const secrets = new MemorySecretStore();
    const driver = new MockPADriver({ scenario: "refresh_expired" });
    const email = new CapturingEmailSender();

    const ref = `superpdp-bundle-${seed_.customerId}`;
    await secrets.put(ref, {
      accessToken: "a",
      refreshToken: "r",
      accessExpiresAt: new Date().toISOString(),
    });
    // Already at 2 failures — next exception triggers the cutover.
    await sql`
      INSERT INTO pa_connections (customer_id, secret_ref,
                                   user_identity_verification_status,
                                   company_verification_status,
                                   refresh_failures_count,
                                   last_refreshed_at)
      VALUES (${seed_.customerId}, ${ref}, ${"verified"}, ${"verified"},
              ${2}, NOW() - INTERVAL '30 minutes')
    `;

    const result = await runRefreshPaTokens({ sql, driver, secrets, email });
    expect(result.lost).toBe(1);
    expect(result.failed).toBe(0);
    expect(await secrets.get(ref)).toBeNull();

    const conns = await sql<{ deleted_at: Date | null; revoked_at: Date | null }[]>`
      SELECT deleted_at, revoked_at FROM pa_connections WHERE customer_id = ${seed_.customerId}
    `;
    expect(conns[0]?.deleted_at).not.toBeNull();
    expect(conns[0]?.revoked_at).not.toBeNull();

    expect(email.sent).toEqual([{ to: "alice@acme.fr", purpose: "pa_token_lost" }]);
    const audit = await sql<{ event_type: string }[]>`
      SELECT event_type FROM auth_audit
      WHERE customer_id = ${seed_.customerId}
      ORDER BY occurred_at ASC, id ASC
    `;
    expect(audit.map((a) => a.event_type)).toEqual(["pa_token_refresh_failed", "pa_token_lost"]);
  });

  it("skipped when another replica holds the advisory lock", async () => {
    const peer = postgres(db.url, { max: 1, onnotice: () => undefined });
    try {
      const lockRows = await peer<{ acquired: boolean }[]>`
        SELECT pg_try_advisory_lock(43211) AS acquired
      `;
      expect(lockRows[0]?.acquired).toBe(true);
      const result = await runRefreshPaTokens({
        sql,
        driver: new MockPADriver(),
        secrets: new MemorySecretStore(),
        email: new CapturingEmailSender(),
      });
      expect(result).toEqual({ skipped: true, refreshed: 0, failed: 0, lost: 0 });
      await peer`SELECT pg_advisory_unlock(43211)`;
    } finally {
      await peer.end();
    }
  });
});
