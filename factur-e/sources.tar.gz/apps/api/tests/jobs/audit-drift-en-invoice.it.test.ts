import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";

import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { parseInvoiceMetadata } from "@factur-e/factur-x-builder";
import { PaUnavailableException, type IncomingInvoice } from "@factur-e/pa-adapter";
import { MockPADriver } from "@factur-e/shared-fakes";

import { runAuditDriftEnInvoice } from "../../src/jobs/audit-drift-en-invoice.js";
import { MemorySecretStore } from "../../src/secrets/index.js";
import { seedFullCustomer } from "../_fixtures/seed-customer.js";
import { setupTestDb, type TestDb } from "../helpers/test-db.js";

/**
 * T-CL-RECV-AUDIT-DRIFT-EN-INVOICE sprint-06 — tests run-level `runAuditDriftEn
 * Invoice` (DB réelle + MockPADriver). Le XML source de vérité est la fixture
 * Factur-X EXTENDED réelle (sprint-01) ; l'en_invoice est dérivé de son parse
 * (zéro drift) ou volontairement altéré (drift BT-1).
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);
const ADVISORY_LOCK_KEY = 43215;

const FIXTURE_XML = readFileSync(
  fileURLToPath(
    new URL(
      "../../../../packages/factur-x-builder/spikes/xsd/fixtures/extended-reference.xml",
      import.meta.url,
    ),
  ),
  "utf8",
);
const TRUTH = parseInvoiceMetadata(FIXTURE_XML);

/** Construit une facture entrante dont l'en_invoice est aligné sur le XML
 *  (zéro drift), surchargeable pour simuler un drift. */
function incoming(
  paInvoiceId: string,
  override: Partial<IncomingInvoice["enInvoice"]> = {},
): IncomingInvoice {
  return {
    paInvoiceId,
    direction: "in",
    receivedAt: "2026-05-20T09:00:00.000Z",
    enInvoice: {
      number: TRUTH.document.invoiceNumber,
      issueDate: TRUTH.document.issueDate,
      currency: TRUTH.document.currency,
      sellerSiren: TRUTH.parties.seller.siren,
      sellerName: TRUTH.parties.seller.name,
      totalTtcCents: TRUTH.totals.totalTtc,
      ...override,
    },
  };
}

describe.skipIf(!enabled)("[audit-drift-en-invoice] worker", () => {
  let db: TestDb;
  let sql: postgres.Sql;
  let secrets: MemorySecretStore;
  let driver: MockPADriver;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 5, onnotice: () => undefined });
    secrets = new MemorySecretStore();
    driver = new MockPADriver();
  });

  afterAll(async () => {
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    driver.reset();
    // XML source de vérité servi par downloadInvoiceFile (Factur-X / CII pur).
    driver.setDownloadInvoiceFileResult({
      bytes: Buffer.from(FIXTURE_XML, "utf8"),
      contentType: "application/xml",
    });
  });

  const deps = (): { sql: postgres.Sql; driver: MockPADriver; secrets: MemorySecretStore } => ({
    sql,
    driver,
    secrets,
  });

  it("en_invoice aligné sur le XML → comparé, zéro drift, audit audit_drift_run", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    driver.seedIncomingInvoices([incoming("45933")]);

    const result = await runAuditDriftEnInvoice(deps());

    expect(result.skipped).toBe(false);
    expect(result.invoicesCompared).toBe(1);
    expect(result.driftDetected).toBe(0);
    expect(result.errors).toBe(0);

    const audits = await sql<{ metadata: { drift_count: number } }[]>`
      SELECT metadata FROM auth_audit
      WHERE event_type = 'audit_drift_run' AND customer_id = ${seed.customerId}
    `;
    expect(audits).toHaveLength(1);
    expect(audits[0]?.metadata.drift_count).toBe(0);
  });

  it("numéro en_invoice altéré → drift BT-1 détecté + agrégé", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    driver.seedIncomingInvoices([incoming("45934", { number: "DRIFT-9999" })]);

    const result = await runAuditDriftEnInvoice(deps());

    expect(result.invoicesCompared).toBe(1);
    expect(result.driftDetected).toBe(1);
    expect(result.driftFields).toContain("BT-1");

    const audits = await sql<{ metadata: { drift_count: number; drift_fields: string[] } }[]>`
      SELECT metadata FROM auth_audit
      WHERE event_type = 'audit_drift_run' AND customer_id = ${seed.customerId}
    `;
    expect(audits[0]?.metadata.drift_count).toBe(1);
    expect(audits[0]?.metadata.drift_fields).toContain("BT-1");
  });

  it("listIncomingInvoices 5xx → erreur comptée + audit audit_drift_failed", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    driver.setListIncomingFailure(
      new PaUnavailableException({ status: 503, message: "sandbox down" }),
    );

    const result = await runAuditDriftEnInvoice(deps());

    expect(result.errors).toBe(1);
    expect(result.invoicesCompared).toBe(0);

    const audits = await sql<{ event_type: string }[]>`
      SELECT event_type FROM auth_audit
      WHERE event_type = 'audit_drift_failed' AND customer_id = ${seed.customerId}
    `;
    expect(audits).toHaveLength(1);
  });

  it("advisory lock tenu par une autre session → tick skip", async () => {
    const locker = postgres(db.url, { max: 1, onnotice: () => undefined });
    try {
      await locker`SELECT pg_advisory_lock(${ADVISORY_LOCK_KEY})`;
      const result = await runAuditDriftEnInvoice(deps());
      expect(result.skipped).toBe(true);
    } finally {
      await locker`SELECT pg_advisory_unlock(${ADVISORY_LOCK_KEY})`;
      await locker.end();
    }
  });
});
