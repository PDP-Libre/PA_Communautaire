import { describe, expect, it } from "vitest";

import { buildExportPgBoss } from "../../src/jobs/job-queue.js";

/**
 * Régression boot pgboss (T-CL-EXPORT-ZIP-RETENTION) : le constructeur PgBoss
 * VALIDE sa config en synchrone (sans connexion DB). `start.ts` n'étant pas
 * exercé par les tests HTTP (ils passent par `buildApp()` + MockJobQueue), ce
 * test couvre la config réelle — il aurait attrapé `expireInHours: 24` rejeté
 * par l'assertion attorney « expiration cannot exceed 24 hours ».
 */
describe("buildExportPgBoss config", () => {
  it("construit l'instance sans throw (expireInHours strictement < 24)", () => {
    expect(() => buildExportPgBoss("postgresql://u:p@localhost:5432/db")).not.toThrow();
  });
});
