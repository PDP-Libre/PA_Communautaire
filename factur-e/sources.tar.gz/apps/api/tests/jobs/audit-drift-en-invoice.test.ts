import { describe, expect, it } from "vitest";

import type { InvoiceMetadata } from "@factur-e/factur-x-builder";
import type { IncomingInvoiceEnData } from "@factur-e/pa-adapter";

import { compareEnInvoiceDrift } from "../../src/jobs/audit-drift-en-invoice.js";

/**
 * T-CL-RECV-AUDIT-DRIFT-EN-INVOICE sprint-06 — tests purs de la détection de
 * drift `en_invoice` (métadonnées SuperPDP) vs XML parsé (source de vérité).
 * Set réduit BT-1/BT-2/BT-30/BT-44/BT-112 (Z5 — BT-47/BT-117 non exposés par
 * l'accesseur en_invoice V1, comparaison reportée).
 */

/** Construit un `InvoiceMetadata` minimal valide, surchargeable. */
function makeMeta(overrides: {
  invoiceNumber?: string;
  issueDate?: string;
  sellerSiren?: string;
  sellerName?: string;
  totalTtc?: number;
}): InvoiceMetadata {
  return {
    format: "cii",
    document: {
      invoiceNumber: overrides.invoiceNumber ?? "F-2026-0001",
      issueDate: overrides.issueDate ?? "2026-05-16",
      currency: "EUR",
      documentType: "380",
    },
    parties: {
      seller: {
        siren: overrides.sellerSiren ?? "111111118",
        name: overrides.sellerName ?? "Vendeur SAS",
      },
      buyer: { siren: "987654321", name: "Client Corp" },
    },
    lines: [],
    totals: {
      subtotalHt: 50000,
      vatAmount: 10000,
      totalTtc: overrides.totalTtc ?? 60000,
      balanceDue: 60000,
    },
  };
}

/** en_invoice aligné par défaut sur `makeMeta()` (zéro drift). */
function makeEn(overrides: Partial<IncomingInvoiceEnData> = {}): IncomingInvoiceEnData {
  return {
    number: "F-2026-0001",
    issueDate: "2026-05-16",
    sellerSiren: "111111118",
    sellerName: "Vendeur SAS",
    totalTtcCents: 60000,
    currency: "EUR",
    ...overrides,
  };
}

describe("compareEnInvoiceDrift", () => {
  it("en_invoice aligné sur le XML → aucun drift", () => {
    expect(compareEnInvoiceDrift(makeEn(), makeMeta({}))).toEqual([]);
  });

  it("numéro divergent → drift BT-1", () => {
    const drift = compareEnInvoiceDrift(makeEn({ number: "F-2026-9999" }), makeMeta({}));
    expect(drift).toEqual(["BT-1"]);
  });

  it("SIREN + total divergents → drift BT-30 + BT-112 agrégés", () => {
    const drift = compareEnInvoiceDrift(
      makeEn({ sellerSiren: "000000000", totalTtcCents: 59999 }),
      makeMeta({}),
    );
    expect(drift).toEqual(["BT-30", "BT-112"]);
  });

  it("champ en_invoice absent → pas de faux drift (comparaison sautée)", () => {
    const drift = compareEnInvoiceDrift(
      makeEn({ number: undefined, sellerName: undefined }),
      makeMeta({ invoiceNumber: "AUTRE", sellerName: "Autre Nom" }),
    );
    expect(drift).toEqual([]);
  });
});
