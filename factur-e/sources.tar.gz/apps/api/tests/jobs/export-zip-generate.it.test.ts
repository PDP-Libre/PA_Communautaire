import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { MockPADriver } from "@factur-e/shared-fakes";

import { findExportRequestById, insertExportRequest } from "../../src/db/repos/export_requests.js";
import { MockEmailSender } from "../../src/email/sender.js";
import { MemorySecretStore } from "../../src/secrets/index.js";
import { runExportZipGenerate } from "../../src/services/export-zip-generate.js";
import { MockObjectStorage } from "../../src/storage/object-storage.js";
import { seedInvoiceUser } from "../http/invoices/_helpers.js";
import { setupTestDb, type TestDb } from "../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

/** Stub storage dont l'upload échoue (test du chemin `failed`). */
class FailingUploadStorage extends MockObjectStorage {
  override async uploadObject(): Promise<void> {
    await Promise.resolve();
    throw new Error("S3 upload boom");
  }
}

describe.skipIf(!enabled)("export-zip-generate service (T-CL-EXPORT-ZIP-RETENTION)", () => {
  let db: TestDb;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 2, onnotice: () => undefined });
  });

  afterAll(async () => {
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    await sql`TRUNCATE TABLE export_requests, received_invoices RESTART IDENTITY CASCADE`;
  });

  async function seedReception(customerId: string): Promise<string> {
    const rows = await sql<{ id: string }[]>`
      INSERT INTO received_invoices (customer_id, pa_invoice_id_in, seller_siren,
        invoice_number_extracted, issue_date, status_current)
      VALUES (${customerId}, 'pa-in-1', '987654321', 'FR-IN-001', '2026-05-01', 'in_process')
      RETURNING id
    `;
    return rows[0]?.id ?? "";
  }

  it("génère le ZIP d'une facture reçue → completed + exported_at + email + audit", async () => {
    const secrets = new MemorySecretStore();
    const seed = await seedInvoiceUser(sql, { secretStore: secrets });
    const receivedId = await seedReception(seed.customerId);
    const request = await insertExportRequest(sql, {
      customer_id: seed.customerId,
      requested_by_user_id: seed.userId,
      scope: "reception",
      filters: {},
      invoice_ids: [receivedId],
      invoice_count: 1,
    });

    const storage = new MockObjectStorage();
    const email = new MockEmailSender();
    await runExportZipGenerate(
      {
        sql,
        exportsStorage: storage,
        paDriver: new MockPADriver(),
        secrets,
        email,
        webBaseUrl: "http://web",
      },
      { exportRequestId: request.id },
    );

    const after = await findExportRequestById(sql, request.id);
    expect(after?.status).toBe("completed");
    expect(after?.file_key).toBe(`exports/${seed.customerId}/${request.id}.zip`);
    expect((after?.file_size_bytes ?? 0) > 0).toBe(true);
    expect(storage.getObject(after?.file_key ?? "")).toBeDefined();

    const recv = await sql<{ exported_at: Date | null }[]>`
      SELECT exported_at FROM received_invoices WHERE id = ${receivedId}
    `;
    expect(recv[0]?.exported_at).not.toBeNull();

    expect(email.lastSentTo("owner@test.fr")?.purpose).toBe("export_ready");

    const audit = await sql<{ n: string }[]>`
      SELECT COUNT(*)::text AS n FROM auth_audit WHERE event_type = 'export_zip_generated'
    `;
    expect(Number(audit[0]?.n)).toBe(1);
  });

  it("échec d'upload S3 → statut failed + error_message + audit export_zip_failed + re-throw", async () => {
    const secrets = new MemorySecretStore();
    const seed = await seedInvoiceUser(sql, { secretStore: secrets });
    const receivedId = await seedReception(seed.customerId);
    const request = await insertExportRequest(sql, {
      customer_id: seed.customerId,
      requested_by_user_id: seed.userId,
      scope: "reception",
      filters: {},
      invoice_ids: [receivedId],
      invoice_count: 1,
    });

    await expect(
      runExportZipGenerate(
        {
          sql,
          exportsStorage: new FailingUploadStorage(),
          paDriver: new MockPADriver(),
          secrets,
          email: new MockEmailSender(),
          webBaseUrl: "http://web",
        },
        { exportRequestId: request.id },
      ),
    ).rejects.toThrow(/boom/);

    const after = await findExportRequestById(sql, request.id);
    expect(after?.status).toBe("failed");
    expect(after?.error_message).toContain("boom");
    const audit = await sql<{ n: string }[]>`
      SELECT COUNT(*)::text AS n FROM auth_audit WHERE event_type = 'export_zip_failed'
    `;
    expect(Number(audit[0]?.n)).toBe(1);
  });

  it("idempotence : re-run sur un export déjà completed ne refait rien", async () => {
    const secrets = new MemorySecretStore();
    const seed = await seedInvoiceUser(sql, { secretStore: secrets });
    const receivedId = await seedReception(seed.customerId);
    const request = await insertExportRequest(sql, {
      customer_id: seed.customerId,
      requested_by_user_id: seed.userId,
      scope: "reception",
      filters: {},
      invoice_ids: [receivedId],
      invoice_count: 1,
    });
    await sql`UPDATE export_requests SET status = 'completed' WHERE id = ${request.id}`;

    const storage = new MockObjectStorage();
    await runExportZipGenerate(
      {
        sql,
        exportsStorage: storage,
        paDriver: new MockPADriver(),
        secrets,
        email: new MockEmailSender(),
        webBaseUrl: "http://web",
      },
      { exportRequestId: request.id },
    );
    // Pas de nouvel upload (l'export était déjà finalisé).
    expect(storage.getObject(`exports/${seed.customerId}/${request.id}.zip`)).toBeUndefined();
  });
});
