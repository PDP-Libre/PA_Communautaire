import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { MockPADriver } from "@factur-e/shared-fakes";

import { runPollPaIdentityStatus } from "../../src/jobs/poll-pa-identity-status.js";
import { MemorySecretStore } from "../../src/secrets/index.js";
import { setupTestDb, type TestDb } from "../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("poll-pa-identity-status job (T-CL-06 sprint-03)", () => {
  let db: TestDb;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 5, onnotice: () => undefined });
  });

  afterAll(async () => {
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  async function seed(): Promise<string> {
    const customerRows = await sql<{ id: string }[]>`
      INSERT INTO customers (siren, legal_name, profile_unverified)
      VALUES (${"100000002"}, ${"Acme"}, ${true})
      RETURNING id
    `;
    return customerRows[0]?.id ?? "";
  }

  it("transitions needs_review → verified (both axes) clears profile_unverified + audit chain", async () => {
    const customerId = await seed();
    const secrets = new MemorySecretStore();
    const driver = new MockPADriver({ scenario: "verified" });

    const ref = `superpdp-bundle-${customerId}`;
    await secrets.put(ref, {
      accessToken: "a",
      refreshToken: "r",
      accessExpiresAt: new Date().toISOString(),
    });
    await sql`
      INSERT INTO pa_connections (customer_id, secret_ref,
                                   user_identity_verification_status,
                                   company_verification_status)
      VALUES (${customerId}, ${ref}, ${"needs_review"}, ${"verified"})
    `;

    const result = await runPollPaIdentityStatus({ sql, driver, secrets });
    expect(result).toMatchObject({
      skipped: false,
      scanned: 1,
      changed: 1,
      cleared_profile_unverified: 1,
    });

    const conn = await sql<
      { user_identity_verification_status: string; company_verification_status: string }[]
    >`
      SELECT user_identity_verification_status, company_verification_status
      FROM pa_connections WHERE customer_id = ${customerId}
    `;
    expect(conn[0]?.user_identity_verification_status).toBe("verified");
    expect(conn[0]?.company_verification_status).toBe("verified");

    const cust = await sql<{ profile_unverified: boolean }[]>`
      SELECT profile_unverified FROM customers WHERE id = ${customerId}
    `;
    expect(cust[0]?.profile_unverified).toBe(false);

    const audit = await sql<{ event_type: string }[]>`
      SELECT event_type FROM auth_audit
      WHERE customer_id = ${customerId}
      ORDER BY occurred_at ASC, id ASC
    `;
    expect(audit.map((a) => a.event_type)).toEqual([
      "pa_identity_status_changed",
      "pa_profile_verified",
    ]);
  });

  it("no change → no UPDATE no audit", async () => {
    const customerId = await seed();
    const secrets = new MemorySecretStore();
    const driver = new MockPADriver({ scenario: "needs_review" }); // user=needs_review, company=verified

    const ref = `superpdp-bundle-${customerId}`;
    await secrets.put(ref, {
      accessToken: "a",
      refreshToken: "r",
      accessExpiresAt: new Date().toISOString(),
    });
    await sql`
      INSERT INTO pa_connections (customer_id, secret_ref,
                                   user_identity_verification_status,
                                   company_verification_status)
      VALUES (${customerId}, ${ref}, ${"needs_review"}, ${"verified"})
    `;

    const result = await runPollPaIdentityStatus({ sql, driver, secrets });
    expect(result).toMatchObject({ scanned: 1, changed: 0, cleared_profile_unverified: 0 });
    const audit = await sql<{ count: string }[]>`
      SELECT COUNT(*)::text AS count FROM auth_audit WHERE customer_id = ${customerId}
    `;
    expect(audit[0]?.count).toBe("0");
  });

  // ── Mécanisme 2 — cycle régressif KYC (ADR-007bis D3 → ADR-007ter D2
  //    candidat). T-CL-SIREN-RECONCILIATION sprint-06 W1. Event
  //    `pa_identity_status_pending_after_verified` émis quand un axe déjà
  //    `verified` régresse vers `needs_review` sur une connexion polled
  //    (l'autre axe étant `needs_review` — sinon la row n'est pas
  //    sélectionnée, cf. findPaConnectionsForIdentityPolling). ──────────

  async function seedConn(
    userStatus: string,
    companyStatus: string,
  ): Promise<{ customerId: string; secrets: MemorySecretStore }> {
    const rows = await sql<{ id: string }[]>`
      INSERT INTO customers (siren, legal_name, profile_unverified)
      VALUES (${"100000003"}, ${"Acme Verified"}, ${false})
      RETURNING id
    `;
    const customerId = rows[0]?.id ?? "";
    const secrets = new MemorySecretStore();
    const ref = `superpdp-bundle-${customerId}`;
    await secrets.put(ref, {
      accessToken: "a",
      refreshToken: "r",
      accessExpiresAt: new Date().toISOString(),
    });
    await sql`
      INSERT INTO pa_connections (customer_id, secret_ref,
                                   user_identity_verification_status,
                                   company_verification_status)
      VALUES (${customerId}, ${ref}, ${userStatus}, ${companyStatus})
    `;
    return { customerId, secrets };
  }

  it("régression user axis verified → needs_review → event pa_identity_status_pending_after_verified", async () => {
    // user=verified (régressera), company=needs_review (rend la row polled).
    const { customerId, secrets } = await seedConn("verified", "needs_review");
    const driver = new MockPADriver();
    driver.setIdentityStatus({ user: "needs_review", company: "needs_review" });

    const result = await runPollPaIdentityStatus({ sql, driver, secrets });
    expect(result.changed).toBe(1);

    const audit = await sql<{ event_type: string }[]>`
      SELECT event_type FROM auth_audit WHERE customer_id = ${customerId}
    `;
    const types = audit.map((a) => a.event_type);
    expect(types).toContain("pa_identity_status_changed");
    expect(types).toContain("pa_identity_status_pending_after_verified");
    // Pas de profil clear (pas verified/verified) → pas de pa_profile_verified.
    expect(types).not.toContain("pa_profile_verified");

    // profile_unverified reste FALSE (non-régression D1 ADR-007bis).
    const cust = await sql<{ profile_unverified: boolean }[]>`
      SELECT profile_unverified FROM customers WHERE id = ${customerId}
    `;
    expect(cust[0]?.profile_unverified).toBe(false);
  });

  it("régression company axis verified → needs_review → event émis", async () => {
    const { customerId, secrets } = await seedConn("needs_review", "verified");
    const driver = new MockPADriver();
    driver.setIdentityStatus({ user: "needs_review", company: "needs_review" });

    await runPollPaIdentityStatus({ sql, driver, secrets });

    const audit = await sql<{ event_type: string }[]>`
      SELECT event_type FROM auth_audit WHERE customer_id = ${customerId}
    `;
    expect(audit.map((a) => a.event_type)).toContain("pa_identity_status_pending_after_verified");
  });

  it("needs_review initial → verified (recovery, pas régression) → event NON émis", async () => {
    // Aucun axe n'était verified → la transition vers verified est une
    // récupération, pas un cycle régressif.
    const { customerId, secrets } = await seedConn("needs_review", "needs_review");
    const driver = new MockPADriver();
    driver.setIdentityStatus({ user: "verified", company: "needs_review" });

    await runPollPaIdentityStatus({ sql, driver, secrets });

    const audit = await sql<{ event_type: string }[]>`
      SELECT event_type FROM auth_audit WHERE customer_id = ${customerId}
    `;
    const types = audit.map((a) => a.event_type);
    expect(types).toContain("pa_identity_status_changed");
    expect(types).not.toContain("pa_identity_status_pending_after_verified");
  });
});
