import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { findExportRequestById, insertExportRequest } from "../../src/db/repos/export_requests.js";
import { runExportZipPurge } from "../../src/jobs/export-zip-purge.js";
import { MockObjectStorage } from "../../src/storage/object-storage.js";
import { seedInvoiceUser } from "../http/invoices/_helpers.js";
import { setupTestDb, type TestDb } from "../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("export-zip-purge cron (T-CL-EXPORT-ZIP-RETENTION)", () => {
  let db: TestDb;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 2, onnotice: () => undefined });
  });

  afterAll(async () => {
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    await sql`TRUNCATE TABLE export_requests RESTART IDENTITY CASCADE`;
  });

  async function seedCompletedExport(customerId: string, userId: string): Promise<string> {
    const req = await insertExportRequest(sql, {
      customer_id: customerId,
      requested_by_user_id: userId,
      scope: "emission",
      filters: {},
      invoice_ids: [crypto.randomUUID()],
      invoice_count: 1,
    });
    await sql`
      UPDATE export_requests
      SET status = 'completed', file_key = ${`exports/${customerId}/${req.id}.zip`},
          file_size_bytes = 1234
      WHERE id = ${req.id}
    `;
    return req.id;
  }

  it("purge les exports expirés → fichier S3 supprimé + status purged + audit", async () => {
    const seed = await seedInvoiceUser(sql);
    const id = await seedCompletedExport(seed.customerId, seed.userId);
    await sql`UPDATE export_requests SET purge_at = NOW() - INTERVAL '1 day' WHERE id = ${id}`;

    const storage = new MockObjectStorage();
    await storage.uploadObject({
      key: `exports/${seed.customerId}/${id}.zip`,
      body: Buffer.from("zip"),
      contentType: "application/zip",
    });

    const result = await runExportZipPurge({ sql, exportsStorage: storage });
    expect(result.purged).toBe(1);

    const after = await findExportRequestById(sql, id);
    expect(after?.status).toBe("purged");
    expect(after?.file_key).toBeNull();
    expect(storage.getObject(`exports/${seed.customerId}/${id}.zip`)).toBeUndefined();

    const audit = await sql<{ n: string }[]>`
      SELECT COUNT(*)::text AS n FROM auth_audit WHERE event_type = 'export_zip_purged'
    `;
    expect(Number(audit[0]?.n)).toBe(1);
  });

  it("ne purge PAS les exports non expirés (RGPD — purge_at future)", async () => {
    const seed = await seedInvoiceUser(sql);
    const id = await seedCompletedExport(seed.customerId, seed.userId);
    // purge_at par défaut = NOW() + 6 mois → non expiré.

    const result = await runExportZipPurge({ sql, exportsStorage: new MockObjectStorage() });
    expect(result.purged).toBe(0);
    const after = await findExportRequestById(sql, id);
    expect(after?.status).toBe("completed");
  });
});
