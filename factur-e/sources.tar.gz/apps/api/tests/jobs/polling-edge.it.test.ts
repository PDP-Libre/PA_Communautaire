import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { MockPADriver } from "@factur-e/shared-fakes";

import { runPollPaIdentityStatus } from "../../src/jobs/poll-pa-identity-status.js";
import { MemorySecretStore } from "../../src/secrets/index.js";
import { setupTestDb, type TestDb } from "../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("poll-pa-identity-status edge cases (T-CL-07 sprint-03)", () => {
  let db: TestDb;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 5, onnotice: () => undefined });
  });

  afterAll(async () => {
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  async function seed(opts?: { profileUnverified?: boolean }): Promise<string> {
    const profileUnverified = opts?.profileUnverified ?? true;
    const customerRows = await sql<{ id: string }[]>`
      INSERT INTO customers (siren, legal_name, profile_unverified)
      VALUES (${"100000008"}, ${"Acme"}, ${profileUnverified})
      RETURNING id
    `;
    return customerRows[0]?.id ?? "";
  }

  // ──────────────────────────────────────────────────────────────────
  // T3 — getIdentityStatus throw scenario : INSERT with needs_review
  // happened in callback (post-F2). Here we test the polling
  // sub-job catches up on the next tick when SuperPDP recovers.
  // ──────────────────────────────────────────────────────────────────

  it("T3 polling rattrape needs_review (post-F2 callback fallback) → verified", async () => {
    const customerId = await seed();
    const secrets = new MemorySecretStore();
    // Driver will return verified on this tick — simulating SuperPDP
    // recovery after the transient 5xx during the callback.
    const driver = new MockPADriver({ scenario: "verified" });

    const ref = `superpdp-bundle-${customerId}`;
    await secrets.put(ref, {
      accessToken: "a",
      refreshToken: "r",
      accessExpiresAt: new Date().toISOString(),
    });
    // Simulate the post-F2 INSERT : both axes needs_review by default
    // because callback couldn't reach getIdentityStatus.
    await sql`
      INSERT INTO pa_connections (customer_id, secret_ref,
                                   user_identity_verification_status,
                                   company_verification_status)
      VALUES (${customerId}, ${ref}, ${"needs_review"}, ${"needs_review"})
    `;

    const result = await runPollPaIdentityStatus({ sql, driver, secrets });
    expect(result).toMatchObject({ scanned: 1, changed: 1, cleared_profile_unverified: 1 });

    const conn = await sql<
      {
        user_identity_verification_status: string;
        company_verification_status: string;
      }[]
    >`
      SELECT user_identity_verification_status, company_verification_status
      FROM pa_connections WHERE customer_id = ${customerId}
    `;
    expect(conn[0]?.user_identity_verification_status).toBe("verified");
    expect(conn[0]?.company_verification_status).toBe("verified");

    const cust = await sql<{ profile_unverified: boolean }[]>`
      SELECT profile_unverified FROM customers WHERE id = ${customerId}
    `;
    expect(cust[0]?.profile_unverified).toBe(false);
  });

  // ──────────────────────────────────────────────────────────────────
  // T8 — Rejected status: track the change, no auto-promote
  // ──────────────────────────────────────────────────────────────────

  it("T8 polling rejected scenario → markIdentityStatuses + audit, no profile flip", async () => {
    const customerId = await seed();
    const secrets = new MemorySecretStore();
    const driver = new MockPADriver({ scenario: "rejected" });

    const ref = `superpdp-bundle-${customerId}`;
    await secrets.put(ref, {
      accessToken: "a",
      refreshToken: "r",
      accessExpiresAt: new Date().toISOString(),
    });
    await sql`
      INSERT INTO pa_connections (customer_id, secret_ref,
                                   user_identity_verification_status,
                                   company_verification_status)
      VALUES (${customerId}, ${ref}, ${"needs_review"}, ${"verified"})
    `;

    const result = await runPollPaIdentityStatus({ sql, driver, secrets });
    expect(result).toMatchObject({
      scanned: 1,
      changed: 1,
      cleared_profile_unverified: 0,
    });

    const conn = await sql<
      {
        user_identity_verification_status: string;
        company_verification_status: string;
      }[]
    >`
      SELECT user_identity_verification_status, company_verification_status
      FROM pa_connections WHERE customer_id = ${customerId}
    `;
    expect(conn[0]?.user_identity_verification_status).toBe("rejected");
    expect(conn[0]?.company_verification_status).toBe("rejected");

    // Profile unverified stays TRUE (the rejected status doesn't promote).
    const cust = await sql<{ profile_unverified: boolean }[]>`
      SELECT profile_unverified FROM customers WHERE id = ${customerId}
    `;
    expect(cust[0]?.profile_unverified).toBe(true);

    const audit = await sql<{ event_type: string }[]>`
      SELECT event_type FROM auth_audit
      WHERE customer_id = ${customerId}
      ORDER BY occurred_at ASC, id ASC
    `;
    expect(audit.map((a) => a.event_type)).toEqual(["pa_identity_status_changed"]);
    // Critical: no pa_profile_verified emitted.
    expect(audit.some((a) => a.event_type === "pa_profile_verified")).toBe(false);
  });

  // ──────────────────────────────────────────────────────────────────
  // T9 — Customer profile_unverified=FALSE already → no double-audit
  //  (post-F4 markCustomerProfileVerified RETURNING count guard)
  // ──────────────────────────────────────────────────────────────────

  it("T9 polling on already-verified customer (FALSE) → no pa_profile_verified audit", async () => {
    // Customer is already verified (profile_unverified=FALSE).
    // pa_connections previously had verified status, was bumped to
    // needs_review by some transient SuperPDP issue, now bouncing
    // back to verified — the polling job should NOT emit
    // pa_profile_verified again because the flag is already cleared.
    const customerId = await seed({ profileUnverified: false });
    const secrets = new MemorySecretStore();
    const driver = new MockPADriver({ scenario: "verified" });

    const ref = `superpdp-bundle-${customerId}`;
    await secrets.put(ref, {
      accessToken: "a",
      refreshToken: "r",
      accessExpiresAt: new Date().toISOString(),
    });
    await sql`
      INSERT INTO pa_connections (customer_id, secret_ref,
                                   user_identity_verification_status,
                                   company_verification_status)
      VALUES (${customerId}, ${ref}, ${"needs_review"}, ${"verified"})
    `;

    const result = await runPollPaIdentityStatus({ sql, driver, secrets });
    expect(result).toMatchObject({
      scanned: 1,
      changed: 1,
      cleared_profile_unverified: 0,
    });

    const audit = await sql<{ event_type: string }[]>`
      SELECT event_type FROM auth_audit
      WHERE customer_id = ${customerId}
      ORDER BY occurred_at ASC, id ASC
    `;
    expect(audit.map((a) => a.event_type)).toEqual(["pa_identity_status_changed"]);
    // Critical: NO pa_profile_verified (post-F4 conditional audit).
    expect(audit.some((a) => a.event_type === "pa_profile_verified")).toBe(false);
  });
});
