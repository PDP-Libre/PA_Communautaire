import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { getReceptionFixture } from "@factur-e/factur-x-fixtures";
import { MockPADriver } from "@factur-e/shared-fakes";
import { PaUnavailableException, type IncomingInvoice } from "@factur-e/pa-adapter";

import { incomingInvoiceFromFixture } from "../../src/dev-support/reception-fixtures.js";
import { findIncomingCdarEventsByReceivedInvoiceId } from "../../src/db/repos/incoming_cdar_events.js";
import { getCursor } from "../../src/db/repos/pa_polling_state.js";
import {
  findActiveReceivedInvoicesByCustomerId,
  findReceivedInvoiceByPaInvoiceIdIn,
} from "../../src/db/repos/received_invoices.js";
import { runPollReceivedInvoices } from "../../src/jobs/poll-received-invoices.js";
import { MemorySecretStore } from "../../src/secrets/index.js";
import { seedFullCustomer } from "../_fixtures/seed-customer.js";
import { setupTestDb, type TestDb } from "../helpers/test-db.js";

/**
 * T-CL-RECV-API sprint-05 W2 — Tests worker `runPollReceivedInvoices`.
 * Pattern miroir des tests `poll-cdar-events`. DB réelle + MockPADriver.
 *
 * Cas : happy (insert + cdar 204 + cursor), cursor persisté direction 'in',
 * idempotence ON CONFLICT (2 ticks même flow → 1 row), fail-safe 5xx (pas
 * d'upsert cursor + audit), advisory lock tenu → skip.
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

// Snapshot worker dérivé du corpus (rx-380-base-facturx : BQ→Tricatel,
// SIREN 000000002, total 96000c). Le `paInvoiceId` reste un paramètre libre
// (clé de mécanique : cursor / idempotence / lock), le `number` en dérive.
const BASE_INCOMING = incomingInvoiceFromFixture(getReceptionFixture("rx-380-base-facturx"));

function incoming(paInvoiceId: string): IncomingInvoice {
  return {
    ...BASE_INCOMING,
    paInvoiceId,
    enInvoice: { ...BASE_INCOMING.enInvoice, number: `FA-${paInvoiceId}` },
  };
}

describe.skipIf(!enabled)("[poll-received-invoices] worker", () => {
  let db: TestDb;
  let sql: postgres.Sql;
  let secrets: MemorySecretStore;
  let driver: MockPADriver;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 5, onnotice: () => undefined });
    secrets = new MemorySecretStore();
    driver = new MockPADriver();
  });

  afterAll(async () => {
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    await sql`DELETE FROM pa_polling_state`;
    driver.reset();
  });

  const deps = () => ({ sql, driver, secrets });

  it("happy path → INSERT received_invoices + cdar 204 + cursor avancé", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    driver.seedIncomingInvoices([incoming("45933")]);

    const result = await runPollReceivedInvoices(deps());

    expect(result.skipped).toBe(false);
    expect(result.receivedInvoicesInserted).toBe(1);

    const rows = await findActiveReceivedInvoicesByCustomerId(sql, seed.customerId);
    expect(rows).toHaveLength(1);
    expect(rows[0]?.pa_invoice_id_in).toBe("45933");
    expect(rows[0]?.seller_siren).toBe("000000002");
    expect(rows[0]?.total_ttc_cents).toBe(96000);
    expect(rows[0]?.status_current).toBe("in_process");

    const events = await findIncomingCdarEventsByReceivedInvoiceId(sql, rows[0]?.id ?? "");
    expect(events.some((e) => e.code === "fr:204" && e.source === "polling")).toBe(true);
  });

  it("cursor persisté scopé direction 'in'", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    driver.seedIncomingInvoices([incoming("100"), incoming("101")]);

    await runPollReceivedInvoices(deps());

    const cursorIn = await getCursor(sql, seed.customerId, "superpdp", "in");
    expect(cursorIn?.cursor).toBe("101");
    // La direction sortante reste vierge (pas de collision §7.5 Z9).
    const cursorOut = await getCursor(sql, seed.customerId, "superpdp", "out");
    expect(cursorOut).toBeUndefined();
  });

  it("idempotence ON CONFLICT — 2 ticks même flow → 1 row insérée", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });

    driver.seedIncomingInvoices([incoming("777")]);
    const t1 = await runPollReceivedInvoices(deps());
    expect(t1.receivedInvoicesInserted).toBe(1);

    driver.seedIncomingInvoices([incoming("777")]);
    const t2 = await runPollReceivedInvoices(deps());
    expect(t2.receivedInvoicesInserted).toBe(0);
    expect(t2.receivedInvoicesSkipped).toBe(1);

    const rows = await findActiveReceivedInvoicesByCustomerId(sql, seed.customerId);
    expect(rows).toHaveLength(1);
  });

  it("ingestion 209 entrant — snapshot rawStatusCode fr:209 → event 209 + status cancelled", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });

    // Tick 1 : facture reçue normale (in_process + 204).
    driver.seedIncomingInvoices([incoming("888")]);
    await runPollReceivedInvoices(deps());

    // Tick 2 : le fournisseur a annulé → snapshot rawStatusCode fr:209.
    driver.seedIncomingInvoices([{ ...incoming("888"), rawStatusCode: "fr:209" }]);
    await runPollReceivedInvoices(deps());

    const row = await findReceivedInvoiceByPaInvoiceIdIn(sql, seed.customerId, "888");
    expect(row?.status_current).toBe("cancelled");

    const events = await findIncomingCdarEventsByReceivedInvoiceId(sql, row?.id ?? "");
    expect(events.some((e) => e.code === "fr:209" && e.source === "polling")).toBe(true);

    // Tick 3 : re-poll annulé → idempotent (pas de second event 209).
    driver.seedIncomingInvoices([{ ...incoming("888"), rawStatusCode: "fr:209" }]);
    await runPollReceivedInvoices(deps());
    const events2 = await findIncomingCdarEventsByReceivedInvoiceId(sql, row?.id ?? "");
    expect(events2.filter((e) => e.code === "fr:209")).toHaveLength(1);
  });

  it("fail-safe 5xx → pas d'upsert cursor + errors compté (ADR-009 D1)", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    driver.setListIncomingFailure(new PaUnavailableException({ status: 503 }));

    const result = await runPollReceivedInvoices(deps());
    expect(result.errors).toBeGreaterThanOrEqual(1);
    expect(result.receivedInvoicesInserted).toBe(0);

    // Pas de cursor persisté → le tick suivant retentera le même range.
    const cursorIn = await getCursor(sql, seed.customerId, "superpdp", "in");
    expect(cursorIn).toBeUndefined();
  });

  it("advisory lock tenu par une autre session → tick skip", async () => {
    const locker = postgres(db.url, { max: 1, onnotice: () => undefined });
    try {
      await locker`SELECT pg_advisory_lock(43214)`;
      const result = await runPollReceivedInvoices(deps());
      expect(result.skipped).toBe(true);
    } finally {
      await locker`SELECT pg_advisory_unlock(43214)`;
      await locker.end();
    }
  });
});
