import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { SuperPDPDriver } from "@factur-e/pa-adapter";
import { startFakeSuperPdp, type FakeSuperPdp, MockPADriver } from "@factur-e/shared-fakes";

import { hashPassword } from "../../src/auth/argon2.js";
import type { EmailPurpose } from "../../src/email/sender.js";
import { runRefreshPaTokens } from "../../src/jobs/refresh-pa-tokens.js";
import { MemorySecretStore } from "../../src/secrets/index.js";
import { setupTestDb, type TestDb } from "../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

interface CapturedEmail {
  to: string;
  purpose: string;
}

class CapturingEmailSender {
  readonly sent: CapturedEmail[] = [];
  send(args: { to: string; purpose: EmailPurpose }): Promise<void> {
    this.sent.push({ to: args.to, purpose: args.purpose });
    return Promise.resolve();
  }
}

describe.skipIf(!enabled)("refresh-pa-tokens edge cases (T-CL-07 sprint-03)", () => {
  let db: TestDb;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 5, onnotice: () => undefined });
  });

  afterAll(async () => {
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  async function seed(siren = "100000007"): Promise<{ customerId: string; userId: string }> {
    const customerRows = await sql<{ id: string }[]>`
      INSERT INTO customers (siren, legal_name) VALUES (${siren}, ${"Acme"}) RETURNING id
    `;
    const customerId = customerRows[0]?.id ?? "";
    const hash = await hashPassword("Password123!");
    const userRows = await sql<{ id: string }[]>`
      INSERT INTO users (customer_id, email, password_hash, role)
      VALUES (${customerId}, ${"alice@acme.fr"}, ${hash}, ${"full"})
      RETURNING id
    `;
    return { customerId, userId: userRows[0]?.id ?? "" };
  }

  // ──────────────────────────────────────────────────────────────────
  // T7 — Real driver + fakeSuperPdp scenario 5xx_then_ok end-to-end
  // ──────────────────────────────────────────────────────────────────

  it("T7 refresh job + real SuperPDPDriver + fakeSuperPdp 5xx_then_ok → eventually succeeds", async () => {
    const seed_ = await seed();
    let fake: FakeSuperPdp | undefined;
    try {
      fake = await startFakeSuperPdp({ scenario: "verified" });
      const fake_ = fake;
      // Build a real driver pointed at the fake — exercise the retry
      // helper with a real fetch round-trip.
      const driver = new SuperPDPDriver({
        clientId: "test",
        clientSecret: "secret",
        baseUrl: fake_.baseUrl,
        retryOptions: { sleep: () => Promise.resolve(), backoffMs: [0, 0] },
      });
      const secrets = new MemorySecretStore();
      const email = new CapturingEmailSender();

      // Pre-seed a valid bundle by exchanging a code first (uses the
      // fake's authorization_code grant to mint a refresh token the
      // fake will accept on subsequent refresh).
      const tokens = await driver.exchangeCode({
        code: "seed-code",
        state: "s",
        expectedState: "s",
        codeVerifier: "v",
        redirectUri: "http://localhost:3001/oauth/superpdp/callback",
      });
      const ref = `superpdp-bundle-${seed_.customerId}`;
      await secrets.put(ref, {
        accessToken: tokens.accessToken,
        refreshToken: tokens.refreshToken,
        accessExpiresAt: tokens.accessExpiresAt.toISOString(),
      });
      await sql`
        INSERT INTO pa_connections (customer_id, secret_ref,
                                     user_identity_verification_status,
                                     company_verification_status,
                                     last_refreshed_at)
        VALUES (${seed_.customerId}, ${ref}, ${"verified"}, ${"verified"},
                NOW() - INTERVAL '30 minutes')
      `;

      // Arm the 5xx_then_ok scenario — the fake returns 500 on the
      // FIRST /oauth2/token hit (counter === 1) then 200 thereafter,
      // so the driver's withRetry helper kicks in and the refresh
      // succeeds on retry.
      //
      // The seed `exchangeCode` already incremented the counter, so we
      // call `resetTokenRequestCount()` to re-arm the trigger WITHOUT
      // wiping `validRefresh` (which `reset()` would do, invalidating
      // the seed refresh token). Cf. `FakeSuperPdp.resetTokenRequestCount`.
      fake_.setScenario("5xx_then_ok");
      fake_.resetTokenRequestCount();
      const result = await runRefreshPaTokens({ sql, driver, secrets, email });
      expect(result).toMatchObject({ skipped: false, refreshed: 1, failed: 0, lost: 0 });
      // Bundle was rotated.
      const stored = await secrets.get(ref);
      expect(stored?.accessToken).not.toBe(tokens.accessToken);
      // Audit recorded the success.
      const audit = await sql<{ event_type: string }[]>`
        SELECT event_type FROM auth_audit
        WHERE customer_id = ${seed_.customerId}
        ORDER BY occurred_at ASC, id ASC
      `;
      expect(audit.map((a) => a.event_type)).toEqual(["pa_token_refreshed"]);
      // The fake observed ≥2 token requests on the refresh call alone
      // (1×500 retried + 1×200 success). resetTokenRequestCount() above
      // ensured we count only post-seed traffic.
      expect(fake_.getTokenRequestCount()).toBeGreaterThanOrEqual(2);
    } finally {
      if (fake !== undefined) await fake.stop();
    }
  });

  // ──────────────────────────────────────────────────────────────────
  // T13 — Refresh job 3-strike chain end-to-end with audit + email
  // ──────────────────────────────────────────────────────────────────

  it("T13 3 consecutive RefreshExpired → audit chain + email pa_token_lost + revoke", async () => {
    const seed_ = await seed("100000013");
    const driver = new MockPADriver({ scenario: "refresh_expired" });
    const secrets = new MemorySecretStore();
    const email = new CapturingEmailSender();

    const ref = `superpdp-bundle-${seed_.customerId}`;
    await secrets.put(ref, {
      accessToken: "a",
      refreshToken: "r",
      accessExpiresAt: new Date().toISOString(),
    });
    await sql`
      INSERT INTO pa_connections (customer_id, secret_ref,
                                   user_identity_verification_status,
                                   company_verification_status,
                                   refresh_failures_count,
                                   last_refreshed_at)
      VALUES (${seed_.customerId}, ${ref}, ${"verified"}, ${"verified"},
              ${0}, NOW() - INTERVAL '30 minutes')
    `;

    // Tick 1 : count 0 → 1, failed (no email yet).
    let result = await runRefreshPaTokens({ sql, driver, secrets, email });
    expect(result).toMatchObject({ failed: 1, lost: 0 });
    // Tick 2 : count 1 → 2, failed.
    result = await runRefreshPaTokens({ sql, driver, secrets, email });
    expect(result).toMatchObject({ failed: 1, lost: 0 });
    // Tick 3 : count 2 → 3, lost (cutover).
    result = await runRefreshPaTokens({ sql, driver, secrets, email });
    expect(result).toMatchObject({ failed: 0, lost: 1 });

    expect(await secrets.get(ref)).toBeNull();
    const conn = await sql<{ deleted_at: Date | null; revoked_at: Date | null }[]>`
      SELECT deleted_at, revoked_at FROM pa_connections WHERE customer_id = ${seed_.customerId}
    `;
    expect(conn[0]?.deleted_at).not.toBeNull();
    expect(conn[0]?.revoked_at).not.toBeNull();

    expect(email.sent).toEqual([{ to: "alice@acme.fr", purpose: "pa_token_lost" }]);

    const audit = await sql<{ event_type: string }[]>`
      SELECT event_type FROM auth_audit
      WHERE customer_id = ${seed_.customerId}
      ORDER BY occurred_at ASC, id ASC
    `;
    // 3 fails (one per tick, the 3rd is a 'fail+lost' chain).
    expect(audit.map((a) => a.event_type)).toEqual([
      "pa_token_refresh_failed",
      "pa_token_refresh_failed",
      "pa_token_refresh_failed",
      "pa_token_lost",
    ]);
  });
});
