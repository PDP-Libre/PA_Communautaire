import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { findExportRequestById, insertExportRequest } from "../../src/db/repos/export_requests.js";
import { runExportZipReminder } from "../../src/jobs/export-zip-reminder.js";
import { MockEmailSender } from "../../src/email/sender.js";
import { seedInvoiceUser } from "../http/invoices/_helpers.js";
import { setupTestDb, type TestDb } from "../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("export-zip-reminder-j30 cron (T-CL-EXPORT-ZIP-RETENTION)", () => {
  let db: TestDb;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 2, onnotice: () => undefined });
  });

  afterAll(async () => {
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    await sql`TRUNCATE TABLE export_requests RESTART IDENTITY CASCADE`;
  });

  async function seedExpiringExport(customerId: string, userId: string): Promise<string> {
    const req = await insertExportRequest(sql, {
      customer_id: customerId,
      requested_by_user_id: userId,
      scope: "emission",
      filters: {},
      invoice_ids: [crypto.randomUUID()],
      invoice_count: 3,
    });
    // completed + purge_at dans 20 jours (≤ 30j) + pas de rappel envoyé.
    await sql`
      UPDATE export_requests
      SET status = 'completed', purge_at = NOW() + INTERVAL '20 days'
      WHERE id = ${req.id}
    `;
    return req.id;
  }

  it("envoie 1 email par customer + pose reminder_sent_at + audit", async () => {
    const seed = await seedInvoiceUser(sql);
    const id = await seedExpiringExport(seed.customerId, seed.userId);

    const email = new MockEmailSender();
    const result = await runExportZipReminder({ sql, email, webBaseUrl: "http://web" });
    expect(result.remindersSent).toBe(1);
    expect(email.lastSentTo("owner@test.fr")?.purpose).toBe("export_reminder");

    const after = await findExportRequestById(sql, id);
    expect(after?.reminder_sent_at).not.toBeNull();
    const audit = await sql<{ n: string }[]>`
      SELECT COUNT(*)::text AS n FROM auth_audit WHERE event_type = 'export_reminder_sent'
    `;
    expect(Number(audit[0]?.n)).toBe(1);
  });

  it("idempotence : re-run ne renvoie pas (reminder_sent_at déjà posé)", async () => {
    const seed = await seedInvoiceUser(sql);
    await seedExpiringExport(seed.customerId, seed.userId);

    const email = new MockEmailSender();
    await runExportZipReminder({ sql, email, webBaseUrl: "http://web" });
    const second = await runExportZipReminder({ sql, email, webBaseUrl: "http://web" });
    expect(second.remindersSent).toBe(0);
  });

  it("ne rappelle pas les exports hors fenêtre 30j", async () => {
    const seed = await seedInvoiceUser(sql);
    const req = await insertExportRequest(sql, {
      customer_id: seed.customerId,
      requested_by_user_id: seed.userId,
      scope: "emission",
      filters: {},
      invoice_ids: [crypto.randomUUID()],
      invoice_count: 1,
    });
    await sql`UPDATE export_requests SET status = 'completed' WHERE id = ${req.id}`;
    // purge_at par défaut = NOW() + 6 mois → hors fenêtre.

    const result = await runExportZipReminder({
      sql,
      email: new MockEmailSender(),
      webBaseUrl: "http://web",
    });
    expect(result.remindersSent).toBe(0);
  });
});
