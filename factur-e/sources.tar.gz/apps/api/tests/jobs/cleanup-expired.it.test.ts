import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { hashPassword } from "../../src/auth/argon2.js";
import { cleanupExpired } from "../../src/jobs/cleanup-expired.js";
import { setupTestDb, type TestDb } from "../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

const noopLog = { error: () => undefined };

interface CustomerSeed {
  customerId: string;
  inviterId: string;
}

async function seedInviter(sql: postgres.Sql): Promise<CustomerSeed> {
  const customerRows = await sql<{ id: string }[]>`
    INSERT INTO customers (siren, legal_name) VALUES (${"123456789"}, ${"Acme"})
    RETURNING id
  `;
  const customerId = customerRows[0]?.id;
  if (customerId === undefined) throw new Error("customer");
  const hash = await hashPassword("Password123!");
  const userRows = await sql<{ id: string }[]>`
    INSERT INTO users (customer_id, email, password_hash, role)
    VALUES (${customerId}, ${"inviter@acme.fr"}, ${hash}, ${"full"})
    RETURNING id
  `;
  const inviterId = userRows[0]?.id;
  if (inviterId === undefined) throw new Error("inviter");
  return { customerId, inviterId };
}

describe.skipIf(!enabled)("cleanup-expired job (T-CL-03 sprint-03)", () => {
  let db: TestDb;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 5, onnotice: () => undefined });
  });

  afterAll(async () => {
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  it("purges signup_pending rows past expires_at, keeps fresh ones", async () => {
    await sql`
      INSERT INTO signup_pending (email, password_hash, terms_accepted_at, expires_at)
      VALUES
        (${"old@x.fr"}, ${"h"}, NOW(), NOW() - INTERVAL '1 hour'),
        (${"old2@x.fr"}, ${"h"}, NOW(), NOW() - INTERVAL '8 days'),
        (${"fresh@x.fr"}, ${"h"}, NOW(), NOW() + INTERVAL '6 days')
    `;

    const result = await cleanupExpired(sql, noopLog);
    expect(result.skipped).toBe(false);
    if (result.skipped) return;
    expect(result.counts.signup_pending).toBe(2);

    const remaining = await sql<{ email: string }[]>`SELECT email FROM signup_pending`;
    expect(remaining.map((r) => r.email)).toEqual(["fresh@x.fr"]);
  });

  it("purges otp_codes past expires_at, keeps fresh ones", async () => {
    const seed = await seedInviter(sql);
    await sql`
      INSERT INTO otp_codes (user_id, code_hash, purpose, expires_at)
      VALUES
        (${seed.inviterId}, ${"h"}, ${"login_mfa"}, NOW() - INTERVAL '10 min'),
        (${seed.inviterId}, ${"h"}, ${"login_mfa"}, NOW() + INTERVAL '5 min')
    `;

    const result = await cleanupExpired(sql, noopLog);
    if (result.skipped) throw new Error("unexpected skip");
    expect(result.counts.otp_codes).toBe(1);

    const remaining = await sql<{ count: string }[]>`SELECT COUNT(*)::text AS count FROM otp_codes`;
    expect(remaining[0]?.count).toBe("1");
  });

  it("purges insee_cache past expires_at, keeps fresh ones", async () => {
    await sql`
      INSERT INTO insee_cache (siren, payload, expires_at)
      VALUES
        (${"100000001"}, ${sql.json({})}, NOW() - INTERVAL '1 day'),
        (${"100000002"}, ${sql.json({})}, NOW() + INTERVAL '30 days')
    `;

    const result = await cleanupExpired(sql, noopLog);
    if (result.skipped) throw new Error("unexpected skip");
    expect(result.counts.insee_cache).toBe(1);

    const remaining = await sql<{ siren: string }[]>`SELECT siren FROM insee_cache`;
    expect(remaining.map((r) => r.siren)).toEqual(["100000002"]);
  });

  it("purges directory_cache past expires_at, keeps fresh ones (T-CL-10)", async () => {
    await sql`
      INSERT INTO directory_cache (siren, payload, addresses, fetched_at, expires_at)
      VALUES
        (${"100000001"}, ${sql.json({})}, ${sql.json([])},
         NOW() - INTERVAL '1 hour', NOW() - INTERVAL '30 min'),
        (${"100000002"}, ${sql.json({})}, ${sql.json([])},
         NOW(), NOW() + INTERVAL '15 min')
    `;

    const result = await cleanupExpired(sql, noopLog);
    if (result.skipped) throw new Error("unexpected skip");
    expect(result.counts.directory_cache).toBe(1);

    const remaining = await sql<{ siren: string }[]>`SELECT siren FROM directory_cache`;
    expect(remaining.map((r) => r.siren)).toEqual(["100000002"]);
  });

  it("purges expired unaccepted invitations, keeps accepted + fresh", async () => {
    const seed = await seedInviter(sql);
    // Accepted (expired but accepted_at set) — kept as audit history.
    await sql`
      INSERT INTO invitations (id, customer_id, inviter_id, email, role,
                               can_purchase, token_hash, expires_at, accepted_at)
      VALUES (gen_random_uuid(), ${seed.customerId}, ${seed.inviterId},
              ${"accepted@x.fr"}, ${"deposit_simple"}, ${false},
              ${"h-accepted"}, NOW() - INTERVAL '8 days', NOW() - INTERVAL '7 days')
    `;
    // Expired + unaccepted — purged.
    await sql`
      INSERT INTO invitations (id, customer_id, inviter_id, email, role,
                               can_purchase, token_hash, expires_at)
      VALUES (gen_random_uuid(), ${seed.customerId}, ${seed.inviterId},
              ${"stale@x.fr"}, ${"deposit_simple"}, ${false},
              ${"h-stale"}, NOW() - INTERVAL '8 days')
    `;
    // Fresh + unaccepted — kept.
    await sql`
      INSERT INTO invitations (id, customer_id, inviter_id, email, role,
                               can_purchase, token_hash, expires_at)
      VALUES (gen_random_uuid(), ${seed.customerId}, ${seed.inviterId},
              ${"fresh@x.fr"}, ${"deposit_simple"}, ${false},
              ${"h-fresh"}, NOW() + INTERVAL '7 days')
    `;

    const result = await cleanupExpired(sql, noopLog);
    if (result.skipped) throw new Error("unexpected skip");
    expect(result.counts.invitations).toBe(1);

    const remaining = await sql<{ email: string }[]>`
      SELECT email FROM invitations ORDER BY email
    `;
    expect(remaining.map((r) => r.email)).toEqual(["accepted@x.fr", "fresh@x.fr"]);
  });

  it("idempotent — second run on a clean state purges 0 rows", async () => {
    await sql`
      INSERT INTO signup_pending (email, password_hash, terms_accepted_at, expires_at)
      VALUES (${"old@x.fr"}, ${"h"}, NOW(), NOW() - INTERVAL '1 hour')
    `;
    const first = await cleanupExpired(sql, noopLog);
    if (first.skipped) throw new Error("unexpected skip");
    expect(first.counts.signup_pending).toBe(1);

    const second = await cleanupExpired(sql, noopLog);
    if (second.skipped) throw new Error("unexpected skip");
    expect(second.counts.signup_pending).toBe(0);
    expect(second.counts.otp_codes).toBe(0);
    expect(second.counts.insee_cache).toBe(0);
    expect(second.counts.invitations).toBe(0);
    expect(second.counts.directory_cache).toBe(0);
  });

  it("skipped when another replica already holds the advisory lock", async () => {
    // Simulate a peer pod holding the lock by acquiring it on a separate
    // connection ourselves. The function under test should fall through
    // to `skipped: true` immediately.
    const peer = postgres(db.url, { max: 1, onnotice: () => undefined });
    try {
      const lockRows = await peer<{ acquired: boolean }[]>`
        SELECT pg_try_advisory_lock(43210) AS acquired
      `;
      expect(lockRows[0]?.acquired).toBe(true);

      const result = await cleanupExpired(sql, noopLog);
      expect(result).toEqual({ skipped: true, reason: "lock_held" });

      await peer`SELECT pg_advisory_unlock(43210)`;
    } finally {
      await peer.end();
    }
  });

  it("graceful per-table — error on one table does not starve the others", async () => {
    await sql`
      INSERT INTO signup_pending (email, password_hash, terms_accepted_at, expires_at)
      VALUES (${"old@x.fr"}, ${"h"}, NOW(), NOW() - INTERVAL '1 hour')
    `;
    await sql`
      INSERT INTO insee_cache (siren, payload, expires_at)
      VALUES (${"100000001"}, ${sql.json({})}, NOW() - INTERVAL '1 day')
    `;

    // Inject failure on signup_pending DELETE via a BEFORE DELETE
    // trigger that always raises. That's the cleanest no-mock fault
    // injection — works in plain Postgres, scoped to this test, no
    // privileges or roles required.
    await sql.unsafe(`
      CREATE OR REPLACE FUNCTION test_signup_pending_fail() RETURNS TRIGGER AS $$
      BEGIN
        RAISE EXCEPTION 'injected delete failure';
      END;
      $$ LANGUAGE plpgsql;
      CREATE TRIGGER test_signup_pending_fail_t
      BEFORE DELETE ON signup_pending
      FOR EACH ROW EXECUTE FUNCTION test_signup_pending_fail();
    `);

    try {
      const errors: { table: unknown }[] = [];
      const log = { error: (obj: { table: unknown }) => errors.push(obj) };
      const result = await cleanupExpired(sql, log);
      if (result.skipped) throw new Error("unexpected skip");

      // signup_pending step failed → null sentinel.
      expect(result.counts.signup_pending).toBeNull();
      // The other tables ran independently.
      expect(result.counts.otp_codes).toBe(0);
      expect(result.counts.insee_cache).toBe(1);
      expect(result.counts.invitations).toBe(0);
      expect(result.counts.directory_cache).toBe(0);

      // Logged the per-table failure.
      expect(errors.some((e) => e.table === "signup_pending")).toBe(true);

      // signup_pending row still there — the trigger raised before
      // the DELETE could proceed.
      const remaining = await sql<{ count: string }[]>`
        SELECT COUNT(*)::text AS count FROM signup_pending
      `;
      expect(remaining[0]?.count).toBe("1");
    } finally {
      await sql.unsafe(`
        DROP TRIGGER IF EXISTS test_signup_pending_fail_t ON signup_pending;
        DROP FUNCTION IF EXISTS test_signup_pending_fail();
      `);
    }
  });
});
