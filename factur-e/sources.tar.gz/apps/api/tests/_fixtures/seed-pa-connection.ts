/**
 * Helper bas-niveau pour seeder une `pa_connections` (+ option
 * `MemorySecretStore` bundle). Réutilisé par `seedFullCustomer` mais
 * aussi consommable directement par les tests multi-PA / régression
 * `profile_unverified` qui veulent contrôler finement les statuts ou
 * ré-attacher un provider différent à un customer existant.
 */

import type postgres from "postgres";

import type { MemorySecretStore, PaTokenBundle } from "../../src/secrets/index.js";

export type SeedPaConnectionProvider = "superpdp" | "esalink";
export type SeedPaIdentityStatus = "verified" | "needs_review" | "rejected";

export interface SeedPaConnectionOptions {
  customerId: string;
  /** Provider PA. V1 = `'superpdp'` (default). `'esalink'` accepté pour
   *  les tests multi-PA même si l'instanciation runtime est gated par
   *  `ENABLE_ESALINK_PROVIDER` (cf. registry). */
  provider: SeedPaConnectionProvider;
  /** Statuts d'identité posés sur la ligne — default `verified`/`verified`
   *  (cas happy). Bascule `needs_review` pour entrée régression
   *  ADR-007bis. */
  identityStatus?: {
    user?: SeedPaIdentityStatus;
    company?: SeedPaIdentityStatus;
  };
  /** Identifiant utilisateur côté PA (default `pa-user-${customerId}`). */
  paUserId?: string;
  /** `secret_ref` explicite (default `test-bundle-${customerId}`). Le
   *  bundle écrit dans `secretStore` (si fourni) est lié à cette clé. */
  secretRef?: string;
  /** Bundle complet ou override partiel — default `accessToken /
   *  refreshToken` synthétiques + TTL 30 min. */
  bundle?: Partial<PaTokenBundle>;
  /** Si fourni, le bundle est écrit dans le store. Sans store, la
   *  `pa_connection` est seedée mais `secrets.get(secret_ref)` retournera
   *  `null` côté apps/api (déclenche path 401 endpoint create.ts:143). */
  secretStore?: MemorySecretStore;
}

export interface SeedPaConnectionResult {
  paConnectionId: string;
  secretRef: string;
}

export async function seedPaConnection(
  sql: postgres.Sql,
  opts: SeedPaConnectionOptions,
): Promise<SeedPaConnectionResult> {
  const userStatus = opts.identityStatus?.user ?? "verified";
  const companyStatus = opts.identityStatus?.company ?? "verified";
  const paUserId = opts.paUserId ?? `pa-user-${opts.customerId.slice(0, 8)}`;
  const secretRef = opts.secretRef ?? `test-bundle-${opts.customerId}`;

  const rows = await sql<{ id: string }[]>`
    INSERT INTO pa_connections (
      customer_id, provider, pa_user_id, secret_ref,
      user_identity_verification_status, company_verification_status,
      connected_at
    ) VALUES (
      ${opts.customerId}, ${opts.provider}, ${paUserId}, ${secretRef},
      ${userStatus}, ${companyStatus}, NOW()
    )
    RETURNING id
  `;
  const paConnectionId = rows[0]?.id ?? "";

  if (opts.secretStore !== undefined) {
    const bundle: PaTokenBundle = {
      accessToken: opts.bundle?.accessToken ?? `test-access-${opts.customerId.slice(0, 8)}`,
      refreshToken: opts.bundle?.refreshToken ?? `test-refresh-${opts.customerId.slice(0, 8)}`,
      accessExpiresAt:
        opts.bundle?.accessExpiresAt ?? new Date(Date.now() + 1800 * 1000).toISOString(),
    };
    await opts.secretStore.put(secretRef, bundle);
  }

  return { paConnectionId, secretRef };
}
