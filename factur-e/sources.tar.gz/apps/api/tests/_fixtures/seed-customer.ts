/**
 * Fixtures BDD paramétrables — T-CL-TEST-INTEGRATION sprint-04.
 *
 * Wrappe le pattern de seeding sprint-03/04 (`tests/http/invoices/_helpers.ts`
 * → `seedInvoiceUser`) avec une signature plus large pour couvrir les
 * scénarios fail-safe ADR-009 et ADR-007bis :
 *
 *  - `withDirectoryAddress: false`   → `directory_address = NULL`, déclenche
 *    le path 412 endpoint `create.ts:154`.
 *  - `withIban: false`               → `iban` / `bic` à NULL, branche
 *    mapping fail `INVALID_PAYMENT_METHOD_MISSING_IBAN`.
 *  - `peppolAddress`                 → identifiant annuaire arbitraire (cas
 *    sandbox réel BQ/Tricatel — annuaire SuperPDP propriétaire).
 *  - `identityStatus`                → bascule `pa_connections.user_*` /
 *    `company_verification_status` (régression `profile_unverified`).
 *  - `profileUnverified`             → bascule `customers.profile_unverified`
 *    (entrée régression ADR-007bis cas #13).
 *
 * `seedPaConnection` (cf. `seed-pa-connection.ts`) reste le helper bas-niveau
 * pour seeder une connexion PA sans toucher au customer (ex. ré-attacher un
 * provider différent sur un customer existant).
 *
 * ─────────────────────────────────────────────────────────────────────
 * [NOTE-COWORK 2026-05-20] — Délégation sandbox + identifiants Peppol
 * ─────────────────────────────────────────────────────────────────────
 *
 * Le compte Bruno SuperPDP a accès aux 2 entreprises **Burger Queen** +
 * **Tricatel** via une application déléguée. Côté Factur-E, on modélise
 * via **2 users distincts** (`bq@dev` + `tricatel@dev`) chacun associé à
 * 1 customer. Lors du OAuth Factur-E, Bruno choisit la délégation
 * correspondante côté tunnel SuperPDP.
 *
 * Les identifiants Peppol annuaire SuperPDP suivent le pattern
 * **propriétaire** `0225:<SIREN_SuperPDP_partner>_<suffix_interne>` (ex.
 * `0225:315143296_3685` Tricatel, `0225:315143296_3686` Burger Queen) —
 * **non dérivables du SIREN customer**. La récupération automatique est
 * planifiée **T-CW-STUDY-PEPPOL-DIRECTORY** + **T-CL-PA-DIRECTORY-PEPPOL**
 * sprint-05.
 *
 * Pour sprint-04 tests :
 *  - `fakeSuperPdp`/`MockPADriver` ne valident pas l'annuaire → fixtures
 *    par défaut `'0225:${siren}'` OK pour la plupart des cas.
 *  - Tests cross-company réalistes → utiliser `FIXTURE_BURGER_QUEEN` +
 *    `FIXTURE_TRICATEL` avec identifiants annuaire exacts (cohérence avec
 *    T-BR-EMIT sandbox réelle).
 */

import { randomUUID } from "node:crypto";

import type postgres from "postgres";

import { hashPassword } from "../../src/auth/argon2.js";
import { signAccessToken } from "../../src/auth/jwt.js";
import type { MemorySecretStore } from "../../src/secrets/index.js";

import { seedPaConnection } from "./seed-pa-connection.js";

export type SeedIdentityStatus = "verified" | "needs_review" | "rejected";

export interface SeedCustomerOptions {
  /** SIREN 9 chiffres (default généré aléatoirement unique par test). */
  readonly siren?: string;
  /** Raison sociale (default `'Test ${siren}'`). */
  readonly legalName?: string;
  /**
   * Default `true`. Si `false`, `customers.directory_address = NULL`
   * (déclenche path 412 endpoint create.ts:154).
   */
  readonly withDirectoryAddress?: boolean;
  /**
   * Override de l'identifiant Peppol annuaire. Default
   * `'0225:${siren}_dgfip'` (peuplement par convention, NON valide pour
   * SuperPDP sandbox réelle — cf. NOTE-COWORK ci-dessus). Pour sandbox
   * réelle, passer la valeur exacte (ex. `'0225:315143296_3685'`
   * Tricatel).
   */
  readonly peppolAddress?: string;
  /**
   * Default `true`. Si `false`, `iban` / `bic` à NULL (branche
   * `INVALID_PAYMENT_METHOD_MISSING_IBAN`).
   */
  readonly withIban?: boolean;
  /**
   * IBAN explicite (sinon valeur défaut `FR76…0189`). Ignoré si
   * `withIban === false`.
   */
  readonly iban?: string;
  /** BIC explicite (sinon `AGRIFRPP`). Ignoré si `withIban === false`. */
  readonly bic?: string;
  /** Numéro TVA intracom (default `FR12345678901`, `null` accepté). */
  readonly vatNumber?: string | null;
  /**
   * Statuts d'identité sur `pa_connections` (default `verified`/`verified`).
   * Utile pour cas #13 `verified → needs_review → verified`.
   */
  readonly identityStatus?: {
    user?: SeedIdentityStatus;
    company?: SeedIdentityStatus;
  };
  /**
   * Default `false`. Si `true`, `customers.profile_unverified = true`
   * (régression ADR-007bis — point d'entrée du cas #13).
   */
  readonly profileUnverified?: boolean;
  /**
   * Default `true`. Crée un user Factur-E + retourne un access token JWT
   * signé valide. Si `false`, `userId` et `bearer` retournés vides — utile
   * pour tester le path 401 sans authent.
   */
  readonly withUser?: boolean;
  /** Email du user (default `test+${siren}@factur-e.local`). */
  readonly userEmail?: string;
  /**
   * Default `true`. Crée une `pa_connections` `'superpdp'` + provisionne
   * un `PaTokenBundle` dans le `MemorySecretStore` (si fourni). Si
   * `false`, customer + user seuls sont créés (cas isolation onboarding).
   */
  readonly withPaConnection?: boolean;
  /**
   * `MemorySecretStore` injecté dans `buildTestApp` — utilisé pour
   * stocker le bundle `{accessToken, refreshToken, accessExpiresAt}` au
   * `secret_ref` canonique. Sans cet argument et `withPaConnection=true`,
   * la `pa_connection` est seedée mais le bundle est absent (déclenche
   * path 401 endpoint create.ts:143).
   */
  readonly secretStore?: MemorySecretStore;
}

export interface SeedCustomerResult {
  customerId: string;
  /** Identifiant user Factur-E créé (vide si `withUser=false`). */
  userId: string;
  /** Alias `accessToken`/`bearer` — JWT HS256 signé pour ce user.
   *  Utilisable comme `Authorization: Bearer` ou `?token=` (post fix
   *  T-CL-WEB-CDAR). Vide si `withUser=false`. */
  bearer: string;
  /** Idem `bearer` — alias pour matcher la signature brief §3.4. */
  accessToken: string;
  siren: string;
  /** Identifiant Peppol annuaire effectivement persisté (ou `null` si
   *  `withDirectoryAddress=false`). */
  peppolAddress: string | null;
  /** `secret_ref` de la `pa_connection` seedée (`null` si
   *  `withPaConnection=false`). */
  paSecretRef: string | null;
}

/** Génère un SIREN test unique (9 chiffres). Préserve l'unicité entre
 *  tests même quand `resetAuthTables()` n'est pas exécuté entre les
 *  blocs (rare mais protège du flake). */
function randomSiren(): string {
  // 9 chiffres aléatoires — pas de check Luhn (les SIREN test repos
  // sprint-03 ne sont pas Luhn-valides non plus).
  return Math.floor(100_000_000 + Math.random() * 899_999_999).toString();
}

/**
 * Seed customer + user + (option) pa_connection. Source de vérité unique
 * pour les tests d'intégration HTTP sprint-04.
 *
 * cf. brief T-CL-TEST-INTEGRATION §3.4 livrable #1.
 */
export async function seedFullCustomer(
  sql: postgres.Sql,
  opts: SeedCustomerOptions = {},
): Promise<SeedCustomerResult> {
  const siren = opts.siren ?? randomSiren();
  const legalName = opts.legalName ?? `Test ${siren}`;
  const withDirectoryAddress = opts.withDirectoryAddress ?? true;
  const withIban = opts.withIban ?? true;
  const withUser = opts.withUser ?? true;
  const withPaConnection = opts.withPaConnection ?? true;
  const profileUnverified = opts.profileUnverified ?? false;
  const peppolAddress = withDirectoryAddress ? (opts.peppolAddress ?? `0225:${siren}_dgfip`) : null;

  const address = {
    line_one: "12 rue de la Paix",
    postcode: "75002",
    city: "Paris",
    country_code: "FR",
  };

  const iban = withIban ? (opts.iban ?? "FR7630006000011234567890189") : null;
  const bic = withIban ? (opts.bic ?? "AGRIFRPP") : null;
  const vatNumber = opts.vatNumber === undefined ? "FR12345678901" : opts.vatNumber;

  const customerRows = await sql<{ id: string }[]>`
    INSERT INTO customers (
      siren, legal_name, address, iban, bic, vat_number,
      directory_address, profile_unverified,
      siren_unverified, legal_name_unverified, address_unverified,
      vat_number_unverified
    )
    VALUES (
      ${siren}, ${legalName}, ${sql.json(address)},
      ${iban}, ${bic}, ${vatNumber},
      ${peppolAddress}, ${profileUnverified},
      ${profileUnverified}, ${profileUnverified}, ${profileUnverified},
      ${profileUnverified}
    )
    RETURNING id
  `;
  const customerId = customerRows[0]?.id ?? "";

  let userId = "";
  let bearer = "";
  if (withUser) {
    const email = opts.userEmail ?? `test+${siren}@factur-e.local`;
    const hash = await hashPassword("Password123!");
    const userRows = await sql<{ id: string }[]>`
      INSERT INTO users (customer_id, email, password_hash, role)
      VALUES (${customerId}, ${email}, ${hash}, 'full')
      RETURNING id
    `;
    userId = userRows[0]?.id ?? "";
    bearer = await signAccessToken({ user_id: userId, customer_id: customerId });
  }

  let paSecretRef: string | null = null;
  if (withPaConnection) {
    const userStatus: SeedIdentityStatus = opts.identityStatus?.user ?? "verified";
    const companyStatus: SeedIdentityStatus = opts.identityStatus?.company ?? "verified";
    const seeded = await seedPaConnection(sql, {
      customerId,
      provider: "superpdp",
      identityStatus: { user: userStatus, company: companyStatus },
      secretStore: opts.secretStore,
      paUserId: `pa-user-${siren}`,
    });
    paSecretRef = seeded.secretRef;
  }

  return {
    customerId,
    userId,
    bearer,
    accessToken: bearer,
    siren,
    peppolAddress,
    paSecretRef,
  };
}

// ─────────────────────────────────────────────────────────────────────
// Fixtures sandbox réels — cf. NOTE-COWORK 2026-05-20 ci-dessus.
// ─────────────────────────────────────────────────────────────────────

/** Burger Queen — sandbox SuperPDP. Compte Bruno délégué via application.
 *  Identifiant annuaire propriétaire SuperPDP (non dérivable du SIREN). */
export const FIXTURE_BURGER_QUEEN = {
  siren: "000000002",
  legalName: "Burger Queen",
  peppolAddressPrimary: "0225:315143296_3686",
  peppolAddressReplyto: "0225:315143296_3686_replyto",
} as const;

/** Tricatel — sandbox SuperPDP. Compte Bruno délégué via application. */
export const FIXTURE_TRICATEL = {
  siren: "000000001",
  legalName: "Tricatel",
  peppolAddressPrimary: "0225:315143296_3685",
  peppolAddressReplyto: "0225:315143296_3685_replyto",
} as const;

/** Seed customer Burger Queen avec son user dédié. */
export function seedBurgerQueen(
  sql: postgres.Sql,
  opts: { userEmail?: string; secretStore?: MemorySecretStore } = {},
): Promise<SeedCustomerResult> {
  return seedFullCustomer(sql, {
    siren: FIXTURE_BURGER_QUEEN.siren,
    legalName: FIXTURE_BURGER_QUEEN.legalName,
    peppolAddress: FIXTURE_BURGER_QUEEN.peppolAddressPrimary,
    userEmail: opts.userEmail ?? "bq@dev.factur-e.local",
    secretStore: opts.secretStore,
  });
}

/** Seed customer Tricatel avec son user dédié. */
export function seedTricatel(
  sql: postgres.Sql,
  opts: { userEmail?: string; secretStore?: MemorySecretStore } = {},
): Promise<SeedCustomerResult> {
  return seedFullCustomer(sql, {
    siren: FIXTURE_TRICATEL.siren,
    legalName: FIXTURE_TRICATEL.legalName,
    peppolAddress: FIXTURE_TRICATEL.peppolAddressPrimary,
    userEmail: opts.userEmail ?? "tricatel@dev.factur-e.local",
    secretStore: opts.secretStore,
  });
}

/** Helper composite — seed Burger Queen + Tricatel en parallèle. Utile
 *  pour scénarios cross-company (BQ émet → Tricatel buyer). */
export async function seedBurgerQueenTricatelPair(
  sql: postgres.Sql,
  opts: { secretStore?: MemorySecretStore } = {},
): Promise<{ bq: SeedCustomerResult; tricatel: SeedCustomerResult }> {
  const bq = await seedBurgerQueen(sql, { secretStore: opts.secretStore });
  const tricatel = await seedTricatel(sql, { secretStore: opts.secretStore });
  return { bq, tricatel };
}

// ─────────────────────────────────────────────────────────────────────
// Helper formulaire — `FixtureFormBase` portable réutilisable par les
// nouveaux tests sans dupliquer la shape Zod. Pattern existant
// `tests/http/invoices/_helpers.ts:fixtureFormBase` conservé pour
// rétro-compat (5 tests existants l'utilisent) ; ce wrapper expose une
// variante qui peut s'aligner sur le seed paramétré (numéro auto, buyer
// configurable via override shallow).
// ─────────────────────────────────────────────────────────────────────

export interface FixtureFormBaseOpts {
  number?: string;
  buyerSiren?: string;
  buyerLegalName?: string;
  buyerPeppolAddress?: string;
}

export function fixtureFormBaseDynamic(opts: FixtureFormBaseOpts = {}): {
  ui_mode: "base";
  document: { number: string; issueDate: string; notes: string | null };
  parties: {
    buyer: {
      siren: string;
      legalName: string;
      address: {
        lineOne: string | null;
        lineTwo: string | null;
        postcode: string;
        city: string;
        countryCode: string;
      };
      electronicAddress: string;
      electronicAddressScheme: string;
    };
  };
  lines: {
    label: string;
    description: string | null;
    quantity: string;
    unitCode: string;
    unitPriceHt: string;
    vatCategory: "S";
    vatRate: string | null;
    totalHt: string;
  }[];
  payment: {
    paymentTerms: { kind: "days"; days: number };
    paymentMethodKind: "transfer";
    mentionsLegales: string | null;
  };
} {
  const peppol = opts.buyerPeppolAddress ?? "0225:987654321_dgfip";
  const scheme = peppol.split(":")[0] ?? "0225";
  const value = peppol.includes(":") ? peppol.slice(peppol.indexOf(":") + 1) : peppol;
  return {
    ui_mode: "base",
    document: {
      number: opts.number ?? `F-${randomUUID().slice(0, 8)}`,
      issueDate: "2026-05-16",
      notes: null,
    },
    parties: {
      buyer: {
        siren: opts.buyerSiren ?? "987654321",
        legalName: opts.buyerLegalName ?? "Client Corp",
        address: {
          lineOne: "5 avenue des Champs",
          lineTwo: null,
          postcode: "69000",
          city: "Lyon",
          countryCode: "FR",
        },
        electronicAddress: value,
        electronicAddressScheme: scheme,
      },
    },
    lines: [
      {
        label: "Prestation conseil",
        description: null,
        quantity: "1",
        unitCode: "HUR",
        unitPriceHt: "500.00",
        vatCategory: "S",
        vatRate: "20.00",
        totalHt: "500.00",
      },
    ],
    payment: {
      paymentTerms: { kind: "days", days: 30 },
      paymentMethodKind: "transfer",
      mentionsLegales: null,
    },
  };
}
