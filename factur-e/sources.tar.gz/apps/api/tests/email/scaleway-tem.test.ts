import { describe, expect, it } from "vitest";

import { ScalewayTemSender } from "../../src/email/scaleway-tem.js";

interface CapturedRequest {
  url: string;
  method: string;
  headers: Record<string, string>;
  body: Record<string, unknown>;
}

function makeFetchSpy(status = 200, responseBody = "{}") {
  const calls: CapturedRequest[] = [];
  const fakeFetch: typeof globalThis.fetch = (input, init) => {
    const url =
      typeof input === "string" ? input : input instanceof URL ? input.toString() : input.url;
    const headersRecord: Record<string, string> = {};
    const rawHeaders = init?.headers;
    if (rawHeaders !== undefined) {
      if (rawHeaders instanceof Headers) {
        rawHeaders.forEach((v, k) => {
          headersRecord[k] = v;
        });
      } else if (Array.isArray(rawHeaders)) {
        for (const pair of rawHeaders as [string, string][]) {
          headersRecord[pair[0]] = pair[1];
        }
      } else {
        for (const [k, v] of Object.entries(rawHeaders as Record<string, string>)) {
          headersRecord[k.toLowerCase()] = v;
        }
      }
    }
    const bodyRaw = typeof init?.body === "string" ? init.body : "{}";
    calls.push({
      url,
      method: init?.method ?? "GET",
      headers: headersRecord,
      body: JSON.parse(bodyRaw) as Record<string, unknown>,
    });
    return Promise.resolve(new Response(responseBody, { status }));
  };
  return { calls, fakeFetch };
}

describe("ScalewayTemSender", () => {
  it("POSTs to fr-par regional endpoint with X-Auth-Token + JSON body", async () => {
    const { calls, fakeFetch } = makeFetchSpy(200);
    const sender = new ScalewayTemSender({
      apiKey: "fake-key-test-only",
      projectId: "fake-project",
      fromEmail: "noreply@dev.factur-e.fr",
      fetch: fakeFetch,
    });

    await sender.send({
      to: "alice@acme.fr",
      purpose: "login_mfa_otp",
      payload: { otp_code: "123456" },
    });

    expect(calls).toHaveLength(1);
    const c = calls[0];
    if (c === undefined) throw new Error("no call");
    expect(c.method).toBe("POST");
    expect(c.url).toMatch(
      /^https:\/\/api\.scaleway\.com\/transactional-email\/v1alpha1\/regions\/fr-par\/emails$/,
    );
    expect(c.headers["x-auth-token"]).toBe("fake-key-test-only");
    expect(c.headers["content-type"]).toBe("application/json");
    expect(c.body.project_id).toBe("fake-project");
    expect(c.body.from).toEqual({ email: "noreply@dev.factur-e.fr", name: "Factur-e" });
    expect(c.body.to).toEqual([{ email: "alice@acme.fr" }]);
    const subject = c.body.subject as string;
    // Issue #1 — pas de PII dans le subject (le code reste dans le body).
    expect(subject).not.toContain("123456");
    expect(subject).toMatch(/Code/);
    const text = c.body.text as string;
    expect(text).toContain("123456");
    const html = c.body.html as string;
    expect(html).toContain("123456");
  });

  it("renders the verify-email template with the magic link URL", async () => {
    const { calls, fakeFetch } = makeFetchSpy(200);
    const sender = new ScalewayTemSender({
      apiKey: "k",
      projectId: "p",
      fromEmail: "noreply@factur-e.fr",
      fetch: fakeFetch,
    });
    await sender.send({
      to: "bob@acme.fr",
      purpose: "phase1_email_verify_otp",
      payload: { magic_link: "https://app.factur-e.fr/onboarding/email-verify?token=xyz" },
    });
    const html = calls[0]?.body.html as string;
    expect(html).toContain("https://app.factur-e.fr/onboarding/email-verify?token=xyz");
  });

  it("throws on non-2xx with body excerpt", async () => {
    const { fakeFetch } = makeFetchSpy(403, "Forbidden by API quota");
    const sender = new ScalewayTemSender({
      apiKey: "k",
      projectId: "p",
      fromEmail: "noreply@factur-e.fr",
      fetch: fakeFetch,
    });
    await expect(
      sender.send({
        to: "x@y.fr",
        purpose: "password_reset",
        payload: { magic_link: "https://app.factur-e.fr/reset-password?token=xyz" },
      }),
    ).rejects.toThrow(/403/);
  });
});
