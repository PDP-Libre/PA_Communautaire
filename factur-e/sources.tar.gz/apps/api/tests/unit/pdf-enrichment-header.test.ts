import { describe, expect, it } from "vitest";

import { InvoiceFormSchema } from "@factur-e/shared-schemas";

import {
  headerMentionFromForm,
  headerMentionFromPayload,
} from "../../src/services/pdf-enrichment.js";

/**
 * F7 (W2 sprint-08) — source de la mention d'en-tête PDF (BT-22
 * `generalComments`). À l'émission depuis le form live (mode avancé) ; à la
 * régénération depuis `payload_extended.generalComments` (jsonb non typé). Le
 * placement/rendu est prouvé côté builder (template-context F7) ; ici on couvre
 * l'extraction de la valeur par les deux chemins.
 */

const advancedForm = InvoiceFormSchema.parse({
  ui_mode: "advanced",
  document: {
    number: "FX-ADV-001",
    issueDate: "2026-06-01",
    typeCode: "380",
    currency: "EUR",
    processingRule: "B2B",
    buyerOrderRef: null,
    sellerOrderRef: null,
    contractRef: null,
    projectRef: null,
    billingPeriod: null,
    notes: "Note publique.",
    privateComments: null,
    footerMentions: null,
    generalComments: "Mention d'en-tête corpus : marché AUDIT-Q2.",
  },
  parties: {
    buyer: {
      siren: "000000001",
      legalName: "Tricatel",
      address: { postcode: "75011", city: "Paris", countryCode: "FR" },
      electronicAddress: "0225:315143296_3685",
      electronicAddressScheme: "0225",
    },
    shipping: null,
    deliveryDate: null,
    clientTaxRegime: "default",
    transporter: null,
    trackingNumber: null,
  },
  lines: [
    {
      label: "Prestation",
      description: null,
      quantity: "1",
      unitCode: "C62",
      unitPriceHt: "100.00",
      vatCategory: "S",
      vatRate: "20.00",
      totalHt: "100.00",
      vatex: null,
      period: null,
      allowance: null,
      longDescription: null,
      note: null,
      basisQuantity: null,
    },
  ],
  documentLevelAllowance: null,
  shippingCostHt: null,
  shippingCostVatCategory: null,
  shippingCostVatRate: null,
  incoterm: null,
  payment: {
    paymentTerms: { kind: "days", days: 30 },
    paymentMethodKind: "transfer",
    paymentMeansCode: null,
    creditorReference: null,
    prepaidAmount: null,
    customPenalties: null,
    mentionsLegales: null,
  },
});

describe("headerMentionFromForm — émission (form live)", () => {
  it("retourne generalComments en mode avancé", () => {
    expect(headerMentionFromForm(advancedForm)).toBe("Mention d'en-tête corpus : marché AUDIT-Q2.");
  });

  it("retourne undefined si generalComments vide", () => {
    const form = InvoiceFormSchema.parse({
      ...advancedForm,
      document: { ...advancedForm.document, generalComments: "" },
    });
    expect(headerMentionFromForm(form)).toBeUndefined();
  });

  it("retourne undefined en mode base (pas de champ generalComments)", () => {
    const baseForm = InvoiceFormSchema.parse({
      ui_mode: "base",
      document: { number: "FX-BASE-001", issueDate: "2026-06-01", notes: null },
      parties: { buyer: advancedForm.parties.buyer },
      lines: [
        {
          label: "Prestation",
          description: null,
          quantity: "1",
          unitCode: "C62",
          unitPriceHt: "100.00",
          vatCategory: "S",
          vatRate: "20.00",
          totalHt: "100.00",
        },
      ],
      payment: {
        paymentTerms: { kind: "days", days: 30 },
        paymentMethodKind: "transfer",
        mentionsLegales: null,
      },
    });
    expect(headerMentionFromForm(baseForm)).toBeUndefined();
  });
});

describe("headerMentionFromPayload — régénération (jsonb persisté)", () => {
  it("lit generalComments du payload avancé", () => {
    expect(headerMentionFromPayload({ generalComments: "Mention haute." })).toBe("Mention haute.");
  });

  it("undefined si absent (payload mode base), vide, ou non-string", () => {
    expect(headerMentionFromPayload({})).toBeUndefined();
    expect(headerMentionFromPayload({ generalComments: "" })).toBeUndefined();
    expect(headerMentionFromPayload({ generalComments: null })).toBeUndefined();
    expect(headerMentionFromPayload({ generalComments: 42 })).toBeUndefined();
  });
});
