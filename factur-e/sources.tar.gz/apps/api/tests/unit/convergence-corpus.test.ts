import { generateCII, validateCascade } from "@factur-e/factur-x-builder";
import {
  allFixtures,
  fixturesBy,
  getFixture,
  type EmissionFixture,
} from "@factur-e/factur-x-fixtures";
import { describe, expect, it } from "vitest";

import { customerRowFromFixtureSeller } from "../../src/dev-support/fixture-seller.js";
import { formToModel } from "../../src/services/invoice-form-to-model.js";

/**
 * Convergence Schematron du corpus (contrat §3.2) — pipeline réel SANS DB :
 *   `formToModel(form, seller)` → `generateCII()` → `validateCascade()`.
 * Mirroir de `routes/invoices/create.ts` (même profil d'émission). Le volet
 * HTTP 422 (POST /api/invoices) est gated Postgres dans
 * `tests/http/invoices/emit-schematron.it.test.ts`.
 *
 * Couvre aussi GAP-1 (vatex → BT-121) : c'est le mapping qui débloque la
 * convergence des 2 fixtures à ligne E (BR-E-10 « code OU texte »).
 *
 * Note arithmétique : la cascade EXTENDED-CTC-FR porte les règles BR-CO-10..15
 * (cohérence des totaux). Un corpus aux totaux faux ferait donc échouer la
 * convergence → ce test REVALIDE par exécution les attentes chiffrées du
 * corpus (cf. contrat §5), au-delà du simple cross-check GrandTotalAmount.
 */

const EMISSION_PROFILE = "extended-ctc-fr" as const;

function ciiFor(fx: EmissionFixture): string {
  const mapping = formToModel(fx.form, customerRowFromFixtureSeller(fx.seller));
  if (!mapping.ok) {
    throw new Error(`${fx.meta.id} — formToModel KO : ${JSON.stringify(mapping.errors)}`);
  }
  return generateCII(mapping.value);
}

/** Valeur attendue d'un nœud MonetarySummation depuis le corpus (par suffixe
 *  de path, ex. "GrandTotalAmount"). */
function expectedXmlValue(fx: EmissionFixture, suffix: string): string | undefined {
  return fx.expect.xml.find((x) => x.path.endsWith(suffix) && x.value !== undefined)?.value;
}

describe("GAP-1 — vatex → ExemptionReasonCode (BT-121)", () => {
  it("fx-380-adv-exo-e : ligne E → ExemptionReasonCode VATEX-EU-132 émis", () => {
    const xml = ciiFor(getFixture("fx-380-adv-exo-e"));
    expect(xml).toContain("<ram:ExemptionReasonCode>VATEX-EU-132</ram:ExemptionReasonCode>");
  });

  it("fx-380-adv-riche : BT-121 émis au niveau ligne ET ventilation (catégorie E)", () => {
    const xml = ciiFor(getFixture("fx-380-adv-riche"));
    expect(xml).toContain("<ram:ExemptionReasonCode>VATEX-EU-132</ram:ExemptionReasonCode>");
    // 2 occurrences : 1 sur la ligne E (BT-121) + 1 sur la ventilation E
    // (réconciliation FR BR-FREXT-E-08rev). La catégorie S n'en porte aucune.
    const count = xml.split("<ram:ExemptionReasonCode>").length - 1;
    expect(count).toBe(2);
  });

  it("non-régression S : facture full-S → aucun ExemptionReasonCode", () => {
    const xml = ciiFor(getFixture("fx-380-base-iban"));
    expect(xml).not.toContain("ExemptionReasonCode");
  });

  it("plus de warning BR-FREXT-E-08rev sur les fixtures à ligne E", async () => {
    for (const id of ["fx-380-adv-exo-e", "fx-380-adv-riche"]) {
      const cascade = await validateCascade(ciiFor(getFixture(id)), EMISSION_PROFILE);
      const warns = cascade.steps.flatMap((s) => s.warnings.map((a) => a.ruleId));
      expect(warns, `${id} warnings`).not.toContain("BR-FREXT-E-08rev");
    }
  });
});

describe("Convergence Schematron — 6 fixtures conformes (0 fatale)", () => {
  const conformes = fixturesBy({ conformant: true });

  it("le corpus expose bien 6 conformes", () => {
    expect(conformes).toHaveLength(6);
  });

  describe.each(conformes.map((f) => [f.meta.id, f] as const))("%s", (_id, fx) => {
    it("formToModel → generateCII → cascade : 0 fatale (warnings flux2 tolérés)", async () => {
      const xml = ciiFor(fx);
      const cascade = await validateCascade(xml, EMISSION_PROFILE);
      // GAP-3 : BR-FR-21/23 (BT-49 ≠ SIREN) sont des WARNINGS structurels
      // sandbox — non bloquants, donc hors de `cascade.ok`. On vérifie aussi
      // qu'aucune étape n'a planté côté moteur (sinon faux vert).
      expect(cascade.engineErrors, "engine saxon-js KO → faux vert").toBe(false);
      if (!cascade.ok) {
        const fatals = cascade.steps.flatMap((s) => s.fatals.map((a) => a.ruleId));
        throw new Error(`${fx.meta.id} — fatales inattendues : ${fatals.join(", ")}`);
      }
      expect(cascade.ok).toBe(true);
    });

    it("GrandTotalAmount émis = attente corpus (cross-check doc)", () => {
      const expected = expectedXmlValue(fx, "GrandTotalAmount");
      expect(expected, "fixture sans attente GrandTotalAmount").toBeDefined();
      const xml = ciiFor(fx);
      expect(xml).toContain(`<ram:GrandTotalAmount>${expected ?? ""}</ram:GrandTotalAmount>`);
    });
  });
});

describe("Convergence Schematron — 3 fixtures NC (fatale détectée)", () => {
  const nc = fixturesBy({ conformant: false });

  it("le corpus expose bien 3 NC", () => {
    expect(nc).toHaveLength(3);
  });

  describe.each(nc.map((f) => [f.meta.id, f] as const))("%s", (_id, fx) => {
    it("cascade bloque (fatale) avec la règle attendue", async () => {
      const xml = ciiFor(fx);
      const cascade = await validateCascade(xml, EMISSION_PROFILE);
      expect(cascade.engineErrors, "engine saxon-js KO → faux vert").toBe(false);
      expect(cascade.ok, "une fixture NC devrait être bloquée").toBe(false);

      const fatalIds = cascade.steps.flatMap((s) => s.fatals.map((a) => a.ruleId));
      const expectedRules = fx.expect.schematron?.expectViolations ?? [];
      for (const rule of expectedRules) {
        expect(
          fatalIds.some((id) => id.includes(rule)),
          `${fx.meta.id} : règle ${rule} absente des fatales [${fatalIds.join(", ")}]`,
        ).toBe(true);
      }
    });
  });
});

describe("corpus exposé au wiring", () => {
  it("allFixtures = 9", () => {
    expect(allFixtures()).toHaveLength(9);
  });
});
