import {
  allCdarSequences,
  allReceptionFixtures,
  motifLabel,
  receptionFixturesBy,
} from "@factur-e/factur-x-fixtures";
import { parseInvoiceMetadata } from "@factur-e/factur-x-builder";
import { mapSuperPDPStatusCode } from "@factur-e/pa-adapter";
import { describe, expect, it } from "vitest";

import {
  buildIncomingFileFromEmissionFixture,
  incomingInvoiceFromFixture,
  paInvoiceIdForFixture,
  RECEPTION_PA_INVOICE_IDS,
} from "../../src/dev-support/reception-fixtures.js";

/**
 * Convergence corpus RÉCEPTION ↔ code RÉEL (Levier 1, oracle déterministe).
 * Pendant de `convergence-corpus.test.ts` (émission). Ici on TRAVERSE le
 * parser réel (`parseInvoiceMetadata`, libxmljs2), le pipeline d'émission réel
 * (pour `kind:"emission"`) et `mapSuperPDPStatusCode` — ce que le socle pur du
 * paquet ne peut pas charger (anti-faux-vert ZG-5).
 *
 * Oracles « fail-volontaire » du contrat (384 `resolveCreditNoteOrigin`,
 * `timelineNotes`, `freeText`) : NON branchés ici — ils traversent `get.ts`
 * (zone RECTIF-AFNOR) / la timeline (CDAR-MOTIF) / le smoke G1. Ils restent
 * portés comme DONNÉES par le corpus + `it.todo` ci-dessous (pas de CI rouge,
 * pas d'oracle affaibli).
 */

const norm = (v: string | null | undefined): string | null => v ?? null;

describe("convergence réception ↔ parser/pipeline réel", () => {
  describe.each(receptionFixturesBy({ sourceKind: "xml" }).map((f) => [f.meta.id, f] as const))(
    "kind:xml %s — parseInvoiceMetadata(XML statique)",
    (_id, rx) => {
      it("re-parse vers expect.parsed (documentType/preceding/total/seller)", () => {
        if (rx.source.kind !== "xml") throw new Error("narrowing");
        const meta = parseInvoiceMetadata(rx.source.xml);
        expect(meta.document.documentType).toBe(rx.expect.parsed.documentType);
        expect(norm(meta.document.precedingInvoiceReference?.invoiceNumber)).toBe(
          norm(rx.expect.parsed.precedingInvoiceNumber),
        );
        expect(meta.totals.totalTtc).toBe(rx.expect.parsed.totalTtcCents);
        expect(meta.parties.seller.siren).toBe(rx.expect.parsed.sellerSiren);
      });
    },
  );

  describe.each(
    receptionFixturesBy({ sourceKind: "emission" }).map((f) => [f.meta.id, f] as const),
  )("kind:emission %s — document DÉRIVÉ (pipeline réel)", (_id, rx) => {
    it("XML dérivé re-parse vers expect.parsed + PDF Factur-X non vide", async () => {
      if (rx.source.kind !== "emission") throw new Error("narrowing");
      const { xmlString, facturxPdfBytes } = await buildIncomingFileFromEmissionFixture(
        rx.source.emissionFixtureId,
      );
      // PDF Factur-X réellement assemblé (signature %PDF) — sert R2 passthrough.
      expect(Buffer.from(facturxPdfBytes.subarray(0, 5)).toString("latin1")).toBe("%PDF-");
      const meta = parseInvoiceMetadata(xmlString);
      expect(meta.document.documentType).toBe(rx.expect.parsed.documentType);
      expect(norm(meta.document.precedingInvoiceReference?.invoiceNumber)).toBe(
        norm(rx.expect.parsed.precedingInvoiceNumber),
      );
      expect(meta.totals.totalTtc).toBe(rx.expect.parsed.totalTtcCents);
      expect(meta.parties.seller.siren).toBe(rx.expect.parsed.sellerSiren);
    });
  });

  it("incomingInvoiceFromFixture : pa_invoice_id 910001-7 uniques + R8 préservé", () => {
    const fixtures = allReceptionFixtures();
    const ids = fixtures.map((f) => paInvoiceIdForFixture(f));
    expect(new Set(ids).size).toBe(ids.length);
    expect(Object.values(RECEPTION_PA_INVOICE_IDS).sort()).toEqual([
      "910001",
      "910002",
      "910003",
      "910004",
      "910005",
      "910006",
      "910007",
    ]);
    // R8 (rx-380-cii-partiel) : les champs enInvoice ABSENTS du snapshot le
    // restent (ne JAMAIS inventer totalTtcCents/dueDate).
    const partielFx = fixtures.find((f) => f.meta.id === "rx-380-cii-partiel");
    if (partielFx === undefined) throw new Error("rx-380-cii-partiel absente du corpus");
    const partiel = incomingInvoiceFromFixture(partielFx);
    expect(partiel.enInvoice?.totalTtcCents).toBeUndefined();
    expect(partiel.enInvoice?.dueDate).toBeUndefined();
    expect(partiel.direction).toBe("in");
    expect(partiel.paInvoiceId).toBe("910002");
  });

  describe.each(allCdarSequences().map((s) => [s.meta.id, s] as const))(
    "séquence %s — mapSuperPDPStatusCode(dernier code)",
    (_id, seq) => {
      // seq-209-acheteur : dernier code fr:209 polled (source pa) attendait
      // `cancelled`. Or la correction C2 (ADR-022 D5) mappe fr:209 polled →
      // info_complete (Complétée), le marqueur d'annulation V1a étant source
      // `app`. La propagation d'annulation acheteur (origine « Annulée » côté
      // vendeur) relève d'un code 220 (gated) / doctrine 209-vs-220 non encore
      // tranchée → skip ciblé (TODO RECTIF-AFNOR), expect fixture conservé.
      it.skipIf(seq.meta.id === "seq-209-acheteur")(
        "dernier statusCode mappé === expect.statusCurrent",
        () => {
          const last = seq.events.at(-1);
          if (last === undefined) throw new Error(`séquence ${seq.meta.id} sans event`);
          expect(mapSuperPDPStatusCode(last.statusCode).status).toBe(seq.expect.statusCurrent);
        },
      );
    },
  );

  // ── Oracles fail-volontaire (anti-faux-vert ZG-5) — cibles hors zone ──
  // rx-384 resolveCreditNoteOrigin (gate 381-only étendu 384) : ACTIVÉ par
  // T-CL-RECV-RECTIF-AFNOR — l'oracle DB-backed vit désormais dans
  // `received-invoices.it.test.ts` (« GET 384 → … creditNote.originFound »),
  // car le matching traverse `get.ts` + `findReceivedInvoiceByPrecedingNumber`.
  // Dé-skip T-CL-RECV-CDAR-MOTIF (finding B). Cohérence corpus ↔ source
  // unique des libellés (`@factur-e/shared-schemas` annexe-e-motifs, promue).
  // Le chemin du bug (renderer timeline → note normalisée) est couvert par
  // `apps/web/tests/cdar-events-to-timeline.test.ts` (émission) +
  // `apps/web/tests/recv/cdar-events-to-timeline.test.ts` (réception, GAP-7) :
  // apps/api ne peut pas importer le renderer apps/web (règle de dépendance).
  it("seq-210 timelineNotes.normalizedLabel === motifLabel(reason.code) (corpus ↔ Annexe E)", () => {
    const seqs = allCdarSequences().filter((s) => s.expect.timelineNotes !== undefined);
    expect(seqs.length).toBeGreaterThan(0);
    for (const seq of seqs) {
      for (const note of seq.expect.timelineNotes ?? []) {
        const ev = seq.events.find((e) => e.statusCode === note.code);
        const code = ev?.reason?.code;
        if (code === undefined) {
          throw new Error(`${seq.meta.id}: event ${note.code} sans reason.code`);
        }
        expect(motifLabel(code)).toBe(note.normalizedLabel);
      }
    }
  });

  // ZG-2 requalifié — H-REASON-TEXT INFIRMÉE (arbitrage Bruno, limite V1
  // PRD v1.10) : SuperPDP `invoice_event_detail` n'expose qu'un code (MDT-113),
  // aucun champ texte → le texte libre du motif 11 NE transite PAS
  // cross-comptes. La face émission asserte donc le libellé « Autre » seul
  // (vérifié ci-dessus) ; le freeText vendeur reste à valider au smoke G1
  // sandbox réelle. Le rendu LOCAL acheteur (reason_text) est couvert par
  // apps/web/tests/recv (non gated par la limite de transport).
  it.todo("seq-210-motif-autre freeText transmis au vendeur → smoke G1 sandbox (limite V1)");
});
