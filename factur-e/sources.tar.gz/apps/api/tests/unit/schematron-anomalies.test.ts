import { type CascadeResult, schematronRuleLabel } from "@factur-e/factur-x-builder";
import { describe, expect, it } from "vitest";

import { toSchematronAnomalies } from "../../src/routes/invoices/_shared.js";

// `toSchematronAnomalies` aplatit une CascadeResult en anomalies API : c'est le
// contrat consommé par l'UI (corps 422 fatales + warnings 201). On le verrouille
// ici sans dépendre du moteur Schematron (pur).

const cascade: CascadeResult = {
  profile: "extended-ctc-fr",
  ok: false,
  zeroWarning: false,
  engineErrors: false,
  steps: [
    { step: "xsd", status: "ok", fatals: [], warnings: [] },
    { step: "schematron-en16931", status: "na", fatals: [], warnings: [] },
    {
      step: "schematron-extended-ctc-fr",
      status: "fatal",
      fatals: [
        {
          ruleId: "BR-CO-15",
          severity: "fatal",
          kind: "failed-assert",
          message: "Total faux",
          xpath: "/x/y",
        },
      ],
      warnings: [],
    },
    {
      step: "schematron-br-fr-flux2",
      status: "warning",
      fatals: [],
      warnings: [
        {
          ruleId: "BR-FR-23",
          severity: "warning",
          kind: "failed-assert",
          message: "Adresse 0225",
          xpath: "/a/b",
        },
      ],
    },
  ],
};

describe("toSchematronAnomalies", () => {
  it("extrait les fatales avec leur étape de cascade", () => {
    expect(toSchematronAnomalies(cascade, "fatal")).toEqual([
      {
        rule_id: "BR-CO-15",
        severity: "fatal",
        message: "Total faux",
        label_fr: schematronRuleLabel("BR-CO-15") ?? null,
        xpath: "/x/y",
        step: "schematron-extended-ctc-fr",
      },
    ]);
    // BR-CO-15 est couvert par la table d'override FR.
    expect(schematronRuleLabel("BR-CO-15")).toBeDefined();
  });

  it("extrait les warnings avec leur étape de cascade", () => {
    expect(toSchematronAnomalies(cascade, "warning")).toEqual([
      {
        rule_id: "BR-FR-23",
        severity: "warning",
        message: "Adresse 0225",
        // Non couvert par la table d'override → fallback svrl:text (label_fr null).
        label_fr: null,
        xpath: "/a/b",
        step: "schematron-br-fr-flux2",
      },
    ]);
  });

  it("retourne un tableau vide quand aucune assertion de la sévérité demandée", () => {
    const clean: CascadeResult = {
      ...cascade,
      steps: [{ step: "xsd", status: "ok", fatals: [], warnings: [] }],
    };
    expect(toSchematronAnomalies(clean, "fatal")).toEqual([]);
    expect(toSchematronAnomalies(clean, "warning")).toEqual([]);
  });
});
