import { describe, expect, it } from "vitest";

import { reconstructFormFromPersisted } from "../../src/routes/invoices/_reconstruct.js";
import type { InvoiceRow } from "../../src/db/repos/invoices.js";
import type { InvoiceLineRow } from "../../src/db/repos/invoice_lines.js";

/**
 * Finding G sprint-07 — `reconstructFormFromPersisted` doit réinjecter le
 * bloc paiement persisté (`payload_extended.payment`) au lieu du hardcode
 * historique `transfer`/30j/null. Sans ça, toute facture régénérée
 * (GET /pdf, /xml, export ZIP) affiche « virement à 30 jours » sans mentions
 * LME, et une facture chèque émise par un vendeur sans IBAN crashait en 500
 * (`INVALID_PAYMENT_METHOD_MISSING_IBAN`). Fallback legacy fail-safe
 * (ADR-009) pour les rows persistées avant le fix.
 */

const EPOCH = new Date("2026-05-29T00:00:00Z");

function makeInvoiceRow(payloadExtended: Record<string, unknown>): InvoiceRow {
  return {
    id: "11111111-1111-4111-8111-111111111111",
    customer_id: "22222222-2222-4222-8222-222222222222",
    number: "F-2026-001",
    issue_date: EPOCH,
    tracking_id: "33333333-3333-4333-8333-333333333333",
    total_ht: "100.00",
    total_vat: "20.00",
    total_ttc: "120.00",
    currency: "EUR",
    processing_rule: "B2B",
    type_code: "380",
    preceding_invoice_id: null,
    pa_invoice_id: null,
    pa_provider: "superpdp",
    sha256: null,
    submitted_at: null,
    status_current: null,
    pdf_archived_at: null,
    payload_extended: payloadExtended,
    deleted_at: null,
    created_at: EPOCH,
    updated_at: EPOCH,
  };
}

const LINES: InvoiceLineRow[] = [
  {
    id: "44444444-4444-4444-8444-444444444444",
    invoice_id: "11111111-1111-4111-8111-111111111111",
    line_number: 1,
    label: "Prestation",
    description: null,
    quantity: "1.0000",
    unit_code: "C62",
    unit_price_ht: "100.0000",
    vat_rate: "20.00",
    vat_category: "S",
    total_ht: "100.00",
    period_start: null,
    period_end: null,
    allowance_amount: null,
    charge_amount: null,
    payload_extended: {},
  },
];

describe("reconstructFormFromPersisted — bloc paiement (finding G)", () => {
  it("chèque + endOfMonth + mentions → réinjecté tel quel (pas de hardcode transfer)", () => {
    const form = reconstructFormFromPersisted(
      makeInvoiceRow({
        payment: {
          paymentTerms: { kind: "endOfMonth", days: 15 },
          paymentMethodKind: "check",
          mentionsLegales: "Escompte 2% sous 10 jours",
        },
      }),
      LINES,
    );
    expect(form.payment.paymentMethodKind).toBe("check");
    expect(form.payment.paymentTerms).toEqual({ kind: "endOfMonth", days: 15 });
    expect(form.payment.mentionsLegales).toBe("Escompte 2% sous 10 jours");
  });

  it("ZG-3 — variante fixedDate préservée (pas de coercition vers days)", () => {
    const form = reconstructFormFromPersisted(
      makeInvoiceRow({
        payment: {
          paymentTerms: { kind: "fixedDate", dueDate: "2026-07-31" },
          paymentMethodKind: "card",
          mentionsLegales: null,
        },
      }),
      LINES,
    );
    expect(form.payment.paymentTerms).toEqual({ kind: "fixedDate", dueDate: "2026-07-31" });
    expect(form.payment.paymentMethodKind).toBe("card");
  });

  it("virement → réinjecté (régression : reste transfer)", () => {
    const form = reconstructFormFromPersisted(
      makeInvoiceRow({
        payment: {
          paymentTerms: { kind: "days", days: 45 },
          paymentMethodKind: "transfer",
          mentionsLegales: null,
        },
      }),
      LINES,
    );
    expect(form.payment.paymentMethodKind).toBe("transfer");
    expect(form.payment.paymentTerms).toEqual({ kind: "days", days: 45 });
  });

  it("fallback legacy (ADR-009) — payload sans payment → transfer/30j/null sans crash", () => {
    const form = reconstructFormFromPersisted(makeInvoiceRow({}), LINES);
    expect(form.payment).toEqual({
      paymentTerms: { kind: "days", days: 30 },
      paymentMethodKind: "transfer",
      mentionsLegales: null,
    });
  });

  it("fallback legacy — payment partiel/malformé → défauts sans crash", () => {
    const form = reconstructFormFromPersisted(
      makeInvoiceRow({ payment: { paymentMethodKind: "check" } }),
      LINES,
    );
    // paymentTerms manquant → fallback complet (pas de form half-built).
    expect(form.payment).toEqual({
      paymentTerms: { kind: "days", days: 30 },
      paymentMethodKind: "transfer",
      mentionsLegales: null,
    });
  });
});
