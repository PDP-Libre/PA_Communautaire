import { describe, expect, it } from "vitest";

import { reconstructFormFromPersisted } from "../../src/routes/invoices/_reconstruct.js";
import type { InvoiceRow } from "../../src/db/repos/invoices.js";
import type { InvoiceLineRow } from "../../src/db/repos/invoice_lines.js";

/**
 * Régression titre PDF avoir/rectificative (finding T-BR sprint-07) :
 * `reconstructFormFromPersisted` doit réinjecter `document.typeCode` depuis
 * la colonne `invoice.type_code`. Sans ça, `formToModel` applique le défaut
 * 380 → le moteur de template choisit `invoice-default.njk` et titre
 * "Facture …" au lieu de "Avoir …" / "Facture rectificative …" lors de la
 * régénération PDF/XML (GET /api/invoices/:id/pdf et /xml).
 */

const EPOCH = new Date("2026-05-29T00:00:00Z");

function makeInvoiceRow(typeCode: string): InvoiceRow {
  return {
    id: "11111111-1111-4111-8111-111111111111",
    customer_id: "22222222-2222-4222-8222-222222222222",
    number: "AV-2026-001",
    issue_date: EPOCH,
    tracking_id: "33333333-3333-4333-8333-333333333333",
    total_ht: "100.00",
    total_vat: "20.00",
    total_ttc: "120.00",
    currency: "EUR",
    processing_rule: "B2B",
    type_code: typeCode,
    preceding_invoice_id: null,
    pa_invoice_id: null,
    pa_provider: "superpdp",
    sha256: null,
    submitted_at: null,
    status_current: null,
    payload_extended: {},
    deleted_at: null,
    created_at: EPOCH,
    updated_at: EPOCH,
  };
}

const LINES: InvoiceLineRow[] = [
  {
    id: "44444444-4444-4444-8444-444444444444",
    invoice_id: "11111111-1111-4111-8111-111111111111",
    line_number: 1,
    label: "Prestation",
    description: null,
    quantity: "1.0000",
    unit_code: "C62",
    unit_price_ht: "100.0000",
    vat_rate: "20.00",
    vat_category: "S",
    total_ht: "100.00",
    period_start: null,
    period_end: null,
    allowance_amount: null,
    charge_amount: null,
    payload_extended: {},
  },
];

describe("reconstructFormFromPersisted — propagation BT-3 typeCode", () => {
  it("avoir 381 → document.typeCode = 381 (pas 380)", () => {
    const form = reconstructFormFromPersisted(makeInvoiceRow("381"), LINES);
    expect(form.document.typeCode).toBe("381");
  });

  it("rectificative 384 → document.typeCode = 384", () => {
    const form = reconstructFormFromPersisted(makeInvoiceRow("384"), LINES);
    expect(form.document.typeCode).toBe("384");
  });

  it("facture standard 380 → document.typeCode = 380", () => {
    const form = reconstructFormFromPersisted(makeInvoiceRow("380"), LINES);
    expect(form.document.typeCode).toBe("380");
  });
});
