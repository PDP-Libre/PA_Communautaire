import { renderInvoiceTextLines } from "@factur-e/factur-x-builder";
import { fixturesBy, type EmissionFixture } from "@factur-e/factur-x-fixtures";
import { describe, expect, it } from "vitest";

import { customerRowFromFixtureSeller } from "../../src/dev-support/fixture-seller.js";
import { formToModel } from "../../src/services/invoice-form-to-model.js";
import { buildSellerEnrichment, headerMentionFromForm } from "../../src/services/pdf-enrichment.js";

/**
 * Suite d'assertions de contenu PDF du corpus (contrat §3.4, Levier 1) — pipeline
 * réel SANS DB : `formToModel(form, seller)` → `renderInvoiceTextLines` (texte
 * rendu dans l'ordre de lecture, oracle déterministe indépendant de la
 * rasterisation). Mirroir de `routes/invoices/{create,preview}.ts` (même
 * enrichissement seller + mention d'en-tête). Prouve le F-cluster W2 levé ET le
 * verrouille pour les versions futures.
 *
 * Le résidu humain (position visuelle exacte F7, lisibilité) reste en
 * `humanCheck` → `docs/sprints/sprint-08/test.md` Sc.2.
 */

/** Rend le texte du PDF d'une fixture (jointe par espace : le wrap F2 découpe
 *  les mentions longues aux espaces, la jointure les recompose). */
async function pdfTextFor(fx: EmissionFixture): Promise<string> {
  const seller = customerRowFromFixtureSeller(fx.seller);
  const mapping = formToModel(fx.form, seller);
  if (!mapping.ok) {
    throw new Error(`${fx.meta.id} — formToModel KO : ${JSON.stringify(mapping.errors)}`);
  }
  const lines = await renderInvoiceTextLines({
    invoice: mapping.value,
    enrichment: { ...buildSellerEnrichment(seller), headerMention: headerMentionFromForm(fx.form) },
  });
  return lines.join(" ");
}

/** Un oracle montant brut (« 960.00 », « 1140.00 ») rendu au format FR au PDF
 *  (« 960,00 », « 1 140,00 » avec U+202F). Pour les tokens purement numériques,
 *  on compare la VALEUR (séparateurs de milliers retirés, virgule = point) —
 *  format-tolérant sans masquer une valeur fausse. Les autres tokens (libellés,
 *  IBAN, mentions) restent en correspondance EXACTE. */
const AMOUNT_RE = /^\d+(?:[.,]\d+)?$/;
function canonNumbers(s: string): string {
  return s.replace(/\s/g, "").replace(/,/g, ".");
}
function present(text: string, needle: string): boolean {
  return AMOUNT_RE.test(needle)
    ? canonNumbers(text).includes(canonNumbers(needle))
    : text.includes(needle);
}

/** Indices croissants = sous-séquence ordonnée présente (oracle F7 partiel). */
function containsInOrder(haystack: string, needles: string[]): boolean {
  let from = 0;
  for (const needle of needles) {
    const idx = haystack.indexOf(needle, from);
    if (idx < 0) return false;
    from = idx + needle.length;
  }
  return true;
}

describe("Contenu PDF — corpus de fixtures conformes (§3.4, F-cluster W2)", () => {
  const conformes = fixturesBy({ conformant: true });

  describe.each(conformes.map((f) => [f.meta.id, f] as const))("%s", (_id, fx) => {
    it("expect.pdf.mustContain / mustNotContain / mustContainInOrder", async () => {
      const text = await pdfTextFor(fx);

      for (const needle of fx.expect.pdf.mustContain) {
        expect(present(text, needle), `${fx.meta.id} — mustContain manquant : « ${needle} »`).toBe(
          true,
        );
      }
      for (const needle of fx.expect.pdf.mustNotContain ?? []) {
        expect(
          present(text, needle),
          `${fx.meta.id} — mustNotContain présent : « ${needle} »`,
        ).toBe(false);
      }
      const ordered = fx.expect.pdf.mustContainInOrder ?? [];
      if (ordered.length > 0) {
        expect(
          containsInOrder(text, ordered),
          `${fx.meta.id} — mustContainInOrder rompu : ${ordered.join(" ▸ ")}`,
        ).toBe(true);
      }
    });
  });
});
