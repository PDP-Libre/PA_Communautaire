import { generateCII, renderInvoiceTextLines } from "@factur-e/factur-x-builder";
import { getFixture } from "@factur-e/factur-x-fixtures";
import { describe, expect, it } from "vitest";

import { customerRowFromFixtureSeller } from "../../src/dev-support/fixture-seller.js";
import { formToModel } from "../../src/services/invoice-form-to-model.js";
import { buildSellerEnrichment, headerMentionFromForm } from "../../src/services/pdf-enrichment.js";

/**
 * Anomalie B (recette T-CL-PDF-MOTEUR-V2) — pour `paymentTerms.kind==="fixedDate"`,
 * la BT-20 `Description` était posée à « Date d'échéance : <ISO> », redondante
 * avec la BT-9 `DueDateDateTime` → date affichée en double (dont une en ISO brut)
 * dans le bloc Paiement du PDF. Fix : pas de Description pour `fixedDate` (BT-9
 * suffit, BR-CO-25 OK). Les autres modalités gardent un libellé informatif.
 */

function modelOf(id: string) {
  const fx = getFixture(id);
  const seller = customerRowFromFixtureSeller(fx.seller);
  const mapping = formToModel(fx.form, seller);
  if (!mapping.ok) throw new Error(`${id} — formToModel KO`);
  return { model: mapping.value, fx, seller };
}

describe("BT-20 paymentTermsDescription — fixedDate", () => {
  it("fixedDate (fx-380-adv-riche) : pas de Description, BT-9 présente, pas d'ISO redondant au XML", () => {
    const { model } = modelOf("fx-380-adv-riche");
    expect(model.tradeTransaction.tradeSettlement.paymentTermsDescription).toBeUndefined();
    const xml = generateCII(model);
    expect(xml).toContain("<ram:DueDateDateTime>");
    expect(xml).not.toContain("Date d'échéance : 2026-06-30");
  });

  it("days (fx-380-base-iban) : Description informative conservée", () => {
    const { model } = modelOf("fx-380-base-iban");
    expect(model.tradeTransaction.tradeSettlement.paymentTermsDescription).toBe(
      "Règlement à 30 jours",
    );
  });

  it("PDF fixedDate : plus de doublon « Conditions de règlement : Date d'échéance » ni d'ISO", async () => {
    const { model, fx, seller } = modelOf("fx-380-adv-riche");
    const text = (
      await renderInvoiceTextLines({
        invoice: model,
        enrichment: {
          ...buildSellerEnrichment(seller),
          headerMention: headerMentionFromForm(fx.form),
        },
      })
    ).join("\n");
    expect(text).not.toContain("Conditions de règlement");
    expect(text).not.toContain("2026-06-30");
    // L'échéance reste affichée (BT-9, format FR).
    expect(text).toContain("Date d'échéance : 30/06/2026");
  });
});
