import { allFixtures } from "@factur-e/factur-x-fixtures";
import { InvoiceFormSchema } from "@factur-e/shared-schemas";
import { describe, expect, it } from "vitest";

import type { InvoiceLineRow } from "../../src/db/repos/invoice_lines.js";
import type { InvoiceRow } from "../../src/db/repos/invoices.js";
import { reconstructFormFromPersisted } from "../../src/routes/invoices/_reconstruct.js";
import { extractPayloadExtended } from "../../src/services/invoice-form-to-model.js";

/**
 * Oracle déterministe W3 (Levier 1) — résout le « faux vert ZG-5 ».
 *
 * Le corpus déclare, par fixture, `expect.reconstruction.roundTripFields` :
 * les chemins du `form` d'origine qui DOIVENT survivre au cycle
 * persist (`extractPayloadExtended` + colonnes) → `reconstructFormFromPersisted`.
 * Avant T-CL-RECONSTRUCT-FIDELE-F8 aucun test n'exécutait ce chemin : la
 * reconstruction forçait `ui_mode:"base"` et perdait silencieusement
 * prepaidAmount / documentLevelAllowance / frais de port / incoterm / notes /
 * BG-3 — sans rougir.
 *
 * Ce test reconstitue fidèlement la persistance de `create.ts` EN MÉMOIRE
 * (sans Postgres : on teste la LOGIQUE de reconstruction, pas le formatage
 * numérique de la colonne `numeric`) puis compare chaque `roundTripField`.
 */

const EPOCH = new Date("2026-05-29T00:00:00Z");

/** Reconstitue la `InvoiceRow` telle que `create.ts` la persisterait. */
function rowFromForm(form: ReturnType<typeof InvoiceFormSchema.parse>): InvoiceRow {
  return {
    id: "11111111-1111-4111-8111-111111111111",
    customer_id: "22222222-2222-4222-8222-222222222222",
    number: form.document.number,
    issue_date: new Date(`${form.document.issueDate}T00:00:00Z`),
    tracking_id: "33333333-3333-4333-8333-333333333333",
    total_ht: "0.00",
    total_vat: "0.00",
    total_ttc: "0.00",
    currency: form.ui_mode === "advanced" ? form.document.currency : "EUR",
    processing_rule: form.ui_mode === "advanced" ? form.document.processingRule : "B2B",
    type_code: form.document.typeCode ?? "380",
    preceding_invoice_id: form.precedingInvoiceId ?? null,
    pa_invoice_id: null,
    pa_provider: "superpdp",
    sha256: null,
    submitted_at: null,
    status_current: null,
    pdf_archived_at: null,
    payload_extended: extractPayloadExtended(form),
    deleted_at: null,
    created_at: EPOCH,
    updated_at: EPOCH,
  };
}

/** Reconstitue les `InvoiceLineRow[]` telles que `create.ts` les persisterait
 *  (mêmes colonnes période/remise + `payload_extended` ligne). Valeurs string
 *  conservées verbatim — le reformatage `numeric` BDD est hors périmètre de
 *  cet oracle de logique. */
function lineRowsFromForm(form: ReturnType<typeof InvoiceFormSchema.parse>): InvoiceLineRow[] {
  return form.lines.map((line, idx): InvoiceLineRow => {
    const row: InvoiceLineRow = {
      id: `44444444-4444-4444-8444-${String(idx).padStart(12, "0")}`,
      invoice_id: "11111111-1111-4111-8111-111111111111",
      line_number: idx + 1,
      label: line.label,
      description: line.description ?? null,
      quantity: line.quantity,
      unit_code: line.unitCode,
      unit_price_ht: line.unitPriceHt,
      vat_rate: line.vatRate,
      vat_category: line.vatCategory,
      total_ht: line.totalHt,
      period_start: null,
      period_end: null,
      allowance_amount: null,
      charge_amount: null,
      payload_extended: {},
    };
    if (form.ui_mode === "advanced") {
      const adv = line as (typeof form.lines)[number];
      if ("period" in adv && adv.period !== null && adv.period !== undefined) {
        if (adv.period.startDate !== null && adv.period.startDate !== undefined) {
          row.period_start = new Date(`${adv.period.startDate}T00:00:00Z`);
        }
        if (adv.period.endDate !== null && adv.period.endDate !== undefined) {
          row.period_end = new Date(`${adv.period.endDate}T00:00:00Z`);
        }
      }
      if ("allowance" in adv && adv.allowance !== null && adv.allowance !== undefined) {
        if (adv.allowance.chargeIndicator) row.charge_amount = adv.allowance.amount;
        else row.allowance_amount = adv.allowance.amount;
      }
      const ext: Record<string, unknown> = {};
      const keep = (v: unknown): boolean => v !== null && v !== undefined;
      if ("longDescription" in adv && keep(adv.longDescription))
        ext.longDescription = adv.longDescription;
      if ("note" in adv && keep(adv.note)) ext.note = adv.note;
      if ("basisQuantity" in adv && keep(adv.basisQuantity)) ext.basisQuantity = adv.basisQuantity;
      if ("vatex" in adv && keep(adv.vatex)) ext.vatex = adv.vatex;
      row.payload_extended = ext;
    }
    return row;
  });
}

/** Résout un chemin pointé (`"payment.prepaidAmount"`, `"lines.0.vatex"`). */
function getByPath(obj: unknown, path: string): unknown {
  return path.split(".").reduce<unknown>((acc, key) => {
    if (acc === null || acc === undefined) return undefined;
    return (acc as Record<string, unknown>)[key];
  }, obj);
}

const fixturesWithReconstruction = allFixtures().filter(
  (f) => f.expect.reconstruction !== undefined,
);

describe("reconstructFormFromPersisted — round-trip corpus (oracle ZG-5)", () => {
  it.each(fixturesWithReconstruction.map((f) => [f.meta.id, f] as const))(
    "%s — chaque roundTripField survit au persist → reconstruct",
    (_id, fx) => {
      const form = InvoiceFormSchema.parse(fx.form);
      const rebuilt = reconstructFormFromPersisted(rowFromForm(form), lineRowsFromForm(form));

      // Le form reconstruit doit rester schema-valide (forme cohérente
      // base/avancé) — garde-fou contre une reconstruction à moitié construite.
      expect(InvoiceFormSchema.safeParse(rebuilt).success).toBe(true);

      // Forme préservée : un payload avancé se reconstruit en avancé (sinon
      // les champs avancés n'ont pas de support de schéma → perte).
      expect(rebuilt.ui_mode).toBe(form.ui_mode);

      const recon = fx.expect.reconstruction;
      if (recon === undefined)
        throw new Error("fixture sans expect.reconstruction (filtrée en amont)");
      for (const field of recon.roundTripFields) {
        expect(getByPath(rebuilt, field), `roundTripField "${field}"`).toEqual(
          getByPath(form, field),
        );
      }
    },
  );
});
