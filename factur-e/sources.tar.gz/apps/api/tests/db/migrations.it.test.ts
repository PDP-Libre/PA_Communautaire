import { afterAll, beforeAll, describe, expect, it } from "vitest";
import postgres from "postgres";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

import { runMigrations } from "../../src/db/migrate.js";

/**
 * Integration test for the auth/onboarding migrations (T-CL-01).
 *
 * Opt-in: skipped unless `TEST_POSTGRES_URL` is set. Spin up the dev
 * stack first:
 *
 *   docker compose -f docker-compose.dev.yml up -d postgres
 *   TEST_POSTGRES_URL=postgresql://factur_e_dev:factur_e_dev_password@localhost:5432/factur_e_dev \
 *     pnpm --filter @factur-e/api test
 *
 * The test creates a throwaway database, runs all migrations against it,
 * exercises a handful of constraints, then drops the database.
 */

const adminUrlEnv = process.env.TEST_POSTGRES_URL;
const enabled = adminUrlEnv !== undefined && adminUrlEnv !== "";

function adminUrl(): string {
  if (adminUrlEnv === undefined || adminUrlEnv === "") {
    throw new Error("TEST_POSTGRES_URL is required for migrations.it.test.ts");
  }
  return adminUrlEnv;
}

const __dirname = dirname(fileURLToPath(import.meta.url));
const migrationsDir = join(__dirname, "..", "..", "src", "db", "migrations");

const dbName = `factur_e_mig_test_${Math.random().toString(36).slice(2, 10)}`;
let testUrl = "";

describe.skipIf(!enabled)("runMigrations — auth/onboarding schema", () => {
  beforeAll(async () => {
    const admin = postgres(adminUrl(), { max: 1, onnotice: () => undefined });
    try {
      await admin.unsafe(`CREATE DATABASE "${dbName}"`);
    } finally {
      await admin.end();
    }
    const url = new URL(adminUrl());
    url.pathname = `/${dbName}`;
    testUrl = url.toString();
  });

  afterAll(async () => {
    if (!enabled) return;
    const admin = postgres(adminUrl(), { max: 1, onnotice: () => undefined });
    try {
      await admin.unsafe(
        `SELECT pg_terminate_backend(pid) FROM pg_stat_activity
         WHERE datname = '${dbName}' AND pid <> pg_backend_pid()`,
      );
      await admin.unsafe(`DROP DATABASE IF EXISTS "${dbName}"`);
    } finally {
      await admin.end();
    }
  });

  it("applies all migrations and creates the expected tables", async () => {
    const result = await runMigrations({
      connectionString: testUrl,
      migrationsDir,
    });

    // bootstrap (sprint-00) + helper + 6 tables (T-CL-01)
    // + signup_pending + alter users.terms_accepted_at (T-CL-02)
    // + otp_codes + alter users.mfa_reset_required (T-CL-03) = 12 files
    // T-CL-01..03: 12, T-CL-06: +2 (users profile fields, customers
    // juridique_code + capital_social) = 14, T-CL-09: +1 (customers
    // profile_unverified) = 15. Sprint-03 T-CL-04: +1 (pa_connections) = 16.
    // Sprint-03 T-CL-09: +2 (directory_cache + buyer_address_preferences) = 18.
    // Sprint-03 T-CL-11: +2 (product_categories + products) = 20.
    // Sprint-03 T-CL-15: +1 (extend_otp_purpose_invite_secondary) = 21.
    // Sprint-04 T-CL-PA-EXT: +1 (cdar_events) = 22.
    // Sprint-04 T-CL-API-INVOICE: +3 (invoices + invoice_lines
    // + invoice_drafts ; cdar_events posée par T-CL-PA-EXT) = 25.
    // Sprint-04 T-CL-PA-INVOICE-FIX: +2 (rename pa_flow_id → pa_invoice_id
    // + create pa_polling_state, ADR-010 v2 D7 + ADR-012 D5) = 27.
    // Sprint-05 T-CL-PA-STATUS-RFC: +1 (remap_invoices_status_current_afnor,
    // ADR-012 D2 amendée refonte AFNOR XP Z12-013) = 28.
    // Sprint-05 T-CL-PA-DIRECTORY-PEPPOL: +2 (peppol_address_retry_columns
    // + patch_customers_directory_address_peppol_format) = 30.
    // Sprint-05 T-CL-RECV-API: +3 (create received_invoices
    // + create incoming_cdar_events + add pa_polling_state direction) = 33.
    // Sprint-06 T-CL-API-INVOICE-MARK-PAID: +1 (extend_cdar_events_source_app
    // — CHECK source autorise 'app') = 34.
    // Sprint-06 T-CL-SIREN-RECONCILIATION: +1 (add_customer_unverified_fields,
    // 4 flags champ-spécifiques Mécanisme 1 ADR-007ter D1 candidat) = 35.
    // Sprint-06 T-CL-CREDIT-NOTES: +1 (add_invoice_preceding_invoice_id,
    // colonne BG-3 preceding_invoice_id + index, L11 avoirs/rectificatives) = 36.
    // Sprint-06 T-CL-EXPORT-ZIP-RETENTION: +1 (create_export_requests
    // + colonnes exported_at invoices/received_invoices) = 37.
    // Sprint-07 T-CL-HOTFIX-RECV-UNIQUE-TENANT: +1 (drop_recreate
    // received_invoices unique index scopé (customer_id, pa_invoice_id_in),
    // finding R1) = 38.
    expect(result.applied.length).toBe(38);

    const sql = postgres(testUrl, { max: 1, onnotice: () => undefined });
    try {
      const tables = await sql<{ table_name: string }[]>`
        SELECT table_name FROM information_schema.tables
        WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
        ORDER BY table_name
      `;
      const names = tables.map((t) => t.table_name);
      expect(names).toEqual(
        expect.arrayContaining([
          "_migrations_applied",
          "auth_audit",
          "customers",
          "export_requests",
          "incoming_cdar_events",
          "insee_cache",
          "invitations",
          "otp_codes",
          "product_categories",
          "products",
          "received_invoices",
          "sessions",
          "signup_pending",
          "users",
        ]),
      );
      expect(names).not.toContain("customer_settings");

      const fns = await sql<{ proname: string }[]>`
        SELECT proname FROM pg_proc WHERE proname = 'set_updated_at'
      `;
      expect(fns).toHaveLength(1);
    } finally {
      await sql.end();
    }
  });

  it("enforces critical constraints", async () => {
    const sql = postgres(testUrl, { max: 1, onnotice: () => undefined });
    try {
      // SIREN UNIQUE
      await sql`
        INSERT INTO customers (siren, legal_name)
        VALUES (${"123456789"}, ${"Acme SARL"})
      `;
      await expect(
        sql`INSERT INTO customers (siren, legal_name) VALUES (${"123456789"}, ${"Acme Bis"})`,
      ).rejects.toThrow();

      // role CHECK rejects unknown values (3 enum values, no `pack_buyer`)
      const customerRow = await sql<{ id: string }[]>`
        SELECT id FROM customers WHERE siren = ${"123456789"}
      `;
      const customerId = customerRow[0]?.id;
      if (customerId === undefined) throw new Error("customer not found");
      await sql`
        INSERT INTO users (customer_id, email, password_hash, role)
        VALUES (${customerId}, ${"alice@acme.fr"}, ${"argon2id$dummy"}, ${"full"})
      `;
      await expect(
        sql`INSERT INTO users (customer_id, email, password_hash, role)
            VALUES (${customerId}, ${"bob@acme.fr"}, ${"argon2id$dummy"}, ${"pack_buyer"})`,
      ).rejects.toThrow();

      // mfa_mode CHECK
      await expect(
        sql`INSERT INTO users (customer_id, email, password_hash, role, mfa_mode)
            VALUES (${customerId}, ${"carol@acme.fr"}, ${"argon2id$dummy"}, ${"full"}, ${"sms"})`,
      ).rejects.toThrow();

      // ui_mode_default defaults to 'basic'
      const cRows = await sql<{ ui_mode_default: string; primary_color: string }[]>`
        SELECT ui_mode_default, primary_color FROM customers WHERE siren = ${"123456789"}
      `;
      const c = cRows[0];
      if (c === undefined) throw new Error("customer not found");
      expect(c.ui_mode_default).toBe("basic");
      expect(c.primary_color).toBe("#316128");

      // primary_color CHECK rejects malformed hex
      await expect(
        sql`INSERT INTO customers (siren, legal_name, primary_color)
            VALUES (${"987654321"}, ${"Other"}, ${"red"})`,
      ).rejects.toThrow();
    } finally {
      await sql.end();
    }
  });

  it("triggers updated_at on customers update", async () => {
    const sql = postgres(testUrl, { max: 1, onnotice: () => undefined });
    try {
      const beforeRows = await sql<{ updated_at: Date }[]>`
        SELECT updated_at FROM customers WHERE siren = ${"123456789"}
      `;
      const before = beforeRows[0];
      if (before === undefined) throw new Error("customer not found");
      await new Promise((r) => setTimeout(r, 20));
      await sql`UPDATE customers SET legal_name = ${"Acme SAS"} WHERE siren = ${"123456789"}`;
      const afterRows = await sql<{ updated_at: Date }[]>`
        SELECT updated_at FROM customers WHERE siren = ${"123456789"}
      `;
      const after = afterRows[0];
      if (after === undefined) throw new Error("customer not found");
      expect(after.updated_at.getTime()).toBeGreaterThan(before.updated_at.getTime());
    } finally {
      await sql.end();
    }
  });

  it("is idempotent on a second run", async () => {
    const replay = await runMigrations({
      connectionString: testUrl,
      migrationsDir,
    });
    expect(replay.applied).toEqual([]);
  });
});
