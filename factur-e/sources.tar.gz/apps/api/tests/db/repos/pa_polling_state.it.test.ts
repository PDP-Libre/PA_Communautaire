import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { getCursor, upsertCursor } from "../../../src/db/repos/pa_polling_state.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

/**
 * Tests repo `pa_polling_state` — T-CL-PA-INVOICE-FIX sprint-04
 * (ADR-012 D5).
 *
 * Couvre :
 *  - getCursor avant tout INSERT → undefined.
 *  - upsertCursor (INSERT) → getCursor retourne la valeur.
 *  - upsertCursor (UPDATE via ON CONFLICT) → cursor mis à jour +
 *    last_polled_at avance.
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("pa_polling_state repo (ADR-012 D5)", () => {
  let db: TestDb;
  let sql: postgres.Sql;
  let customerId: string;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
  });

  afterAll(async () => {
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    const customer = await sql<{ id: string }[]>`
      INSERT INTO customers (siren, legal_name) VALUES ('111111118', 'Test') RETURNING id
    `;
    customerId = customer[0]?.id ?? "";
  });

  it("getCursor avant INSERT → undefined ; upsertCursor INSERT + relecture OK", async () => {
    const initial = await getCursor(sql, customerId, "superpdp");
    expect(initial).toBeUndefined();

    await upsertCursor(sql, { customerId, provider: "superpdp", cursor: "42" });
    const after = await getCursor(sql, customerId, "superpdp");
    expect(after?.cursor).toBe("42");
    expect(after?.last_polled_at).toBeInstanceOf(Date);
  });

  it("upsertCursor UPDATE via ON CONFLICT → cursor mis à jour", async () => {
    await upsertCursor(sql, { customerId, provider: "superpdp", cursor: "42" });
    const firstSnapshot = await getCursor(sql, customerId, "superpdp");
    // Force un délai mesurable pour que last_polled_at avance (NOW()
    // change entre 2 calls). On utilise setTimeout 5ms — suffisant
    // pour timestamptz Postgres microsecond precision.
    await new Promise<void>((resolve) => setTimeout(resolve, 5));
    await upsertCursor(sql, { customerId, provider: "superpdp", cursor: "100" });
    const secondSnapshot = await getCursor(sql, customerId, "superpdp");
    expect(secondSnapshot?.cursor).toBe("100");
    expect(secondSnapshot?.last_polled_at.getTime()).toBeGreaterThanOrEqual(
      firstSnapshot?.last_polled_at.getTime() ?? 0,
    );
  });
});
