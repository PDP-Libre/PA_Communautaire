import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import {
  findFreshDirectoryCacheBySiren,
  upsertDirectoryCache,
  type CachedDirectoryAddress,
} from "../../../src/db/repos/directory_cache.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("repos/directory_cache (T-CL-09 sprint-03)", () => {
  let db: TestDb;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
  });

  afterAll(async () => {
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  it("upsert + findFresh roundtrip + negative cache + override on conflict", async () => {
    const siren = "111111118";
    expect(await findFreshDirectoryCacheBySiren(sql, siren)).toBeUndefined();

    const addresses: CachedDirectoryAddress[] = [
      {
        party_id: "0225:111111118_dgfip",
        scheme_id: "0225",
        is_active: true,
        pa_name: "SuperPDP",
      },
    ];
    await upsertDirectoryCache(sql, {
      siren,
      payload: { number: siren, formal_name: "Acme SARL" },
      addresses,
    });

    const fresh = await findFreshDirectoryCacheBySiren(sql, siren);
    expect(fresh).toBeDefined();
    expect(fresh?.payload).toMatchObject({ number: siren, formal_name: "Acme SARL" });
    expect(fresh?.addresses).toEqual(addresses);
    expect(fresh?.expires_at.getTime()).toBeGreaterThan(Date.now());

    // Negative cache (not_found / disabled) — payload null + addresses [].
    const negativeSiren = "222222226";
    await upsertDirectoryCache(sql, { siren: negativeSiren, payload: null, addresses: [] });
    const neg = await findFreshDirectoryCacheBySiren(sql, negativeSiren);
    expect(neg?.payload).toBeNull();
    expect(neg?.addresses).toEqual([]);

    // Override on conflict — same siren, different payload.
    await upsertDirectoryCache(sql, {
      siren,
      payload: { number: siren, formal_name: "Acme SAS" },
      addresses: [],
    });
    const updated = await findFreshDirectoryCacheBySiren(sql, siren);
    expect(updated?.payload).toMatchObject({ formal_name: "Acme SAS" });
    expect(updated?.addresses).toEqual([]);
  });

  it("findFresh returns undefined when expires_at is past", async () => {
    const siren = "333333335";
    // Tight TTL of 0 seconds → expires_at = NOW() exactly. The
    // `expires_at > NOW()` filter excludes it on the next query.
    await upsertDirectoryCache(sql, { siren, payload: {}, addresses: [], ttlSeconds: 0 });
    // Add a tiny sleep to make sure NOW() at the SELECT moment is past
    // expires_at (Postgres NOW() resolution is microsecond, but a 1ms
    // wait is robust to clock skew on CI).
    await new Promise((resolve) => setTimeout(resolve, 5));
    expect(await findFreshDirectoryCacheBySiren(sql, siren)).toBeUndefined();
  });
});
