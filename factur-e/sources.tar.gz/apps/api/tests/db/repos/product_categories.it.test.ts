import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import {
  createProductCategory,
  deleteProductCategory,
  findProductCategoryById,
  listProductCategoriesByCustomer,
  updateProductCategory,
} from "../../../src/db/repos/product_categories.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

async function seedCustomer(sql: postgres.Sql, siren: string): Promise<string> {
  const rows = await sql<{ id: string }[]>`
    INSERT INTO customers (siren, legal_name) VALUES (${siren}, ${"Acme " + siren})
    RETURNING id
  `;
  const id = rows[0]?.id;
  if (id === undefined) throw new Error("seedCustomer");
  return id;
}

describe.skipIf(!enabled)("repos/product_categories (T-CL-11 sprint-03)", () => {
  let db: TestDb;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
  });

  afterAll(async () => {
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  it("create + findById + listByCustomer roundtrip", async () => {
    const customerId = await seedCustomer(sql, "111111118");

    expect(await listProductCategoriesByCustomer(sql, customerId)).toEqual([]);

    const created = await createProductCategory(sql, { customerId, label: "Prestations" });
    expect(created.label).toBe("Prestations");
    expect(created.customer_id).toBe(customerId);

    const fetched = await findProductCategoryById(sql, { id: created.id, customerId });
    expect(fetched?.label).toBe("Prestations");

    const list = await listProductCategoriesByCustomer(sql, customerId);
    expect(list.length).toBe(1);
  });

  it("listByCustomer ordre alphabétique", async () => {
    const customerId = await seedCustomer(sql, "111111118");
    await createProductCategory(sql, { customerId, label: "Zèbres" });
    await createProductCategory(sql, { customerId, label: "Alpes" });
    await createProductCategory(sql, { customerId, label: "Marais" });

    const list = await listProductCategoriesByCustomer(sql, customerId);
    expect(list.map((r) => r.label)).toEqual(["Alpes", "Marais", "Zèbres"]);
  });

  it("isolation multi-tenant : findById ne fuit pas inter-customer", async () => {
    const customerA = await seedCustomer(sql, "111111118");
    const customerB = await seedCustomer(sql, "552081317");
    const catA = await createProductCategory(sql, { customerId: customerA, label: "Conseil" });

    expect(
      await findProductCategoryById(sql, { id: catA.id, customerId: customerB }),
    ).toBeUndefined();
    expect(
      await findProductCategoryById(sql, { id: catA.id, customerId: customerA }),
    ).toBeDefined();
  });

  it("update modifie le label, updated_at avance", async () => {
    const customerId = await seedCustomer(sql, "111111118");
    const cat = await createProductCategory(sql, { customerId, label: "Avant" });
    await new Promise((r) => setTimeout(r, 5));

    const n = await updateProductCategory(sql, {
      id: cat.id,
      customerId,
      label: "Après",
    });
    expect(n).toBe(1);

    const fetched = await findProductCategoryById(sql, { id: cat.id, customerId });
    expect(fetched?.label).toBe("Après");
    if (fetched === undefined) throw new Error("expected fetched");
    expect(fetched.updated_at.getTime()).toBeGreaterThan(cat.updated_at.getTime());
  });

  it("delete = soft-delete (deleted_at), exclu des SELECTs", async () => {
    const customerId = await seedCustomer(sql, "111111118");
    const cat = await createProductCategory(sql, { customerId, label: "À supprimer" });

    const n = await deleteProductCategory(sql, { id: cat.id, customerId });
    expect(n).toBe(1);

    expect(await findProductCategoryById(sql, { id: cat.id, customerId })).toBeUndefined();
    expect(await listProductCategoriesByCustomer(sql, customerId)).toEqual([]);

    // Idempotent : 2e delete = 0 row affected.
    expect(await deleteProductCategory(sql, { id: cat.id, customerId })).toBe(0);
  });
});
