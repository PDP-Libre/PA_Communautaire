import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { createProductCategory } from "../../../src/db/repos/product_categories.js";
import {
  archiveProduct,
  createProduct,
  findProductById,
  findProductsByInternalCode,
  hardDeleteProduct,
  listProductsByCustomer,
  unarchiveProduct,
  updateProduct,
} from "../../../src/db/repos/products.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

async function seedCustomer(sql: postgres.Sql, siren: string): Promise<string> {
  const rows = await sql<{ id: string }[]>`
    INSERT INTO customers (siren, legal_name) VALUES (${siren}, ${"Acme " + siren})
    RETURNING id
  `;
  const id = rows[0]?.id;
  if (id === undefined) throw new Error("seedCustomer");
  return id;
}

describe.skipIf(!enabled)("repos/products (T-CL-11 sprint-03)", () => {
  let db: TestDb;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
  });

  afterAll(async () => {
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  it("create + findById roundtrip avec champs complets", async () => {
    const customerId = await seedCustomer(sql, "111111118");
    const cat = await createProductCategory(sql, { customerId, label: "Conseil" });

    const created = await createProduct(sql, {
      customerId,
      label: "Conseil junior 1h",
      description: "Heure de conseil junior",
      internalCode: "J1k",
      unitPriceHt: "100.0000",
      unit: "HUR",
      vatCategory: "S",
      vatRate: "20.00",
      categoryId: cat.id,
    });

    expect(created.label).toBe("Conseil junior 1h");
    expect(created.internal_code).toBe("J1k");
    expect(created.unit_price_ht).toBe("100.0000");
    expect(created.vat_category).toBe("S");
    expect(created.vat_rate).toBe("20.00");
    expect(created.category_id).toBe(cat.id);
    expect(created.is_archived).toBe(false);

    const fetched = await findProductById(sql, { id: created.id, customerId });
    expect(fetched?.label).toBe("Conseil junior 1h");
  });

  it("create avec defaults (unit + champs nullable)", async () => {
    const customerId = await seedCustomer(sql, "111111118");

    const created = await createProduct(sql, {
      customerId,
      label: "Forfait",
      unitPriceHt: "1500.0000",
      vatCategory: "AE",
    });

    expect(created.unit).toBe("unité");
    expect(created.description).toBeNull();
    expect(created.internal_code).toBeNull();
    expect(created.vat_rate).toBeNull();
    expect(created.category_id).toBeNull();
  });

  it("CHECK vat_category rejette une valeur hors enum", async () => {
    const customerId = await seedCustomer(sql, "111111118");
    await expect(
      createProduct(sql, {
        customerId,
        label: "Bad",
        unitPriceHt: "10.0000",
        vatCategory: "X" as never,
      }),
    ).rejects.toThrow(/vat_category/);
  });

  it("listByCustomer : exclut archivés par défaut, inclut si demandé", async () => {
    const customerId = await seedCustomer(sql, "111111118");
    const active = await createProduct(sql, {
      customerId,
      label: "Actif",
      unitPriceHt: "100.0000",
      vatCategory: "S",
      vatRate: "20.00",
    });
    const arch = await createProduct(sql, {
      customerId,
      label: "Archivé",
      unitPriceHt: "200.0000",
      vatCategory: "S",
      vatRate: "20.00",
    });
    await archiveProduct(sql, { id: arch.id, customerId });

    const def = await listProductsByCustomer(sql, customerId);
    expect(def.map((r) => r.id)).toEqual([active.id]);

    const all = await listProductsByCustomer(sql, customerId, { includeArchived: true });
    expect(all.length).toBe(2);
  });

  it("listByCustomer : filtre search ILIKE sur label", async () => {
    const customerId = await seedCustomer(sql, "111111118");
    await createProduct(sql, {
      customerId,
      label: "Conseil junior 1h",
      unitPriceHt: "100.0000",
      vatCategory: "S",
      vatRate: "20.00",
    });
    await createProduct(sql, {
      customerId,
      label: "Domiciliation mensuelle",
      unitPriceHt: "50.0000",
      vatCategory: "S",
      vatRate: "20.00",
    });

    const found = await listProductsByCustomer(sql, customerId, { search: "conseil" });
    expect(found.length).toBe(1);
    expect(found[0]?.label).toBe("Conseil junior 1h");

    const none = await listProductsByCustomer(sql, customerId, { search: "zzz" });
    expect(none).toEqual([]);
  });

  it("listByCustomer : filtre categoryId (valeur, null explicite)", async () => {
    const customerId = await seedCustomer(sql, "111111118");
    const cat = await createProductCategory(sql, { customerId, label: "Conseil" });
    const inCat = await createProduct(sql, {
      customerId,
      label: "A",
      unitPriceHt: "1.0000",
      vatCategory: "S",
      vatRate: "20.00",
      categoryId: cat.id,
    });
    const outCat = await createProduct(sql, {
      customerId,
      label: "B",
      unitPriceHt: "1.0000",
      vatCategory: "S",
      vatRate: "20.00",
    });

    const filtered = await listProductsByCustomer(sql, customerId, { categoryId: cat.id });
    expect(filtered.map((r) => r.id)).toEqual([inCat.id]);

    const orphans = await listProductsByCustomer(sql, customerId, { categoryId: null });
    expect(orphans.map((r) => r.id)).toEqual([outCat.id]);
  });

  it("findByInternalCode : doublons retournés en array", async () => {
    const customerId = await seedCustomer(sql, "111111118");
    await createProduct(sql, {
      customerId,
      label: "Conseil J1",
      internalCode: "J1k",
      unitPriceHt: "100.0000",
      vatCategory: "S",
      vatRate: "20.00",
    });
    await createProduct(sql, {
      customerId,
      label: "Conseil J1 bis",
      internalCode: "J1k",
      unitPriceHt: "120.0000",
      vatCategory: "S",
      vatRate: "20.00",
    });

    const matches = await findProductsByInternalCode(sql, { customerId, internalCode: "J1k" });
    expect(matches.length).toBe(2);

    const none = await findProductsByInternalCode(sql, { customerId, internalCode: "ABSENT" });
    expect(none).toEqual([]);
  });

  it("isolation multi-tenant : findById ne fuit pas, listByCustomer non plus", async () => {
    const customerA = await seedCustomer(sql, "111111118");
    const customerB = await seedCustomer(sql, "552081317");
    const prodA = await createProduct(sql, {
      customerId: customerA,
      label: "A",
      unitPriceHt: "10.0000",
      vatCategory: "S",
      vatRate: "20.00",
    });

    expect(await findProductById(sql, { id: prodA.id, customerId: customerB })).toBeUndefined();
    expect(await listProductsByCustomer(sql, customerB)).toEqual([]);
  });

  it("update : full row, updated_at avance", async () => {
    const customerId = await seedCustomer(sql, "111111118");
    const prod = await createProduct(sql, {
      customerId,
      label: "Avant",
      unitPriceHt: "100.0000",
      vatCategory: "S",
      vatRate: "20.00",
    });
    await new Promise((r) => setTimeout(r, 5));

    const n = await updateProduct(sql, {
      id: prod.id,
      customerId,
      label: "Après",
      description: "Nouvelle description",
      internalCode: "AP",
      unitPriceHt: "200.0000",
      unit: "heure",
      vatCategory: "Z",
      vatRate: null,
      categoryId: null,
    });
    expect(n).toBe(1);

    const fetched = await findProductById(sql, { id: prod.id, customerId });
    expect(fetched?.label).toBe("Après");
    expect(fetched?.unit_price_ht).toBe("200.0000");
    expect(fetched?.vat_category).toBe("Z");
    expect(fetched?.vat_rate).toBeNull();
    if (fetched === undefined) throw new Error("expected fetched");
    expect(fetched.updated_at.getTime()).toBeGreaterThan(prod.updated_at.getTime());
  });

  it("archive + unarchive idempotents, findById accessible des 2 côtés", async () => {
    const customerId = await seedCustomer(sql, "111111118");
    const prod = await createProduct(sql, {
      customerId,
      label: "X",
      unitPriceHt: "1.0000",
      vatCategory: "S",
      vatRate: "20.00",
    });

    expect(await archiveProduct(sql, { id: prod.id, customerId })).toBe(1);
    let fetched = await findProductById(sql, { id: prod.id, customerId });
    expect(fetched?.is_archived).toBe(true);

    expect(await unarchiveProduct(sql, { id: prod.id, customerId })).toBe(1);
    fetched = await findProductById(sql, { id: prod.id, customerId });
    expect(fetched?.is_archived).toBe(false);
  });

  it("hardDelete : stamp deleted_at, exclu de tout SELECT", async () => {
    const customerId = await seedCustomer(sql, "111111118");
    const prod = await createProduct(sql, {
      customerId,
      label: "X",
      unitPriceHt: "1.0000",
      vatCategory: "S",
      vatRate: "20.00",
    });

    expect(await hardDeleteProduct(sql, { id: prod.id, customerId })).toBe(1);
    expect(await findProductById(sql, { id: prod.id, customerId })).toBeUndefined();
    expect(await listProductsByCustomer(sql, customerId)).toEqual([]);
    expect(await listProductsByCustomer(sql, customerId, { includeArchived: true })).toEqual([]);
  });

  it("FK category_id ON DELETE SET NULL : product orphan préservé", async () => {
    const customerId = await seedCustomer(sql, "111111118");
    const cat = await createProductCategory(sql, { customerId, label: "Conseil" });
    const prod = await createProduct(sql, {
      customerId,
      label: "Lié",
      unitPriceHt: "1.0000",
      vatCategory: "S",
      vatRate: "20.00",
      categoryId: cat.id,
    });
    // Hard-delete physique de la catégorie (le repo soft-delete via deleted_at,
    // mais ici on simule un admin DELETE qui retire la row pour valider la FK).
    await sql`DELETE FROM product_categories WHERE id = ${cat.id}`;

    const fetched = await findProductById(sql, { id: prod.id, customerId });
    expect(fetched?.category_id).toBeNull();
  });
});
