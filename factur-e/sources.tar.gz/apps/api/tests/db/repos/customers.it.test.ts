import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import {
  findCustomerJuridiqueCodeById,
  findCustomerLegalNameById,
  findCustomerLogoKeyById,
  insertCustomerFromPhase1,
  markCustomerCapitalSocial,
  markCustomerLogoKey,
  markCustomerTradingName,
} from "../../../src/db/repos/customers.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("repos/customers", () => {
  let db: TestDb;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
  });

  afterAll(async () => {
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  it("insertCustomerFromPhase1 + readers + mark<Field> setters", async () => {
    const inserted = await insertCustomerFromPhase1(sql, {
      siren: "987654321",
      legalName: "Acme SAS",
      address: { street: "1 rue de Test", zip: "75001", city: "Paris", country_code: "FR" },
      nafCode: "62.01Z",
      juridiqueCode: "5710",
      directoryAddress: "987654321",
      profileUnverified: true,
    });

    expect(await findCustomerLegalNameById(sql, inserted.id)).toEqual({ legal_name: "Acme SAS" });
    expect(await findCustomerJuridiqueCodeById(sql, inserted.id)).toEqual({
      juridique_code: "5710",
    });
    expect(await findCustomerLogoKeyById(sql, inserted.id)).toEqual({ logo_s3_key: null });

    await markCustomerTradingName(sql, inserted.id, "Acme Tech");
    await markCustomerLogoKey(sql, inserted.id, "customers/123/logo.png");
    await markCustomerCapitalSocial(sql, inserted.id, 50_000);

    const after = await sql<
      { trading_name: string | null; logo_s3_key: string | null; capital_social: string | null }[]
    >`
      SELECT trading_name, logo_s3_key, capital_social::text AS capital_social
      FROM customers WHERE id = ${inserted.id}
    `;
    expect(after[0]).toEqual({
      trading_name: "Acme Tech",
      logo_s3_key: "customers/123/logo.png",
      capital_social: "50000.00",
    });
  });
});
