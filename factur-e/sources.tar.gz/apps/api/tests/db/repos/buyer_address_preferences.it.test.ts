import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import {
  findBuyerAddressPreference,
  markBuyerAddressPreferenceUsed,
  upsertBuyerAddressPreference,
} from "../../../src/db/repos/buyer_address_preferences.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("repos/buyer_address_preferences (T-CL-09 sprint-03)", () => {
  let db: TestDb;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
  });

  afterAll(async () => {
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  async function seedCustomer(): Promise<string> {
    const rows = await sql<{ id: string }[]>`
      INSERT INTO customers (siren, legal_name) VALUES (${"100000020"}, ${"Acme"})
      RETURNING id
    `;
    return rows[0]?.id ?? "";
  }

  it("upsert + find + mark used roundtrip + override on conflict", async () => {
    const customerId = await seedCustomer();
    const buyerSiren = "444444443";

    expect(await findBuyerAddressPreference(sql, { customerId, buyerSiren })).toBeUndefined();

    await upsertBuyerAddressPreference(sql, {
      customerId,
      buyerSiren,
      preferredPartyId: "0225:444444443_dgfip",
    });
    const initial = await findBuyerAddressPreference(sql, { customerId, buyerSiren });
    expect(initial?.preferred_party_id).toBe("0225:444444443_dgfip");
    const initialUsedAt = initial?.last_used_at;
    expect(initialUsedAt).toBeDefined();

    // mark used : touch last_used_at without changing party_id.
    await new Promise((resolve) => setTimeout(resolve, 5));
    await markBuyerAddressPreferenceUsed(sql, { customerId, buyerSiren });
    const touched = await findBuyerAddressPreference(sql, { customerId, buyerSiren });
    expect(touched?.preferred_party_id).toBe("0225:444444443_dgfip");
    if (initialUsedAt !== undefined && touched?.last_used_at !== undefined) {
      expect(touched.last_used_at.getTime()).toBeGreaterThan(initialUsedAt.getTime());
    }

    // Override on conflict — user changes preference.
    await upsertBuyerAddressPreference(sql, {
      customerId,
      buyerSiren,
      preferredPartyId: "0225:444444443_other",
    });
    const updated = await findBuyerAddressPreference(sql, { customerId, buyerSiren });
    expect(updated?.preferred_party_id).toBe("0225:444444443_other");
  });

  it("isolates preferences by (customer_id, buyer_siren) couple", async () => {
    const c1 = await seedCustomer();
    const c2Rows = await sql<{ id: string }[]>`
      INSERT INTO customers (siren, legal_name) VALUES (${"100000021"}, ${"Other"})
      RETURNING id
    `;
    const c2 = c2Rows[0]?.id ?? "";

    await upsertBuyerAddressPreference(sql, {
      customerId: c1,
      buyerSiren: "555555556",
      preferredPartyId: "c1-pref",
    });
    await upsertBuyerAddressPreference(sql, {
      customerId: c2,
      buyerSiren: "555555556",
      preferredPartyId: "c2-pref",
    });

    expect(
      (await findBuyerAddressPreference(sql, { customerId: c1, buyerSiren: "555555556" }))
        ?.preferred_party_id,
    ).toBe("c1-pref");
    expect(
      (await findBuyerAddressPreference(sql, { customerId: c2, buyerSiren: "555555556" }))
        ?.preferred_party_id,
    ).toBe("c2-pref");
  });
});
