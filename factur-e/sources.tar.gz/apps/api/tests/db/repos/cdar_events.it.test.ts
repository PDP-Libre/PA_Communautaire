import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { findCdarEventsByInvoiceId, insertCdarEvent } from "../../../src/db/repos/cdar_events.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

/**
 * Tests repo `cdar_events` — sprint-04 T-CL-API-INVOICE.
 *
 * **Test idempotence ADR-009 D4** : INSERT 2× avec même
 * `(invoice_id, code, occurred_at)` → 2ème INSERT no-op via
 * `ON CONFLICT DO NOTHING`. Critique pour la doctrine fail-safe
 * degradation (webhook + polling hybride T-CL-PA-EXT — pas de doublons).
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("cdar_events repo", () => {
  let db: TestDb;
  let sql: postgres.Sql;
  let invoiceId: string;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
  });

  afterAll(async () => {
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    // Setup minimal : 1 customer + 1 invoice pour avoir un invoice_id valide.
    const customer = await sql<{ id: string }[]>`
      INSERT INTO customers (siren, legal_name)
      VALUES ('111111118', 'Ma Boîte')
      RETURNING id
    `;
    const customerId = customer[0]?.id ?? "";
    const invoice = await sql<{ id: string }[]>`
      INSERT INTO invoices (customer_id, number, issue_date, total_ht, total_vat, total_ttc)
      VALUES (${customerId}, 'F-TEST-001', '2026-05-16', '100', '20', '120')
      RETURNING id
    `;
    invoiceId = invoice[0]?.id ?? "";
  });

  it("idempotence : 2× INSERT (invoice_id, code, occurred_at) → 1 row + 2e inserted=false", async () => {
    const occurredAt = new Date("2026-05-16T10:00:00Z");

    const first = await insertCdarEvent(sql, {
      invoice_id: invoiceId,
      code: "Déposée",
      occurred_at: occurredAt,
      source: "synthetic",
    });
    expect(first.inserted).toBe(true);
    expect(first.id).toMatch(/^[0-9a-f-]{36}$/);

    // 2ème insert avec la même clé naturelle → no-op
    const second = await insertCdarEvent(sql, {
      invoice_id: invoiceId,
      code: "Déposée",
      occurred_at: occurredAt,
      source: "webhook", // source différente mais clé naturelle identique
    });
    expect(second.inserted).toBe(false);
    expect(second.id).toBeNull();

    // BDD : 1 seul row physique (vs 2 si idempotence cassée)
    const rows = await findCdarEventsByInvoiceId(sql, invoiceId);
    expect(rows).toHaveLength(1);
    expect(rows[0]?.source).toBe("synthetic"); // 1er gagne (DO NOTHING)
  });

  it("différents occurred_at sur même code → 2 events distincts", async () => {
    const a = new Date("2026-05-16T10:00:00Z");
    const b = new Date("2026-05-16T10:01:00Z");

    await insertCdarEvent(sql, {
      invoice_id: invoiceId,
      code: "Déposée",
      occurred_at: a,
      source: "synthetic",
    });
    await insertCdarEvent(sql, {
      invoice_id: invoiceId,
      code: "Déposée",
      occurred_at: b,
      source: "webhook",
    });

    const rows = await findCdarEventsByInvoiceId(sql, invoiceId);
    expect(rows).toHaveLength(2);
  });

  it("ordering ASC par occurred_at", async () => {
    const a = new Date("2026-05-16T10:00:00Z");
    const b = new Date("2026-05-16T11:00:00Z");
    const c = new Date("2026-05-16T12:00:00Z");

    // Insert dans le désordre
    await insertCdarEvent(sql, {
      invoice_id: invoiceId,
      code: "B",
      occurred_at: b,
      source: "synthetic",
    });
    await insertCdarEvent(sql, {
      invoice_id: invoiceId,
      code: "C",
      occurred_at: c,
      source: "synthetic",
    });
    await insertCdarEvent(sql, {
      invoice_id: invoiceId,
      code: "A",
      occurred_at: a,
      source: "synthetic",
    });

    const rows = await findCdarEventsByInvoiceId(sql, invoiceId);
    expect(rows.map((r) => r.code)).toEqual(["A", "B", "C"]);
  });
});
