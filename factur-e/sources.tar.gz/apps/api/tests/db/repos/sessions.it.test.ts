import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { hashPassword } from "../../../src/auth/argon2.js";
import {
  deleteSessionsByUserId,
  findActiveSessionForRefresh,
  revokeSessionById,
} from "../../../src/db/repos/sessions.js";
import { insertUserFromInvitation } from "../../../src/db/repos/users.js";
import { insertSession } from "../../../src/db/tx.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("repos/sessions", () => {
  let db: TestDb;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
  });

  afterAll(async () => {
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  async function seedUser(): Promise<string> {
    const customer = await sql<{ id: string }[]>`
      INSERT INTO customers (siren, legal_name) VALUES (${"111111111"}, ${"Acme"}) RETURNING id
    `;
    const customerId = customer[0]?.id ?? "";
    const userId = "00000000-0000-0000-0000-00000000feed";
    await insertUserFromInvitation(sql, {
      id: userId,
      customerId,
      email: "u@acme.fr",
      passwordHash: await hashPassword("Password123!"),
      role: "deposit_simple",
      canPurchase: false,
    });
    return userId;
  }

  it("insertSession via tx helper + findActiveSessionForRefresh + revokeSessionById", async () => {
    const userId = await seedUser();
    const sessionId = "00000000-0000-0000-0000-00000000aaaa";

    await insertSession(sql, { id: sessionId, userId, ip: "127.0.0.1", userAgent: "Mocha/1.0" });

    const found = await findActiveSessionForRefresh(sql, { sessionId, userId });
    expect(found).toEqual({ id: sessionId });

    await revokeSessionById(sql, sessionId);
    expect(await findActiveSessionForRefresh(sql, { sessionId, userId })).toBeUndefined();
  });

  it("deleteSessionsByUserId drops every live session at once", async () => {
    const userId = await seedUser();
    await insertSession(sql, {
      id: "00000000-0000-0000-0000-00000000bbbb",
      userId,
      ip: null,
      userAgent: null,
    });
    await insertSession(sql, {
      id: "00000000-0000-0000-0000-00000000cccc",
      userId,
      ip: null,
      userAgent: null,
    });

    const before = await sql<{ n: string }[]>`
      SELECT COUNT(*)::text AS n FROM sessions WHERE user_id = ${userId}
    `;
    expect(Number(before[0]?.n)).toBe(2);

    await deleteSessionsByUserId(sql, userId);

    const after = await sql<{ n: string }[]>`
      SELECT COUNT(*)::text AS n FROM sessions WHERE user_id = ${userId}
    `;
    expect(Number(after[0]?.n)).toBe(0);
  });
});
