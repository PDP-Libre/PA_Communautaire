import { randomUUID } from "node:crypto";

import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { hashPassword } from "../../../src/auth/argon2.js";
import {
  deletePendingInvitationByCustomerAndEmail,
  deletePendingInvitationByIdAndCustomer,
  findInvitationExpiresAtById,
  findInvitationForAcceptById,
  findPendingInvitationsByCustomer,
  insertInvitation,
  markInvitationAccepted,
} from "../../../src/db/repos/invitations.js";
import { insertUserFromInvitation } from "../../../src/db/repos/users.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("repos/invitations", () => {
  let db: TestDb;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
  });

  afterAll(async () => {
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  async function seedInviter(): Promise<{ customerId: string; inviterId: string }> {
    const customer = await sql<{ id: string }[]>`
      INSERT INTO customers (siren, legal_name) VALUES (${"222222222"}, ${"Acme"}) RETURNING id
    `;
    const customerId = customer[0]?.id ?? "";
    const inviterId = randomUUID();
    await insertUserFromInvitation(sql, {
      id: inviterId,
      customerId,
      email: "inviter@acme.fr",
      passwordHash: await hashPassword("Password123!"),
      role: "full",
      canPurchase: true,
    });
    return { customerId, inviterId };
  }

  it("insert + list + accept lifecycle", async () => {
    const { customerId, inviterId } = await seedInviter();
    const id = randomUUID();

    await insertInvitation(sql, {
      id,
      customerId,
      inviterId,
      email: "invitee@acme.fr",
      role: "deposit_simple",
      canPurchase: false,
      tokenHash: "$bcrypt-hash",
      ttlDays: 7,
    });

    const expires = await findInvitationExpiresAtById(sql, id);
    expect(expires?.expires_at.getTime()).toBeGreaterThan(Date.now());

    const list = await findPendingInvitationsByCustomer(sql, customerId);
    expect(list).toHaveLength(1);
    expect(list[0]?.email).toBe("invitee@acme.fr");

    const inv = await findInvitationForAcceptById(sql, id);
    expect(inv?.accepted_at).toBeNull();

    await markInvitationAccepted(sql, id);
    const list2 = await findPendingInvitationsByCustomer(sql, customerId);
    expect(list2).toHaveLength(0);
  });

  it("delete pending by (customer, email) + by (id, customer) scopes", async () => {
    const { customerId, inviterId } = await seedInviter();
    const id1 = randomUUID();
    const id2 = randomUUID();

    await insertInvitation(sql, {
      id: id1,
      customerId,
      inviterId,
      email: "a@acme.fr",
      role: "deposit_simple",
      canPurchase: false,
      tokenHash: "$h1",
      ttlDays: 7,
    });
    await insertInvitation(sql, {
      id: id2,
      customerId,
      inviterId,
      email: "b@acme.fr",
      role: "deposit_simple",
      canPurchase: false,
      tokenHash: "$h2",
      ttlDays: 7,
    });

    // delete by (customer, email) only touches matching rows
    await deletePendingInvitationByCustomerAndEmail(sql, { customerId, email: "a@acme.fr" });
    expect(await findInvitationForAcceptById(sql, id1)).toBeUndefined();
    expect(await findInvitationForAcceptById(sql, id2)).not.toBeUndefined();

    // delete by id returns count for 404 vs 204
    const dropped = await deletePendingInvitationByIdAndCustomer(sql, { id: id2, customerId });
    expect(dropped).toBe(1);
    const droppedAgain = await deletePendingInvitationByIdAndCustomer(sql, {
      id: id2,
      customerId,
    });
    expect(droppedAgain).toBe(0);
  });
});
