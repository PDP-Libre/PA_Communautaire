import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { hashPassword } from "../../../src/auth/argon2.js";
import {
  deletePendingByEmailNonDecoy,
  deletePendingById,
  findActivePendingDigestById,
  findPendingFullById,
  insertPending,
  markPendingEmailVerified,
  markPendingSirenChosen,
} from "../../../src/db/repos/signup_pending.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("repos/signup_pending", () => {
  let db: TestDb;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
  });

  afterAll(async () => {
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  it("insertPending + findActivePendingDigestById + mark<Step> markers", async () => {
    const passwordHash = await hashPassword("Password123!");

    const inserted = await insertPending(sql, {
      email: "po@acme.fr",
      passwordHash,
      isDecoy: false,
    });

    expect(inserted.current_step).toBe("siren");

    const digest = await findActivePendingDigestById(sql, inserted.id);
    expect(digest?.email).toBe("po@acme.fr");
    expect(digest?.is_decoy).toBe(false);

    await markPendingSirenChosen(sql, inserted.id, {
      siren: "123456789",
      prefilled: { legal_name: "Acme" },
    });
    await markPendingEmailVerified(sql, inserted.id);

    const full = await findPendingFullById(sql, inserted.id);
    expect(full?.siren).toBe("123456789");
    expect(full?.email_verified_at).not.toBeNull();
    expect(full?.current_step).toBe("secondary_email");
  });

  it("deletePendingByEmailNonDecoy + deletePendingById are scoped correctly", async () => {
    const passwordHash = await hashPassword("Password123!");

    const decoy = await insertPending(sql, {
      email: "x@acme.fr",
      passwordHash,
      isDecoy: true,
    });
    const real = await insertPending(sql, {
      email: "x@acme.fr",
      passwordHash,
      isDecoy: false,
    });

    // dedupe non-decoy on retry, decoy untouched
    await deletePendingByEmailNonDecoy(sql, "x@acme.fr");
    expect(await findActivePendingDigestById(sql, real.id)).toBeUndefined();
    expect(await findActivePendingDigestById(sql, decoy.id)).not.toBeUndefined();

    // explicit single-id delete still works on the decoy
    await deletePendingById(sql, decoy.id);
    expect(await findActivePendingDigestById(sql, decoy.id)).toBeUndefined();
  });
});
