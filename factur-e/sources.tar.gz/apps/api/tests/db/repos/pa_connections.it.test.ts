import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import {
  findActivePaConnectionForDisconnectByCustomerId,
  findActivePaConnectionStatusByCustomerId,
  findPaConnectionsForIdentityPolling,
  findPaConnectionsForRefresh,
  insertPaConnection,
  markPaConnectionIdentityStatuses,
  markPaConnectionRefreshFailureIncrement,
  markPaConnectionRefreshed,
  markPaConnectionRevoked,
} from "../../../src/db/repos/pa_connections.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("repos/pa_connections (T-CL-04 sprint-03)", () => {
  let db: TestDb;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
  });

  afterAll(async () => {
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  async function seedCustomer(siren = "111111111"): Promise<string> {
    const rows = await sql<{ id: string }[]>`
      INSERT INTO customers (siren, legal_name) VALUES (${siren}, ${"Acme"}) RETURNING id
    `;
    return rows[0]?.id ?? "";
  }

  it("roundtrip insert + find + mark identity + mark refreshed + mark revoked + reconnect", async () => {
    const customerId = await seedCustomer();

    // INSERT — needs_review on user, verified on company (a real-world
    // edge case ADR-005 D7 covers).
    const inserted = await insertPaConnection(sql, {
      customerId,
      paUserId: "pa-user-42",
      secretRef: "factur-e-superpdp-keychain-fixture",
      userIdentityStatus: "needs_review",
      companyStatus: "verified",
    });
    expect(inserted.id).toMatch(/^[0-9a-f-]{36}$/);

    // STATUS lookup — what /api/pa/status will read.
    const status = await findActivePaConnectionStatusByCustomerId(sql, customerId);
    expect(status).toBeDefined();
    expect(status?.id).toBe(inserted.id);
    expect(status?.pa_user_id).toBe("pa-user-42");
    expect(status?.user_identity_verification_status).toBe("needs_review");
    expect(status?.company_verification_status).toBe("verified");
    expect(status?.last_refreshed_at).toBeNull();

    // POLLING list — should contain this row because user status is needs_review.
    const polling = await findPaConnectionsForIdentityPolling(sql);
    expect(polling.map((r) => r.id)).toEqual([inserted.id]);

    // mark identity statuses (the polling job's update path).
    await markPaConnectionIdentityStatuses(sql, inserted.id, {
      user: "verified",
      company: "verified",
    });
    const polling2 = await findPaConnectionsForIdentityPolling(sql);
    expect(polling2).toEqual([]);

    // REFRESH list — fresh connection (last_refreshed_at IS NULL) is due.
    const refreshDue = await findPaConnectionsForRefresh(sql, 1500);
    expect(refreshDue.map((r) => r.id)).toEqual([inserted.id]);

    // mark refreshed → no longer due (just refreshed).
    await markPaConnectionRefreshed(sql, inserted.id);
    const refreshDue2 = await findPaConnectionsForRefresh(sql, 1500);
    expect(refreshDue2).toEqual([]);

    // mark refresh failure increments and returns new count.
    const after1 = await markPaConnectionRefreshFailureIncrement(sql, inserted.id);
    expect(after1).toBe(1);
    const after2 = await markPaConnectionRefreshFailureIncrement(sql, inserted.id);
    expect(after2).toBe(2);

    // DISCONNECT lookup — finds the active row.
    const forDisconnect = await findActivePaConnectionForDisconnectByCustomerId(sql, customerId);
    expect(forDisconnect?.id).toBe(inserted.id);
    expect(forDisconnect?.refresh_failures_count).toBe(2);

    // mark revoked (disconnect path) — soft-deletes.
    await markPaConnectionRevoked(sql, inserted.id);
    const statusAfter = await findActivePaConnectionStatusByCustomerId(sql, customerId);
    expect(statusAfter).toBeUndefined();

    // RECONNECT — once the previous row is soft-deleted, the partial
    // UNIQUE index releases the slot so a new INSERT for the same
    // (customer_id, provider) works without violation. Validates the
    // forward-compat / historic-reconnect motivation behind Option B.
    const reconnected = await insertPaConnection(sql, {
      customerId,
      paUserId: "pa-user-42-bis",
      secretRef: "factur-e-superpdp-keychain-fixture-2",
      userIdentityStatus: "verified",
      companyStatus: "verified",
    });
    expect(reconnected.id).not.toBe(inserted.id);

    const statusReconnected = await findActivePaConnectionStatusByCustomerId(sql, customerId);
    expect(statusReconnected?.id).toBe(reconnected.id);
    expect(statusReconnected?.pa_user_id).toBe("pa-user-42-bis");
  });

  it("partial UNIQUE forbids two active rows on the same (customer_id, provider)", async () => {
    const customerId = await seedCustomer();
    await insertPaConnection(sql, {
      customerId,
      paUserId: "u1",
      secretRef: "ref1",
      userIdentityStatus: "verified",
      companyStatus: "verified",
    });
    await expect(
      insertPaConnection(sql, {
        customerId,
        paUserId: "u2",
        secretRef: "ref2",
        userIdentityStatus: "verified",
        companyStatus: "verified",
      }),
    ).rejects.toThrow(/duplicate key|unique/i);
  });
});
