import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { hashPassword } from "../../../src/auth/argon2.js";
import {
  countActiveFullsByCustomer,
  findActiveUserByEmail,
  findActiveUserCustomerById,
  findActiveUserRoleById,
  findUserIdByEmailAnyState,
  insertUserFromInvitation,
  insertUserFromPhase1,
  markLastLogin,
  markRole,
  markUserDeleted,
} from "../../../src/db/repos/users.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("repos/users", () => {
  let db: TestDb;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
  });

  afterAll(async () => {
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  async function seedCustomer(): Promise<string> {
    const rows = await sql<{ id: string }[]>`
      INSERT INTO customers (siren, legal_name) VALUES (${"123456789"}, ${"Acme"}) RETURNING id
    `;
    return rows[0]?.id ?? "";
  }

  it("insertUserFromPhase1 + findActiveUserByEmail roundtrip", async () => {
    const customerId = await seedCustomer();
    const passwordHash = await hashPassword("Password123!");

    const inserted = await insertUserFromPhase1(sql, {
      customerId,
      email: "po@acme.fr",
      passwordHash,
      mfaSecret: null,
      mfaMode: "none",
      mfaEnrolledAt: null,
      recoveryCodesHashed: null,
      role: "full",
      canPurchase: true,
      emailVerifiedAt: new Date(),
      secondaryEmail: "po+secours@acme.fr",
      secondaryEmailVerifiedAt: new Date(),
      termsAcceptedAt: new Date(),
    });

    const found = await findActiveUserByEmail(sql, "po@acme.fr");
    expect(found?.id).toBe(inserted.id);
    expect(found?.role).toBe("full");

    // soft-deleted users disappear from findActive*By*
    await markUserDeleted(sql, inserted.id);
    expect(await findActiveUserByEmail(sql, "po@acme.fr")).toBeUndefined();

    // but findUserIdByEmailAnyState still returns them (used for collision
    // detection at signup / invitation accept).
    expect(await findUserIdByEmailAnyState(sql, "po@acme.fr")).toEqual({ id: inserted.id });
  });

  it("findActiveUserCustomerById + role/markRole + countActiveFullsByCustomer", async () => {
    const customerId = await seedCustomer();
    const passwordHash = await hashPassword("Password123!");

    const u1 = await insertUserFromPhase1(sql, {
      customerId,
      email: "f1@acme.fr",
      passwordHash,
      mfaSecret: null,
      mfaMode: "none",
      mfaEnrolledAt: null,
      recoveryCodesHashed: null,
      role: "full",
      canPurchase: true,
      emailVerifiedAt: new Date(),
      secondaryEmail: "",
      secondaryEmailVerifiedAt: null,
      termsAcceptedAt: new Date(),
    });

    const fetched = await findActiveUserCustomerById(sql, u1.id);
    expect(fetched).toEqual({ id: u1.id, customer_id: customerId });
    expect(await findActiveUserRoleById(sql, u1.id)).toEqual({ role: "full" });
    expect(await countActiveFullsByCustomer(sql, customerId)).toBe(1);

    await markRole(sql, u1.id, "deposit_simple");
    expect(await findActiveUserRoleById(sql, u1.id)).toEqual({ role: "deposit_simple" });
    expect(await countActiveFullsByCustomer(sql, customerId)).toBe(0);
  });

  it("markLastLogin updates last_login_at to NOW()", async () => {
    const customerId = await seedCustomer();
    const passwordHash = await hashPassword("Password123!");
    await insertUserFromInvitation(sql, {
      id: "00000000-0000-0000-0000-00000000abcd",
      customerId,
      email: "inv@acme.fr",
      passwordHash,
      role: "deposit_simple",
      canPurchase: false,
    });

    const before = await sql<{ last_login_at: Date | null }[]>`
      SELECT last_login_at FROM users WHERE email = ${"inv@acme.fr"}
    `;
    expect(before[0]?.last_login_at).toBeNull();

    await markLastLogin(sql, "00000000-0000-0000-0000-00000000abcd");

    const after = await sql<{ last_login_at: Date | null }[]>`
      SELECT last_login_at FROM users WHERE email = ${"inv@acme.fr"}
    `;
    expect(after[0]?.last_login_at).not.toBeNull();
  });
});
