import { describe, expect, it } from "vitest";

import { ScalewaySecretManagerStore } from "../../src/secrets/index.js";

/**
 * Wrapper Scaleway Secret Manager — tests via `fetch` injection.
 * Aucune connexion HTTP réelle : on observe seulement les URLs/methods
 * envoyés et on contrôle les réponses.
 */

interface RecordedCall {
  url: string;
  method: string;
  bodyJson?: unknown;
}

function makeFakeFetch(
  routes: Record<string, (call: RecordedCall) => Response | Promise<Response>>,
): { fetchFn: typeof globalThis.fetch; calls: RecordedCall[] } {
  const calls: RecordedCall[] = [];
  const fetchFn: typeof globalThis.fetch = async (input, init) => {
    const url = typeof input === "string" ? input : input instanceof URL ? input.href : input.url;
    const method = (init?.method ?? "GET").toUpperCase();
    let bodyJson: unknown;
    if (typeof init?.body === "string") {
      try {
        bodyJson = JSON.parse(init.body);
      } catch {
        bodyJson = init.body;
      }
    }
    const call: RecordedCall = { url, method, bodyJson };
    calls.push(call);
    const handler = routes[`${method} ${url.replace(/^https?:\/\/[^/]+/, "")}`];
    if (handler === undefined) {
      return Promise.resolve(new Response("not stubbed", { status: 599 }));
    }
    return handler(call);
  };
  return { fetchFn, calls };
}

describe("ScalewaySecretManagerStore (HTTPS API via fetch injection)", () => {
  const baseUrl = "http://fake.scw";
  const region = "fr-par";
  const path = "/secret-manager/v1beta1/regions/fr-par";

  it("get() returns null when secrets-by-path returns 404", async () => {
    const { fetchFn } = makeFakeFetch({
      [`GET ${path}/secrets-by-path?secret_path=${encodeURIComponent("/factur-e/staging/superpdp/c1/bundle")}`]:
        () => new Response(null, { status: 404 }),
    });
    const store = new ScalewaySecretManagerStore({
      apiToken: "tok",
      region,
      baseUrl,
      fetch: fetchFn,
    });
    expect(await store.get("/factur-e/staging/superpdp/c1/bundle")).toBeNull();
  });

  it("get() resolves id then accesses latest_enabled version (base64 decode)", async () => {
    const bundle = {
      accessToken: "a",
      refreshToken: "r",
      accessExpiresAt: "2026-05-06T10:00:00.000Z",
    };
    const data = Buffer.from(JSON.stringify(bundle), "utf8").toString("base64");
    const { fetchFn } = makeFakeFetch({
      [`GET ${path}/secrets-by-path?secret_path=${encodeURIComponent("/factur-e/staging/superpdp/c1/bundle")}`]:
        () => new Response(JSON.stringify({ id: "sec-id-1" }), { status: 200 }),
      [`GET ${path}/secrets/sec-id-1/versions/latest_enabled/access`]: () =>
        new Response(JSON.stringify({ data }), { status: 200 }),
    });
    const store = new ScalewaySecretManagerStore({
      apiToken: "tok",
      region,
      baseUrl,
      fetch: fetchFn,
    });
    expect(await store.get("/factur-e/staging/superpdp/c1/bundle")).toEqual(bundle);
  });

  it("put() creates secret on first call, then versions on subsequent", async () => {
    const calls: RecordedCall[] = [];
    let secretIdAfterCreate: string | null = null;
    const fetchFn: typeof globalThis.fetch = (input, init) => {
      const url = typeof input === "string" ? input : input instanceof URL ? input.href : input.url;
      const method = (init?.method ?? "GET").toUpperCase();
      const bodyJson: unknown = typeof init?.body === "string" ? JSON.parse(init.body) : undefined;
      calls.push({ url, method, bodyJson });
      // First put : resolveSecretId returns 404, then create returns id, then version.
      if (method === "GET" && url.includes("/secrets-by-path")) {
        if (secretIdAfterCreate === null)
          return Promise.resolve(new Response(null, { status: 404 }));
        return Promise.resolve(
          new Response(JSON.stringify({ id: secretIdAfterCreate }), { status: 200 }),
        );
      }
      if (method === "POST" && url.endsWith("/secrets")) {
        secretIdAfterCreate = "sec-fresh";
        return Promise.resolve(new Response(JSON.stringify({ id: "sec-fresh" }), { status: 200 }));
      }
      if (method === "POST" && url.endsWith("/versions")) {
        return Promise.resolve(new Response(JSON.stringify({ revision: 1 }), { status: 200 }));
      }
      return Promise.resolve(new Response("unexpected", { status: 599 }));
    };
    const store = new ScalewaySecretManagerStore({
      apiToken: "tok",
      region,
      baseUrl,
      fetch: fetchFn,
    });
    const bundle = {
      accessToken: "a",
      refreshToken: "r",
      accessExpiresAt: "2026-05-06T10:00:00.000Z",
    };
    await store.put("/factur-e/prod/superpdp/c1/bundle", bundle);
    // Sequence : resolve(404) -> create -> version
    expect(calls.map((c) => `${c.method} ${c.url.replace(baseUrl, "")}`)).toEqual([
      `GET ${path}/secrets-by-path?secret_path=${encodeURIComponent("/factur-e/prod/superpdp/c1/bundle")}`,
      `POST ${path}/secrets`,
      `POST ${path}/secrets/sec-fresh/versions`,
    ]);
    // Body of /versions must contain the base64-encoded bundle.
    const versionCall = calls[2];
    expect(versionCall).toBeDefined();
    const versionBody = versionCall?.bodyJson as { data: string };
    expect(JSON.parse(Buffer.from(versionBody.data, "base64").toString("utf8"))).toEqual(bundle);
  });

  it("delete() is idempotent — 404 on resolve = noop", async () => {
    const { fetchFn } = makeFakeFetch({
      [`GET ${path}/secrets-by-path?secret_path=${encodeURIComponent("/missing")}`]: () =>
        new Response(null, { status: 404 }),
    });
    const store = new ScalewaySecretManagerStore({
      apiToken: "tok",
      region,
      baseUrl,
      fetch: fetchFn,
    });
    await expect(store.delete("/missing")).resolves.toBeUndefined();
  });
});
