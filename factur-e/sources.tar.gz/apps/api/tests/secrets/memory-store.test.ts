import { describe, expect, it } from "vitest";

import { MemorySecretStore } from "../../src/secrets/index.js";

describe("MemorySecretStore", () => {
  it("get/put/delete roundtrip", async () => {
    const store = new MemorySecretStore();
    expect(await store.get("ref-1")).toBeNull();

    await store.put("ref-1", {
      accessToken: "a",
      refreshToken: "r",
      accessExpiresAt: "2026-05-06T10:00:00.000Z",
    });
    const after = await store.get("ref-1");
    expect(after).toEqual({
      accessToken: "a",
      refreshToken: "r",
      accessExpiresAt: "2026-05-06T10:00:00.000Z",
    });

    // put overwrites silently.
    await store.put("ref-1", {
      accessToken: "a2",
      refreshToken: "r2",
      accessExpiresAt: "2026-05-06T11:00:00.000Z",
    });
    expect((await store.get("ref-1"))?.accessToken).toBe("a2");

    await store.delete("ref-1");
    expect(await store.get("ref-1")).toBeNull();

    // delete idempotent on absent.
    await expect(store.delete("ref-1")).resolves.toBeUndefined();
  });

  it("isolates entries by secretRef", async () => {
    const store = new MemorySecretStore();
    await store.put("a", { accessToken: "Xa", refreshToken: "Xr", accessExpiresAt: "x" });
    await store.put("b", { accessToken: "Ya", refreshToken: "Yr", accessExpiresAt: "y" });
    expect((await store.get("a"))?.accessToken).toBe("Xa");
    expect((await store.get("b"))?.accessToken).toBe("Ya");
  });
});
