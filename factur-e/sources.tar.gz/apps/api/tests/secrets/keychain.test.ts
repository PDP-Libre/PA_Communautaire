import { afterEach, describe, expect, it } from "vitest";

import { KeychainSecretStore } from "../../src/secrets/index.js";

/**
 * Keychain wrapper — opt-in test. Touche le vrai Keychain macOS via
 * `security` CLI. Activé uniquement si `KEYCHAIN_TEST_ENABLED=true` est
 * exporté pour ne pas perturber le Keychain de Bruno ou un poste de
 * teammate (les commandes peuvent prompter pour autoriser l'accès).
 *
 * Convention : tous les secrets de test utilisent le préfixe
 * `factur-e-test-` pour être facilement identifiables et purgeables
 * en cas d'incident.
 */

const enabled = process.env.KEYCHAIN_TEST_ENABLED === "true";

describe.skipIf(!enabled)("KeychainSecretStore (opt-in macOS smoke)", () => {
  const ref = `factur-e-test-keychain-roundtrip-${String(Date.now())}`;
  const store = new KeychainSecretStore();

  afterEach(async () => {
    await store.delete(ref);
  });

  it("roundtrip put / get / delete on macOS Keychain", async () => {
    expect(await store.get(ref)).toBeNull();

    const bundle = {
      accessToken: "fixture-access",
      refreshToken: "fixture-refresh",
      accessExpiresAt: "2026-05-06T10:00:00.000Z",
    };
    await store.put(ref, bundle);
    expect(await store.get(ref)).toEqual(bundle);

    await store.delete(ref);
    expect(await store.get(ref)).toBeNull();

    // Idempotent delete.
    await expect(store.delete(ref)).resolves.toBeUndefined();
  });
});
