import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { SuperPDPDriver, type CustomerContext } from "@factur-e/pa-adapter";
import { startFakeSuperPdp, type FakeSuperPdp } from "@factur-e/shared-fakes";

// SuperPDP annuaire ignore le `ctx` (security: [] côté OpenAPI — pas
// d'auth requise). Ctx dummy partagé entre tous les cas.
const NO_CTX: CustomerContext = {
  customerId: "test-no-customer",
  credentials: { kind: "superpdp-oauth-cc", accessToken: "", accessExpiresAt: new Date(0) },
};

/**
 * Integration test pa-adapter directory ↔ fakeSuperPdp (T-CL-09 sprint-03).
 * Lives in `apps/api/tests/integration/` for the same workspace dep
 * cycle reason as `superpdp-driver.test.ts` (T-CL-06 C1).
 *
 * Couvre les 5 outcomes discriminated `DirectorySearchResult` :
 *   - found_one_address
 *   - found_multi_address
 *   - not_found
 *   - disabled
 *   - unavailable (5xx)
 *
 * + 1 cas de filtrage `is_replyto=true` côté adapter (audit T-CW-08 §3.2).
 */

describe("SuperPDPDriver — directory searchSiren vs fakeSuperPdp (T-CL-09)", () => {
  let fake: FakeSuperPdp;
  let driver: SuperPDPDriver;

  beforeAll(async () => {
    fake = await startFakeSuperPdp({});
    driver = new SuperPDPDriver({
      clientId: "test",
      clientSecret: "secret",
      baseUrl: fake.baseUrl,
      retryOptions: { sleep: () => Promise.resolve(), backoffMs: [0, 0] },
    });
  });

  afterAll(async () => {
    await fake.stop();
  });

  beforeEach(() => {
    fake.reset();
  });

  function fakeCompany(siren: string): {
    number: string;
    formal_name: string;
    address: string;
    postcode: string;
    city: string;
    country: string;
  } {
    return {
      number: siren,
      formal_name: "Acme SARL",
      address: "12 rue de la Paix",
      postcode: "75002",
      city: "Paris",
      country: "FR",
    };
  }

  it("found_one_address : 1 entry active → outcome found_one_address + adresse", async () => {
    const siren = "111111118";
    fake.seedDirectorySiren({
      siren,
      company: fakeCompany(siren),
      entries: [{ identifier: "0225:111111118", is_active: true }],
    });
    const result = await driver.searchSiren({ siren }, NO_CTX);
    expect(result.kind).toBe("found_one_address");
    if (result.kind !== "found_one_address") return;
    expect(result.address.party_id).toBe("0225:111111118");
    expect(result.address.scheme_id).toBe("0225");
    expect(result.address.is_active).toBe(true);
    expect(result.company.formal_name).toBe("Acme SARL");
  });

  it("found_multi_address : 2 entries actives → outcome found_multi_address", async () => {
    const siren = "222222226";
    fake.seedDirectorySiren({
      siren,
      company: fakeCompany(siren),
      entries: [
        { identifier: "0225:222222226", is_active: true },
        { identifier: "0225:222222226_dgfip", is_active: true },
      ],
    });
    const result = await driver.searchSiren({ siren }, NO_CTX);
    expect(result.kind).toBe("found_multi_address");
    if (result.kind !== "found_multi_address") return;
    expect(result.addresses).toHaveLength(2);
    expect(result.addresses.map((a) => a.party_id).sort()).toEqual([
      "0225:222222226",
      "0225:222222226_dgfip",
    ]);
  });

  it("not_found : siren absent annuaire → outcome not_found", async () => {
    const result = await driver.searchSiren({ siren: "999999991" }, NO_CTX);
    expect(result.kind).toBe("not_found");
  });

  it("disabled : company existe mais aucune entry active → outcome disabled", async () => {
    const siren = "333333335";
    fake.seedDirectorySiren({
      siren,
      company: fakeCompany(siren),
      entries: [{ identifier: "0225:333333335", is_active: false }],
    });
    const result = await driver.searchSiren({ siren }, NO_CTX);
    expect(result.kind).toBe("disabled");
    if (result.kind !== "disabled") return;
    expect(result.company.number).toBe(siren);
  });

  it("unavailable : 503 sur companies → outcome unavailable cause=5xx", async () => {
    fake.setDirectoryUnavailable(true);
    const result = await driver.searchSiren({ siren: "444444443" }, NO_CTX);
    expect(result.kind).toBe("unavailable");
    if (result.kind !== "unavailable") return;
    expect(result.cause).toBe("5xx");
    expect(result.status).toBe(503);
  });

  it("filtre is_replyto=true côté adapter (audit T-CW-08 §3.2)", async () => {
    const siren = "555555556";
    fake.seedDirectorySiren({
      siren,
      company: fakeCompany(siren),
      entries: [
        { identifier: "0225:555555556", is_active: true },
        // Cette entrée doit être invisible côté caller — adapter filter.
        { identifier: "0225:555555556_replyto", is_active: true, is_replyto: true },
      ],
    });
    const result = await driver.searchSiren({ siren }, NO_CTX);
    expect(result.kind).toBe("found_one_address");
    if (result.kind !== "found_one_address") return;
    expect(result.address.party_id).toBe("0225:555555556");
  });
});
