import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import {
  EsaLinkDriver,
  NotImplementedYetException,
  type CustomerContext,
} from "@factur-e/pa-adapter";
import { startFakeHubtimize, type FakeHubtimize } from "@factur-e/shared-fakes";

/**
 * T-CL-PA-INVOICE-FIX sprint-04 — Tests `EsaLinkDriver` V1 partiel
 * (ADR-011 V1 + ADR-012 D8).
 *
 * Couvre :
 *  - 3 méthodes Hubtimize V1 (authenticateOrchestrator + healthcheck +
 *    searchSiren) avec fakeHubtimize.
 *  - 7 méthodes restées stubbées → `throw NotImplementedYetException`
 *    (Customer Managed Hubtimize, conditionné partenariat).
 *
 * **Note sprint-10 W1** : `submitInvoice` + `pollCdarEvents` ne sont PLUS
 * stubbées — le transport AFNOR Flow `/flows` est implémenté (paramétré
 * par stratégie d'auth). Leur couverture est dans
 * `afnor-flow-transport.test.ts` (contre les routes `/afnor-flow/*` du
 * fake, stratégie OAuth2 Client Credentials). fakeHubtimize ne mocke pas
 * `/v1/flows` → on ne les exerce pas ici.
 */

const EXPECTED_FIREWALL_KEY = "fake-firewall-api-key-mock";
const EXPECTED_CLIENT_ID = "contact+fl@mona.re";
const EXPECTED_CLIENT_SECRET = "fake-keycloak-password";

const DUMMY_CTX: CustomerContext = {
  customerId: "test-customer",
  credentials: {
    kind: "esalink-keycloak-distributor",
    username: EXPECTED_CLIENT_ID,
    password: EXPECTED_CLIENT_SECRET,
    accessToken: "",
    refreshToken: "",
    accessExpiresAt: new Date(),
    refreshExpiresAt: new Date(),
    scope: "",
    sessionState: "",
    jwtClaims: {
      sub: "",
      entityId: null,
      email: null,
      roles: [],
      groups: [],
      iss: null,
    },
  },
};

describe("EsaLinkDriver V1 partiel (ADR-011 V1)", () => {
  let fake: FakeHubtimize;
  let driver: EsaLinkDriver;

  beforeAll(async () => {
    fake = await startFakeHubtimize({});
    driver = new EsaLinkDriver({
      keycloakUsername: EXPECTED_CLIENT_ID,
      keycloakPassword: EXPECTED_CLIENT_SECRET,
      firewallApiKey: EXPECTED_FIREWALL_KEY,
      baseUrl: fake.baseUrl,
      retryOptions: { sleep: () => Promise.resolve(), backoffMs: [0, 0] },
    });
  });

  afterAll(async () => {
    await fake.stop();
  });

  beforeEach(() => {
    fake.reset();
  });

  // ─── 3 méthodes implémentées V1 ────────────────────────────────────

  it("authenticateOrchestrator : Keycloak Client Credentials + JWT decode", async () => {
    const result = await driver.authenticateOrchestrator();
    expect(result.accessToken).toMatch(/^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/);
    expect(result.expiresAt.getTime()).toBeGreaterThan(Date.now());
    // JWT claims décodés (ADR-011 D3 observabilité).
    expect(result.jwtClaims.email).toBe(EXPECTED_CLIENT_ID);
    expect(result.jwtClaims.entityId).toBe(42);
    expect(result.jwtClaims.roles).toContain("hubtimize-pa-distributor");
    expect(fake.getTokenRequestCount()).toBe(1);
  });

  it("healthcheck : 200 OK → true", async () => {
    const ok = await driver.healthcheck();
    expect(ok).toBe(true);
    expect(fake.getHealthcheckRequestCount()).toBe(1);
  });

  it("searchSiren : cascade siren + directory-line → found_one_address", async () => {
    const result = await driver.searchSiren({ siren: "123456789" }, DUMMY_CTX);
    expect(result.kind).toBe("found_one_address");
    if (result.kind !== "found_one_address") return;
    expect(result.company.number).toBe("123456789");
    expect(result.company.formal_name).toBe("FAKE COMPANY SAS");
    expect(result.address.party_id).toBe("0225:123456789_dgfip");
    expect(result.address.scheme_id).toBe("0225");
    expect(result.address.is_active).toBe(true);
  });

  // ─── 7 méthodes restées stubbées → NotImplementedYetException ──────
  // (submitInvoice + pollCdarEvents désormais implémentées — cf.
  //  afnor-flow-transport.test.ts)

  it("getCustomerSnapshot → NotImplementedYetException (V2.1)", async () => {
    await expect(driver.getCustomerSnapshot(DUMMY_CTX)).rejects.toThrow(NotImplementedYetException);
  });

  it("createCustomer → NotImplementedYetException (V2.1)", async () => {
    await expect(
      driver.createCustomer({ contactEmail: "c@e.fr", legalName: "X", siren: "123456789" }),
    ).rejects.toThrow(NotImplementedYetException);
  });

  it("updateCustomer → NotImplementedYetException (V2.4)", async () => {
    await expect(driver.updateCustomer("paid", {})).rejects.toThrow(NotImplementedYetException);
  });

  it("provisionIdentifier → NotImplementedYetException (V2.1)", async () => {
    await expect(
      driver.provisionIdentifier("paid", { identifier: "0225:1", qualifier: "0225" }),
    ).rejects.toThrow(NotImplementedYetException);
  });

  it("listIdentifiers → NotImplementedYetException (V2.1)", async () => {
    await expect(driver.listIdentifiers("paid")).rejects.toThrow(NotImplementedYetException);
  });

  it("createEdiUser → NotImplementedYetException (V2.2)", async () => {
    await expect(driver.createEdiUser("paid")).rejects.toThrow(NotImplementedYetException);
  });

  it("regenerateEdiUserSecret → NotImplementedYetException (V2.2)", async () => {
    await expect(driver.regenerateEdiUserSecret("paid", "u1")).rejects.toThrow(
      NotImplementedYetException,
    );
  });
});
