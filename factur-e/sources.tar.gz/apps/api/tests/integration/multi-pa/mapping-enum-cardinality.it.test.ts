import { describe, expect, it } from "vitest";

import {
  FACTUR_E_STATUS_CODES,
  type FacturEStatusCode,
  mapSuperPDPStatusCode,
  SUPERPDP_STATUS_CODE_MAP,
} from "@factur-e/pa-adapter";

/**
 * Cas #17 — Mapping enum `FacturEStatusCode` cardinality (ADR-012 D2
 * amendée T-CL-PA-STATUS-RFC sprint-05, refonte AFNOR XP Z12-013).
 *
 * Test paramétré exhaustif sur les codes SuperPDP `api:|fr:|ppf:` → 21
 * valeurs internes. Vérifie :
 *  - Toutes les valeurs du mapping appartiennent à `FACTUR_E_STATUS_CODES`
 *    (= invariant enum).
 *  - Chaque code raw produit le mapping documenté (table complète),
 *    aligné sémantique métier AFNOR XP Z12-013 stricte (NC-19 levée).
 *  - Code raw inconnu → fallback `'unknown'` + `fellBack: true` (D7).
 *  - Cardinalité totale du map (régression — détecte ajout/suppression
 *    silencieuse côté pa-adapter).
 *
 * ─────────────────────────────────────────────────────────────────────
 * NC-19 sprint-04 — LEVÉE par T-CL-PA-STATUS-RFC sprint-05
 * ─────────────────────────────────────────────────────────────────────
 *
 * Les 7 entrées `fr:*` sémantiquement fausses sprint-04 sont désormais
 * remappées selon AFNOR XP Z12-013 officiel :
 *  - `fr:204` Prise en charge (In Process) → `in_process` (nouveau)
 *  - `fr:205` Approuvée (Accepted) → `accepted_business`
 *  - `fr:206` Approuvée partiellement → `partially_accepted`
 *  - `fr:207` En litige (Under Query) → `under_query` (nouveau)
 *  - `fr:208` Complétée (donnée fournie) → `info_complete` (nouveau)
 *  - `fr:211` Paiement transmis info → `payment_transmitted` (nouveau)
 *  - `fr:213` Rejet plateforme → `rejected_compliance` (nouveau)
 *
 * Distinction sémantique stricte préservée : `paid` (fr:212 Encaissée
 * fiscal Vendeur, terminal) ≠ `payment_transmitted` (fr:211 info
 * Acquéreur ordre virement, non terminal).
 *
 * Le helper `mapSuperPDPStatusCode` est désormais re-exporté par
 * `@factur-e/pa-adapter` (lève `[DEBT-low]` arbitrage post-merge
 * T-CL-TEST-INTEGRATION sprint-04).
 */

describe("[multi-pa] mapping enum FacturEStatusCode cardinalité (ADR-012 D2 amendée sprint-05)", () => {
  it("toutes les valeurs cibles appartiennent à FACTUR_E_STATUS_CODES (invariant enum)", () => {
    for (const [raw, mapped] of SUPERPDP_STATUS_CODE_MAP) {
      expect(FACTUR_E_STATUS_CODES.has(mapped), `raw='${raw}' → mapped='${mapped}'`).toBe(true);
    }
  });

  it("cardinalité du map figée sprint-05 = 43 entrées (8 api: + 15 fr: + 20 ppf:)", () => {
    expect(SUPERPDP_STATUS_CODE_MAP.size).toBe(43);
  });

  it("cardinalité enum FACTUR_E_STATUS_CODES = 21 (refonte sprint-05)", () => {
    expect(FACTUR_E_STATUS_CODES.size).toBe(21);
  });

  it("compte par préfixe : api:8, fr:15, ppf:20", () => {
    const byPrefix = { api: 0, fr: 0, ppf: 0, other: 0 };
    for (const raw of SUPERPDP_STATUS_CODE_MAP.keys()) {
      if (raw.startsWith("api:")) byPrefix.api += 1;
      else if (raw.startsWith("fr:")) byPrefix.fr += 1;
      else if (raw.startsWith("ppf:")) byPrefix.ppf += 1;
      else byPrefix.other += 1;
    }
    expect(byPrefix).toEqual({ api: 8, fr: 15, ppf: 20, other: 0 });
  });

  it.each<[string, FacturEStatusCode]>([
    // ─── api:* (pipeline technique pré-transmission) ───
    ["api:uploaded", "submitted"],
    ["api:invalid", "rejected_xsd"],
    ["api:validated", "validated"],
    ["api:sent", "transmitting"],
    ["api:rejected", "rejected_xsd"],
    ["api:received", "received"],
    ["api:acknowledged", "received"],
    ["api:accepted", "accepted_business"],

    // ─── fr:* (AFNOR XP Z12-013 — refonte sémantique sprint-05) ───
    ["fr:200", "validated"], // Déposée
    ["fr:201", "transmitting"], // Émise
    ["fr:202", "received"], // Reçue par la PA
    ["fr:203", "available_to_recipient"], // Mise à disposition
    ["fr:204", "in_process"], // REFONTE — Prise en charge
    ["fr:205", "accepted_business"], // REFONTE — Approuvée
    ["fr:206", "partially_accepted"], // REFONTE — Approuvée partiellement
    ["fr:207", "under_query"], // REFONTE — En litige
    ["fr:208", "info_complete"], // REFONTE — Complétée (donnée fournie)
    ["fr:209", "cancelled"], // Annulée
    ["fr:210", "refused_business"], // Refusée
    ["fr:211", "payment_transmitted"], // REFONTE — Paiement transmis info Acquéreur
    ["fr:212", "paid"], // Encaissée (fiscal exigibilité TVA)
    ["fr:213", "rejected_compliance"], // REFONTE — Rejet plateforme
    ["fr:501", "transmission_failed"], // Irrecevable

    // ─── ppf:* (échanges DGFiP Portail Public Facturation — préservés) ───
    ["ppf:validated", "validated"],
    ["ppf:validated-ack", "validated"],
    ["ppf:validated-ack-error", "validated"],
    ["ppf:validated-rejected", "rejected_xsd"],
    ["ppf:refused", "refused_business"],
    ["ppf:refused-ack", "refused_business"],
    ["ppf:refused-ack-error", "refused_business"],
    ["ppf:refused-rejected", "refused_business"],
    ["ppf:payment-received", "paid"],
    ["ppf:payment-received-ack", "paid"],
    ["ppf:payment-received-ack-error", "paid"],
    ["ppf:payment-received-rejected", "paid"],
    ["ppf:rejected", "rejected_xsd"],
    ["ppf:rejected-ack", "rejected_xsd"],
    ["ppf:rejected-ack-error", "rejected_xsd"],
    ["ppf:rejected-rejected", "rejected_xsd"],
    ["ppf:flow-1", "transmitting"],
    ["ppf:flow-1-ack", "transmitting"],
    ["ppf:flow-1-ack-error", "transmitting"],
    ["ppf:flow-1-rejected", "transmission_failed"],
  ])("mapSuperPDPStatusCode(%s) → %s", (raw, expected) => {
    const result = mapSuperPDPStatusCode(raw);
    expect(result.status).toBe(expected);
    expect(result.fellBack).toBe(false);
  });

  it("fallback : code inconnu → unknown + fellBack=true (D7 forward-compat)", () => {
    const cases = [
      "api:future_status_code_v2",
      "fr:999",
      "ppf:nonexistent",
      "completely-malformed",
      "",
      null,
      undefined,
    ];
    for (const raw of cases) {
      const result = mapSuperPDPStatusCode(raw);
      expect(result.status, `raw=${String(raw)}`).toBe("unknown");
      expect(result.fellBack, `raw=${String(raw)}`).toBe(true);
    }
  });

  it("distinction sémantique fr:211 (info Acquéreur) vs fr:212 (fiscal Vendeur)", () => {
    expect(mapSuperPDPStatusCode("fr:211").status).toBe("payment_transmitted");
    expect(mapSuperPDPStatusCode("fr:212").status).toBe("paid");
  });
});
