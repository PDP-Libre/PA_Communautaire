import { describe, expect, it } from "vitest";

import {
  FACTUR_E_STATUS_CODES,
  type FacturEStatusCode,
  mapSuperPDPStatusCode,
  SUPERPDP_TECHNICAL_STATUS_MAP,
} from "@factur-e/pa-adapter";

/**
 * Cas #17 — Mapping enum `FacturEStatusCode` cardinality, vu à la couche API.
 *
 * Refonte source unique (T-CL-CDAR-CAPABILITY-V2, ADR-022 D1) : les codes
 * canoniques AFNOR (`fr:NNN`) dérivent du **référentiel** (`@factur-e/shared-
 * schemas`) ; seuls les codes techniques propriétaires (`api:*`, `ppf:<nommé>`)
 * vivent dans `SUPERPDP_TECHNICAL_STATUS_MAP`. Correction C2 (D5) : `fr:208 →
 * on_hold`, `fr:209 → info_complete`, `fr:220 → cancelled`. (Détail exhaustif +
 * dual-209 : `packages/pa-adapter/tests/map-status-code.test.ts`.)
 */
describe("[multi-pa] mapping enum FacturEStatusCode cardinalité (ADR-022 D1 source unique)", () => {
  it("valeurs techniques ⊆ FACTUR_E_STATUS_CODES (invariant enum)", () => {
    for (const [raw, mapped] of SUPERPDP_TECHNICAL_STATUS_MAP) {
      expect(FACTUR_E_STATUS_CODES.has(mapped), `raw='${raw}' → '${mapped}'`).toBe(true);
    }
  });

  it("table technique propriétaire figée = 29 entrées (8 api: + 21 ppf:, aucun fr:)", () => {
    const byPrefix = { api: 0, fr: 0, ppf: 0, other: 0 };
    for (const raw of SUPERPDP_TECHNICAL_STATUS_MAP.keys()) {
      if (raw.startsWith("api:")) byPrefix.api += 1;
      else if (raw.startsWith("fr:")) byPrefix.fr += 1;
      else if (raw.startsWith("ppf:")) byPrefix.ppf += 1;
      else byPrefix.other += 1;
    }
    expect(byPrefix).toEqual({ api: 8, fr: 0, ppf: 21, other: 0 });
    expect(SUPERPDP_TECHNICAL_STATUS_MAP.size).toBe(29);
  });

  it("cardinalité enum FACTUR_E_STATUS_CODES = 21", () => {
    expect(FACTUR_E_STATUS_CODES.size).toBe(21);
  });

  it.each<[string, FacturEStatusCode]>([
    ["api:uploaded", "submitted"],
    ["api:accepted", "accepted_business"],
    ["fr:200", "validated"],
    ["fr:204", "in_process"],
    ["fr:208", "on_hold"], // C2 (était info_complete)
    ["fr:209", "info_complete"], // C2 (était cancelled)
    ["fr:212", "paid"],
    ["fr:213", "rejected_compliance"],
    ["fr:220", "cancelled"], // C2 (nouvelle cible)
    ["fr:501", "transmission_failed"],
    ["ppf:flow-1", "transmitting"],
    ["ppf:flow-1-response-ok", "transmitting"], // F-PPF-OK
  ])("mapSuperPDPStatusCode(%s) → %s", (raw, expected) => {
    const result = mapSuperPDPStatusCode(raw);
    expect(result.status).toBe(expected);
    expect(result.fellBack).toBe(false);
  });

  it("fallback : code hors référentiel/technique → unknown + fellBack=true (D7)", () => {
    for (const raw of [
      "api:future_v2",
      "fr:999",
      "ppf:nonexistent",
      "malformed",
      "",
      null,
      undefined,
    ]) {
      const result = mapSuperPDPStatusCode(raw);
      expect(result.status, `raw=${String(raw)}`).toBe("unknown");
      expect(result.fellBack, `raw=${String(raw)}`).toBe(true);
    }
  });
});
