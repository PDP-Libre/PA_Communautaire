import { describe, expect, it } from "vitest";

import {
  EsaLinkDriver,
  isApiOnboarding,
  isWebOnboarding,
  SuperPDPDriver,
} from "@factur-e/pa-adapter";

/**
 * Cas #14 — Architecture multi-PA capability-based (ADR-012 D1+D6).
 *
 * Vérifie que les 2 drivers V1 livrés implémentent les bonnes
 * sous-interfaces composées :
 *  - `SuperPDPDriver` → `PADriverWebOnboarding` (tunnel OAuth
 *    Authorization Code, `providerId='superpdp'`, `onboardingMode='web-authorization-code'`).
 *  - `EsaLinkDriver` → `PADriverApiOnboarding` (Customer Managed
 *    workflow, `providerId='esalink'`, `onboardingMode='api-customer-managed'`).
 *
 * Type guards runtime `isWebOnboarding` / `isApiOnboarding` discriminent
 * proprement les 2 drivers — TypeScript narrowing exhaustif côté
 * apps/api callers.
 *
 * Test pur (pas de DB, pas de network) — peut tourner sans `TEST_POSTGRES_URL`.
 */

describe("[multi-pa] capability-based PADriver type guards (ADR-012 D1+D6)", () => {
  const superpdp = new SuperPDPDriver({
    clientId: "fake-client-id",
    clientSecret: "fake-client-secret",
    baseUrl: "http://localhost.invalid",
  });

  const esalink = new EsaLinkDriver({
    keycloakUsername: "fake@test.local",
    keycloakPassword: "fake-secret",
    firewallApiKey: "fake-firewall-key",
    baseUrl: "http://localhost.invalid",
  });

  it("SuperPDPDriver satisfait PADriverWebOnboarding + isWebOnboarding=true", () => {
    expect(superpdp.providerId).toBe("superpdp");
    expect(superpdp.onboardingMode).toBe("web-authorization-code");
    expect(isWebOnboarding(superpdp)).toBe(true);
    expect(isApiOnboarding(superpdp)).toBe(false);

    // Méthodes Web Onboarding présentes.
    expect(typeof superpdp.authorize).toBe("function");
    expect(typeof superpdp.exchangeCode).toBe("function");
    expect(typeof superpdp.refreshToken).toBe("function");
    expect(typeof superpdp.revoke).toBe("function");
    expect(typeof superpdp.getIdentityStatus).toBe("function");

    // Méthodes Core obligatoires aussi présentes.
    expect(typeof superpdp.submitInvoice).toBe("function");
    expect(typeof superpdp.pollCdarEvents).toBe("function");
    expect(typeof superpdp.searchSiren).toBe("function");
    expect(typeof superpdp.healthcheck).toBe("function");
  });

  it("EsaLinkDriver satisfait PADriverApiOnboarding + isApiOnboarding=true", () => {
    expect(esalink.providerId).toBe("esalink");
    expect(esalink.onboardingMode).toBe("api-customer-managed");
    expect(isApiOnboarding(esalink)).toBe(true);
    expect(isWebOnboarding(esalink)).toBe(false);

    // Méthodes Api Onboarding présentes (3 implem + 6 stubs — toutes
    // doivent au moins être des fonctions sur l'instance).
    expect(typeof esalink.authenticateOrchestrator).toBe("function");
    expect(typeof esalink.createCustomer).toBe("function");
    expect(typeof esalink.updateCustomer).toBe("function");
    expect(typeof esalink.provisionIdentifier).toBe("function");
    expect(typeof esalink.listIdentifiers).toBe("function");
    expect(typeof esalink.createEdiUser).toBe("function");
    expect(typeof esalink.regenerateEdiUserSecret).toBe("function");

    // Méthodes Core obligatoires aussi présentes.
    expect(typeof esalink.submitInvoice).toBe("function");
    expect(typeof esalink.pollCdarEvents).toBe("function");
    expect(typeof esalink.searchSiren).toBe("function");
    expect(typeof esalink.healthcheck).toBe("function");
  });

  it("narrowing TypeScript exhaustif via type guards (compile + runtime)", () => {
    const drivers = [superpdp, esalink] as const;
    for (const d of drivers) {
      if (isWebOnboarding(d)) {
        // TS narrow : `authorize` accessible.
        expect(typeof d.authorize).toBe("function");
        expect(d.providerId).toBe("superpdp");
      } else if (isApiOnboarding(d)) {
        // TS narrow : `authenticateOrchestrator` accessible.
        expect(typeof d.authenticateOrchestrator).toBe("function");
        expect(d.providerId).toBe("esalink");
      } else {
        // `d` est narrowed à `never` à ce point (les 2 guards couvrent
        // tous les modes d'onboarding V1). Ce throw défensif n'est
        // atteint que si une 3ᵉ PA arrive sans nouveau type guard.
        const unreachable = d as { providerId: string };
        throw new Error(
          `Driver ${unreachable.providerId} ne satisfait aucune sous-interface — failsafe`,
        );
      }
    }
  });
});
