import { describe, expect, it } from "vitest";

import {
  EsaLinkDriver,
  NotImplementedYetException,
  UnknownProviderException,
} from "@factur-e/pa-adapter";

import { ESALINK_ENABLED, instantiateDriver, isProviderEnabled } from "../../../src/pa/registry.js";

/**
 * Cas #15 — Feature flag EsaLink (ADR-011 D9 + ADR-012 D8).
 *
 * Vérifie 2 invariants V1 :
 *  - `ENABLE_ESALINK_PROVIDER` non setté (default = false) → registry
 *    `instantiateDriver({providerId:'esalink', ...})` lève
 *    `UnknownProviderException` + `isProviderEnabled('esalink') === false`.
 *  - `EsaLinkDriver` instanciable directement (le feature flag gate
 *    l'**accessibilité côté registry**, pas la classe elle-même) ; ses 9
 *    méthodes stubbées V1 lèvent toutes `NotImplementedYetException`.
 *
 * Note design (cf. registry.ts:62) : `ESALINK_ENABLED` est lu au module
 * load (process.env figé). Toggle runtime impossible sans
 * `vi.resetModules()` + dynamic import — overkill pour ce périmètre.
 * Les 2 branches (false / true) sont testées :
 *  - false → via le registry directement (état default des tests).
 *  - true → via la classe `EsaLinkDriver` instanciée out-of-registry
 *    (équivalent au comportement post-flip flag, le registry ne fait
 *    que gatekeeper l'access).
 */

describe("[multi-pa] EsaLink feature flag (ADR-011 D9 + ADR-012 D8)", () => {
  it("default false : ESALINK_ENABLED=false + isProviderEnabled('esalink')=false", () => {
    // Sans override env, le registry est dans son état default.
    expect(ESALINK_ENABLED).toBe(false);
    expect(isProviderEnabled("esalink")).toBe(false);
    // SuperPDP toujours actif (cf. SUPERPDP_ENABLED constant).
    expect(isProviderEnabled("superpdp")).toBe(true);
    // Provider inconnu : false (closed default).
    expect(isProviderEnabled("docaposte")).toBe(false);
  });

  it("instantiateDriver({providerId:'esalink'}) → UnknownProviderException (flag off)", () => {
    expect(() =>
      instantiateDriver({
        providerId: "esalink",
        config: {
          keycloakUsername: "fake",
          keycloakPassword: "fake",
          firewallApiKey: "fake",
        },
      }),
    ).toThrow(UnknownProviderException);

    try {
      instantiateDriver({
        providerId: "esalink",
        config: { keycloakUsername: "a", keycloakPassword: "b", firewallApiKey: "c" },
      });
      throw new Error("Should have thrown");
    } catch (e) {
      expect(e).toBeInstanceOf(UnknownProviderException);
      expect((e as UnknownProviderException).provider).toBe("esalink");
      expect((e as Error).message).toMatch(/ENABLE_ESALINK_PROVIDER=true/);
    }
  });

  it("instantiateDriver({providerId:'superpdp'}) OK (toujours activé V1)", () => {
    const driver = instantiateDriver({
      providerId: "superpdp",
      config: { clientId: "fake", clientSecret: "fake", baseUrl: "http://localhost.invalid" },
    });
    expect(driver.providerId).toBe("superpdp");
    expect(driver.onboardingMode).toBe("web-authorization-code");
  });

  it("EsaLinkDriver instanciable out-of-registry → 7 stubs Customer Managed throw NotImplementedYetException", async () => {
    // Post-flip ENABLE_ESALINK_PROVIDER=true : les méthodes Customer
    // Managed Hubtimize restent stubbées (conditionné partenariat).
    // NB sprint-10 W1 : submitInvoice + pollCdarEvents NE SONT PLUS
    // stubbées (transport AFNOR Flow implémenté — cf.
    // afnor-flow-transport.test.ts). Restent 7 stubs.
    const driver = new EsaLinkDriver({
      keycloakUsername: "fake@test.local",
      keycloakPassword: "fake",
      firewallApiKey: "fake",
      baseUrl: "http://localhost.invalid",
    });

    // ── PADriverCore stub restant ──
    const ctxStub = {
      customerId: "fake-customer-id",
      credentials: {
        kind: "esalink-keycloak-distributor",
        username: "fake",
        password: "fake",
        accessToken: "fake",
        refreshToken: "fake",
        accessExpiresAt: new Date(),
        refreshExpiresAt: new Date(),
        scope: "fake",
        sessionState: "fake",
        jwtClaims: { sub: "fake", entityId: null, email: null, roles: [], groups: [], iss: null },
      },
    } as const;

    await expect(driver.getCustomerSnapshot(ctxStub)).rejects.toBeInstanceOf(
      NotImplementedYetException,
    );

    // ── PADriverApiOnboarding stubs ──
    await expect(
      driver.createCustomer({ contactEmail: "x@y", legalName: "X", siren: "111111111" }),
    ).rejects.toBeInstanceOf(NotImplementedYetException);

    await expect(driver.updateCustomer("fake-id", { legalName: "X2" })).rejects.toBeInstanceOf(
      NotImplementedYetException,
    );

    await expect(
      driver.provisionIdentifier("fake-id", { identifier: "0225:111", qualifier: "0225" }),
    ).rejects.toBeInstanceOf(NotImplementedYetException);

    await expect(driver.listIdentifiers("fake-id")).rejects.toBeInstanceOf(
      NotImplementedYetException,
    );

    await expect(driver.createEdiUser("fake-id")).rejects.toBeInstanceOf(
      NotImplementedYetException,
    );

    await expect(driver.regenerateEdiUserSecret("fake-id", "edi-user-id")).rejects.toBeInstanceOf(
      NotImplementedYetException,
    );
  });
});
