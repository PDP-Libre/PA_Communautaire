import { afterEach, beforeEach, describe, expect, it } from "vitest";

import { UnknownProviderException } from "@factur-e/pa-adapter";

import {
  DEFAULT_PA_CONFIG_ID,
  PA_CONFIGS,
  resolveActivePaConfig,
  resolvePaConfig,
} from "../../../src/pa/registry.js";

/**
 * T-CL-REGISTRE-AFNORDRIVER sprint-10 W1 — registre PA multi-config.
 * Couvre la résolution `paId → descripteur`, la sélection active par
 * `PA_ACTIVE_CONFIG`, le gating des configs externes non câblées, et
 * l'**invariant identités partagées** (DoD : superpdp-prop & -afnor =
 * même `identitiesKey`).
 */

describe("registre PA multi-config", () => {
  const savedEnv = process.env.PA_ACTIVE_CONFIG;

  beforeEach(() => {
    delete process.env.PA_ACTIVE_CONFIG;
  });
  afterEach(() => {
    if (savedEnv === undefined) delete process.env.PA_ACTIVE_CONFIG;
    else process.env.PA_ACTIVE_CONFIG = savedEnv;
  });

  it("identités partagées : superpdp-proprietaire et superpdp-afnor pointent le même bloc 'superpdp'", () => {
    expect(PA_CONFIGS["superpdp-proprietaire"].identitiesKey).toBe("superpdp");
    expect(PA_CONFIGS["superpdp-afnor"].identitiesKey).toBe("superpdp");
    // Zéro duplication : même clé → mêmes SIREN à l'émission (DoD).
    expect(PA_CONFIGS["superpdp-afnor"].identitiesKey).toBe(
      PA_CONFIGS["superpdp-proprietaire"].identitiesKey,
    );
  });

  it("familles : superpdp-proprietaire = propriétaire, superpdp-afnor = afnor-flow", () => {
    expect(PA_CONFIGS["superpdp-proprietaire"].family).toBe("superpdp-proprietary");
    expect(PA_CONFIGS["superpdp-afnor"].family).toBe("afnor-flow");
  });

  it("configs externes déclarées mais gated (wired:false)", () => {
    expect(PA_CONFIGS.esalink.wired).toBe(false);
    expect(PA_CONFIGS.proxypdplibre.wired).toBe(false);
    expect(PA_CONFIGS.pa_communautaire.wired).toBe(false);
    // Les deux SuperPDP sont câblées W1.
    expect(PA_CONFIGS["superpdp-proprietaire"].wired).toBe(true);
    expect(PA_CONFIGS["superpdp-afnor"].wired).toBe(true);
  });

  it("resolvePaConfig : id connu → descripteur, id inconnu → UnknownProviderException", () => {
    expect(resolvePaConfig("superpdp-afnor").paId).toBe("superpdp-afnor");
    expect(() => resolvePaConfig("nope")).toThrow(UnknownProviderException);
  });

  it("resolveActivePaConfig : défaut = superpdp-proprietaire (pas d'env)", () => {
    expect(resolveActivePaConfig().paId).toBe(DEFAULT_PA_CONFIG_ID);
    expect(resolveActivePaConfig().paId).toBe("superpdp-proprietaire");
  });

  it("resolveActivePaConfig : PA_ACTIVE_CONFIG=superpdp-afnor → config AFNOR", () => {
    process.env.PA_ACTIVE_CONFIG = "superpdp-afnor";
    const active = resolveActivePaConfig();
    expect(active.paId).toBe("superpdp-afnor");
    expect(active.family).toBe("afnor-flow");
  });

  it("resolveActivePaConfig : config non câblée (esalink) → throw (ne pas booter)", () => {
    process.env.PA_ACTIVE_CONFIG = "esalink";
    expect(() => resolveActivePaConfig()).toThrow(UnknownProviderException);
  });

  it("resolveActivePaConfig : env inconnu → throw", () => {
    process.env.PA_ACTIVE_CONFIG = "bogus-pa";
    expect(() => resolveActivePaConfig()).toThrow(UnknownProviderException);
  });
});
