import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import type { CdarEvent } from "@factur-e/pa-adapter";
import { MockPADriver } from "@factur-e/shared-fakes";

import { runPollCdarEvents } from "../../../src/jobs/poll-cdar-events.js";
import { MemorySecretStore } from "../../../src/secrets/index.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";
import { seedFullCustomer } from "../../_fixtures/seed-customer.js";

/**
 * Cas #16 — Forward-compat fallback `'unknown'` + audit
 * `pa_status_code_unmapped` (ADR-012 D7).
 *
 * Simule la situation où SuperPDP propriétaire introduit en cours de
 * route un nouveau code event que `mapSuperPDPStatusCode` ne connaît
 * pas (ex. `api:future_status_code_v2`). Le mapping retourne
 * `{ status: 'unknown', fellBack: true }` — pas de crash. Le job
 * polling :
 *  - Persiste l'event avec son `rawStatusCode` natif (pour timeline UI).
 *  - UPDATE `invoices.status_current = 'unknown'`.
 *  - Émet audit `pa_status_code_unmapped` côté caller (poll-cdar-events.ts:230-244).
 *
 * Le caller passe les événements via `MockPADriver.seedCdarEvents` avec
 * un `CdarEvent.status = 'unknown'` + `rawStatusCode = 'api:future_…'` —
 * c'est ce que le vrai `SuperPDPDriver.pollCdarEvents` retournerait
 * après un mapping `fellBack: true` (cf. driver implementation).
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("[multi-pa] forward-compat unknown status code (ADR-012 D7)", () => {
  let db: TestDb;
  let sql: postgres.Sql;
  let secrets: MemorySecretStore;
  let driver: MockPADriver;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 5, onnotice: () => undefined });
    secrets = new MemorySecretStore();
    driver = new MockPADriver();
  });

  afterAll(async () => {
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    driver.reset();
  });

  it("event status=unknown + raw='api:future_…' → persisté + audit pa_status_code_unmapped", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const invRows = await sql<{ id: string }[]>`
      INSERT INTO invoices (
        customer_id, number, issue_date, tracking_id, sha256,
        total_ht, total_vat, total_ttc, currency, processing_rule,
        type_code, pa_invoice_id, status_current
      ) VALUES (
        ${seed.customerId}, 'F-FWD-001', '2026-05-16',
        ${"55555555-5555-4555-8555-555555555555"},
        ${"c".repeat(64)},
        '100.00', '20.00', '120.00', 'EUR', 'B2B',
        '380', '777', 'submitted'
      ) RETURNING id
    `;
    const invoiceId = invRows[0]?.id ?? "";

    const futureEvent: CdarEvent = {
      paEventId: "9999",
      paInvoiceId: "777",
      rawStatusCode: "api:future_status_code_v2",
      // Status = 'unknown' représente le résultat du mapping fellBack
      // côté driver. Le job lit ce status directement (pas de re-mapping).
      status: "unknown",
      occurredAt: "2026-05-16T15:00:00Z",
    };
    driver.seedCdarEvents([futureEvent]);

    const result = await runPollCdarEvents({ sql, driver, secrets });
    expect(result.events_inserted).toBe(1);
    expect(result.errors).toBe(0);

    // L'event est persisté avec son raw code natif (timeline UI affiche
    // banner « En cours de qualification » via FacturEStatusCode='unknown').
    const persisted = await sql<{ code: string }[]>`
      SELECT code FROM cdar_events WHERE invoice_id = ${invoiceId}
    `;
    expect(persisted).toHaveLength(1);
    expect(persisted[0]?.code).toBe("api:future_status_code_v2");

    // UPDATE invoices.status_current = 'unknown' (forward-compat safe).
    const inv = await sql<{ status_current: string }[]>`
      SELECT status_current FROM invoices WHERE id = ${invoiceId}
    `;
    expect(inv[0]?.status_current).toBe("unknown");

    // Audit ADR-012 D7 émis.
    const audits = await sql<
      { event_type: string; metadata: { raw_status_code?: string } | null }[]
    >`
      SELECT event_type, metadata FROM auth_audit WHERE customer_id = ${seed.customerId}
    `;
    const unmappedAudit = audits.find((a) => a.event_type === "pa_status_code_unmapped");
    expect(unmappedAudit).toBeDefined();
    expect(unmappedAudit?.metadata?.raw_status_code).toBe("api:future_status_code_v2");
  });

  it("event status=unknown + raw='' (string vide) → PAS d'audit unmapped (cf. poll-cdar-events.ts:233)", async () => {
    // Cas dégénéré : si le driver retourne status='unknown' avec un
    // rawStatusCode vide (= échec parsing/edge case extreme), le job
    // n'émet PAS pa_status_code_unmapped (le mapping fellBack inclut
    // les valeurs vides comme cas légitimes, pas comme nouveau code à
    // signaler).
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const invRows = await sql<{ id: string }[]>`
      INSERT INTO invoices (
        customer_id, number, issue_date, tracking_id, sha256,
        total_ht, total_vat, total_ttc, currency, processing_rule,
        type_code, pa_invoice_id, status_current
      ) VALUES (
        ${seed.customerId}, 'F-FWD-002', '2026-05-16',
        ${"66666666-6666-4666-8666-666666666666"},
        ${"d".repeat(64)},
        '50.00', '10.00', '60.00', 'EUR', 'B2B',
        '380', '888', 'submitted'
      ) RETURNING id
    `;
    expect(invRows[0]?.id).toBeDefined();

    driver.seedCdarEvents([
      {
        paEventId: "10000",
        paInvoiceId: "888",
        rawStatusCode: "",
        status: "unknown",
        occurredAt: "2026-05-16T16:00:00Z",
      },
    ]);

    await runPollCdarEvents({ sql, driver, secrets });

    const audits = await sql<{ event_type: string }[]>`
      SELECT event_type FROM auth_audit WHERE customer_id = ${seed.customerId}
    `;
    expect(audits.filter((a) => a.event_type === "pa_status_code_unmapped")).toHaveLength(0);
  });
});
