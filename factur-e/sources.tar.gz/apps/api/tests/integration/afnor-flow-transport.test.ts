import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { SuperPdpAfnorDriver, type CustomerContext } from "@factur-e/pa-adapter";
import { startFakeSuperPdp, type FakeSuperPdp } from "@factur-e/shared-fakes";

/**
 * T-CL-REGISTRE-AFNORDRIVER sprint-10 W1 — transport AFNOR Flow `/flows`
 * du `SuperPdpAfnorDriver` (config `superpdp-afnor`) contre les routes
 * `/afnor-flow/*` du fakeSuperPdp.
 *
 * Oracle déterministe (Levier 1) du round-trip harness `--pa=superpdp-afnor` :
 *  - dépôt multipart `flowInfo`+`file` → 202 + `flowId`.
 *  - auth OAuth2 Client Credentials auto-portée (`/oauth2/token` grant
 *    `client_credentials`) — `ctx.credentials` (AC) ignoré.
 *  - poll Tier-1 : relit l'`acknowledgement.status` de NOTRE flux via
 *    `/flows/search` (curseur temporel) → `submitted` (Pending) puis
 *    `validated` (Ok) — preuve de **transport** (pas le CDAR métier).
 *
 * ⚠️ La preuve d'**acceptation PA** reste le harness contre SuperPDP-AFNOR
 * réel (sandbox) — ce fake sert la non-régression CI uniquement.
 */

const PDF_BYTES = Buffer.from("%PDF-1.7\nfake-factur-x-afnor\n%%EOF");

// L'AfnorDriver ignore `ctx.credentials` (auth CC auto-portée Z2) — ctx
// minimal valide suffit.
const DUMMY_CTX: CustomerContext = {
  customerId: "11111111-1111-7111-8111-111111111111",
  credentials: {
    kind: "superpdp-oauth-ac",
    accessToken: "ac-ignored",
    refreshToken: "r-ignored",
    accessExpiresAt: new Date(Date.now() + 3_600_000),
    paUserId: null,
  },
};

function submitInput(invoiceNumber: string) {
  return {
    pdfBytes: PDF_BYTES,
    trackingId: `trk-${invoiceNumber}`,
    sha256: "a".repeat(64),
    processingRule: "B2B" as const,
    profile: "EXTENDED" as const,
    invoiceNumber,
    recipientPeppolId: "0225:000000001",
    senderPeppolId: "0225:000000002",
  };
}

describe("SuperPdpAfnorDriver — transport AFNOR Flow /flows (superpdp-afnor)", () => {
  let fake: FakeSuperPdp;
  let driver: SuperPdpAfnorDriver;

  beforeAll(async () => {
    fake = await startFakeSuperPdp({});
    driver = new SuperPdpAfnorDriver({
      clientId: "fake-cc-client-id",
      clientSecret: "fake-cc-client-secret",
      baseUrl: fake.baseUrl,
    });
  });

  afterAll(async () => {
    await fake.stop();
  });

  beforeEach(() => {
    fake.reset();
  });

  it("conserve providerId 'superpdp' + onboardingMode web (poll guard, type PADriver)", () => {
    expect(driver.providerId).toBe("superpdp");
    expect(driver.onboardingMode).toBe("web-authorization-code");
    expect(driver.pollingCursorNamespace).toBe("superpdp-afnor");
  });

  it("submitInvoice : dépôt multipart → 202 + flowId (paInvoiceId)", async () => {
    const out = await driver.submitInvoice(submitInput("AF-001"), DUMMY_CTX);
    expect(out.paInvoiceId).toMatch(/^i_\d+$/);
    expect(out.status).toBe("submitted");
    expect(out.rawStatusCode).toBe("afnor:deposited");
    expect(fake.getAfnorFlowCount()).toBe(1);
  });

  it("pollCdarEvents Tier-1 : acknowledgement Pending → submitted, mappé sur notre flowId", async () => {
    const out = await driver.submitInvoice(submitInput("AF-002"), DUMMY_CTX);
    const poll = await driver.pollCdarEvents({ cursor: "0", limit: 100 }, DUMMY_CTX);
    expect(poll.events.length).toBeGreaterThanOrEqual(1);
    const ev = poll.events.find((e) => e.paInvoiceId === out.paInvoiceId);
    expect(ev).toBeDefined();
    expect(ev?.rawStatusCode).toBe("afnor-ack:Pending");
    expect(ev?.status).toBe("submitted");
    // Curseur temporel ISO avancé (≠ '0').
    expect(poll.nextCursor).not.toBe("0");
    expect(Number.isNaN(Date.parse(poll.nextCursor))).toBe(false);
  });

  it("pollCdarEvents Tier-1 : acknowledgement Ok → validated (transition PA)", async () => {
    const out = await driver.submitInvoice(submitInput("AF-003"), DUMMY_CTX);
    fake.setAfnorFlowAck(out.paInvoiceId, "Ok");
    const poll = await driver.pollCdarEvents({ cursor: "0", limit: 100 }, DUMMY_CTX);
    const ev = poll.events.find((e) => e.paInvoiceId === out.paInvoiceId);
    expect(ev?.rawStatusCode).toBe("afnor-ack:Ok");
    expect(ev?.status).toBe("validated");
  });

  it("pollCdarEvents Tier-1 : acknowledgement Error → rejected_xsd", async () => {
    const out = await driver.submitInvoice(submitInput("AF-004"), DUMMY_CTX);
    fake.setAfnorFlowAck(out.paInvoiceId, "Error");
    const poll = await driver.pollCdarEvents({ cursor: "0", limit: 100 }, DUMMY_CTX);
    const ev = poll.events.find((e) => e.paInvoiceId === out.paInvoiceId);
    expect(ev?.status).toBe("rejected_xsd");
  });
});
