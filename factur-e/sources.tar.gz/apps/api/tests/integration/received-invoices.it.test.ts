import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { getReceptionFixture } from "@factur-e/factur-x-fixtures";
import { MockPADriver } from "@factur-e/shared-fakes";

import { insertIncomingCdarEvent } from "../../src/db/repos/incoming_cdar_events.js";
import {
  insertReceivedInvoice,
  type NewReceivedInvoiceRow,
} from "../../src/db/repos/received_invoices.js";
import { MemorySecretStore } from "../../src/secrets/index.js";
import { buildIncomingFileFromEmissionFixture } from "../../src/dev-support/reception-fixtures.js";
import { seedFullCustomer } from "../_fixtures/seed-customer.js";
import { buildTestApp, type TestApp } from "../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../helpers/test-db.js";

/**
 * T-CL-RECV-API sprint-05 W2 — Tests intégration HTTP `/api/received-invoices/*`.
 * Pattern `buildTestApp` + `fetch` natif (cf. `docs/guides/test-ci.md`).
 *
 * ≥ 12 cas : liste (vide / peuplée / filtre statut / pagination cursor),
 * fiche (complète / parsedMetadata / 404 RBAC scope), pose CDAR (205 / 210 /
 * 422 reason_code manquant / 422 reason_text manquant), proxy PDF (200 Full /
 * 403 Restreint) + proxy XML (403 Responsable).
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

// XML CII statique du corpus (migration du `CII_SAMPLE` inline §1.3-4) —
// rx-380-cii-partiel : CII pur tiers, BT-1 "FT-2026-0042", parsable par le
// parser réel. Identité par défaut des rows sourcée de rx-380-base-facturx.
const RX_CII = getReceptionFixture("rx-380-cii-partiel");
if (RX_CII.source.kind !== "xml") throw new Error("rx-380-cii-partiel doit être kind:xml");
const CII_SAMPLE = RX_CII.source.xml;
const RX_BASE = getReceptionFixture("rx-380-base-facturx");

describe.skipIf(!enabled)("[received-invoices] routes `/api/received-invoices/*`", () => {
  let db: TestDb;
  let sql: postgres.Sql;
  let secrets: MemorySecretStore;
  let driver: MockPADriver;
  let app: TestApp;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 5, onnotice: () => undefined });
    secrets = new MemorySecretStore();
    driver = new MockPADriver();
    app = await buildTestApp({ connectionString: db.url, paDriver: driver, secretStore: secrets });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    driver.reset();
  });

  async function seedReceived(
    customerId: string,
    overrides: Partial<NewReceivedInvoiceRow> = {},
  ): Promise<string> {
    const row = await insertReceivedInvoice(sql, {
      customer_id: customerId,
      pa_invoice_id_in:
        overrides.pa_invoice_id_in ?? `pa-${Math.random().toString(36).slice(2, 9)}`,
      seller_siren: RX_BASE.expect.row.sellerSiren,
      seller_name_cached: RX_BASE.incoming.enInvoice?.sellerName ?? null,
      supplier_matched: true,
      invoice_number_extracted: "FA-RECV-1",
      issue_date: "2026-05-18",
      total_ttc_cents: 120050,
      currency: "EUR",
      status_current: "in_process",
      ...overrides,
    });
    if (row === null) throw new Error("seedReceived: insert returned null");
    return row.id;
  }

  const auth = (bearer: string): RequestInit => ({
    headers: { authorization: `Bearer ${bearer}` },
  });

  it("GET /api/received-invoices → 401 sans bearer", async () => {
    const res = await fetch(`${app.url}/api/received-invoices`);
    expect(res.status).toBe(401);
  });

  it("GET /api/received-invoices → liste vide", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const res = await fetch(`${app.url}/api/received-invoices`, auth(seed.bearer));
    expect(res.status).toBe(200);
    const body = (await res.json()) as { items: unknown[]; nextCursor: string | null };
    expect(body.items).toHaveLength(0);
    expect(body.nextCursor).toBeNull();
  });

  it("GET /api/received-invoices → liste peuplée + filtre status", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    await seedReceived(seed.customerId, { status_current: "in_process" });
    await seedReceived(seed.customerId, { status_current: "accepted_business" });
    await seedReceived(seed.customerId, { status_current: "in_process" });

    const all = await fetch(`${app.url}/api/received-invoices`, auth(seed.bearer));
    const allBody = (await all.json()) as { items: unknown[] };
    expect(allBody.items).toHaveLength(3);

    const filtered = await fetch(
      `${app.url}/api/received-invoices?status=accepted_business`,
      auth(seed.bearer),
    );
    const filteredBody = (await filtered.json()) as { items: { status_current: string }[] };
    expect(filteredBody.items).toHaveLength(1);
    expect(filteredBody.items[0]?.status_current).toBe("accepted_business");
  });

  it("GET /api/received-invoices → pagination cursor (page 1 → page 2)", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    for (let i = 0; i < 3; i++) await seedReceived(seed.customerId);

    const page1 = await fetch(`${app.url}/api/received-invoices?limit=2`, auth(seed.bearer));
    const p1 = (await page1.json()) as { items: { id: string }[]; nextCursor: string | null };
    expect(p1.items).toHaveLength(2);
    expect(p1.nextCursor).not.toBeNull();

    const page2 = await fetch(
      `${app.url}/api/received-invoices?limit=2&cursor=${encodeURIComponent(p1.nextCursor ?? "")}`,
      auth(seed.bearer),
    );
    const p2 = (await page2.json()) as { items: { id: string }[]; nextCursor: string | null };
    expect(p2.items).toHaveLength(1);
    expect(p2.nextCursor).toBeNull();
    // Pas de chevauchement entre les pages.
    const ids = new Set([...p1.items, ...p2.items].map((i) => i.id));
    expect(ids.size).toBe(3);
  });

  it("GET /api/received-invoices/:id → fiche + cdarEvents + parsedMetadata", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const id = await seedReceived(seed.customerId);
    await insertIncomingCdarEvent(sql, {
      received_invoice_id: id,
      code: "fr:204",
      occurred_at: new Date(),
      source: "polling",
    });
    // Mock download → XML CII → parsedMetadata peuplé.
    driver.setDownloadInvoiceFileResult({
      bytes: Buffer.from(CII_SAMPLE, "utf8"),
      contentType: "application/xml",
    });

    const res = await fetch(`${app.url}/api/received-invoices/${id}`, auth(seed.bearer));
    expect(res.status).toBe(200);
    const body = (await res.json()) as {
      invoice: { id: string; status_current: string };
      supplierMatched: boolean;
      cdarEvents: { code: string }[];
      parsedMetadata: { document: { invoiceNumber: string } } | null;
    };
    expect(body.invoice.id).toBe(id);
    expect(body.supplierMatched).toBe(true);
    expect(body.cdarEvents).toHaveLength(1);
    expect(body.cdarEvents[0]?.code).toBe("fr:204");
    expect(body.parsedMetadata?.document.invoiceNumber).toBe("FT-2026-0042");
  });

  it("GET /api/received-invoices/:id → 404 si pas owned (RBAC scope autre customer)", async () => {
    const owner = await seedFullCustomer(sql, { secretStore: secrets });
    const other = await seedFullCustomer(sql, { secretStore: secrets });
    const id = await seedReceived(owner.customerId);

    const res = await fetch(`${app.url}/api/received-invoices/${id}`, auth(other.bearer));
    expect(res.status).toBe(404);
  });

  it("POST /api/received-invoices/:id/cdar → 205 happy → insert + UPDATE status", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const id = await seedReceived(seed.customerId);

    const res = await fetch(`${app.url}/api/received-invoices/${id}/cdar`, {
      method: "POST",
      headers: { authorization: `Bearer ${seed.bearer}`, "content-type": "application/json" },
      body: JSON.stringify({ code: "205" }),
    });
    expect(res.status).toBe(200);
    const body = (await res.json()) as {
      status_current: string;
      cdarEvent: { code: string } | null;
    };
    expect(body.status_current).toBe("accepted_business");
    expect(body.cdarEvent?.code).toBe("fr:205");
    expect(driver.counts.createInvoiceEvent).toBe(1);

    const fiche = await fetch(`${app.url}/api/received-invoices/${id}`, auth(seed.bearer));
    const ficheBody = (await fiche.json()) as { invoice: { status_current: string } };
    expect(ficheBody.invoice.status_current).toBe("accepted_business");
  });

  it("POST /api/received-invoices/:id/cdar → 210 + reason_code valide → insert", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const id = await seedReceived(seed.customerId);

    const res = await fetch(`${app.url}/api/received-invoices/${id}/cdar`, {
      method: "POST",
      headers: { authorization: `Bearer ${seed.bearer}`, "content-type": "application/json" },
      body: JSON.stringify({ code: "210", reason_code: "03" }),
    });
    expect(res.status).toBe(200);
    const body = (await res.json()) as {
      status_current: string;
      cdarEvent: { reason_code: string | null } | null;
    };
    expect(body.status_current).toBe("refused_business");
    expect(body.cdarEvent?.reason_code).toBe("03");
  });

  it("POST /api/received-invoices/:id/cdar → 422 reason_code manquant si 210", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const id = await seedReceived(seed.customerId);

    const res = await fetch(`${app.url}/api/received-invoices/${id}/cdar`, {
      method: "POST",
      headers: { authorization: `Bearer ${seed.bearer}`, "content-type": "application/json" },
      body: JSON.stringify({ code: "210" }),
    });
    expect(res.status).toBe(422);
    expect(driver.counts.createInvoiceEvent).toBe(0);
  });

  it("POST /api/received-invoices/:id/cdar → 422 reason_text manquant si reason_code 11", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const id = await seedReceived(seed.customerId);

    const res = await fetch(`${app.url}/api/received-invoices/${id}/cdar`, {
      method: "POST",
      headers: { authorization: `Bearer ${seed.bearer}`, "content-type": "application/json" },
      body: JSON.stringify({ code: "210", reason_code: "11" }),
    });
    expect(res.status).toBe(422);
  });

  it("POST /api/received-invoices/:id/cdar → 211 happy (post-205) → payment_transmitted", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const id = await seedReceived(seed.customerId, { status_current: "accepted_business" });

    const res = await fetch(`${app.url}/api/received-invoices/${id}/cdar`, {
      method: "POST",
      headers: { authorization: `Bearer ${seed.bearer}`, "content-type": "application/json" },
      body: JSON.stringify({ code: "211" }),
    });
    expect(res.status).toBe(200);
    const body = (await res.json()) as {
      status_current: string;
      cdarEvent: { code: string } | null;
    };
    expect(body.status_current).toBe("payment_transmitted");
    expect(body.cdarEvent?.code).toBe("fr:211");
    expect(driver.counts.createInvoiceEvent).toBe(1);
  });

  it("POST /api/received-invoices/:id/cdar → 211 sur statut non approuvé → 422 + pas de pose", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const id = await seedReceived(seed.customerId, { status_current: "in_process" });

    const res = await fetch(`${app.url}/api/received-invoices/${id}/cdar`, {
      method: "POST",
      headers: { authorization: `Bearer ${seed.bearer}`, "content-type": "application/json" },
      body: JSON.stringify({ code: "211" }),
    });
    expect(res.status).toBe(422);
    expect(driver.counts.createInvoiceEvent).toBe(0);
  });

  it("GET /api/received-invoices/:id/pdf → 200 stream PDF (rôle Full)", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const id = await seedReceived(seed.customerId);
    // Mock download default = PDF stub → passthrough.

    const res = await fetch(`${app.url}/api/received-invoices/${id}/pdf`, auth(seed.bearer));
    expect(res.status).toBe(200);
    expect(res.headers.get("content-type")).toContain("application/pdf");
    // R2 — passthrough Factur-X = ReadableView PA → en-tête source `pa`.
    expect(res.headers.get("x-pdf-source")).toBe("pa");
  });

  it("GET /api/received-invoices/:id/pdf → XML pur → rendu maison réduit (200 PDF, Axe B)", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const id = await seedReceived(seed.customerId);
    // PA ne fournit pas de PDF lisible → XML CII pur → readable-view maison.
    driver.setDownloadInvoiceFileResult({
      bytes: Buffer.from(CII_SAMPLE, "utf8"),
      contentType: "application/xml",
    });

    const res = await fetch(`${app.url}/api/received-invoices/${id}/pdf`, auth(seed.bearer));
    expect(res.status).toBe(200);
    expect(res.headers.get("content-type")).toContain("application/pdf");
    // R2 — rendu maison `renderPdfFromXml` → en-tête source `home` (pilote
    // l'étiquette « Vue lisible reconstituée » côté fiche).
    expect(res.headers.get("x-pdf-source")).toBe("home");
    const bytes = Buffer.from(await res.arrayBuffer());
    expect(bytes.subarray(0, 5).toString("latin1")).toBe("%PDF-");
  });

  it("GET /api/received-invoices/:id/pdf → 403 rôle Restreint (deposit_simple)", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    await sql`UPDATE users SET role = 'deposit_simple' WHERE id = ${seed.userId}`;
    const id = await seedReceived(seed.customerId);

    const res = await fetch(`${app.url}/api/received-invoices/${id}/pdf`, auth(seed.bearer));
    expect(res.status).toBe(403);
  });

  it("GET /api/received-invoices/:id/xml → 403 rôle Responsable (deposit_states, XML = Full only)", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    await sql`UPDATE users SET role = 'deposit_states' WHERE id = ${seed.userId}`;
    const id = await seedReceived(seed.customerId);

    const res = await fetch(`${app.url}/api/received-invoices/${id}/xml`, auth(seed.bearer));
    expect(res.status).toBe(403);
  });

  // ─── AVOIR-11 — rectificative 384 reçue (oracle corpus rx-384, ZG-5) ───

  it("GET 384 → type 384 + creditNote.originFound (R5/R6 matching étendu 384)", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    // Origine 380 présente en Réception (clé naturelle seller 000000002 +
    // numéro FX-380-BASE-001 = le BG-3 de la rectificative).
    const originId = await seedReceived(seed.customerId, {
      pa_invoice_id_in: "pa-origin-380",
      seller_siren: "000000002",
      invoice_number_extracted: "FX-380-BASE-001",
      type_code: "380",
    });
    const rectifId = await seedReceived(seed.customerId, {
      pa_invoice_id_in: "pa-rectif-384",
      seller_siren: "000000002",
      invoice_number_extracted: "FX-384-RECT-001",
      type_code: "384",
    });
    // Document 384 DÉRIVÉ du corpus (BG-3 → FX-380-BASE-001) servi par le mock.
    const { xmlString } = await buildIncomingFileFromEmissionFixture("fx-384-rectif-bg3");
    driver.setDownloadInvoiceFileResult({
      bytes: Buffer.from(xmlString, "utf8"),
      contentType: "application/xml",
    });

    const res = await fetch(`${app.url}/api/received-invoices/${rectifId}`, auth(seed.bearer));
    expect(res.status).toBe(200);
    const body = (await res.json()) as {
      parsedMetadata: { document: { documentType: string } } | null;
      creditNote: {
        isCreditNote: boolean;
        originFound: boolean;
        originReceivedInvoiceId: string | null;
        originStatus: string | null;
      } | null;
    };
    // R5 : type 384 (rectificative, pas avoir 381).
    expect(body.parsedMetadata?.document.documentType).toBe("384");
    // R6 : le gate étendu retrouve l'origine seedée (échouait sur le gate 381-only).
    expect(body.creditNote?.originFound).toBe(true);
    expect(body.creditNote?.originReceivedInvoiceId).toBe(originId);
    // Statut de l'origine remonté (pilote l'affichage du CTA « Accepter »).
    expect(body.creditNote?.originStatus).toBe("in_process");
    // Une rectificative n'est PAS remboursable (pas de CTA 211).
    expect(body.creditNote?.isCreditNote).toBe(false);
  });

  it("POST 209 (acheteur) → annulation LOCALE de l'origine (cancelled + cdar 209 source 'app', SANS pose PA) (R3 / V1a ADR-020 D4)", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const originId = await seedReceived(seed.customerId, { status_current: "accepted_business" });

    // V1a : « Annulée » inexprimable via SuperPDP (fr:220 absent, fr:209 =
    // « Complétée ») → le 209 acheteur saute l'appel PA et annule localement.
    const eventsBefore = driver.counts.createInvoiceEvent;
    const res = await fetch(`${app.url}/api/received-invoices/${originId}/cdar`, {
      method: "POST",
      headers: { authorization: `Bearer ${seed.bearer}`, "content-type": "application/json" },
      body: JSON.stringify({ code: "209" }),
    });
    expect(res.status).toBe(200);
    const body = (await res.json()) as {
      status_current: string;
      cdarEvent: { code: string; source: string } | null;
    };
    expect(body.status_current).toBe("cancelled");
    expect(body.cdarEvent?.code).toBe("fr:209");
    expect(body.cdarEvent?.source).toBe("app");
    // Coeur du carve-out : AUCUNE pose PA `createInvoiceEvent` pour le 209.
    expect(driver.counts.createInvoiceEvent).toBe(eventsBefore);

    const fiche = await fetch(`${app.url}/api/received-invoices/${originId}`, auth(seed.bearer));
    const ficheBody = (await fiche.json()) as { invoice: { status_current: string } };
    expect(ficheBody.invoice.status_current).toBe("cancelled");

    // Audit : succès local + marqueur `skipped_unsupported_220` (miroir vendeur).
    const audits = await sql<{ metadata: { code?: string; pa_propagation?: string } }[]>`
      SELECT metadata FROM auth_audit
      WHERE customer_id = ${seed.customerId}
        AND event_type = 'received_invoice_cdar_posted'
        AND success = true
    `;
    const cancelAudit = audits.find((a) => a.metadata.code === "209");
    expect(cancelAudit?.metadata.pa_propagation).toBe("skipped_unsupported_220");
  });

  it("liste : cancelled_by_self reflète la source du 209 (app=true, polling=false)", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const selfId = await seedReceived(seed.customerId, {
      pa_invoice_id_in: "pa-209-self",
      status_current: "cancelled",
    });
    const supplierId = await seedReceived(seed.customerId, {
      pa_invoice_id_in: "pa-209-supplier",
      status_current: "cancelled",
    });
    await insertIncomingCdarEvent(sql, {
      received_invoice_id: selfId,
      code: "fr:209",
      occurred_at: "2026-06-02T10:00:00.000Z",
      source: "app",
    });
    await insertIncomingCdarEvent(sql, {
      received_invoice_id: supplierId,
      code: "fr:209",
      occurred_at: "2026-06-02T10:00:00.000Z",
      source: "polling",
    });

    const res = await fetch(`${app.url}/api/received-invoices`, auth(seed.bearer));
    expect(res.status).toBe(200);
    const body = (await res.json()) as {
      items: { id: string; cancelled_by_self: boolean }[];
    };
    expect(body.items.find((i) => i.id === selfId)?.cancelled_by_self).toBe(true);
    expect(body.items.find((i) => i.id === supplierId)?.cancelled_by_self).toBe(false);
  });

  it("POST 209 sur une facture déjà annulée → 422 + pas de double pose (anti double accept)", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const originId = await seedReceived(seed.customerId, { status_current: "cancelled" });

    const res = await fetch(`${app.url}/api/received-invoices/${originId}/cdar`, {
      method: "POST",
      headers: { authorization: `Bearer ${seed.bearer}`, "content-type": "application/json" },
      body: JSON.stringify({ code: "209" }),
    });
    expect(res.status).toBe(422);
    expect(driver.counts.createInvoiceEvent).toBe(0);
  });

  it("download par paInvoiceId : la fiche origine sert SON document (380), pas celui de la 384", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    if (RX_BASE.source.kind !== "emission")
      throw new Error("rx-380-base-facturx doit être emission");
    const { xmlString: originXml } = await buildIncomingFileFromEmissionFixture(
      RX_BASE.source.emissionFixtureId,
    );
    const { xmlString: rectifXml } =
      await buildIncomingFileFromEmissionFixture("fx-384-rectif-bg3");

    const originId = await seedReceived(seed.customerId, {
      pa_invoice_id_in: "pa-origin-pid",
      seller_siren: "000000002",
      invoice_number_extracted: "FX-380-BASE-001",
      type_code: "380",
    });
    const rectifId = await seedReceived(seed.customerId, {
      pa_invoice_id_in: "pa-rectif-pid",
      seller_siren: "000000002",
      invoice_number_extracted: "FX-384-RECT-001",
      type_code: "384",
    });
    driver.setDownloadInvoiceFileResultFor("pa-origin-pid", {
      bytes: Buffer.from(originXml, "utf8"),
      contentType: "application/xml",
    });
    driver.setDownloadInvoiceFileResultFor("pa-rectif-pid", {
      bytes: Buffer.from(rectifXml, "utf8"),
      contentType: "application/xml",
    });

    const origin = (await (
      await fetch(`${app.url}/api/received-invoices/${originId}`, auth(seed.bearer))
    ).json()) as {
      parsedMetadata: { document: { documentType: string } } | null;
      creditNote: unknown;
    };
    // L'origine parse SON propre document (380) → aucun rattachement
    // rectificative (le bug recette servait le doc de la 384 à l'origine).
    expect(origin.parsedMetadata?.document.documentType).toBe("380");
    expect(origin.creditNote).toBeNull();

    const rectif = (await (
      await fetch(`${app.url}/api/received-invoices/${rectifId}`, auth(seed.bearer))
    ).json()) as { parsedMetadata: { document: { documentType: string } } | null };
    expect(rectif.parsedMetadata?.document.documentType).toBe("384");
  });

  // ─── R4 (FICHE-FIXS) — lien inverse origine → rectificative ───

  it("GET origine 380 → linkedRectifications cite la 384 qui la vise (R4 sens retour)", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const { xmlString: originXml } = await buildIncomingFileFromEmissionFixture(
      RX_BASE.source.kind === "emission" ? RX_BASE.source.emissionFixtureId : "fx-380-base",
    );
    const { xmlString: rectifXml } =
      await buildIncomingFileFromEmissionFixture("fx-384-rectif-bg3");

    const originId = await seedReceived(seed.customerId, {
      pa_invoice_id_in: "pa-r4-origin",
      seller_siren: "000000002",
      invoice_number_extracted: "FX-380-BASE-001",
      type_code: "380",
    });
    const rectifId = await seedReceived(seed.customerId, {
      pa_invoice_id_in: "pa-r4-rectif",
      seller_siren: "000000002",
      invoice_number_extracted: "FX-384-RECT-001",
      type_code: "384",
    });
    driver.setDownloadInvoiceFileResultFor("pa-r4-origin", {
      bytes: Buffer.from(originXml, "utf8"),
      contentType: "application/xml",
    });
    driver.setDownloadInvoiceFileResultFor("pa-r4-rectif", {
      bytes: Buffer.from(rectifXml, "utf8"),
      contentType: "application/xml",
    });

    const body = (await (
      await fetch(`${app.url}/api/received-invoices/${originId}`, auth(seed.bearer))
    ).json()) as {
      linkedRectifications:
        | { receivedInvoiceId: string; number: string | null; typeCode: string | null }[]
        | null;
    };
    expect(body.linkedRectifications).not.toBeNull();
    expect(body.linkedRectifications).toHaveLength(1);
    expect(body.linkedRectifications?.[0]).toMatchObject({
      receivedInvoiceId: rectifId,
      number: "FX-384-RECT-001",
      typeCode: "384",
    });
  });

  it("R4 isolation tenant : la 384 d'un AUTRE customer ne se rattache pas à l'origine", async () => {
    // Invariant S07/R1 : la requête candidats est scopée `customer_id`. Une
    // rectificative d'un autre customer (même fournisseur + même numéro
    // d'origine référencé) ne doit JAMAIS être résolue comme visant l'origine.
    const seedA = await seedFullCustomer(sql, { secretStore: secrets });
    const seedB = await seedFullCustomer(sql, { secretStore: secrets });
    const { xmlString: originXml } = await buildIncomingFileFromEmissionFixture(
      RX_BASE.source.kind === "emission" ? RX_BASE.source.emissionFixtureId : "fx-380-base",
    );
    const { xmlString: rectifXml } =
      await buildIncomingFileFromEmissionFixture("fx-384-rectif-bg3");

    const originId = await seedReceived(seedA.customerId, {
      pa_invoice_id_in: "pa-r4-origin-a",
      seller_siren: "000000002",
      invoice_number_extracted: "FX-380-BASE-001",
      type_code: "380",
    });
    // Rectificative chez le customer B visant le MÊME numéro d'origine.
    await seedReceived(seedB.customerId, {
      pa_invoice_id_in: "pa-r4-rectif-b",
      seller_siren: "000000002",
      invoice_number_extracted: "FX-384-RECT-001",
      type_code: "384",
    });
    driver.setDownloadInvoiceFileResultFor("pa-r4-origin-a", {
      bytes: Buffer.from(originXml, "utf8"),
      contentType: "application/xml",
    });
    // Téléchargement de la 384 de B disponible : si le scope tenant fuitait, le
    // parsing matcherait FX-380-BASE-001 → le test échouerait (garde réelle).
    driver.setDownloadInvoiceFileResultFor("pa-r4-rectif-b", {
      bytes: Buffer.from(rectifXml, "utf8"),
      contentType: "application/xml",
    });

    const body = (await (
      await fetch(`${app.url}/api/received-invoices/${originId}`, auth(seedA.bearer))
    ).json()) as { linkedRectifications: unknown[] | null };
    expect(body.linkedRectifications).toBeNull();
  });
});
