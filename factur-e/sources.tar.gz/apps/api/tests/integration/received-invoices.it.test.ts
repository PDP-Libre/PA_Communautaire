import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { MockPADriver } from "@factur-e/shared-fakes";

import { insertIncomingCdarEvent } from "../../src/db/repos/incoming_cdar_events.js";
import {
  insertReceivedInvoice,
  type NewReceivedInvoiceRow,
} from "../../src/db/repos/received_invoices.js";
import { MemorySecretStore } from "../../src/secrets/index.js";
import { seedFullCustomer } from "../_fixtures/seed-customer.js";
import { buildTestApp, type TestApp } from "../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../helpers/test-db.js";

/**
 * T-CL-RECV-API sprint-05 W2 — Tests intégration HTTP `/api/received-invoices/*`.
 * Pattern `buildTestApp` + `fetch` natif (cf. `docs/guides/test-ci.md`).
 *
 * ≥ 12 cas : liste (vide / peuplée / filtre statut / pagination cursor),
 * fiche (complète / parsedMetadata / 404 RBAC scope), pose CDAR (205 / 210 /
 * 422 reason_code manquant / 422 reason_text manquant), proxy PDF (200 Full /
 * 403 Restreint) + proxy XML (403 Responsable).
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

const CII_SAMPLE = `<?xml version="1.0" encoding="UTF-8"?>
<rsm:CrossIndustryInvoice xmlns:rsm="urn:un:unece:uncefact:data:standard:CrossIndustryInvoice:100" xmlns:ram="urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:100" xmlns:udt="urn:un:unece:uncefact:data:standard:UnqualifiedDataType:100">
  <rsm:ExchangedDocument><ram:ID>FA-RECV-1</ram:ID><ram:TypeCode>380</ram:TypeCode><ram:IssueDateTime><udt:DateTimeString format="102">20260518</udt:DateTimeString></ram:IssueDateTime></rsm:ExchangedDocument>
  <rsm:SupplyChainTradeTransaction>
    <ram:ApplicableHeaderTradeAgreement>
      <ram:SellerTradeParty><ram:Name>Tricatel</ram:Name><ram:SpecifiedLegalOrganization><ram:ID schemeID="0002">552100554</ram:ID></ram:SpecifiedLegalOrganization></ram:SellerTradeParty>
      <ram:BuyerTradeParty><ram:Name>Burger Queen</ram:Name></ram:BuyerTradeParty>
    </ram:ApplicableHeaderTradeAgreement>
    <ram:ApplicableHeaderTradeSettlement>
      <ram:InvoiceCurrencyCode>EUR</ram:InvoiceCurrencyCode>
      <ram:SpecifiedTradeSettlementHeaderMonetarySummation><ram:GrandTotalAmount>1200.50</ram:GrandTotalAmount></ram:SpecifiedTradeSettlementHeaderMonetarySummation>
    </ram:ApplicableHeaderTradeSettlement>
  </rsm:SupplyChainTradeTransaction>
</rsm:CrossIndustryInvoice>`;

describe.skipIf(!enabled)("[received-invoices] routes `/api/received-invoices/*`", () => {
  let db: TestDb;
  let sql: postgres.Sql;
  let secrets: MemorySecretStore;
  let driver: MockPADriver;
  let app: TestApp;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 5, onnotice: () => undefined });
    secrets = new MemorySecretStore();
    driver = new MockPADriver();
    app = await buildTestApp({ connectionString: db.url, paDriver: driver, secretStore: secrets });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    driver.reset();
  });

  async function seedReceived(
    customerId: string,
    overrides: Partial<NewReceivedInvoiceRow> = {},
  ): Promise<string> {
    const row = await insertReceivedInvoice(sql, {
      customer_id: customerId,
      pa_invoice_id_in:
        overrides.pa_invoice_id_in ?? `pa-${Math.random().toString(36).slice(2, 9)}`,
      seller_siren: "552100554",
      seller_name_cached: "Tricatel",
      supplier_matched: true,
      invoice_number_extracted: "FA-RECV-1",
      issue_date: "2026-05-18",
      total_ttc_cents: 120050,
      currency: "EUR",
      status_current: "in_process",
      ...overrides,
    });
    if (row === null) throw new Error("seedReceived: insert returned null");
    return row.id;
  }

  const auth = (bearer: string): RequestInit => ({
    headers: { authorization: `Bearer ${bearer}` },
  });

  it("GET /api/received-invoices → 401 sans bearer", async () => {
    const res = await fetch(`${app.url}/api/received-invoices`);
    expect(res.status).toBe(401);
  });

  it("GET /api/received-invoices → liste vide", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const res = await fetch(`${app.url}/api/received-invoices`, auth(seed.bearer));
    expect(res.status).toBe(200);
    const body = (await res.json()) as { items: unknown[]; nextCursor: string | null };
    expect(body.items).toHaveLength(0);
    expect(body.nextCursor).toBeNull();
  });

  it("GET /api/received-invoices → liste peuplée + filtre status", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    await seedReceived(seed.customerId, { status_current: "in_process" });
    await seedReceived(seed.customerId, { status_current: "accepted_business" });
    await seedReceived(seed.customerId, { status_current: "in_process" });

    const all = await fetch(`${app.url}/api/received-invoices`, auth(seed.bearer));
    const allBody = (await all.json()) as { items: unknown[] };
    expect(allBody.items).toHaveLength(3);

    const filtered = await fetch(
      `${app.url}/api/received-invoices?status=accepted_business`,
      auth(seed.bearer),
    );
    const filteredBody = (await filtered.json()) as { items: { status_current: string }[] };
    expect(filteredBody.items).toHaveLength(1);
    expect(filteredBody.items[0]?.status_current).toBe("accepted_business");
  });

  it("GET /api/received-invoices → pagination cursor (page 1 → page 2)", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    for (let i = 0; i < 3; i++) await seedReceived(seed.customerId);

    const page1 = await fetch(`${app.url}/api/received-invoices?limit=2`, auth(seed.bearer));
    const p1 = (await page1.json()) as { items: { id: string }[]; nextCursor: string | null };
    expect(p1.items).toHaveLength(2);
    expect(p1.nextCursor).not.toBeNull();

    const page2 = await fetch(
      `${app.url}/api/received-invoices?limit=2&cursor=${encodeURIComponent(p1.nextCursor ?? "")}`,
      auth(seed.bearer),
    );
    const p2 = (await page2.json()) as { items: { id: string }[]; nextCursor: string | null };
    expect(p2.items).toHaveLength(1);
    expect(p2.nextCursor).toBeNull();
    // Pas de chevauchement entre les pages.
    const ids = new Set([...p1.items, ...p2.items].map((i) => i.id));
    expect(ids.size).toBe(3);
  });

  it("GET /api/received-invoices/:id → fiche + cdarEvents + parsedMetadata", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const id = await seedReceived(seed.customerId);
    await insertIncomingCdarEvent(sql, {
      received_invoice_id: id,
      code: "fr:204",
      occurred_at: new Date(),
      source: "polling",
    });
    // Mock download → XML CII → parsedMetadata peuplé.
    driver.setDownloadInvoiceFileResult({
      bytes: Buffer.from(CII_SAMPLE, "utf8"),
      contentType: "application/xml",
    });

    const res = await fetch(`${app.url}/api/received-invoices/${id}`, auth(seed.bearer));
    expect(res.status).toBe(200);
    const body = (await res.json()) as {
      invoice: { id: string; status_current: string };
      supplierMatched: boolean;
      cdarEvents: { code: string }[];
      parsedMetadata: { document: { invoiceNumber: string } } | null;
    };
    expect(body.invoice.id).toBe(id);
    expect(body.supplierMatched).toBe(true);
    expect(body.cdarEvents).toHaveLength(1);
    expect(body.cdarEvents[0]?.code).toBe("fr:204");
    expect(body.parsedMetadata?.document.invoiceNumber).toBe("FA-RECV-1");
  });

  it("GET /api/received-invoices/:id → 404 si pas owned (RBAC scope autre customer)", async () => {
    const owner = await seedFullCustomer(sql, { secretStore: secrets });
    const other = await seedFullCustomer(sql, { secretStore: secrets });
    const id = await seedReceived(owner.customerId);

    const res = await fetch(`${app.url}/api/received-invoices/${id}`, auth(other.bearer));
    expect(res.status).toBe(404);
  });

  it("POST /api/received-invoices/:id/cdar → 205 happy → insert + UPDATE status", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const id = await seedReceived(seed.customerId);

    const res = await fetch(`${app.url}/api/received-invoices/${id}/cdar`, {
      method: "POST",
      headers: { authorization: `Bearer ${seed.bearer}`, "content-type": "application/json" },
      body: JSON.stringify({ code: "205" }),
    });
    expect(res.status).toBe(200);
    const body = (await res.json()) as {
      status_current: string;
      cdarEvent: { code: string } | null;
    };
    expect(body.status_current).toBe("accepted_business");
    expect(body.cdarEvent?.code).toBe("fr:205");
    expect(driver.counts.createInvoiceEvent).toBe(1);

    const fiche = await fetch(`${app.url}/api/received-invoices/${id}`, auth(seed.bearer));
    const ficheBody = (await fiche.json()) as { invoice: { status_current: string } };
    expect(ficheBody.invoice.status_current).toBe("accepted_business");
  });

  it("POST /api/received-invoices/:id/cdar → 210 + reason_code valide → insert", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const id = await seedReceived(seed.customerId);

    const res = await fetch(`${app.url}/api/received-invoices/${id}/cdar`, {
      method: "POST",
      headers: { authorization: `Bearer ${seed.bearer}`, "content-type": "application/json" },
      body: JSON.stringify({ code: "210", reason_code: "03" }),
    });
    expect(res.status).toBe(200);
    const body = (await res.json()) as {
      status_current: string;
      cdarEvent: { reason_code: string | null } | null;
    };
    expect(body.status_current).toBe("refused_business");
    expect(body.cdarEvent?.reason_code).toBe("03");
  });

  it("POST /api/received-invoices/:id/cdar → 422 reason_code manquant si 210", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const id = await seedReceived(seed.customerId);

    const res = await fetch(`${app.url}/api/received-invoices/${id}/cdar`, {
      method: "POST",
      headers: { authorization: `Bearer ${seed.bearer}`, "content-type": "application/json" },
      body: JSON.stringify({ code: "210" }),
    });
    expect(res.status).toBe(422);
    expect(driver.counts.createInvoiceEvent).toBe(0);
  });

  it("POST /api/received-invoices/:id/cdar → 422 reason_text manquant si reason_code 11", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const id = await seedReceived(seed.customerId);

    const res = await fetch(`${app.url}/api/received-invoices/${id}/cdar`, {
      method: "POST",
      headers: { authorization: `Bearer ${seed.bearer}`, "content-type": "application/json" },
      body: JSON.stringify({ code: "210", reason_code: "11" }),
    });
    expect(res.status).toBe(422);
  });

  it("POST /api/received-invoices/:id/cdar → 211 happy (post-205) → payment_transmitted", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const id = await seedReceived(seed.customerId, { status_current: "accepted_business" });

    const res = await fetch(`${app.url}/api/received-invoices/${id}/cdar`, {
      method: "POST",
      headers: { authorization: `Bearer ${seed.bearer}`, "content-type": "application/json" },
      body: JSON.stringify({ code: "211" }),
    });
    expect(res.status).toBe(200);
    const body = (await res.json()) as {
      status_current: string;
      cdarEvent: { code: string } | null;
    };
    expect(body.status_current).toBe("payment_transmitted");
    expect(body.cdarEvent?.code).toBe("fr:211");
    expect(driver.counts.createInvoiceEvent).toBe(1);
  });

  it("POST /api/received-invoices/:id/cdar → 211 sur statut non approuvé → 422 + pas de pose", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const id = await seedReceived(seed.customerId, { status_current: "in_process" });

    const res = await fetch(`${app.url}/api/received-invoices/${id}/cdar`, {
      method: "POST",
      headers: { authorization: `Bearer ${seed.bearer}`, "content-type": "application/json" },
      body: JSON.stringify({ code: "211" }),
    });
    expect(res.status).toBe(422);
    expect(driver.counts.createInvoiceEvent).toBe(0);
  });

  it("GET /api/received-invoices/:id/pdf → 200 stream PDF (rôle Full)", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const id = await seedReceived(seed.customerId);
    // Mock download default = PDF stub → passthrough.

    const res = await fetch(`${app.url}/api/received-invoices/${id}/pdf`, auth(seed.bearer));
    expect(res.status).toBe(200);
    expect(res.headers.get("content-type")).toContain("application/pdf");
  });

  it("GET /api/received-invoices/:id/pdf → XML pur → rendu maison réduit (200 PDF, Axe B)", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const id = await seedReceived(seed.customerId);
    // PA ne fournit pas de PDF lisible → XML CII pur → readable-view maison.
    driver.setDownloadInvoiceFileResult({
      bytes: Buffer.from(CII_SAMPLE, "utf8"),
      contentType: "application/xml",
    });

    const res = await fetch(`${app.url}/api/received-invoices/${id}/pdf`, auth(seed.bearer));
    expect(res.status).toBe(200);
    expect(res.headers.get("content-type")).toContain("application/pdf");
    const bytes = Buffer.from(await res.arrayBuffer());
    expect(bytes.subarray(0, 5).toString("latin1")).toBe("%PDF-");
  });

  it("GET /api/received-invoices/:id/pdf → 403 rôle Restreint (deposit_simple)", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    await sql`UPDATE users SET role = 'deposit_simple' WHERE id = ${seed.userId}`;
    const id = await seedReceived(seed.customerId);

    const res = await fetch(`${app.url}/api/received-invoices/${id}/pdf`, auth(seed.bearer));
    expect(res.status).toBe(403);
  });

  it("GET /api/received-invoices/:id/xml → 403 rôle Responsable (deposit_states, XML = Full only)", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    await sql`UPDATE users SET role = 'deposit_states' WHERE id = ${seed.userId}`;
    const id = await seedReceived(seed.customerId);

    const res = await fetch(`${app.url}/api/received-invoices/${id}/xml`, auth(seed.bearer));
    expect(res.status).toBe(403);
  });
});
