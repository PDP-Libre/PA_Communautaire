import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import type { CdarEvent } from "@factur-e/pa-adapter";
import { MockPADriver } from "@factur-e/shared-fakes";

import { runPollCdarEvents } from "../../../src/jobs/poll-cdar-events.js";
import * as cdarRepo from "../../../src/db/repos/cdar_events.js";
import { MemorySecretStore } from "../../../src/secrets/index.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";
import { seedFullCustomer } from "../../_fixtures/seed-customer.js";

/**
 * Dédup doublon "Déposée/Envoyée" — finding C T-CL-W3-A-CYCLE-VIE-FIXS
 * (recette Sc.6/Sc.11.3 sprint-06).
 *
 * À l'envoi, `create.ts` pose un CDAR `source='synthetic'` immédiat
 * (`occurred_at = new Date()`, ADR-009 D4 fail-safe). Le job polling insère
 * ensuite le vrai event SuperPDP de MEME code (`occurred_at` réel SuperPDP).
 * La clé naturelle `(invoice_id, code, occurred_at)` ne dédoublonne pas car
 * `occurred_at` diffère → 2 lignes pour le même code (`fr:200`/`api:uploaded`).
 *
 * Option A (arbitrage Bruno) : `deleteSyntheticCdarEvent` supprime le
 * placeholder synthetic de même `(invoice_id, code)` dès que le vrai event
 * polling est persisté. Pas de migration. Hypothèse vérifiée (Z1) : le raw
 * code Déposée est identique côté submit et polling.
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("[cycle-de-vie] dedup synthetic/polling (finding C)", () => {
  let db: TestDb;
  let sql: postgres.Sql;
  let secrets: MemorySecretStore;
  let driver: MockPADriver;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 5, onnotice: () => undefined });
    secrets = new MemorySecretStore();
    driver = new MockPADriver();
  });

  afterAll(async () => {
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    driver.reset();
  });

  /** Insère une facture émise (post-envoi) avec un `pa_invoice_id` donné. */
  async function seedSubmittedInvoice(args: {
    customerId: string;
    number: string;
    paInvoiceId: string;
  }): Promise<string> {
    const rows = await sql<{ id: string }[]>`
      INSERT INTO invoices (
        customer_id, number, issue_date, tracking_id, sha256,
        total_ht, total_vat, total_ttc, currency, processing_rule,
        type_code, pa_invoice_id, status_current
      ) VALUES (
        ${args.customerId}, ${args.number}, '2026-05-20',
        ${"33333333-3333-3333-8333-333333333333"},
        ${"c".repeat(64)},
        '100.00', '20.00', '120.00', 'EUR', 'B2B',
        '380', ${args.paInvoiceId}, 'submitted'
      ) RETURNING id
    `;
    return rows[0]?.id ?? "";
  }

  /** Pose le placeholder synthetic Déposée tel que `create.ts` à l'envoi. */
  async function insertSynthetic(invoiceId: string, code: string): Promise<void> {
    await cdarRepo.insertCdarEvent(sql, {
      invoice_id: invoiceId,
      code,
      label: "Déposée",
      occurred_at: "2026-05-20T09:59:00Z",
      source: "synthetic",
    });
  }

  async function rowsFor(
    invoiceId: string,
    code?: string,
  ): Promise<{ code: string; source: string }[]> {
    if (code === undefined) {
      return sql<{ code: string; source: string }[]>`
        SELECT code, source FROM cdar_events WHERE invoice_id = ${invoiceId} ORDER BY code
      `;
    }
    return sql<{ code: string; source: string }[]>`
      SELECT code, source FROM cdar_events
      WHERE invoice_id = ${invoiceId} AND code = ${code}
    `;
  }

  it("le vrai event polling supersede le placeholder synthetic (1 ligne)", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const invoiceId = await seedSubmittedInvoice({
      customerId: seed.customerId,
      number: "F-2026-D1",
      paInvoiceId: "201",
    });
    await insertSynthetic(invoiceId, "fr:200");

    const evt: CdarEvent = {
      paEventId: "evt-201",
      paInvoiceId: "201",
      rawStatusCode: "fr:200",
      status: "validated",
      occurredAt: "2026-05-20T10:00:00Z",
    };
    driver.seedCdarEvents([evt]);

    await runPollCdarEvents({ sql, driver, secrets });

    const r = await rowsFor(invoiceId, "fr:200");
    expect(r.length).toBe(1);
    expect(r[0]?.source).toBe("polling");
  });

  it("cold start : polling sans synthetic préexistant → INSERT normal", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const invoiceId = await seedSubmittedInvoice({
      customerId: seed.customerId,
      number: "F-2026-D2",
      paInvoiceId: "202",
    });

    const evt: CdarEvent = {
      paEventId: "evt-202",
      paInvoiceId: "202",
      rawStatusCode: "fr:200",
      status: "validated",
      occurredAt: "2026-05-20T10:00:00Z",
    };
    driver.seedCdarEvents([evt]);

    await runPollCdarEvents({ sql, driver, secrets });

    const r = await rowsFor(invoiceId);
    expect(r.length).toBe(1);
    expect(r[0]?.source).toBe("polling");
  });

  it("code différent : le synthetic d'un autre code n'est PAS supprimé (ADR-009 D4)", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const invoiceId = await seedSubmittedInvoice({
      customerId: seed.customerId,
      number: "F-2026-D3",
      paInvoiceId: "203",
    });
    await insertSynthetic(invoiceId, "fr:200");

    // Le polling livre un AUTRE code (fr:201) → le synthetic fr:200 subsiste.
    const evt: CdarEvent = {
      paEventId: "evt-203",
      paInvoiceId: "203",
      rawStatusCode: "fr:201",
      status: "validated",
      occurredAt: "2026-05-20T10:05:00Z",
    };
    driver.seedCdarEvents([evt]);

    await runPollCdarEvents({ sql, driver, secrets });

    const r = await rowsFor(invoiceId);
    expect(r.map((x) => x.code)).toEqual(["fr:200", "fr:201"]);
    expect(r.find((x) => x.code === "fr:200")?.source).toBe("synthetic");
  });

  it("fail-safe : polling ne livre rien → synthetic préservé seul (ADR-009 D4)", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const invoiceId = await seedSubmittedInvoice({
      customerId: seed.customerId,
      number: "F-2026-D4",
      paInvoiceId: "204",
    });
    await insertSynthetic(invoiceId, "fr:200");

    // Driver ne seed aucun event — SuperPDP n'a encore rien livré.
    await runPollCdarEvents({ sql, driver, secrets });

    const r = await rowsFor(invoiceId, "fr:200");
    expect(r.length).toBe(1);
    expect(r[0]?.source).toBe("synthetic");
  });
});
