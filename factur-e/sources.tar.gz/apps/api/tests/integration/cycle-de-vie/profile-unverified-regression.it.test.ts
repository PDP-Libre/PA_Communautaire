import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { MockPADriver } from "@factur-e/shared-fakes";

import { runPollPaIdentityStatus } from "../../../src/jobs/poll-pa-identity-status.js";
import { MemorySecretStore } from "../../../src/secrets/index.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";
import { seedFullCustomer } from "../../_fixtures/seed-customer.js";

/**
 * Cas #13 — Régression ADR-007bis D3 : non-flip de
 * `customers.profile_unverified` lors d'un cycle transient
 * `verified → needs_review → verified` post-onboarding initial.
 *
 * Contexte. Un customer onboardé sprint-02 + connecté PA sprint-03 a
 * `profile_unverified = false` (acté par T-CL-07 + ADR-007). Si la PA
 * SuperPDP bascule transitoirement `user_identity_verification_status`
 * sur `needs_review` (audit manuel ponctuel, par exemple), puis retour
 * `verified`, la valeur `profile_unverified` doit rester `false`
 * CONSTANT — pas de re-flip. Cf. commentaire `poll-pa-identity-status.ts:140-152`
 * (T-CL-07 expert review [low] #5).
 *
 * Le job émet `pa_identity_status_changed` à chaque transition, mais
 * **ne ré-émet pas** `pa_profile_verified` quand
 * `markCustomerProfileVerified` retourne `updatedRows = 0` (= le flag
 * était déjà FALSE).
 *
 * [MAJ 2026-05-26 T-CL-SIREN-RECONCILIATION] — l'event
 * `pa_identity_status_pending_after_verified` (Mécanisme 2, ADR-007bis
 * D3) est désormais IMPLÉMENTÉ dans `poll-pa-identity-status.ts:pollOne`
 * (dette `[DEBT-medium]` levée, T-CL-OBSERVABILITY-IDENTITY-CYCLE
 * absorbé). Il n'est émis QUE sur une vraie régression d'axe
 * `verified → needs_review` observée par le polling — pas sur le sens
 * récupération `needs_review → verified` testé ici. La couverture
 * positive de l'event vit dans `tests/jobs/poll-pa-identity-status.it.test.ts` ;
 * on asserte ici son ABSENCE (la récupération n'est pas un cycle régressif).
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("[cycle-de-vie] profile_unverified non-régression ADR-007bis D3", () => {
  let db: TestDb;
  let sql: postgres.Sql;
  let secrets: MemorySecretStore;
  let driver: MockPADriver;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 5, onnotice: () => undefined });
    secrets = new MemorySecretStore();
    driver = new MockPADriver();
  });

  afterAll(async () => {
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    driver.reset();
  });

  it("cycle verified → needs_review → verified : profile_unverified=false constant + pas de pa_profile_verified doublon", async () => {
    // T0 — customer onboardé, profile_unverified=false (état post sprint-03).
    const seed = await seedFullCustomer(sql, {
      secretStore: secrets,
      profileUnverified: false,
      identityStatus: { user: "verified", company: "verified" },
    });
    expect(seed.customerId).not.toBe("");

    // T1 — la PA bascule transitoirement `user_identity_verification_status`
    // vers `needs_review` (audit manuel ponctuel côté SuperPDP). On
    // simule en UPDATE direct sur pa_connections (= comme si le polling
    // précédent avait observé ce statut). Le job devra rattraper le
    // retour à `verified` au tick suivant.
    await sql`
      UPDATE pa_connections
      SET user_identity_verification_status = 'needs_review'
      WHERE customer_id = ${seed.customerId}
    `;

    // T2 — la PA répond `verified/verified` à nouveau. Le job pollue
    // et observe la bascule retour.
    driver.setIdentityStatus({ user: "verified", company: "verified" });
    const result = await runPollPaIdentityStatus({ sql, driver, secrets });
    expect(result.scanned).toBe(1);
    expect(result.changed).toBe(1); // statut user a effectivement changé
    // cleared_profile_unverified = 0 puisque le flag était déjà FALSE.
    expect(result.cleared_profile_unverified).toBe(0);

    // Assertion clé ADR-007bis D3 : profile_unverified reste FALSE.
    const cust = await sql<{ profile_unverified: boolean }[]>`
      SELECT profile_unverified FROM customers WHERE id = ${seed.customerId}
    `;
    expect(cust[0]?.profile_unverified).toBe(false);

    // Audit : `pa_identity_status_changed` émis (transition observée),
    // PAS de `pa_profile_verified` doublon (le flag n'a pas été
    // re-baissé).
    const audits = await sql<{ event_type: string }[]>`
      SELECT event_type FROM auth_audit WHERE customer_id = ${seed.customerId}
    `;
    expect(audits.some((a) => a.event_type === "pa_identity_status_changed")).toBe(true);
    expect(audits.filter((a) => a.event_type === "pa_profile_verified")).toHaveLength(0);
    // Mécanisme 2 négatif : la récupération `needs_review → verified`
    // n'est PAS un cycle régressif → pas d'event pending_after_verified.
    expect(
      audits.filter((a) => a.event_type === "pa_identity_status_pending_after_verified"),
    ).toHaveLength(0);

    // pa_connections.user_identity_verification_status remonté à 'verified'.
    const conn = await sql<{ user_identity_verification_status: string }[]>`
      SELECT user_identity_verification_status FROM pa_connections
      WHERE customer_id = ${seed.customerId}
    `;
    expect(conn[0]?.user_identity_verification_status).toBe("verified");
  });

  it("symétrique côté company axis : verified → needs_review → verified, pas de flip", async () => {
    const seed = await seedFullCustomer(sql, {
      secretStore: secrets,
      profileUnverified: false,
      identityStatus: { user: "verified", company: "verified" },
    });
    await sql`
      UPDATE pa_connections
      SET company_verification_status = 'needs_review'
      WHERE customer_id = ${seed.customerId}
    `;
    driver.setIdentityStatus({ user: "verified", company: "verified" });

    const result = await runPollPaIdentityStatus({ sql, driver, secrets });
    expect(result.cleared_profile_unverified).toBe(0);

    const cust = await sql<{ profile_unverified: boolean }[]>`
      SELECT profile_unverified FROM customers WHERE id = ${seed.customerId}
    `;
    expect(cust[0]?.profile_unverified).toBe(false);

    const audits = await sql<{ event_type: string }[]>`
      SELECT event_type FROM auth_audit WHERE customer_id = ${seed.customerId}
    `;
    expect(audits.filter((a) => a.event_type === "pa_profile_verified")).toHaveLength(0);
  });
});
