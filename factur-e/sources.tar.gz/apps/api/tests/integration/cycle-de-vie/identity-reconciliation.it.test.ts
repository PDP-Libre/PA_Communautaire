import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { reconcileCustomerIdentity } from "../../../src/services/identity-reconciliation.js";
import { insertReceivedInvoice } from "../../../src/db/repos/received_invoices.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";
import { seedFullCustomer } from "../../_fixtures/seed-customer.js";

/**
 * Mécanisme 3 — réconciliation SIREN onboarding ↔ société attestée KYC
 * (T-CL-SIREN-RECONCILIATION sprint-06 W1, US-PA-005).
 *
 * Couvre : mismatch sans facture → réconciliation + réinitialisation infos
 * entreprise (Option B) ; SIREN identique → no-op ; SIREN attesté absent →
 * fail-safe ; **mismatch avec historique de factures → blocage** (règle
 * Bruno sprint-06) ; idempotence.
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

const COMPANY = {
  siren: "999999998",
  formalName: "Tricatel SAS",
  address: { line: "1 rue de Test", postcode: "75001", city: "Paris", country: "FR" },
} as const;

interface AuditRow {
  event_type: string;
  metadata: Record<string, unknown> | null;
}

describe.skipIf(!enabled)("[cycle-de-vie] réconciliation SIREN (Mécanisme 3)", () => {
  let db: TestDb;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 5, onnotice: () => undefined });
  });

  afterAll(async () => {
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  async function audits(customerId: string, eventType: string): Promise<AuditRow[]> {
    return sql<AuditRow[]>`
      SELECT event_type, metadata FROM auth_audit
      WHERE customer_id = ${customerId} AND event_type = ${eventType}
      ORDER BY occurred_at ASC, id ASC
    `;
  }

  it("mismatch sans facture → réconciliation + réinitialisation infos entreprise (Option B)", async () => {
    const seed = await seedFullCustomer(sql, {
      siren: "000000001",
      profileUnverified: true,
      withPaConnection: false,
    });
    // Pré-remplir des descripteurs entreprise pour vérifier leur reset.
    await sql`
      UPDATE customers
      SET naf_code = '6201Z', rcs = 'Paris B 123', juridique_code = '5710',
          capital_social = 10000, trading_name = 'Ancien Nom'
      WHERE id = ${seed.customerId}
    `;

    const result = await reconcileCustomerIdentity({
      sql,
      customerId: seed.customerId,
      company: COMPANY,
    });
    expect(result.status).toBe("reconciled");
    expect(result).toMatchObject({ valueBefore: "000000001", valueAfter: "999999998" });

    const cust = await sql<
      {
        siren: string;
        legal_name: string;
        vat_number: string | null;
        naf_code: string | null;
        rcs: string | null;
        juridique_code: string | null;
        capital_social: string | null;
        trading_name: string | null;
        directory_address: string | null;
        siren_unverified: boolean;
        vat_number_unverified: boolean;
        address: Record<string, unknown>;
      }[]
    >`
      SELECT siren, legal_name, vat_number, naf_code, rcs, juridique_code,
             capital_social::text AS capital_social, trading_name, directory_address,
             siren_unverified, vat_number_unverified, address
      FROM customers WHERE id = ${seed.customerId}
    `;
    const c = cust[0];
    expect(c?.siren).toBe("999999998");
    expect(c?.legal_name).toBe("Tricatel SAS");
    expect(c?.address).toMatchObject({ city: "Paris", postcode: "75001", country_code: "FR" });
    // Descripteurs réinitialisés.
    expect(c?.vat_number).toBeNull();
    expect(c?.naf_code).toBeNull();
    expect(c?.rcs).toBeNull();
    expect(c?.juridique_code).toBeNull();
    expect(c?.capital_social).toBeNull();
    expect(c?.trading_name).toBeNull();
    expect(c?.directory_address).toBeNull();
    // Flags : SIREN attesté, N° TVA à re-confirmer.
    expect(c?.siren_unverified).toBe(false);
    expect(c?.vat_number_unverified).toBe(true);

    const ev = await audits(seed.customerId, "pa_identity_siren_reconciled");
    expect(ev).toHaveLength(1);
    expect(ev[0]?.metadata).toMatchObject({
      field: "siren",
      value_before: "000000001",
      value_after: "999999998",
      kyc_source: "superpdp",
    });
  });

  it("SIREN identique → no-op, pas d'event", async () => {
    const seed = await seedFullCustomer(sql, {
      siren: "999999998",
      profileUnverified: true,
      withPaConnection: false,
    });
    const result = await reconcileCustomerIdentity({
      sql,
      customerId: seed.customerId,
      company: COMPANY,
    });
    expect(result.status).toBe("no_op");
    expect(await audits(seed.customerId, "pa_identity_siren_reconciled")).toHaveLength(0);
  });

  it("SIREN attesté absent (null) → fail-safe no-op", async () => {
    const seed = await seedFullCustomer(sql, {
      siren: "000000001",
      profileUnverified: true,
      withPaConnection: false,
    });
    const result = await reconcileCustomerIdentity({
      sql,
      customerId: seed.customerId,
      company: { siren: null, formalName: "", address: null },
    });
    expect(result.status).toBe("no_op");
    expect(await audits(seed.customerId, "pa_identity_siren_reconciled")).toHaveLength(0);
  });

  it("mismatch AVEC historique de factures → BLOCAGE (pas de changement de SIREN)", async () => {
    const seed = await seedFullCustomer(sql, {
      siren: "000000001",
      profileUnverified: true,
      withPaConnection: false,
    });
    // Une facture reçue suffit à bloquer.
    await insertReceivedInvoice(sql, {
      customer_id: seed.customerId,
      pa_invoice_id_in: "in-1",
      seller_siren: "123456789",
    });

    const result = await reconcileCustomerIdentity({
      sql,
      customerId: seed.customerId,
      company: COMPANY,
    });
    expect(result.status).toBe("blocked");
    expect(result.effectiveSiren).toBe("000000001");

    // SIREN inchangé.
    const cust = await sql<{ siren: string }[]>`
      SELECT siren FROM customers WHERE id = ${seed.customerId}
    `;
    expect(cust[0]?.siren).toBe("000000001");

    // Audit blocage émis, PAS d'event de réconciliation.
    expect(await audits(seed.customerId, "pa_identity_siren_reconcile_blocked")).toHaveLength(1);
    expect(await audits(seed.customerId, "pa_identity_siren_reconciled")).toHaveLength(0);
  });

  it("idempotence — re-jeu après réconciliation → un seul event", async () => {
    const seed = await seedFullCustomer(sql, {
      siren: "000000001",
      profileUnverified: true,
      withPaConnection: false,
    });
    await reconcileCustomerIdentity({ sql, customerId: seed.customerId, company: COMPANY });
    const second = await reconcileCustomerIdentity({
      sql,
      customerId: seed.customerId,
      company: COMPANY,
    });
    expect(second.status).toBe("no_op");
    expect(await audits(seed.customerId, "pa_identity_siren_reconciled")).toHaveLength(1);
  });
});
