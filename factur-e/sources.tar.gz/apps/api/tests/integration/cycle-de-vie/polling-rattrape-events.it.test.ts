import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import type { CdarEvent } from "@factur-e/pa-adapter";
import { MockPADriver } from "@factur-e/shared-fakes";

import { runPollCdarEvents } from "../../../src/jobs/poll-cdar-events.js";
import { MemorySecretStore } from "../../../src/secrets/index.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";
import { seedFullCustomer } from "../../_fixtures/seed-customer.js";

/**
 * Cas #11 — Polling CDAR rattrape les events. Scénario : facture déjà
 * émise et persistée côté Factur-E (avec `pa_invoice_id` mappé), puis
 * la PA SuperPDP émet 3 events `fr:200 → fr:201 → fr:202` (chrono). Le
 * job `runPollCdarEvents` pollue le cursor, persiste les 3 events via
 * `insertCdarEvent` idempotent, UPDATE `invoices.status_current` à la
 * dernière valeur mappée, et écrit 3 audit `pa_polling_caught_missed_event`.
 *
 * Cf. ADR-009 D1 fail-safe + D4 idempotence + ADR-010 v2 D4 cursor
 * Stripe-like + ADR-012 D2 enum 17 valeurs.
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)(
  "[cycle-de-vie] runPollCdarEvents rattrape les events post-émission",
  () => {
    let db: TestDb;
    let sql: postgres.Sql;
    let secrets: MemorySecretStore;
    let driver: MockPADriver;

    beforeAll(async () => {
      const setup = await setupTestDb();
      if (setup === null) throw new Error("TEST_POSTGRES_URL required");
      db = setup;
      sql = postgres(db.url, { max: 5, onnotice: () => undefined });
      secrets = new MemorySecretStore();
      driver = new MockPADriver();
    });

    afterAll(async () => {
      await sql.end();
      await db.drop();
    });

    beforeEach(async () => {
      await db.resetAuthTables();
      driver.reset();
    });

    it("3 events fr:* injectés → 3 insertCdarEvent + UPDATE status_current + audit caught x3", async () => {
      const seed = await seedFullCustomer(sql, { secretStore: secrets });
      // Pré-poser une invoice avec pa_invoice_id="42" (simule l'état
      // post-`POST /api/invoices` happy path).
      const invoiceRows = await sql<{ id: string }[]>`
      INSERT INTO invoices (
        customer_id, number, issue_date, tracking_id, sha256,
        total_ht, total_vat, total_ttc, currency, processing_rule,
        type_code, pa_invoice_id, status_current
      ) VALUES (
        ${seed.customerId}, 'F-2026-0001', '2026-05-16',
        ${"33333333-3333-4333-8333-333333333333"},
        ${"a".repeat(64)},
        '500.00', '100.00', '600.00', 'EUR', 'B2B',
        '380', '42', 'submitted'
      ) RETURNING id
    `;
      const invoiceId = invoiceRows[0]?.id ?? "";

      // Seed la séquence d'events que MockPADriver va retourner sur le
      // prochain pollCdarEvents (FIFO queue).
      const events: CdarEvent[] = [
        {
          paEventId: "100",
          paInvoiceId: "42",
          rawStatusCode: "fr:200",
          status: "validated",
          occurredAt: "2026-05-16T10:00:00Z",
        },
        {
          paEventId: "101",
          paInvoiceId: "42",
          rawStatusCode: "fr:201",
          status: "transmitting",
          occurredAt: "2026-05-16T10:01:00Z",
        },
        {
          paEventId: "102",
          paInvoiceId: "42",
          rawStatusCode: "fr:202",
          status: "received",
          occurredAt: "2026-05-16T10:02:00Z",
        },
      ];
      driver.seedCdarEvents(events);

      const result = await runPollCdarEvents({ sql, driver, secrets });
      expect(result.skipped).toBe(false);
      expect(result.customersScanned).toBe(1);
      expect(result.events_inserted).toBe(3);
      expect(result.errors).toBe(0);

      // 3 cdar_events persistés source='polling'.
      const persisted = await sql<{ code: string; source: string }[]>`
      SELECT code, source FROM cdar_events WHERE invoice_id = ${invoiceId}
      ORDER BY occurred_at ASC
    `;
      expect(persisted).toHaveLength(3);
      expect(persisted.map((e) => e.code)).toEqual(["fr:200", "fr:201", "fr:202"]);
      expect(persisted.every((e) => e.source === "polling")).toBe(true);

      // UPDATE invoices.status_current à la dernière valeur mappée (received).
      const inv = await sql<{ status_current: string }[]>`
      SELECT status_current FROM invoices WHERE id = ${invoiceId}
    `;
      expect(inv[0]?.status_current).toBe("received");

      // 3 audit pa_polling_caught_missed_event.
      const audits = await sql<{ event_type: string }[]>`
      SELECT event_type FROM auth_audit WHERE customer_id = ${seed.customerId}
    `;
      const caught = audits.filter((a) => a.event_type === "pa_polling_caught_missed_event");
      expect(caught).toHaveLength(3);

      // Cursor avancé à "102".
      const cursor = await sql<{ cursor: string }[]>`
      SELECT cursor FROM pa_polling_state
      WHERE customer_id = ${seed.customerId} AND provider = 'superpdp'
    `;
      expect(cursor[0]?.cursor).toBe("102");
    });

    it("event pour pa_invoice_id inconnu → audit pa_polling_event_unknown_invoice (pas d'insert)", async () => {
      const seed = await seedFullCustomer(sql, { secretStore: secrets });
      // Pas d'invoice persistée → event routé vers "ghost".
      driver.seedCdarEvents([
        {
          paEventId: "200",
          paInvoiceId: "ghost-999",
          rawStatusCode: "fr:200",
          status: "validated",
          occurredAt: "2026-05-16T10:00:00Z",
        },
      ]);

      const result = await runPollCdarEvents({ sql, driver, secrets });
      expect(result.events_inserted).toBe(0);

      const audits = await sql<{ event_type: string }[]>`
      SELECT event_type FROM auth_audit WHERE customer_id = ${seed.customerId}
    `;
      expect(audits.some((a) => a.event_type === "pa_polling_event_unknown_invoice")).toBe(true);

      const count = await sql<{ count: string }[]>`
      SELECT COUNT(*)::text AS count FROM cdar_events
    `;
      expect(count[0]?.count).toBe("0");
    });
  },
);
