import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import type { CdarEvent } from "@factur-e/pa-adapter";
import { MockPADriver } from "@factur-e/shared-fakes";

import { findIncomingCdarEventsByReceivedInvoiceId } from "../../../src/db/repos/incoming_cdar_events.js";
import { insertReceivedInvoice } from "../../../src/db/repos/received_invoices.js";
import { runPollCdarEvents } from "../../../src/jobs/poll-cdar-events.js";
import { MemorySecretStore } from "../../../src/secrets/index.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";
import { seedFullCustomer } from "../../_fixtures/seed-customer.js";

/**
 * V2 routing entrant (ADR-020 D6 / ADR-022 ZG-4, T-CL-CDAR-CAPABILITY-V2).
 *
 * Le feed global `invoice_events` (lu par `poll-cdar-events`) porte aussi les
 * events des factures REÇUES — jusqu'ici droppés en `unknown_invoice`. On
 * vérifie : routing vers `incoming_cdar_events` + `status_current`, scoping
 * tenant (2 customers même `pa_invoice_id_in`), exclusion annulation (209/220,
 * possédée par poll-received-invoices), idempotence. Gated Postgres.
 */
const enabled = Boolean(process.env.TEST_POSTGRES_URL);

function recvEvent(over: Partial<CdarEvent> & { paInvoiceId: string }): CdarEvent {
  return {
    paEventId: "1",
    rawStatusCode: "fr:205",
    status: "accepted_business",
    occurredAt: "2026-06-01T10:00:00Z",
    ...over,
  };
}

describe.skipIf(!enabled)("[cycle-de-vie] V2 routing entrant — factures reçues", () => {
  let db: TestDb;
  let sql: postgres.Sql;
  let secrets: MemorySecretStore;
  let driver: MockPADriver;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 5, onnotice: () => undefined });
    secrets = new MemorySecretStore();
    driver = new MockPADriver();
  });

  afterAll(async () => {
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    driver.reset();
  });

  it("event lifecycle (fr:205) d'une facture REÇUE → routé (timeline + statut), pas droppé", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const recv = await insertReceivedInvoice(sql, {
      customer_id: seed.customerId,
      pa_invoice_id_in: "recv-100",
      seller_siren: "111111111",
      status_current: "in_process",
    });
    if (recv === null) throw new Error("received invoice seed failed");

    driver.seedCdarEvents([recvEvent({ paInvoiceId: "recv-100", paEventId: "500" })]);

    const result = await runPollCdarEvents({ sql, driver, secrets });
    expect(result.received_events_routed).toBe(1);
    expect(result.events_inserted).toBe(0); // pas une facture émise
    expect(result.errors).toBe(0);

    // Timeline reçue (source 'polling') + statut appliqué.
    const events = await findIncomingCdarEventsByReceivedInvoiceId(sql, recv.id);
    expect(events.map((e) => e.code)).toEqual(["fr:205"]);
    expect(events[0]?.source).toBe("polling");
    const row = await sql<{ status_current: string }[]>`
      SELECT status_current FROM received_invoices WHERE id = ${recv.id}
    `;
    expect(row[0]?.status_current).toBe("accepted_business");

    // Audit routed présent, unknown_invoice ABSENT (facture connue).
    const audits = await sql<{ event_type: string }[]>`
      SELECT event_type FROM auth_audit WHERE customer_id = ${seed.customerId}
    `;
    const types = audits.map((a) => a.event_type);
    expect(types).toContain("pa_polling_received_event_routed");
    expect(types).not.toContain("pa_polling_event_unknown_invoice");
  });

  it("tenant-scoping : 2 customers même pa_invoice_id_in → seul le tenant pollé est touché", async () => {
    // Customer A connecté (pollé) + customer B isolé (pas de connexion PA).
    const a = await seedFullCustomer(sql, { secretStore: secrets });
    const b = await seedFullCustomer(sql, { withPaConnection: false });

    const recvA = await insertReceivedInvoice(sql, {
      customer_id: a.customerId,
      pa_invoice_id_in: "SHARED-1",
      seller_siren: "111111111",
      status_current: "in_process",
    });
    const recvB = await insertReceivedInvoice(sql, {
      customer_id: b.customerId,
      pa_invoice_id_in: "SHARED-1", // MÊME id externe (compte PA partagé)
      seller_siren: "111111111",
      status_current: "in_process",
    });
    if (recvA === null || recvB === null) throw new Error("received invoice seed failed");

    driver.seedCdarEvents([recvEvent({ paInvoiceId: "SHARED-1", paEventId: "600" })]);

    const result = await runPollCdarEvents({ sql, driver, secrets });
    expect(result.received_events_routed).toBe(1);

    // A (pollé) muté ; B (autre tenant) intact — pas de fuite cross-tenant.
    const rows = await sql<{ id: string; status_current: string }[]>`
      SELECT id, status_current FROM received_invoices WHERE id IN (${recvA.id}, ${recvB.id})
    `;
    const byId = new Map(rows.map((r) => [r.id, r.status_current]));
    expect(byId.get(recvA.id)).toBe("accepted_business");
    expect(byId.get(recvB.id)).toBe("in_process");

    const eventsB = await findIncomingCdarEventsByReceivedInvoiceId(sql, recvB.id);
    expect(eventsB).toHaveLength(0);
  });

  it("annulation entrante (fr:209) NON routée par V2 (déléguée à maybeIngestCancellation)", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const recv = await insertReceivedInvoice(sql, {
      customer_id: seed.customerId,
      pa_invoice_id_in: "recv-209",
      seller_siren: "111111111",
      status_current: "in_process",
    });
    if (recv === null) throw new Error("received invoice seed failed");

    // fr:209 polled (source pa) → info_complete côté mapping, mais V2 exclut
    // 209/220 du routing (annulation possédée par poll-received-invoices).
    driver.seedCdarEvents([
      recvEvent({ paInvoiceId: "recv-209", rawStatusCode: "fr:209", status: "info_complete" }),
    ]);

    const result = await runPollCdarEvents({ sql, driver, secrets });
    expect(result.received_events_routed).toBe(0);
    expect(result.events_inserted).toBe(0);

    // Facture connue → PAS d'unknown_invoice ; statut + timeline intacts.
    const audits = await sql<{ event_type: string }[]>`
      SELECT event_type FROM auth_audit WHERE customer_id = ${seed.customerId}
    `;
    expect(audits.map((a) => a.event_type)).not.toContain("pa_polling_event_unknown_invoice");
    const events = await findIncomingCdarEventsByReceivedInvoiceId(sql, recv.id);
    expect(events).toHaveLength(0);
    const row = await sql<{ status_current: string }[]>`
      SELECT status_current FROM received_invoices WHERE id = ${recv.id}
    `;
    expect(row[0]?.status_current).toBe("in_process");
  });

  it("idempotence : re-rejouer le même event → 0 nouveau routage (ON CONFLICT)", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const recv = await insertReceivedInvoice(sql, {
      customer_id: seed.customerId,
      pa_invoice_id_in: "recv-idem",
      seller_siren: "111111111",
      status_current: "in_process",
    });
    if (recv === null) throw new Error("received invoice seed failed");

    const ev = recvEvent({ paInvoiceId: "recv-idem", paEventId: "700" });
    driver.seedCdarEvents([ev]);
    const tick1 = await runPollCdarEvents({ sql, driver, secrets });
    expect(tick1.received_events_routed).toBe(1);

    driver.seedCdarEvents([ev]);
    const tick2 = await runPollCdarEvents({ sql, driver, secrets });
    expect(tick2.received_events_routed).toBe(0);

    const events = await findIncomingCdarEventsByReceivedInvoiceId(sql, recv.id);
    expect(events).toHaveLength(1);
  });

  it("event d'un pa_invoice_id totalement inconnu → unknown_invoice (aucun des 2 lookups)", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    driver.seedCdarEvents([recvEvent({ paInvoiceId: "ghost-xyz", paEventId: "800" })]);

    const result = await runPollCdarEvents({ sql, driver, secrets });
    expect(result.received_events_routed).toBe(0);
    expect(result.events_inserted).toBe(0);
    const audits = await sql<{ event_type: string }[]>`
      SELECT event_type FROM auth_audit WHERE customer_id = ${seed.customerId}
    `;
    expect(audits.map((a) => a.event_type)).toContain("pa_polling_event_unknown_invoice");
  });
});
