import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import type { CdarEvent } from "@factur-e/pa-adapter";
import { MockPADriver } from "@factur-e/shared-fakes";

import { runPollCdarEvents } from "../../../src/jobs/poll-cdar-events.js";
import { MemorySecretStore } from "../../../src/secrets/index.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";
import { seedFullCustomer } from "../../_fixtures/seed-customer.js";

/**
 * Cas #12 — Idempotence polling : si le même event arrive deux fois
 * (race condition typique webhook/polling) ou si on rejoue le même
 * batch, UNIQUE `(invoice_id, code, occurred_at)` + `ON CONFLICT DO
 * NOTHING` garantissent que la 2e insertion est ignorée. Le second tick
 * polling avec MEME cursor ne crée pas de doublons.
 *
 * Cf. ADR-009 D4 idempotence + repo `cdar_events.insertCdarEvent.inserted`.
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("[cycle-de-vie] polling idempotence ADR-009 D4", () => {
  let db: TestDb;
  let sql: postgres.Sql;
  let secrets: MemorySecretStore;
  let driver: MockPADriver;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 5, onnotice: () => undefined });
    secrets = new MemorySecretStore();
    driver = new MockPADriver();
  });

  afterAll(async () => {
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    driver.reset();
  });

  it("2 ticks avec le MEME event → 1 INSERT + 1 DUPLICATE ignoré (ON CONFLICT DO NOTHING)", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const invRows = await sql<{ id: string }[]>`
      INSERT INTO invoices (
        customer_id, number, issue_date, tracking_id, sha256,
        total_ht, total_vat, total_ttc, currency, processing_rule,
        type_code, pa_invoice_id, status_current
      ) VALUES (
        ${seed.customerId}, 'F-2026-DUP', '2026-05-16',
        ${"44444444-4444-4444-8444-444444444444"},
        ${"b".repeat(64)},
        '100.00', '20.00', '120.00', 'EUR', 'B2B',
        '380', '99', 'submitted'
      ) RETURNING id
    `;
    const invoiceId = invRows[0]?.id ?? "";

    const evt: CdarEvent = {
      paEventId: "555",
      paInvoiceId: "99",
      rawStatusCode: "fr:200",
      status: "validated",
      occurredAt: "2026-05-16T12:00:00Z",
    };
    driver.seedCdarEvents([evt]);

    // Tick 1 — insert effectif.
    const tick1 = await runPollCdarEvents({ sql, driver, secrets });
    expect(tick1.events_inserted).toBe(1);

    // Force le cursor à reculer pour simuler une réception du MEME
    // event au prochain tick (cas réel : webhook avait rattrapé, polling
    // rejoue avant que le cursor avance — protégé par ON CONFLICT).
    await sql`
      UPDATE pa_polling_state SET cursor = '0'
      WHERE customer_id = ${seed.customerId} AND provider = 'superpdp'
    `;
    driver.seedCdarEvents([evt]);

    // Tick 2 — l'event est ré-injecté côté driver, l'INSERT ON CONFLICT
    // DO NOTHING l'absorbe (inserted=false). Le job renvoie
    // events_inserted=0 car le compteur côté job s'incrémente seulement
    // quand insertCdarEvent.inserted === true.
    const tick2 = await runPollCdarEvents({ sql, driver, secrets });
    expect(tick2.events_inserted).toBe(0);

    // BDD : 1 seul cdar_event persisté (idempotence garantie).
    const persisted = await sql<{ count: string }[]>`
      SELECT COUNT(*)::text AS count FROM cdar_events WHERE invoice_id = ${invoiceId}
    `;
    expect(persisted[0]?.count).toBe("1");
  });

  it("polling 2× sans nouveaux events → no-op + pas de doublon audit", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    // Driver ne seed AUCUN event — la queue retourne vide.

    const tick1 = await runPollCdarEvents({ sql, driver, secrets });
    expect(tick1.events_inserted).toBe(0);
    expect(tick1.customersScanned).toBe(1);

    const tick2 = await runPollCdarEvents({ sql, driver, secrets });
    expect(tick2.events_inserted).toBe(0);

    const audits = await sql<{ count: string }[]>`
      SELECT COUNT(*)::text AS count FROM auth_audit WHERE customer_id = ${seed.customerId}
    `;
    expect(audits[0]?.count).toBe("0"); // pas d'audit polling sur ticks no-op.
  });
});
