import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { MockPADriver } from "@factur-e/shared-fakes";

import { runEnrichCustomerPeppolAddress } from "../../src/jobs/enrich-customer-peppol-address.js";
import { MemorySecretStore } from "../../src/secrets/index.js";
import { setupTestDb, type TestDb } from "../helpers/test-db.js";
import { seedFullCustomer } from "../_fixtures/seed-customer.js";

/**
 * T-CL-PA-DIRECTORY-PEPPOL sprint-05 — Tests intégration job
 * `enrich-customer-peppol-address` (background retry post-callback fail).
 *
 *  - Pickup happy : customer NULL → annuaire `found_one_address` → UPDATE +
 *    audit `peppol_address_enriched_via_job`
 *  - Idempotent : 2ème run picks 0 customers (skip si déjà enrolled)
 *  - Pickup retry : `not_found` → bump retry_count + planifier next_retry_at
 *
 *  Multi-replica safe via `pg_try_advisory_lock(43213)` — non testé ici
 *  (test générique advisory lock couvert sprint-04 pattern existant).
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("[enrich-customer-peppol-address] job", () => {
  let db: TestDb;
  let sql: postgres.Sql;
  let secrets: MemorySecretStore;
  let driver: MockPADriver;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 5, onnotice: () => undefined });
    secrets = new MemorySecretStore();
    driver = new MockPADriver();
  });

  afterAll(async () => {
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    driver.reset();
  });

  it("enrichit customer NULL → annuaire `found_one_address` → UPDATE + audit", async () => {
    const seed = await seedFullCustomer(sql, {
      secretStore: secrets,
      withDirectoryAddress: false,
    });
    // Adresse propre résolue via `directory_entries` (authentifié) — le job
    // lit le token depuis la pa_connection seedée (secretStore).
    driver.setOwnPeppolAddress(`0225:${seed.siren}_via_job`);

    const result = await runEnrichCustomerPeppolAddress({ sql, driver, secrets });
    expect(result.skipped).toBe(false);
    expect(result.enriched).toBe(1);
    expect(result.givenup).toBe(0);

    const dbRow = await sql<{ directory_address: string }[]>`
      SELECT directory_address FROM customers WHERE id = ${seed.customerId}
    `;
    expect(dbRow[0]?.directory_address).toBe(`0225:${seed.siren}_via_job`);

    const audits = await sql<{ event_type: string }[]>`
      SELECT event_type FROM auth_audit WHERE customer_id = ${seed.customerId}
    `;
    expect(audits.map((a) => a.event_type)).toContain("peppol_address_enriched_via_job");
  });

  it("2ème run idempotent — skip customer déjà enrolled", async () => {
    const seed = await seedFullCustomer(sql, {
      secretStore: secrets,
      peppolAddress: "0225:315143296_already_enrolled",
    });
    // Déjà enrolled (directory_address `0225:%`) → non sélectionné par le
    // job (scanned 0), peu importe ce que retournerait l'annuaire.
    driver.setOwnPeppolAddress(`0225:${seed.siren}_should_not_apply`);

    const result = await runEnrichCustomerPeppolAddress({ sql, driver, secrets });
    expect(result.scanned).toBe(0);
    expect(result.enriched).toBe(0);

    const dbRow = await sql<{ directory_address: string }[]>`
      SELECT directory_address FROM customers WHERE id = ${seed.customerId}
    `;
    expect(dbRow[0]?.directory_address).toBe("0225:315143296_already_enrolled");
  });

  it("not_found → bump retry_count + planifier next_retry_at", async () => {
    const seed = await seedFullCustomer(sql, {
      secretStore: secrets,
      withDirectoryAddress: false,
    });
    // Pas de setOwnPeppolAddress → MockPADriver.getOwnDirectoryEntries
    // retourne `not_found`.

    const result = await runEnrichCustomerPeppolAddress({ sql, driver, secrets });
    expect(result.enriched).toBe(0);
    expect(result.givenup).toBe(0);

    const dbRow = await sql<
      {
        peppol_address_retry_count: number;
        peppol_address_next_retry_at: Date | null;
      }[]
    >`
      SELECT peppol_address_retry_count, peppol_address_next_retry_at
      FROM customers WHERE id = ${seed.customerId}
    `;
    expect(dbRow[0]?.peppol_address_retry_count).toBe(1);
    expect(dbRow[0]?.peppol_address_next_retry_at).not.toBeNull();
  });
});
