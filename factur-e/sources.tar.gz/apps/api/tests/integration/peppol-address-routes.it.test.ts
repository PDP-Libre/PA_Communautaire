import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { MockPADriver } from "@factur-e/shared-fakes";

import { MemorySecretStore } from "../../src/secrets/index.js";
import { buildTestApp, type TestApp } from "../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../helpers/test-db.js";
import { seedFullCustomer } from "../_fixtures/seed-customer.js";

/**
 * T-CL-PA-DIRECTORY-PEPPOL sprint-05 — Tests intégration HTTP routes
 * `GET /customers/me/peppol-address` + `POST /customers/me/peppol-address/refresh`.
 *
 * Couvre :
 *  - GET happy path (customer enrolled `0225:...`)
 *  - GET 401 anon
 *  - POST refresh happy path (annuaire `found_one_address` → UPDATE + audit)
 *  - POST refresh not_found (audit `peppol_address_not_enrolled_yet`,
 *    pas d'UPDATE, ADR-009 D2 fail-safe non-blocking)
 *
 * Pattern HTTP : `buildTestApp` + `fetch` natif (cf. `docs/guides/test-ci.md`).
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("[peppol-address] routes `/customers/me/peppol-address`", () => {
  let db: TestDb;
  let sql: postgres.Sql;
  let secrets: MemorySecretStore;
  let driver: MockPADriver;
  let app: TestApp;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 5, onnotice: () => undefined });
    secrets = new MemorySecretStore();
    driver = new MockPADriver();
    app = await buildTestApp({
      connectionString: db.url,
      paDriver: driver,
      secretStore: secrets,
    });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    driver.reset();
  });

  it("GET 401 sans bearer", async () => {
    const res = await fetch(`${app.url}/customers/me/peppol-address`);
    expect(res.status).toBe(401);
  });

  it("GET happy path — customer enrolled `0225:...`", async () => {
    const seed = await seedFullCustomer(sql, {
      secretStore: secrets,
      peppolAddress: "0225:315143296_3686",
    });
    const res = await fetch(`${app.url}/customers/me/peppol-address`, {
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    expect(res.status).toBe(200);
    const body = (await res.json()) as {
      directory_address: string;
      status: string;
      retry_count: number;
    };
    expect(body.directory_address).toBe("0225:315143296_3686");
    expect(body.status).toBe("enrolled");
    expect(body.retry_count).toBe(0);
  });

  it("GET pending — directory_address NULL", async () => {
    const seed = await seedFullCustomer(sql, {
      secretStore: secrets,
      withDirectoryAddress: false,
    });
    const res = await fetch(`${app.url}/customers/me/peppol-address`, {
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    expect(res.status).toBe(200);
    const body = (await res.json()) as { status: string };
    expect(body.status).toBe("pending");
  });

  it("POST refresh happy path — annuaire `found_one_address` → UPDATE + audit", async () => {
    const seed = await seedFullCustomer(sql, {
      secretStore: secrets,
      withDirectoryAddress: false,
    });
    // Adresse propre via directory_entries (authentifié) — token PA lu via
    // la pa_connection seedée (secretStore).
    driver.setOwnPeppolAddress(`0225:${seed.siren}_v1`);

    const res = await fetch(`${app.url}/customers/me/peppol-address/refresh`, {
      method: "POST",
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    expect(res.status).toBe(200);
    const body = (await res.json()) as { directory_address: string; status: string };
    expect(body.directory_address).toBe(`0225:${seed.siren}_v1`);
    expect(body.status).toBe("enrolled");

    const dbRow = await sql<{ directory_address: string }[]>`
      SELECT directory_address FROM customers WHERE id = ${seed.customerId}
    `;
    expect(dbRow[0]?.directory_address).toBe(`0225:${seed.siren}_v1`);

    const audits = await sql<{ event_type: string }[]>`
      SELECT event_type FROM auth_audit WHERE customer_id = ${seed.customerId}
    `;
    expect(audits.map((a) => a.event_type)).toContain("peppol_address_refreshed");
  });

  it("POST refresh not_found — pas d'UPDATE + audit `peppol_address_not_enrolled_yet`", async () => {
    const seed = await seedFullCustomer(sql, {
      secretStore: secrets,
      withDirectoryAddress: false,
    });
    // Pas de setOwnPeppolAddress → MockPADriver.getOwnDirectoryEntries
    // retourne `not_found`.

    const res = await fetch(`${app.url}/customers/me/peppol-address/refresh`, {
      method: "POST",
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    expect(res.status).toBe(200);
    const body = (await res.json()) as { status: string };
    expect(body.status).toBe("pending");

    const dbRow = await sql<{ directory_address: string | null }[]>`
      SELECT directory_address FROM customers WHERE id = ${seed.customerId}
    `;
    expect(dbRow[0]?.directory_address).toBeNull();

    const audits = await sql<{ event_type: string }[]>`
      SELECT event_type FROM auth_audit WHERE customer_id = ${seed.customerId}
    `;
    expect(audits.map((a) => a.event_type)).toContain("peppol_address_not_enrolled_yet");
  });
});
