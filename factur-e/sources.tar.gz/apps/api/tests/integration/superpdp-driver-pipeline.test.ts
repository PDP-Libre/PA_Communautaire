import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import {
  InvoiceRejectedXsdException,
  PaAccessTokenExpiredException,
  SuperPDPDriver,
  type CustomerContext,
} from "@factur-e/pa-adapter";
import { startFakeSuperPdp, type FakeSuperPdp } from "@factur-e/shared-fakes";

/**
 * T-CL-PA-INVOICE-FIX sprint-04 — Tests `SuperPDPDriver` pipeline facture
 * refactor (ADR-010 v2 D3 + D4 + D5).
 *
 * Couvre :
 *  - submitInvoice happy path (POST /v1.beta/invoices body PDF + external_id)
 *  - submitInvoice 400 Seller.ElectronicAddress → InvoiceRejectedXsdException
 *  - submitInvoice 5xx retry then OK
 *  - submitInvoice 401 → PaAccessTokenExpiredException
 *  - pollCdarEvents happy path (cursor Stripe-like)
 *  - pollCdarEvents has_after pagination
 */

const CTX: CustomerContext = {
  customerId: "c-test",
  credentials: {
    kind: "superpdp-oauth-ac",
    accessToken: "a-test",
    refreshToken: "r-test",
    accessExpiresAt: new Date(Date.now() + 1800 * 1000),
    paUserId: null,
  },
};

describe("SuperPDPDriver — pipeline facture (ADR-010 v2 D3+D4)", () => {
  let fake: FakeSuperPdp;
  let driver: SuperPDPDriver;

  beforeAll(async () => {
    fake = await startFakeSuperPdp({});
    driver = new SuperPDPDriver({
      clientId: "test",
      clientSecret: "secret",
      baseUrl: fake.baseUrl,
      retryOptions: { sleep: () => Promise.resolve(), backoffMs: [0, 0] },
    });
  });

  afterAll(async () => {
    await fake.stop();
  });

  beforeEach(() => {
    fake.reset();
  });

  it("submitInvoice happy path → POST /v1.beta/invoices + parse invoice", async () => {
    fake.preassignNextPaInvoiceId(42);
    const result = await driver.submitInvoice(
      {
        pdfBytes: Buffer.from("%PDF-1.4 fake"),
        trackingId: "0192a82e-7c0a-7000-8000-000000000001",
        sha256: "x".repeat(64),
        processingRule: "B2B",
        profile: "EXTENDED",
        invoiceNumber: "F-2026-0001",
        recipientPeppolId: "0225:987654321",
        senderPeppolId: "0225:123456789",
      },
      CTX,
    );
    expect(result.paInvoiceId).toBe("42");
    expect(result.status).toBe("submitted");
    expect(result.rawStatusCode).toBe("api:uploaded");
    expect(result.submittedAt).toBeInstanceOf(Date);
    expect(fake.getSubmitRequestCount()).toBe(1);
  });

  it("submitInvoice 400 Seller.ElectronicAddress → InvoiceRejectedXsdException", async () => {
    fake.setScenario("submit_400_seller_address");
    await expect(
      driver.submitInvoice(
        {
          pdfBytes: Buffer.from("%PDF-1.4 fake"),
          trackingId: "t1",
          sha256: "x".repeat(64),
          processingRule: "B2B",
          profile: "EXTENDED",
          invoiceNumber: "F-001",
          recipientPeppolId: "0225:1",
          senderPeppolId: "0225:2",
        },
        CTX,
      ),
    ).rejects.toThrow(InvoiceRejectedXsdException);
  });

  it("submitInvoice 5xx → retry then OK (ADR-005 D11 préservé)", async () => {
    fake.setScenario("submit_5xx_then_ok");
    fake.preassignNextPaInvoiceId(99);
    const result = await driver.submitInvoice(
      {
        pdfBytes: Buffer.from("%PDF-1.4 fake"),
        trackingId: "t2",
        sha256: "x".repeat(64),
        processingRule: "B2B",
        profile: "EXTENDED",
        invoiceNumber: "F-002",
        recipientPeppolId: "0225:1",
        senderPeppolId: "0225:2",
      },
      CTX,
    );
    expect(result.paInvoiceId).toBe("99");
    expect(fake.getSubmitRequestCount()).toBe(2);
  });

  it("submitInvoice 401 → PaAccessTokenExpiredException", async () => {
    fake.setScenario("submit_401_token_expired");
    await expect(
      driver.submitInvoice(
        {
          pdfBytes: Buffer.from("%PDF-1.4 fake"),
          trackingId: "t3",
          sha256: "x".repeat(64),
          processingRule: "B2B",
          profile: "EXTENDED",
          invoiceNumber: "F-003",
          recipientPeppolId: "0225:1",
          senderPeppolId: "0225:2",
        },
        CTX,
      ),
    ).rejects.toThrow(PaAccessTokenExpiredException);
  });

  it("pollCdarEvents happy path → cursor Stripe-like batch", async () => {
    // Seed 3 events sur 2 invoices distinctes.
    fake.seedInvoiceWithEvents({
      paInvoiceId: "100",
      events: [
        { id: 1, invoice_id: 100, status_code: "api:uploaded", created_at: "2026-05-17T10:00:00Z" },
        { id: 2, invoice_id: 100, status_code: "fr:200", created_at: "2026-05-17T10:01:00Z" },
      ],
    });
    fake.seedInvoiceWithEvents({
      paInvoiceId: "101",
      events: [
        { id: 3, invoice_id: 101, status_code: "fr:201", created_at: "2026-05-17T10:02:00Z" },
      ],
    });
    const result = await driver.pollCdarEvents({ cursor: "0", limit: 100 }, CTX);
    expect(result.events).toHaveLength(3);
    expect(result.events[0]?.paEventId).toBe("1");
    expect(result.events[0]?.status).toBe("submitted");
    expect(result.events[1]?.paEventId).toBe("2");
    expect(result.events[1]?.status).toBe("validated");
    expect(result.events[1]?.paInvoiceId).toBe("100");
    expect(result.events[2]?.paInvoiceId).toBe("101");
    expect(result.nextCursor).toBe("3");
    expect(result.hasMore).toBe(false);
  });

  it("pollCdarEvents has_after=true → 2 calls successifs avec cursor", async () => {
    // Seed 5 events ; on demande limit=2 → 1ère page = events 1+2,
    // 2e page = events 3+4, 3e page = event 5.
    fake.seedInvoiceWithEvents({
      paInvoiceId: "200",
      events: Array.from({ length: 5 }, (_, i) => ({
        id: i + 1,
        invoice_id: 200,
        status_code: "fr:200",
        created_at: new Date(Date.UTC(2026, 4, 17, 10, i)).toISOString(),
      })),
    });
    const r1 = await driver.pollCdarEvents({ cursor: "0", limit: 2 }, CTX);
    expect(r1.events).toHaveLength(2);
    expect(r1.hasMore).toBe(true);
    expect(r1.nextCursor).toBe("2");

    const r2 = await driver.pollCdarEvents({ cursor: r1.nextCursor, limit: 2 }, CTX);
    expect(r2.events).toHaveLength(2);
    expect(r2.hasMore).toBe(true);
    expect(r2.nextCursor).toBe("4");

    const r3 = await driver.pollCdarEvents({ cursor: r2.nextCursor, limit: 2 }, CTX);
    expect(r3.events).toHaveLength(1);
    expect(r3.hasMore).toBe(false);
    expect(r3.nextCursor).toBe("5");
  });
});
