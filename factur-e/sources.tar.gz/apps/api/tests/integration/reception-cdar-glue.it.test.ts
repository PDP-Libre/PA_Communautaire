import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { getCdarSequence } from "@factur-e/factur-x-fixtures";
import { MockPADriver } from "@factur-e/shared-fakes";

import { findCdarEventsByInvoiceId } from "../../src/db/repos/cdar_events.js";
import { applyCdarSequence } from "../../src/dev-support/reception-fixtures.js";
import { MemorySecretStore } from "../../src/secrets/index.js";
import { buildTestApp, type TestApp } from "../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../helpers/test-db.js";
import { seedInvoiceUser } from "../http/invoices/_helpers.js";

/**
 * CDAR entrants côté ÉMISSION (vue vendeur) — `applyCdarSequence` (rejeu
 * ordonné d'une `IncomingCdarSequence`) + extension `__dev/cdar/inject`
 * (mapSuperPDPStatusCode + reason). Gated Postgres.
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);
const T0 = new Date("2026-06-01T08:00:00.000Z");

describe.skipIf(!enabled)("CDAR entrants — applyCdarSequence + __dev/cdar/inject", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;
  let secrets: MemorySecretStore;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
    secrets = new MemorySecretStore();
    app = await buildTestApp({
      connectionString: db.url,
      paDriver: new MockPADriver(),
      secretStore: secrets,
    });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  async function seedEmittedInvoice(number: string): Promise<string> {
    const user = await seedInvoiceUser(sql, { secretStore: secrets });
    const rows = await sql<{ id: string }[]>`
      INSERT INTO invoices (customer_id, number, issue_date, total_ht, total_vat, total_ttc)
      VALUES (${user.customerId}, ${number}, '2026-06-01', '800', '160', '960')
      RETURNING id
    `;
    return rows[0]?.id ?? "";
  }

  // TODO RECTIF-AFNOR — propagation annulation acheteur, doctrine 209-vs-220
  // non tranchée. Depuis la correction C2 (ADR-022 D5), fr:209 polled (source
  // pa) → info_complete (Complétée), plus cancelled ; le marqueur d'annulation
  // V1a est source `app`. La propagation « origine Annulée côté vendeur »
  // dépend d'un code 220 (gated). Expect fixture conservé, scénario re-câblé
  // par RECTIF-AFNOR (arbitrage Bruno T-CL-CDAR-CAPABILITY-V2).
  it.skip("seq-209-acheteur : 3 jalons rejoués → status_current = cancelled", async () => {
    const invoiceId = await seedEmittedInvoice("FX-380-BASE-001");
    const res = await applyCdarSequence(sql, invoiceId, getCdarSequence("seq-209-acheteur"), T0);
    expect(res.statusCurrent).toBe("cancelled");
    expect(res.insertedCount).toBe(3);

    const events = await findCdarEventsByInvoiceId(sql, invoiceId);
    expect(events.map((e) => e.code)).toEqual(["fr:204", "fr:205", "fr:209"]);
    const status = await sql<{ status_current: string }[]>`
      SELECT status_current FROM invoices WHERE id = ${invoiceId}
    `;
    expect(status[0]?.status_current).toBe("cancelled");
  });

  it("seq-210-motif-code : refus → reason '03' persisté + status refused_business", async () => {
    const invoiceId = await seedEmittedInvoice("FX-380-BASE-001");
    const res = await applyCdarSequence(sql, invoiceId, getCdarSequence("seq-210-motif-code"), T0);
    expect(res.statusCurrent).toBe("refused_business");

    const events = await findCdarEventsByInvoiceId(sql, invoiceId);
    const refusal = events.find((e) => e.code === "fr:210");
    expect(refusal?.reason).toBe("03");
  });

  it("seq-210-motif-autre : reason '11' + texte libre dans payload.data", async () => {
    const invoiceId = await seedEmittedInvoice("FX-380-ADV-RICHE-001");
    await applyCdarSequence(sql, invoiceId, getCdarSequence("seq-210-motif-autre"), T0);
    const events = await findCdarEventsByInvoiceId(sql, invoiceId);
    const refusal = events.find((e) => e.code === "fr:210");
    expect(refusal?.reason).toBe("11");
    expect(refusal?.payload.data).toContain("Conditions tarifaires renégociées");
  });

  it("__dev/cdar/inject étendu : fr:210 + reason → mapStatus + reason persistés", async () => {
    const invoiceId = await seedEmittedInvoice("FX-380-BASE-001");
    const res = await fetch(`${app.url}/__dev/cdar/inject`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        invoice_id: invoiceId,
        code: "fr:210",
        occurred_at: "2026-06-01T09:00:00.000Z",
        reason: { code: "03", text: "Montant erroné sur la ligne 2" },
      }),
    });
    expect(res.status).toBe(200);
    const body = (await res.json()) as { inserted: boolean; status: string };
    expect(body.status).toBe("refused_business");

    const events = await findCdarEventsByInvoiceId(sql, invoiceId);
    const refusal = events.find((e) => e.code === "fr:210");
    expect(refusal?.reason).toBe("03");
    expect(refusal?.payload.data).toBe("Montant erroné sur la ligne 2");
  });
});
