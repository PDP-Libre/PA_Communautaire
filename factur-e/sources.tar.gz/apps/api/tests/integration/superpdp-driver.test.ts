import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import {
  PaInvalidStateException,
  PaUnavailableException,
  RefreshExpiredException,
  SuperPDPDriver,
  deriveS256Challenge,
} from "@factur-e/pa-adapter";
import { startFakeSuperPdp, type FakeSuperPdp } from "@factur-e/shared-fakes";

/**
 * Integration test pa-adapter ↔ fakeSuperPdp. Lives in `apps/api/tests/`
 * to avoid the workspace dep cycle (`pa-adapter` → `shared-fakes` →
 * `pa-adapter` for the new `MockPADriver` types). `apps/api` already
 * has both packages as deps. T-CL-06 sprint-03 — patch trace.md.
 */
describe("SuperPDPDriver — integration against fakeSuperPdp", () => {
  let fake: FakeSuperPdp;
  let driver: SuperPDPDriver;

  beforeAll(async () => {
    fake = await startFakeSuperPdp({ scenario: "verified", paUserId: "pa-user-test" });
    driver = new SuperPDPDriver({
      clientId: "factur-e-test",
      clientSecret: "secret-test",
      baseUrl: fake.baseUrl,
      // Instant retries for tests.
      retryOptions: { sleep: () => Promise.resolve(), backoffMs: [0, 0] },
    });
  });

  afterAll(async () => {
    await fake.stop();
  });

  beforeEach(() => {
    fake.reset();
    fake.setScenario("verified");
  });

  it("authorize() builds a valid URL with PKCE S256 + state + challenge", async () => {
    const challenge = await driver.authorize({
      customerId: "cust-1",
      redirectUri: "http://localhost:3001/oauth/superpdp/callback",
    });
    expect(challenge.authorizeUrl).toMatch(/\/oauth2\/authorize\?/);
    expect(challenge.state).toMatch(/^[A-Za-z0-9_-]+$/);
    expect(challenge.codeVerifier).toMatch(/^[A-Za-z0-9_-]+$/);
    // Server-side, the URL must carry the SHA-256 of the verifier.
    const url = new URL(challenge.authorizeUrl);
    expect(url.searchParams.get("code_challenge")).toBe(
      deriveS256Challenge(challenge.codeVerifier),
    );
    expect(url.searchParams.get("code_challenge_method")).toBe("S256");
    expect(url.searchParams.get("state")).toBe(challenge.state);
    expect(url.searchParams.get("client_id")).toBe("factur-e-test");
    expect(url.searchParams.has("scope")).toBe(false);
  });

  it("exchangeCode() returns tokens (paUserId null per spec) on happy path", async () => {
    const tokens = await driver.exchangeCode({
      code: "code-1",
      state: "s",
      expectedState: "s",
      codeVerifier: "v-fixture",
      redirectUri: "http://localhost:3001/oauth/superpdp/callback",
    });
    expect(tokens.accessToken).toBe("a-code-1");
    expect(tokens.refreshToken).toMatch(/^r-code-1-/);
    // Spec SuperPDP `oauth2_session` n'expose pas d'id user — paUserId
    // toujours null sur ce driver (patch T-CL-08 smoke 11 mai 2026).
    expect(tokens.paUserId).toBeNull();
    expect(tokens.accessExpiresAt.getTime()).toBeGreaterThan(Date.now());
  });

  it("exchangeCode() throws PaInvalidStateException on state mismatch", async () => {
    await expect(
      driver.exchangeCode({
        code: "code-2",
        state: "s",
        expectedState: "different",
        codeVerifier: "v",
        redirectUri: "http://localhost:3001/oauth/superpdp/callback",
      }),
    ).rejects.toBeInstanceOf(PaInvalidStateException);
  });

  it("refreshToken() rotates tokens on success", async () => {
    const initial = await driver.exchangeCode({
      code: "code-r",
      state: "s",
      expectedState: "s",
      codeVerifier: "v",
      redirectUri: "http://localhost:3001/oauth/superpdp/callback",
    });
    const refreshed = await driver.refreshToken({ refreshToken: initial.refreshToken });
    expect(refreshed.accessToken).not.toBe(initial.accessToken);
    expect(refreshed.refreshToken).not.toBe(initial.refreshToken);
    // Old refresh is now consumed — re-using it raises invalid_grant
    // -> RefreshExpiredException.
    await expect(
      driver.refreshToken({ refreshToken: initial.refreshToken }),
    ).rejects.toBeInstanceOf(RefreshExpiredException);
  });

  it("refreshToken() maps invalid_grant to RefreshExpiredException (rotation imposed)", async () => {
    fake.setScenario("invalid_grant");
    await expect(driver.refreshToken({ refreshToken: "anything" })).rejects.toBeInstanceOf(
      RefreshExpiredException,
    );
  });

  it("revoke() returns void on RFC 7009 200 (idempotent)", async () => {
    await expect(driver.revoke({ refreshToken: "any" })).resolves.toBeUndefined();
  });

  it("getIdentityStatus() returns verified on happy path", async () => {
    const tokens = await driver.exchangeCode({
      code: "code-id",
      state: "s",
      expectedState: "s",
      codeVerifier: "v",
      redirectUri: "http://localhost:3001/oauth/superpdp/callback",
    });
    const id = await driver.getIdentityStatus({ accessToken: tokens.accessToken });
    expect(id.user).toBe("verified");
    expect(id.company).toBe("verified");
    // Spec SuperPDP — pas d'id user dans la réponse.
    expect(id.paUserId).toBeNull();
  });

  it("getIdentityStatus() returns needs_review on the asynchronous-KYC scenario", async () => {
    fake.setScenario("needs_review");
    const tokens = await driver.exchangeCode({
      code: "code-nr",
      state: "s",
      expectedState: "s",
      codeVerifier: "v",
      redirectUri: "http://localhost:3001/oauth/superpdp/callback",
    });
    const id = await driver.getIdentityStatus({ accessToken: tokens.accessToken });
    expect(id.user).toBe("needs_review");
    expect(id.company).toBe("verified");
  });

  it("retries on 5xx then succeeds (workaround sandbox 500 — ADR-005 D11)", async () => {
    fake.setScenario("5xx_then_ok");
    const tokens = await driver.exchangeCode({
      code: "code-retry",
      state: "s",
      expectedState: "s",
      codeVerifier: "v",
      redirectUri: "http://localhost:3001/oauth/superpdp/callback",
    });
    expect(tokens.accessToken).toBe("a-code-retry");
    // 1 initial 500 + 1 retry success = 2 token requests minimum.
    expect(fake.getTokenRequestCount()).toBeGreaterThanOrEqual(2);
  });

  it("throws PaUnavailableException when 5xx persists past retry budget", async () => {
    // Build a driver pointed at a fake that always returns 500 on token.
    // We model it by injecting a fetch that always 500s.
    const always500: typeof globalThis.fetch = () =>
      Promise.resolve(
        new Response(JSON.stringify({ error: "server_error" }), {
          status: 500,
          headers: { "content-type": "application/json" },
        }),
      );
    const angryDriver = new SuperPDPDriver({
      clientId: "x",
      clientSecret: "y",
      baseUrl: fake.baseUrl,
      fetch: always500,
      retryOptions: { sleep: () => Promise.resolve(), backoffMs: [0, 0], maxRetries: 2 },
    });
    await expect(
      angryDriver.exchangeCode({
        code: "code-down",
        state: "s",
        expectedState: "s",
        codeVerifier: "v",
        redirectUri: "http://localhost:3001/oauth/superpdp/callback",
      }),
    ).rejects.toBeInstanceOf(PaUnavailableException);
  });

  it("authorize URL roundtrip — fakeSuperPdp accepts the challenge", async () => {
    // Cross-verify that what the driver builds is what the fake accepts.
    const challenge = await driver.authorize({
      customerId: "cust-r",
      redirectUri: "http://localhost:3001/oauth/superpdp/callback",
    });
    const res = await fetch(challenge.authorizeUrl);
    expect(res.status).toBe(200);
    const body = (await res.json()) as Record<string, unknown>;
    expect(body.echoed_state).toBe(challenge.state);
    expect(body.echoed_challenge).toBe(deriveS256Challenge(challenge.codeVerifier));
  });
});
