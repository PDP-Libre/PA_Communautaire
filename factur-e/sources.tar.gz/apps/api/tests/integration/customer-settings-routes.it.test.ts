import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { MockPADriver } from "@factur-e/shared-fakes";

import { MemorySecretStore } from "../../src/secrets/index.js";
import { buildTestApp, type TestApp } from "../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../helpers/test-db.js";
import { seedFullCustomer } from "../_fixtures/seed-customer.js";

/**
 * T-CL-WEB-SETTINGS-ENTREPRISE-V1 sprint-05 — Tests intégration HTTP
 * routes `GET /customers/me/settings` + `PATCH /customers/me/settings`.
 *
 * Couvre :
 *  - GET happy path (consolidé : INSEE + 3 champs nouveaux exposés)
 *  - GET 401 sans bearer
 *  - PATCH happy path partial update (vat_number seul)
 *  - PATCH happy path multi-champs (3 champs simultanés + audit)
 *  - PATCH 403 rôle non-Full (`deposit_simple`)
 *  - PATCH 400 Zod invalide (vat_number format incorrect)
 *  - PATCH 400 Zod body vide (refine `Object.keys.length > 0`)
 *  - PATCH idempotence (même PATCH 2x → 204 + audit émis 2x)
 *
 * Pattern HTTP : `buildTestApp` + `fetch` natif (cf. `docs/guides/test-ci.md`).
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("[customer-settings] routes `/customers/me/settings`", () => {
  let db: TestDb;
  let sql: postgres.Sql;
  let secrets: MemorySecretStore;
  let driver: MockPADriver;
  let app: TestApp;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 5, onnotice: () => undefined });
    secrets = new MemorySecretStore();
    driver = new MockPADriver();
    app = await buildTestApp({
      connectionString: db.url,
      paDriver: driver,
      secretStore: secrets,
    });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    driver.reset();
  });

  // ─── GET ─────────────────────────────────────────────────────────

  it("GET 401 sans bearer", async () => {
    const res = await fetch(`${app.url}/customers/me/settings`);
    expect(res.status).toBe(401);
  });

  it("GET happy path — vue consolidée INSEE + champs entreprise", async () => {
    const seed = await seedFullCustomer(sql, {
      secretStore: secrets,
      peppolAddress: "0225:315143296_3686",
    });
    const res = await fetch(`${app.url}/customers/me/settings`, {
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    expect(res.status).toBe(200);
    const body = (await res.json()) as {
      siren: string;
      legal_name: string;
      vat_number: string | null;
      has_iban: boolean;
      iban_display: string | null;
      bic: string | null;
      primary_color: string;
      vat_on_encashment: boolean;
      ui_mode_default: "basic" | "advanced";
      directory_address: string | null;
      logo_url: string | null;
    };
    expect(body.siren).toBe(seed.siren);
    expect(body.vat_number).toBe("FR12345678901");
    expect(body.has_iban).toBe(true);
    // NC-3 : IBAN masqué (jamais en clair) — 4 derniers visibles, milieu masqué.
    expect(body.iban_display).not.toBeNull();
    expect(body.iban_display).toContain("••••");
    expect(body.bic).toBe("AGRIFRPP");
    expect(body.primary_color).toMatch(/^#[0-9A-Fa-f]{6}$/);
    expect(body.vat_on_encashment).toBe(false);
    expect(body.ui_mode_default).toBe("basic");
    expect(body.directory_address).toBe("0225:315143296_3686");
    expect(body.logo_url).toBeNull();
  });

  // ─── PATCH ───────────────────────────────────────────────────────

  it("PATCH happy path — vat_number seul (partial update)", async () => {
    const seed = await seedFullCustomer(sql, {
      secretStore: secrets,
      vatNumber: null,
    });
    const res = await fetch(`${app.url}/customers/me/settings`, {
      method: "PATCH",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify({ vat_number: "FR12821456789" }),
    });
    expect(res.status).toBe(204);

    const row = await sql<{ vat_number: string | null }[]>`
      SELECT vat_number FROM customers WHERE id = ${seed.customerId}
    `;
    expect(row[0]?.vat_number).toBe("FR12821456789");

    const audit = await sql<{ event_type: string; metadata: Record<string, unknown> }[]>`
      SELECT event_type, metadata FROM auth_audit
      WHERE user_id = ${seed.userId} AND event_type = 'customer_settings_updated'
    `;
    expect(audit.length).toBe(1);
    expect(audit[0]?.metadata).toMatchObject({ fields_updated: ["vat_number"] });
  });

  it("PATCH vat_number avec espaces et minuscules — normalisé en BDD (followups #2)", async () => {
    const seed = await seedFullCustomer(sql, {
      secretStore: secrets,
      vatNumber: null,
    });
    const res = await fetch(`${app.url}/customers/me/settings`, {
      method: "PATCH",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      // Saisie typique copie depuis doc officiel : "fr 12 821 456 789"
      body: JSON.stringify({ vat_number: "fr 12 821 456 789" }),
    });
    expect(res.status).toBe(204);

    const row = await sql<{ vat_number: string | null }[]>`
      SELECT vat_number FROM customers WHERE id = ${seed.customerId}
    `;
    expect(row[0]?.vat_number).toBe("FR12821456789");
  });

  it("PATCH happy path — 3 champs simultanés", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const res = await fetch(`${app.url}/customers/me/settings`, {
      method: "PATCH",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify({
        vat_number: "FR99821456789",
        vat_on_encashment: true,
        ui_mode_default: "advanced",
      }),
    });
    expect(res.status).toBe(204);

    const row = await sql<
      {
        vat_number: string | null;
        vat_on_encashment: boolean;
        ui_mode_default: string;
      }[]
    >`
      SELECT vat_number, vat_on_encashment, ui_mode_default
      FROM customers WHERE id = ${seed.customerId}
    `;
    expect(row[0]).toEqual({
      vat_number: "FR99821456789",
      vat_on_encashment: true,
      ui_mode_default: "advanced",
    });
  });

  it("PATCH 403 rôle non-Full (`deposit_simple`)", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    await sql`UPDATE users SET role = 'deposit_simple' WHERE id = ${seed.userId}`;
    const res = await fetch(`${app.url}/customers/me/settings`, {
      method: "PATCH",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify({ ui_mode_default: "advanced" }),
    });
    expect(res.status).toBe(403);
  });

  it("PATCH 400 vat_number format invalide — issues détaillées (followups #3)", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const res = await fetch(`${app.url}/customers/me/settings`, {
      method: "PATCH",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify({ vat_number: "INVALID12345" }),
    });
    expect(res.status).toBe(400);
    // NC-15 : enveloppe d'erreur standard — issues Zod à plat sous `issues`
    // (et non plus imbriquées sous `error.issues`).
    const body = (await res.json()) as {
      message: string;
      issues?: { path?: (string | number)[]; message: string; code?: string }[];
    };
    expect(body.message).toBeTruthy();
    expect(body.issues).toBeDefined();
    expect(body.issues?.length).toBeGreaterThan(0);
    const issue = body.issues?.[0];
    expect(issue?.path).toContain("vat_number");
    expect(issue?.message).toMatch(/Format attendu/i);
  });

  it("PATCH 400 body vide (refine Object.keys.length > 0)", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const res = await fetch(`${app.url}/customers/me/settings`, {
      method: "PATCH",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify({}),
    });
    expect(res.status).toBe(400);
  });

  it("PATCH idempotence — même PATCH 2x → 204 + audit émis 2x", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    const body = JSON.stringify({ ui_mode_default: "advanced" });
    const headers = {
      authorization: `Bearer ${seed.bearer}`,
      "content-type": "application/json",
    };
    const r1 = await fetch(`${app.url}/customers/me/settings`, { method: "PATCH", headers, body });
    const r2 = await fetch(`${app.url}/customers/me/settings`, { method: "PATCH", headers, body });
    expect(r1.status).toBe(204);
    expect(r2.status).toBe(204);

    const audit = await sql<{ id: string }[]>`
      SELECT id FROM auth_audit
      WHERE user_id = ${seed.userId} AND event_type = 'customer_settings_updated'
    `;
    expect(audit.length).toBe(2);
  });
});
