import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { getReceptionFixture } from "@factur-e/factur-x-fixtures";

import {
  findIncomingCdarEventsByReceivedInvoiceId,
  insertIncomingCdarEvent,
} from "../../src/db/repos/incoming_cdar_events.js";
import {
  findActiveReceivedInvoicesByCustomerId,
  findReceivedInvoiceByPaInvoiceIdIn,
  findReceivedInvoiceByPrecedingNumber,
  getReceivedInvoiceById,
  insertReceivedInvoice,
  markReceivedInvoiceAsRead,
  markReceivedInvoiceStatus,
  type NewReceivedInvoiceRow,
} from "../../src/db/repos/received_invoices.js";
import { seedFullCustomer } from "../_fixtures/seed-customer.js";
import { setupTestDb, type TestDb } from "../helpers/test-db.js";

/**
 * T-CL-RECV-API sprint-05 W2 — Tests repo `received_invoices` +
 * `incoming_cdar_events` (convention T-CL-01). CRUD + RBAC scope +
 * idempotence ON CONFLICT (ADR-009 D4).
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("[received_invoices] repo", () => {
  let db: TestDb;
  let sql: postgres.Sql;
  let customerId: string;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 5, onnotice: () => undefined });
  });

  afterAll(async () => {
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    const seed = await seedFullCustomer(sql, { withPaConnection: false });
    customerId = seed.customerId;
  });

  // Identité par défaut sourcée du corpus (rx-380-base-facturx : SIREN
  // 000000002 BQ). Les clés de mécanique (`pa-1`, `dup`, `999999999`, …)
  // restent libres — ce test porte le concept REPO (idempotence / scope /
  // filtres), pas le contenu fonctionnel d'un flux (≠ seedReceivedRowFromFixture).
  const RX_BASE = getReceptionFixture("rx-380-base-facturx");
  const newRow = (over: Partial<NewReceivedInvoiceRow> = {}): NewReceivedInvoiceRow => ({
    customer_id: customerId,
    pa_invoice_id_in: over.pa_invoice_id_in ?? "pa-1",
    seller_siren: RX_BASE.expect.row.sellerSiren,
    seller_name_cached: RX_BASE.incoming.enInvoice?.sellerName ?? null,
    supplier_matched: true,
    invoice_number_extracted: "FA-1",
    issue_date: "2026-05-18",
    total_ttc_cents: 120050,
    currency: "EUR",
    status_current: "in_process",
    ...over,
  });

  it("insertReceivedInvoice → retourne la ligne", async () => {
    const row = await insertReceivedInvoice(sql, newRow());
    expect(row).not.toBeNull();
    expect(row?.pa_invoice_id_in).toBe("pa-1");
    expect(row?.total_ttc_cents).toBe(120050);
    expect(row?.status_current).toBe("in_process");
  });

  it("insertReceivedInvoice ON CONFLICT (pa_invoice_id_in) → null (idempotence ADR-009 D4)", async () => {
    const first = await insertReceivedInvoice(sql, newRow({ pa_invoice_id_in: "dup" }));
    expect(first).not.toBeNull();
    const second = await insertReceivedInvoice(sql, newRow({ pa_invoice_id_in: "dup" }));
    expect(second).toBeNull();
  });

  it("insertReceivedInvoice — unicité scopée tenant : 2 customers, même pa_invoice_id_in → 2 lignes (T-CL-HOTFIX-RECV-UNIQUE-TENANT R1)", async () => {
    // Régression du bug latent sprint-05 : deux clients Factur-E partageant un
    // compte SuperPDP reçoivent le même `pa_invoice_id_in`. Avant le fix, la
    // clé UNIQUE globale faisait skip le second (réception partielle).
    const other = await seedFullCustomer(sql, { withPaConnection: false });

    const a = await insertReceivedInvoice(sql, newRow({ pa_invoice_id_in: "shared-superpdp-id" }));
    const b = await insertReceivedInvoice(
      sql,
      newRow({ customer_id: other.customerId, pa_invoice_id_in: "shared-superpdp-id" }),
    );

    expect(a).not.toBeNull();
    expect(b).not.toBeNull();
    expect(a?.customer_id).toBe(customerId);
    expect(b?.customer_id).toBe(other.customerId);
    expect(a?.id).not.toBe(b?.id);

    // Idempotence intra-tenant préservée : même customer + même id → null.
    const dup = await insertReceivedInvoice(
      sql,
      newRow({ pa_invoice_id_in: "shared-superpdp-id" }),
    );
    expect(dup).toBeNull();
  });

  it("insertReceivedInvoice — soft-delete puis ré-insert même clé tenant → OK (index partiel deleted_at IS NULL)", async () => {
    const first = await insertReceivedInvoice(sql, newRow({ pa_invoice_id_in: "recyclable" }));
    expect(first).not.toBeNull();

    // Soft-delete : la ligne sort de l'index partiel (WHERE deleted_at IS NULL).
    await sql`UPDATE received_invoices SET deleted_at = NOW() WHERE id = ${first?.id ?? ""}`;

    // Ré-insert de la même clé (customer_id, pa_invoice_id_in) → autorisé.
    const second = await insertReceivedInvoice(sql, newRow({ pa_invoice_id_in: "recyclable" }));
    expect(second).not.toBeNull();
    expect(second?.id).not.toBe(first?.id);
  });

  it("findReceivedInvoiceByPaInvoiceIdIn — scopé tenant (ne retourne pas la ligne d'un autre client partageant l'id)", async () => {
    const other = await seedFullCustomer(sql, { withPaConnection: false });
    const mine = await insertReceivedInvoice(sql, newRow({ pa_invoice_id_in: "shared" }));
    const theirs = await insertReceivedInvoice(
      sql,
      newRow({ customer_id: other.customerId, pa_invoice_id_in: "shared" }),
    );

    const found = await findReceivedInvoiceByPaInvoiceIdIn(sql, customerId, "shared");
    expect(found?.id).toBe(mine?.id);

    const foundOther = await findReceivedInvoiceByPaInvoiceIdIn(sql, other.customerId, "shared");
    expect(foundOther?.id).toBe(theirs?.id);
  });

  it("getReceivedInvoiceById → RBAC scope customer (undefined si autre customer)", async () => {
    const row = await insertReceivedInvoice(sql, newRow());
    const other = await seedFullCustomer(sql, { withPaConnection: false });

    const owned = await getReceivedInvoiceById(sql, row?.id ?? "", customerId);
    expect(owned?.id).toBe(row?.id);

    const foreign = await getReceivedInvoiceById(sql, row?.id ?? "", other.customerId);
    expect(foreign).toBeUndefined();
  });

  it("findActiveReceivedInvoicesByCustomerId → filtres status + sellerSiren", async () => {
    await insertReceivedInvoice(
      sql,
      newRow({ pa_invoice_id_in: "a", status_current: "in_process" }),
    );
    await insertReceivedInvoice(
      sql,
      newRow({ pa_invoice_id_in: "b", status_current: "accepted_business" }),
    );
    await insertReceivedInvoice(sql, newRow({ pa_invoice_id_in: "c", seller_siren: "999999999" }));

    const byStatus = await findActiveReceivedInvoicesByCustomerId(sql, customerId, {
      status: "accepted_business",
    });
    expect(byStatus).toHaveLength(1);

    const bySiren = await findActiveReceivedInvoicesByCustomerId(sql, customerId, {
      sellerSiren: "999999999",
    });
    expect(bySiren).toHaveLength(1);
    expect(bySiren[0]?.pa_invoice_id_in).toBe("c");
  });

  it("markReceivedInvoiceStatus → met à jour status_current", async () => {
    const row = await insertReceivedInvoice(sql, newRow());
    await markReceivedInvoiceStatus(sql, row?.id ?? "", "refused_business");
    const after = await getReceivedInvoiceById(sql, row?.id ?? "", customerId);
    expect(after?.status_current).toBe("refused_business");
  });

  it("markReceivedInvoiceAsRead → renseigne read_at (scope customer)", async () => {
    const row = await insertReceivedInvoice(sql, newRow());
    expect(row?.read_at).toBeNull();
    await markReceivedInvoiceAsRead(sql, row?.id ?? "", customerId);
    const after = await getReceivedInvoiceById(sql, row?.id ?? "", customerId);
    expect(after?.read_at).not.toBeNull();
  });

  it("incoming_cdar_events → insert idempotent + lecture timeline", async () => {
    const row = await insertReceivedInvoice(sql, newRow());
    const id = row?.id ?? "";
    const occurredAt = new Date("2026-05-20T09:00:00.000Z");

    const first = await insertIncomingCdarEvent(sql, {
      received_invoice_id: id,
      code: "fr:204",
      occurred_at: occurredAt,
      source: "polling",
    });
    expect(first.inserted).toBe(true);

    // Même clé naturelle (received_invoice_id, code, occurred_at) → no-op.
    const dup = await insertIncomingCdarEvent(sql, {
      received_invoice_id: id,
      code: "fr:204",
      occurred_at: occurredAt,
      source: "polling",
    });
    expect(dup.inserted).toBe(false);

    const events = await findIncomingCdarEventsByReceivedInvoiceId(sql, id);
    expect(events).toHaveLength(1);
    expect(events[0]?.code).toBe("fr:204");
  });

  it("findReceivedInvoiceByPrecedingNumber — matche l'origine (BT-29 + BT-25), sinon undefined", async () => {
    // Facture d'origine reçue (FA-ORIG du fournisseur 552100554).
    await insertReceivedInvoice(
      sql,
      newRow({ pa_invoice_id_in: "pa-orig", invoice_number_extracted: "FA-ORIG" }),
    );

    const found = await findReceivedInvoiceByPrecedingNumber(
      sql,
      customerId,
      RX_BASE.expect.row.sellerSiren,
      "FA-ORIG",
    );
    expect(found?.invoice_number_extracted).toBe("FA-ORIG");

    // Numéro d'origine inconnu → undefined (variant dégradé UI).
    const missing = await findReceivedInvoiceByPrecedingNumber(
      sql,
      customerId,
      RX_BASE.expect.row.sellerSiren,
      "FA-INCONNUE",
    );
    expect(missing).toBeUndefined();

    // SIREN fournisseur différent → undefined (pas de cross-fournisseur).
    const wrongSiren = await findReceivedInvoiceByPrecedingNumber(
      sql,
      customerId,
      "999999999",
      "FA-ORIG",
    );
    expect(wrongSiren).toBeUndefined();
  });
});
