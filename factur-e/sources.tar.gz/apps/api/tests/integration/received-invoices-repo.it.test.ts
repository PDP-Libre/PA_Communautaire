import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import {
  findIncomingCdarEventsByReceivedInvoiceId,
  insertIncomingCdarEvent,
} from "../../src/db/repos/incoming_cdar_events.js";
import {
  findActiveReceivedInvoicesByCustomerId,
  getReceivedInvoiceById,
  insertReceivedInvoice,
  markReceivedInvoiceAsRead,
  markReceivedInvoiceStatus,
  type NewReceivedInvoiceRow,
} from "../../src/db/repos/received_invoices.js";
import { seedFullCustomer } from "../_fixtures/seed-customer.js";
import { setupTestDb, type TestDb } from "../helpers/test-db.js";

/**
 * T-CL-RECV-API sprint-05 W2 — Tests repo `received_invoices` +
 * `incoming_cdar_events` (convention T-CL-01). CRUD + RBAC scope +
 * idempotence ON CONFLICT (ADR-009 D4).
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("[received_invoices] repo", () => {
  let db: TestDb;
  let sql: postgres.Sql;
  let customerId: string;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 5, onnotice: () => undefined });
  });

  afterAll(async () => {
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    const seed = await seedFullCustomer(sql, { withPaConnection: false });
    customerId = seed.customerId;
  });

  const newRow = (over: Partial<NewReceivedInvoiceRow> = {}): NewReceivedInvoiceRow => ({
    customer_id: customerId,
    pa_invoice_id_in: over.pa_invoice_id_in ?? "pa-1",
    seller_siren: "552100554",
    seller_name_cached: "Tricatel",
    supplier_matched: true,
    invoice_number_extracted: "FA-1",
    issue_date: "2026-05-18",
    total_ttc_cents: 120050,
    currency: "EUR",
    status_current: "in_process",
    ...over,
  });

  it("insertReceivedInvoice → retourne la ligne", async () => {
    const row = await insertReceivedInvoice(sql, newRow());
    expect(row).not.toBeNull();
    expect(row?.pa_invoice_id_in).toBe("pa-1");
    expect(row?.total_ttc_cents).toBe(120050);
    expect(row?.status_current).toBe("in_process");
  });

  it("insertReceivedInvoice ON CONFLICT (pa_invoice_id_in) → null (idempotence ADR-009 D4)", async () => {
    const first = await insertReceivedInvoice(sql, newRow({ pa_invoice_id_in: "dup" }));
    expect(first).not.toBeNull();
    const second = await insertReceivedInvoice(sql, newRow({ pa_invoice_id_in: "dup" }));
    expect(second).toBeNull();
  });

  it("getReceivedInvoiceById → RBAC scope customer (undefined si autre customer)", async () => {
    const row = await insertReceivedInvoice(sql, newRow());
    const other = await seedFullCustomer(sql, { withPaConnection: false });

    const owned = await getReceivedInvoiceById(sql, row?.id ?? "", customerId);
    expect(owned?.id).toBe(row?.id);

    const foreign = await getReceivedInvoiceById(sql, row?.id ?? "", other.customerId);
    expect(foreign).toBeUndefined();
  });

  it("findActiveReceivedInvoicesByCustomerId → filtres status + sellerSiren", async () => {
    await insertReceivedInvoice(
      sql,
      newRow({ pa_invoice_id_in: "a", status_current: "in_process" }),
    );
    await insertReceivedInvoice(
      sql,
      newRow({ pa_invoice_id_in: "b", status_current: "accepted_business" }),
    );
    await insertReceivedInvoice(sql, newRow({ pa_invoice_id_in: "c", seller_siren: "999999999" }));

    const byStatus = await findActiveReceivedInvoicesByCustomerId(sql, customerId, {
      status: "accepted_business",
    });
    expect(byStatus).toHaveLength(1);

    const bySiren = await findActiveReceivedInvoicesByCustomerId(sql, customerId, {
      sellerSiren: "999999999",
    });
    expect(bySiren).toHaveLength(1);
    expect(bySiren[0]?.pa_invoice_id_in).toBe("c");
  });

  it("markReceivedInvoiceStatus → met à jour status_current", async () => {
    const row = await insertReceivedInvoice(sql, newRow());
    await markReceivedInvoiceStatus(sql, row?.id ?? "", "refused_business");
    const after = await getReceivedInvoiceById(sql, row?.id ?? "", customerId);
    expect(after?.status_current).toBe("refused_business");
  });

  it("markReceivedInvoiceAsRead → renseigne read_at (scope customer)", async () => {
    const row = await insertReceivedInvoice(sql, newRow());
    expect(row?.read_at).toBeNull();
    await markReceivedInvoiceAsRead(sql, row?.id ?? "", customerId);
    const after = await getReceivedInvoiceById(sql, row?.id ?? "", customerId);
    expect(after?.read_at).not.toBeNull();
  });

  it("incoming_cdar_events → insert idempotent + lecture timeline", async () => {
    const row = await insertReceivedInvoice(sql, newRow());
    const id = row?.id ?? "";
    const occurredAt = new Date("2026-05-20T09:00:00.000Z");

    const first = await insertIncomingCdarEvent(sql, {
      received_invoice_id: id,
      code: "fr:204",
      occurred_at: occurredAt,
      source: "polling",
    });
    expect(first.inserted).toBe(true);

    // Même clé naturelle (received_invoice_id, code, occurred_at) → no-op.
    const dup = await insertIncomingCdarEvent(sql, {
      received_invoice_id: id,
      code: "fr:204",
      occurred_at: occurredAt,
      source: "polling",
    });
    expect(dup.inserted).toBe(false);

    const events = await findIncomingCdarEventsByReceivedInvoiceId(sql, id);
    expect(events).toHaveLength(1);
    expect(events[0]?.code).toBe("fr:204");
  });
});
