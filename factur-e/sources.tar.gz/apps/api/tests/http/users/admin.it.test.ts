import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { hashPassword } from "../../../src/auth/argon2.js";
import { signAccessToken } from "../../../src/auth/jwt.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

interface SeedResult {
  customerId: string;
  full1: { id: string; bearer: string };
  full2: { id: string; bearer: string };
  light: { id: string; bearer: string };
}

async function seedTeam(sql: postgres.Sql): Promise<SeedResult> {
  const customerRows = await sql<{ id: string }[]>`
    INSERT INTO customers (siren, legal_name) VALUES (${"123456789"}, ${"Acme"})
    RETURNING id
  `;
  const customerId = customerRows[0]?.id;
  if (customerId === undefined) throw new Error("customer");
  const hash = await hashPassword("Password123!");

  const f1Rows = await sql<{ id: string }[]>`
    INSERT INTO users (customer_id, email, password_hash, role)
    VALUES (${customerId}, ${"full1@acme.fr"}, ${hash}, ${"full"}) RETURNING id
  `;
  const f2Rows = await sql<{ id: string }[]>`
    INSERT INTO users (customer_id, email, password_hash, role)
    VALUES (${customerId}, ${"full2@acme.fr"}, ${hash}, ${"full"}) RETURNING id
  `;
  const lightRows = await sql<{ id: string }[]>`
    INSERT INTO users (customer_id, email, password_hash, role)
    VALUES (${customerId}, ${"light@acme.fr"}, ${hash}, ${"deposit_simple"}) RETURNING id
  `;
  const f1Id = f1Rows[0]?.id ?? "";
  const f2Id = f2Rows[0]?.id ?? "";
  const lightId = lightRows[0]?.id ?? "";
  return {
    customerId,
    full1: {
      id: f1Id,
      bearer: await signAccessToken({ user_id: f1Id, customer_id: customerId }),
    },
    full2: {
      id: f2Id,
      bearer: await signAccessToken({ user_id: f2Id, customer_id: customerId }),
    },
    light: {
      id: lightId,
      bearer: await signAccessToken({ user_id: lightId, customer_id: customerId }),
    },
  };
}

describe.skipIf(!enabled)("users admin (GET / PATCH / DELETE)", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    app = await buildTestApp({ connectionString: db.url });
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  it("GET /users lists active users (Full only)", async () => {
    const team = await seedTeam(sql);
    const res = await fetch(`${app.url}/users`, {
      headers: { authorization: `Bearer ${team.full1.bearer}` },
    });
    expect(res.status).toBe(200);
    const body = (await res.json()) as { users: { email: string }[] };
    expect(body.users.map((u) => u.email).sort()).toEqual([
      "full1@acme.fr",
      "full2@acme.fr",
      "light@acme.fr",
    ]);
  });

  it("GET /users 403 for non-Full", async () => {
    const team = await seedTeam(sql);
    const res = await fetch(`${app.url}/users`, {
      headers: { authorization: `Bearer ${team.light.bearer}` },
    });
    expect(res.status).toBe(403);
  });

  it("PATCH /users/:id/role updates target", async () => {
    const team = await seedTeam(sql);
    const res = await fetch(`${app.url}/users/${team.light.id}/role`, {
      method: "PATCH",
      headers: { "content-type": "application/json", authorization: `Bearer ${team.full1.bearer}` },
      body: JSON.stringify({ role: "deposit_states" }),
    });
    expect(res.status).toBe(204);
    const rows = await sql<{ role: string }[]>`SELECT role FROM users WHERE id = ${team.light.id}`;
    expect(rows[0]?.role).toBe("deposit_states");
  });

  it("PATCH /users/:id/role refuses self-modify", async () => {
    const team = await seedTeam(sql);
    const res = await fetch(`${app.url}/users/${team.full1.id}/role`, {
      method: "PATCH",
      headers: { "content-type": "application/json", authorization: `Bearer ${team.full1.bearer}` },
      body: JSON.stringify({ role: "deposit_simple" }),
    });
    expect(res.status).toBe(400);
  });

  it("DELETE /users/:id soft-deletes and revokes sessions", async () => {
    const team = await seedTeam(sql);
    // Create a session for light user first.
    await sql`
      INSERT INTO sessions (id, user_id, ip, user_agent, expires_at)
      VALUES (gen_random_uuid(), ${team.light.id}, ${"1.2.3.4"}, ${null}, NOW() + INTERVAL '1 day')
    `;

    const res = await fetch(`${app.url}/users/${team.light.id}`, {
      method: "DELETE",
      headers: { authorization: `Bearer ${team.full1.bearer}` },
    });
    expect(res.status).toBe(204);

    const userRows = await sql<{ deleted_at: Date | null }[]>`
      SELECT deleted_at FROM users WHERE id = ${team.light.id}
    `;
    expect(userRows[0]?.deleted_at).not.toBeNull();

    const sessRows = await sql<{ count: string }[]>`
      SELECT COUNT(*)::text AS count FROM sessions WHERE user_id = ${team.light.id}
    `;
    expect(sessRows[0]?.count).toBe("0");
  });

  it("DELETE refuses self", async () => {
    const team = await seedTeam(sql);
    const res = await fetch(`${app.url}/users/${team.full1.id}`, {
      method: "DELETE",
      headers: { authorization: `Bearer ${team.full1.bearer}` },
    });
    expect(res.status).toBe(400);
  });

  it("PATCH /users/:id/can-purchase refuses self-modify", async () => {
    const team = await seedTeam(sql);
    const res = await fetch(`${app.url}/users/${team.full1.id}/can-purchase`, {
      method: "PATCH",
      headers: { "content-type": "application/json", authorization: `Bearer ${team.full1.bearer}` },
      body: JSON.stringify({ can_purchase: false }),
    });
    expect(res.status).toBe(400);
  });

  it("PATCH can-purchase updates target flag", async () => {
    const team = await seedTeam(sql);
    const res = await fetch(`${app.url}/users/${team.light.id}/can-purchase`, {
      method: "PATCH",
      headers: { "content-type": "application/json", authorization: `Bearer ${team.full1.bearer}` },
      body: JSON.stringify({ can_purchase: true }),
    });
    expect(res.status).toBe(204);
    const rows = await sql<{ can_purchase: boolean }[]>`
      SELECT can_purchase FROM users WHERE id = ${team.light.id}
    `;
    expect(rows[0]?.can_purchase).toBe(true);
  });
});
