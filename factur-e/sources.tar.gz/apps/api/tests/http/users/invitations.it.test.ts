import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { hashPassword } from "../../../src/auth/argon2.js";
import { signAccessToken } from "../../../src/auth/jwt.js";
import { MockEmailSender } from "../../../src/email/sender.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

async function seedFullUser(
  sql: postgres.Sql,
  email = "alice@acme.fr",
): Promise<{ userId: string; customerId: string; bearer: string }> {
  const customerRows = await sql<{ id: string }[]>`
    INSERT INTO customers (siren, legal_name) VALUES (${"123456789"}, ${"Acme"})
    RETURNING id
  `;
  const customerId = customerRows[0]?.id;
  if (customerId === undefined) throw new Error("customer");
  const hash = await hashPassword("Password123!");
  const userRows = await sql<{ id: string }[]>`
    INSERT INTO users (customer_id, email, password_hash, role)
    VALUES (${customerId}, ${email}, ${hash}, ${"full"})
    RETURNING id
  `;
  const userId = userRows[0]?.id;
  if (userId === undefined) throw new Error("user");
  const bearer = await signAccessToken({ user_id: userId, customer_id: customerId });
  return { userId, customerId, bearer };
}

describe.skipIf(!enabled)("invitations flow", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;
  let email: MockEmailSender;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    email = new MockEmailSender();
    app = await buildTestApp({
      connectionString: db.url,
      emailSender: email,
    });
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    email.reset();
  });

  it("Full creates invite, invitee accepts, gets access token", async () => {
    const { customerId, bearer } = await seedFullUser(sql);

    // 1. POST /users/invite
    const inviteRes = await fetch(`${app.url}/users/invite`, {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${bearer}` },
      body: JSON.stringify({ email: "bob@acme.fr", role: "deposit_simple", can_purchase: false }),
    });
    expect(inviteRes.status).toBe(201);
    const inviteBody = (await inviteRes.json()) as Record<string, unknown>;
    expect(typeof inviteBody.invitation_id).toBe("string");

    // 2. Email sent — extract magic link
    const sent = email.lastSentTo("bob@acme.fr");
    expect(sent?.purpose).toBe("invitation");
    const link = sent?.payload.magic_link ?? "";
    const token = link.split("/invite/")[1] ?? "";
    expect(token.includes(".")).toBe(true);

    // 3. GET preview shows the right metadata
    const previewRes = await fetch(`${app.url}/invitations/${token}/preview`);
    expect(previewRes.status).toBe(200);
    const preview = (await previewRes.json()) as Record<string, unknown>;
    expect(preview.email).toBe("bob@acme.fr");
    expect(preview.role).toBe("deposit_simple");
    expect(preview.customer_legal_name).toBe("Acme");
    expect(preview.inviter_email).toBe("alice@acme.fr");

    // 4. POST accept — creates user, returns access token + mfa_setup_required
    const acceptRes = await fetch(`${app.url}/invitations/${token}/accept`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ password: "BobPassword!2", terms_accepted: true }),
    });
    expect(acceptRes.status).toBe(200);
    const acceptBody = (await acceptRes.json()) as Record<string, unknown>;
    expect(typeof acceptBody.access_token).toBe("string");
    expect(acceptBody.mfa_setup_required).toBe(true);

    // 5. user persisted with mfa_reset_required=true and email_verified
    const userRows = await sql<
      {
        email: string;
        role: string;
        can_purchase: boolean;
        mfa_mode: string;
        mfa_reset_required: boolean;
        email_verified_at: Date | null;
      }[]
    >`
      SELECT email, role, can_purchase, mfa_mode, mfa_reset_required, email_verified_at
      FROM users WHERE customer_id = ${customerId} AND email = ${"bob@acme.fr"}
    `;
    expect(userRows[0]?.role).toBe("deposit_simple");
    expect(userRows[0]?.mfa_mode).toBe("none");
    expect(userRows[0]?.mfa_reset_required).toBe(true);
    expect(userRows[0]?.email_verified_at).not.toBeNull();
  });

  it("rejects accept-invite if email already exists in users", async () => {
    const { bearer } = await seedFullUser(sql);
    // Pre-create a user collision (race scenario or external signup).
    const inviteRes = await fetch(`${app.url}/users/invite`, {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${bearer}` },
      body: JSON.stringify({ email: "carol@acme.fr", role: "deposit_simple" }),
    });
    expect(inviteRes.status).toBe(201);
    const link = email.lastSentTo("carol@acme.fr")?.payload.magic_link ?? "";
    const token = link.split("/invite/")[1] ?? "";

    // Now insert a colliding user externally.
    const customerRows = await sql<{ id: string }[]>`
      INSERT INTO customers (siren, legal_name) VALUES (${"987654321"}, ${"Other"}) RETURNING id
    `;
    const otherCustomerId = customerRows[0]?.id ?? "";
    const hash = await hashPassword("Other123!");
    await sql`
      INSERT INTO users (customer_id, email, password_hash, role)
      VALUES (${otherCustomerId}, ${"carol@acme.fr"}, ${hash}, ${"full"})
    `;

    const acceptRes = await fetch(`${app.url}/invitations/${token}/accept`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ password: "CarolPassword12!", terms_accepted: true }),
    });
    expect(acceptRes.status).toBe(409);
  });

  it("invite refuses email already in users (409 immediate)", async () => {
    const { bearer } = await seedFullUser(sql);
    const res = await fetch(`${app.url}/users/invite`, {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${bearer}` },
      body: JSON.stringify({ email: "alice@acme.fr", role: "deposit_simple" }),
    });
    expect(res.status).toBe(409);
  });

  it("invite replaces a pending invitation for the same email", async () => {
    const { customerId, bearer } = await seedFullUser(sql);

    const r1 = await fetch(`${app.url}/users/invite`, {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${bearer}` },
      body: JSON.stringify({ email: "dora@acme.fr", role: "deposit_simple" }),
    });
    expect(r1.status).toBe(201);

    const r2 = await fetch(`${app.url}/users/invite`, {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${bearer}` },
      body: JSON.stringify({ email: "dora@acme.fr", role: "deposit_states" }),
    });
    expect(r2.status).toBe(201);

    const rows = await sql<{ count: string }[]>`
      SELECT COUNT(*)::text AS count FROM invitations
      WHERE customer_id = ${customerId} AND email = ${"dora@acme.fr"} AND accepted_at IS NULL
    `;
    expect(rows[0]?.count).toBe("1");
  });

  it("non-Full cannot invite (403)", async () => {
    const { customerId } = await seedFullUser(sql);
    const hash = await hashPassword("Pass123!");
    const userRows = await sql<{ id: string }[]>`
      INSERT INTO users (customer_id, email, password_hash, role)
      VALUES (${customerId}, ${"eve@acme.fr"}, ${hash}, ${"deposit_simple"})
      RETURNING id
    `;
    const userId = userRows[0]?.id ?? "";
    const bearer = await signAccessToken({ user_id: userId, customer_id: customerId });

    const res = await fetch(`${app.url}/users/invite`, {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${bearer}` },
      body: JSON.stringify({ email: "frank@acme.fr", role: "deposit_simple" }),
    });
    expect(res.status).toBe(403);
  });

  it("preview returns 404 on bad token format", async () => {
    const res = await fetch(`${app.url}/invitations/garbage/preview`);
    expect(res.status).toBe(404);
  });

  it("revoke removes a pending invitation", async () => {
    const { customerId, bearer } = await seedFullUser(sql);
    const res = await fetch(`${app.url}/users/invite`, {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${bearer}` },
      body: JSON.stringify({ email: "gina@acme.fr", role: "deposit_simple" }),
    });
    expect(res.status).toBe(201);
    const { invitation_id: id } = (await res.json()) as { invitation_id: string };

    const del = await fetch(`${app.url}/invitations/${id}`, {
      method: "DELETE",
      headers: { authorization: `Bearer ${bearer}` },
    });
    expect(del.status).toBe(204);

    const rows = await sql<{ count: string }[]>`
      SELECT COUNT(*)::text AS count FROM invitations WHERE customer_id = ${customerId}
    `;
    expect(rows[0]?.count).toBe("0");
  });
});
