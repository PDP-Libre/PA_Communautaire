import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { MockPADriver } from "@factur-e/shared-fakes";

import { hashPassword } from "../../../src/auth/argon2.js";
import { signAccessToken } from "../../../src/auth/jwt.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

/**
 * T-CL-10 sprint-03 — POST /api/directory/search + /preference.
 *
 * 5 cas représentatifs des 5 outcomes du discriminated `kind` côté
 * `DirectorySearchResult` :
 *  1. found_one_address — happy path, cache rempli, 2e appel = cache hit
 *     (compteur driver inchangé).
 *  2. found_multi_address — 2 adresses, sélection mémorisée via
 *     `/preference` (vérifie l'INSERT dans `buyer_address_preferences`).
 *  3. not_found — payload null caché.
 *  4. disabled — company avec addresses=[].
 *  5. unavailable — pas de cache écrit (le 2e appel re-tape l'adapter).
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

interface Seed {
  customerId: string;
  userId: string;
  bearer: string;
}

async function seedFullUser(sql: postgres.Sql): Promise<Seed> {
  const customerRows = await sql<{ id: string }[]>`
    INSERT INTO customers (siren, legal_name) VALUES (${"123456789"}, ${"Acme"})
    RETURNING id
  `;
  const customerId = customerRows[0]?.id ?? "";
  const hash = await hashPassword("Password123!");
  const userRows = await sql<{ id: string }[]>`
    INSERT INTO users (customer_id, email, password_hash, role)
    VALUES (${customerId}, ${"alice@acme.fr"}, ${hash}, ${"full"})
    RETURNING id
  `;
  const userId = userRows[0]?.id ?? "";
  return {
    customerId,
    userId,
    bearer: await signAccessToken({ user_id: userId, customer_id: customerId }),
  };
}

// SIRENs valides Luhn. 732829320 = Air France SA (utilisé en T-CL-09).
const SIREN_OK = "732829320";
const SIREN_MULTI = "552081317";
const SIREN_NOT_FOUND = "880129119";
const SIREN_DISABLED = "552120222";
const SIREN_UNAVAILABLE = "303174304";

const SAMPLE_COMPANY = {
  number: "732829320",
  formal_name: "AIR FRANCE",
  address: "45 RUE DE PARIS",
  postcode: "95747",
  city: "ROISSY-CDG",
  country: "FR",
};

describe.skipIf(!enabled)("POST /api/directory/* (T-CL-10 sprint-03)", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;
  let driver: MockPADriver;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
    driver = new MockPADriver({ scenario: "verified" });
    app = await buildTestApp({
      connectionString: db.url,
      paDriver: driver,
    });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    driver.reset();
  });

  it("found_one_address → cache rempli, 2e appel = hit (driver count inchangé)", async () => {
    const seed = await seedFullUser(sql);
    driver.setSearchSirenOutcome(SIREN_OK, {
      kind: "found_one_address",
      company: SAMPLE_COMPANY,
      address: {
        party_id: "0225:732829320_dgfip",
        scheme_id: "0225",
        is_active: true,
        pa_name: "SuperPDP",
      },
    });

    const r1 = await fetch(`${app.url}/api/directory/search`, {
      method: "POST",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify({ siren: SIREN_OK }),
    });
    expect(r1.status).toBe(200);
    const body1 = (await r1.json()) as { kind: string; address?: { party_id: string } };
    expect(body1.kind).toBe("found_one_address");
    expect(body1.address?.party_id).toBe("0225:732829320_dgfip");
    expect(driver.counts.searchSiren).toBe(1);

    // 2e appel — cache hit : ne re-tape pas l'adapter.
    const r2 = await fetch(`${app.url}/api/directory/search`, {
      method: "POST",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify({ siren: SIREN_OK }),
    });
    expect(r2.status).toBe(200);
    expect(driver.counts.searchSiren).toBe(1);

    const cacheRows = await sql<{ siren: string }[]>`
      SELECT siren FROM directory_cache WHERE siren = ${SIREN_OK}
    `;
    expect(cacheRows.length).toBe(1);
  });

  it("found_multi_address → préférence mémorisée via /preference", async () => {
    const seed = await seedFullUser(sql);
    driver.setSearchSirenOutcome(SIREN_MULTI, {
      kind: "found_multi_address",
      company: { ...SAMPLE_COMPANY, number: SIREN_MULTI, formal_name: "MULTI SA" },
      addresses: [
        { party_id: "0225:multi_a", scheme_id: "0225", is_active: true, pa_name: "SuperPDP" },
        { party_id: "0225:multi_b", scheme_id: "0225", is_active: true, pa_name: "OtherPA" },
      ],
    });

    const r = await fetch(`${app.url}/api/directory/search`, {
      method: "POST",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify({ siren: SIREN_MULTI }),
    });
    expect(r.status).toBe(200);
    const body = (await r.json()) as {
      kind: string;
      addresses?: { party_id: string }[];
    };
    expect(body.kind).toBe("found_multi_address");
    expect(body.addresses?.length).toBe(2);

    // Mémorisation
    const pref = await fetch(`${app.url}/api/directory/preference`, {
      method: "POST",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify({ buyer_siren: SIREN_MULTI, party_id: "0225:multi_b" }),
    });
    expect(pref.status).toBe(204);

    const prefRows = await sql<{ preferred_party_id: string }[]>`
      SELECT preferred_party_id FROM buyer_address_preferences
      WHERE customer_id = ${seed.customerId} AND buyer_siren = ${SIREN_MULTI}
    `;
    expect(prefRows.length).toBe(1);
    expect(prefRows[0]?.preferred_party_id).toBe("0225:multi_b");
  });

  it("not_found → cache négatif (payload null), 2e appel = hit", async () => {
    const seed = await seedFullUser(sql);
    // MockPADriver default = not_found, donc inutile de setter.

    const r = await fetch(`${app.url}/api/directory/search`, {
      method: "POST",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify({ siren: SIREN_NOT_FOUND }),
    });
    expect(r.status).toBe(200);
    expect(((await r.json()) as { kind: string }).kind).toBe("not_found");
    expect(driver.counts.searchSiren).toBe(1);

    const cacheRows = await sql<{ payload: unknown }[]>`
      SELECT payload FROM directory_cache WHERE siren = ${SIREN_NOT_FOUND}
    `;
    expect(cacheRows.length).toBe(1);
    expect(cacheRows[0]?.payload).toBeNull();

    // 2e appel = cache hit
    await fetch(`${app.url}/api/directory/search`, {
      method: "POST",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify({ siren: SIREN_NOT_FOUND }),
    });
    expect(driver.counts.searchSiren).toBe(1);
  });

  it("disabled → company exposé, addresses=[] côté cache", async () => {
    const seed = await seedFullUser(sql);
    driver.setSearchSirenOutcome(SIREN_DISABLED, {
      kind: "disabled",
      company: { ...SAMPLE_COMPANY, number: SIREN_DISABLED, formal_name: "DISABLED SA" },
    });

    const r = await fetch(`${app.url}/api/directory/search`, {
      method: "POST",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify({ siren: SIREN_DISABLED }),
    });
    expect(r.status).toBe(200);
    const body = (await r.json()) as { kind: string; company?: { formal_name: string } };
    expect(body.kind).toBe("disabled");
    expect(body.company?.formal_name).toBe("DISABLED SA");

    const cacheRows = await sql<{ addresses: unknown[] }[]>`
      SELECT addresses FROM directory_cache WHERE siren = ${SIREN_DISABLED}
    `;
    expect(cacheRows.length).toBe(1);
    expect(cacheRows[0]?.addresses).toEqual([]);
  });

  it("unavailable → propagé sans cache (2e appel re-tape l'adapter)", async () => {
    const seed = await seedFullUser(sql);
    driver.setSearchSirenOutcome(SIREN_UNAVAILABLE, {
      kind: "unavailable",
      cause: "5xx",
      status: 503,
    });

    const r1 = await fetch(`${app.url}/api/directory/search`, {
      method: "POST",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify({ siren: SIREN_UNAVAILABLE }),
    });
    expect(r1.status).toBe(200);
    expect(((await r1.json()) as { kind: string }).kind).toBe("unavailable");

    const cacheRows = await sql<{ count: string }[]>`
      SELECT COUNT(*)::text AS count FROM directory_cache WHERE siren = ${SIREN_UNAVAILABLE}
    `;
    expect(cacheRows[0]?.count).toBe("0");

    const r2 = await fetch(`${app.url}/api/directory/search`, {
      method: "POST",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify({ siren: SIREN_UNAVAILABLE }),
    });
    expect(r2.status).toBe(200);
    expect(driver.counts.searchSiren).toBe(2);
  });

  it("NC-4 — TTL différencié : positif ~7j, négatif ~15min", async () => {
    const seed = await seedFullUser(sql);
    driver.setSearchSirenOutcome(SIREN_OK, {
      kind: "found_one_address",
      company: SAMPLE_COMPANY,
      address: {
        party_id: "0225:732829320",
        scheme_id: "0225",
        is_active: true,
        pa_name: "SuperPDP",
      },
    });
    // SIREN_NOT_FOUND → MockPADriver renvoie not_found par défaut.
    const headers = { authorization: `Bearer ${seed.bearer}`, "content-type": "application/json" };
    await fetch(`${app.url}/api/directory/search`, {
      method: "POST",
      headers,
      body: JSON.stringify({ siren: SIREN_OK }),
    });
    await fetch(`${app.url}/api/directory/search`, {
      method: "POST",
      headers,
      body: JSON.stringify({ siren: SIREN_NOT_FOUND }),
    });

    const rows = await sql<{ siren: string; ttl_seconds: number }[]>`
      SELECT siren, EXTRACT(EPOCH FROM (expires_at - now()))::int AS ttl_seconds
      FROM directory_cache
      WHERE siren IN (${SIREN_OK}, ${SIREN_NOT_FOUND})
    `;
    const positive = rows.find((r) => r.siren === SIREN_OK)?.ttl_seconds ?? 0;
    const negative = rows.find((r) => r.siren === SIREN_NOT_FOUND)?.ttl_seconds ?? 0;
    // Positif : ~7 jours (604800s) — bien au-delà d'1 jour.
    expect(positive).toBeGreaterThan(24 * 60 * 60);
    // Négatif : ~15 min (900s) — sous l'heure.
    expect(negative).toBeLessThan(60 * 60);
    expect(negative).toBeGreaterThan(0);
  });
});
