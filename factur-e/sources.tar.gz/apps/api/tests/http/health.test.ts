import { describe, expect, it } from "vitest";

import { buildTestApp } from "../helpers/build-app.js";

describe("GET /health", () => {
  it("returns 200 with status ok and version metadata", async () => {
    const { url, stop } = await buildTestApp();
    try {
      const res = await fetch(`${url}/health`);
      expect(res.status).toBe(200);
      expect(res.headers.get("content-type")).toMatch(/application\/json/);

      const body = (await res.json()) as Record<string, unknown>;
      expect(body.status).toBe("ok");
      expect(body.service).toBe("factur-e-api");
      expect(typeof body.version).toBe("string");
    } finally {
      await stop();
    }
  });

  it("does not match unrelated paths", async () => {
    const { url, stop } = await buildTestApp();
    try {
      const res = await fetch(`${url}/nope`);
      expect(res.status).toBe(404);
    } finally {
      await stop();
    }
  });
});
