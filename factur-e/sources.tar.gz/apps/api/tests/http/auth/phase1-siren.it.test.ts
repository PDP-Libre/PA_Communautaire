import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import type { InseeClient, InseeLookupResult, InseeUniteLegale } from "@factur-e/insee-adapter";

import { MockEmailSender } from "../../../src/email/sender.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

class FixedInseeClient implements InseeClient {
  constructor(private readonly result: InseeLookupResult) {}
  async lookupSiren(): Promise<InseeLookupResult> {
    await Promise.resolve();
    return this.result;
  }
}

const VALID_SIREN = "552120222"; // Luhn-valid SIREN of "ACME SAS" fixture
const FOUND_FIXTURE: InseeLookupResult = {
  kind: "found",
  unite: {
    siren: VALID_SIREN,
    legal_name: "ACME SAS",
    juridique_code: "5710",
    naf_code: "6201Z",
    creation_date: "1955-04-01",
    etat_administratif: "A",
  } satisfies InseeUniteLegale,
  etablissements: [
    {
      siret: `${VALID_SIREN}00015`,
      is_siege: true,
      etat_administratif: "A",
      creation_date: "2010-01-01",
      address: { street: "1 RUE DE LA PAIX", zip: "75002", city: "PARIS 2", country_code: "FR" },
    },
    {
      siret: `${VALID_SIREN}00023`,
      is_siege: false,
      etat_administratif: "A",
      creation_date: "2018-06-15",
      address: {
        street: "12 AVENUE VICTOR HUGO",
        zip: "33000",
        city: "BORDEAUX",
        country_code: "FR",
      },
    },
  ],
  raw: { stub: true },
};

async function startSignup(url: string, email: string): Promise<string> {
  const res = await fetch(`${url}/auth/signup`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ email, password: "Password123!", terms_accepted: true }),
  });
  expect(res.status).toBe(201);
  const cookie = res.headers.get("set-cookie");
  if (cookie === null) throw new Error("cookie");
  return cookie;
}

describe.skipIf(!enabled)("POST /auth/phase1/siren", () => {
  let db: TestDb;
  let sql: postgres.Sql;
  let app: TestApp;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    app = await buildTestApp({
      connectionString: db.url,
      emailSender: new MockEmailSender(),
      inseeClient: new FixedInseeClient(FOUND_FIXTURE),
    });
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  it("returns kind=found, persists prefilled, advances current_step to siret", async () => {
    const cookie = await startSignup(app.url, "alice@acme.fr");
    const res = await fetch(`${app.url}/auth/phase1/siren`, {
      method: "POST",
      headers: { "content-type": "application/json", cookie },
      body: JSON.stringify({ siren: VALID_SIREN }),
    });
    expect(res.status).toBe(200);
    const body = (await res.json()) as Record<string, unknown>;
    expect(body.kind).toBe("found");
    expect(body.legal_name).toBe("ACME SAS");
    expect(body.juridique_label).toBe("Société par actions simplifiée (SAS)");
    expect(body.naf_code).toBe("6201Z");
    const ets = body.establishments as { siret: string; is_siege: boolean }[];
    expect(ets).toHaveLength(2);
    expect(ets[0]?.is_siege).toBe(true); // siège first

    const rows = await sql<
      {
        siren: string | null;
        current_step: string;
        customer_data_prefilled: Record<string, unknown> | null;
      }[]
    >`SELECT siren, current_step, customer_data_prefilled FROM signup_pending`;
    expect(rows[0]?.siren).toBe(VALID_SIREN);
    expect(rows[0]?.current_step).toBe("siret");
    const prefilled = rows[0]?.customer_data_prefilled;
    expect(prefilled?.legal_name).toBe("ACME SAS");
    expect(Array.isArray(prefilled?.establishments)).toBe(true);
  });

  it("returns kind=already_bound when SIREN exists in customers", async () => {
    await sql`
      INSERT INTO customers (siren, legal_name) VALUES (${VALID_SIREN}, ${"Acme Existant"})
    `;
    const cookie = await startSignup(app.url, "bob@acme.fr");
    const res = await fetch(`${app.url}/auth/phase1/siren`, {
      method: "POST",
      headers: { "content-type": "application/json", cookie },
      body: JSON.stringify({ siren: VALID_SIREN }),
    });
    expect(res.status).toBe(200);
    const body = (await res.json()) as Record<string, unknown>;
    expect(body.kind).toBe("already_bound");

    const rows = await sql<{ current_step: string; siren: string | null }[]>`
      SELECT current_step, siren FROM signup_pending
    `;
    expect(rows[0]?.current_step).toBe("siren"); // step NOT advanced
    expect(rows[0]?.siren).toBeNull();
  });

  it("rejects a SIREN failing Luhn (returns not_found without calling INSEE)", async () => {
    const cookie = await startSignup(app.url, "carol@acme.fr");
    const res = await fetch(`${app.url}/auth/phase1/siren`, {
      method: "POST",
      headers: { "content-type": "application/json", cookie },
      body: JSON.stringify({ siren: "123456789" }), // not Luhn-valid
    });
    expect(res.status).toBe(200);
    const body = (await res.json()) as Record<string, unknown>;
    expect(body.kind).toBe("not_found");
  });

  it("returns kind=unavailable on adapter outage and does NOT advance step", async () => {
    // Use a fresh app instance with a different INSEE client.
    const downApp = await buildTestApp({
      connectionString: db.url,
      emailSender: new MockEmailSender(),
      inseeClient: new FixedInseeClient({ kind: "unavailable", cause: "network" }),
    });
    try {
      const cookie = await startSignup(downApp.url, "dan@acme.fr");
      const res = await fetch(`${downApp.url}/auth/phase1/siren`, {
        method: "POST",
        headers: { "content-type": "application/json", cookie },
        body: JSON.stringify({ siren: VALID_SIREN }),
      });
      expect(res.status).toBe(503);
      const body = (await res.json()) as Record<string, unknown>;
      expect(body.kind).toBe("unavailable");

      const rows = await sql<{ current_step: string }[]>`
        SELECT current_step FROM signup_pending WHERE email = ${"dan@acme.fr"}
      `;
      expect(rows[0]?.current_step).toBe("siren");
    } finally {
      await downApp.stop();
    }
  });

  it("returns 401 without a signup_session cookie", async () => {
    const res = await fetch(`${app.url}/auth/phase1/siren`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ siren: VALID_SIREN }),
    });
    expect(res.status).toBe(401);
  });
});
