import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { hashPassword } from "../../../src/auth/argon2.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("GET /auth/me", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    app = await buildTestApp({ connectionString: db.url });
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  it("returns 401 when neither cookie nor bearer is present", async () => {
    const res = await fetch(`${app.url}/auth/me`);
    expect(res.status).toBe(401);
  });

  it("returns state=pending after signup, with email + current_step", async () => {
    const signupRes = await fetch(`${app.url}/auth/signup`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        email: "alice@acme.fr",
        password: "Password123!",
        terms_accepted: true,
      }),
    });
    const signupCookie = signupRes.headers.get("set-cookie") ?? "";
    expect(signupCookie).toMatch(/signup_session=/);

    const meRes = await fetch(`${app.url}/auth/me`, {
      headers: { cookie: signupCookie },
    });
    expect(meRes.status).toBe(200);
    const body = (await meRes.json()) as Record<string, unknown>;
    expect(body.state).toBe("pending");
    expect(body.current_step).toBe("siren");
    expect(body.email).toBe("alice@acme.fr");
  });

  it("returns state=authenticated with user + customer on bearer token", async () => {
    const customerRows = await sql<{ id: string }[]>`
      INSERT INTO customers (siren, legal_name, primary_color)
      VALUES (${"123456789"}, ${"Acme SARL"}, ${"#316128"})
      RETURNING id
    `;
    const customerId = customerRows[0]?.id;
    if (customerId === undefined) throw new Error("customer");
    const hash = await hashPassword("Password123!");
    // T-CL-03 invariant: full + mfa_mode='none' would 500 at login.
    // Use deposit_simple (AUTH-3 allows MFA-less for non-Full).
    await sql`
      INSERT INTO users (customer_id, email, password_hash, role)
      VALUES (${customerId}, ${"alice@acme.fr"}, ${hash}, ${"deposit_simple"})
    `;

    const loginRes = await fetch(`${app.url}/auth/login`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ email: "alice@acme.fr", password: "Password123!" }),
    });
    const loginBody = (await loginRes.json()) as { access_token: string };

    const meRes = await fetch(`${app.url}/auth/me`, {
      headers: { authorization: `Bearer ${loginBody.access_token}` },
    });
    expect(meRes.status).toBe(200);
    const body = (await meRes.json()) as Record<string, unknown>;
    expect(body.state).toBe("authenticated");
    const user = body.user as Record<string, unknown>;
    expect(user.email).toBe("alice@acme.fr");
    expect(user.role).toBe("deposit_simple");
    expect(user.can_purchase).toBe(false);
    expect(user.mfa_mode).toBe("none");
    expect(user.mfa_reset_required).toBe(false);
    const customer = body.customer as Record<string, unknown>;
    expect(customer.siren).toBe("123456789");
    expect(customer.legal_name).toBe("Acme SARL");
    expect(customer.primary_color).toBe("#316128");
  });

  it("prefers bearer over signup cookie when both are present", async () => {
    const signupRes = await fetch(`${app.url}/auth/signup`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        email: "stale@acme.fr",
        password: "Password123!",
        terms_accepted: true,
      }),
    });
    const signupCookie = signupRes.headers.get("set-cookie") ?? "";

    const customerRows = await sql<{ id: string }[]>`
      INSERT INTO customers (siren, legal_name) VALUES (${"987654321"}, ${"Other"})
      RETURNING id
    `;
    const customerId = customerRows[0]?.id;
    if (customerId === undefined) throw new Error("customer");
    const hash = await hashPassword("Password123!");
    // T-CL-03 invariant: full + mfa_mode='none' would 500 at login.
    // Use deposit_simple (AUTH-3 allows MFA-less for non-Full).
    await sql`
      INSERT INTO users (customer_id, email, password_hash, role)
      VALUES (${customerId}, ${"alice@acme.fr"}, ${hash}, ${"deposit_simple"})
    `;
    const loginRes = await fetch(`${app.url}/auth/login`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ email: "alice@acme.fr", password: "Password123!" }),
    });
    const loginBody = (await loginRes.json()) as { access_token: string };

    const meRes = await fetch(`${app.url}/auth/me`, {
      headers: {
        cookie: signupCookie,
        authorization: `Bearer ${loginBody.access_token}`,
      },
    });
    expect(meRes.status).toBe(200);
    const body = (await meRes.json()) as Record<string, unknown>;
    expect(body.state).toBe("authenticated");
  });
});
