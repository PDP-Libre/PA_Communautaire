import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import type { InseeClient, InseeLookupResult } from "@factur-e/insee-adapter";

import { MockEmailSender } from "../../../src/email/sender.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

const VALID_SIREN = "552120222";
const SIEGE_SIRET = `${VALID_SIREN}00015`;

class FixedInseeClient implements InseeClient {
  constructor(private readonly result: InseeLookupResult) {}
  async lookupSiren(): Promise<InseeLookupResult> {
    await Promise.resolve();
    return this.result;
  }
}

const FOUND_FIXTURE: InseeLookupResult = {
  kind: "found",
  unite: {
    siren: VALID_SIREN,
    legal_name: "ACME SAS",
    juridique_code: "5710",
    naf_code: "6201Z",
    creation_date: "1955-04-01",
    etat_administratif: "A",
  },
  etablissements: [
    {
      siret: SIEGE_SIRET,
      is_siege: true,
      etat_administratif: "A",
      creation_date: "2010-01-01",
      address: { street: "1 RUE DE LA PAIX", zip: "75002", city: "PARIS 2", country_code: "FR" },
    },
  ],
  raw: { stub: true },
};

async function bringSignupToSiretStep(url: string, email: string): Promise<string> {
  const signupRes = await fetch(`${url}/auth/signup`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ email, password: "Password123!", terms_accepted: true }),
  });
  const cookie = signupRes.headers.get("set-cookie");
  if (cookie === null) throw new Error("cookie");
  await fetch(`${url}/auth/phase1/siren`, {
    method: "POST",
    headers: { "content-type": "application/json", cookie },
    body: JSON.stringify({ siren: VALID_SIREN }),
  });
  return cookie;
}

describe.skipIf(!enabled)("POST /auth/phase1/siret", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    app = await buildTestApp({
      connectionString: db.url,
      emailSender: new MockEmailSender(),
      inseeClient: new FixedInseeClient(FOUND_FIXTURE),
    });
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  it("siret kind: persists chosen establishment + address, advances to email_verify", async () => {
    const cookie = await bringSignupToSiretStep(app.url, "alice@acme.fr");

    const res = await fetch(`${app.url}/auth/phase1/siret`, {
      method: "POST",
      headers: { "content-type": "application/json", cookie },
      body: JSON.stringify({ kind: "siret", siret: SIEGE_SIRET }),
    });
    expect(res.status).toBe(204);

    const rows = await sql<
      {
        siret: string | null;
        current_step: string;
        customer_data_prefilled: Record<string, unknown> | null;
      }[]
    >`SELECT siret, current_step, customer_data_prefilled FROM signup_pending`;
    expect(rows[0]?.siret).toBe(SIEGE_SIRET);
    expect(rows[0]?.current_step).toBe("email_verify");
    const addr = rows[0]?.customer_data_prefilled?.address as Record<string, unknown> | undefined;
    expect(addr?.zip).toBe("75002");
    expect(addr?.city).toBe("PARIS 2");
  });

  it("manual kind: persists provided address, advances step", async () => {
    const cookie = await bringSignupToSiretStep(app.url, "bob@acme.fr");

    const res = await fetch(`${app.url}/auth/phase1/siret`, {
      method: "POST",
      headers: { "content-type": "application/json", cookie },
      body: JSON.stringify({
        kind: "manual",
        address: {
          street: "5 rue Personnelle",
          zip: "75001",
          city: "Paris",
          country_code: "FR",
        },
      }),
    });
    expect(res.status).toBe(204);

    const rows = await sql<
      { siret: string | null; customer_data_prefilled: Record<string, unknown> | null }[]
    >`SELECT siret, customer_data_prefilled FROM signup_pending`;
    expect(rows[0]?.siret).toBeNull();
    const addr = rows[0]?.customer_data_prefilled?.address as Record<string, unknown> | undefined;
    expect(addr?.street).toBe("5 rue Personnelle");
  });

  it("rejects a SIRET that doesn't start with the chosen SIREN", async () => {
    const cookie = await bringSignupToSiretStep(app.url, "carol@acme.fr");

    const res = await fetch(`${app.url}/auth/phase1/siret`, {
      method: "POST",
      headers: { "content-type": "application/json", cookie },
      body: JSON.stringify({ kind: "siret", siret: "99999999900015" }),
    });
    expect(res.status).toBe(400);
  });

  it("rejects a SIRET not in the establishments list", async () => {
    const cookie = await bringSignupToSiretStep(app.url, "dan@acme.fr");

    const res = await fetch(`${app.url}/auth/phase1/siret`, {
      method: "POST",
      headers: { "content-type": "application/json", cookie },
      body: JSON.stringify({ kind: "siret", siret: `${VALID_SIREN}00099` }),
    });
    expect(res.status).toBe(400);
  });

  it("returns 409 when called before /siren", async () => {
    const signupRes = await fetch(`${app.url}/auth/signup`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        email: "eve@acme.fr",
        password: "Password123!",
        terms_accepted: true,
      }),
    });
    const cookie = signupRes.headers.get("set-cookie") ?? "";
    const res = await fetch(`${app.url}/auth/phase1/siret`, {
      method: "POST",
      headers: { "content-type": "application/json", cookie },
      body: JSON.stringify({ kind: "siret", siret: SIEGE_SIRET }),
    });
    expect(res.status).toBe(409);
  });
});
