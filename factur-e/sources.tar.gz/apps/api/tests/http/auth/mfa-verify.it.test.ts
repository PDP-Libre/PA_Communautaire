import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { hashPassword } from "../../../src/auth/argon2.js";
import { encrypt } from "../../../src/auth/encryption.js";
import { generateRecoveryCodes } from "../../../src/auth/recovery.js";
import { generateTotpSecret, currentTotpCode } from "../../../src/auth/totp.js";
import { MockEmailSender } from "../../../src/email/sender.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

interface SeededUser {
  userId: string;
  customerId: string;
  totpSecret: Buffer;
  recoveryPlain: string[];
}

async function seedFullUserWithTotp(sql: postgres.Sql, email: string): Promise<SeededUser> {
  const customerRows = await sql<{ id: string }[]>`
    INSERT INTO customers (siren, legal_name) VALUES (${"123456789"}, ${"Acme SARL"})
    RETURNING id
  `;
  const customerId = customerRows[0]?.id;
  if (customerId === undefined) throw new Error("customer");

  const password_hash = await hashPassword("Password123!");
  const totpSecret = generateTotpSecret();
  const encrypted = encrypt(totpSecret);
  const { plain, hashed } = await generateRecoveryCodes();

  const userRows = await sql<{ id: string }[]>`
    INSERT INTO users (
      customer_id, email, password_hash,
      mfa_secret, mfa_mode, recovery_codes_hashed,
      role, can_purchase
    ) VALUES (
      ${customerId}, ${email}, ${password_hash},
      ${encrypted}, ${"totp"}, ${hashed},
      ${"full"}, ${true}
    )
    RETURNING id
  `;
  const userId = userRows[0]?.id;
  if (userId === undefined) throw new Error("user");
  return { userId, customerId, totpSecret, recoveryPlain: plain };
}

describe.skipIf(!enabled)("POST /auth/mfa/verify (login challenge)", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;
  let email: MockEmailSender;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    email = new MockEmailSender();
    app = await buildTestApp({ connectionString: db.url, emailSender: email });
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    email.reset();
  });

  it("login with TOTP user returns mfa_required → mfa/verify with code grants access", async () => {
    const { totpSecret } = await seedFullUserWithTotp(sql, "alice@acme.fr");

    const loginRes = await fetch(`${app.url}/auth/login`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ email: "alice@acme.fr", password: "Password123!" }),
    });
    expect(loginRes.status).toBe(200);
    const loginBody = (await loginRes.json()) as Record<string, unknown>;
    expect(loginBody.state).toBe("mfa_required");
    expect(loginBody.mfa_mode).toBe("totp");
    expect(typeof loginBody.mfa_challenge_token).toBe("string");
    // No refresh cookie at the password step.
    expect(loginRes.headers.get("set-cookie")).toBeNull();

    const code = currentTotpCode(totpSecret);
    const verifyRes = await fetch(`${app.url}/auth/mfa/verify`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ mfa_challenge_token: loginBody.mfa_challenge_token, code }),
    });
    expect(verifyRes.status).toBe(200);
    const verifyBody = (await verifyRes.json()) as Record<string, unknown>;
    expect(typeof verifyBody.access_token).toBe("string");
    expect(verifyRes.headers.get("set-cookie")).toMatch(/_session=/);

    const audit = await sql<{ event_type: string }[]>`
      SELECT event_type FROM auth_audit ORDER BY occurred_at
    `;
    const events = audit.map((a) => a.event_type);
    expect(events).toContain("login_password_ok_mfa_pending");
    expect(events).toContain("mfa_verified");
  });

  it("login email-MFA fires OTP via mock sender; mfa/verify with that code grants access", async () => {
    const customerRows = await sql<{ id: string }[]>`
      INSERT INTO customers (siren, legal_name) VALUES (${"123456789"}, ${"Acme SARL"})
      RETURNING id
    `;
    const customerId = customerRows[0]?.id;
    if (customerId === undefined) throw new Error("customer");
    const hash = await hashPassword("Password123!");
    await sql`
      INSERT INTO users (customer_id, email, password_hash, mfa_mode, role)
      VALUES (${customerId}, ${"alice@acme.fr"}, ${hash}, ${"email"}, ${"full"})
    `;

    const loginRes = await fetch(`${app.url}/auth/login`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ email: "alice@acme.fr", password: "Password123!" }),
    });
    const loginBody = (await loginRes.json()) as Record<string, unknown>;
    expect(loginBody.state).toBe("mfa_required");
    expect(loginBody.mfa_mode).toBe("email");

    const captured = email.lastSentTo("alice@acme.fr");
    expect(captured?.purpose).toBe("login_mfa_otp");
    const code = captured?.payload.otp_code;
    if (code === undefined) throw new Error("no otp");

    const verifyRes = await fetch(`${app.url}/auth/mfa/verify`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ mfa_challenge_token: loginBody.mfa_challenge_token, code }),
    });
    expect(verifyRes.status).toBe(200);
  });

  it("recovery code consume forces MFA reset and grants access", async () => {
    const { recoveryPlain } = await seedFullUserWithTotp(sql, "alice@acme.fr");
    const recoveryCode = recoveryPlain[0];
    if (recoveryCode === undefined) throw new Error("recovery");

    const loginRes = await fetch(`${app.url}/auth/login`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ email: "alice@acme.fr", password: "Password123!" }),
    });
    const loginBody = (await loginRes.json()) as Record<string, unknown>;

    const verifyRes = await fetch(`${app.url}/auth/mfa/verify`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        mfa_challenge_token: loginBody.mfa_challenge_token,
        recovery_code: recoveryCode,
      }),
    });
    expect(verifyRes.status).toBe(200);

    const userRows = await sql<
      {
        mfa_mode: string;
        mfa_secret: Buffer | null;
        mfa_reset_required: boolean;
        recovery_codes_hashed: string[] | null;
      }[]
    >`
      SELECT mfa_mode, mfa_secret, mfa_reset_required, recovery_codes_hashed FROM users
    `;
    const u = userRows[0];
    if (u === undefined) throw new Error("user");
    expect(u.mfa_mode).toBe("none");
    expect(u.mfa_secret).toBeNull();
    expect(u.mfa_reset_required).toBe(true);
    expect(u.recovery_codes_hashed).toHaveLength(9);

    const audit = await sql<{ event_type: string }[]>`
      SELECT event_type FROM auth_audit ORDER BY occurred_at DESC LIMIT 1
    `;
    expect(audit[0]?.event_type).toBe("mfa_recovery_used");
  });

  it("wrong TOTP code returns 401 + mfa_failed audit", async () => {
    await seedFullUserWithTotp(sql, "alice@acme.fr");
    const loginRes = await fetch(`${app.url}/auth/login`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ email: "alice@acme.fr", password: "Password123!" }),
    });
    const loginBody = (await loginRes.json()) as Record<string, unknown>;

    const verifyRes = await fetch(`${app.url}/auth/mfa/verify`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        mfa_challenge_token: loginBody.mfa_challenge_token,
        code: "000000",
      }),
    });
    expect(verifyRes.status).toBe(401);

    const audit = await sql<{ event_type: string }[]>`
      SELECT event_type FROM auth_audit ORDER BY occurred_at DESC LIMIT 1
    `;
    expect(audit[0]?.event_type).toBe("mfa_failed");
  });

  it("invalid challenge token returns 401", async () => {
    const verifyRes = await fetch(`${app.url}/auth/mfa/verify`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ mfa_challenge_token: "garbage", code: "123456" }),
    });
    expect(verifyRes.status).toBe(401);
  });
});
