import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { hashPassword } from "../../../src/auth/argon2.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("POST /auth/logout", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    app = await buildTestApp({ connectionString: db.url });
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  it("revokes the session and clears cookies", async () => {
    const customerRows = await sql<{ id: string }[]>`
      INSERT INTO customers (siren, legal_name)
      VALUES (${"123456789"}, ${"Acme SARL"})
      RETURNING id
    `;
    const customerId = customerRows[0]?.id;
    if (customerId === undefined) throw new Error("customer");
    const hash = await hashPassword("Password123!");
    // T-CL-03 invariant: full + mfa_mode='none' would 500. Use deposit_simple.
    await sql`
      INSERT INTO users (customer_id, email, password_hash, role)
      VALUES (${customerId}, ${"alice@acme.fr"}, ${hash}, ${"deposit_simple"})
    `;

    const loginRes = await fetch(`${app.url}/auth/login`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ email: "alice@acme.fr", password: "Password123!" }),
    });
    const refreshCookie = loginRes.headers.get("set-cookie") ?? "";
    expect(refreshCookie).toMatch(/_session=/);

    const logoutRes = await fetch(`${app.url}/auth/logout`, {
      method: "POST",
      headers: { cookie: refreshCookie },
    });
    expect(logoutRes.status).toBe(204);

    const cleared = logoutRes.headers.get("set-cookie") ?? "";
    expect(cleared).toMatch(/_session=;/);
    expect(cleared).toMatch(/signup_session=;/);

    const sessions = await sql<{ revoked_at: Date | null }[]>`
      SELECT revoked_at FROM sessions
    `;
    expect(sessions[0]?.revoked_at).not.toBeNull();

    const audit = await sql<{ event_type: string }[]>`
      SELECT event_type FROM auth_audit WHERE event_type = 'logout'
    `;
    expect(audit).toHaveLength(1);
  });

  it("returns 204 even without a valid cookie", async () => {
    const res = await fetch(`${app.url}/auth/logout`, { method: "POST" });
    expect(res.status).toBe(204);
  });
});
