import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { hashPassword, verifyPassword } from "../../../src/auth/argon2.js";
import { MockEmailSender } from "../../../src/email/sender.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

function extractToken(url: string): string {
  const match = /token=([^&]+)/.exec(url);
  const captured = match?.[1];
  if (captured === undefined) throw new Error("no token");
  return decodeURIComponent(captured);
}

async function seedUser(sql: postgres.Sql, email: string, password: string): Promise<string> {
  const customerRows = await sql<{ id: string }[]>`
    INSERT INTO customers (siren, legal_name) VALUES (${"123456789"}, ${"Acme"})
    RETURNING id
  `;
  const cId = customerRows[0]?.id;
  if (cId === undefined) throw new Error("customer");
  const hash = await hashPassword(password);
  const userRows = await sql<{ id: string }[]>`
    INSERT INTO users (customer_id, email, password_hash, role)
    VALUES (${cId}, ${email}, ${hash}, ${"deposit_simple"})
    RETURNING id
  `;
  const uid = userRows[0]?.id;
  if (uid === undefined) throw new Error("user");
  return uid;
}

describe.skipIf(!enabled)("Password reset (request + complete)", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;
  let email: MockEmailSender;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    email = new MockEmailSender();
    app = await buildTestApp({ connectionString: db.url, emailSender: email });
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    email.reset();
  });

  it("request sends a magic link to a known email", async () => {
    await seedUser(sql, "alice@acme.fr", "OldPass123!");

    const res = await fetch(`${app.url}/auth/password-reset/request`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ email: "alice@acme.fr" }),
    });
    expect(res.status).toBe(204);

    const captured = email.lastSentTo("alice@acme.fr");
    expect(captured?.purpose).toBe("password_reset");
    expect(captured?.payload.magic_link).toMatch(/\/reset-password\?token=/);
  });

  it("request returns 204 with no email when the user does not exist (anti-énum)", async () => {
    const res = await fetch(`${app.url}/auth/password-reset/request`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ email: "ghost@acme.fr" }),
    });
    expect(res.status).toBe(204);
    expect(email.lastSentTo("ghost@acme.fr")).toBeUndefined();

    const audit = await sql<{ event_type: string; metadata: Record<string, unknown> }[]>`
      SELECT event_type, metadata FROM auth_audit ORDER BY occurred_at DESC LIMIT 1
    `;
    expect(audit[0]?.event_type).toBe("password_reset_request");
    expect(audit[0]?.metadata.reason).toBe("no_user");
  });

  it("complete sets a new password and sends notification", async () => {
    const userId = await seedUser(sql, "alice@acme.fr", "OldPass123!");

    await fetch(`${app.url}/auth/password-reset/request`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ email: "alice@acme.fr" }),
    });
    const token = extractToken(email.lastSentTo("alice@acme.fr")?.payload.magic_link ?? "");
    email.reset();

    const res = await fetch(`${app.url}/auth/password-reset/complete`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ token, password: "BrandNew1!@#" }),
    });
    expect(res.status).toBe(204);

    const userRows = await sql<{ password_hash: string }[]>`
      SELECT password_hash FROM users WHERE id = ${userId}
    `;
    const newHash = userRows[0]?.password_hash;
    if (newHash === undefined) throw new Error("user");
    expect(await verifyPassword(newHash, "BrandNew1!@#")).toBe(true);
    expect(await verifyPassword(newHash, "OldPass123!")).toBe(false);

    expect(email.lastSentTo("alice@acme.fr")?.purpose).toBe("password_changed");
  });

  it("complete with re-used token → 410 (hash marker mismatch)", async () => {
    await seedUser(sql, "alice@acme.fr", "OldPass123!");

    await fetch(`${app.url}/auth/password-reset/request`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ email: "alice@acme.fr" }),
    });
    const token = extractToken(email.lastSentTo("alice@acme.fr")?.payload.magic_link ?? "");

    const first = await fetch(`${app.url}/auth/password-reset/complete`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ token, password: "BrandNew1!@#" }),
    });
    expect(first.status).toBe(204);

    const replay = await fetch(`${app.url}/auth/password-reset/complete`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ token, password: "OtherOne1!@#" }),
    });
    expect(replay.status).toBe(410);
  });

  it("complete with garbage token → 410", async () => {
    const res = await fetch(`${app.url}/auth/password-reset/complete`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ token: "garbage", password: "BrandNew1!@#" }),
    });
    expect(res.status).toBe(410);
  });

  it("complete with weak password → 400", async () => {
    await seedUser(sql, "alice@acme.fr", "OldPass123!");
    await fetch(`${app.url}/auth/password-reset/request`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ email: "alice@acme.fr" }),
    });
    const token = extractToken(email.lastSentTo("alice@acme.fr")?.payload.magic_link ?? "");

    const res = await fetch(`${app.url}/auth/password-reset/complete`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ token, password: "weak" }),
    });
    expect(res.status).toBe(400);
  });
});
