import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { hashPassword } from "../../../src/auth/argon2.js";
import { generateRecoveryCodes } from "../../../src/auth/recovery.js";
import { MockEmailSender } from "../../../src/email/sender.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("MFA reset paths", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    app = await buildTestApp({ connectionString: db.url, emailSender: new MockEmailSender() });
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  it("Full + mfa_mode='none' + reset_required=false → 500 invariant_violation", async () => {
    const customerRows = await sql<{ id: string }[]>`
      INSERT INTO customers (siren, legal_name) VALUES (${"123456789"}, ${"Acme"}) RETURNING id
    `;
    const cId = customerRows[0]?.id;
    if (cId === undefined) throw new Error("customer");
    const hash = await hashPassword("Password123!");
    await sql`
      INSERT INTO users (customer_id, email, password_hash, role)
      VALUES (${cId}, ${"alice@acme.fr"}, ${hash}, ${"full"})
    `;

    const res = await fetch(`${app.url}/auth/login`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ email: "alice@acme.fr", password: "Password123!" }),
    });
    expect(res.status).toBe(500);

    const audit = await sql<{ event_type: string; metadata: Record<string, unknown> }[]>`
      SELECT event_type, metadata FROM auth_audit ORDER BY occurred_at DESC LIMIT 1
    `;
    expect(audit[0]?.event_type).toBe("invariant_violation");
    expect(audit[0]?.metadata.invariant).toBe("full_user_without_mfa");
  });

  it("Login with mfa_reset_required=true returns mfa_reset_required + reset_token", async () => {
    const customerRows = await sql<{ id: string }[]>`
      INSERT INTO customers (siren, legal_name) VALUES (${"123456789"}, ${"Acme"}) RETURNING id
    `;
    const cId = customerRows[0]?.id;
    if (cId === undefined) throw new Error("customer");
    const hash = await hashPassword("Password123!");
    await sql`
      INSERT INTO users (customer_id, email, password_hash, role, mfa_reset_required)
      VALUES (${cId}, ${"alice@acme.fr"}, ${hash}, ${"full"}, ${true})
    `;

    const res = await fetch(`${app.url}/auth/login`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ email: "alice@acme.fr", password: "Password123!" }),
    });
    expect(res.status).toBe(200);
    const body = (await res.json()) as Record<string, unknown>;
    expect(body.state).toBe("mfa_reset_required");
    expect(typeof body.reset_token).toBe("string");
    // No refresh cookie at this stage.
    expect(res.headers.get("set-cookie")).toBeNull();
  });

  it("/auth/mfa/reset-via-recovery consumes recovery code, clears MFA, sets flag", async () => {
    const customerRows = await sql<{ id: string }[]>`
      INSERT INTO customers (siren, legal_name) VALUES (${"123456789"}, ${"Acme"}) RETURNING id
    `;
    const cId = customerRows[0]?.id;
    if (cId === undefined) throw new Error("customer");
    const password_hash = await hashPassword("Password123!");
    const { plain, hashed } = await generateRecoveryCodes();

    await sql`
      INSERT INTO users (
        customer_id, email, password_hash, mfa_mode, recovery_codes_hashed, role
      ) VALUES (
        ${cId}, ${"alice@acme.fr"}, ${password_hash},
        ${"email"}, ${hashed}, ${"full"}
      )
    `;

    // Login → mfa_required (we don't fulfill it via OTP here; we use a
    // direct seeded access token via signing — simpler than chasing OTPs).
    // Actually, simpler: the recovery code reset endpoint requires a
    // bearer token, so we get one by going through the login + mfa/verify
    // recovery path for a different recovery code.
    const loginRes = await fetch(`${app.url}/auth/login`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ email: "alice@acme.fr", password: "Password123!" }),
    });
    const loginBody = (await loginRes.json()) as Record<string, unknown>;
    const firstCode = plain[0];
    if (firstCode === undefined) throw new Error("recovery");

    const verifyRes = await fetch(`${app.url}/auth/mfa/verify`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        mfa_challenge_token: loginBody.mfa_challenge_token,
        recovery_code: firstCode,
      }),
    });
    expect(verifyRes.status).toBe(200);
    const verifyBody = (await verifyRes.json()) as { access_token: string };

    // Now use the access token to call /auth/mfa/reset-via-recovery with
    // a second recovery code. (mfa_secret is already cleared by the prior
    // step, but the endpoint still validates the recovery code consume.)
    const secondCode = plain[1];
    if (secondCode === undefined) throw new Error("recovery 2");
    const resetRes = await fetch(`${app.url}/auth/mfa/reset-via-recovery`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        authorization: `Bearer ${verifyBody.access_token}`,
      },
      body: JSON.stringify({ recovery_code: secondCode }),
    });
    expect(resetRes.status).toBe(204);

    const users = await sql<
      { mfa_mode: string; mfa_reset_required: boolean; recovery_codes_hashed: string[] | null }[]
    >`SELECT mfa_mode, mfa_reset_required, recovery_codes_hashed FROM users`;
    const u = users[0];
    if (u === undefined) throw new Error("user");
    expect(u.mfa_mode).toBe("none");
    expect(u.mfa_reset_required).toBe(true);
    // 10 - 2 consumed = 8 remaining.
    expect(u.recovery_codes_hashed).toHaveLength(8);
  });

  it("/auth/mfa/reset-via-recovery without bearer returns 401", async () => {
    const res = await fetch(`${app.url}/auth/mfa/reset-via-recovery`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ recovery_code: "abcd-efab-1234" }),
    });
    expect(res.status).toBe(401);
  });
});
