import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("POST /auth/signup", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    app = await buildTestApp({ connectionString: db.url });
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  it("creates a signup_pending row and returns 201 with current_step=siren", async () => {
    const res = await fetch(`${app.url}/auth/signup`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        email: "alice@acme.fr",
        password: "Password123!",
        terms_accepted: true,
      }),
    });
    expect(res.status).toBe(201);
    const body = (await res.json()) as Record<string, unknown>;
    expect(body.state).toBe("pending");
    expect(body.current_step).toBe("siren");

    const setCookie = res.headers.get("set-cookie");
    expect(setCookie).toMatch(/signup_session=/);
    expect(setCookie).toMatch(/HttpOnly/);
    expect(setCookie).toMatch(/SameSite=Lax/i);

    const rows = await sql<{ email: string; is_decoy: boolean }[]>`
      SELECT email, is_decoy FROM signup_pending
    `;
    expect(rows).toHaveLength(1);
    expect(rows[0]?.email).toBe("alice@acme.fr");
    expect(rows[0]?.is_decoy).toBe(false);

    const audit = await sql<{ event_type: string; success: boolean }[]>`
      SELECT event_type, success FROM auth_audit
    `;
    expect(audit).toHaveLength(1);
    expect(audit[0]?.event_type).toBe("signup_success");
    expect(audit[0]?.success).toBe(true);
  });

  it("normalizes email to lowercase", async () => {
    const res = await fetch(`${app.url}/auth/signup`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        email: "Bob@Acme.fr",
        password: "Password123!",
        terms_accepted: true,
      }),
    });
    expect(res.status).toBe(201);

    const rows = await sql<{ email: string }[]>`SELECT email FROM signup_pending`;
    expect(rows[0]?.email).toBe("bob@acme.fr");
  });

  it("creates a decoy when the email is already a confirmed user (anti-enumeration)", async () => {
    // Seed a customer + user with the same email.
    const customerRows = await sql<{ id: string }[]>`
      INSERT INTO customers (siren, legal_name)
      VALUES (${"123456789"}, ${"Acme SARL"})
      RETURNING id
    `;
    const customerId = customerRows[0]?.id;
    if (customerId === undefined) throw new Error("customer not created");
    await sql`
      INSERT INTO users (customer_id, email, password_hash, role)
      VALUES (${customerId}, ${"alice@acme.fr"}, ${"argon2id$dummy"}, ${"full"})
    `;

    const res = await fetch(`${app.url}/auth/signup`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        email: "alice@acme.fr",
        password: "Password123!",
        terms_accepted: true,
      }),
    });
    expect(res.status).toBe(201); // identical UI response
    const body = (await res.json()) as Record<string, unknown>;
    expect(body.state).toBe("pending");
    expect(body.current_step).toBe("siren");

    const rows = await sql<{ is_decoy: boolean }[]>`
      SELECT is_decoy FROM signup_pending WHERE email = ${"alice@acme.fr"}
    `;
    expect(rows).toHaveLength(1);
    expect(rows[0]?.is_decoy).toBe(true);

    const audit = await sql<{ event_type: string; metadata: Record<string, unknown> }[]>`
      SELECT event_type, metadata FROM auth_audit
    `;
    expect(audit[0]?.event_type).toBe("signup_failed");
    expect(audit[0]?.metadata.reason).toBe("email_exists");
  });

  it("rejects malformed payload with 400 neutral message", async () => {
    // PRD §5.1 US-AUTH-001 requires uppercase + digit + special. Lowercase
    // is NOT explicitly required, so only those three rules are tested.
    const cases = [
      { email: "not-an-email", password: "Password123!", terms_accepted: true },
      { email: "ok@a.fr", password: "short", terms_accepted: true },
      { email: "ok@a.fr", password: "passwordnocaps123!", terms_accepted: true },
      { email: "ok@a.fr", password: "PasswordNoDigit!", terms_accepted: true },
      { email: "ok@a.fr", password: "PasswordNoSymbol1", terms_accepted: true },
      { email: "ok@a.fr", password: "Password123!", terms_accepted: false },
      { email: "ok@a.fr", password: "Password123!" },
    ];
    for (const body of cases) {
      const res = await fetch(`${app.url}/auth/signup`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body),
      });
      expect(res.status).toBe(400);
      const json = (await res.json()) as Record<string, unknown>;
      expect(json.message).toBe("Vérifiez vos informations.");
    }

    const rows = await sql<{ count: string }[]>`SELECT COUNT(*)::text AS count FROM signup_pending`;
    expect(Number(rows[0]?.count ?? "0")).toBe(0);
  });
});
