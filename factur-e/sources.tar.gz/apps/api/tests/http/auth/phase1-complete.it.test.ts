import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { hashPassword } from "../../../src/auth/argon2.js";
import { decrypt } from "../../../src/auth/encryption.js";
import { currentTotpCode } from "../../../src/auth/totp.js";
import { MockEmailSender } from "../../../src/email/sender.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

interface SignupContext {
  cookie: string;
  signupId: string;
}

async function fullPhase1(
  url: string,
  sql: postgres.Sql,
  email: string,
  prefilled: Record<string, unknown>,
): Promise<SignupContext> {
  const signupRes = await fetch(`${url}/auth/signup`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ email, password: "Password123!", terms_accepted: true }),
  });
  const cookie = signupRes.headers.get("set-cookie");
  if (cookie === null) throw new Error("cookie");

  // Seed the prerequisites the route layer doesn't yet expose endpoints for
  // (T-CL-04 + T-CL-05 will fill them via real flows).
  await sql`
    UPDATE signup_pending
    SET siren = ${"123456789"},
        siret = ${"12345678900015"},
        customer_data_prefilled = ${sql.json(prefilled as postgres.JSONValue)},
        email_verified_at = NOW(),
        secondary_email = ${"alice.backup@acme.fr"},
        secondary_email_verified_at = NOW()
    WHERE email = ${email}
  `;

  await fetch(`${url}/auth/phase1/mfa/choose`, {
    method: "POST",
    headers: { "content-type": "application/json", cookie },
    body: JSON.stringify({ mode: "totp" }),
  });

  const rows = await sql<{ id: string; mfa_secret_pending: Buffer | null }[]>`
    SELECT id, mfa_secret_pending FROM signup_pending WHERE email = ${email}
  `;
  const r = rows[0];
  if (!r?.mfa_secret_pending) throw new Error("setup failed");
  const code = currentTotpCode(decrypt(r.mfa_secret_pending));

  await fetch(`${url}/auth/phase1/mfa/verify`, {
    method: "POST",
    headers: { "content-type": "application/json", cookie },
    body: JSON.stringify({ code }),
  });

  return { cookie, signupId: r.id };
}

describe.skipIf(!enabled)("POST /auth/phase1/recovery-codes/ack (finalize)", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    app = await buildTestApp({ connectionString: db.url, emailSender: new MockEmailSender() });
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  it("happy path → INSERT customer + user + DELETE signup_pending + access token", async () => {
    const { cookie } = await fullPhase1(app.url, sql, "alice@acme.fr", {
      legal_name: "Acme SARL",
      naf_code: "6201Z",
      address: { street: "1 rue de la Paix", zip: "75002", city: "Paris", country_code: "FR" },
    });

    const res = await fetch(`${app.url}/auth/phase1/recovery-codes/ack`, {
      method: "POST",
      headers: { "content-type": "application/json", cookie },
      body: JSON.stringify({ ack: true }),
    });
    expect(res.status).toBe(200);
    const body = (await res.json()) as Record<string, unknown>;
    expect(typeof body.access_token).toBe("string");
    expect(body.expires_in).toBe(60 * 15);

    const setCookie = res.headers.get("set-cookie") ?? "";
    expect(setCookie).toMatch(/_session=/);
    expect(setCookie).toMatch(/signup_session=;/);

    const customers = await sql<
      { siren: string; legal_name: string }[]
    >`SELECT siren, legal_name FROM customers`;
    expect(customers).toHaveLength(1);
    expect(customers[0]?.siren).toBe("123456789");
    expect(customers[0]?.legal_name).toBe("Acme SARL");

    const users = await sql<
      { role: string; can_purchase: boolean; mfa_mode: string }[]
    >`SELECT role, can_purchase, mfa_mode FROM users`;
    expect(users[0]?.role).toBe("full");
    expect(users[0]?.can_purchase).toBe(true);
    expect(users[0]?.mfa_mode).toBe("totp");

    const remaining = await sql<
      { count: string }[]
    >`SELECT COUNT(*)::text AS count FROM signup_pending`;
    expect(Number(remaining[0]?.count ?? "0")).toBe(0);

    const audit = await sql<{ event_type: string }[]>`
      SELECT event_type FROM auth_audit ORDER BY occurred_at
    `;
    expect(audit.map((a) => a.event_type)).toContain("signup_completed");
  });

  it("decoy (email already a user) returns 401 neutral and silently deletes the row", async () => {
    // Seed a real user with the same email beforehand.
    const customerRows = await sql<{ id: string }[]>`
      INSERT INTO customers (siren, legal_name) VALUES (${"999999999"}, ${"Existing"})
      RETURNING id
    `;
    const cId = customerRows[0]?.id;
    if (cId === undefined) throw new Error("customer");
    const hash = await hashPassword("Password123!");
    await sql`
      INSERT INTO users (customer_id, email, password_hash, role)
      VALUES (${cId}, ${"alice@acme.fr"}, ${hash}, ${"deposit_simple"})
    `;

    const { cookie } = await fullPhase1(app.url, sql, "alice@acme.fr", {
      legal_name: "Acme",
      naf_code: "6201Z",
      address: {},
    });
    // The signup row is now marked is_decoy=true via signup route.
    const res = await fetch(`${app.url}/auth/phase1/recovery-codes/ack`, {
      method: "POST",
      headers: { "content-type": "application/json", cookie },
      body: JSON.stringify({ ack: true }),
    });
    expect(res.status).toBe(401);
    const body = (await res.json()) as Record<string, unknown>;
    expect(body.message).toBe("Vérifiez vos informations.");

    // Decoy row deleted.
    const rows = await sql<{ count: string }[]>`SELECT COUNT(*)::text AS count FROM signup_pending`;
    expect(Number(rows[0]?.count ?? "0")).toBe(0);

    // Original user untouched.
    const users = await sql<{ count: string }[]>`SELECT COUNT(*)::text AS count FROM users`;
    expect(Number(users[0]?.count ?? "0")).toBe(1);
  });

  it("incomplete (email_verified_at missing) returns 400 with current_step", async () => {
    const signupRes = await fetch(`${app.url}/auth/signup`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        email: "alice@acme.fr",
        password: "Password123!",
        terms_accepted: true,
      }),
    });
    const cookie = signupRes.headers.get("set-cookie");
    if (cookie === null) throw new Error("cookie");

    // Seed all but `email_verified_at` so we trip the `email_verify` step.
    await sql`
      UPDATE signup_pending
      SET siren = ${"123456789"},
          siret = ${"12345678900015"},
          customer_data_prefilled = ${sql.json({ legal_name: "Acme", address: {} })},
          secondary_email = ${"alice.backup@acme.fr"},
          secondary_email_verified_at = NOW(),
          mfa_setup_completed_at = NOW(),
          recovery_codes_pending = ARRAY[${"a"},${"b"},${"c"},${"d"},${"e"},${"f"},${"g"},${"h"},${"i"},${"j"}],
          mfa_mode_choice = ${"email"},
          current_step = ${"recovery_codes"}
      WHERE email = ${"alice@acme.fr"}
    `;

    const res = await fetch(`${app.url}/auth/phase1/recovery-codes/ack`, {
      method: "POST",
      headers: { "content-type": "application/json", cookie },
      body: JSON.stringify({ ack: true }),
    });
    expect(res.status).toBe(400);
    const body = (await res.json()) as Record<string, unknown>;
    expect(body.current_step).toBe("email_verify");
  });
});
