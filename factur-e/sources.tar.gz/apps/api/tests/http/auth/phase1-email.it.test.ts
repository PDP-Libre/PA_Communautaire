import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { MockEmailSender } from "../../../src/email/sender.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

function extractToken(url: string): string {
  const match = /token=([^&]+)/.exec(url);
  const captured = match?.[1];
  if (captured === undefined) throw new Error("no token in url");
  return decodeURIComponent(captured);
}

describe.skipIf(!enabled)("Phase 1 email verify (magic link)", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;
  let email: MockEmailSender;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    email = new MockEmailSender();
    app = await buildTestApp({ connectionString: db.url, emailSender: email });
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    email.reset();
  });

  it("signup auto-triggers a verify magic link to the new email", async () => {
    const res = await fetch(`${app.url}/auth/signup`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        email: "alice@acme.fr",
        password: "Password123!",
        terms_accepted: true,
      }),
    });
    expect(res.status).toBe(201);

    const captured = email.lastSentTo("alice@acme.fr");
    expect(captured?.purpose).toBe("phase1_email_verify_otp");
    expect(captured?.payload.magic_link).toMatch(/\/onboarding\/email-verify\?token=/);
  });

  it("decoy signup auto-triggers a password-reset link to the existing user", async () => {
    // Seed a real user.
    const customerRows = await sql<{ id: string }[]>`
      INSERT INTO customers (siren, legal_name) VALUES (${"123456789"}, ${"Acme"})
      RETURNING id
    `;
    const cId = customerRows[0]?.id;
    if (cId === undefined) throw new Error("customer");
    await sql`
      INSERT INTO users (customer_id, email, password_hash, role)
      VALUES (${cId}, ${"alice@acme.fr"}, ${"$argon2id$dummy"}, ${"deposit_simple"})
    `;

    const res = await fetch(`${app.url}/auth/signup`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        email: "alice@acme.fr",
        password: "Password123!",
        terms_accepted: true,
      }),
    });
    expect(res.status).toBe(201);

    const captured = email.lastSentTo("alice@acme.fr");
    expect(captured?.purpose).toBe("password_reset");
    expect(captured?.payload.magic_link).toMatch(/\/reset-password\?token=/);
  });

  it("verify endpoint consumes the link, sets email_verified_at, advances step", async () => {
    const signupRes = await fetch(`${app.url}/auth/signup`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        email: "alice@acme.fr",
        password: "Password123!",
        terms_accepted: true,
      }),
    });
    expect(signupRes.status).toBe(201);

    const captured = email.lastSentTo("alice@acme.fr");
    const url = captured?.payload.magic_link;
    if (url === undefined) throw new Error("no magic link captured");
    const token = extractToken(url);

    // Brief design §5.1 : SIREN+SIRET doivent être complétés avant que
    // le clic sur le magic link soit accepté. On simule ça en avançant
    // current_step à 'email_verify' (équivalent post-SIRET).
    await sql`UPDATE signup_pending SET current_step = ${"email_verify"}`;

    const verifyRes = await fetch(`${app.url}/auth/phase1/email/verify`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ token }),
    });
    expect(verifyRes.status).toBe(200);
    const body = (await verifyRes.json()) as Record<string, unknown>;
    expect(body.state).toBe("verified");
    expect(body.next_step).toBe("secondary_email");

    const rows = await sql<{ email_verified_at: Date | null; current_step: string }[]>`
      SELECT email_verified_at, current_step FROM signup_pending
    `;
    expect(rows[0]?.email_verified_at).not.toBeNull();
    expect(rows[0]?.current_step).toBe("secondary_email");

    // Re-consume → 410.
    const replay = await fetch(`${app.url}/auth/phase1/email/verify`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ token }),
    });
    expect(replay.status).toBe(410);
  });

  it("verify rejects 409 if SIREN/SIRET pas encore saisis (clic prématuré)", async () => {
    const signupRes = await fetch(`${app.url}/auth/signup`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        email: "early-click@acme.fr",
        password: "Password123!",
        terms_accepted: true,
      }),
    });
    expect(signupRes.status).toBe(201);
    const captured = email.lastSentTo("early-click@acme.fr");
    const token = extractToken(captured?.payload.magic_link ?? "");

    // current_step est encore `siren` (default DB après signup).
    const res = await fetch(`${app.url}/auth/phase1/email/verify`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ token }),
    });
    expect(res.status).toBe(409);
    const rows = await sql<{ email_verified_at: Date | null; current_step: string }[]>`
      SELECT email_verified_at, current_step FROM signup_pending WHERE email = ${"early-click@acme.fr"}
    `;
    // Pas de mutation : current_step inchangé, email pas marqué vérifié.
    expect(rows[0]?.email_verified_at).toBeNull();
    expect(rows[0]?.current_step).toBe("siren");
  });

  it("verify with garbage token → 410", async () => {
    const res = await fetch(`${app.url}/auth/phase1/email/verify`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ token: "not-a-jwt" }),
    });
    expect(res.status).toBe(410);
  });

  it("verify-trigger re-issues a magic link", async () => {
    const signupRes = await fetch(`${app.url}/auth/signup`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        email: "alice@acme.fr",
        password: "Password123!",
        terms_accepted: true,
      }),
    });
    const cookie = signupRes.headers.get("set-cookie") ?? "";
    email.reset();

    const triggerRes = await fetch(`${app.url}/auth/phase1/email/verify-trigger`, {
      method: "POST",
      headers: { "content-type": "application/json", cookie },
      body: JSON.stringify({}),
    });
    expect(triggerRes.status).toBe(204);

    const captured = email.lastSentTo("alice@acme.fr");
    expect(captured?.purpose).toBe("phase1_email_verify_otp");
  });
});
