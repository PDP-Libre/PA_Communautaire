import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { MockEmailSender } from "../../../src/email/sender.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

async function startSignup(url: string): Promise<string> {
  const res = await fetch(`${url}/auth/signup`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      email: "alice@acme.fr",
      password: "Password123!",
      terms_accepted: true,
    }),
  });
  expect(res.status).toBe(201);
  const cookie = res.headers.get("set-cookie");
  if (cookie === null) throw new Error("cookie");
  return cookie;
}

describe.skipIf(!enabled)("Phase 1 secondary email (set + verify)", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;
  let email: MockEmailSender;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    email = new MockEmailSender();
    app = await buildTestApp({ connectionString: db.url, emailSender: email });
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    email.reset();
  });

  it("set sends an OTP to the secondary email and persists it", async () => {
    const cookie = await startSignup(app.url);

    const res = await fetch(`${app.url}/auth/phase1/secondary-email/set`, {
      method: "POST",
      headers: { "content-type": "application/json", cookie },
      body: JSON.stringify({ email: "alice.backup@acme.fr" }),
    });
    expect(res.status).toBe(204);

    const captured = email.lastSentTo("alice.backup@acme.fr");
    expect(captured?.purpose).toBe("phase1_secondary_email_verify_otp");
    expect(captured?.payload.otp_code).toMatch(/^\d{6}$/);

    const rows = await sql<
      { secondary_email: string | null; current_step: string }[]
    >`SELECT secondary_email, current_step FROM signup_pending`;
    expect(rows[0]?.secondary_email).toBe("alice.backup@acme.fr");
    expect(rows[0]?.current_step).toBe("secondary_email");
  });

  it("rejects when secondary equals principal", async () => {
    const cookie = await startSignup(app.url);
    const res = await fetch(`${app.url}/auth/phase1/secondary-email/set`, {
      method: "POST",
      headers: { "content-type": "application/json", cookie },
      body: JSON.stringify({ email: "alice@acme.fr" }),
    });
    expect(res.status).toBe(400);
  });

  it("verify with correct OTP advances current_step to mfa_choice", async () => {
    const cookie = await startSignup(app.url);
    await fetch(`${app.url}/auth/phase1/secondary-email/set`, {
      method: "POST",
      headers: { "content-type": "application/json", cookie },
      body: JSON.stringify({ email: "alice.backup@acme.fr" }),
    });
    const code = email.lastSentTo("alice.backup@acme.fr")?.payload.otp_code;
    if (code === undefined) throw new Error("no code captured");

    const res = await fetch(`${app.url}/auth/phase1/secondary-email/verify`, {
      method: "POST",
      headers: { "content-type": "application/json", cookie },
      body: JSON.stringify({ code }),
    });
    expect(res.status).toBe(204);

    const rows = await sql<
      { secondary_email_verified_at: Date | null; current_step: string }[]
    >`SELECT secondary_email_verified_at, current_step FROM signup_pending`;
    expect(rows[0]?.secondary_email_verified_at).not.toBeNull();
    expect(rows[0]?.current_step).toBe("mfa_choice");
  });

  it("verify with wrong OTP returns 401", async () => {
    const cookie = await startSignup(app.url);
    await fetch(`${app.url}/auth/phase1/secondary-email/set`, {
      method: "POST",
      headers: { "content-type": "application/json", cookie },
      body: JSON.stringify({ email: "alice.backup@acme.fr" }),
    });

    const res = await fetch(`${app.url}/auth/phase1/secondary-email/verify`, {
      method: "POST",
      headers: { "content-type": "application/json", cookie },
      body: JSON.stringify({ code: "000000" }),
    });
    expect(res.status).toBe(401);
  });
});
