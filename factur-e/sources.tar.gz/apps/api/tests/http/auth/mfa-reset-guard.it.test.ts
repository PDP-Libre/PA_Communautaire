import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { hashPassword } from "../../../src/auth/argon2.js";
import { signAccessToken } from "../../../src/auth/jwt.js";
import {
  MFA_GUARD_ALLOWED_UNGUARDED_EXACT,
  MFA_GUARD_ALLOWED_UNGUARDED_PREFIXES,
  MFA_PROTECTED_PREFIXES,
  matchesPrefix,
} from "../../../src/auth/mfa-reset-guard.js";
import { buildApp } from "../../../src/server.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

interface SeedResult {
  customerId: string;
  userId: string;
  bearer: string;
}

async function seedUser(sql: postgres.Sql, mfaResetRequired: boolean): Promise<SeedResult> {
  const customerRows = await sql<{ id: string }[]>`
    INSERT INTO customers (siren, legal_name) VALUES (${"123456789"}, ${"Acme"})
    RETURNING id
  `;
  const customerId = customerRows[0]?.id;
  if (customerId === undefined) throw new Error("customer");
  const hash = await hashPassword("Password123!");
  const userRows = await sql<{ id: string }[]>`
    INSERT INTO users (customer_id, email, password_hash, role, mfa_reset_required)
    VALUES (${customerId}, ${"alice@acme.fr"}, ${hash}, ${"deposit_simple"}, ${mfaResetRequired})
    RETURNING id
  `;
  const userId = userRows[0]?.id;
  if (userId === undefined) throw new Error("user");
  return {
    customerId,
    userId,
    bearer: await signAccessToken({ user_id: userId, customer_id: customerId }),
  };
}

describe.skipIf(!enabled)("mfa_reset_required preHandler guard (T-CL-03 sprint-03)", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    app = await buildTestApp({ connectionString: db.url });
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  it("flag=false → request lands on protected route normally", async () => {
    const seed = await seedUser(sql, false);
    const res = await fetch(`${app.url}/users/me/profile`, {
      method: "PATCH",
      headers: {
        "content-type": "application/json",
        authorization: `Bearer ${seed.bearer}`,
      },
      body: JSON.stringify({ first_name: "Alice", last_name: "Martin" }),
    });
    expect(res.status).toBe(204);
  });

  it("flag=true → 403 {message, code:'mfa_reset_required'} on /users/* route", async () => {
    const seed = await seedUser(sql, true);
    const res = await fetch(`${app.url}/users/me/profile`, {
      method: "PATCH",
      headers: {
        "content-type": "application/json",
        authorization: `Bearer ${seed.bearer}`,
      },
      body: JSON.stringify({ first_name: "Alice", last_name: "Martin" }),
    });
    expect(res.status).toBe(403);
    // NC-15 : enveloppe d'erreur standard `{ message, code }` (remplace
    // l'ancien `{ reason }` sans message).
    const body = (await res.json()) as Record<string, unknown>;
    expect(body.code).toBe("mfa_reset_required");
    expect(typeof body.message).toBe("string");
  });

  it("flag=true → 200 on /auth/me (auth/* stays free for MFA reconfiguration)", async () => {
    const seed = await seedUser(sql, true);
    const res = await fetch(`${app.url}/auth/me`, {
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    expect(res.status).toBe(200);
    const body = (await res.json()) as { state: string; user: { mfa_reset_required: boolean } };
    expect(body.state).toBe("authenticated");
    expect(body.user.mfa_reset_required).toBe(true);
  });

  it("anon (no Bearer) on protected route → guard next() → route 401 (not 403)", async () => {
    // Confirms the guard does not eat anonymous traffic. The route's own
    // 401 must still fire, otherwise we'd leak the existence of the
    // mfa_reset_required state to unauthenticated callers.
    const res = await fetch(`${app.url}/users/me/profile`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ first_name: "X", last_name: "Y" }),
    });
    expect(res.status).toBe(401);
  });

  it("flag=true → /auth/refresh stays reachable (regression guard for /auth/* exemption)", async () => {
    // Belt-and-suspenders: any /auth/* route must pass through the guard
    // regardless of the flag, otherwise the user can't reach
    // /auth/setup-mfa to clear it. /auth/refresh reads the refresh cookie,
    // not the Bearer — sending no cookie yields a 401 from the route,
    // never a 403 from the guard.
    const seed = await seedUser(sql, true);
    const res = await fetch(`${app.url}/auth/refresh`, {
      method: "POST",
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    expect(res.status).not.toBe(403);
  });

  it("flag=true on /invitations admin list → 403 (defensive depth, see C1 retro)", async () => {
    const seed = await seedUser(sql, true);
    const res = await fetch(`${app.url}/invitations`, {
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    expect(res.status).toBe(403);
    const body = (await res.json()) as Record<string, unknown>;
    expect(body.code).toBe("mfa_reset_required");
    expect(typeof body.message).toBe("string");
  });

  it("public /invitations/:token/preview stays reachable for anon (state=anon → guard skip)", async () => {
    // Anon callers must still be able to preview an invitation even
    // when an authenticated user with a pending MFA reset exists in
    // the same DB. The guard's first branch skips on `state !== authenticated`.
    const res = await fetch(`${app.url}/invitations/non-existent-token/preview`);
    // 410 / 404 from the route — definitely not 403.
    expect(res.status).not.toBe(403);
  });

  describe("matchesPrefix() helper", () => {
    it("matches exact + nested paths, rejects same-prefix-different-segment", () => {
      expect(matchesPrefix("/users", "/users")).toBe(true);
      expect(matchesPrefix("/users/me/profile", "/users")).toBe(true);
      expect(matchesPrefix("/users?page=1", "/users")).toBe(true);
      expect(matchesPrefix("/users-foo", "/users")).toBe(false);
      expect(matchesPrefix("/usersbar", "/users")).toBe(false);
      expect(matchesPrefix("/", "/users")).toBe(false);
    });
  });
});

describe.skipIf(!enabled)("route inventory — anti-regression for new top-level prefixes", () => {
  let db: TestDb;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
  });

  afterAll(async () => {
    await db.drop();
  });

  it("every registered route is either guarded or explicitly allow-listed", async () => {
    const fresh = await buildApp({ connectionString: db.url });
    try {
      // `commonPrefix: false` flattens the tree so each line carries an
      // absolute path segment (or a relative continuation). Indentation
      // (`│   `) marks nesting depth.
      //
      // Sample:
      //   ├── /users (GET, HEAD)
      //   │   ├── /me/profile (PATCH)
      //   │   └── /:id (DELETE)
      //   │       └── /role (PATCH)
      //   └── * (OPTIONS)
      const tree = fresh.printRoutes({ commonPrefix: false });
      const lines = tree.split("\n");
      const paths: string[] = [];
      const stack: { depth: number; path: string }[] = [];

      for (const raw of lines) {
        const m = /^([│ ]*)[├└]──\s+(\S+?)(?:\s+\(([\w,\s]+)\))?\s*$/.exec(raw);
        if (m === null) continue;
        const depth = (m[1] ?? "").length;
        const segment = m[2] ?? "";
        const methods = m[3];

        // Pop stack frames at depth ≥ current. The new frame is a child
        // of the deepest remaining frame.
        while (stack.length > 0 && (stack[stack.length - 1]?.depth ?? -1) >= depth) {
          stack.pop();
        }
        const parentPath = stack[stack.length - 1]?.path ?? "";
        const fullPath = parentPath + segment;
        stack.push({ depth, path: fullPath });

        if (methods !== undefined) paths.push(fullPath);
      }

      const guarded = (url: string): boolean =>
        MFA_PROTECTED_PREFIXES.some((p) => matchesPrefix(url, p));
      const allowed = (url: string): boolean => {
        if (MFA_GUARD_ALLOWED_UNGUARDED_EXACT.includes(url as never)) return true;
        if (MFA_GUARD_ALLOWED_UNGUARDED_PREFIXES.some((p) => matchesPrefix(url, p))) return true;
        // CORS preflight handler installed by `@fastify/cors` matches `*`
        // (every method via OPTIONS). Treat as infrastructure, not a
        // business surface — never carries `mfa_reset_required` semantics.
        if (url === "*") return true;
        return false;
      };

      const orphans = paths.filter((u) => !guarded(u) && !allowed(u));
      // The assertion message is the orphan list itself — a future
      // author adding `/invoices/...` sees immediately what to update.
      expect(orphans).toEqual([]);
      // Sanity: catch the case where parsing missed everything silently.
      expect(paths.length).toBeGreaterThan(20);
      expect(paths).toContain("/auth/me");
      expect(paths).toContain("/users");
      expect(paths).toContain("/users/me/profile");
      expect(paths).toContain("/customers/me/profile");
      expect(paths).toContain("/invitations");
    } finally {
      await fresh.close();
    }
  });
});
