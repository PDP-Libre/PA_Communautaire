import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { decrypt } from "../../../src/auth/encryption.js";
import { currentTotpCode } from "../../../src/auth/totp.js";
import { MockEmailSender } from "../../../src/email/sender.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

async function startSignup(url: string, email: string): Promise<string> {
  const res = await fetch(`${url}/auth/signup`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ email, password: "Password123!", terms_accepted: true }),
  });
  expect(res.status).toBe(201);
  const cookie = res.headers.get("set-cookie");
  if (cookie === null) throw new Error("no signup_session cookie");
  return cookie;
}

describe.skipIf(!enabled)("Phase 1 MFA (choose + verify)", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;
  let email: MockEmailSender;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    email = new MockEmailSender();
    app = await buildTestApp({ connectionString: db.url, emailSender: email });
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    email.reset();
  });

  it("TOTP choose returns otpauth_uri + qr_svg and persists encrypted secret", async () => {
    const cookie = await startSignup(app.url, "alice@acme.fr");

    const chooseRes = await fetch(`${app.url}/auth/phase1/mfa/choose`, {
      method: "POST",
      headers: { "content-type": "application/json", cookie },
      body: JSON.stringify({ mode: "totp" }),
    });
    expect(chooseRes.status).toBe(200);
    const body = (await chooseRes.json()) as Record<string, unknown>;
    expect(body.mode).toBe("totp");
    expect(typeof body.otpauth_uri).toBe("string");
    expect(body.otpauth_uri as string).toMatch(/otpauth:\/\/totp/);
    expect(typeof body.qr_svg).toBe("string");
    expect(body.qr_svg as string).toMatch(/<svg/);

    const rows = await sql<
      { current_step: string; mfa_mode_choice: string | null; mfa_secret_pending: Buffer | null }[]
    >`
      SELECT current_step, mfa_mode_choice, mfa_secret_pending FROM signup_pending
    `;
    const r = rows[0];
    if (!r?.mfa_secret_pending) throw new Error("no row");
    expect(r.current_step).toBe("mfa_setup");
    expect(r.mfa_mode_choice).toBe("totp");
    // Decrypt round-trip works.
    const plain = decrypt(r.mfa_secret_pending);
    expect(plain.length).toBe(20);
  });

  it("TOTP verify with correct code generates 10 recovery codes and advances step", async () => {
    const cookie = await startSignup(app.url, "alice@acme.fr");
    await fetch(`${app.url}/auth/phase1/mfa/choose`, {
      method: "POST",
      headers: { "content-type": "application/json", cookie },
      body: JSON.stringify({ mode: "totp" }),
    });

    const rows = await sql<{ mfa_secret_pending: Buffer | null }[]>`
      SELECT mfa_secret_pending FROM signup_pending
    `;
    const encrypted = rows[0]?.mfa_secret_pending;
    if (!encrypted) throw new Error("no secret");
    const secret = decrypt(encrypted);
    const code = currentTotpCode(secret);

    const verifyRes = await fetch(`${app.url}/auth/phase1/mfa/verify`, {
      method: "POST",
      headers: { "content-type": "application/json", cookie },
      body: JSON.stringify({ code }),
    });
    expect(verifyRes.status).toBe(200);
    const body = (await verifyRes.json()) as { recovery_codes: string[] };
    expect(body.recovery_codes).toHaveLength(10);
    for (const c of body.recovery_codes) {
      expect(c).toMatch(/^[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}$/);
    }

    const after = await sql<
      {
        current_step: string;
        mfa_setup_completed_at: Date | null;
        recovery_codes_pending: string[] | null;
      }[]
    >`
      SELECT current_step, mfa_setup_completed_at, recovery_codes_pending FROM signup_pending
    `;
    expect(after[0]?.current_step).toBe("recovery_codes");
    expect(after[0]?.mfa_setup_completed_at).not.toBeNull();
    expect(after[0]?.recovery_codes_pending).toHaveLength(10);
  });

  it("TOTP verify with wrong code returns 401 and no recovery codes", async () => {
    const cookie = await startSignup(app.url, "alice@acme.fr");
    await fetch(`${app.url}/auth/phase1/mfa/choose`, {
      method: "POST",
      headers: { "content-type": "application/json", cookie },
      body: JSON.stringify({ mode: "totp" }),
    });

    const verifyRes = await fetch(`${app.url}/auth/phase1/mfa/verify`, {
      method: "POST",
      headers: { "content-type": "application/json", cookie },
      body: JSON.stringify({ code: "000000" }),
    });
    expect(verifyRes.status).toBe(401);

    const rows = await sql<{ recovery_codes_pending: string[] | null }[]>`
      SELECT recovery_codes_pending FROM signup_pending
    `;
    expect(rows[0]?.recovery_codes_pending).toBeNull();
  });

  it("email mode delivers OTP via mock sender and verifies it", async () => {
    const cookie = await startSignup(app.url, "alice@acme.fr");

    const chooseRes = await fetch(`${app.url}/auth/phase1/mfa/choose`, {
      method: "POST",
      headers: { "content-type": "application/json", cookie },
      body: JSON.stringify({ mode: "email" }),
    });
    expect(chooseRes.status).toBe(200);
    const body = (await chooseRes.json()) as Record<string, unknown>;
    expect(body.mode).toBe("email");
    expect(body.otp_sent_to).toBe("alice@acme.fr");

    const captured = email.lastSentTo("alice@acme.fr");
    expect(captured?.purpose).toBe("phase1_mfa_setup_otp");
    const otp = captured?.payload.otp_code;
    if (otp === undefined) throw new Error("no otp captured");
    expect(otp).toMatch(/^\d{6}$/);

    const verifyRes = await fetch(`${app.url}/auth/phase1/mfa/verify`, {
      method: "POST",
      headers: { "content-type": "application/json", cookie },
      body: JSON.stringify({ code: otp }),
    });
    expect(verifyRes.status).toBe(200);
    const verifyBody = (await verifyRes.json()) as { recovery_codes: string[] };
    expect(verifyBody.recovery_codes).toHaveLength(10);
  });
});
