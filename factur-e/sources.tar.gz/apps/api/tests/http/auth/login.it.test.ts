import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { hashPassword } from "../../../src/auth/argon2.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

async function seedUser(
  sql: postgres.Sql,
  email: string,
  password: string,
  role: "deposit_simple" | "deposit_states" | "full" = "deposit_simple",
): Promise<{ userId: string; customerId: string }> {
  // T-CL-03 invariant: a `full` role with `mfa_mode='none'` and
  // `mfa_reset_required=false` is data corruption (PRD §5.1 US-AUTH-003).
  // Login tests in this file exercise the no-MFA happy path → seed
  // `deposit_simple` by default, which AUTH-3 allows to skip MFA.
  const customerRows = await sql<{ id: string }[]>`
    INSERT INTO customers (siren, legal_name)
    VALUES (${"123456789"}, ${"Acme SARL"})
    RETURNING id
  `;
  const customerId = customerRows[0]?.id;
  if (customerId === undefined) throw new Error("customer not seeded");

  const hash = await hashPassword(password);
  const userRows = await sql<{ id: string }[]>`
    INSERT INTO users (customer_id, email, password_hash, role)
    VALUES (${customerId}, ${email}, ${hash}, ${role})
    RETURNING id
  `;
  const userId = userRows[0]?.id;
  if (userId === undefined) throw new Error("user not seeded");
  return { userId, customerId };
}

describe.skipIf(!enabled)("POST /auth/login", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    app = await buildTestApp({ connectionString: db.url });
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  it("returns 200 with access_token and sets refresh cookie on valid credentials", async () => {
    await seedUser(sql, "alice@acme.fr", "Password123!");

    const res = await fetch(`${app.url}/auth/login`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ email: "alice@acme.fr", password: "Password123!" }),
    });
    expect(res.status).toBe(200);
    const body = (await res.json()) as Record<string, unknown>;
    expect(typeof body.access_token).toBe("string");
    expect(body.expires_in).toBe(60 * 15);

    const setCookie = res.headers.get("set-cookie");
    expect(setCookie).toMatch(/_session=/);
    expect(setCookie).toMatch(/HttpOnly/);
    expect(setCookie).toMatch(/SameSite=Strict/i);

    const sessions = await sql<{ user_id: string }[]>`SELECT user_id FROM sessions`;
    expect(sessions).toHaveLength(1);

    const audit = await sql<{ event_type: string }[]>`
      SELECT event_type FROM auth_audit ORDER BY occurred_at
    `;
    expect(audit.map((a) => a.event_type)).toContain("login_success");
  });

  it("returns 401 with neutral message on wrong password", async () => {
    await seedUser(sql, "alice@acme.fr", "Password123!");

    const res = await fetch(`${app.url}/auth/login`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ email: "alice@acme.fr", password: "WrongPass1!" }),
    });
    expect(res.status).toBe(401);
    const body = (await res.json()) as Record<string, unknown>;
    expect(body.message).toBe("Vérifiez vos informations.");

    const audit = await sql<{ event_type: string; metadata: Record<string, unknown> }[]>`
      SELECT event_type, metadata FROM auth_audit
    `;
    expect(audit[0]?.event_type).toBe("login_failed");
    expect(audit[0]?.metadata.reason).toBe("bad_password");
  });

  it("returns 401 with same neutral message when the user does not exist", async () => {
    const res = await fetch(`${app.url}/auth/login`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ email: "ghost@acme.fr", password: "Password123!" }),
    });
    expect(res.status).toBe(401);
    const body = (await res.json()) as Record<string, unknown>;
    expect(body.message).toBe("Vérifiez vos informations.");
  });

  it("locks out after 5 failed attempts in 15 min", async () => {
    await seedUser(sql, "alice@acme.fr", "Password123!");

    for (let i = 0; i < 5; i++) {
      const r = await fetch(`${app.url}/auth/login`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ email: "alice@acme.fr", password: "Wrong" + String(i) + "!" }),
      });
      expect(r.status).toBe(401);
    }

    // 6th attempt — even with the correct password, must be locked out.
    const res = await fetch(`${app.url}/auth/login`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ email: "alice@acme.fr", password: "Password123!" }),
    });
    expect(res.status).toBe(401);

    const audit = await sql<{ metadata: Record<string, unknown> }[]>`
      SELECT metadata FROM auth_audit
      WHERE event_type = 'login_failed'
      ORDER BY occurred_at DESC LIMIT 1
    `;
    expect(audit[0]?.metadata.reason).toBe("lockout");
  });
});
