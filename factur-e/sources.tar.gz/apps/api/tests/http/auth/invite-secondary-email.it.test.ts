import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { hashPassword } from "../../../src/auth/argon2.js";
import { signAccessToken, verifyMfaResetToken } from "../../../src/auth/jwt.js";
import { MockEmailSender } from "../../../src/email/sender.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

/**
 * T-CL-15 sprint-03 — `/auth/accept-invitation/secondary-email/{set,verify}`
 *
 * Couvre 6 cas requis (brief T-CL-15 + ajustements Bruno A bis) :
 *  1. happy path : set → mail OTP → verify → reset_token signed
 *  2. set refuse `email === primary_email` (400)
 *  3. set throttled : 2 calls dans 5 min → 429 reason='throttled'
 *  4. verify avec OTP faux → 401 NEUTRAL
 *  5. defense in depth : `setup-recovery-ack` refuse 409 si
 *     secondary_email_verified_at IS NULL
 *  6. /auth/me expose secondary_email_set:false avant verify, :true après
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

/** Seed un user *invité* directement en BDD : `mfa_reset_required=TRUE`,
 *  `secondary_email=''`, `secondary_email_verified_at=NULL`. Reproduit
 *  exactement l'état post-`/invitations/:token/accept`. */
async function seedInvitee(
  sql: postgres.Sql,
  email = "invitee@acme.fr",
  args: { role?: "full" | "deposit_simple" | "deposit_states"; canPurchase?: boolean } = {},
): Promise<{ userId: string; customerId: string; bearer: string }> {
  const role = args.role ?? "deposit_simple";
  const canPurchase = args.canPurchase ?? false;
  // SIREN aléatoire pour éviter les collisions UNIQUE entre plusieurs
  // appels seedInvitee dans le même test (cf. setup-context cas 1/2/3).
  const siren = String(100_000_000 + Math.floor(Math.random() * 899_999_999));
  const customerRows = await sql<{ id: string }[]>`
    INSERT INTO customers (siren, legal_name) VALUES (${siren}, ${"Acme Invitee"})
    RETURNING id
  `;
  const customerId = customerRows[0]?.id;
  if (customerId === undefined) throw new Error("customer");
  const hash = await hashPassword("Password123!");
  // Mirror exact de `insertUserFromInvitation` : secondary_email = '',
  // verified_at = NULL (default), mfa_reset_required = TRUE.
  const userRows = await sql<{ id: string }[]>`
    INSERT INTO users (
      customer_id, email, password_hash, role, can_purchase,
      mfa_mode, mfa_reset_required, email_verified_at, terms_accepted_at,
      secondary_email
    ) VALUES (
      ${customerId}, ${email}, ${hash}, ${role}, ${canPurchase},
      ${"none"}, TRUE, NOW(), NOW(), ${""}
    )
    RETURNING id
  `;
  const userId = userRows[0]?.id;
  if (userId === undefined) throw new Error("user");
  const bearer = await signAccessToken({ user_id: userId, customer_id: customerId });
  return { userId, customerId, bearer };
}

describe.skipIf(!enabled)("/auth/accept-invitation/secondary-email/* (T-CL-15)", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;
  let email: MockEmailSender;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    email = new MockEmailSender();
    app = await buildTestApp({ connectionString: db.url, emailSender: email });
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    email.reset();
  });

  it("happy path : set → OTP email → verify → reset_token + secondary_email_set flip", async () => {
    const { userId, bearer } = await seedInvitee(sql);

    // SET
    const setRes = await fetch(`${app.url}/auth/accept-invitation/secondary-email/set`, {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${bearer}` },
      body: JSON.stringify({ email: "invitee.backup@acme.fr" }),
    });
    expect(setRes.status).toBe(204);

    const captured = email.lastSentTo("invitee.backup@acme.fr");
    expect(captured?.purpose).toBe("invite_secondary_email_verify_otp");
    const otp = captured?.payload.otp_code;
    expect(otp).toMatch(/^\d{6}$/);

    // BDD : secondary_email set, mais verified_at toujours NULL.
    const before = await sql<
      { secondary_email: string; secondary_email_verified_at: Date | null }[]
    >`SELECT secondary_email, secondary_email_verified_at FROM users WHERE id = ${userId}`;
    expect(before[0]?.secondary_email).toBe("invitee.backup@acme.fr");
    expect(before[0]?.secondary_email_verified_at).toBeNull();

    // /auth/me reflète secondary_email_set: false
    const meBefore = await fetch(`${app.url}/auth/me`, {
      headers: { authorization: `Bearer ${bearer}` },
    });
    const meBeforeJson = (await meBefore.json()) as {
      user: { secondary_email_set: boolean; mfa_reset_required: boolean };
    };
    expect(meBeforeJson.user.secondary_email_set).toBe(false);
    expect(meBeforeJson.user.mfa_reset_required).toBe(true);

    // VERIFY
    const verifyRes = await fetch(`${app.url}/auth/accept-invitation/secondary-email/verify`, {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${bearer}` },
      body: JSON.stringify({ code: otp }),
    });
    expect(verifyRes.status).toBe(200);
    const verifyJson = (await verifyRes.json()) as { reset_token: string; expires_in: number };
    expect(verifyJson.expires_in).toBeGreaterThan(0);
    const decoded = await verifyMfaResetToken(verifyJson.reset_token);
    expect(decoded.user_id).toBe(userId);

    // BDD : secondary_email_verified_at = NOW(). mfa_reset_required reste TRUE.
    const after = await sql<
      { secondary_email_verified_at: Date | null; mfa_reset_required: boolean }[]
    >`SELECT secondary_email_verified_at, mfa_reset_required FROM users WHERE id = ${userId}`;
    expect(after[0]?.secondary_email_verified_at).not.toBeNull();
    expect(after[0]?.mfa_reset_required).toBe(true);

    // /auth/me reflète secondary_email_set: true
    const meAfter = await fetch(`${app.url}/auth/me`, {
      headers: { authorization: `Bearer ${bearer}` },
    });
    const meAfterJson = (await meAfter.json()) as {
      user: { secondary_email_set: boolean; mfa_reset_required: boolean };
    };
    expect(meAfterJson.user.secondary_email_set).toBe(true);
    expect(meAfterJson.user.mfa_reset_required).toBe(true);
  });

  it("set refuse `secondary === primary` (400)", async () => {
    const { bearer } = await seedInvitee(sql, "invitee@acme.fr");
    const res = await fetch(`${app.url}/auth/accept-invitation/secondary-email/set`, {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${bearer}` },
      body: JSON.stringify({ email: "invitee@acme.fr" }),
    });
    expect(res.status).toBe(400);
  });

  it("set throttled : 2 calls dans 5 min → 429 reason='throttled'", async () => {
    const { bearer } = await seedInvitee(sql);

    const first = await fetch(`${app.url}/auth/accept-invitation/secondary-email/set`, {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${bearer}` },
      body: JSON.stringify({ email: "invitee.backup@acme.fr" }),
    });
    expect(first.status).toBe(204);

    const second = await fetch(`${app.url}/auth/accept-invitation/secondary-email/set`, {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${bearer}` },
      body: JSON.stringify({ email: "invitee.backup2@acme.fr" }),
    });
    expect(second.status).toBe(429);
    const body = (await second.json()) as { reason: string };
    expect(body.reason).toBe("throttled");
  });

  it("verify avec OTP faux → 401 NEUTRAL", async () => {
    const { bearer } = await seedInvitee(sql);

    await fetch(`${app.url}/auth/accept-invitation/secondary-email/set`, {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${bearer}` },
      body: JSON.stringify({ email: "invitee.backup@acme.fr" }),
    });

    const res = await fetch(`${app.url}/auth/accept-invitation/secondary-email/verify`, {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${bearer}` },
      body: JSON.stringify({ code: "000000" }),
    });
    expect(res.status).toBe(401);
  });

  it("defense in depth : setup-recovery-ack refuse 409 si secondary_email_verified_at IS NULL", async () => {
    // Seed invitee, sans passer par secondary-email. Setup MFA puis tente
    // recovery-ack — doit 409 reason='secondary_email_pending'.
    const { userId } = await seedInvitee(sql);

    // Configure manuellement TOTP comme si /setup-choose+/setup-verify avaient
    // tourné. mfa_mode = totp + recovery_codes_hashed set.
    await sql`
      UPDATE users
      SET mfa_mode = 'totp',
          recovery_codes_hashed = ${["dummyhash"]}
      WHERE id = ${userId}
    `;

    // Signe un reset_token comme le flux MFA setup le ferait.
    const { signMfaResetToken } = await import("../../../src/auth/jwt.js");
    const resetToken = await signMfaResetToken({ user_id: userId });

    const res = await fetch(`${app.url}/auth/mfa/setup-recovery-ack`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ reset_token: resetToken, ack: true }),
    });
    expect(res.status).toBe(409);
    const body = (await res.json()) as { reason: string };
    expect(body.reason).toBe("secondary_email_pending");

    // Le user doit rester `mfa_reset_required=TRUE`.
    const u = await sql<
      { mfa_reset_required: boolean }[]
    >`SELECT mfa_reset_required FROM users WHERE id = ${userId}`;
    expect(u[0]?.mfa_reset_required).toBe(true);
  });

  it("set idempotent : re-call si secondary_email_verified_at déjà set → 409 reason='already_verified'", async () => {
    const { userId, bearer } = await seedInvitee(sql);

    // Fast-forward : simule un verify déjà fait directement en BDD.
    await sql`
      UPDATE users
      SET secondary_email = ${"invitee.backup@acme.fr"},
          secondary_email_verified_at = NOW()
      WHERE id = ${userId}
    `;

    const res = await fetch(`${app.url}/auth/accept-invitation/secondary-email/set`, {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${bearer}` },
      body: JSON.stringify({ email: "invitee.backup2@acme.fr" }),
    });
    expect(res.status).toBe(409);
    const body = (await res.json()) as { reason: string };
    expect(body.reason).toBe("already_verified");
  });

  // ────────────────────────────────────────────────────────────────────
  // ADR-006 §D3 — enforcement TOTP-only pour rôles privilégiés (T-CL-15).
  // ────────────────────────────────────────────────────────────────────

  it("setup-choose refuse 403 reason='totp_required' pour un Full qui demande email", async () => {
    const { userId } = await seedInvitee(sql, "full@acme.fr", { role: "full" });
    const { signMfaResetToken } = await import("../../../src/auth/jwt.js");
    const resetToken = await signMfaResetToken({ user_id: userId });

    const res = await fetch(`${app.url}/auth/mfa/setup-choose`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ reset_token: resetToken, mode: "email" }),
    });
    expect(res.status).toBe(403);
    const body = (await res.json()) as { reason: string };
    expect(body.reason).toBe("totp_required");
  });

  it("setup-choose refuse 403 pour un can_purchase=true qui demande email", async () => {
    const { userId } = await seedInvitee(sql, "purchaser@acme.fr", {
      role: "deposit_simple",
      canPurchase: true,
    });
    const { signMfaResetToken } = await import("../../../src/auth/jwt.js");
    const resetToken = await signMfaResetToken({ user_id: userId });

    const res = await fetch(`${app.url}/auth/mfa/setup-choose`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ reset_token: resetToken, mode: "email" }),
    });
    expect(res.status).toBe(403);
    const body = (await res.json()) as { reason: string };
    expect(body.reason).toBe("totp_required");
  });

  it("setup-context retourne requires_totp + is_first_time selon le user", async () => {
    const { signMfaResetToken } = await import("../../../src/auth/jwt.js");

    // Cas 1 : invité Full mfa_mode='none' → requires_totp=true + is_first_time=true.
    const full = await seedInvitee(sql, "full1@acme.fr", { role: "full" });
    const tokenFull = await signMfaResetToken({ user_id: full.userId });
    const resFull = await fetch(`${app.url}/auth/mfa/setup-context`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ reset_token: tokenFull }),
    });
    expect(resFull.status).toBe(200);
    expect(await resFull.json()).toEqual({ requires_totp: true, is_first_time: true });

    // Cas 2 : deposit_simple sans can_purchase mfa_mode='none' → both fields opposite.
    const simple = await seedInvitee(sql, "simple1@acme.fr", { role: "deposit_simple" });
    const tokenSimple = await signMfaResetToken({ user_id: simple.userId });
    const resSimple = await fetch(`${app.url}/auth/mfa/setup-context`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ reset_token: tokenSimple }),
    });
    expect(resSimple.status).toBe(200);
    expect(await resSimple.json()).toEqual({ requires_totp: false, is_first_time: true });

    // Cas 3 : user simulé post-recovery-code (mfa_mode était totp, reset
    // requis) → requires_totp=false + is_first_time=false (re-config).
    await sql`UPDATE users SET mfa_mode = ${"totp"} WHERE id = ${simple.userId}`;
    const resReConfig = await fetch(`${app.url}/auth/mfa/setup-context`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ reset_token: tokenSimple }),
    });
    expect(resReConfig.status).toBe(200);
    expect(await resReConfig.json()).toEqual({ requires_totp: false, is_first_time: false });
  });

  it("setup-choose autorise mode='totp' pour un Full (chemin légitime)", async () => {
    const { userId } = await seedInvitee(sql, "full2@acme.fr", { role: "full" });
    const { signMfaResetToken } = await import("../../../src/auth/jwt.js");
    const resetToken = await signMfaResetToken({ user_id: userId });

    const res = await fetch(`${app.url}/auth/mfa/setup-choose`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ reset_token: resetToken, mode: "totp" }),
    });
    expect(res.status).toBe(200);
    const body = (await res.json()) as { mode: string; otpauth_uri: string; qr_svg: string };
    expect(body.mode).toBe("totp");
    expect(body.otpauth_uri).toMatch(/^otpauth:\/\/totp\//);
    expect(body.qr_svg).toContain("<svg");
  });
});
