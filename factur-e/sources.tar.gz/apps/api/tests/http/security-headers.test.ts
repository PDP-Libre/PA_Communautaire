import { describe, expect, it } from "vitest";

import { buildTestApp } from "../helpers/build-app.js";

describe("Helmet security headers", () => {
  it("sets CSP, X-Frame-Options DENY, X-Content-Type-Options nosniff, Referrer-Policy", async () => {
    const { url, stop } = await buildTestApp();
    try {
      const res = await fetch(`${url}/health`);
      expect(res.status).toBe(200);

      const csp = res.headers.get("content-security-policy") ?? "";
      expect(csp).toContain("default-src 'self'");
      expect(csp).toContain("frame-ancestors 'none'");
      expect(csp).toContain("object-src 'none'");

      expect(res.headers.get("x-frame-options")).toBe("DENY");
      expect(res.headers.get("x-content-type-options")).toBe("nosniff");
      expect(res.headers.get("referrer-policy")).toBe("strict-origin-when-cross-origin");
    } finally {
      await stop();
    }
  });

  it("does not set HSTS in non-production", async () => {
    // NODE_ENV=test in vitest setup — HSTS should be disabled.
    const { url, stop } = await buildTestApp();
    try {
      const res = await fetch(`${url}/health`);
      expect(res.headers.get("strict-transport-security")).toBeNull();
    } finally {
      await stop();
    }
  });
});
