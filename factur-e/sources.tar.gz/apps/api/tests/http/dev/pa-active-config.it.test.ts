import postgres from "postgres";
import { afterAll, afterEach, beforeAll, describe, expect, it } from "vitest";

import { MockPADriver } from "@factur-e/shared-fakes";

import { MemorySecretStore } from "../../../src/secrets/index.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

/**
 * Oracle de l'endpoint `GET /__dev/pa/active-config` (T-CL-REGISTRE-AFNORDRIVER
 * follow-up). Expose la config PA résolue au boot par le registre, consommée
 * par le préflight anti-faux-vert du harness. `buildTestApp` exige Postgres →
 * suite gated `TEST_POSTGRES_URL`.
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("GET /__dev/pa/active-config", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;
  const savedEnv = process.env.PA_ACTIVE_CONFIG;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
    app = await buildTestApp({
      connectionString: db.url,
      paDriver: new MockPADriver(),
      secretStore: new MemorySecretStore(),
    });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  afterEach(() => {
    if (savedEnv === undefined) delete process.env.PA_ACTIVE_CONFIG;
    else process.env.PA_ACTIVE_CONFIG = savedEnv;
  });

  it("défaut (pas d'env) → superpdp-proprietaire", async () => {
    delete process.env.PA_ACTIVE_CONFIG;
    const res = await fetch(`${app.url}/__dev/pa/active-config`);
    expect(res.status).toBe(200);
    const body = (await res.json()) as { paId: string; family: string; driver: string };
    expect(body.paId).toBe("superpdp-proprietaire");
    expect(body.family).toBe("superpdp-proprietary");
    expect(typeof body.driver).toBe("string");
  });

  it("PA_ACTIVE_CONFIG=superpdp-afnor → config AFNOR", async () => {
    process.env.PA_ACTIVE_CONFIG = "superpdp-afnor";
    const res = await fetch(`${app.url}/__dev/pa/active-config`);
    expect(res.status).toBe(200);
    const body = (await res.json()) as { paId: string; family: string };
    expect(body.paId).toBe("superpdp-afnor");
    expect(body.family).toBe("afnor-flow");
  });
});
