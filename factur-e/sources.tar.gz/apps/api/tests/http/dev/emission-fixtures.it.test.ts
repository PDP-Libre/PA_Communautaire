import postgres from "postgres";
import { afterAll, beforeAll, describe, expect, it } from "vitest";

import { MockPADriver } from "@factur-e/shared-fakes";

import { MemorySecretStore } from "../../../src/secrets/index.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

/**
 * Oracle déterministe de l'endpoint `GET /__dev/emission-fixtures[/:id]`
 * (T-CL-HARNESS-SUPERPDP-PROP sprint-10 W0-A) — sert le `form` du corpus au
 * harness `.mjs`. Lecture seule (pas de DB / pas d'auth), mais `buildTestApp`
 * exige une connexion Postgres → suite gated `TEST_POSTGRES_URL`.
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("GET /__dev/emission-fixtures", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
    app = await buildTestApp({
      connectionString: db.url,
      paDriver: new MockPADriver(),
      secretStore: new MemorySecretStore(),
    });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  it("liste les ids du corpus", async () => {
    const res = await fetch(`${app.url}/__dev/emission-fixtures`);
    expect(res.status).toBe(200);
    const body = (await res.json()) as { ids: string[] };
    expect(body.ids).toContain("fx-380-base-iban");
  });

  it("retourne le form (InvoiceForm) d'une fixture connue", async () => {
    const res = await fetch(`${app.url}/__dev/emission-fixtures/fx-380-base-iban`);
    expect(res.status).toBe(200);
    const body = (await res.json()) as {
      id: string;
      form: { document: { number: string }; parties: { buyer: { siren: string } } };
    };
    expect(body.id).toBe("fx-380-base-iban");
    expect(body.form.document.number).toBe("FX-380-BASE-001");
    expect(body.form.parties.buyer.siren).toBe("000000001");
  });

  it("fixture inconnue → 404 + ids disponibles", async () => {
    const res = await fetch(`${app.url}/__dev/emission-fixtures/fx-inexistante`);
    expect(res.status).toBe(404);
    const body = (await res.json()) as { ids: string[] };
    expect(body.ids).toContain("fx-380-base-iban");
  });
});
