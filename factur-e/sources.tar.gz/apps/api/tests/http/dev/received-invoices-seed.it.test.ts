import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { MockPADriver } from "@factur-e/shared-fakes";

import { findIncomingCdarEventsByReceivedInvoiceId } from "../../../src/db/repos/incoming_cdar_events.js";
import {
  findReceivedInvoiceByPaInvoiceIdIn,
  findReceivedInvoiceByPrecedingNumber,
} from "../../../src/db/repos/received_invoices.js";
import { MemorySecretStore } from "../../../src/secrets/index.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";
import { seedInvoiceUser } from "../invoices/_helpers.js";

/**
 * Levier 2 — seed recette réception `__dev/received-invoices/seed { fixtureId }`
 * (T-CL-FIXTURES-RECV-WIRING, GAP-2). DB-direct : INSERT row + fr:204, origine
 * chaînée seedée d'abord, download pré-configuré pour la fiche (R2). Gated
 * Postgres.
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("POST /__dev/received-invoices/seed { fixtureId }", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;
  let secrets: MemorySecretStore;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
    secrets = new MemorySecretStore();
    app = await buildTestApp({
      connectionString: db.url,
      paDriver: new MockPADriver(),
      secretStore: secrets,
    });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  async function seed(fixtureId: string): Promise<Response> {
    return fetch(`${app.url}/__dev/received-invoices/seed`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ user_email: "owner@test.fr", fixtureId }),
    });
  }

  it("rx-380-base-facturx → row 910001 (BQ matché) + event fr:204 + download configuré", async () => {
    const user = await seedInvoiceUser(sql, { secretStore: secrets });
    const res = await seed("rx-380-base-facturx");
    expect(res.status).toBe(200);
    const body = (await res.json()) as { originSeeded: string | null; downloadConfigured: boolean };
    expect(body.originSeeded).toBeNull();
    expect(body.downloadConfigured).toBe(true);

    const row = await findReceivedInvoiceByPaInvoiceIdIn(sql, user.customerId, "910001");
    expect(row?.seller_siren).toBe("000000002");
    expect(row?.total_ttc_cents).toBe(96000);
    expect(row?.supplier_matched).toBe(true);
    expect(row?.invoice_number_extracted).toBe("FX-380-BASE-001");

    const events = await findIncomingCdarEventsByReceivedInvoiceId(sql, row?.id ?? "");
    expect(events.map((e) => e.code)).toEqual(["fr:204"]);
  });

  it("rx-384-rectif-bg3 → origine seedée d'abord, matching BT-25 résout l'origine", async () => {
    const user = await seedInvoiceUser(sql, { secretStore: secrets });
    const res = await seed("rx-384-rectif-bg3");
    expect(res.status).toBe(200);
    const body = (await res.json()) as { originSeeded: string | null };
    expect(body.originSeeded).toBe("rx-380-base-facturx");

    // Les DEUX rows présentes (origine 910001 + rectif 910004).
    expect(await findReceivedInvoiceByPaInvoiceIdIn(sql, user.customerId, "910001")).toBeDefined();
    expect(await findReceivedInvoiceByPaInvoiceIdIn(sql, user.customerId, "910004")).toBeDefined();

    // Le matching origine (clé naturelle seller_siren + BT-25) retrouve
    // l'origine depuis le numéro précédent de la rectificative.
    const origin = await findReceivedInvoiceByPrecedingNumber(
      sql,
      user.customerId,
      "000000002",
      "FX-380-BASE-001",
    );
    expect(origin?.pa_invoice_id_in).toBe("910001");
  });

  it("rx-380-cii-partiel → fournisseur NON identifié + montant null (R8)", async () => {
    const user = await seedInvoiceUser(sql, { secretStore: secrets });
    expect((await seed("rx-380-cii-partiel")).status).toBe(200);
    const row = await findReceivedInvoiceByPaInvoiceIdIn(sql, user.customerId, "910002");
    expect(row?.supplier_matched).toBe(false);
    expect(row?.total_ttc_cents).toBeNull();
    expect(row?.seller_siren).toBe("123456782");
  });

  it("fixtureId inconnu → 404", async () => {
    await seedInvoiceUser(sql, { secretStore: secrets });
    expect((await seed("rx-inexistante")).status).toBe(404);
  });
});
