import postgres from "postgres";
import { afterAll, afterEach, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { MockPADriver } from "@factur-e/shared-fakes";

import { getCursor, upsertCursor } from "../../../src/db/repos/pa_polling_state.js";
import { MemorySecretStore } from "../../../src/secrets/index.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";
import { seedInvoiceUser } from "../invoices/_helpers.js";

/**
 * T-CL-W5 EMIT-FIXS — POST /__dev/pa/reset-cursor. Oracle déterministe du reset
 * de curseur (remplace la procédure SQL manuelle du hotfix R1 ZG-1). Couvre :
 * reset → re-poll repart du cursor initial ; scoping tenant (un reset ne touche
 * QUE le customer ciblé) ; refus en production. Gated Postgres.
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("POST /__dev/pa/reset-cursor", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;
  let secrets: MemorySecretStore;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
    secrets = new MemorySecretStore();
    app = await buildTestApp({
      connectionString: db.url,
      paDriver: new MockPADriver(),
      secretStore: secrets,
    });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  async function reset(body: Record<string, unknown>): Promise<Response> {
    return fetch(`${app.url}/__dev/pa/reset-cursor`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    });
  }

  it("seed cursor → reset → cursor supprimé (re-poll repartira du cursor initial)", async () => {
    const seed = await seedInvoiceUser(sql, { siren: "111111118", email: "owner@test.fr" });
    await upsertCursor(sql, {
      customerId: seed.customerId,
      provider: "superpdp",
      cursor: "42",
      direction: "in",
    });
    expect((await getCursor(sql, seed.customerId, "superpdp", "in"))?.cursor).toBe("42");

    const res = await reset({ user_email: "owner@test.fr", direction: "in" });
    expect(res.status).toBe(200);
    expect((await res.json()) as { deleted: number }).toEqual({ deleted: 1, direction: "in" });

    expect(await getCursor(sql, seed.customerId, "superpdp", "in")).toBeUndefined();
  });

  it("ne touche QUE le tenant ciblé (scoping customer_id)", async () => {
    const a = await seedInvoiceUser(sql, { siren: "111111118", email: "a@test.fr" });
    const b = await seedInvoiceUser(sql, { siren: "222222226", email: "b@test.fr" });
    await upsertCursor(sql, {
      customerId: a.customerId,
      provider: "superpdp",
      cursor: "10",
      direction: "in",
    });
    await upsertCursor(sql, {
      customerId: b.customerId,
      provider: "superpdp",
      cursor: "20",
      direction: "in",
    });

    const res = await reset({ user_email: "b@test.fr", direction: "in" });
    expect(res.status).toBe(200);

    // Le cursor du tenant A reste intact, celui de B est parti.
    expect((await getCursor(sql, a.customerId, "superpdp", "in"))?.cursor).toBe("10");
    expect(await getCursor(sql, b.customerId, "superpdp", "in")).toBeUndefined();
  });

  it("direction 'out' ne supprime pas le cursor 'in' du même tenant", async () => {
    const seed = await seedInvoiceUser(sql, { siren: "111111118", email: "owner@test.fr" });
    await upsertCursor(sql, {
      customerId: seed.customerId,
      provider: "superpdp",
      cursor: "5",
      direction: "in",
    });

    const res = await reset({ user_email: "owner@test.fr", direction: "out" });
    expect(res.status).toBe(200);
    expect((await res.json()) as { deleted: number }).toEqual({ deleted: 0, direction: "out" });
    expect((await getCursor(sql, seed.customerId, "superpdp", "in"))?.cursor).toBe("5");
  });

  it("email inconnu → 404", async () => {
    const res = await reset({ user_email: "nobody@test.fr", direction: "in" });
    expect(res.status).toBe(404);
  });

  it("direction invalide → 400", async () => {
    await seedInvoiceUser(sql, { siren: "111111118", email: "owner@test.fr" });
    const res = await reset({ user_email: "owner@test.fr", direction: "sideways" });
    expect(res.status).toBe(400);
  });

  describe("refus en production", () => {
    let prev: string | undefined;
    beforeEach(() => {
      prev = process.env.NODE_ENV;
      process.env.NODE_ENV = "production";
    });
    afterEach(() => {
      process.env.NODE_ENV = prev;
    });

    it("NODE_ENV=production → 404", async () => {
      const res = await reset({ user_email: "owner@test.fr", direction: "in" });
      expect(res.status).toBe(404);
    });
  });
});
