import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { FX_ORIGIN_INVOICE_ID } from "@factur-e/factur-x-fixtures";
import { MockPADriver } from "@factur-e/shared-fakes";

import { MemorySecretStore } from "../../../src/secrets/index.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";
import { seedInvoiceUser } from "../invoices/_helpers.js";

/**
 * Levier 2 — seed recette nommé `__dev/invoice-drafts/seed { fixtureId }`
 * (T-CL-FIXTURES-WIRING §3.5). Oracle déterministe du chaînage BG-3 : le seed
 * d'un avoir/rectif crée d'abord l'origine fx-380-base-iban à l'id fixe
 * FX_ORIGIN_INVOICE_ID, scopée au customer courant. Gated Postgres.
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("POST /__dev/invoice-drafts/seed { fixtureId }", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;
  let secrets: MemorySecretStore;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
    secrets = new MemorySecretStore();
    app = await buildTestApp({
      connectionString: db.url,
      paDriver: new MockPADriver(),
      secretStore: secrets,
    });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  it("fixtureId conforme simple → brouillon + customer aligné sur le seller", async () => {
    const seed = await seedInvoiceUser(sql, { secretStore: secrets });
    const res = await fetch(`${app.url}/__dev/invoice-drafts/seed`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ user_email: "owner@test.fr", fixtureId: "fx-380-base-iban" }),
    });
    expect(res.status).toBe(200);
    const body = (await res.json()) as { draftId: string; originInvoiceId?: string };
    expect(body.draftId).toBeTruthy();
    expect(body.originInvoiceId).toBeUndefined();

    // Customer aligné sur SELLER_BQ (identité sandbox 000000002 + PMD corpus).
    const rows = await sql<
      { siren: string; iban: string | null; default_invoice_values: Record<string, unknown> }[]
    >`SELECT siren, iban, default_invoice_values FROM customers WHERE id = ${seed.customerId}`;
    expect(rows[0]?.siren).toBe("000000002");
    expect(rows[0]?.iban).toBe("FR7630006000011234567890189");
    expect(rows[0]?.default_invoice_values.late_penalties_mention).toContain("Pénalités de retard");

    // Brouillon stocké avec le payload de la fixture (typeCode 380), mais
    // `issueDate` forcé à AUJOURD'HUI (émission « du jour » → tri liste en tête,
    // pas antidatée par la date figée du corpus).
    const drafts = await sql<{ payload: { document: { number: string; issueDate: string } } }[]>`
      SELECT payload FROM invoice_drafts WHERE id = ${body.draftId}
    `;
    expect(drafts[0]?.payload.document.number).toBe("FX-380-BASE-001");
    expect(drafts[0]?.payload.document.issueDate).toBe(new Date().toISOString().slice(0, 10));
  });

  it("fixtureId avoir 381 → crée l'origine BG-3 à l'id fixe, scopée au customer", async () => {
    const seed = await seedInvoiceUser(sql, { secretStore: secrets });
    const res = await fetch(`${app.url}/__dev/invoice-drafts/seed`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ user_email: "owner@test.fr", fixtureId: "fx-381-avoir-bg3" }),
    });
    expect(res.status).toBe(200);
    const body = (await res.json()) as { draftId: string; originInvoiceId?: string };
    expect(body.originInvoiceId).toBe(FX_ORIGIN_INVOICE_ID);

    const origin = await sql<{ customer_id: string; number: string; type_code: string }[]>`
      SELECT customer_id, number, type_code FROM invoices WHERE id = ${FX_ORIGIN_INVOICE_ID}
    `;
    expect(origin[0]?.customer_id).toBe(seed.customerId);
    expect(origin[0]?.number).toBe("FX-380-BASE-001");
    expect(origin[0]?.type_code).toBe("380");
  });

  it("fixtureId inconnu → 400", async () => {
    await seedInvoiceUser(sql, { secretStore: secrets });
    const res = await fetch(`${app.url}/__dev/invoice-drafts/seed`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ user_email: "owner@test.fr", fixtureId: "fx-inexistante" }),
    });
    expect(res.status).toBe(400);
  });
});
