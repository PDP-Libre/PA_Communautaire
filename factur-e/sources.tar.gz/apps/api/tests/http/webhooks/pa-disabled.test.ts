import { describe, expect, it } from "vitest";

import { buildTestApp } from "../../helpers/build-app.js";

/**
 * T-CL-PA-INVOICE-FIX sprint-04 — Test endpoint webhook PA désactivé V1
 * (ADR-010 v2 + ADR-011).
 *
 * SuperPDP propriétaire et EsaLink n'exposent pas de webhook V1 — le
 * polling cursor global est l'unique canal cycle de vie. La route
 * `POST /api/v1/webhooks/pa` est conservée mais retourne 503 explicite
 * + audit `pa_webhook_received_but_disabled`.
 *
 * Pattern HTTP tests (CLAUDE.md §6.1) : buildApp + fetch natif.
 */

describe("POST /api/v1/webhooks/pa — désactivé V1 (503)", () => {
  it("retourne 503 + body error 'webhook_disabled_v1' + message explicatif", async () => {
    const { url, stop } = await buildTestApp();
    try {
      const res = await fetch(`${url}/api/v1/webhooks/pa`, {
        method: "POST",
        headers: {
          "content-type": "application/json",
          "x-superpdp-signature": "sha256=abc",
        },
        body: JSON.stringify({ flowId: "fid-1", code: "fr:200" }),
      });
      expect(res.status).toBe(503);
      const body = (await res.json()) as { error: string; message: string };
      expect(body.error).toBe("webhook_disabled_v1");
      expect(body.message).toMatch(/désactivé V1/);
    } finally {
      await stop();
    }
  });
});
