import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { MockPADriver } from "@factur-e/shared-fakes";

import { OAUTH_STATE_COOKIE, signOAuthStateToken } from "../../../src/auth/oauth-state.js";
import { insertReceivedInvoice } from "../../../src/db/repos/received_invoices.js";
import { MemorySecretStore } from "../../../src/secrets/index.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";
import { seedFullCustomer } from "../../_fixtures/seed-customer.js";

/**
 * Mécanisme 3 (HTTP) — réconciliation silencieuse SIREN au callback OAuth
 * SuperPDP `verified` (T-CL-SIREN-RECONCILIATION sprint-06 W1, US-PA-005).
 *
 * Vérifie le parcours complet : callback `verified/verified` → clear
 * profil + flags (ADR-007 D2 immédiat, F2) + réconciliation SIREN priorité
 * KYC + audit `pa_identity_siren_reconciled`. Lève le workaround psql
 * historique T-BR-EMIT (NC-13 sprint-04).
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("[oauth/callback] réconciliation SIREN (Mécanisme 3)", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;
  let driver: MockPADriver;
  let secrets: MemorySecretStore;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
    driver = new MockPADriver({ scenario: "verified", paUserId: "pa-user-test" });
    secrets = new MemorySecretStore();
    app = await buildTestApp({
      connectionString: db.url,
      paDriver: driver,
      secretStore: secrets,
    });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    driver.reset();
    driver.setScenario("verified");
    secrets.clear();
  });

  async function hitCallback(customerId: string, userId: string): Promise<Response> {
    const cookie = await signOAuthStateToken({
      state: "fixed-state-r",
      code_verifier: "fixed-verifier-r",
      customer_id: customerId,
      user_id: userId,
      pa_code: "superpdp",
    });
    return fetch(`${app.url}/oauth/superpdp/callback?code=fake-code-r&state=fixed-state-r`, {
      method: "GET",
      redirect: "manual",
      headers: { cookie: `${OAUTH_STATE_COOKIE}=${cookie}` },
    });
  }

  /** pa_connections ACTIVES (non soft-deleted) du customer. */
  async function activePaConnections(customerId: string): Promise<{ id: string }[]> {
    return sql<{ id: string }[]>`
      SELECT id FROM pa_connections
      WHERE customer_id = ${customerId} AND provider = ${"superpdp"} AND deleted_at IS NULL
    `;
  }

  it("mismatch SIREN onboarding INSEE vs KYC → UPDATE priorité KYC + flags + audit", async () => {
    // Onboarding INSEE '000000001' (Tricatel sandbox) + profil non vérifié.
    const seed = await seedFullCustomer(sql, {
      siren: "000000001",
      profileUnverified: true,
      withPaConnection: false,
    });
    // SuperPDP KYC atteste un SIREN différent (via companies/me) + adresse
    // Peppol propre (via directory_entries authentifié).
    driver.setIdentityStatus({ user: "verified", company: "verified" });
    driver.setConnectedCompany({ number: "999999998" });
    driver.setOwnPeppolAddress("0225:999999998_test");

    const res = await hitCallback(seed.customerId, seed.userId);
    expect(res.status).toBe(302);
    expect(res.headers.get("location")).toMatch(/status=connected/);
    // Toast info → param siren=reconciled.
    expect(res.headers.get("location")).toMatch(/siren=reconciled/);

    const cust = await sql<
      {
        siren: string;
        siren_unverified: boolean;
        profile_unverified: boolean;
        directory_address: string | null;
      }[]
    >`
      SELECT siren, siren_unverified, profile_unverified, directory_address
      FROM customers WHERE id = ${seed.customerId}
    `;
    expect(cust[0]?.siren).toBe("999999998");
    expect(cust[0]?.siren_unverified).toBe(false);
    expect(cust[0]?.profile_unverified).toBe(false);
    // Adresse Peppol émetteur résolue via directory_entries (débloque 7.3).
    expect(cust[0]?.directory_address).toBe("0225:999999998_test");

    const audit = await sql<{ event_type: string; metadata: Record<string, unknown> | null }[]>`
      SELECT event_type, metadata FROM auth_audit WHERE customer_id = ${seed.customerId}
    `;
    const types = audit.map((a) => a.event_type);
    expect(types).toContain("pa_identity_siren_reconciled");
    expect(types).toContain("pa_profile_verified");
    const reconciled = audit.find((a) => a.event_type === "pa_identity_siren_reconciled");
    expect(reconciled?.metadata).toMatchObject({
      field: "siren",
      value_before: "000000001",
      value_after: "999999998",
      kyc_source: "superpdp",
    });
  });

  it("SIREN identique → profil cleared mais PAS d'event de réconciliation (crit. 7)", async () => {
    const seed = await seedFullCustomer(sql, {
      siren: "123456789",
      profileUnverified: true,
      withPaConnection: false,
    });
    driver.setIdentityStatus({ user: "verified", company: "verified" });
    driver.setConnectedCompany({ number: "123456789" });

    const res = await hitCallback(seed.customerId, seed.userId);
    expect(res.status).toBe(302);

    const cust = await sql<{ siren: string; profile_unverified: boolean }[]>`
      SELECT siren, profile_unverified FROM customers WHERE id = ${seed.customerId}
    `;
    expect(cust[0]?.siren).toBe("123456789");
    expect(cust[0]?.profile_unverified).toBe(false);

    // Finding F régression — cas nominal verified : pa_connection créée et
    // PRÉSERVÉE (pas de cleanup, pas de blocage).
    expect(await activePaConnections(seed.customerId)).toHaveLength(1);

    const audit = await sql<{ event_type: string }[]>`
      SELECT event_type FROM auth_audit WHERE customer_id = ${seed.customerId}
    `;
    expect(audit.map((a) => a.event_type)).not.toContain("pa_identity_siren_reconciled");
    expect(audit.map((a) => a.event_type)).not.toContain("pa_connection_blocked_cleanup");
  });

  it("callback needs_review → pas de réconciliation, profil reste non vérifié", async () => {
    const seed = await seedFullCustomer(sql, {
      siren: "000000001",
      profileUnverified: true,
      withPaConnection: false,
    });
    // KYC `needs_review` → la réconciliation ne doit PAS se déclencher,
    // même si une société est connue côté companies/me.
    driver.setIdentityStatus({ user: "needs_review", company: "verified" });
    driver.setConnectedCompany({ number: "999999998" });

    const res = await hitCallback(seed.customerId, seed.userId);
    expect(res.status).toBe(302);

    const cust = await sql<{ siren: string; profile_unverified: boolean }[]>`
      SELECT siren, profile_unverified FROM customers WHERE id = ${seed.customerId}
    `;
    // SIREN non touché (réconciliation déclenchée uniquement sur verified/verified).
    expect(cust[0]?.siren).toBe("000000001");
    expect(cust[0]?.profile_unverified).toBe(true);

    // Finding F sécurité — le cleanup pa_connection est STRICTEMENT réservé au
    // blocage SIREN historique : `needs_review` (état transitoire) préserve la
    // pa_connection + n'émet PAS d'audit de cleanup.
    expect(await activePaConnections(seed.customerId)).toHaveLength(1);

    const audit = await sql<{ event_type: string }[]>`
      SELECT event_type FROM auth_audit WHERE customer_id = ${seed.customerId}
    `;
    expect(audit.map((a) => a.event_type)).not.toContain("pa_identity_siren_reconciled");
    expect(audit.map((a) => a.event_type)).not.toContain("pa_connection_blocked_cleanup");
  });

  it("mismatch + historique de factures → BLOCAGE : SIREN inchangé + redirect siren=blocked", async () => {
    const seed = await seedFullCustomer(sql, {
      siren: "000000001",
      profileUnverified: true,
      withPaConnection: false,
    });
    // Historique : une facture reçue en base → changement de SIREN interdit.
    await insertReceivedInvoice(sql, {
      customer_id: seed.customerId,
      pa_invoice_id_in: "in-block-1",
      seller_siren: "123456789",
    });
    driver.setIdentityStatus({ user: "verified", company: "verified" });
    driver.setConnectedCompany({ number: "999999998" });

    const res = await hitCallback(seed.customerId, seed.userId);
    expect(res.status).toBe(302);
    expect(res.headers.get("location")).toMatch(/siren=blocked/);

    // SIREN inchangé (blocage).
    const cust = await sql<{ siren: string }[]>`
      SELECT siren FROM customers WHERE id = ${seed.customerId}
    `;
    expect(cust[0]?.siren).toBe("000000001");

    const audit = await sql<{ event_type: string }[]>`
      SELECT event_type FROM auth_audit WHERE customer_id = ${seed.customerId}
    `;
    const types = audit.map((a) => a.event_type);
    expect(types).toContain("pa_identity_siren_reconcile_blocked");
    expect(types).not.toContain("pa_identity_siren_reconciled");
  });

  it("blocage SIREN historique → déconnexion programmatique PA + audit cleanup (finding F)", async () => {
    const seed = await seedFullCustomer(sql, {
      siren: "000000001",
      profileUnverified: true,
      withPaConnection: false,
    });
    // Historique mixte : 1 facture émise + 1 reçue → blocage + cleanup.
    await insertReceivedInvoice(sql, {
      customer_id: seed.customerId,
      pa_invoice_id_in: "in-block-2",
      seller_siren: "123456789",
    });
    driver.setIdentityStatus({ user: "verified", company: "verified" });
    driver.setConnectedCompany({ number: "999999998" });

    const res = await hitCallback(seed.customerId, seed.userId);
    expect(res.status).toBe(302);
    // L'UI ne doit PAS afficher "Connexion active" : déconnexion programmatique
    // → status=disconnected + l'Alert bloquante (siren=blocked).
    expect(res.headers.get("location")).toMatch(/status=disconnected/);
    expect(res.headers.get("location")).toMatch(/siren=blocked/);

    // pa_connection créée puis SOFT-DELETE (déconnexion programmatique) :
    // plus aucune connexion active.
    expect(await activePaConnections(seed.customerId)).toHaveLength(0);

    // Audit `pa_connection_blocked_cleanup` distinct + payload complet.
    const audit = await sql<{ event_type: string; metadata: Record<string, unknown> | null }[]>`
      SELECT event_type, metadata FROM auth_audit WHERE customer_id = ${seed.customerId}
    `;
    const types = audit.map((a) => a.event_type);
    expect(types).toContain("pa_identity_siren_reconcile_blocked");
    expect(types).toContain("pa_connection_blocked_cleanup");
    const cleanup = audit.find((a) => a.event_type === "pa_connection_blocked_cleanup");
    expect(cleanup?.metadata).toMatchObject({
      blocked_reason: "has_invoice_history",
      kyc_siren: "999999998",
      customer_siren: "000000001",
      invoices_received_count: 1,
    });
    // Le secret bundle est nettoyé + le refresh token révoqué (best-effort).
    expect(driver.counts.revoke).toBeGreaterThanOrEqual(1);
  });
});
