import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { MemorySecretStore } from "../../../src/secrets/index.js";
import { MockPADriver } from "@factur-e/shared-fakes";
import { OAUTH_STATE_COOKIE, signOAuthStateToken } from "../../../src/auth/oauth-state.js";
import { hashPassword } from "../../../src/auth/argon2.js";
import { signAccessToken } from "../../../src/auth/jwt.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

interface Seed {
  customerId: string;
  userId: string;
  bearer: string;
}

async function seedFullUser(sql: postgres.Sql, mfaResetRequired = false): Promise<Seed> {
  const customerRows = await sql<{ id: string }[]>`
    INSERT INTO customers (siren, legal_name) VALUES (${"123456789"}, ${"Acme"})
    RETURNING id
  `;
  const customerId = customerRows[0]?.id ?? "";
  const hash = await hashPassword("Password123!");
  const userRows = await sql<{ id: string }[]>`
    INSERT INTO users (customer_id, email, password_hash, role, mfa_reset_required)
    VALUES (${customerId}, ${"alice@acme.fr"}, ${hash}, ${"full"}, ${mfaResetRequired})
    RETURNING id
  `;
  const userId = userRows[0]?.id ?? "";
  return {
    customerId,
    userId,
    bearer: await signAccessToken({ user_id: userId, customer_id: customerId }),
  };
}

describe.skipIf(!enabled)("OAuth SuperPDP smoke (T-CL-06 sprint-03)", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;
  let driver: MockPADriver;
  let secrets: MemorySecretStore;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
    driver = new MockPADriver({ scenario: "verified", paUserId: "pa-user-test" });
    secrets = new MemorySecretStore();
    app = await buildTestApp({
      connectionString: db.url,
      paDriver: driver,
      secretStore: secrets,
    });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    driver.reset();
    driver.setScenario("verified");
    secrets.clear();
  });

  // ──────────────────────────────────────────────────────────────────
  // Happy paths (6)
  // ──────────────────────────────────────────────────────────────────

  it("authorize returns 302 to SuperPDP + sets oauth_state cookie", async () => {
    const seed = await seedFullUser(sql);
    const res = await fetch(`${app.url}/oauth/superpdp/authorize`, {
      method: "GET",
      redirect: "manual",
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    expect(res.status).toBe(302);
    expect(res.headers.get("location")).toMatch(/\/oauth2\/authorize\?/);
    const setCookie = res.headers.get("set-cookie") ?? "";
    expect(setCookie).toMatch(new RegExp(`${OAUTH_STATE_COOKIE}=`));
    expect(setCookie).toMatch(/HttpOnly/i);
    expect(setCookie).toMatch(/SameSite=Lax/i);
    expect(setCookie).toMatch(/Path=\/oauth\/superpdp\//);
    expect(driver.counts.authorize).toBe(1);
  });

  it("authorize-init (T-CL-08) returns 200 JSON {authorize_url} + sets oauth_state cookie", async () => {
    const seed = await seedFullUser(sql);
    const res = await fetch(`${app.url}/oauth/superpdp/authorize-init`, {
      method: "POST",
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    expect(res.status).toBe(200);
    const body = (await res.json()) as { authorize_url?: string };
    expect(body.authorize_url).toMatch(/\/oauth2\/authorize\?/);
    const setCookie = res.headers.get("set-cookie") ?? "";
    expect(setCookie).toMatch(new RegExp(`${OAUTH_STATE_COOKIE}=`));
    expect(driver.counts.authorize).toBe(1);
  });

  it("authorize-init without auth → 401", async () => {
    const res = await fetch(`${app.url}/oauth/superpdp/authorize-init`, { method: "POST" });
    expect(res.status).toBe(401);
  });

  it("callback exchanges code, persists secret + pa_connections, redirects to SPA", async () => {
    const seed = await seedFullUser(sql);
    // The MockPADriver returns a deterministic state pattern.
    // We simulate /authorize by signing a cookie ourselves.
    const cookie = await signOAuthStateToken({
      state: "fixed-state-1",
      code_verifier: "fixed-verifier-1",
      customer_id: seed.customerId,
      user_id: seed.userId,
      pa_code: "superpdp",
    });
    const res = await fetch(
      `${app.url}/oauth/superpdp/callback?code=fake-code-1&state=fixed-state-1`,
      {
        method: "GET",
        redirect: "manual",
        headers: { cookie: `${OAUTH_STATE_COOKIE}=${cookie}` },
      },
    );
    expect(res.status).toBe(302);
    expect(res.headers.get("location")).toMatch(/parametres\/connexion-pa\?status=connected/);
    const conns = await sql<{ id: string; pa_user_id: string | null }[]>`
      SELECT id, pa_user_id FROM pa_connections WHERE customer_id = ${seed.customerId}
    `;
    expect(conns).toHaveLength(1);
    expect(conns[0]?.pa_user_id).toBe("pa-user-test");
    // SecretStore got the bundle.
    const stored = await secrets.get(`superpdp-bundle-${seed.customerId}`);
    expect(stored?.accessToken).toBeDefined();
    expect(stored?.refreshToken).toBeDefined();
    // Cookie cleared on success.
    const clearCookie = res.headers.get("set-cookie") ?? "";
    expect(clearCookie).toMatch(new RegExp(`${OAUTH_STATE_COOKIE}=;`));
  });

  it("callback with needs_review redirects to SPA with status=needs_review", async () => {
    const seed = await seedFullUser(sql);
    driver.setScenario("needs_review");
    const cookie = await signOAuthStateToken({
      state: "s",
      code_verifier: "v",
      customer_id: seed.customerId,
      user_id: seed.userId,
      pa_code: "superpdp",
    });
    const res = await fetch(`${app.url}/oauth/superpdp/callback?code=c&state=s`, {
      method: "GET",
      redirect: "manual",
      headers: { cookie: `${OAUTH_STATE_COOKIE}=${cookie}` },
    });
    expect(res.status).toBe(302);
    expect(res.headers.get("location")).toMatch(/status=needs_review/);
  });

  it("disconnect revokes via driver, deletes secret, soft-deletes pa_connection", async () => {
    const seed = await seedFullUser(sql);
    // Seed an active connection.
    await secrets.put(`superpdp-bundle-${seed.customerId}`, {
      accessToken: "a",
      refreshToken: "r",
      accessExpiresAt: new Date().toISOString(),
    });
    await sql`
      INSERT INTO pa_connections (customer_id, pa_user_id, secret_ref,
                                   user_identity_verification_status,
                                   company_verification_status)
      VALUES (${seed.customerId}, ${"pa-1"}, ${`superpdp-bundle-${seed.customerId}`},
              ${"verified"}, ${"verified"})
    `;
    const res = await fetch(`${app.url}/oauth/superpdp/disconnect`, {
      method: "POST",
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    expect(res.status).toBe(204);
    expect(driver.counts.revoke).toBe(1);
    expect(await secrets.get(`superpdp-bundle-${seed.customerId}`)).toBeNull();
    const rows = await sql<{ deleted_at: Date | null; revoked_at: Date | null }[]>`
      SELECT deleted_at, revoked_at FROM pa_connections WHERE customer_id = ${seed.customerId}
    `;
    expect(rows[0]?.deleted_at).not.toBeNull();
    expect(rows[0]?.revoked_at).not.toBeNull();
  });

  it("disconnect when nothing connected → 204 (idempotent)", async () => {
    const seed = await seedFullUser(sql);
    const res = await fetch(`${app.url}/oauth/superpdp/disconnect`, {
      method: "POST",
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    expect(res.status).toBe(204);
    expect(driver.counts.revoke).toBe(0);
  });

  it("/pa/status returns connected:true with derived identity_status", async () => {
    const seed = await seedFullUser(sql);
    await sql`
      INSERT INTO pa_connections (customer_id, pa_user_id, secret_ref,
                                   user_identity_verification_status,
                                   company_verification_status)
      VALUES (${seed.customerId}, ${"pa-42"}, ${"ref"}, ${"needs_review"}, ${"verified"})
    `;
    const res = await fetch(`${app.url}/pa/status`, {
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    expect(res.status).toBe(200);
    const body = (await res.json()) as Record<string, unknown>;
    expect(body.connected).toBe(true);
    // Worst-case derivation: needs_review ⊕ verified → needs_review.
    expect(body.identity_status).toBe("needs_review");
    expect(body.user_identity_verification_status).toBe("needs_review");
    expect(body.company_verification_status).toBe("verified");
    expect(body.pa_user_id).toBe("pa-42");
  });

  // ──────────────────────────────────────────────────────────────────
  // Sécu obligatoires (3 — chat décision D2)
  // ──────────────────────────────────────────────────────────────────

  it("callback with state mismatch (cookie state ≠ query state) → 401 + audit fail", async () => {
    const seed = await seedFullUser(sql);
    const cookie = await signOAuthStateToken({
      state: "cookie-state",
      code_verifier: "v",
      customer_id: seed.customerId,
      user_id: seed.userId,
      pa_code: "superpdp",
    });
    const res = await fetch(`${app.url}/oauth/superpdp/callback?code=c&state=different-state`, {
      method: "GET",
      redirect: "manual",
      headers: { cookie: `${OAUTH_STATE_COOKIE}=${cookie}` },
    });
    expect(res.status).toBe(401);
    // Audit row recorded.
    const audit = await sql<{ event_type: string; metadata: Record<string, unknown> | null }[]>`
      SELECT event_type, metadata FROM auth_audit
      WHERE customer_id = ${seed.customerId} AND event_type = ${"pa_connection_failed"}
    `;
    expect(audit).toHaveLength(1);
    expect(audit[0]?.metadata).toMatchObject({ reason: "state_mismatch" });
  });

  it("callback without oauth_state cookie → 401 (no orphan callback possible)", async () => {
    const res = await fetch(`${app.url}/oauth/superpdp/callback?code=c&state=s`, {
      method: "GET",
      redirect: "manual",
    });
    expect(res.status).toBe(401);
  });

  it("authorize without auth → 401 (Bearer required, US-PA-001 Full)", async () => {
    const res = await fetch(`${app.url}/oauth/superpdp/authorize`, {
      method: "GET",
      redirect: "manual",
    });
    expect(res.status).toBe(401);
  });
});
