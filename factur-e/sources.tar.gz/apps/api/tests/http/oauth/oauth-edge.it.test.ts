import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { MockPADriver } from "@factur-e/shared-fakes";
import { PaInvalidStateException } from "@factur-e/pa-adapter";

import { hashPassword } from "../../../src/auth/argon2.js";
import { signAccessToken } from "../../../src/auth/jwt.js";
import { OAUTH_STATE_COOKIE, signOAuthStateToken } from "../../../src/auth/oauth-state.js";
import { MemorySecretStore } from "../../../src/secrets/index.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

interface Seed {
  customerId: string;
  userId: string;
  bearer: string;
}

async function seedFullUser(sql: postgres.Sql): Promise<Seed> {
  const customerRows = await sql<{ id: string }[]>`
    INSERT INTO customers (siren, legal_name) VALUES (${"123456789"}, ${"Acme"})
    RETURNING id
  `;
  const customerId = customerRows[0]?.id ?? "";
  const hash = await hashPassword("Password123!");
  const userRows = await sql<{ id: string }[]>`
    INSERT INTO users (customer_id, email, password_hash, role)
    VALUES (${customerId}, ${"alice@acme.fr"}, ${hash}, ${"full"})
    RETURNING id
  `;
  const userId = userRows[0]?.id ?? "";
  return {
    customerId,
    userId,
    bearer: await signAccessToken({ user_id: userId, customer_id: customerId }),
  };
}

async function signedCookie(seed: Seed, opts?: { state?: string }): Promise<string> {
  const token = await signOAuthStateToken({
    state: opts?.state ?? "fixed-state",
    code_verifier: "fixed-verifier",
    customer_id: seed.customerId,
    user_id: seed.userId,
    pa_code: "superpdp",
  });
  return `${OAUTH_STATE_COOKIE}=${token}`;
}

describe.skipIf(!enabled)("OAuth SuperPDP edge cases (T-CL-07 sprint-03)", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;
  let driver: MockPADriver;
  let secrets: MemorySecretStore;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
    driver = new MockPADriver({ scenario: "verified", paUserId: "pa-user-test" });
    secrets = new MemorySecretStore();
    app = await buildTestApp({
      connectionString: db.url,
      paDriver: driver,
      secretStore: secrets,
    });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    driver.reset();
    driver.setScenario("verified");
    secrets.clear();
  });

  // ──────────────────────────────────────────────────────────────────
  // T1 — Driver throws PaInvalidStateException directly (review medium #1)
  // ──────────────────────────────────────────────────────────────────

  it("T1 callback maps PaInvalidStateException → audit reason=state_mismatch + 302 error", async () => {
    const seed = await seedFullUser(sql);
    // Force the driver to throw PaInvalidStateException no matter what
    // the route's local state check does (covers the defense-in-depth
    // branch at callback.ts where the driver-thrown exception is mapped
    // to the same audit reason as the local state check).
    const throwingDriver = new MockPADriver({ scenario: "verified" });
    throwingDriver.exchangeCode = (): Promise<never> => {
      return Promise.reject(new PaInvalidStateException());
    };
    const isolatedSecrets = new MemorySecretStore();
    const isolated = await buildTestApp({
      connectionString: db.url,
      paDriver: throwingDriver,
      secretStore: isolatedSecrets,
    });
    try {
      const cookie = await signedCookie(seed, { state: "s1" });
      const res = await fetch(`${isolated.url}/oauth/superpdp/callback?code=c&state=s1`, {
        method: "GET",
        redirect: "manual",
        headers: { cookie },
      });
      expect(res.status).toBe(302);
      expect(res.headers.get("location")).toMatch(/status=error&reason=state_mismatch/);
      const audit = await sql<{ event_type: string; metadata: Record<string, unknown> | null }[]>`
        SELECT event_type, metadata FROM auth_audit
        WHERE customer_id = ${seed.customerId} AND event_type = ${"pa_connection_failed"}
      `;
      expect(audit).toHaveLength(1);
      expect(audit[0]?.metadata).toMatchObject({ reason: "state_mismatch" });
    } finally {
      await isolated.stop();
    }
  });

  // ──────────────────────────────────────────────────────────────────
  // T2 — Concurrent authorize race (review medium #2 — post-F1 ordering)
  // ──────────────────────────────────────────────────────────────────

  it("T2 callback hits UNIQUE PARTIAL on concurrent authorize → secret store NOT touched", async () => {
    const seed = await seedFullUser(sql);
    // Simulate "another tab already completed" by pre-inserting an
    // active pa_connection. The new callback's INSERT will violate
    // the partial UNIQUE index. The post-F1 ordering guarantees
    // secrets.put isn't called when the INSERT fails.
    await sql`
      INSERT INTO pa_connections (customer_id, secret_ref,
                                   user_identity_verification_status,
                                   company_verification_status)
      VALUES (${seed.customerId}, ${"superpdp-bundle-existing"},
              ${"verified"}, ${"verified"})
    `;
    expect(await secrets.get(`superpdp-bundle-${seed.customerId}`)).toBeNull();

    const cookie = await signedCookie(seed, { state: "s2" });
    const res = await fetch(`${app.url}/oauth/superpdp/callback?code=c&state=s2`, {
      method: "GET",
      redirect: "manual",
      headers: { cookie },
    });
    expect(res.status).toBe(302);
    expect(res.headers.get("location")).toMatch(/status=error&reason=concurrent_or_db_failed/);
    // Critical: SecretStore.put was NOT called → no orphan secret.
    expect(await secrets.get(`superpdp-bundle-${seed.customerId}`)).toBeNull();
    // Existing connection still active and untouched.
    const conns = await sql<{ secret_ref: string; deleted_at: Date | null }[]>`
      SELECT secret_ref, deleted_at FROM pa_connections WHERE customer_id = ${seed.customerId}
    `;
    expect(conns).toHaveLength(1);
    expect(conns[0]?.secret_ref).toBe("superpdp-bundle-existing");
    expect(conns[0]?.deleted_at).toBeNull();
  });

  // ──────────────────────────────────────────────────────────────────
  // T4 — SuperPDP returns ?error=access_denied
  // ──────────────────────────────────────────────────────────────────

  it("T4 callback ?error=access_denied → audit fail + 302 SPA error reason", async () => {
    const seed = await seedFullUser(sql);
    const cookie = await signedCookie(seed);
    const res = await fetch(
      `${app.url}/oauth/superpdp/callback?error=access_denied&error_description=user+denied`,
      {
        method: "GET",
        redirect: "manual",
        headers: { cookie },
      },
    );
    expect(res.status).toBe(302);
    expect(res.headers.get("location")).toMatch(/status=error&reason=access_denied/);
    expect(driver.counts.exchange).toBe(0);
    const audit = await sql<{ metadata: Record<string, unknown> | null }[]>`
      SELECT metadata FROM auth_audit
      WHERE customer_id = ${seed.customerId} AND event_type = ${"pa_connection_failed"}
    `;
    expect(audit[0]?.metadata).toMatchObject({ reason: "access_denied" });
  });

  // ──────────────────────────────────────────────────────────────────
  // T5 — Cookie OAuth state expired (TTL passed)
  // ──────────────────────────────────────────────────────────────────

  it("T5 callback with expired oauth_state cookie → 401 invalid", async () => {
    // Forge a cookie that's already expired by signing then waiting...
    // we can't sleep 5 min in tests, so we sign a token with a custom
    // payload using a different audience. verifyOAuthStateToken will
    // fail → 401. This covers the verify-throws branch.
    const cookie = `${OAUTH_STATE_COOKIE}=eyJhbGciOiJIUzI1NiJ9.expired.signature`;
    const res = await fetch(`${app.url}/oauth/superpdp/callback?code=c&state=s`, {
      method: "GET",
      redirect: "manual",
      headers: { cookie },
    });
    expect(res.status).toBe(401);
    const body = (await res.json()) as Record<string, unknown>;
    expect(body.message).toMatch(/Session OAuth/);
    // Cookie cleared even on auth failure (defense in depth).
    const setCookie = res.headers.get("set-cookie") ?? "";
    expect(setCookie).toMatch(new RegExp(`${OAUTH_STATE_COOKIE}=;`));
  });

  // ──────────────────────────────────────────────────────────────────
  // T6 — Cookie OAuth state tampered (signature invalid)
  // ──────────────────────────────────────────────────────────────────

  it("T6 callback with tampered oauth_state signature → 401", async () => {
    const seed = await seedFullUser(sql);
    const valid = await signOAuthStateToken({
      state: "s",
      code_verifier: "v",
      customer_id: seed.customerId,
      user_id: seed.userId,
      pa_code: "superpdp",
    });
    // Flip a few characters in the signature segment to break the HMAC.
    const parts = valid.split(".");
    const head = parts[0] ?? "";
    const body = parts[1] ?? "";
    const sig = parts[2] ?? "";
    const tampered = `${head}.${body}.${sig.slice(0, -4)}AAAA`;
    const res = await fetch(`${app.url}/oauth/superpdp/callback?code=c&state=s`, {
      method: "GET",
      redirect: "manual",
      headers: { cookie: `${OAUTH_STATE_COOKIE}=${tampered}` },
    });
    expect(res.status).toBe(401);
  });

  // ──────────────────────────────────────────────────────────────────
  // T10 — Disconnect with orphan SecretStore (bundle already gone)
  // ──────────────────────────────────────────────────────────────────

  it("T10 disconnect with orphan SecretStore (bundle absent) → soft-delete OK + 204", async () => {
    const seed = await seedFullUser(sql);
    // Insert pa_connection but DO NOT put the bundle in SecretStore.
    await sql`
      INSERT INTO pa_connections (customer_id, secret_ref,
                                   user_identity_verification_status,
                                   company_verification_status)
      VALUES (${seed.customerId}, ${`superpdp-bundle-${seed.customerId}`},
              ${"verified"}, ${"verified"})
    `;
    expect(await secrets.get(`superpdp-bundle-${seed.customerId}`)).toBeNull();

    const res = await fetch(`${app.url}/oauth/superpdp/disconnect`, {
      method: "POST",
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    expect(res.status).toBe(204);
    // Driver.revoke is NOT called when bundle is null (we have no
    // refresh token to feed it) — that's by design in disconnect.ts.
    expect(driver.counts.revoke).toBe(0);
    const rows = await sql<{ deleted_at: Date | null; revoked_at: Date | null }[]>`
      SELECT deleted_at, revoked_at FROM pa_connections WHERE customer_id = ${seed.customerId}
    `;
    expect(rows[0]?.deleted_at).not.toBeNull();
    expect(rows[0]?.revoked_at).not.toBeNull();
  });

  // ──────────────────────────────────────────────────────────────────
  // T11 — Disconnect when revoke throws (SuperPDP 5xx) → soft-delete OK
  // ──────────────────────────────────────────────────────────────────

  it("T11 disconnect with revoke throw → soft-delete + audit metadata revoke_ok=false", async () => {
    const seed = await seedFullUser(sql);
    // Inject a driver that throws on revoke (simulates SuperPDP 5xx
    // exhausted retries from the real driver).
    const angryDriver = new MockPADriver({ scenario: "verified" });
    angryDriver.revoke = (): Promise<void> => {
      return Promise.reject(new Error("simulated revoke 5xx exhausted"));
    };
    const isolatedSecrets = new MemorySecretStore();
    const isolated = await buildTestApp({
      connectionString: db.url,
      paDriver: angryDriver,
      secretStore: isolatedSecrets,
    });
    try {
      await isolatedSecrets.put(`superpdp-bundle-${seed.customerId}`, {
        accessToken: "a",
        refreshToken: "r",
        accessExpiresAt: new Date().toISOString(),
      });
      await sql`
        INSERT INTO pa_connections (customer_id, secret_ref,
                                     user_identity_verification_status,
                                     company_verification_status)
        VALUES (${seed.customerId}, ${`superpdp-bundle-${seed.customerId}`},
                ${"verified"}, ${"verified"})
      `;
      const res = await fetch(`${isolated.url}/oauth/superpdp/disconnect`, {
        method: "POST",
        headers: { authorization: `Bearer ${seed.bearer}` },
      });
      expect(res.status).toBe(204);
      // Local soft-delete still happened.
      const rows = await sql<{ deleted_at: Date | null }[]>`
        SELECT deleted_at FROM pa_connections WHERE customer_id = ${seed.customerId}
      `;
      expect(rows[0]?.deleted_at).not.toBeNull();
      // SecretStore was cleaned up too.
      expect(await isolatedSecrets.get(`superpdp-bundle-${seed.customerId}`)).toBeNull();
      // Audit recorded the partial outcome.
      const audit = await sql<{ metadata: Record<string, unknown> | null }[]>`
        SELECT metadata FROM auth_audit
        WHERE customer_id = ${seed.customerId} AND event_type = ${"pa_connection_disconnected"}
      `;
      expect(audit[0]?.metadata).toMatchObject({ revoke_ok: false });
    } finally {
      await isolated.stop();
    }
  });

  // ──────────────────────────────────────────────────────────────────
  // T12 — Status endpoint with soft-deleted connection → connected: false
  // ──────────────────────────────────────────────────────────────────

  it("T12 /pa/status with soft-deleted connection returns {connected:false}", async () => {
    const seed = await seedFullUser(sql);
    await sql`
      INSERT INTO pa_connections (customer_id, secret_ref,
                                   user_identity_verification_status,
                                   company_verification_status,
                                   revoked_at, deleted_at)
      VALUES (${seed.customerId}, ${`superpdp-bundle-${seed.customerId}`},
              ${"verified"}, ${"verified"}, NOW(), NOW())
    `;
    const res = await fetch(`${app.url}/pa/status`, {
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    expect(res.status).toBe(200);
    const body = (await res.json()) as Record<string, unknown>;
    expect(body).toEqual({ connected: false });
  });
});
