import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { hashPassword } from "../../../src/auth/argon2.js";
import { signAccessToken } from "../../../src/auth/jwt.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

/**
 * T-CL-12 sprint-03 — CRUD /api/products + soft-delete + warnings.
 *
 * 14 cas représentatifs (brief T-CL-12 §Tests 8 cas minimum) :
 *  - CRUD happy path (create + read + update + soft-delete + list).
 *  - Warning duplicate_internal_code (create + update).
 *  - Soft-delete + include_archived expose archivés.
 *  - Hard-delete réservé full (deposit_simple → 403).
 *  - Mode UI base (S+rate) + mode avancé (catégorie+taux).
 *  - Tenant isolation create/get inter-customer.
 *  - 404 sur id inexistant.
 *  - Cohérence vat_category ↔ vat_rate (S exige rate, autres exigent null).
 *  - Pagination cursor next/return.
 *  - MFA guard bloque user avec mfa_reset_required=TRUE.
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

interface Seed {
  customerId: string;
  userId: string;
  bearer: string;
}

async function seedUser(
  sql: postgres.Sql,
  args: {
    siren: string;
    email: string;
    role?: "full" | "deposit_simple" | "deposit_states";
    mfaResetRequired?: boolean;
  },
): Promise<Seed> {
  const customerRows = await sql<{ id: string }[]>`
    INSERT INTO customers (siren, legal_name) VALUES (${args.siren}, ${"Acme " + args.siren})
    RETURNING id
  `;
  const customerId = customerRows[0]?.id ?? "";
  const hash = await hashPassword("Password123!");
  const userRows = await sql<{ id: string }[]>`
    INSERT INTO users (customer_id, email, password_hash, role, mfa_reset_required)
    VALUES (
      ${customerId}, ${args.email}, ${hash},
      ${args.role ?? "full"}, ${args.mfaResetRequired ?? false}
    )
    RETURNING id
  `;
  const userId = userRows[0]?.id ?? "";
  return {
    customerId,
    userId,
    bearer: await signAccessToken({ user_id: userId, customer_id: customerId }),
  };
}

interface ProductBody {
  id: string;
  label: string;
  internal_code: string | null;
  unit_price_ht: string;
  vat_category: string;
  vat_rate: string | null;
  is_archived: boolean;
  category_id: string | null;
}

describe.skipIf(!enabled)("CRUD /api/products (T-CL-12 sprint-03)", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
    app = await buildTestApp({ connectionString: db.url });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  // ──────────────────────────────────────────────────────────────────
  // Happy path
  // ──────────────────────────────────────────────────────────────────

  it("CRUD happy path : create + get + list + update + archive", async () => {
    const seed = await seedUser(sql, { siren: "111111118", email: "alice@a.fr" });

    // CREATE
    const createRes = await fetch(`${app.url}/api/products`, {
      method: "POST",
      headers: { authorization: `Bearer ${seed.bearer}`, "content-type": "application/json" },
      body: JSON.stringify({
        label: "Conseil junior 1h",
        internal_code: "J1k",
        unit_price_ht: "100.0000",
        unit: "HUR",
        vat_category: "S",
        vat_rate: "20.00",
      }),
    });
    expect(createRes.status).toBe(201);
    const createBody = (await createRes.json()) as { product: ProductBody; warnings: unknown[] };
    expect(createBody.product.label).toBe("Conseil junior 1h");
    expect(createBody.product.unit_price_ht).toBe("100.0000");
    expect(createBody.product.vat_category).toBe("S");
    expect(createBody.warnings).toEqual([]);
    const productId = createBody.product.id;

    // GET single
    const getRes = await fetch(`${app.url}/api/products/${productId}`, {
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    expect(getRes.status).toBe(200);
    expect(((await getRes.json()) as ProductBody).label).toBe("Conseil junior 1h");

    // LIST
    const listRes = await fetch(`${app.url}/api/products`, {
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    expect(listRes.status).toBe(200);
    const listBody = (await listRes.json()) as { items: ProductBody[]; next_cursor: string | null };
    expect(listBody.items.length).toBe(1);
    expect(listBody.next_cursor).toBeNull();

    // PATCH
    const patchRes = await fetch(`${app.url}/api/products/${productId}`, {
      method: "PATCH",
      headers: { authorization: `Bearer ${seed.bearer}`, "content-type": "application/json" },
      body: JSON.stringify({ label: "Conseil junior 2h", unit_price_ht: "200.0000" }),
    });
    expect(patchRes.status).toBe(200);
    expect(((await patchRes.json()) as { product: ProductBody }).product.label).toBe(
      "Conseil junior 2h",
    );

    // ARCHIVE (soft-delete par défaut)
    const delRes = await fetch(`${app.url}/api/products/${productId}`, {
      method: "DELETE",
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    expect(delRes.status).toBe(204);

    // LIST par défaut → archivé exclu.
    const listAfterRes = await fetch(`${app.url}/api/products`, {
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    expect(((await listAfterRes.json()) as { items: ProductBody[] }).items).toEqual([]);

    // LIST include_archived=true → archivé visible.
    const listAllRes = await fetch(`${app.url}/api/products?include_archived=true`, {
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    const listAllBody = (await listAllRes.json()) as { items: ProductBody[] };
    expect(listAllBody.items.length).toBe(1);
    expect(listAllBody.items[0]?.is_archived).toBe(true);
  });

  // ──────────────────────────────────────────────────────────────────
  // Warning duplicate_internal_code
  // ──────────────────────────────────────────────────────────────────

  it("create avec internal_code en doublon → 201 + warning non bloquant", async () => {
    const seed = await seedUser(sql, { siren: "111111118", email: "alice@a.fr" });
    await fetch(`${app.url}/api/products`, {
      method: "POST",
      headers: { authorization: `Bearer ${seed.bearer}`, "content-type": "application/json" },
      body: JSON.stringify({
        label: "Conseil J1 v1",
        internal_code: "J1k",
        unit_price_ht: "100.0000",
        vat_category: "S",
        vat_rate: "20.00",
      }),
    });

    const dupRes = await fetch(`${app.url}/api/products`, {
      method: "POST",
      headers: { authorization: `Bearer ${seed.bearer}`, "content-type": "application/json" },
      body: JSON.stringify({
        label: "Conseil J1 v2",
        internal_code: "J1k",
        unit_price_ht: "120.0000",
        vat_category: "S",
        vat_rate: "20.00",
      }),
    });
    expect(dupRes.status).toBe(201);
    const body = (await dupRes.json()) as {
      product: ProductBody;
      warnings: { code: string; existing_label: string }[];
    };
    expect(body.product.label).toBe("Conseil J1 v2");
    expect(body.warnings.length).toBe(1);
    expect(body.warnings[0]?.code).toBe("duplicate_internal_code");
    expect(body.warnings[0]?.existing_label).toBe("Conseil J1 v1");
  });

  // ──────────────────────────────────────────────────────────────────
  // Hard-delete : full only
  // ──────────────────────────────────────────────────────────────────

  it("DELETE ?hard=true : full OK, deposit_simple 403", async () => {
    const adminSeed = await seedUser(sql, {
      siren: "111111118",
      email: "admin@a.fr",
      role: "full",
    });
    const depositSeed = await seedUser(sql, {
      siren: "552081317",
      email: "dep@b.fr",
      role: "deposit_simple",
    });

    // Article créé par admin.
    const created = await fetch(`${app.url}/api/products`, {
      method: "POST",
      headers: { authorization: `Bearer ${adminSeed.bearer}`, "content-type": "application/json" },
      body: JSON.stringify({
        label: "X",
        unit_price_ht: "1.0000",
        vat_category: "S",
        vat_rate: "20.00",
      }),
    });
    const productId = ((await created.json()) as { product: ProductBody }).product.id;

    // Article créé par deposit dans son propre tenant.
    const createdDep = await fetch(`${app.url}/api/products`, {
      method: "POST",
      headers: {
        authorization: `Bearer ${depositSeed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify({
        label: "Y",
        unit_price_ht: "1.0000",
        vat_category: "S",
        vat_rate: "20.00",
      }),
    });
    const productDepId = ((await createdDep.json()) as { product: ProductBody }).product.id;

    // deposit_simple → hard=true sur son propre article = 403.
    const depHard = await fetch(`${app.url}/api/products/${productDepId}?hard=true`, {
      method: "DELETE",
      headers: { authorization: `Bearer ${depositSeed.bearer}` },
    });
    expect(depHard.status).toBe(403);

    // Full → hard=true = 204.
    const fullHard = await fetch(`${app.url}/api/products/${productId}?hard=true`, {
      method: "DELETE",
      headers: { authorization: `Bearer ${adminSeed.bearer}` },
    });
    expect(fullHard.status).toBe(204);

    // Get sur le row hard-deleted = 404.
    const after = await fetch(`${app.url}/api/products/${productId}`, {
      headers: { authorization: `Bearer ${adminSeed.bearer}` },
    });
    expect(after.status).toBe(404);
  });

  // ──────────────────────────────────────────────────────────────────
  // Tenant isolation
  // ──────────────────────────────────────────────────────────────────

  it("tenant isolation : product customerA invisible pour customerB", async () => {
    const seedA = await seedUser(sql, { siren: "111111118", email: "a@a.fr" });
    const seedB = await seedUser(sql, { siren: "552081317", email: "b@b.fr" });

    const r = await fetch(`${app.url}/api/products`, {
      method: "POST",
      headers: { authorization: `Bearer ${seedA.bearer}`, "content-type": "application/json" },
      body: JSON.stringify({
        label: "Secret A",
        unit_price_ht: "1.0000",
        vat_category: "S",
        vat_rate: "20.00",
      }),
    });
    const idA = ((await r.json()) as { product: ProductBody }).product.id;

    // B cherche A → 404.
    const r1 = await fetch(`${app.url}/api/products/${idA}`, {
      headers: { authorization: `Bearer ${seedB.bearer}` },
    });
    expect(r1.status).toBe(404);

    // B liste son catalogue → vide.
    const r2 = await fetch(`${app.url}/api/products`, {
      headers: { authorization: `Bearer ${seedB.bearer}` },
    });
    expect(((await r2.json()) as { items: ProductBody[] }).items).toEqual([]);
  });

  // ──────────────────────────────────────────────────────────────────
  // 404
  // ──────────────────────────────────────────────────────────────────

  it("404 sur id inexistant (GET + PATCH + DELETE)", async () => {
    const seed = await seedUser(sql, { siren: "111111118", email: "a@a.fr" });
    const fakeId = "00000000-0000-0000-0000-000000000000";

    const r1 = await fetch(`${app.url}/api/products/${fakeId}`, {
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    expect(r1.status).toBe(404);

    const r2 = await fetch(`${app.url}/api/products/${fakeId}`, {
      method: "PATCH",
      headers: { authorization: `Bearer ${seed.bearer}`, "content-type": "application/json" },
      body: JSON.stringify({ label: "X" }),
    });
    expect(r2.status).toBe(404);

    const r3 = await fetch(`${app.url}/api/products/${fakeId}`, {
      method: "DELETE",
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    expect(r3.status).toBe(404);
  });

  // ──────────────────────────────────────────────────────────────────
  // Cohérence vat_category ↔ vat_rate
  // ──────────────────────────────────────────────────────────────────

  it("vat_category S exige vat_rate, AE refuse vat_rate (create)", async () => {
    const seed = await seedUser(sql, { siren: "111111118", email: "a@a.fr" });

    // S sans vat_rate → 400.
    const r1 = await fetch(`${app.url}/api/products`, {
      method: "POST",
      headers: { authorization: `Bearer ${seed.bearer}`, "content-type": "application/json" },
      body: JSON.stringify({
        label: "X",
        unit_price_ht: "1.0000",
        vat_category: "S",
        // vat_rate manquant
      }),
    });
    expect(r1.status).toBe(400);

    // AE avec vat_rate → 400.
    const r2 = await fetch(`${app.url}/api/products`, {
      method: "POST",
      headers: { authorization: `Bearer ${seed.bearer}`, "content-type": "application/json" },
      body: JSON.stringify({
        label: "X",
        unit_price_ht: "1.0000",
        vat_category: "AE",
        vat_rate: "20.00",
      }),
    });
    expect(r2.status).toBe(400);

    // AE sans vat_rate → 201.
    const r3 = await fetch(`${app.url}/api/products`, {
      method: "POST",
      headers: { authorization: `Bearer ${seed.bearer}`, "content-type": "application/json" },
      body: JSON.stringify({
        label: "Forfait AE",
        unit_price_ht: "1.0000",
        vat_category: "AE",
      }),
    });
    expect(r3.status).toBe(201);
  });

  // ──────────────────────────────────────────────────────────────────
  // Pagination cursor
  // ──────────────────────────────────────────────────────────────────

  it("pagination cursor : limit=2 retourne next_cursor utilisable", async () => {
    const seed = await seedUser(sql, { siren: "111111118", email: "a@a.fr" });

    // 5 articles, ordre label ASC.
    for (const label of ["Alpes", "Brise", "Comète", "Doré", "Echo"]) {
      await fetch(`${app.url}/api/products`, {
        method: "POST",
        headers: { authorization: `Bearer ${seed.bearer}`, "content-type": "application/json" },
        body: JSON.stringify({
          label,
          unit_price_ht: "1.0000",
          vat_category: "S",
          vat_rate: "20.00",
        }),
      });
    }

    const page1 = await fetch(`${app.url}/api/products?limit=2`, {
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    const body1 = (await page1.json()) as { items: ProductBody[]; next_cursor: string | null };
    expect(body1.items.map((r) => r.label)).toEqual(["Alpes", "Brise"]);
    expect(body1.next_cursor).not.toBeNull();

    const page2 = await fetch(
      `${app.url}/api/products?limit=2&cursor=${encodeURIComponent(body1.next_cursor ?? "")}`,
      { headers: { authorization: `Bearer ${seed.bearer}` } },
    );
    const body2 = (await page2.json()) as { items: ProductBody[]; next_cursor: string | null };
    expect(body2.items.map((r) => r.label)).toEqual(["Comète", "Doré"]);

    const page3 = await fetch(
      `${app.url}/api/products?limit=2&cursor=${encodeURIComponent(body2.next_cursor ?? "")}`,
      { headers: { authorization: `Bearer ${seed.bearer}` } },
    );
    const body3 = (await page3.json()) as { items: ProductBody[]; next_cursor: string | null };
    expect(body3.items.map((r) => r.label)).toEqual(["Echo"]);
    expect(body3.next_cursor).toBeNull();
  });

  // ──────────────────────────────────────────────────────────────────
  // Auth + MFA guard
  // ──────────────────────────────────────────────────────────────────

  it("sans Bearer → 401", async () => {
    const r = await fetch(`${app.url}/api/products`);
    expect(r.status).toBe(401);
  });

  it("user avec mfa_reset_required → 403 sur tous les endpoints products", async () => {
    const seed = await seedUser(sql, {
      siren: "111111118",
      email: "blocked@a.fr",
      mfaResetRequired: true,
    });
    const r = await fetch(`${app.url}/api/products`, {
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    expect(r.status).toBe(403);
  });

  // ──────────────────────────────────────────────────────────────────
  // Filtres list
  // ──────────────────────────────────────────────────────────────────

  it("list filtre search ILIKE sur label", async () => {
    const seed = await seedUser(sql, { siren: "111111118", email: "a@a.fr" });
    for (const label of ["Conseil junior 1h", "Domiciliation", "Conseil senior 1h"]) {
      await fetch(`${app.url}/api/products`, {
        method: "POST",
        headers: { authorization: `Bearer ${seed.bearer}`, "content-type": "application/json" },
        body: JSON.stringify({
          label,
          unit_price_ht: "1.0000",
          vat_category: "S",
          vat_rate: "20.00",
        }),
      });
    }
    const r = await fetch(`${app.url}/api/products?search=conseil`, {
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    const body = (await r.json()) as { items: ProductBody[] };
    expect(body.items.length).toBe(2);
    expect(body.items.map((p) => p.label)).toEqual(["Conseil junior 1h", "Conseil senior 1h"]);
  });
});
