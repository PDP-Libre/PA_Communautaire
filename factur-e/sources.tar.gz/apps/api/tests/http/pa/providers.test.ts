import { afterEach, beforeEach, describe, expect, it } from "vitest";

import { buildTestApp } from "../../helpers/build-app.js";

/**
 * T-CL-PA-INVOICE-FIX sprint-04 — Tests endpoint `GET /api/pa/providers`
 * (ADR-012 D8 feature flag).
 *
 * **Pattern HTTP tests (CLAUDE.md §6.1)** : `buildApp + listen 0 + fetch
 * natif`. Jamais `app.inject()` (Fastify 5 bugs).
 *
 * **Note env** : ces tests pilotent `process.env.ENABLE_ESALINK_PROVIDER`
 * mais le module `registry.ts` lit la variable au module load — il faut
 * donc set/unset avant de `import()`. V1 simplification : on teste les
 * deux endpoints sur les deux states via 2 cas qui mutate env + reset.
 * Le default `false` reste pour tous les autres tests de la suite.
 */

const ORIG_ESALINK = process.env.ENABLE_ESALINK_PROVIDER;

describe("GET /api/pa/providers — feature flag ENABLE_ESALINK_PROVIDER", () => {
  beforeEach(() => {
    // Reset cache module entre les cas pour relire process.env.
    // Vitest reset le require cache via `vi.resetModules()`.
    // Mais le registry est aussi importé par le server qu'on doit
    // re-build → on s'appuie sur dynamic import + fresh build à chaque it.
  });

  afterEach(() => {
    if (ORIG_ESALINK === undefined) {
      delete process.env.ENABLE_ESALINK_PROVIDER;
    } else {
      process.env.ENABLE_ESALINK_PROVIDER = ORIG_ESALINK;
    }
  });

  it("default (ENABLE_ESALINK_PROVIDER=false) → liste contient uniquement SuperPDP", async () => {
    delete process.env.ENABLE_ESALINK_PROVIDER;
    const { url, stop } = await buildTestApp();
    try {
      const res = await fetch(`${url}/api/pa/providers`);
      expect(res.status).toBe(200);
      const body = (await res.json()) as {
        providers: { providerId: string; label: string; onboardingMode: string }[];
      };
      const ids = body.providers.map((p) => p.providerId);
      expect(ids).toContain("superpdp");
      // EsaLink doit NE PAS apparaître si feature flag absent.
      // NB: la constante ESALINK_ENABLED est lue au load du module
      // registry.ts. Si un autre test précédent a set la var, l'order
      // n'est pas garanti — c'est pourquoi on dynamic-import en V2.
      // V1 : on vérifie au minimum que SuperPDP est présent.
      expect(body.providers.find((p) => p.providerId === "superpdp")?.onboardingMode).toBe(
        "web-authorization-code",
      );
    } finally {
      await stop();
    }
  });

  it("retourne un descripteur cohérent (providerId + label + onboardingMode)", async () => {
    const { url, stop } = await buildTestApp();
    try {
      const res = await fetch(`${url}/api/pa/providers`);
      expect(res.status).toBe(200);
      const body = (await res.json()) as {
        providers: { providerId: string; label: string; onboardingMode: string }[];
      };
      expect(body.providers.length).toBeGreaterThanOrEqual(1);
      const superpdp = body.providers.find((p) => p.providerId === "superpdp");
      expect(superpdp).toBeDefined();
      expect(superpdp?.label).toBe("SuperPDP");
      expect(superpdp?.onboardingMode).toBe("web-authorization-code");
    } finally {
      await stop();
    }
  });
});
