import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { insertExportRequest } from "../../../src/db/repos/export_requests.js";
import { MockJobQueue } from "../../../src/jobs/job-queue.js";
import { MockObjectStorage } from "../../../src/storage/object-storage.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";
import { seedInvoiceUser } from "../invoices/_helpers.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("GET /api/exports + /:id/download (T-CL-EXPORT-ZIP-RETENTION)", () => {
  let db: TestDb;
  let sql: postgres.Sql;
  let app: TestApp;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 2, onnotice: () => undefined });
    app = await buildTestApp({
      connectionString: db.url,
      jobQueue: new MockJobQueue(),
      exportsStorage: new MockObjectStorage(),
    });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    await sql`TRUNCATE TABLE export_requests RESTART IDENTITY CASCADE`;
  });

  const get = (path: string, bearer: string, manual = false): Promise<Response> =>
    fetch(`${app.url}${path}`, {
      headers: { authorization: `Bearer ${bearer}` },
      redirect: manual ? "manual" : "follow",
    });

  async function seedCompleted(customerId: string, userId: string): Promise<string> {
    const req = await insertExportRequest(sql, {
      customer_id: customerId,
      requested_by_user_id: userId,
      scope: "emission",
      filters: {},
      invoice_ids: [crypto.randomUUID()],
      invoice_count: 2,
    });
    await sql`
      UPDATE export_requests
      SET status = 'completed', file_key = ${`exports/${customerId}/${req.id}.zip`}
      WHERE id = ${req.id}
    `;
    return req.id;
  }

  it("GET /api/exports — liste paginée Full", async () => {
    const seed = await seedInvoiceUser(sql);
    await seedCompleted(seed.customerId, seed.userId);
    const res = await get("/api/exports", seed.bearer);
    expect(res.status).toBe(200);
    const body = (await res.json()) as { items: unknown[]; total: number; page_size: number };
    expect(body.total).toBe(1);
    expect(body.items.length).toBe(1);
    expect(body.page_size).toBe(20);
  });

  it("download : 302 vers presigned URL si completed et < 7j", async () => {
    const seed = await seedInvoiceUser(sql);
    const id = await seedCompleted(seed.customerId, seed.userId);
    const res = await get(`/api/exports/${id}/download`, seed.bearer, true);
    expect(res.status).toBe(302);
    expect(res.headers.get("location")).toContain("mock://presigned/");
  });

  it("download : 410 Gone si completed mais > 7j", async () => {
    const seed = await seedInvoiceUser(sql);
    const id = await seedCompleted(seed.customerId, seed.userId);
    await sql`UPDATE export_requests SET created_at = NOW() - INTERVAL '8 days' WHERE id = ${id}`;
    const res = await get(`/api/exports/${id}/download`, seed.bearer, true);
    expect(res.status).toBe(410);
  });

  it("download : 409 si l'export n'est pas completed", async () => {
    const seed = await seedInvoiceUser(sql);
    const req = await insertExportRequest(sql, {
      customer_id: seed.customerId,
      requested_by_user_id: seed.userId,
      scope: "emission",
      filters: {},
      invoice_ids: [crypto.randomUUID()],
      invoice_count: 1,
    });
    const res = await get(`/api/exports/${req.id}/download`, seed.bearer, true);
    expect(res.status).toBe(409);
  });

  it("download : 404 si purged", async () => {
    const seed = await seedInvoiceUser(sql);
    const id = await seedCompleted(seed.customerId, seed.userId);
    await sql`UPDATE export_requests SET status = 'purged', file_key = NULL WHERE id = ${id}`;
    const res = await get(`/api/exports/${id}/download`, seed.bearer, true);
    expect(res.status).toBe(404);
  });

  it("download : 404 si export d'un autre customer (inter-tenant)", async () => {
    const owner = await seedInvoiceUser(sql);
    const id = await seedCompleted(owner.customerId, owner.userId);
    const other = await seedInvoiceUser(sql, { siren: "222222229", email: "other@test.fr" });
    const res = await get(`/api/exports/${id}/download`, other.bearer, true);
    expect(res.status).toBe(404);
  });
});
