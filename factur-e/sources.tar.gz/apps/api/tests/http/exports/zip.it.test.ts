import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { hashPassword } from "../../../src/auth/argon2.js";
import { signAccessToken } from "../../../src/auth/jwt.js";
import { MockEmailSender } from "../../../src/email/sender.js";
import { MockJobQueue } from "../../../src/jobs/job-queue.js";
import { MemorySecretStore } from "../../../src/secrets/index.js";
import { MockObjectStorage } from "../../../src/storage/object-storage.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";
import { seedInvoiceUser } from "../invoices/_helpers.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("POST /api/exports/zip (T-CL-EXPORT-ZIP-RETENTION)", () => {
  let db: TestDb;
  let sql: postgres.Sql;
  let app: TestApp;
  let jobQueue: MockJobQueue;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 2, onnotice: () => undefined });
    jobQueue = new MockJobQueue();
    app = await buildTestApp({
      connectionString: db.url,
      jobQueue,
      exportsStorage: new MockObjectStorage(),
      emailSender: new MockEmailSender(),
      secretStore: new MemorySecretStore(),
    });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    await sql`TRUNCATE TABLE export_requests, received_invoices RESTART IDENTITY CASCADE`;
    jobQueue.reset();
  });

  const post = (bearer: string | null, body: unknown): Promise<Response> =>
    fetch(`${app.url}/api/exports/zip`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        ...(bearer !== null ? { authorization: `Bearer ${bearer}` } : {}),
      },
      body: JSON.stringify(body),
    });

  async function seedReception(customerId: string): Promise<void> {
    await sql`
      INSERT INTO received_invoices (customer_id, pa_invoice_id_in, seller_siren, status_current)
      VALUES (${customerId}, 'pa-in-1', '987654321', 'in_process')
    `;
  }

  it("401 sans authentification", async () => {
    const res = await post(null, { scope: "all", filters: {} });
    expect(res.status).toBe(401);
  });

  it("403 pour un rôle non-Full", async () => {
    const seed = await seedInvoiceUser(sql);
    const hash = await hashPassword("Password123!");
    const rows = await sql<{ id: string }[]>`
      INSERT INTO users (customer_id, email, password_hash, role)
      VALUES (${seed.customerId}, 'restreint@test.fr', ${hash}, 'deposit_simple')
      RETURNING id
    `;
    const bearer = await signAccessToken({
      user_id: rows[0]?.id ?? "",
      customer_id: seed.customerId,
    });
    const res = await post(bearer, { scope: "all", filters: {} });
    expect(res.status).toBe(403);
  });

  it("400 si aucune facture à exporter", async () => {
    const seed = await seedInvoiceUser(sql);
    const res = await post(seed.bearer, { scope: "emission", filters: {} });
    expect(res.status).toBe(400);
  });

  it("202 happy path Full → row pending + job enqueue", async () => {
    const seed = await seedInvoiceUser(sql);
    await seedReception(seed.customerId);

    const res = await post(seed.bearer, { scope: "reception", filters: {} });
    expect(res.status).toBe(202);
    const body = (await res.json()) as { export_id: string; correlation_id: string };
    expect(body.export_id).toBeDefined();
    expect(body.correlation_id).toBeDefined();

    const enqueued = jobQueue.lastEnqueued("export-zip-generate");
    expect(enqueued?.export_request_id).toBe(body.export_id);

    const rows = await sql<{ status: string; invoice_count: number }[]>`
      SELECT status, invoice_count FROM export_requests WHERE id = ${body.export_id}
    `;
    expect(rows[0]?.status).toBe("pending");
    expect(rows[0]?.invoice_count).toBe(1);

    const audit = await sql<{ n: string }[]>`
      SELECT COUNT(*)::text AS n FROM auth_audit WHERE event_type = 'export_zip_requested'
    `;
    expect(Number(audit[0]?.n)).toBe(1);
  });
});
