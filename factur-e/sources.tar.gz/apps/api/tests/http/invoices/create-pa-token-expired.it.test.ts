import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { PaAccessTokenExpiredException } from "@factur-e/pa-adapter";
import { MockPADriver } from "@factur-e/shared-fakes";

import { MemorySecretStore } from "../../../src/secrets/index.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";
import { seedFullCustomer } from "../../_fixtures/seed-customer.js";
import { fixtureFormBase } from "./_helpers.js";

/**
 * Cas #7 — Token PA expiré (401 SuperPDP). Le driver lève
 * `PaAccessTokenExpiredException`. Route mappe → 401 + message UX
 * canonique "Reconnectez-vous depuis Paramètres > Connexion à ma
 * Plateforme Agréée." + audit `pa_token_expired_during_submission`.
 *
 * Pendant du **cas timeout déconnexion** acté brief §3.3 scope étendu
 * PMO 2026-05-20 (= ce cas #7).
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("POST /api/invoices — token PA expiré (401)", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;
  let secrets: MemorySecretStore;
  let driver: MockPADriver;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
    secrets = new MemorySecretStore();
    driver = new MockPADriver();
    app = await buildTestApp({ connectionString: db.url, paDriver: driver, secretStore: secrets });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    driver.reset();
  });

  it("401 + userMessage Reconnectez-vous + audit pa_token_expired_during_submission", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    driver.setSubmitInvoiceFailure(new PaAccessTokenExpiredException());

    const res = await fetch(`${app.url}/api/invoices`, {
      method: "POST",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify(fixtureFormBase()),
    });
    expect(res.status).toBe(401);
    const body = (await res.json()) as { message: string };
    expect(body.message).toMatch(
      /Reconnectez-vous depuis Paramètres > Connexion à ma Plateforme Agréée/i,
    );

    // ROLLBACK : pas d'invoice.
    const persisted = await sql<{ count: string }[]>`
      SELECT COUNT(*)::text AS count FROM invoices WHERE customer_id = ${seed.customerId}
    `;
    expect(persisted[0]?.count).toBe("0");

    // Audit propre.
    const audits = await sql<{ event_type: string; success: boolean }[]>`
      SELECT event_type, success FROM auth_audit WHERE user_id = ${seed.userId}
    `;
    expect(
      audits.some((a) => a.event_type === "pa_token_expired_during_submission" && !a.success),
    ).toBe(true);
  });

  it("401 + même message quand bundle SecretStore absent (= reconnexion requise)", async () => {
    // Cas symétrique : pa_connection présente mais bundle absent dans
    // SecretStore (rare — typiquement après revoke incomplet ou
    // disconnect en cours). Endpoint create.ts:143 retourne 401 sans
    // appeler le driver.
    const seed = await seedFullCustomer(sql, { withPaConnection: true });
    // Pas de secrets.put → bundle = null côté store.

    const res = await fetch(`${app.url}/api/invoices`, {
      method: "POST",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify(fixtureFormBase()),
    });
    expect(res.status).toBe(401);
    const body = (await res.json()) as { message: string };
    expect(body.message).toMatch(/connexion à la Plateforme Agréée a expiré/i);

    // Pas de call submit (court-circuit avant le driver) — pas d'audit
    // submission spécifique.
    expect(driver.counts.submitInvoice).toBe(0);
  });
});
