import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { SuperPDPDriver } from "@factur-e/pa-adapter";
import { startFakeSuperPdp, type FakeSuperPdp } from "@factur-e/shared-fakes";

import { MemorySecretStore } from "../../../src/secrets/index.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";
import { seedFullCustomer } from "../../_fixtures/seed-customer.js";
import { fixtureFormBase } from "./_helpers.js";

/**
 * Cas #5 — Émission PA 5xx + retry interne plafonné OK : SuperPDP
 * répond 500 au 1er call, 200 au 2e call. Le driver `SuperPDPDriver`
 * exécute `withRetry` (ADR-005 D11 — max 2 retries + backoff 1s/2s). Le
 * route call est transparent : retourne 201 + invoice persistée + audit
 * `pa_invoice_submitted` succès. Observable : `fake.getSubmitRequestCount() === 2`.
 *
 * Pattern : real driver + fakeSuperPdp HTTP, distinct des autres cas qui
 * utilisent MockPADriver. Permet d'éprouver le retry end-to-end via la
 * route, pas juste le driver unit.
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("POST /api/invoices — PA 5xx puis OK (retry transparent)", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;
  let secrets: MemorySecretStore;
  let fake: FakeSuperPdp;
  let driver: SuperPDPDriver;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
    secrets = new MemorySecretStore();
    // Backoff 0/0 pour ne pas attendre 1s/2s en test — retry plafonné
    // se déclenche quand même via le compteur d'attempts interne.
    fake = await startFakeSuperPdp({ scenario: "submit_5xx_then_ok" });
    driver = new SuperPDPDriver({
      clientId: "fake-client-id",
      clientSecret: "fake-client-secret",
      baseUrl: fake.baseUrl,
      // ADR-005 D11 : max 2 retries. Override sleep pour ne pas
      // attendre 1s/2s côté test.
      retryOptions: { maxRetries: 2, backoffMs: [0, 0], sleep: () => Promise.resolve() },
    });
    app = await buildTestApp({ connectionString: db.url, paDriver: driver, secretStore: secrets });
  });

  afterAll(async () => {
    await app.stop();
    await fake.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    fake.reset();
    fake.setScenario("submit_5xx_then_ok");
  });

  it("201 + persiste invoice + audit succès + le driver a fait 2 calls (1 fail + 1 ok)", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });

    const res = await fetch(`${app.url}/api/invoices`, {
      method: "POST",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify(fixtureFormBase()),
    });
    expect(res.status).toBe(201);
    const body = (await res.json()) as {
      invoice: { id: string; pa_invoice_id: string; status_current: string };
    };
    expect(body.invoice.pa_invoice_id).toMatch(/^\d+$/); // SuperPDP integer stringifié
    expect(body.invoice.status_current).toBe("submitted");

    // ── Observable retry : fakeSuperPdp a vu 2 appels submit. ──
    expect(fake.getSubmitRequestCount()).toBe(2);

    // Audit succès écrit (pas d'audit failure intermédiaire — le retry
    // est totalement absorbé par le driver).
    const audits = await sql<{ event_type: string; success: boolean }[]>`
      SELECT event_type, success FROM auth_audit WHERE user_id = ${seed.userId}
    `;
    expect(audits.some((a) => a.event_type === "pa_invoice_submitted" && a.success)).toBe(true);
    // Pas de pa_submission_failed_max_retries puisque le retry a abouti.
    expect(audits.some((a) => a.event_type === "pa_submission_failed_max_retries")).toBe(false);

    // Invoice persistée (pipeline complet).
    const persisted = await sql<{ pa_invoice_id: string }[]>`
      SELECT pa_invoice_id FROM invoices WHERE customer_id = ${seed.customerId}
    `;
    expect(persisted).toHaveLength(1);
  });
});
