import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import {
  PaSubmissionFailedException,
  PaUnavailableException,
  PaRateLimitException,
} from "@factur-e/pa-adapter";
import { MockPADriver } from "@factur-e/shared-fakes";

import { MemorySecretStore } from "../../../src/secrets/index.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";
import { seedFullCustomer } from "../../_fixtures/seed-customer.js";
import { fixtureFormBase } from "./_helpers.js";

/**
 * Cas #6 — Émission PA 5xx épuisé (max retries atteint). Le driver
 * remonte `PaSubmissionFailedException` après épuisement de `withRetry`.
 * Route mappe → 503 + audit `pa_submission_failed_max_retries`. Le
 * brouillon UI côté front reste sauvegardé (auto-save 5s) — pas de
 * statut intermédiaire `pending_pa_response` côté `invoices` (MVP).
 *
 * Bonus : couvre aussi le cas `PaUnavailableException` (équivalent 503
 * pour les autres flux que submitInvoice) + `PaRateLimitException` (429
 * mappé séparément).
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("POST /api/invoices — PA 5xx max retries exhausted", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;
  let secrets: MemorySecretStore;
  let driver: MockPADriver;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
    secrets = new MemorySecretStore();
    driver = new MockPADriver();
    app = await buildTestApp({ connectionString: db.url, paDriver: driver, secretStore: secrets });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    driver.reset();
  });

  it("503 + ROLLBACK + audit pa_submission_failed_max_retries sur PaSubmissionFailedException", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    driver.setSubmitInvoiceFailure(
      new PaSubmissionFailedException({ retries: 2, lastStatus: 500 }),
    );

    const res = await fetch(`${app.url}/api/invoices`, {
      method: "POST",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify(fixtureFormBase()),
    });
    expect(res.status).toBe(503);
    const body = (await res.json()) as { message: string };
    expect(body.message).toMatch(/Plateforme Agréée est momentanément indisponible/i);

    const persisted = await sql<{ count: string }[]>`
      SELECT COUNT(*)::text AS count FROM invoices WHERE customer_id = ${seed.customerId}
    `;
    expect(persisted[0]?.count).toBe("0");

    const audits = await sql<{ event_type: string; success: boolean }[]>`
      SELECT event_type, success FROM auth_audit WHERE user_id = ${seed.userId}
    `;
    expect(
      audits.some((a) => a.event_type === "pa_submission_failed_max_retries" && !a.success),
    ).toBe(true);
  });

  it("503 + audit pa_submission_failed_max_retries sur PaUnavailableException (réutilisation mapping)", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    driver.setSubmitInvoiceFailure(new PaUnavailableException({ status: 503 }));

    const res = await fetch(`${app.url}/api/invoices`, {
      method: "POST",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify(fixtureFormBase()),
    });
    expect(res.status).toBe(503);

    const audits = await sql<{ event_type: string }[]>`
      SELECT event_type FROM auth_audit WHERE user_id = ${seed.userId}
    `;
    expect(audits.some((a) => a.event_type === "pa_submission_failed_max_retries")).toBe(true);
  });

  it("429 + audit pa_rate_limited sur PaRateLimitException", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    driver.setSubmitInvoiceFailure(new PaRateLimitException({ retryAfterSeconds: 30 }));

    const res = await fetch(`${app.url}/api/invoices`, {
      method: "POST",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify(fixtureFormBase()),
    });
    expect(res.status).toBe(429);
    const body = (await res.json()) as { message: string };
    expect(body.message).toMatch(/Trop de requêtes/i);

    const audits = await sql<{ event_type: string }[]>`
      SELECT event_type FROM auth_audit WHERE user_id = ${seed.userId}
    `;
    expect(audits.some((a) => a.event_type === "pa_rate_limited")).toBe(true);
  });
});
