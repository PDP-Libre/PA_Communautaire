import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";
import { seedInvoiceUser } from "./_helpers.js";

/**
 * Cas 5 — Drafts CRUD complet : POST + 3× PATCH (auto-save 5s
 * simulation) + GET retrieve + DELETE.
 *
 * Vérifie : `last_modified_at` avancé à chaque PATCH, payload
 * permissif accepté, tenant isolation (404 si pas du customer).
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("CRUD /api/invoice-drafts", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
    app = await buildTestApp({ connectionString: db.url });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  it("POST + 3× PATCH + GET + DELETE → état cohérent", async () => {
    const seed = await seedInvoiceUser(sql);

    // POST initial
    const createRes = await fetch(`${app.url}/api/invoice-drafts`, {
      method: "POST",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify({
        payload: { ui_mode: "base", document: { number: "F-DRAFT-001" } },
        step_completed: { document: 50 },
      }),
    });
    expect(createRes.status).toBe(201);
    const draft = (await createRes.json()) as { id: string; last_modified_at: string };
    const firstModified = new Date(draft.last_modified_at);

    // 3× PATCH simulant auto-save (small delay pour discriminer
    // last_modified_at).
    for (let i = 0; i < 3; i++) {
      await new Promise((r) => setTimeout(r, 10));
      const patchRes = await fetch(`${app.url}/api/invoice-drafts/${draft.id}`, {
        method: "PATCH",
        headers: {
          authorization: `Bearer ${seed.bearer}`,
          "content-type": "application/json",
        },
        body: JSON.stringify({
          payload: {
            ui_mode: "base",
            document: { number: "F-DRAFT-001", notes: `iteration ${String(i + 1)}` },
          },
        }),
      });
      expect(patchRes.status).toBe(200);
    }

    // GET retrieve — payload final + last_modified_at > firstModified
    const getRes = await fetch(`${app.url}/api/invoice-drafts/${draft.id}`, {
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    expect(getRes.status).toBe(200);
    const retrieved = (await getRes.json()) as {
      payload: { document: { notes: string } };
      last_modified_at: string;
    };
    expect(retrieved.payload.document.notes).toBe("iteration 3");
    expect(new Date(retrieved.last_modified_at).getTime()).toBeGreaterThan(firstModified.getTime());

    // GET list — un draft
    const listRes = await fetch(`${app.url}/api/invoice-drafts`, {
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    expect(listRes.status).toBe(200);
    const list = (await listRes.json()) as { items: { id: string }[] };
    expect(list.items).toHaveLength(1);
    expect(list.items[0]?.id).toBe(draft.id);

    // DELETE
    const delRes = await fetch(`${app.url}/api/invoice-drafts/${draft.id}`, {
      method: "DELETE",
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    expect(delRes.status).toBe(204);

    // GET 404 après delete
    const after = await fetch(`${app.url}/api/invoice-drafts/${draft.id}`, {
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    expect(after.status).toBe(404);
  });

  it("tenant isolation — un customer ne voit pas les drafts d'un autre", async () => {
    const seedA = await seedInvoiceUser(sql, {
      siren: "111111118",
      email: "a@a.fr",
    });
    const seedB = await seedInvoiceUser(sql, {
      siren: "222222221",
      email: "b@b.fr",
    });

    const createA = await fetch(`${app.url}/api/invoice-drafts`, {
      method: "POST",
      headers: { authorization: `Bearer ${seedA.bearer}`, "content-type": "application/json" },
      body: JSON.stringify({ payload: { ui_mode: "base" } }),
    });
    const draftA = (await createA.json()) as { id: string };

    const getB = await fetch(`${app.url}/api/invoice-drafts/${draftA.id}`, {
      headers: { authorization: `Bearer ${seedB.bearer}` },
    });
    expect(getB.status).toBe(404); // 404 not 403 — pas leak de l'existence
  });
});
