import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { MockPADriver } from "@factur-e/shared-fakes";

import { MemorySecretStore } from "../../../src/secrets/index.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";
import { fixtureFormBase, seedInvoiceUser } from "./_helpers.js";

/**
 * Cas 1 — Émission B2B base happy path (15 champs mode UI base).
 * Pipeline complet : formToModel → generateCII → validateXsd →
 * assembleFacturXPdfA3 → SHA256 → INSERT invoice + lines → mockSubmit →
 * UPDATE pa_invoice_id + status_current → INSERT cdar_events 'Déposée'.
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("POST /api/invoices — base happy path", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;
  let secrets: MemorySecretStore;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
    secrets = new MemorySecretStore();
    app = await buildTestApp({
      connectionString: db.url,
      paDriver: new MockPADriver(),
      secretStore: secrets,
    });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  it("crée invoice + lines + cdar_events Déposée + flowId", async () => {
    const seed = await seedInvoiceUser(sql, { secretStore: secrets });
    const form = fixtureFormBase();

    const res = await fetch(`${app.url}/api/invoices`, {
      method: "POST",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify(form),
    });
    expect(res.status).toBe(201);
    const body = (await res.json()) as {
      invoice: {
        id: string;
        number: string;
        pa_invoice_id: string;
        status_current: string;
        sha256: string;
      };
      lines: { line_number: number; label: string }[];
      cdar_events: { code: string; source: string }[];
      pa_invoice_id: string;
    };

    expect(body.invoice.number).toBe("F-2026-0001");
    // MockPADriver retourne `mock-invoice-<n>` (rename T-CL-PA-INVOICE-FIX
    // depuis `mock-flow-<n>`) ; en prod SuperPDP retourne un integer
    // stringifié `invoice.id`. On vérifie juste que pa_invoice_id est non vide.
    expect(body.invoice.pa_invoice_id).toMatch(/^[\w-]+$/);
    expect(body.invoice.sha256).toMatch(/^[0-9a-f]{64}$/);
    // status_current = FacturEStatusCode normalisé (ADR-012 D2).
    // MockPADriver retourne 'submitted' (= 'api:uploaded' mappé).
    expect(body.invoice.status_current).toBe("submitted");
    expect(body.lines).toHaveLength(1);
    expect(body.lines[0]?.label).toBe("Prestation conseil");
    expect(body.cdar_events).toHaveLength(1);
    // cdar_events.code = raw status_code natif (`api:uploaded`).
    expect(body.cdar_events[0]?.code).toBe("api:uploaded");
    expect(body.cdar_events[0]?.source).toBe("synthetic");
    expect(body.pa_invoice_id).toBe(body.invoice.pa_invoice_id);

    // Vérification BDD directe
    const persisted = await sql<{ id: string; pa_invoice_id: string; total_ttc: string }[]>`
      SELECT id, pa_invoice_id, total_ttc::text AS total_ttc
      FROM invoices WHERE customer_id = ${seed.customerId}
    `;
    expect(persisted).toHaveLength(1);
    expect(persisted[0]?.total_ttc).toBe("600.00"); // 500 HT + 20% TVA

    // Audit pa_invoice_submitted écrit.
    const audits = await sql<{ event_type: string; success: boolean }[]>`
      SELECT event_type, success FROM auth_audit WHERE user_id = ${seed.userId}
    `;
    expect(audits.some((a) => a.event_type === "pa_invoice_submitted" && a.success)).toBe(true);
  });
});
