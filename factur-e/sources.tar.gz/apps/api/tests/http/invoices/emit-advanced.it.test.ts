import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { MockPADriver } from "@factur-e/shared-fakes";

import { MemorySecretStore } from "../../../src/secrets/index.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";
import { seedInvoiceUser } from "./_helpers.js";

/**
 * Cas 2 — Émission B2B avancé happy path (54 champs).
 * Vérifie : BT-13 buyerOrderRef + BT-14 sellerOrderRef + BG-13 shipping
 * + BG-20 documentLevelAllowance + 4 zones commentaires + ICS BT-90 +
 * persistance payload_extended jsonb non vide.
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("POST /api/invoices — advanced happy path", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;
  let secrets: MemorySecretStore;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
    secrets = new MemorySecretStore();
    app = await buildTestApp({
      connectionString: db.url,
      paDriver: new MockPADriver(),
      secretStore: secrets,
    });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  it("persiste payload_extended (BT-13, BG-13, BG-20, ICS) + invoice + lines + cdar Déposée", async () => {
    const seed = await seedInvoiceUser(sql, { secretStore: secrets });
    const advancedForm = {
      ui_mode: "advanced",
      document: {
        number: "F-2026-0042",
        issueDate: "2026-05-16",
        typeCode: "380",
        currency: "EUR",
        processingRule: "B2B",
        buyerOrderRef: "PO-2026-1234",
        sellerOrderRef: "202502-1",
        contractRef: "CTR-2025-456",
        projectRef: null,
        billingPeriod: null,
        notes: "Merci de votre confiance",
        privateComments: "Client habituel",
        footerMentions: "TVA non applicable, art. 293 B du CGI",
        generalComments: "Acompte signé le 02/05/2026",
      },
      parties: {
        buyer: {
          siren: "987654321",
          legalName: "Client Corp",
          address: {
            lineOne: "5 av. des Champs",
            lineTwo: null,
            postcode: "69000",
            city: "Lyon",
            countryCode: "FR",
          },
          electronicAddress: "0225:987654321_dgfip",
          electronicAddressScheme: "0225",
        },
        shipping: {
          name: "Client Corp — Entrepôt Sud",
          locationId: null,
          address: {
            lineOne: "Z.I. Sud",
            lineTwo: null,
            postcode: "13000",
            city: "Marseille",
            countryCode: "FR",
          },
        },
        deliveryDate: "2026-05-20",
        clientTaxRegime: "default",
        transporter: "DHL Express",
        trackingNumber: "DHL12345",
      },
      lines: [
        {
          label: "Service annuel",
          description: null,
          quantity: "1",
          unitCode: "C62",
          unitPriceHt: "1000.00",
          vatCategory: "S",
          vatRate: "20.00",
          totalHt: "1000.00",
          longDescription: "Abonnement annuel mensualisé",
          note: "Facture annuelle — détail mensuel",
          basisQuantity: null,
        },
      ],
      documentLevelAllowance: {
        chargeIndicator: false,
        // Finding I — mode % : montant dérivé serveur (sentinelle "0"), plus
        // figé en dur. round2(1000 × 10 %) = 100 → TTC 1080 prouve la
        // dérivation de bout en bout.
        amount: "0",
        baseAmount: null,
        percent: "10.00",
        reason: "Remise commerciale 10 %",
        reasonCode: "95",
        vatCategory: "S",
        vatRate: "20.00",
      },
      payment: {
        paymentTerms: { kind: "days", days: 30 },
        paymentMethodKind: "transfer",
        paymentMeansCode: null,
        creditorReference: "FR76ZZZ123456",
        prepaidAmount: null,
        customPenalties: null,
        mentionsLegales: null,
      },
    };

    const res = await fetch(`${app.url}/api/invoices`, {
      method: "POST",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify(advancedForm),
    });
    expect(res.status).toBe(201);
    const body = (await res.json()) as {
      invoice: { number: string; payload_extended: Record<string, unknown>; total_ttc: string };
    };

    expect(body.invoice.number).toBe("F-2026-0042");
    // payload_extended doit contenir les champs avancé (les 39
    // additionnels non en colonnes BDD).
    expect(body.invoice.payload_extended.buyerOrderRef).toBe("PO-2026-1234");
    expect(body.invoice.payload_extended.sellerOrderRef).toBe("202502-1");
    expect(body.invoice.payload_extended.contractRef).toBe("CTR-2025-456");
    expect(body.invoice.payload_extended.privateComments).toBe("Client habituel");
    expect(body.invoice.payload_extended.footerMentions).toBe(
      "TVA non applicable, art. 293 B du CGI",
    );
    expect(body.invoice.payload_extended.clientTaxRegime).toBe("default");
    expect(body.invoice.payload_extended.transporter).toBe("DHL Express");
    expect(body.invoice.payload_extended.creditorReference).toBe("FR76ZZZ123456");
    // documentLevelAllowance présent → totaux : 1000 HT − 100 = 900 base,
    // TVA 180, TTC 1080.
    expect(body.invoice.total_ttc).toBe("1080.00");
  });
});
