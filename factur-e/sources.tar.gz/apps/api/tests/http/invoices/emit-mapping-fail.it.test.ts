import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";
import { fixtureFormBase, seedInvoiceUser } from "./_helpers.js";

/**
 * Cas 3 — Mapping formToModel échoue → 422 + 0 invoice persistée.
 * Couvre la branche ADR-009 D1 fail-safe : transient interne (mapping
 * incohérent) → pas de persist. Test négatif obligatoire.
 *
 * Scénario synthétique : `paymentMethodKind=transfer` mais customer
 * sans IBAN → IBAN manquant pour BG-17 → INVALID_PAYMENT_METHOD_MISSING_IBAN.
 *
 * NB : la validation XSD côté `factur-x-builder` est déjà testée
 * exhaustivement sprint-01. On teste ici le **point de bascule du
 * pipeline** plutôt que de générer un XML synthétiquement invalide
 * (qui serait fragile au changement de XSD).
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("POST /api/invoices — mapping fail (IBAN manquant)", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
    app = await buildTestApp({ connectionString: db.url });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  it("retourne 422 + 0 invoice persistée si IBAN customer manquant pour transfer", async () => {
    const seed = await seedInvoiceUser(sql, { iban: null, bic: null });
    const form = fixtureFormBase();

    const res = await fetch(`${app.url}/api/invoices`, {
      method: "POST",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify(form),
    });
    expect(res.status).toBe(422);
    const body = (await res.json()) as { errors: { code: string; field?: string }[] };
    expect(body.errors[0]?.code).toBe("INVALID_PAYMENT_METHOD_MISSING_IBAN");
    expect(body.errors[0]?.field).toBe("iban");

    // 0 invoice persistée — ROLLBACK pas même atteint car erreur en amont
    // du pipeline transactionnel.
    const persisted = await sql<{ count: string }[]>`
      SELECT COUNT(*)::text AS count FROM invoices WHERE customer_id = ${seed.customerId}
    `;
    expect(persisted[0]?.count).toBe("0");
  });
});
