import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { MockPADriver } from "@factur-e/shared-fakes";

import { MemorySecretStore } from "../../../src/secrets/index.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";
import { fixtureFormBase, seedInvoiceUser, type InvoiceSeed } from "./_helpers.js";

/**
 * T-CL-CREDIT-NOTES sprint-06 — `POST /api/invoices/:id/credit-note` (brouillon
 * avoir 381 / rectificative 384, pattern restart) + chemin d'envoi (POST
 * /api/invoices type 381/384 → lien BG-3 + pose 209 auto sur l'origine 384).
 *
 * Couvre : happy 381/384 (draft pré-rempli) ; gates 409 (statut non éligible,
 * origine annulée, origine déjà avoir 381) ; 404 ; 401 ; 403 RBAC ; envoi 381
 * (origine inchangée + linked_invoices + filtre type_code) ; envoi 384 (pose
 * 209 auto sur l'origine).
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

const ELIGIBLE_STATUS = "accepted_business";

describe.skipIf(!enabled)("POST /api/invoices/:id/credit-note + envoi 381/384", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;
  let secrets: MemorySecretStore;
  let driver: MockPADriver;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
    secrets = new MemorySecretStore();
    driver = new MockPADriver();
    app = await buildTestApp({ connectionString: db.url, paDriver: driver, secretStore: secrets });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    driver.setCreateInvoiceEventFailure(null);
  });

  /** Émet une facture standard réelle (POST /api/invoices) puis force son
   *  statut courant. Retourne le seed + l'id + le numéro origine. */
  async function seedOrigin(
    status: string,
    opts: { seed?: InvoiceSeed; number?: string } = {},
  ): Promise<{ seed: InvoiceSeed; originId: string; originNumber: string }> {
    const seed = opts.seed ?? (await seedInvoiceUser(sql, { secretStore: secrets }));
    const number = opts.number ?? "F-2026-0001";
    const res = await fetch(`${app.url}/api/invoices`, {
      method: "POST",
      headers: { authorization: `Bearer ${seed.bearer}`, "content-type": "application/json" },
      body: JSON.stringify(fixtureFormBase({ number })),
    });
    expect(res.status).toBe(201);
    const body = (await res.json()) as { invoice: { id: string } };
    const originId = body.invoice.id;
    await sql`UPDATE invoices SET status_current = ${status} WHERE id = ${originId}`;
    return { seed, originId, originNumber: number };
  }

  function postCreditNote(
    originId: string,
    typeCode: "381" | "384",
    bearer?: string,
  ): Promise<Response> {
    return fetch(`${app.url}/api/invoices/${originId}/credit-note`, {
      method: "POST",
      headers:
        bearer === undefined
          ? { "content-type": "application/json" }
          : { authorization: `Bearer ${bearer}`, "content-type": "application/json" },
      body: JSON.stringify({ type_code: typeCode }),
    });
  }

  /** Corps POST /api/invoices d'un avoir/rectificative (mode base + BG-3). */
  function sentCreditNoteBody(o: {
    number: string;
    typeCode: "381" | "384";
    precedingId: string;
    precedingNumber: string;
  }): unknown {
    const base = fixtureFormBase({ number: o.number });
    return {
      ...base,
      document: { number: o.number, issueDate: "2026-05-20", typeCode: o.typeCode, notes: null },
      precedingInvoiceId: o.precedingId,
      precedingInvoiceNumber: o.precedingNumber,
      precedingIssueDate: "2026-05-16",
    };
  }

  function postInvoice(body: unknown, bearer: string): Promise<Response> {
    return fetch(`${app.url}/api/invoices`, {
      method: "POST",
      headers: { authorization: `Bearer ${bearer}`, "content-type": "application/json" },
      body: JSON.stringify(body),
    });
  }

  // ── Endpoint credit-note (brouillon) ──────────────────────────────────

  it("happy 381 → 201 + newDraftId + brouillon pré-rempli (typeCode + BG-3 + lignes)", async () => {
    const { seed, originId, originNumber } = await seedOrigin(ELIGIBLE_STATUS);
    const res = await postCreditNote(originId, "381", seed.bearer);
    expect(res.status).toBe(201);
    const body = (await res.json()) as { newDraftId: string; type_code: string };
    expect(body.type_code).toBe("381");
    expect(body.newDraftId).toBeDefined();

    const drafts = await sql<{ payload: Record<string, unknown> }[]>`
      SELECT payload FROM invoice_drafts WHERE id = ${body.newDraftId}
    `;
    const payload = drafts[0]?.payload as {
      document: { typeCode: string };
      precedingInvoiceId: string;
      precedingInvoiceNumber: string;
      lines: unknown[];
    };
    expect(payload.document.typeCode).toBe("381");
    expect(payload.precedingInvoiceId).toBe(originId);
    expect(payload.precedingInvoiceNumber).toBe(originNumber);
    expect(payload.lines).toHaveLength(1);

    const audits = await sql<{ event_type: string }[]>`
      SELECT event_type FROM auth_audit WHERE user_id = ${seed.userId}
    `;
    expect(audits.some((a) => a.event_type === "invoice.credit_note_created")).toBe(true);
  });

  it("happy 384 → 201 + type_code 384", async () => {
    const { seed, originId } = await seedOrigin(ELIGIBLE_STATUS);
    const res = await postCreditNote(originId, "384", seed.bearer);
    expect(res.status).toBe(201);
    const body = (await res.json()) as { type_code: string };
    expect(body.type_code).toBe("384");
  });

  it("409 si origine dans un statut non éligible (submitted)", async () => {
    const { seed, originId } = await seedOrigin("submitted");
    const res = await postCreditNote(originId, "381", seed.bearer);
    expect(res.status).toBe(409);
  });

  it("409 si origine déjà annulée (cancelled / 209)", async () => {
    const { seed, originId } = await seedOrigin("cancelled");
    const res = await postCreditNote(originId, "381", seed.bearer);
    expect(res.status).toBe(409);
  });

  it("409 si origine est déjà un avoir (type 381 — chaînage AVOIR-9)", async () => {
    const { seed, originId } = await seedOrigin(ELIGIBLE_STATUS);
    await sql`UPDATE invoices SET type_code = '381' WHERE id = ${originId}`;
    const res = await postCreditNote(originId, "381", seed.bearer);
    expect(res.status).toBe(409);
  });

  it("404 si facture inexistante / pas owned", async () => {
    const seed = await seedInvoiceUser(sql, { secretStore: secrets });
    const res = await postCreditNote("00000000-0000-0000-0000-000000000000", "381", seed.bearer);
    expect(res.status).toBe(404);
  });

  it("401 si auth absente", async () => {
    const { originId } = await seedOrigin(ELIGIBLE_STATUS);
    const res = await postCreditNote(originId, "381");
    expect(res.status).toBe(401);
  });

  it("403 si rôle interdit (deposit_simple)", async () => {
    const { seed, originId } = await seedOrigin(ELIGIBLE_STATUS);
    await sql`UPDATE users SET role = 'deposit_simple' WHERE id = ${seed.userId}`;
    const res = await postCreditNote(originId, "381", seed.bearer);
    expect(res.status).toBe(403);
  });

  // ── Chemin d'envoi (POST /api/invoices type 381/384) ──────────────────

  it("envoi 381 → invoice 381 + preceding_invoice_id + origine INCHANGÉE + linked + filtre", async () => {
    const { seed, originId, originNumber } = await seedOrigin(ELIGIBLE_STATUS);
    const res = await postInvoice(
      sentCreditNoteBody({
        number: "AV-2026-001",
        typeCode: "381",
        precedingId: originId,
        precedingNumber: originNumber,
      }),
      seed.bearer,
    );
    expect(res.status).toBe(201);
    const body = (await res.json()) as {
      invoice: { id: string; type_code: string; preceding_invoice_id: string | null };
      preceding_cancellation: unknown;
    };
    expect(body.invoice.type_code).toBe("381");
    expect(body.invoice.preceding_invoice_id).toBe(originId);
    // Avoir 381 : PAS de pose 209 sur l'origine.
    expect(body.preceding_cancellation).toBeNull();

    const origin = await sql<{ status_current: string }[]>`
      SELECT status_current FROM invoices WHERE id = ${originId}
    `;
    expect(origin[0]?.status_current).toBe(ELIGIBLE_STATUS);

    // GET origine → linked_invoices contient l'avoir.
    const getRes = await fetch(`${app.url}/api/invoices/${originId}`, {
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    const detail = (await getRes.json()) as { linked_invoices: { id: string }[] };
    expect(detail.linked_invoices.some((l) => l.id === body.invoice.id)).toBe(true);

    // Filtre liste type_code=381 → ne retourne que l'avoir.
    const listRes = await fetch(`${app.url}/api/invoices?type_code=381`, {
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    const list = (await listRes.json()) as { items: { type_code: string }[] };
    expect(list.items.length).toBeGreaterThanOrEqual(1);
    expect(list.items.every((i) => i.type_code === "381")).toBe(true);
  });

  it("envoi 384 → pose 209 auto sur l'origine (cancelled + cdar 209)", async () => {
    const { seed, originId, originNumber } = await seedOrigin(ELIGIBLE_STATUS);
    const res = await postInvoice(
      sentCreditNoteBody({
        number: "R-2026-001",
        typeCode: "384",
        precedingId: originId,
        precedingNumber: originNumber,
      }),
      seed.bearer,
    );
    expect(res.status).toBe(201);
    const body = (await res.json()) as {
      preceding_cancellation: { cancelled: boolean; preceding_number: string } | null;
    };
    expect(body.preceding_cancellation?.cancelled).toBe(true);
    expect(body.preceding_cancellation?.preceding_number).toBe(originNumber);

    const origin = await sql<{ status_current: string }[]>`
      SELECT status_current FROM invoices WHERE id = ${originId}
    `;
    expect(origin[0]?.status_current).toBe("cancelled");

    const events = await sql<{ code: string; source: string }[]>`
      SELECT code, source FROM cdar_events WHERE invoice_id = ${originId} AND code = 'fr:209'
    `;
    expect(events).toHaveLength(1);
    expect(events[0]?.source).toBe("app");
  });
});
