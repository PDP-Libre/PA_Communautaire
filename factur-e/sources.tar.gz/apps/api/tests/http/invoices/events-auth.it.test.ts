import { randomUUID } from "node:crypto";

import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { MockPADriver } from "@factur-e/shared-fakes";

import { signRefreshToken } from "../../../src/auth/jwt.js";
import { MemorySecretStore } from "../../../src/secrets/index.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";
import { fixtureFormBase, seedInvoiceUser } from "./_helpers.js";

/**
 * T-CL-AUTH-SSE-COOKIE-HTTPONLY (sprint-06, Z9 α) — sécurité du flux SSE
 * `GET /api/invoices/:id/events`. L'auth passe désormais uniquement par le
 * cookie HttpOnly `_session` (refresh token) via `resolveSseAuthContext` :
 *   - cookie `_session` valide → 200 + flux `text/event-stream` ;
 *   - `?token=<bearer>` query SANS cookie → 401 (hard cut, plus de bearer URL) ;
 *   - cookie absent / corrompu → 401 ;
 *   - cookie valide + facture d'un autre customer → 404 (l'auth a réussi).
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

/** Insère une session active + signe le refresh token correspondant (= la
 *  valeur du cookie `_session` posée au login). */
async function sessionCookie(sql: postgres.Sql, userId: string): Promise<string> {
  const sessionId = randomUUID();
  await sql`
    INSERT INTO sessions (id, user_id, expires_at)
    VALUES (${sessionId}, ${userId}, NOW() + INTERVAL '30 days')
  `;
  const refresh = await signRefreshToken({ session_id: sessionId, user_id: userId });
  return `_session=${refresh}`;
}

/** Crée une facture émise réelle (pipeline complet via MockPADriver) et
 *  renvoie son id — la facture porte déjà un cdar_event backlog. */
async function createInvoice(appUrl: string, bearer: string): Promise<string> {
  const res = await fetch(`${appUrl}/api/invoices`, {
    method: "POST",
    headers: { authorization: `Bearer ${bearer}`, "content-type": "application/json" },
    body: JSON.stringify(fixtureFormBase()),
  });
  expect(res.status).toBe(201);
  const body = (await res.json()) as { invoice: { id: string } };
  return body.invoice.id;
}

describe.skipIf(!enabled)("GET /api/invoices/:id/events — auth cookie HttpOnly", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;
  let secrets: MemorySecretStore;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
    secrets = new MemorySecretStore();
    app = await buildTestApp({
      connectionString: db.url,
      paDriver: new MockPADriver(),
      secretStore: secrets,
    });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  it("cookie _session valide → 200 + flux text/event-stream + backlog", async () => {
    const seed = await seedInvoiceUser(sql, { secretStore: secrets });
    const invoiceId = await createInvoice(app.url, seed.bearer);
    const cookie = await sessionCookie(sql, seed.userId);

    const ac = new AbortController();
    const res = await fetch(`${app.url}/api/invoices/${invoiceId}/events`, {
      headers: { cookie },
      signal: ac.signal,
    });

    expect(res.status).toBe(200);
    expect(res.headers.get("content-type")).toContain("text/event-stream");

    // Backlog : le 1er chunk contient l'event CDAR 'Déposée' écrit à la
    // souscription. Lecture bornée pour ne pas pendre sur le keep-alive.
    const reader = res.body?.getReader();
    expect(reader).toBeDefined();
    let firstChunk = "<no-read>";
    if (reader !== undefined) {
      const readPromise = reader
        .read()
        .then((r): string =>
          r.value instanceof Uint8Array ? new TextDecoder().decode(r.value) : "",
        );
      const timeoutPromise = new Promise<string>((resolve) => {
        setTimeout(() => {
          resolve("<timeout>");
        }, 3000);
      });
      firstChunk = await Promise.race([readPromise, timeoutPromise]);
      await reader.cancel();
    }
    expect(firstChunk).toContain("data:");
    ac.abort();
  });

  it("?token=<bearer> query SANS cookie → 401 (hard cut)", async () => {
    const seed = await seedInvoiceUser(sql, { secretStore: secrets });
    const invoiceId = await createInvoice(app.url, seed.bearer);

    const res = await fetch(
      `${app.url}/api/invoices/${invoiceId}/events?token=${encodeURIComponent(seed.bearer)}`,
    );
    expect(res.status).toBe(401);
    await res.body?.cancel();
  });

  it("cookie absent → 401", async () => {
    const seed = await seedInvoiceUser(sql, { secretStore: secrets });
    const invoiceId = await createInvoice(app.url, seed.bearer);

    const res = await fetch(`${app.url}/api/invoices/${invoiceId}/events`);
    expect(res.status).toBe(401);
    await res.body?.cancel();
  });

  it("cookie _session corrompu → 401", async () => {
    const seed = await seedInvoiceUser(sql, { secretStore: secrets });
    const invoiceId = await createInvoice(app.url, seed.bearer);

    const res = await fetch(`${app.url}/api/invoices/${invoiceId}/events`, {
      headers: { cookie: "_session=not-a-valid-jwt" },
    });
    expect(res.status).toBe(401);
    await res.body?.cancel();
  });

  it("cookie valide + facture inexistante → 404 (auth a réussi, pas 401)", async () => {
    const seed = await seedInvoiceUser(sql, { secretStore: secrets });
    const cookie = await sessionCookie(sql, seed.userId);

    const res = await fetch(`${app.url}/api/invoices/${randomUUID()}/events`, {
      headers: { cookie },
    });
    expect(res.status).toBe(404);
    await res.body?.cancel();
  });
});
