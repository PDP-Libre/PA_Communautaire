import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { MockPADriver } from "@factur-e/shared-fakes";

import { MemorySecretStore } from "../../../src/secrets/index.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";
import {
  FIXTURE_BURGER_QUEEN,
  FIXTURE_TRICATEL,
  seedBurgerQueenTricatelPair,
  fixtureFormBaseDynamic,
} from "../../_fixtures/seed-customer.js";

/**
 * Cas #18 — Cross-company avec fixtures sandbox réels SuperPDP. User
 * Burger Queen émet une facture vers buyer Tricatel — vérifie que les
 * identifiants Peppol annuaire propriétaire transitent correctement
 * (BT-30 sender = BQ `0225:315143296_3686`, BT-49 buyer = Tricatel
 * `0225:315143296_3685`).
 *
 * Brief §3.4 cas #18 + [NOTE-COWORK 2026-05-20] délégation sandbox :
 * compte Bruno SuperPDP délégué BQ + Tricatel via application. Côté
 * Factur-E modélisé en 2 users distincts (`bq@dev` + `tricatel@dev`).
 *
 * Pendant testable T-BR-EMIT en sandbox réelle — ici on valide
 * uniquement le pipeline route (MockPADriver capture l'input et confirme
 * les identifiants annuaire propagés).
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("POST /api/invoices — cross-company BQ → Tricatel (sandbox réel)", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;
  let secrets: MemorySecretStore;
  let driver: MockPADriver;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
    secrets = new MemorySecretStore();
    driver = new MockPADriver();
    app = await buildTestApp({ connectionString: db.url, paDriver: driver, secretStore: secrets });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    driver.reset();
    secrets.clear();
  });

  it("BQ → Tricatel : identifiants annuaire SuperPDP propagés au driver + cdar_events injecté", async () => {
    // Seed les 2 sandbox + leurs bundles secret.
    const { bq, tricatel } = await seedBurgerQueenTricatelPair(sql, { secretStore: secrets });
    expect(bq.peppolAddress).toBe(FIXTURE_BURGER_QUEEN.peppolAddressPrimary);
    expect(tricatel.peppolAddress).toBe(FIXTURE_TRICATEL.peppolAddressPrimary);

    // BQ émet vers Tricatel (buyer fixture = Tricatel SIREN + adresse annuaire).
    const form = fixtureFormBaseDynamic({
      number: "F-BQ-2026-0001",
      buyerSiren: FIXTURE_TRICATEL.siren,
      buyerLegalName: FIXTURE_TRICATEL.legalName,
      buyerPeppolAddress: FIXTURE_TRICATEL.peppolAddressPrimary,
    });

    const res = await fetch(`${app.url}/api/invoices`, {
      method: "POST",
      headers: {
        authorization: `Bearer ${bq.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify(form),
    });
    expect(res.status).toBe(201);
    const body = (await res.json()) as {
      invoice: { customer_id: string; pa_invoice_id: string };
      cdar_events: { code: string; source: string }[];
    };

    // Driver a été appelé 1× côté BQ.
    expect(driver.counts.submitInvoice).toBe(1);

    // cdar_events synthétique injecté côté BQ (source='synthetic').
    expect(body.cdar_events).toHaveLength(1);
    expect(body.cdar_events[0]?.source).toBe("synthetic");

    // Vérification BDD : invoice persistée sur le customer BQ (pas Tricatel).
    const bqInvoices = await sql<{ id: string; pa_invoice_id: string }[]>`
      SELECT id, pa_invoice_id FROM invoices WHERE customer_id = ${bq.customerId}
    `;
    expect(bqInvoices).toHaveLength(1);

    const tricatelInvoices = await sql<{ count: string }[]>`
      SELECT COUNT(*)::text AS count FROM invoices WHERE customer_id = ${tricatel.customerId}
    `;
    expect(tricatelInvoices[0]?.count).toBe("0");

    // Cross-check : le user BQ ne peut pas requêter le customer Tricatel
    // (token JWT scope par customer_id) — preuve d'isolation.
    const isolationProbe = await fetch(`${app.url}/api/invoices`, {
      method: "GET",
      headers: { authorization: `Bearer ${bq.bearer}` },
    });
    expect(isolationProbe.status).toBe(200);
    const list = (await isolationProbe.json()) as { items: { customer_id: string }[] };
    // Toutes les invoices retournées appartiennent au customer BQ (isolation
    // garantie par `resolveAuthContext` + filtre SQL `WHERE customer_id =`).
    for (const inv of list.items) {
      expect(inv.customer_id).toBe(bq.customerId);
    }
    expect(list.items.length).toBeGreaterThanOrEqual(1);
  });
});
