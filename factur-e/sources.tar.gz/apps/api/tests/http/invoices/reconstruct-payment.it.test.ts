import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { MockPADriver } from "@factur-e/shared-fakes";

import { insertExportRequest } from "../../../src/db/repos/export_requests.js";
import { MockEmailSender } from "../../../src/email/sender.js";
import { runExportZipGenerate } from "../../../src/services/export-zip-generate.js";
import { MemorySecretStore } from "../../../src/secrets/index.js";
import { MockObjectStorage } from "../../../src/storage/object-storage.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";
import { fixtureFormBase, seedInvoiceUser } from "./_helpers.js";

/**
 * Finding G sprint-07 — régénération fidèle du bloc paiement.
 *
 * Avant le fix, `reconstructFormFromPersisted` hardcodait
 * `transfer`/30j/null. Conséquence sur les 3 consommateurs de la
 * reconstruction (`GET /pdf`, `GET /xml`, export ZIP émission) :
 *  - document régénéré toujours « virement à 30 jours » sans mentions LME ;
 *  - **500** `INVALID_PAYMENT_METHOD_MISSING_IBAN` sur une facture chèque
 *    émise par un vendeur sans IBAN (le hardcode `transfer` force la règle
 *    IBAN à la reconstruction).
 *
 * Après le fix, le bloc paiement est persisté à l'émission
 * (`extractPayloadExtended`) et réinjecté à la reconstruction.
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("reconstruction bloc paiement (finding G)", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;
  let secrets: MemorySecretStore;
  let exportsStorage: MockObjectStorage;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
    secrets = new MemorySecretStore();
    exportsStorage = new MockObjectStorage();
    app = await buildTestApp({
      connectionString: db.url,
      paDriver: new MockPADriver(),
      secretStore: secrets,
      exportsStorage,
    });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  const emit = (bearer: string, body: unknown): Promise<Response> =>
    fetch(`${app.url}/api/invoices`, {
      method: "POST",
      headers: { authorization: `Bearer ${bearer}`, "content-type": "application/json" },
      body: JSON.stringify(body),
    });

  const get = (bearer: string, path: string): Promise<Response> =>
    fetch(`${app.url}${path}`, { headers: { authorization: `Bearer ${bearer}` } });

  it("facture chèque (vendeur sans IBAN) → /pdf + /xml + export ZIP succeed, paiement reconstruit", async () => {
    // Vendeur SANS IBAN — le hardcode `transfer` faisait crasher la
    // reconstruction (INVALID_PAYMENT_METHOD_MISSING_IBAN).
    const seed = await seedInvoiceUser(sql, { secretStore: secrets, iban: null, bic: null });
    const form = {
      ...fixtureFormBase({ number: "F-2026-CHQ" }),
      payment: {
        paymentTerms: { kind: "endOfMonth", days: 15 },
        paymentMethodKind: "check",
        mentionsLegales: "Escompte 2% sous 10 jours — pénalités 3× taux légal (art. L441-10)",
      },
    };

    const emitRes = await emit(seed.bearer, form);
    expect(emitRes.status).toBe(201);
    const { invoice } = (await emitRes.json()) as { invoice: { id: string } };

    // (1) GET /pdf — 200 au lieu de 500.
    const pdfRes = await get(seed.bearer, `/api/invoices/${invoice.id}/pdf`);
    expect(pdfRes.status).toBe(200);
    expect(pdfRes.headers.get("content-type")).toContain("application/pdf");

    // (2) GET /xml — 200 + paiement chèque (TypeCode 20) + AUCUN IBAN (ADR-008).
    const xmlRes = await get(seed.bearer, `/api/invoices/${invoice.id}/xml`);
    expect(xmlRes.status).toBe(200);
    const xml = await xmlRes.text();
    expect(xml).toContain("<ram:TypeCode>20</ram:TypeCode>"); // BT-81 chèque (≠ 58 virement)
    expect(xml).not.toContain("IBANID");
    // Termes réellement saisis (endOfMonth/15) préservés dans le document
    // régénéré — preuve que la variante de l'union discriminée n'est PAS
    // coercée vers le hardcode `days:30` (ZG-3). BT-20 description dérivée
    // de `paymentTerms` côté builder.
    // NB : `mentionsLegales` (champ libre BT-20) est bien persisté +
    // reconstruit (cf. unit tests) mais n'est pas mappé au XML CII en V1
    // (champ capté non-rendu, pré-existant — hors scope finding G).
    expect(xml).toContain("<ram:Description>Règlement à 15 jours fin de mois</ram:Description>");

    // (3) Export ZIP émission — la reconstruction ne doit pas échouer.
    const request = await insertExportRequest(sql, {
      customer_id: seed.customerId,
      requested_by_user_id: seed.userId,
      scope: "emission",
      filters: {},
      invoice_ids: [invoice.id],
      invoice_count: 1,
    });
    await runExportZipGenerate(
      {
        sql,
        exportsStorage,
        paDriver: new MockPADriver(),
        secrets,
        email: new MockEmailSender(),
        webBaseUrl: "http://web",
      },
      { exportRequestId: request.id },
    );
    // exported_at n'est posé que si l'entrée émission n'a PAS d'erreur de
    // reconstruction (cf. export-zip-generate `exportedEmissionIds`).
    const rows = await sql<{ exported_at: Date | null }[]>`
      SELECT exported_at FROM invoices WHERE id = ${invoice.id}
    `;
    expect(rows[0]?.exported_at).not.toBeNull();
  });

  it("régression virement (vendeur avec IBAN) → /xml régénéré porte l'IBAN (BG-17)", async () => {
    const seed = await seedInvoiceUser(sql, { secretStore: secrets });
    const form = {
      ...fixtureFormBase({ number: "F-2026-VIR" }),
      payment: {
        paymentTerms: { kind: "days", days: 45 },
        paymentMethodKind: "transfer",
        mentionsLegales: null,
      },
    };

    const emitRes = await emit(seed.bearer, form);
    expect(emitRes.status).toBe(201);
    const { invoice } = (await emitRes.json()) as { invoice: { id: string } };

    const xmlRes = await get(seed.bearer, `/api/invoices/${invoice.id}/xml`);
    expect(xmlRes.status).toBe(200);
    const xml = await xmlRes.text();
    // BG-17 — IBAN déchiffré ré-sourcé depuis `seller`, pas depuis
    // payload_extended (ADR-008).
    expect(xml).toContain("<ram:TypeCode>58</ram:TypeCode>"); // BT-81 virement SEPA
    expect(xml).toContain("<ram:IBANID>FR7630006000011234567890189</ram:IBANID>");
  });
});
