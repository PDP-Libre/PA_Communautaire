import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { MockPADriver } from "@factur-e/shared-fakes";

import { MemorySecretStore } from "../../../src/secrets/index.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";
import { fixtureFormBase, seedInvoiceUser } from "./_helpers.js";

/**
 * Cas 7 — Liste filtrée avec status + date range + search.
 * Crée 3 invoices avec dates/numéros variés, vérifie chaque filtre.
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("GET /api/invoices — filtres", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;
  let secrets: MemorySecretStore;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
    secrets = new MemorySecretStore();
    app = await buildTestApp({
      connectionString: db.url,
      paDriver: new MockPADriver(),
      secretStore: secrets,
    });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  it("filtre par status / search / date_from + tenant isolation", async () => {
    const seed = await seedInvoiceUser(sql, { secretStore: secrets });

    // Crée 3 invoices avec dates variées
    for (const [num, date] of [
      ["F-2026-0001", "2026-04-01"],
      ["F-2026-0002", "2026-05-01"],
      ["F-2026-0003", "2026-05-15"],
    ] as const) {
      const form = fixtureFormBase({ number: num });
      form.document.issueDate = date;
      const res = await fetch(`${app.url}/api/invoices`, {
        method: "POST",
        headers: {
          authorization: `Bearer ${seed.bearer}`,
          "content-type": "application/json",
        },
        body: JSON.stringify(form),
      });
      expect(res.status).toBe(201);
    }

    // Liste sans filtre → 3
    const all = await fetch(`${app.url}/api/invoices`, {
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    expect(all.status).toBe(200);
    const allBody = (await all.json()) as { items: unknown[]; total: number };
    expect(allBody.total).toBe(3);
    expect(allBody.items).toHaveLength(3);

    // Filtre status=submitted (toutes émises → status_current
    // FacturEStatusCode normalisé 'submitted' depuis l'`api:uploaded`
    // initial du MockPADriver — rename T-CL-PA-INVOICE-FIX ADR-012 D2,
    // ex-`Déposée` libellé).
    const byStatus = await fetch(`${app.url}/api/invoices?status=submitted`, {
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    expect(byStatus.status).toBe(200);
    const byStatusBody = (await byStatus.json()) as { total: number };
    expect(byStatusBody.total).toBe(3);

    // Filtre date_from=2026-05-01 → 2 invoices (0002 et 0003)
    const byDate = await fetch(`${app.url}/api/invoices?date_from=2026-05-01`, {
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    expect(byDate.status).toBe(200);
    const byDateBody = (await byDate.json()) as { items: { number: string }[]; total: number };
    expect(byDateBody.total).toBe(2);
    expect(byDateBody.items.map((i) => i.number).sort()).toEqual(["F-2026-0002", "F-2026-0003"]);

    // Filtre search=0003 (ILIKE %0003%) → 1 invoice
    const bySearch = await fetch(`${app.url}/api/invoices?search=0003`, {
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    expect(bySearch.status).toBe(200);
    const bySearchBody = (await bySearch.json()) as { items: { number: string }[]; total: number };
    expect(bySearchBody.total).toBe(1);
    expect(bySearchBody.items[0]?.number).toBe("F-2026-0003");

    // Tenant isolation : un autre customer ne voit rien
    const seedB = await seedInvoiceUser(sql, {
      siren: "222222221",
      email: "b@b.fr",
      secretStore: secrets,
    });
    const otherTenant = await fetch(`${app.url}/api/invoices`, {
      headers: { authorization: `Bearer ${seedB.bearer}` },
    });
    expect(otherTenant.status).toBe(200);
    const otherBody = (await otherTenant.json()) as { total: number };
    expect(otherBody.total).toBe(0);
  });

  // sprint-07 T-CL-W3-C finding S — filtre retention=expiring : factures
  // éligibles export (exported_at IS NULL) dont la purge (created_at + 6 mois)
  // tombe dans les 30 prochains jours. Lien ExportRappelBanner.
  it("filtre retention=expiring → factures non exportées approchant la purge", async () => {
    const seed = await seedInvoiceUser(sql, {
      siren: "333333331",
      email: "c@c.fr",
      secretStore: secrets,
    });

    async function createInvoice(number: string): Promise<string> {
      const res = await fetch(`${app.url}/api/invoices`, {
        method: "POST",
        headers: {
          authorization: `Bearer ${seed.bearer}`,
          "content-type": "application/json",
        },
        body: JSON.stringify(fixtureFormBase({ number })),
      });
      expect(res.status).toBe(201);
      return ((await res.json()) as { invoice: { id: string } }).invoice.id;
    }

    const expiringId = await createInvoice("F-2026-1001");
    const recentId = await createInvoice("F-2026-1002");
    const exportedExpiringId = await createInvoice("F-2026-1003");

    // `expiring` : purge dans ~10 jours (created_at il y a 5 mois et 20 jours).
    await sql`UPDATE invoices SET created_at = NOW() - INTERVAL '5 months 20 days'
              WHERE id = ${expiringId}`;
    // `recent` : créée aujourd'hui → purge dans ~6 mois → hors fenêtre 30 jours.
    // (laissé tel quel)
    void recentId;
    // `exportedExpiring` : même fenêtre de purge MAIS déjà exportée → exclue.
    await sql`UPDATE invoices
              SET created_at = NOW() - INTERVAL '5 months 20 days', exported_at = NOW()
              WHERE id = ${exportedExpiringId}`;

    const res = await fetch(`${app.url}/api/invoices?retention=expiring`, {
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    expect(res.status).toBe(200);
    const body = (await res.json()) as { items: { number: string }[]; total: number };
    expect(body.total).toBe(1);
    expect(body.items.map((i) => i.number)).toEqual(["F-2026-1001"]);
  });

  it("retention valeur invalide → 400 (z.literal('expiring'))", async () => {
    const seed = await seedInvoiceUser(sql, {
      siren: "444444441",
      email: "d@d.fr",
      secretStore: secrets,
    });
    const res = await fetch(`${app.url}/api/invoices?retention=soon`, {
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    expect(res.status).toBe(400);
  });
});
