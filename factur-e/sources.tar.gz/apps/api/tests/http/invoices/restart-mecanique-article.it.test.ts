import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { MockPADriver } from "@factur-e/shared-fakes";

import { MemorySecretStore } from "../../../src/secrets/index.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";
import { fixtureFormBase, seedInvoiceUser } from "./_helpers.js";

/**
 * Cas 4 — Restart d'une invoice émise vers nouveau draft + test négatif
 * **mécanique Article = initialiseur (T-CW-11 acté)** :
 *
 *   - POST /api/invoices/:id/restart crée un nouveau draft cloné.
 *   - Les lignes du draft sont copiées **indépendantes** des Articles
 *     d'origine.
 *   - Modifier une ligne du draft (via PATCH) ne modifie pas les
 *     `products` du customer (cas concret : si le client avait
 *     initialement choisi un Article catalogue à 500€, et qu'il modifie
 *     le prix dans le clone à 600€, le produit catalogue reste à 500€).
 *
 * NB : dans ce test on s'assure que **l'invoice et ses lignes** source
 * restent inchangées après restart. Le test "modifier prix dans le
 * clone" se ferait via PATCH /api/invoice-drafts/:id ; ici on vérifie
 * la séparation au niveau BDD.
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("POST /api/invoices/:id/restart — mécanique Article", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;
  let secrets: MemorySecretStore;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
    secrets = new MemorySecretStore();
    app = await buildTestApp({
      connectionString: db.url,
      paDriver: new MockPADriver(),
      secretStore: secrets,
    });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  it("clone l'invoice vers un draft + lignes indépendantes + source inchangée", async () => {
    const seed = await seedInvoiceUser(sql, { secretStore: secrets });

    // Step 1 — créer une invoice source
    const createRes = await fetch(`${app.url}/api/invoices`, {
      method: "POST",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify(fixtureFormBase({ number: "F-2026-0042" })),
    });
    expect(createRes.status).toBe(201);
    const sourceInvoice = (await createRes.json()) as {
      invoice: { id: string; number: string };
    };
    const sourceId = sourceInvoice.invoice.id;

    // Step 2 — restart vers nouveau draft
    const restartRes = await fetch(`${app.url}/api/invoices/${sourceId}/restart`, {
      method: "POST",
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    expect(restartRes.status).toBe(201);
    const restartBody = (await restartRes.json()) as { newDraftId: string };
    expect(restartBody.newDraftId).toMatch(/^[0-9a-f-]{36}$/);

    // Step 3 — récupérer le draft et vérifier qu'il contient les lignes
    // clonées + suggestion numéro auto-incrémenté.
    const draftRes = await fetch(`${app.url}/api/invoice-drafts/${restartBody.newDraftId}`, {
      headers: { authorization: `Bearer ${seed.bearer}` },
    });
    expect(draftRes.status).toBe(200);
    const draft = (await draftRes.json()) as {
      payload: {
        ui_mode: string;
        restartedFromInvoiceId: string;
        document: { number: string };
        lines: { label: string; unitPriceHt: string }[];
      };
    };
    expect(draft.payload.restartedFromInvoiceId).toBe(sourceId);
    expect(draft.payload.document.number).toBe("F-2026-0043"); // F-2026-0042 + 1
    expect(draft.payload.lines).toHaveLength(1);
    expect(draft.payload.lines[0]?.label).toBe("Prestation conseil");

    // Step 4 — modifier la ligne du draft (PATCH) avec un prix différent
    const modifiedPayload = {
      ...draft.payload,
      lines: [
        {
          ...draft.payload.lines[0],
          unitPriceHt: "999.99", // Override
          totalHt: "999.99",
        },
      ],
    };
    const patchRes = await fetch(`${app.url}/api/invoice-drafts/${restartBody.newDraftId}`, {
      method: "PATCH",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify({ payload: modifiedPayload }),
    });
    expect(patchRes.status).toBe(200);

    // Step 5 — invoice source DOIT être inchangée
    const sourceCheck = await sql<{ unit_price_ht: string; label: string }[]>`
      SELECT unit_price_ht::text AS unit_price_ht, label
      FROM invoice_lines WHERE invoice_id = ${sourceId}
    `;
    expect(sourceCheck).toHaveLength(1);
    expect(sourceCheck[0]?.unit_price_ht).toBe("500.0000");
    expect(sourceCheck[0]?.label).toBe("Prestation conseil");

    // Audit invoice_restarted_from écrit.
    const audits = await sql<{ event_type: string }[]>`
      SELECT event_type FROM auth_audit WHERE user_id = ${seed.userId}
    `;
    expect(audits.some((a) => a.event_type === "invoice_restarted_from")).toBe(true);
  });
});
