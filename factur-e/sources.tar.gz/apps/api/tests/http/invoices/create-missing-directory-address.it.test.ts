import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { MockPADriver } from "@factur-e/shared-fakes";

import { MemorySecretStore } from "../../../src/secrets/index.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";
import { seedFullCustomer } from "../../_fixtures/seed-customer.js";
import { fixtureFormBase } from "./_helpers.js";

/**
 * Cas #8 — `customers.directory_address` manquante. Endpoint
 * `create.ts:154` court-circuite avant le call PA → 412 +
 * userMessage "Re-connectez-vous à votre PA". Pas d'invoice persistée,
 * pas de call driver, pas d'audit submission.
 *
 * Scope étendu PMO 2026-05-20 (brief §3.3) — couvre le path négatif que
 * le front consomme via la modal `missingAddressModal` du formulaire
 * d'émission.
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("POST /api/invoices — directory_address manquante (412)", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;
  let secrets: MemorySecretStore;
  let driver: MockPADriver;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
    secrets = new MemorySecretStore();
    driver = new MockPADriver();
    app = await buildTestApp({ connectionString: db.url, paDriver: driver, secretStore: secrets });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    driver.reset();
  });

  it("412 + message canonique + 0 call driver + 0 invoice persistée", async () => {
    const seed = await seedFullCustomer(sql, {
      withDirectoryAddress: false,
      secretStore: secrets,
    });

    const res = await fetch(`${app.url}/api/invoices`, {
      method: "POST",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify(fixtureFormBase()),
    });
    expect(res.status).toBe(412);
    const body = (await res.json()) as { message: string };
    expect(body.message).toMatch(
      /Votre entreprise n'a pas d'adresse électronique Plateforme Agréée/i,
    );
    expect(body.message).toMatch(/Re-connectez-vous à votre PA/i);

    // Driver pas appelé (court-circuit pre-pipeline).
    expect(driver.counts.submitInvoice).toBe(0);

    const persisted = await sql<{ count: string }[]>`
      SELECT COUNT(*)::text AS count FROM invoices WHERE customer_id = ${seed.customerId}
    `;
    expect(persisted[0]?.count).toBe("0");
  });

  it("412 même quand directory_address = '' (chaine vide — protection symétrique)", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    // Reset directory_address à '' explicitement.
    await sql`UPDATE customers SET directory_address = '' WHERE id = ${seed.customerId}`;

    const res = await fetch(`${app.url}/api/invoices`, {
      method: "POST",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify(fixtureFormBase()),
    });
    expect(res.status).toBe(412);
    expect(driver.counts.submitInvoice).toBe(0);
  });
});
