import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { fixturesBy } from "@factur-e/factur-x-fixtures";
import { MockPADriver } from "@factur-e/shared-fakes";

import { MemorySecretStore } from "../../../src/secrets/index.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";
import { fixtureFormBase, seedInvoiceUser } from "./_helpers.js";

/**
 * S1 — Schematron FNFE câblé à l'émission (T-CL-S1-WIRE-EMISSION).
 *
 * La cascade `validateCascade` tourne après le XSD bloquant (ADR-016 D4) :
 *   - aucune fatale → l'envoi passe (201) et les warnings sont propagés à l'UI
 *     via `schematron_warnings` (politique ADR-009 : warning = non bloquant) ;
 *   - une fatale bloquerait l'envoi (422). Note : par construction, une facture
 *     émise via le formulaire est conforme (le builder calcule des totaux
 *     cohérents, la cotraitance — seules fatales BR-FR-Flux2 — est refusée en
 *     amont). Le bloc 422 est donc un filet defense-in-depth ; sa détection de
 *     fatale est verrouillée au niveau builder
 *     (`packages/factur-x-builder/tests/schematron/psvi-guardrail.test.ts`,
 *     XML falsifié → cascade.ok === false) et son mapping d'anomalies par
 *     `tests/unit/schematron-anomalies.test.ts`.
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("POST /api/invoices — cascade Schematron (S1)", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;
  let secrets: MemorySecretStore;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
    secrets = new MemorySecretStore();
    app = await buildTestApp({
      connectionString: db.url,
      paDriver: new MockPADriver(),
      secretStore: secrets,
    });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  it("émission conforme → 201 + warnings Schematron propagés à l'UI", async () => {
    const seed = await seedInvoiceUser(sql, { secretStore: secrets });

    const res = await fetch(`${app.url}/api/invoices`, {
      method: "POST",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify(fixtureFormBase()),
    });

    expect(res.status).toBe(201);
    const body = (await res.json()) as {
      schematron_warnings: {
        rule_id: string;
        severity: string;
        message: string;
        xpath: string;
        step: string;
      }[];
    };

    // La cascade s'est exécutée et a propagé ses avertissements (non bloquants).
    expect(Array.isArray(body.schematron_warnings)).toBe(true);
    const warn = body.schematron_warnings.find((w) => w.rule_id === "BR-FR-23_BT-49");
    expect(warn).toBeDefined();
    expect(warn?.severity).toBe("warning");
    expect(warn?.step).toBe("schematron-br-fr-flux2");
    expect(warn?.message.length).toBeGreaterThan(0);
    expect(warn?.xpath.length).toBeGreaterThan(0);
  });

  it("aperçu → non-conformités Schematron listées pré-envoi (200)", async () => {
    const seed = await seedInvoiceUser(sql, { secretStore: secrets });

    const res = await fetch(`${app.url}/api/invoices/preview`, {
      method: "POST",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify(fixtureFormBase()),
    });

    expect(res.status).toBe(200);
    const body = (await res.json()) as {
      schematron_anomalies: {
        rule_id: string;
        severity: string;
        message: string;
        label_fr: string | null;
        xpath: string;
        step: string;
      }[];
    };

    expect(Array.isArray(body.schematron_anomalies)).toBe(true);
    const anomaly = body.schematron_anomalies.find((a) => a.rule_id === "BR-FR-23_BT-49");
    expect(anomaly).toBeDefined();
    expect(anomaly?.severity).toBe("warning");
    // BR-FR-23 non couvert par l'override → label_fr null, le svrl:text suffit.
    expect(anomaly?.label_fr).toBeNull();
    expect(anomaly?.message.length).toBeGreaterThan(0);
  });

  it("émission non conforme (vendeur sans n° TVA, ligne S) → 422 fatale BR-S-02", async () => {
    const seed = await seedInvoiceUser(sql, { secretStore: secrets });
    // Retire le n° TVA vendeur (BT-31). Sur une ligne au taux standard (S), la
    // règle EN16931 BR-S-02 devient fatale → la cascade bloque l'émission.
    // (Reproduit le finding e2e T-CL-S1 — oracle déterministe, Levier 1.)
    await sql`UPDATE customers SET vat_number = NULL WHERE id = ${seed.customerId}`;

    const res = await fetch(`${app.url}/api/invoices`, {
      method: "POST",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify(fixtureFormBase()),
    });

    expect(res.status).toBe(422);
    const body = (await res.json()) as {
      schematron: {
        profile: string;
        anomalies: { rule_id: string; severity: string; label_fr: string | null }[];
      };
    };
    expect(body.schematron.profile).toBe("extended-ctc-fr");
    const fatal = body.schematron.anomalies.find((a) => a.rule_id === "BR-S-02");
    expect(fatal).toBeDefined();
    expect(fatal?.severity).toBe("fatal");
    // Le libellé FR actionnable est propagé à l'UI (override, pas le svrl:text anglais).
    expect(fatal?.label_fr).toMatch(/TVA du vendeur/i);
  });
});

/**
 * S1 — corpus de blocage (T-CL-FIXTURES-WIRING §3.3). Les 3 fixtures NC
 * `@factur-e/factur-x-fixtures` (passent Zod + formToModel, seule la cascade
 * lève) sont POSTées telles quelles → 422 + l'id de règle attendu, pour que
 * W1 n'invente pas ses cas NC (contrat §2). Pendant déterministe non-gated :
 * `convergence-corpus.test.ts` (cascade pure, hors HTTP).
 */
describe.skipIf(!enabled)("POST /api/invoices — corpus NC (S1 blocage 422)", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;
  let secrets: MemorySecretStore;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
    secrets = new MemorySecretStore();
    app = await buildTestApp({
      connectionString: db.url,
      paDriver: new MockPADriver(),
      secretStore: secrets,
    });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  for (const fx of fixturesBy({ conformant: false })) {
    const rule = fx.expect.schematron?.expectViolations[0] ?? "";
    it(`${fx.meta.id} → 422 fatale ${rule}`, async () => {
      const seed = await seedInvoiceUser(sql, { secretStore: secrets });

      const res = await fetch(`${app.url}/api/invoices`, {
        method: "POST",
        headers: {
          authorization: `Bearer ${seed.bearer}`,
          "content-type": "application/json",
        },
        body: JSON.stringify(fx.form),
      });

      expect(res.status, fx.meta.id).toBe(422);
      const body = (await res.json()) as {
        schematron: { profile: string; anomalies: { rule_id: string; severity: string }[] };
      };
      expect(body.schematron.profile).toBe("extended-ctc-fr");
      const fatal = body.schematron.anomalies.find(
        (a) => a.severity === "fatal" && a.rule_id.includes(rule),
      );
      expect(fatal, `${fx.meta.id} : règle ${rule} absente des anomalies`).toBeDefined();
    });
  }
});
