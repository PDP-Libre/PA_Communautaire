import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { InvoiceRejectedXsdException } from "@factur-e/pa-adapter";
import { MockPADriver } from "@factur-e/shared-fakes";

import { MemorySecretStore } from "../../../src/secrets/index.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";
import { fixtureFormBase, seedInvoiceUser, type InvoiceSeed } from "./_helpers.js";

/**
 * T-CL-API-INVOICE-MARK-PAID sprint-06 — `POST /api/invoices/:id/mark-paid`
 * (pose 212 Encaissée côté Émetteur, US-CDAR-008 PRD §5.11). Couvre :
 *   - happy path 205 Approuvée → 200 + CDAR 212 (source 'app') + status `paid`
 *     + audit `invoice.marked_paid` (flag vat_on_encashment) ;
 *   - RBAC Restreint (deposit_simple) → 403 (Z3) ;
 *   - statut ≠ 205 → 409 (Z4) ;
 *   - facture inexistante → 404 ; auth absente → 401 ;
 *   - PA refuse (4xx) → 422 propagé (NC-15).
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("POST /api/invoices/:id/mark-paid", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;
  let secrets: MemorySecretStore;
  let driver: MockPADriver;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
    secrets = new MemorySecretStore();
    driver = new MockPADriver();
    app = await buildTestApp({ connectionString: db.url, paDriver: driver, secretStore: secrets });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    driver.setCreateInvoiceEventFailure(null);
  });

  /** Crée une facture émise réelle puis force son statut courant. */
  async function seedInvoiceAtStatus(
    statusCurrent: string,
  ): Promise<{ seed: InvoiceSeed; invoiceId: string }> {
    const seed = await seedInvoiceUser(sql, { secretStore: secrets });
    const res = await fetch(`${app.url}/api/invoices`, {
      method: "POST",
      headers: { authorization: `Bearer ${seed.bearer}`, "content-type": "application/json" },
      body: JSON.stringify(fixtureFormBase()),
    });
    expect(res.status).toBe(201);
    const body = (await res.json()) as { invoice: { id: string } };
    const invoiceId = body.invoice.id;
    await sql`UPDATE invoices SET status_current = ${statusCurrent} WHERE id = ${invoiceId}`;
    return { seed, invoiceId };
  }

  function markPaid(invoiceId: string, bearer?: string): Promise<Response> {
    return fetch(`${app.url}/api/invoices/${invoiceId}/mark-paid`, {
      method: "POST",
      headers: bearer === undefined ? {} : { authorization: `Bearer ${bearer}` },
    });
  }

  it("205 Approuvée → 200 + CDAR 212 source 'app' + status paid + audit", async () => {
    const { seed, invoiceId } = await seedInvoiceAtStatus("accepted_business");
    await sql`UPDATE customers SET vat_on_encashment = TRUE WHERE id = ${seed.customerId}`;

    const res = await markPaid(invoiceId, seed.bearer);
    expect(res.status).toBe(200);
    const body = (await res.json()) as {
      invoice: { status_current: string };
      cdarEvent: { code: string; source: string } | null;
    };
    expect(body.invoice.status_current).toBe("paid");
    expect(body.cdarEvent?.code).toBe("fr:212");
    expect(body.cdarEvent?.source).toBe("app");

    const persisted = await sql<{ status_current: string }[]>`
      SELECT status_current FROM invoices WHERE id = ${invoiceId}
    `;
    expect(persisted[0]?.status_current).toBe("paid");

    const events = await sql<{ code: string; source: string }[]>`
      SELECT code, source FROM cdar_events WHERE invoice_id = ${invoiceId} AND code = 'fr:212'
    `;
    expect(events).toHaveLength(1);
    expect(events[0]?.source).toBe("app");

    const audits = await sql<
      { event_type: string; metadata: { vat_on_encashment_flag: boolean } }[]
    >`
      SELECT event_type, metadata FROM auth_audit WHERE user_id = ${seed.userId}
    `;
    const marked = audits.find((a) => a.event_type === "invoice.marked_paid");
    expect(marked).toBeDefined();
    expect(marked?.metadata.vat_on_encashment_flag).toBe(true);
  });

  it("rôle Restreint (deposit_simple) → 403", async () => {
    const { seed, invoiceId } = await seedInvoiceAtStatus("accepted_business");
    await sql`UPDATE users SET role = 'deposit_simple' WHERE id = ${seed.userId}`;

    const res = await markPaid(invoiceId, seed.bearer);
    expect(res.status).toBe(403);
  });

  it("statut ≠ 205 Approuvée (submitted) → 409 Conflict", async () => {
    const { seed, invoiceId } = await seedInvoiceAtStatus("submitted");

    const res = await markPaid(invoiceId, seed.bearer);
    expect(res.status).toBe(409);
  });

  it("facture inexistante / pas owned → 404", async () => {
    const seed = await seedInvoiceUser(sql, { secretStore: secrets });
    const res = await markPaid("00000000-0000-0000-0000-000000000000", seed.bearer);
    expect(res.status).toBe(404);
  });

  it("auth absente → 401", async () => {
    const { invoiceId } = await seedInvoiceAtStatus("accepted_business");
    const res = await markPaid(invoiceId);
    expect(res.status).toBe(401);
  });

  it("PA refuse (4xx) → 422 propagé, aucune écriture BDD", async () => {
    const { seed, invoiceId } = await seedInvoiceAtStatus("accepted_business");
    driver.setCreateInvoiceEventFailure(
      new InvoiceRejectedXsdException({ message: "rejet sandbox" }),
    );

    const res = await markPaid(invoiceId, seed.bearer);
    expect(res.status).toBe(422);

    // Statut inchangé + pas d'event 212 (pose non transmise = pas d'écriture).
    const persisted = await sql<{ status_current: string }[]>`
      SELECT status_current FROM invoices WHERE id = ${invoiceId}
    `;
    expect(persisted[0]?.status_current).toBe("accepted_business");
    const events = await sql<{ code: string }[]>`
      SELECT code FROM cdar_events WHERE invoice_id = ${invoiceId} AND code = 'fr:212'
    `;
    expect(events).toHaveLength(0);
  });
});
