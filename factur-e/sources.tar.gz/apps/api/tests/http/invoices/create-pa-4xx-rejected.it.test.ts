import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { InvoiceRejectedXsdException, PaForbiddenException } from "@factur-e/pa-adapter";
import { MockPADriver } from "@factur-e/shared-fakes";

import { MemorySecretStore } from "../../../src/secrets/index.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";
import { seedFullCustomer } from "../../_fixtures/seed-customer.js";
import { fixtureFormBase } from "./_helpers.js";

/**
 * Cas #4 — Émission PA 4xx : XSD rejeté côté PA (422) ou opération
 * refusée (403). Pipeline atteint le call `paDriver.submitInvoice` puis
 * exception typée → ROLLBACK transaction (pas d'invoice orpheline) +
 * audit `pa_submission_failed_4xx` + HTTP code mappé (422/403). cf.
 * ADR-009 D5 fail-safe + create.ts:336-396 mapping exceptions.
 *
 * Note : cas #3 (« validation XSD côté factur-x-builder ») est
 * structurellement difficile à atteindre via une entrée Zod-validée
 * (mapping formToModel sanitize les cas évidents). La branche
 * `validateExtendedXsd` côté builder est couverte par
 * `packages/factur-x-builder/tests/` (XSD pure). Le path HTTP route
 * 422+fail-safe **équivalent** est couvert par
 * `emit-mapping-fail.it.test.ts` (mapping IBAN manquant) et par ce
 * fichier (PA-side XSD reject). [NOTE-COWORK 2026-05-20 sprint-04]
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("POST /api/invoices — PA 4xx exceptions mapping", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;
  let secrets: MemorySecretStore;
  let driver: MockPADriver;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
    secrets = new MemorySecretStore();
    driver = new MockPADriver();
    app = await buildTestApp({ connectionString: db.url, paDriver: driver, secretStore: secrets });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    driver.reset();
  });

  it("retourne 422 + ROLLBACK invoice + audit pa_submission_failed_4xx sur InvoiceRejectedXsdException", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    driver.setSubmitInvoiceFailure(
      new InvoiceRejectedXsdException({ detail: "BR-FR-CO-9 : SellerVatID prefix required" }),
    );

    const res = await fetch(`${app.url}/api/invoices`, {
      method: "POST",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify(fixtureFormBase()),
    });
    expect(res.status).toBe(422);
    const body = (await res.json()) as { message: string; detail?: string };
    expect(body.message).toMatch(/Plateforme Agréée a rejeté la facture/i);
    expect(body.detail).toBe("BR-FR-CO-9 : SellerVatID prefix required");

    // Pas d'invoice persistée (ROLLBACK).
    const persisted = await sql<{ count: string }[]>`
      SELECT COUNT(*)::text AS count FROM invoices WHERE customer_id = ${seed.customerId}
    `;
    expect(persisted[0]?.count).toBe("0");

    // Pas de cdar_event Déposée orphelin (ROLLBACK inclus le synthetic event).
    const cdarCount = await sql<{ count: string }[]>`
      SELECT COUNT(*)::text AS count FROM cdar_events
    `;
    expect(cdarCount[0]?.count).toBe("0");

    // Audit pa_submission_failed_4xx écrit (writeAuthAudit en dehors de
    // la tx — donc visible même après ROLLBACK).
    const audits = await sql<{ event_type: string; success: boolean }[]>`
      SELECT event_type, success FROM auth_audit WHERE user_id = ${seed.userId}
    `;
    expect(audits.some((a) => a.event_type === "pa_submission_failed_4xx" && !a.success)).toBe(
      true,
    );
  });

  it("retourne 403 + ROLLBACK + audit pa_submission_failed_4xx sur PaForbiddenException", async () => {
    const seed = await seedFullCustomer(sql, { secretStore: secrets });
    driver.setSubmitInvoiceFailure(
      new PaForbiddenException({ detail: "Compte SuperPDP non vérifié" }),
    );

    const res = await fetch(`${app.url}/api/invoices`, {
      method: "POST",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify(fixtureFormBase()),
    });
    expect(res.status).toBe(403);
    const body = (await res.json()) as { message: string; detail?: string };
    expect(body.message).toMatch(/Plateforme Agréée refuse cette opération/i);
    expect(body.detail).toBe("Compte SuperPDP non vérifié");

    const persisted = await sql<{ count: string }[]>`
      SELECT COUNT(*)::text AS count FROM invoices WHERE customer_id = ${seed.customerId}
    `;
    expect(persisted[0]?.count).toBe("0");

    const audits = await sql<{ event_type: string }[]>`
      SELECT event_type FROM auth_audit WHERE user_id = ${seed.userId}
    `;
    expect(audits.some((a) => a.event_type === "pa_submission_failed_4xx")).toBe(true);
  });
});
