import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { MockPADriver } from "@factur-e/shared-fakes";

import { MemorySecretStore } from "../../../src/secrets/index.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";
import { fixtureFormBase, seedInvoiceUser } from "./_helpers.js";

/**
 * Cas 6 — Check unicité numéro :
 *   - 1er call sur "F-2026-0042" → available=true + suggestion=F-NNNN
 *   - création de F-2026-0042 via POST /api/invoices
 *   - 2e call sur même → available=false + existingInvoiceId + suggestion=F-2026-0043
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("POST /api/invoices/check-number-unique", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;
  let secrets: MemorySecretStore;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
    secrets = new MemorySecretStore();
    app = await buildTestApp({
      connectionString: db.url,
      paDriver: new MockPADriver(),
      secretStore: secrets,
    });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  it("available=true puis available=false après création + suggestion incrémentée", async () => {
    const seed = await seedInvoiceUser(sql, { secretStore: secrets });

    // 1er call : aucune invoice → available=true + suggestion fallback
    const first = await fetch(`${app.url}/api/invoices/check-number-unique`, {
      method: "POST",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify({ number: "F-2026-0042" }),
    });
    expect(first.status).toBe(200);
    const firstBody = (await first.json()) as {
      available: boolean;
      suggestion: string;
      existingInvoiceId: string | null;
    };
    expect(firstBody.available).toBe(true);
    expect(firstBody.existingInvoiceId).toBeNull();
    // Suggestion fallback car aucune invoice émise.
    expect(firstBody.suggestion).toMatch(/^F-\d{4}-0001$/);

    // Crée l'invoice F-2026-0042
    const createRes = await fetch(`${app.url}/api/invoices`, {
      method: "POST",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify(fixtureFormBase({ number: "F-2026-0042" })),
    });
    expect(createRes.status).toBe(201);
    const created = (await createRes.json()) as { invoice: { id: string } };

    // 2e call : conflit → available=false + suggestion incrémentée
    const second = await fetch(`${app.url}/api/invoices/check-number-unique`, {
      method: "POST",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify({ number: "F-2026-0042" }),
    });
    expect(second.status).toBe(200);
    const secondBody = (await second.json()) as {
      available: boolean;
      suggestion: string;
      existingInvoiceId: string | null;
    };
    expect(secondBody.available).toBe(false);
    expect(secondBody.existingInvoiceId).toBe(created.invoice.id);
    expect(secondBody.suggestion).toBe("F-2026-0043");
  });
});
