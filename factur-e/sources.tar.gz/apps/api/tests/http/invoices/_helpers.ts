import type postgres from "postgres";

import { hashPassword } from "../../../src/auth/argon2.js";
import { signAccessToken } from "../../../src/auth/jwt.js";
import type { MemorySecretStore } from "../../../src/secrets/index.js";

export interface InvoiceSeed {
  customerId: string;
  userId: string;
  bearer: string;
  /** secret_ref de la `pa_connection` seedée — accessToken stocké dans
   *  le `MemorySecretStore` injecté. */
  paSecretRef: string;
}

/**
 * Seed un customer + user complets pour les tests d'émission. Inclut
 * `address` jsonb + `iban` + `bic` (requis pour le pipeline
 * `paymentMethodKind: "transfer"` qui mappe vers BG-17).
 */
export async function seedInvoiceUser(
  sql: postgres.Sql,
  args: {
    siren?: string;
    email?: string;
    legalName?: string;
    iban?: string | null;
    bic?: string | null;
    vatNumber?: string | null;
    /** MemorySecretStore injecté dans buildTestApp — on y enregistre le
     *  bundle `{accessToken, refreshToken, ...}` pour que la route
     *  POST /api/invoices puisse lire l'access token via
     *  `app.secrets.get(secret_ref)`. */
    secretStore?: MemorySecretStore;
  } = {},
): Promise<InvoiceSeed> {
  const siren = args.siren ?? "111111118";
  const email = args.email ?? "owner@test.fr";
  const legalName = args.legalName ?? "Ma Boîte SAS";
  const address = {
    line_one: "12 rue de la Paix",
    postcode: "75002",
    city: "Paris",
    country_code: "FR",
  };
  const customerRows = await sql<{ id: string }[]>`
    INSERT INTO customers (
      siren, legal_name, address, iban, bic, vat_number,
      directory_address, profile_unverified
    )
    VALUES (
      ${siren}, ${legalName}, ${sql.json(address)},
      ${args.iban === null ? null : (args.iban ?? "FR7630006000011234567890189")},
      ${args.bic === null ? null : (args.bic ?? "AGRIFRPP")},
      ${args.vatNumber === null ? null : (args.vatNumber ?? "FR12345678901")},
      ${`0225:${siren}_dgfip`}, FALSE
    )
    RETURNING id
  `;
  const customerId = customerRows[0]?.id ?? "";
  const hash = await hashPassword("Password123!");
  const userRows = await sql<{ id: string }[]>`
    INSERT INTO users (customer_id, email, password_hash, role)
    VALUES (${customerId}, ${email}, ${hash}, 'full')
    RETURNING id
  `;
  const userId = userRows[0]?.id ?? "";

  // Seed pa_connection + bundle token (consommés par la route
  // POST /api/invoices → app.paDriver.submitInvoice({accessToken})).
  const paSecretRef = `test-bundle-${siren}`;
  await sql`
    INSERT INTO pa_connections (
      customer_id, provider, pa_user_id, secret_ref,
      user_identity_verification_status, company_verification_status,
      connected_at
    ) VALUES (
      ${customerId}, 'superpdp', ${`pa-user-${siren}`}, ${paSecretRef},
      'verified', 'verified', NOW()
    )
  `;
  if (args.secretStore !== undefined) {
    await args.secretStore.put(paSecretRef, {
      accessToken: `test-access-${siren}`,
      refreshToken: `test-refresh-${siren}`,
      accessExpiresAt: new Date(Date.now() + 1800 * 1000).toISOString(),
    });
  }

  return {
    customerId,
    userId,
    bearer: await signAccessToken({ user_id: userId, customer_id: customerId }),
    paSecretRef,
  };
}

/** Fixture InvoiceFormBase prête à `POST /api/invoices`. Valeurs
 *  raisonnables, modifiables via overrides shallow. */
export interface FixtureFormBase {
  ui_mode: "base";
  document: { number: string; issueDate: string; notes: string | null };
  parties: {
    buyer: {
      siren: string;
      legalName: string;
      address: {
        lineOne: string | null;
        lineTwo: string | null;
        postcode: string;
        city: string;
        countryCode: string;
      };
      electronicAddress: string;
      electronicAddressScheme: string;
    };
  };
  lines: {
    label: string;
    description: string | null;
    quantity: string;
    unitCode: string;
    unitPriceHt: string;
    vatCategory: "S";
    vatRate: string | null;
    totalHt: string;
  }[];
  payment: {
    paymentTerms: { kind: "days"; days: number };
    paymentMethodKind: "transfer";
    mentionsLegales: string | null;
  };
}

export function fixtureFormBase(overrides: { number?: string } = {}): FixtureFormBase {
  return {
    ui_mode: "base",
    document: {
      number: overrides.number ?? "F-2026-0001",
      issueDate: "2026-05-16",
      notes: null,
    },
    parties: {
      buyer: {
        siren: "987654321",
        legalName: "Client Corp",
        address: {
          lineOne: "5 avenue des Champs",
          lineTwo: null,
          postcode: "69000",
          city: "Lyon",
          countryCode: "FR",
        },
        electronicAddress: "0225:987654321_dgfip",
        electronicAddressScheme: "0225",
      },
    },
    lines: [
      {
        label: "Prestation conseil",
        description: null,
        quantity: "1",
        unitCode: "HUR",
        unitPriceHt: "500.00",
        vatCategory: "S",
        vatRate: "20.00",
        totalHt: "500.00",
      },
    ],
    payment: {
      paymentTerms: { kind: "days", days: 30 },
      paymentMethodKind: "transfer",
      mentionsLegales: null,
    },
  };
}
