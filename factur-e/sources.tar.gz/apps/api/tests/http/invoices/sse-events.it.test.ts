import { randomUUID } from "node:crypto";

import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { MockPADriver } from "@factur-e/shared-fakes";

import { signRefreshToken } from "../../../src/auth/jwt.js";
import { MemorySecretStore } from "../../../src/secrets/index.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";
import { fixtureFormBase, seedInvoiceUser } from "./_helpers.js";

/** Cookie `_session` (refresh token) — l'auth SSE passe par le cookie HttpOnly
 *  depuis T-CL-AUTH-SSE-COOKIE-HTTPONLY sprint-06 (plus de bearer en query). */
async function sessionCookie(sql: postgres.Sql, userId: string): Promise<string> {
  const sessionId = randomUUID();
  await sql`
    INSERT INTO sessions (id, user_id, expires_at)
    VALUES (${sessionId}, ${userId}, NOW() + INTERVAL '30 days')
  `;
  const refresh = await signRefreshToken({ session_id: sessionId, user_id: userId });
  return `_session=${refresh}`;
}

/**
 * Cas 8 — SSE events : GET /api/invoices/:id/events ouvre le stream,
 * envoie le backlog initial (event Déposée synthetic), puis émet en
 * temps réel les nouveaux events insérés en BDD via le polling 3s
 * côté serveur.
 *
 * NB : Vitest n'a pas de support EventSource natif — on consomme le
 * stream via `fetch(...).body` ReadableStream et on parse SSE manuellement.
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

interface ParsedEvent {
  data: string;
}

async function readNEvents(
  reader: ReadableStreamDefaultReader<Uint8Array>,
  count: number,
  timeoutMs = 8000,
): Promise<ParsedEvent[]> {
  const decoder = new TextDecoder();
  const events: ParsedEvent[] = [];
  let buffer = "";
  const deadline = Date.now() + timeoutMs;
  while (events.length < count && Date.now() < deadline) {
    const remaining = deadline - Date.now();
    const result = await Promise.race([
      reader.read(),
      new Promise<never>((_, reject) => {
        setTimeout(() => {
          reject(new Error("timeout"));
        }, remaining);
      }),
    ]);
    if (result.done) break;
    buffer += decoder.decode(result.value, { stream: true });
    let idx: number;
    while ((idx = buffer.indexOf("\n\n")) !== -1) {
      const chunk = buffer.slice(0, idx);
      buffer = buffer.slice(idx + 2);
      const dataLine = chunk.split("\n").find((l) => l.startsWith("data: "));
      if (dataLine !== undefined) {
        events.push({ data: dataLine.slice("data: ".length) });
      }
    }
  }
  return events;
}

describe.skipIf(!enabled)("GET /api/invoices/:id/events — SSE", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;
  let secrets: MemorySecretStore;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
    secrets = new MemorySecretStore();
    app = await buildTestApp({
      connectionString: db.url,
      paDriver: new MockPADriver(),
      secretStore: secrets,
    });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  it("stream les events backlog + reçoit un nouvel event externe en < 5s", async () => {
    const seed = await seedInvoiceUser(sql, { secretStore: secrets });
    const createRes = await fetch(`${app.url}/api/invoices`, {
      method: "POST",
      headers: {
        authorization: `Bearer ${seed.bearer}`,
        "content-type": "application/json",
      },
      body: JSON.stringify(fixtureFormBase()),
    });
    expect(createRes.status).toBe(201);
    const created = (await createRes.json()) as { invoice: { id: string } };

    // Ouvre le stream SSE — auth via cookie HttpOnly `_session` (sprint-06).
    const cookie = await sessionCookie(sql, seed.userId);
    const sseRes = await fetch(`${app.url}/api/invoices/${created.invoice.id}/events`, {
      headers: { cookie },
    });
    expect(sseRes.status).toBe(200);
    expect(sseRes.headers.get("content-type")).toContain("text/event-stream");
    const reader = sseRes.body?.getReader();
    if (reader === undefined) throw new Error("SSE body reader undefined");

    try {
      // Backlog : 1 event initial avec raw status_code natif PA. Depuis
      // T-CL-PA-INVOICE-FIX, le `cdar_events.code` synthetic stocke le
      // raw `submission.rawStatusCode` SuperPDP (`api:uploaded` typique)
      // au lieu du libellé humain `Déposée` — cf. ADR-010 v2 + ADR-012 D2.
      const initial = await readNEvents(reader, 1, 3000);
      expect(initial.length).toBeGreaterThanOrEqual(1);
      const initialCodes = initial.map((e) => (JSON.parse(e.data) as { code: string }).code);
      expect(initialCodes).toContain("api:uploaded");

      // Insère un nouvel event en BDD (simule webhook PA T-CL-PA-EXT).
      // ON CONFLICT DO NOTHING — un occurred_at différent pour éviter
      // collision idempotence avec le synthetic initial (qui a NOW()).
      await new Promise((r) => setTimeout(r, 50));
      // T-CL-PA-EXT schema : payload jsonb NOT NULL DEFAULT '{}'.
      await sql`
          INSERT INTO cdar_events (invoice_id, code, occurred_at, payload, source)
          VALUES (${created.invoice.id}, '204 Prise en charge', NOW(), '{}'::jsonb, 'webhook')
        `;

      // Le polling 3s côté serveur doit nous l'envoyer en ≤ 8s. On
      // lit jusqu'à voir un "204" dans le flux (tolérant aux race
      // conditions où le backlog peut être re-livré).
      const tail: { code: string; source: string }[] = [];
      const deadline = Date.now() + 8000;
      while (Date.now() < deadline) {
        const batch = await readNEvents(reader, 1, deadline - Date.now());
        for (const e of batch) tail.push(JSON.parse(e.data) as { code: string; source: string });
        if (tail.some((t) => t.code === "204 Prise en charge" && t.source === "webhook")) break;
      }
      expect(tail.some((t) => t.code === "204 Prise en charge")).toBe(true);
    } finally {
      try {
        reader.releaseLock();
      } catch {
        // already released
      }
      try {
        await sseRes.body?.cancel();
      } catch {
        // stream already closed
      }
    }
  }, 15000);
});
