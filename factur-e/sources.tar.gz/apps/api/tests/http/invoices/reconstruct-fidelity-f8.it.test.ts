import { getFixture } from "@factur-e/factur-x-fixtures";
import { MockPADriver } from "@factur-e/shared-fakes";
import postgres from "postgres";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";

import { MemorySecretStore } from "../../../src/secrets/index.js";
import { invoicePdfArchiveKey } from "../../../src/services/invoice-pdf-archive.js";
import { MockObjectStorage } from "../../../src/storage/object-storage.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";
import { seedInvoiceUser } from "./_helpers.js";

/**
 * T-CL-RECONSTRUCT-FIDELE-F8 — reconstruction fidèle (F3 notes, G1 BG-3) +
 * copie immuable F8 servie pour l'envoyé / fallback purge / fallback legacy.
 *
 * Bout-en-bout via POST réel (pipeline d'émission complet : formToModel →
 * XSD → Schematron → PDF → MockPADriver → persist + copie immuable).
 */

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

describe.skipIf(!enabled)("reconstruction fidèle + copie immuable F8", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;
  let secrets: MemorySecretStore;
  let exportsStorage: MockObjectStorage;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
    secrets = new MemorySecretStore();
    exportsStorage = new MockObjectStorage();
    app = await buildTestApp({
      connectionString: db.url,
      paDriver: new MockPADriver(),
      secretStore: secrets,
      exportsStorage,
    });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    exportsStorage.reset();
  });

  const emit = (bearer: string, body: unknown): Promise<Response> =>
    fetch(`${app.url}/api/invoices`, {
      method: "POST",
      headers: { authorization: `Bearer ${bearer}`, "content-type": "application/json" },
      body: JSON.stringify(body),
    });

  const get = (bearer: string, path: string): Promise<Response> =>
    fetch(`${app.url}${path}`, { headers: { authorization: `Bearer ${bearer}` } });

  async function emitAndGetId(bearer: string, form: unknown): Promise<string> {
    const res = await emit(bearer, form);
    expect(res.status).toBe(201);
    return ((await res.json()) as { invoice: { id: string } }).invoice.id;
  }

  it("F3 — la note publique (BT-22) est réinjectée dans le XML régénéré", async () => {
    const seed = await seedInvoiceUser(sql, { secretStore: secrets });
    const form = getFixture("fx-380-base-iban").form; // notes: "Note publique corpus…"
    const id = await emitAndGetId(seed.bearer, form);

    const xmlRes = await get(seed.bearer, `/api/invoices/${id}/xml`);
    expect(xmlRes.status).toBe(200);
    const xml = await xmlRes.text();
    // Avant le fix : `_reconstruct.ts` codait `notes:null` → la note
    // disparaissait du document régénéré (F3). Désormais réinjectée.
    expect(xml).toContain("Note publique corpus : merci de votre confiance.");
  });

  it("F8 — facture envoyée : /pdf sert la copie immuable, bytes stables entre 2 GET", async () => {
    const seed = await seedInvoiceUser(sql, { secretStore: secrets });
    const id = await emitAndGetId(seed.bearer, getFixture("fx-380-base-iban").form);

    // pdf_archived_at posé à l'envoi.
    const rows = await sql<{ pdf_archived_at: Date | null }[]>`
      SELECT pdf_archived_at FROM invoices WHERE id = ${id}
    `;
    expect(rows[0]?.pdf_archived_at).not.toBeNull();

    // La copie existe sur le stockage objet (clé scopée tenant).
    const key = invoicePdfArchiveKey(seed.customerId, id);
    const archived = exportsStorage.getObject(key);
    expect(archived).toBeDefined();
    if (archived === undefined) throw new Error("copie immuable manquante");

    const a = await get(seed.bearer, `/api/invoices/${id}/pdf`);
    const b = await get(seed.bearer, `/api/invoices/${id}/pdf`);
    expect(a.status).toBe(200);
    expect(b.status).toBe(200);
    const ba = Buffer.from(await a.arrayBuffer());
    const bb = Buffer.from(await b.arrayBuffer());
    // Intégrité : bytes identiques entre 2 GET ET = la copie transmise
    // (≠ reconstruction dont l'ID trailer dépend de la generationDate).
    expect(ba.equals(bb)).toBe(true);
    expect(ba.equals(archived.body)).toBe(true);
  });

  it("F8 fallback purge — copie 180 j purgée → /pdf reconstruit, pas de 500", async () => {
    const seed = await seedInvoiceUser(sql, { secretStore: secrets });
    const id = await emitAndGetId(seed.bearer, getFixture("fx-380-base-iban").form);

    // Simule la purge lifecycle 180 j : l'objet disparaît mais
    // `pdf_archived_at` reste posé.
    await exportsStorage.deleteObject(invoicePdfArchiveKey(seed.customerId, id));

    const res = await get(seed.bearer, `/api/invoices/${id}/pdf`);
    expect(res.status).toBe(200);
    expect(res.headers.get("content-type")).toContain("application/pdf");
  });

  it("F8 fallback legacy — pdf_archived_at NULL (envoi pré-fix) → /pdf reconstruit", async () => {
    const seed = await seedInvoiceUser(sql, { secretStore: secrets });
    const id = await emitAndGetId(seed.bearer, getFixture("fx-380-base-iban").form);

    // Simule une facture legacy envoyée avant F8 : flag NULL + pas de copie.
    await sql`UPDATE invoices SET pdf_archived_at = NULL WHERE id = ${id}`;
    await exportsStorage.deleteObject(invoicePdfArchiveKey(seed.customerId, id));

    const res = await get(seed.bearer, `/api/invoices/${id}/pdf`);
    expect(res.status).toBe(200);
    expect(res.headers.get("content-type")).toContain("application/pdf");
  });

  it("G1 — avoir 381 régénéré : BG-3 (BT-25/26) présent dans le XML", async () => {
    const seed = await seedInvoiceUser(sql, { secretStore: secrets });
    // 1. Émet l'origine (FK self-référentielle preceding_invoice_id).
    const originId = await emitAndGetId(seed.bearer, getFixture("fx-380-base-iban").form);

    // 2. Émet l'avoir liant l'origine réelle (numéro/date d'origine = BG-3).
    const avoir = {
      ...getFixture("fx-381-avoir-bg3").form,
      precedingInvoiceId: originId,
      precedingInvoiceNumber: "FX-380-BASE-001",
      precedingIssueDate: "2026-06-01",
    };
    const avoirId = await emitAndGetId(seed.bearer, avoir);

    const xmlRes = await get(seed.bearer, `/api/invoices/${avoirId}/xml`);
    expect(xmlRes.status).toBe(200);
    const xml = await xmlRes.text();
    expect(xml).toContain("<ram:TypeCode>381</ram:TypeCode>");
    // BG-3 — réf facture d'origine (BT-25 numéro + BT-26 date) réinjectée.
    expect(xml).toContain("FX-380-BASE-001"); // BT-25 IssuerAssignedID
    expect(xml).toContain("20260601"); // BT-26 FormattedIssueDateTime
  });
});
