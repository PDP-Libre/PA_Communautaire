import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { hashPassword } from "../../../src/auth/argon2.js";
import { decrypt } from "../../../src/auth/encryption.js";
import { signAccessToken } from "../../../src/auth/jwt.js";
import { MockObjectStorage } from "../../../src/storage/object-storage.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

async function seedCustomerWithUser(
  sql: postgres.Sql,
  args: { email: string; role?: "deposit_simple" | "full"; juridique?: string | null },
): Promise<{ userId: string; customerId: string; bearer: string }> {
  const customerRows = await sql<{ id: string }[]>`
    INSERT INTO customers (siren, legal_name, juridique_code)
    VALUES (${"123456789"}, ${"Acme"}, ${args.juridique ?? null})
    RETURNING id
  `;
  const customerId = customerRows[0]?.id;
  if (customerId === undefined) throw new Error("customer");
  const hash = await hashPassword("Password123!");
  const userRows = await sql<{ id: string }[]>`
    INSERT INTO users (customer_id, email, password_hash, role)
    VALUES (${customerId}, ${args.email}, ${hash}, ${args.role ?? "full"})
    RETURNING id
  `;
  const userId = userRows[0]?.id;
  if (userId === undefined) throw new Error("user");
  const bearer = await signAccessToken({ user_id: userId, customer_id: customerId });
  return { userId, customerId, bearer };
}

describe.skipIf(!enabled)("PATCH /customers/me/profile", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    app = await buildTestApp({
      connectionString: db.url,
      objectStorage: new MockObjectStorage(),
    });
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  it("encrypts IBAN and persists trading_name + bic + mentions_legales", async () => {
    const { customerId, bearer } = await seedCustomerWithUser(sql, {
      email: "alice@acme.fr",
      role: "full",
    });

    const res = await fetch(`${app.url}/customers/me/profile`, {
      method: "PATCH",
      headers: { "content-type": "application/json", authorization: `Bearer ${bearer}` },
      body: JSON.stringify({
        trading_name: "Acme commerce",
        iban: "FR14 2004 1010 0505 0001 3M02 606",
        bic: "BNPAFRPP",
        mentions_legales: "Capital social libéré.",
      }),
    });
    expect(res.status).toBe(204);

    const rows = await sql<
      {
        trading_name: string | null;
        iban: string | null;
        bic: string | null;
        legal_mentions: string | null;
      }[]
    >`SELECT trading_name, iban, bic, legal_mentions FROM customers WHERE id = ${customerId}`;
    const row = rows[0];
    if (row === undefined) throw new Error("customer");
    expect(row.trading_name).toBe("Acme commerce");
    expect(row.bic).toBe("BNPAFRPP");
    expect(row.legal_mentions).toBe("Capital social libéré.");

    // Decrypt IBAN round-trip.
    expect(row.iban).toMatch(/^v1:/);
    const cipher = Buffer.from((row.iban ?? "").slice(3), "base64");
    const plain = decrypt(cipher).toString("utf8");
    expect(plain).toBe("FR1420041010050500013M02606");
  });

  it("rejects an invalid IBAN", async () => {
    const { bearer } = await seedCustomerWithUser(sql, {
      email: "alice@acme.fr",
      role: "full",
    });
    const res = await fetch(`${app.url}/customers/me/profile`, {
      method: "PATCH",
      headers: { "content-type": "application/json", authorization: `Bearer ${bearer}` },
      body: JSON.stringify({ iban: "FR1420041010050500013M02607" }),
    });
    expect(res.status).toBe(400);
  });

  it("requires capital_social for SAS first-time profile", async () => {
    const { bearer } = await seedCustomerWithUser(sql, {
      email: "alice@acme.fr",
      role: "full",
      juridique: "5710", // SAS
    });
    const res = await fetch(`${app.url}/customers/me/profile`, {
      method: "PATCH",
      headers: { "content-type": "application/json", authorization: `Bearer ${bearer}` },
      body: JSON.stringify({ trading_name: "Acme SAS" }),
    });
    expect(res.status).toBe(400);
  });

  it("accepts capital_social for SAS", async () => {
    const { customerId, bearer } = await seedCustomerWithUser(sql, {
      email: "alice@acme.fr",
      role: "full",
      juridique: "5710",
    });
    const res = await fetch(`${app.url}/customers/me/profile`, {
      method: "PATCH",
      headers: { "content-type": "application/json", authorization: `Bearer ${bearer}` },
      body: JSON.stringify({ trading_name: "Acme SAS", capital_social: 50000 }),
    });
    expect(res.status).toBe(204);
    const rows = await sql<{ capital_social: string | null }[]>`
      SELECT capital_social::text AS capital_social FROM customers WHERE id = ${customerId}
    `;
    expect(Number(rows[0]?.capital_social)).toBe(50000);
  });

  it("records capital_social in the audit metadata fields_updated", async () => {
    const { userId, bearer } = await seedCustomerWithUser(sql, {
      email: "alice@acme.fr",
      role: "full",
      juridique: "5710",
    });
    const res = await fetch(`${app.url}/customers/me/profile`, {
      method: "PATCH",
      headers: { "content-type": "application/json", authorization: `Bearer ${bearer}` },
      body: JSON.stringify({ capital_social: 10000 }),
    });
    expect(res.status).toBe(204);
    const audit = await sql<{ metadata: Record<string, unknown> }[]>`
      SELECT metadata FROM auth_audit
      WHERE user_id = ${userId} AND event_type = 'customer_profile_updated'
    `;
    expect(audit[0]?.metadata).toMatchObject({ fields_updated: ["capital_social"] });
  });

  it("allows a partial update without capital_social once it is already set (SARL)", async () => {
    const { customerId, bearer } = await seedCustomerWithUser(sql, {
      email: "alice@acme.fr",
      role: "full",
      juridique: "5499", // SARL générique
    });
    // Capital déjà renseigné en base (customer SARL existant) — l'édition
    // d'un autre champ ne doit pas redéclencher la garde conditionnelle.
    await sql`UPDATE customers SET capital_social = ${10000} WHERE id = ${customerId}`;
    const res = await fetch(`${app.url}/customers/me/profile`, {
      method: "PATCH",
      headers: { "content-type": "application/json", authorization: `Bearer ${bearer}` },
      body: JSON.stringify({ trading_name: "Acme SARL" }),
    });
    expect(res.status).toBe(204);
    const rows = await sql<{ capital_social: string | null; trading_name: string | null }[]>`
      SELECT capital_social::text AS capital_social, trading_name
      FROM customers WHERE id = ${customerId}
    `;
    expect(Number(rows[0]?.capital_social)).toBe(10000);
    expect(rows[0]?.trading_name).toBe("Acme SARL");
  });

  it("does not require capital_social for an entrepreneur individuel (EI)", async () => {
    const { bearer } = await seedCustomerWithUser(sql, {
      email: "pierre@morel.fr",
      role: "full",
      juridique: "1000", // EI — hors CAPITAL_REQUIRED_CODES
    });
    const res = await fetch(`${app.url}/customers/me/profile`, {
      method: "PATCH",
      headers: { "content-type": "application/json", authorization: `Bearer ${bearer}` },
      body: JSON.stringify({ trading_name: "Morel BTP" }),
    });
    expect(res.status).toBe(204);
  });

  it("rejects an attempt to mutate legal_name (Sirene read-only — T-LIBELLES)", async () => {
    const { customerId, bearer } = await seedCustomerWithUser(sql, {
      email: "alice@acme.fr",
      role: "full",
    });
    // `legal_name` n'est pas dans CustomerProfilePatchBodySchema (.strict())
    // → safeParse échoue → 400 NEUTRAL, aucune écriture (Option A Z6).
    const res = await fetch(`${app.url}/customers/me/profile`, {
      method: "PATCH",
      headers: { "content-type": "application/json", authorization: `Bearer ${bearer}` },
      body: JSON.stringify({ legal_name: "AttaqueFraude" }),
    });
    expect(res.status).toBe(400);
    const json = (await res.json()) as { message?: string };
    expect(json.message).toBe("Vérifiez vos informations.");
    const rows = await sql<{ legal_name: string }[]>`
      SELECT legal_name FROM customers WHERE id = ${customerId}
    `;
    expect(rows[0]?.legal_name).toBe("Acme"); // valeur seed inchangée
  });

  // ── Régression finding N (recette sprint-06 Sc.9.1) ──────────────────────
  // La recette avait conclu que `capital_social` n'était jamais audité — en
  // interrogeant le mauvais event_type (`customer_settings_updated`). En
  // réalité `capital_social` transite par PATCH /customers/me/profile → event
  // `customer_profile_updated`, où il EST présent dans `fields_updated`. Le
  // cas de base est déjà couvert ci-dessus ("records capital_social in the
  // audit metadata fields_updated") ; ces tests verrouillent en plus le
  // multi-champs, l'absence de valeur (ADR-008) et la taxonomie d'event.
  // Aucun changement runtime — finding N = misdiagnostic d'observation
  // (cf. trace sprint-07 [done] T-CL-W3-E-AUDIT-FIX).

  it("lists every patched field in the audit fields_updated (multi-field)", async () => {
    const { userId, bearer } = await seedCustomerWithUser(sql, {
      email: "alice@acme.fr",
      role: "full",
      juridique: "5710",
    });
    const res = await fetch(`${app.url}/customers/me/profile`, {
      method: "PATCH",
      headers: { "content-type": "application/json", authorization: `Bearer ${bearer}` },
      body: JSON.stringify({
        trading_name: "Sophie SAS",
        capital_social: 5710,
        primary_color: "#1A2B3C",
      }),
    });
    expect(res.status).toBe(204);
    const audit = await sql<{ metadata: { fields_updated: string[] } }[]>`
      SELECT metadata FROM auth_audit
      WHERE user_id = ${userId} AND event_type = 'customer_profile_updated'
    `;
    expect(audit[0]?.metadata.fields_updated).toEqual(
      expect.arrayContaining(["trading_name", "capital_social", "primary_color"]),
    );
    expect(audit[0]?.metadata.fields_updated).toHaveLength(3);
  });

  it("audits field names only, never the capital_social value (ADR-008)", async () => {
    const { userId, bearer } = await seedCustomerWithUser(sql, {
      email: "alice@acme.fr",
      role: "full",
      juridique: "5710",
    });
    const res = await fetch(`${app.url}/customers/me/profile`, {
      method: "PATCH",
      headers: { "content-type": "application/json", authorization: `Bearer ${bearer}` },
      body: JSON.stringify({ capital_social: 5710 }),
    });
    expect(res.status).toBe(204);
    const audit = await sql<{ metadata: Record<string, unknown> }[]>`
      SELECT metadata FROM auth_audit
      WHERE user_id = ${userId} AND event_type = 'customer_profile_updated'
    `;
    const serialized = JSON.stringify(audit[0]?.metadata);
    expect(serialized).toContain("capital_social"); // le nom du champ est audité
    expect(serialized).not.toContain("5710"); // jamais la valeur saisie
  });

  it("never records capital_social under customer_settings_updated (taxonomy)", async () => {
    const { customerId, bearer } = await seedCustomerWithUser(sql, {
      email: "alice@acme.fr",
      role: "full",
      juridique: "5710",
    });
    const res = await fetch(`${app.url}/customers/me/profile`, {
      method: "PATCH",
      headers: { "content-type": "application/json", authorization: `Bearer ${bearer}` },
      body: JSON.stringify({ capital_social: 5710 }),
    });
    expect(res.status).toBe(204);
    const settings = await sql<{ n: number }[]>`
      SELECT COUNT(*)::int AS n FROM auth_audit
      WHERE customer_id = ${customerId} AND event_type = 'customer_settings_updated'
    `;
    expect(settings[0]?.n).toBe(0);
  });

  it("403 for non-full role", async () => {
    const { bearer } = await seedCustomerWithUser(sql, {
      email: "alice@acme.fr",
      role: "deposit_simple",
    });
    const res = await fetch(`${app.url}/customers/me/profile`, {
      method: "PATCH",
      headers: { "content-type": "application/json", authorization: `Bearer ${bearer}` },
      body: JSON.stringify({ trading_name: "Hack" }),
    });
    expect(res.status).toBe(403);
  });
});
