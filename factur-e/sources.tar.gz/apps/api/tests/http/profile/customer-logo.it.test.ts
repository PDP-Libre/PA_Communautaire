import { Buffer } from "node:buffer";

import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { hashPassword } from "../../../src/auth/argon2.js";
import { signAccessToken } from "../../../src/auth/jwt.js";
import { MockObjectStorage } from "../../../src/storage/object-storage.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

// Minimal valid PNG (1×1 transparent pixel).
const PNG_BYTES = Buffer.from(
  "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkAAIAAAoAAv/lxKUAAAAASUVORK5CYII=",
  "base64",
);

async function seedFullUser(sql: postgres.Sql): Promise<{ customerId: string; bearer: string }> {
  const customerRows = await sql<{ id: string }[]>`
    INSERT INTO customers (siren, legal_name) VALUES (${"123456789"}, ${"Acme"})
    RETURNING id
  `;
  const customerId = customerRows[0]?.id;
  if (customerId === undefined) throw new Error("customer");
  const hash = await hashPassword("Password123!");
  const userRows = await sql<{ id: string }[]>`
    INSERT INTO users (customer_id, email, password_hash, role)
    VALUES (${customerId}, ${"alice@acme.fr"}, ${hash}, ${"full"})
    RETURNING id
  `;
  const userId = userRows[0]?.id;
  if (userId === undefined) throw new Error("user");
  const bearer = await signAccessToken({ user_id: userId, customer_id: customerId });
  return { customerId, bearer };
}

function multipart(
  file: Buffer,
  filename: string,
  contentType: string,
): { body: Buffer; headers: Record<string, string> } {
  const boundary = "----factureBoundary123";
  const head = Buffer.from(
    `--${boundary}\r\nContent-Disposition: form-data; name="logo"; filename="${filename}"\r\nContent-Type: ${contentType}\r\n\r\n`,
  );
  const tail = Buffer.from(`\r\n--${boundary}--\r\n`);
  return {
    body: Buffer.concat([head, file, tail]),
    headers: {
      "content-type": `multipart/form-data; boundary=${boundary}`,
    },
  };
}

describe.skipIf(!enabled)("POST/DELETE /customers/me/logo", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;
  let storage: MockObjectStorage;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    storage = new MockObjectStorage();
    app = await buildTestApp({ connectionString: db.url, objectStorage: storage });
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
    storage.reset();
  });

  it("uploads PNG, persists logo_s3_key, returns logo_url", async () => {
    const { customerId, bearer } = await seedFullUser(sql);
    const m = multipart(PNG_BYTES, "logo.png", "image/png");

    const res = await fetch(`${app.url}/customers/me/logo`, {
      method: "POST",
      headers: { ...m.headers, authorization: `Bearer ${bearer}` },
      body: m.body,
    });
    expect(res.status).toBe(200);
    const body = (await res.json()) as Record<string, unknown>;
    expect(typeof body.logo_url).toBe("string");

    const expectedKey = `customers/${customerId}/logo.png`;
    expect(storage.getObject(expectedKey)?.contentType).toBe("image/png");

    const rows = await sql<{ logo_s3_key: string | null }[]>`
      SELECT logo_s3_key FROM customers WHERE id = ${customerId}
    `;
    expect(rows[0]?.logo_s3_key).toBe(expectedKey);
  });

  it("rejects unsupported types", async () => {
    const { bearer } = await seedFullUser(sql);
    const m = multipart(Buffer.from("not a real jpeg"), "logo.jpg", "image/jpeg");
    const res = await fetch(`${app.url}/customers/me/logo`, {
      method: "POST",
      headers: { ...m.headers, authorization: `Bearer ${bearer}` },
      body: m.body,
    });
    expect(res.status).toBe(415);
  });

  it("DELETE clears logo_s3_key and removes object", async () => {
    const { customerId, bearer } = await seedFullUser(sql);
    const m = multipart(PNG_BYTES, "logo.png", "image/png");
    await fetch(`${app.url}/customers/me/logo`, {
      method: "POST",
      headers: { ...m.headers, authorization: `Bearer ${bearer}` },
      body: m.body,
    });

    const del = await fetch(`${app.url}/customers/me/logo`, {
      method: "DELETE",
      headers: { authorization: `Bearer ${bearer}` },
    });
    expect(del.status).toBe(204);

    const rows = await sql<{ logo_s3_key: string | null }[]>`
      SELECT logo_s3_key FROM customers WHERE id = ${customerId}
    `;
    expect(rows[0]?.logo_s3_key).toBeNull();
    expect(storage.getObject(`customers/${customerId}/logo.png`)).toBeUndefined();
  });
});
