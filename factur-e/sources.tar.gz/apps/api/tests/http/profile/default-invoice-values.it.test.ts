import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { hashPassword } from "../../../src/auth/argon2.js";
import { signAccessToken } from "../../../src/auth/jwt.js";
import { MockObjectStorage } from "../../../src/storage/object-storage.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

async function seedFullUser(sql: postgres.Sql): Promise<{ customerId: string; bearer: string }> {
  const customerRows = await sql<{ id: string }[]>`
    INSERT INTO customers (siren, legal_name) VALUES (${"123456789"}, ${"Acme"})
    RETURNING id
  `;
  const customerId = customerRows[0]?.id;
  if (customerId === undefined) throw new Error("customer");
  const hash = await hashPassword("Password123!");
  const userRows = await sql<{ id: string }[]>`
    INSERT INTO users (customer_id, email, password_hash, role)
    VALUES (${customerId}, ${"alice@acme.fr"}, ${hash}, ${"full"})
    RETURNING id
  `;
  const userId = userRows[0]?.id;
  if (userId === undefined) throw new Error("user");
  const bearer = await signAccessToken({ user_id: userId, customer_id: customerId });
  return { customerId, bearer };
}

describe.skipIf(!enabled)("PUT /customers/me/default-invoice-values", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    app = await buildTestApp({
      connectionString: db.url,
      objectStorage: new MockObjectStorage(),
    });
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  it("persists default invoice values JSONB on customers", async () => {
    const { customerId, bearer } = await seedFullUser(sql);

    const res = await fetch(`${app.url}/customers/me/default-invoice-values`, {
      method: "PUT",
      headers: { "content-type": "application/json", authorization: `Bearer ${bearer}` },
      body: JSON.stringify({
        currency: "EUR",
        payment_terms: "net_30_eom",
        vat_rate_default: 20,
        footer_mention: "Pas d'escompte pour paiement anticipé.",
        vat_on_encashment: true,
      }),
    });
    expect(res.status).toBe(204);

    const rows = await sql<
      { default_invoice_values: Record<string, unknown> | null }[]
    >`SELECT default_invoice_values FROM customers WHERE id = ${customerId}`;
    const v = rows[0]?.default_invoice_values;
    expect(v?.currency).toBe("EUR");
    expect(v?.payment_terms).toBe("net_30_eom");
    expect(v?.vat_rate_default).toBe(20);
    expect(v?.vat_on_encashment).toBe(true);
  });

  it("rejects invalid VAT rate", async () => {
    const { bearer } = await seedFullUser(sql);
    const res = await fetch(`${app.url}/customers/me/default-invoice-values`, {
      method: "PUT",
      headers: { "content-type": "application/json", authorization: `Bearer ${bearer}` },
      body: JSON.stringify({
        currency: "EUR",
        payment_terms: "net_30",
        vat_rate_default: 8.5, // not in allowed set
      }),
    });
    expect(res.status).toBe(400);
  });
});
