import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import postgres from "postgres";

import { hashPassword } from "../../../src/auth/argon2.js";
import { signAccessToken } from "../../../src/auth/jwt.js";
import { MockObjectStorage } from "../../../src/storage/object-storage.js";
import { buildTestApp, type TestApp } from "../../helpers/build-app.js";
import { setupTestDb, type TestDb } from "../../helpers/test-db.js";

const enabled = Boolean(process.env.TEST_POSTGRES_URL);

async function seedUser(
  sql: postgres.Sql,
  email: string,
  role: "deposit_simple" | "full" = "deposit_simple",
): Promise<{ userId: string; customerId: string; bearer: string }> {
  const customerRows = await sql<{ id: string }[]>`
    INSERT INTO customers (siren, legal_name)
    VALUES (${"123456789"}, ${"Acme"})
    RETURNING id
  `;
  const customerId = customerRows[0]?.id;
  if (customerId === undefined) throw new Error("customer");
  const hash = await hashPassword("Password123!");
  const userRows = await sql<{ id: string }[]>`
    INSERT INTO users (customer_id, email, password_hash, role)
    VALUES (${customerId}, ${email}, ${hash}, ${role})
    RETURNING id
  `;
  const userId = userRows[0]?.id;
  if (userId === undefined) throw new Error("user");
  const bearer = await signAccessToken({ user_id: userId, customer_id: customerId });
  return { userId, customerId, bearer };
}

describe.skipIf(!enabled)("PATCH /users/me/profile", () => {
  let db: TestDb;
  let app: TestApp;
  let sql: postgres.Sql;

  beforeAll(async () => {
    const setup = await setupTestDb();
    if (setup === null) throw new Error("TEST_POSTGRES_URL required");
    db = setup;
    app = await buildTestApp({
      connectionString: db.url,
      objectStorage: new MockObjectStorage(),
    });
    sql = postgres(db.url, { max: 1, onnotice: () => undefined });
  });

  afterAll(async () => {
    await app.stop();
    await sql.end();
    await db.drop();
  });

  beforeEach(async () => {
    await db.resetAuthTables();
  });

  it("updates the current user's profile fields", async () => {
    const { userId, bearer } = await seedUser(sql, "alice@acme.fr");

    const res = await fetch(`${app.url}/users/me/profile`, {
      method: "PATCH",
      headers: { "content-type": "application/json", authorization: `Bearer ${bearer}` },
      body: JSON.stringify({
        first_name: "Alice",
        last_name: "Dupont",
        function_title: "Gérante",
      }),
    });
    expect(res.status).toBe(204);

    const rows = await sql<
      { first_name: string | null; last_name: string | null; function_title: string | null }[]
    >`SELECT first_name, last_name, function_title FROM users WHERE id = ${userId}`;
    expect(rows[0]?.first_name).toBe("Alice");
    expect(rows[0]?.last_name).toBe("Dupont");
    expect(rows[0]?.function_title).toBe("Gérante");
  });

  it("rejects without bearer", async () => {
    const res = await fetch(`${app.url}/users/me/profile`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ first_name: "Alice", last_name: "Dupont" }),
    });
    expect(res.status).toBe(401);
  });

  it("rejects missing required fields with 400", async () => {
    const { bearer } = await seedUser(sql, "alice@acme.fr");
    const res = await fetch(`${app.url}/users/me/profile`, {
      method: "PATCH",
      headers: { "content-type": "application/json", authorization: `Bearer ${bearer}` },
      body: JSON.stringify({ first_name: "Alice" }),
    });
    expect(res.status).toBe(400);
  });
});
