export { default } from "@factur-e/eslint-config/node";
