import node from "@factur-e/eslint-config/node";

/**
 * Config apps/api = config Node partagée + garde-fou import du corpus de
 * fixtures (T-CL-FIXTURES-WIRING §2).
 *
 * `@factur-e/factur-x-fixtures` est un paquet test-support : il ne doit JAMAIS
 * être importé par du code métier de prod. Consommateurs autorisés (override
 * ci-dessous) : suites de test + endpoints seed `__dev` (gatés runtime) + le
 * module dev-support partagé qui adapte `FixtureSeller` → `CustomerRow`.
 */
export default [
  ...node,
  {
    rules: {
      "no-restricted-imports": [
        "error",
        {
          paths: [
            {
              name: "@factur-e/factur-x-fixtures",
              message:
                "Paquet test-support : import réservé aux tests, à routes/dev/** et à src/dev-support/** (jamais dans le code métier de prod).",
            },
          ],
        },
      ],
    },
  },
  {
    files: ["**/*.test.ts", "tests/**", "src/routes/dev/**", "src/dev-support/**"],
    rules: {
      "no-restricted-imports": "off",
    },
  },
];
