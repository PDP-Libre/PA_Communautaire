import { describe, expect, it } from "vitest";

import {
  allCdarSequences,
  allReceptionFixtures,
  getCdarSequence,
  getFixture,
  getReceptionFixture,
  receptionFixturesBy,
  SENDER_TIERS,
  TEST_IDENTITIES,
} from "../src/index.js";

/**
 * Test socle du corpus RÉCEPTION (contrat 02-contrat-consommation.md §3) —
 * garde-fous de COHÉRENCE DE DONNÉES. Ne dépend QUE de ses propres exports
 * (paquet test-support strict : `@factur-e/shared-schemas` only) — comme le
 * socle émission (`corpus.test.ts`), il NE charge PAS `parseInvoiceMetadata`
 * (libxmljs2, `factur-x-builder`) ni `mapSuperPDPStatusCode` (`pa-adapter`).
 *
 * Les oracles qui exigent le PIPELINE/PARSER RÉEL vivent côté apps/api
 * (`reception-convergence.test.ts`), où ces deps existent déjà — même
 * arbitrage que la convergence Schematron S08 : le paquet reste pur, les
 * oracles « traversent le chemin du bug » dans l'app.
 */

describe("corpus réception factur-x-fixtures — test socle (cohérence données)", () => {
  const fixtures = allReceptionFixtures();
  const sequences = allCdarSequences();

  it("contient 7 fixtures reçues + 3 séquences CDAR", () => {
    expect(fixtures).toHaveLength(7);
    expect(sequences).toHaveLength(3);
  });

  it("ids fixtures uniques + getReceptionFixture résout, throw sur inconnu", () => {
    const ids = fixtures.map((f) => f.meta.id);
    expect(new Set(ids).size).toBe(ids.length);
    for (const id of ids) expect(getReceptionFixture(id).meta.id).toBe(id);
    expect(() => getReceptionFixture("inconnue")).toThrow(/Fixture réception inconnue/);
  });

  it("ids séquences uniques + getCdarSequence résout, throw sur inconnu", () => {
    const ids = sequences.map((s) => s.meta.id);
    expect(new Set(ids).size).toBe(ids.length);
    for (const id of ids) expect(getCdarSequence(id).meta.id).toBe(id);
    expect(() => getCdarSequence("inconnue")).toThrow(/Séquence CDAR inconnue/);
  });

  it("receptionFixturesBy filtre par typeCode / sourceKind / finding", () => {
    expect(receptionFixturesBy({ typeCode: "384" }).map((f) => f.meta.id)).toEqual([
      "rx-384-rectif-bg3",
      "rx-384-origine-introuvable",
    ]);
    expect(receptionFixturesBy({ sourceKind: "emission" })).toHaveLength(3);
    expect(receptionFixturesBy({ sourceKind: "xml" })).toHaveLength(4);
    expect(receptionFixturesBy({ finding: "R8" }).map((f) => f.meta.id)).toContain(
      "rx-380-cii-partiel",
    );
  });

  describe.each(fixtures.map((f) => [f.meta.id, f] as const))("%s", (_id, rx) => {
    it("cohérence interne expect.row ⟺ expect.parsed (seller + montant)", () => {
      expect(rx.expect.row.sellerSiren).toBe(rx.expect.parsed.sellerSiren);
      // R8 assumé : row.totalTtcCents peut être null ALORS QUE parsed le porte
      // (rx-380-cii-partiel) — la tension est voulue, on ne l'aplatit pas.
      if (rx.expect.row.totalTtcCents !== null) {
        expect(rx.expect.row.totalTtcCents).toBe(rx.expect.parsed.totalTtcCents);
      }
    });

    it("meta.typeCode cohérent avec expect.parsed.documentType (sauf GAP-5)", () => {
      // rx-380-sans-typecode : XML sans BT-3, documentType vient du fallback
      // parser "380" — meta.typeCode = valeur fonctionnelle assumée (égales ici).
      expect(rx.expect.parsed.documentType).toBe(rx.meta.typeCode);
    });

    if (rx.source.kind === "emission") {
      it("source.emissionFixtureId résolu dans le corpus ÉMISSION", () => {
        const src = rx.source;
        if (src.kind !== "emission") throw new Error("narrowing");
        expect(getFixture(src.emissionFixtureId).meta.id).toBe(src.emissionFixtureId);
      });
    }

    if (rx.source.kind === "xml") {
      it("XML statique non vide + SIREN émetteur présent (garde anti-drift)", () => {
        const src = rx.source;
        if (src.kind !== "xml") throw new Error("narrowing");
        expect(src.xml.length).toBeGreaterThan(0);
        // Le parser RÉEL est exercé côté apps/api ; ici on garde juste contre
        // une dérive entre le SIREN embarqué et l'oracle / le module identités.
        expect(src.xml).toContain(rx.expect.parsed.sellerSiren);
      });
    }
  });

  it("chaînage originFixtureId : résolu + cohérent (number = BT-25, même seller)", () => {
    const chained = fixtures.filter((f) => f.originFixtureId !== undefined);
    expect(chained.map((f) => f.meta.id)).toEqual(["rx-381-avoir-bg3", "rx-384-rectif-bg3"]);
    for (const rx of chained) {
      const originId = rx.originFixtureId;
      if (originId === undefined) continue;
      const origin = getReceptionFixture(originId);
      expect(origin.incoming.enInvoice?.number).toBe(rx.expect.parsed.precedingInvoiceNumber);
      expect(origin.incoming.enInvoice?.sellerSiren).toBe(rx.expect.parsed.sellerSiren);
    }
  });

  it("ordre du corpus : chaque origine seedée AVANT ses référents (seed itératif)", () => {
    const order = fixtures.map((f) => f.meta.id);
    for (const rx of fixtures) {
      if (rx.originFixtureId === undefined) continue;
      expect(order.indexOf(rx.originFixtureId)).toBeLessThan(order.indexOf(rx.meta.id));
    }
  });

  it("séquences : appliesToEmissionFixtureId résolu dans le corpus ÉMISSION", () => {
    for (const seq of sequences) {
      expect(getFixture(seq.appliesToEmissionFixtureId).meta.id).toBe(
        seq.appliesToEmissionFixtureId,
      );
      expect(seq.events.length).toBeGreaterThan(0);
    }
  });

  it("SENDER_TIERS reste hors annuaire (knownToPa=false) — distinction structurante", () => {
    expect(SENDER_TIERS.knownToPa).toBe(false);
    expect(TEST_IDENTITIES.superpdp.sellerBq.knownToPa).toBe(true);
    expect(TEST_IDENTITIES.superpdp.buyerTricatel.knownToPa).toBe(true);
    // Les XML tiers ne doivent JAMAIS porter le SIREN Burger Queen (pollution
    // de la clé naturelle de matching origine).
    for (const rx of receptionFixturesBy({ sourceKind: "xml" })) {
      if (rx.source.kind !== "xml") continue;
      expect(rx.source.xml).not.toContain(TEST_IDENTITIES.superpdp.sellerBq.siren);
    }
  });
});
