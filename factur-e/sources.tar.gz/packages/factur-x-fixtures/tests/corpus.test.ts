import { InvoiceFormSchema } from "@factur-e/shared-schemas";
import { describe, expect, it } from "vitest";

import { allFixtures, fixturesBy, getFixture } from "../src/index.js";

/**
 * Test socle du corpus (contrat §3.1) — garde-fou « zéro champ inventé » +
 * cohérence interne. Ne dépend QUE de `@factur-e/shared-schemas` (le paquet
 * ne peut pas voir `formToModel`). La revalidation des totaux contre le
 * pipeline réel (formToModel → XML) vit dans la convergence apps/api
 * (`convergence-corpus.test.ts`), cf. contrat §5 « revalidée par exécution ».
 */

const round2 = (n: number): number => Math.round((n + Number.EPSILON) * 100) / 100;

describe("corpus factur-x-fixtures — test socle", () => {
  const fixtures = allFixtures();

  it("contient 9 fixtures (6 conformes + 3 NC)", () => {
    expect(fixtures).toHaveLength(9);
    expect(fixturesBy({ conformant: true })).toHaveLength(6);
    expect(fixturesBy({ conformant: false })).toHaveLength(3);
  });

  it("ids uniques + getFixture résout chaque id, throw sur inconnu", () => {
    const ids = fixtures.map((f) => f.meta.id);
    expect(new Set(ids).size).toBe(ids.length);
    for (const id of ids) expect(getFixture(id).meta.id).toBe(id);
    expect(() => getFixture("inconnue")).toThrow(/Fixture inconnue/);
  });

  describe.each(fixtures.map((f) => [f.meta.id, f] as const))("%s", (_id, fx) => {
    it("form parse InvoiceFormSchema (zéro champ inventé)", () => {
      const res = InvoiceFormSchema.safeParse(fx.form);
      if (!res.success) {
        throw new Error(
          `${fx.meta.id} ne parse pas : ${JSON.stringify(res.error.issues, null, 2)}`,
        );
      }
      expect(res.success).toBe(true);
    });

    it("cohérence ligne : quantité × prix unitaire ÷ basisQuantity = totalHt", () => {
      for (const [i, line] of fx.form.lines.entries()) {
        const qty = Number(line.quantity);
        const unit = Number(line.unitPriceHt);
        const basis =
          "basisQuantity" in line && line.basisQuantity !== null && line.basisQuantity !== undefined
            ? Number(line.basisQuantity)
            : 1;
        const expected = round2((qty * unit) / basis);
        expect(round2(Number(line.totalHt)), `ligne ${String(i)} (${line.label})`).toBe(expected);
      }
    });

    it("invariant conformant ⟺ présence du bloc schematron", () => {
      if (fx.meta.conformant) {
        expect(fx.expect.schematron).toBeUndefined();
      } else {
        expect(fx.expect.schematron?.expectViolations.length ?? 0).toBeGreaterThan(0);
      }
    });
  });
});
