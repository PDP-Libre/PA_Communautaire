/** Fixture réception 7 (Z7, incluse au GO) — 380 reçue d'un tiers SANS
 *  `ram:TypeCode` : documente le fallback silencieux du parser
 *  `documentType ?? "380"` (GAP-5, parse-invoice-metadata.ts:380).
 *
 *  ⚠ Trouvaille de validation (GAP-T2-2, cf. 01-matrice-couverture.md §5) :
 *  ce XML VALIDE contre le XSD CII D22B (xmllint 2026-06-11) — TypeCode est
 *  optionnel dans le schéma UN/CEFACT complet. Le document est donc
 *  XSD-valide mais EN16931-NC (BR-04 exige BT-3) ; comme le parser
 *  réception ne valide pas (by design, PA trustée), le fallback est
 *  atteignable avec un flux « valide ». Comportement assumé V1 :
 *  traiter comme Facture 380 — à documenter au récap RECTIF-AFNOR (Z4).
 *
 *  Z4 double oracle : `parsed.documentType="380"` (fallback parser) ;
 *  `row.typeCodeIfPersisted=null` (extraction STRICTE de BT-3 au poll →
 *  indéterminable ; si la colonne reprend le fallback parser, elle dirait
 *  "380" — la divergence est le point à trancher). */

import type { ReceptionFixture } from "./types.js";

const XML = `<?xml version="1.0" encoding="UTF-8"?>
<rsm:CrossIndustryInvoice xmlns:qdt="urn:un:unece:uncefact:data:standard:QualifiedDataType:100" xmlns:ram="urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:100" xmlns:rsm="urn:un:unece:uncefact:data:standard:CrossIndustryInvoice:100" xmlns:udt="urn:un:unece:uncefact:data:standard:UnqualifiedDataType:100">
  <rsm:ExchangedDocumentContext>
    <ram:GuidelineSpecifiedDocumentContextParameter>
      <ram:ID>urn:cen.eu:en16931:2017</ram:ID>
    </ram:GuidelineSpecifiedDocumentContextParameter>
  </rsm:ExchangedDocumentContext>
  <rsm:ExchangedDocument>
    <ram:ID>FT-2026-0061</ram:ID>
    <ram:IssueDateTime><udt:DateTimeString format="102">20260607</udt:DateTimeString></ram:IssueDateTime>
  </rsm:ExchangedDocument>
  <rsm:SupplyChainTradeTransaction>
    <ram:IncludedSupplyChainTradeLineItem>
      <ram:AssociatedDocumentLineDocument><ram:LineID>1</ram:LineID></ram:AssociatedDocumentLineDocument>
      <ram:SpecifiedTradeProduct><ram:Name>Abonnement service de nettoyage - juin</ram:Name></ram:SpecifiedTradeProduct>
      <ram:SpecifiedLineTradeAgreement>
        <ram:NetPriceProductTradePrice><ram:ChargeAmount>200.00</ram:ChargeAmount></ram:NetPriceProductTradePrice>
      </ram:SpecifiedLineTradeAgreement>
      <ram:SpecifiedLineTradeDelivery><ram:BilledQuantity unitCode="C62">1</ram:BilledQuantity></ram:SpecifiedLineTradeDelivery>
      <ram:SpecifiedLineTradeSettlement>
        <ram:ApplicableTradeTax>
          <ram:TypeCode>VAT</ram:TypeCode>
          <ram:CategoryCode>S</ram:CategoryCode>
          <ram:RateApplicablePercent>20.00</ram:RateApplicablePercent>
        </ram:ApplicableTradeTax>
        <ram:SpecifiedTradeSettlementLineMonetarySummation><ram:LineTotalAmount>200.00</ram:LineTotalAmount></ram:SpecifiedTradeSettlementLineMonetarySummation>
      </ram:SpecifiedLineTradeSettlement>
    </ram:IncludedSupplyChainTradeLineItem>
    <ram:ApplicableHeaderTradeAgreement>
      <ram:SellerTradeParty>
        <ram:Name>Fournitures Tiers SARL</ram:Name>
        <ram:SpecifiedLegalOrganization><ram:ID schemeID="0002">123456782</ram:ID></ram:SpecifiedLegalOrganization>
        <ram:PostalTradeAddress>
          <ram:PostcodeCode>69003</ram:PostcodeCode>
          <ram:LineOne>5 rue des Lilas</ram:LineOne>
          <ram:CityName>Lyon</ram:CityName>
          <ram:CountryID>FR</ram:CountryID>
        </ram:PostalTradeAddress>
        <ram:SpecifiedTaxRegistration><ram:ID schemeID="VA">FR11123456782</ram:ID></ram:SpecifiedTaxRegistration>
      </ram:SellerTradeParty>
      <ram:BuyerTradeParty>
        <ram:Name>Tricatel</ram:Name>
        <ram:SpecifiedLegalOrganization><ram:ID schemeID="0002">000000001</ram:ID></ram:SpecifiedLegalOrganization>
        <ram:PostalTradeAddress>
          <ram:PostcodeCode>75011</ram:PostcodeCode>
          <ram:LineOne>1 rue de l'Industrie</ram:LineOne>
          <ram:CityName>Paris</ram:CityName>
          <ram:CountryID>FR</ram:CountryID>
        </ram:PostalTradeAddress>
      </ram:BuyerTradeParty>
    </ram:ApplicableHeaderTradeAgreement>
    <ram:ApplicableHeaderTradeDelivery/>
    <ram:ApplicableHeaderTradeSettlement>
      <ram:InvoiceCurrencyCode>EUR</ram:InvoiceCurrencyCode>
      <ram:ApplicableTradeTax>
        <ram:CalculatedAmount>40.00</ram:CalculatedAmount>
        <ram:TypeCode>VAT</ram:TypeCode>
        <ram:BasisAmount>200.00</ram:BasisAmount>
        <ram:CategoryCode>S</ram:CategoryCode>
        <ram:RateApplicablePercent>20.00</ram:RateApplicablePercent>
      </ram:ApplicableTradeTax>
      <ram:SpecifiedTradePaymentTerms>
        <ram:DueDateDateTime><udt:DateTimeString format="102">20260707</udt:DateTimeString></ram:DueDateDateTime>
      </ram:SpecifiedTradePaymentTerms>
      <ram:SpecifiedTradeSettlementHeaderMonetarySummation>
        <ram:LineTotalAmount>200.00</ram:LineTotalAmount>
        <ram:TaxBasisTotalAmount>200.00</ram:TaxBasisTotalAmount>
        <ram:TaxTotalAmount currencyID="EUR">40.00</ram:TaxTotalAmount>
        <ram:GrandTotalAmount>240.00</ram:GrandTotalAmount>
        <ram:DuePayableAmount>240.00</ram:DuePayableAmount>
      </ram:SpecifiedTradeSettlementHeaderMonetarySummation>
    </ram:ApplicableHeaderTradeSettlement>
  </rsm:SupplyChainTradeTransaction>
</rsm:CrossIndustryInvoice>`;

export const rx380SansTypecode: ReceptionFixture = {
  meta: {
    id: "rx-380-sans-typecode",
    title: "Facture reçue SANS ram:TypeCode — fallback parser documenté (GAP-5)",
    typeCode: "380", // valeur FONCTIONNELLE assumée — le XML n'a pas de BT-3
    btBg: ["BT-1", "BT-2", "BT-30", "BT-112"],
    findings: ["GAP-5"],
  },
  source: { kind: "xml", xml: XML, download: "xml" },
  incoming: {
    receivedAt: "2026-06-07T10:00:00.000Z",
    enInvoice: {
      number: "FT-2026-0061",
      issueDate: "2026-06-07",
      dueDate: "2026-07-07",
      currency: "EUR",
      sellerSiren: "123456782",
      sellerName: "Fournitures Tiers SARL",
      totalTtcCents: 24000,
    },
  },
  expect: {
    parsed: {
      documentType: "380", // fallback `?? "380"` — comportement assumé V1
      precedingInvoiceNumber: null,
      totalTtcCents: 24000,
      sellerSiren: "123456782",
    },
    row: {
      sellerSiren: "123456782",
      numberExtracted: "FT-2026-0061",
      totalTtcCents: 24000,
      supplierMatched: false,
      typeCodeIfPersisted: null, // extraction stricte BT-3 : indéterminable (Z4)
    },
    ui: {
      docLabel: "Facture",
      humanCheck: [
        "Affichée comme Facture standard (fallback assumé) — aucune erreur, aucun libellé « type inconnu »",
      ],
    },
  },
};
