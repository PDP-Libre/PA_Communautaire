/** Fixture réception 1 — 380 Factur-X complète BQ→Tricatel. Baseline
 *  liste/fiche + R2 chemin passthrough PDF + R8 témoin (totaux OK) +
 *  ORIGINE des chaînages (rx-381-avoir-bg3 et rx-384-rectif-bg3 la visent
 *  par BT-25 = FX-380-BASE-001).
 *
 *  Z2 : document dérivé au wiring de `fx-380-base-iban` via le pipeline
 *  réel (`buildIncomingFileFromEmissionFixture`) — zéro XML recopié ici.
 *  Cohérence cross-comptes vérifiée sur le corpus émission : number
 *  FX-380-BASE-001, GrandTotal 960.00 (expect.xml fx-380-base-iban),
 *  seller SIREN 000000002, issueDate 2026-06-01, virement 30 j → échéance
 *  2026-07-01. */

import type { ReceptionFixture } from "./types.js";

export const rx380BaseFacturx: ReceptionFixture = {
  meta: {
    id: "rx-380-base-facturx",
    title: "Facture 380 reçue — Factur-X complète BQ→Tricatel (baseline + origine des chaînages)",
    typeCode: "380",
    btBg: ["BT-1", "BT-2", "BT-3", "BT-9", "BT-30", "BT-112"],
    findings: ["R2-passthrough", "R8-temoin", "R4"],
  },
  source: { kind: "emission", emissionFixtureId: "fx-380-base-iban", download: "facturx-pdf" },
  incoming: {
    receivedAt: "2026-06-01T10:00:00.000Z",
    enInvoice: {
      number: "FX-380-BASE-001",
      issueDate: "2026-06-01",
      dueDate: "2026-07-01",
      currency: "EUR",
      sellerSiren: "000000002",
      sellerName: "Burger Queen",
      totalTtcCents: 96000,
    },
  },
  expect: {
    parsed: {
      documentType: "380",
      precedingInvoiceNumber: null,
      totalTtcCents: 96000,
      sellerSiren: "000000002",
    },
    row: {
      sellerSiren: "000000002",
      numberExtracted: "FX-380-BASE-001",
      totalTtcCents: 96000,
      supplierMatched: true,
      typeCodeIfPersisted: "380",
    },
    ui: {
      docLabel: "Facture",
      humanCheck: [
        "R2 (chemin passthrough) : aperçu PDF non vide sur la fiche — le PDF Factur-X téléchargé, pas le placeholder statique ReceivedInvoicePdfPreview",
        "R8 témoin : récap liste/fiche = 960,00 € TTC, TVA 160,00 € — pas de TTC affiché en HT (recv-adapters toListFixture)",
        "R4 : depuis CETTE fiche (origine), liens vers rx-381-avoir-bg3 ET rx-384-rectif-bg3 qui la visent (lookup inverse à créer — FICHE-FIXS)",
      ],
    },
  },
};
