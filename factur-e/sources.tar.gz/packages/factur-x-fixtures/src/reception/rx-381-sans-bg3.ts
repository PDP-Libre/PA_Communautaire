/** Fixture réception 6 — Avoir 381 reçu d'un tiers (Z5) SANS
 *  `InvoiceReferencedDocument` : branche dédiée `precedingInvoiceNumber=null`
 *  de `resolveCreditNoteOrigin` (return précoce `originFound=false` sans
 *  lookup — get.ts:81-88). L'UI ne doit pas fabriquer « Avoir lié à la
 *  facture undefined ».
 *
 *  BG-3 est obligatoire EN 16931 pour un 381 (BR-55) — document toléré par
 *  le parser réception (lecture tolérante by design, PA trustée) : c'est
 *  précisément le cas limite à couvrir.
 *
 *  XML validé xmllint contre CII D22B le 2026-06-11. */

import type { ReceptionFixture } from "./types.js";

const XML = `<?xml version="1.0" encoding="UTF-8"?>
<rsm:CrossIndustryInvoice xmlns:qdt="urn:un:unece:uncefact:data:standard:QualifiedDataType:100" xmlns:ram="urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:100" xmlns:rsm="urn:un:unece:uncefact:data:standard:CrossIndustryInvoice:100" xmlns:udt="urn:un:unece:uncefact:data:standard:UnqualifiedDataType:100">
  <rsm:ExchangedDocumentContext>
    <ram:GuidelineSpecifiedDocumentContextParameter>
      <ram:ID>urn:cen.eu:en16931:2017</ram:ID>
    </ram:GuidelineSpecifiedDocumentContextParameter>
  </rsm:ExchangedDocumentContext>
  <rsm:ExchangedDocument>
    <ram:ID>AV-2026-0007</ram:ID>
    <ram:TypeCode>381</ram:TypeCode>
    <ram:IssueDateTime><udt:DateTimeString format="102">20260606</udt:DateTimeString></ram:IssueDateTime>
  </rsm:ExchangedDocument>
  <rsm:SupplyChainTradeTransaction>
    <ram:IncludedSupplyChainTradeLineItem>
      <ram:AssociatedDocumentLineDocument><ram:LineID>1</ram:LineID></ram:AssociatedDocumentLineDocument>
      <ram:SpecifiedTradeProduct><ram:Name>Avoir - retour ramettes papier A4 endommagées</ram:Name></ram:SpecifiedTradeProduct>
      <ram:SpecifiedLineTradeAgreement>
        <ram:NetPriceProductTradePrice><ram:ChargeAmount>30.00</ram:ChargeAmount></ram:NetPriceProductTradePrice>
      </ram:SpecifiedLineTradeAgreement>
      <ram:SpecifiedLineTradeDelivery><ram:BilledQuantity unitCode="C62">1</ram:BilledQuantity></ram:SpecifiedLineTradeDelivery>
      <ram:SpecifiedLineTradeSettlement>
        <ram:ApplicableTradeTax>
          <ram:TypeCode>VAT</ram:TypeCode>
          <ram:CategoryCode>S</ram:CategoryCode>
          <ram:RateApplicablePercent>20.00</ram:RateApplicablePercent>
        </ram:ApplicableTradeTax>
        <ram:SpecifiedTradeSettlementLineMonetarySummation><ram:LineTotalAmount>30.00</ram:LineTotalAmount></ram:SpecifiedTradeSettlementLineMonetarySummation>
      </ram:SpecifiedLineTradeSettlement>
    </ram:IncludedSupplyChainTradeLineItem>
    <ram:ApplicableHeaderTradeAgreement>
      <ram:SellerTradeParty>
        <ram:Name>Fournitures Tiers SARL</ram:Name>
        <ram:SpecifiedLegalOrganization><ram:ID schemeID="0002">123456782</ram:ID></ram:SpecifiedLegalOrganization>
        <ram:PostalTradeAddress>
          <ram:PostcodeCode>69003</ram:PostcodeCode>
          <ram:LineOne>5 rue des Lilas</ram:LineOne>
          <ram:CityName>Lyon</ram:CityName>
          <ram:CountryID>FR</ram:CountryID>
        </ram:PostalTradeAddress>
        <ram:SpecifiedTaxRegistration><ram:ID schemeID="VA">FR11123456782</ram:ID></ram:SpecifiedTaxRegistration>
      </ram:SellerTradeParty>
      <ram:BuyerTradeParty>
        <ram:Name>Tricatel</ram:Name>
        <ram:SpecifiedLegalOrganization><ram:ID schemeID="0002">000000001</ram:ID></ram:SpecifiedLegalOrganization>
        <ram:PostalTradeAddress>
          <ram:PostcodeCode>75011</ram:PostcodeCode>
          <ram:LineOne>1 rue de l'Industrie</ram:LineOne>
          <ram:CityName>Paris</ram:CityName>
          <ram:CountryID>FR</ram:CountryID>
        </ram:PostalTradeAddress>
      </ram:BuyerTradeParty>
    </ram:ApplicableHeaderTradeAgreement>
    <ram:ApplicableHeaderTradeDelivery/>
    <ram:ApplicableHeaderTradeSettlement>
      <ram:InvoiceCurrencyCode>EUR</ram:InvoiceCurrencyCode>
      <ram:ApplicableTradeTax>
        <ram:CalculatedAmount>6.00</ram:CalculatedAmount>
        <ram:TypeCode>VAT</ram:TypeCode>
        <ram:BasisAmount>30.00</ram:BasisAmount>
        <ram:CategoryCode>S</ram:CategoryCode>
        <ram:RateApplicablePercent>20.00</ram:RateApplicablePercent>
      </ram:ApplicableTradeTax>
      <ram:SpecifiedTradeSettlementHeaderMonetarySummation>
        <ram:LineTotalAmount>30.00</ram:LineTotalAmount>
        <ram:TaxBasisTotalAmount>30.00</ram:TaxBasisTotalAmount>
        <ram:TaxTotalAmount currencyID="EUR">6.00</ram:TaxTotalAmount>
        <ram:GrandTotalAmount>36.00</ram:GrandTotalAmount>
        <ram:DuePayableAmount>36.00</ram:DuePayableAmount>
      </ram:SpecifiedTradeSettlementHeaderMonetarySummation>
    </ram:ApplicableHeaderTradeSettlement>
  </rsm:SupplyChainTradeTransaction>
</rsm:CrossIndustryInvoice>`;

export const rx381SansBg3: ReceptionFixture = {
  meta: {
    id: "rx-381-sans-bg3",
    title: "Avoir 381 reçu — SANS InvoiceReferencedDocument (precedingInvoiceNumber=null)",
    typeCode: "381",
    btBg: ["BT-3(381)", "BT-30", "BT-112"],
    findings: ["R6-null"],
  },
  source: { kind: "xml", xml: XML, download: "xml" },
  incoming: {
    receivedAt: "2026-06-06T09:00:00.000Z",
    enInvoice: {
      number: "AV-2026-0007",
      issueDate: "2026-06-06",
      currency: "EUR",
      sellerSiren: "123456782",
      sellerName: "Fournitures Tiers SARL",
      totalTtcCents: 3600,
    },
  },
  expect: {
    parsed: {
      documentType: "381",
      precedingInvoiceNumber: null,
      totalTtcCents: 3600,
      sellerSiren: "123456782",
    },
    row: {
      sellerSiren: "123456782",
      numberExtracted: "AV-2026-0007",
      totalTtcCents: 3600,
      supplierMatched: false,
      typeCodeIfPersisted: "381",
    },
    // Branche précoce : isCreditNote=true, precedingInvoiceNumber=null,
    // originFound=false, AUCUN lookup SQL exécuté.
    origin: { isLinkedDoc: true, matchExpected: false },
    ui: {
      docLabel: "Avoir",
      humanCheck: [
        "Bandeau dégradé SANS numéro d'origine — pas de « Avoir lié à la facture undefined » ni de lien mort",
        "CTA « Marquer remboursée » reste disponible (AVOIR-10 ne dépend pas du chaînage)",
      ],
    },
  },
};
