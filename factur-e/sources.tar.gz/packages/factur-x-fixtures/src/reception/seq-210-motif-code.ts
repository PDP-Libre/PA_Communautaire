/** Séquence CDAR 1 — Refus 210 avec motif CODE SEUL (Annexe E "03") sur la
 *  facture émise fx-380-base-iban. Cœur du finding B : la timeline émission
 *  affiche aujourd'hui le motif BRUT (`note = ev.reason` →
 *  emit/detail/cdar-events-to-timeline.ts:150) : l'acheteur voit « 03 » au
 *  lieu de « Montant incorrect ».
 *
 *  Anti-faux-vert ZG-5 : l'oracle `timelineNotes` asserte le libellé
 *  NORMALISÉ — il DOIT échouer sur le code actuel (note brute "03") et
 *  passer après T-CL-RECV-CDAR-MOTIF. Table commune : annexe-e-motifs.ts
 *  (Z6). */

import type { IncomingCdarSequence } from "./types.js";

export const seq210MotifCode: IncomingCdarSequence = {
  meta: {
    id: "seq-210-motif-code",
    title: "Refus 210 entrant — motif code seul (03), libellé normalisé attendu",
    findings: ["finding-B"],
  },
  appliesToEmissionFixtureId: "fx-380-base-iban",
  events: [
    { statusCode: "fr:204", offsetMinutes: 0 },
    { statusCode: "fr:210", reason: { code: "03" }, offsetMinutes: 60 },
  ],
  expect: {
    statusCurrent: "refused_business", // mapSuperPDPStatusCode("fr:210")
    timelineNotes: [{ code: "fr:210", normalizedLabel: "Montant incorrect" }],
  },
};
