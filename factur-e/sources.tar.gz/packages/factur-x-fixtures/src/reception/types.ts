/**
 * T-CW-FIXTURES-RECEPTION sprint-09 — types du corpus de fixtures de flux
 * ENTRANTS (Temps 2, hors-git). Recopie repo par T-CL-FIXTURES-RECV-WIRING
 * dans `packages/factur-x-fixtures/src/reception/` (même paquet que
 * l'émission — PAS un 2ᵉ corpus, cf. 00-analyse-plan.md §3.2).
 *
 * Contrat §3.1 du 00-analyse-plan.md (validé GO Bruno+PMO). Une fixture
 * entrante lie les TROIS représentations d'un flux reçu (constat §1.3) :
 *  (a) le document (XML statique, ou dérivé d'une fixture émission via le
 *      pipeline réel — Z2 : zéro recopie de XML pour `kind:"emission"`),
 *  (b) le snapshot listing PA (`IncomingInvoiceEnData` partiel possible —
 *      c'est un cas fonctionnel : R8),
 *  (c) les oracles par couche (parser / row worker / matching origine / UI).
 *
 * Écarts d'exécution vs contrat Temps 1 (complétions actées au Temps 2,
 * signalées au reporting — pas des re-discussions) :
 *  - E1 : `download` ajouté à la variante `kind:"emission"` — la matrice §4
 *    l'annotait déjà (« download PDF Factur-X ») ; le seed doit savoir quelle
 *    représentation servir via `setDownloadInvoiceFileResult`.
 *  - E2 : `expect.row.supplierMatched` ajouté — la matrice exige l'oracle
 *    « Fournisseur non identifié » (supplier_matched=false, rx-380-cii-partiel).
 *  - E3 : `expect.row.typeCodeIfPersisted` ajouté — Z4 : oracle fourni dans
 *    LES DEUX branches de la décision colonne `type_code` (récap RECTIF-AFNOR).
 *    Si colonne ajoutée → cette valeur ; sans colonne → la fiche dérive de
 *    `expect.parsed.documentType` (on-demand, dégradable à null si PA down).
 */

// ─────────────────────────────────────────────────────────────────────
// Facture reçue
// ─────────────────────────────────────────────────────────────────────

export interface ReceptionFixtureMeta {
  /** Identifiant stable — clé du seed recette nommé (Levier 2). */
  id: string;
  title: string;
  /** BT-3 FONCTIONNEL du document. Pour `rx-380-sans-typecode`, c'est la
   *  valeur assumée (le XML, lui, n'a PAS de `ram:TypeCode` — GAP-5). */
  typeCode: "380" | "381" | "384";
  /** BT/BG exercés — alimente la matrice de couverture. */
  btBg: string[];
  /** Findings ciblés (R2/R3/R4/R5/R6/R8, GAP-5…). */
  findings: string[];
}

/**
 * SOURCE UNIQUE du document entrant — deux formes exclusives.
 *
 * `download` pilote ce que `downloadInvoiceFile` doit servir au seed/mock :
 *  - `"facturx-pdf"` → bytes PDF, contentType `application/pdf` (R2 chemin
 *    passthrough fiche /pdf) ;
 *  - `"xml"` → bytes XML, contentType `application/xml` (R2 chemin
 *    `renderPdfFromXml`, vue lisible reconstituée).
 */
export type ReceptionSource =
  /** Flux BQ→Tricatel : le document EST une fixture émission. XML + PDF
   *  Factur-X DÉRIVÉS au wiring par le pipeline réel (formToModel →
   *  generateCII → assemblage) côté apps/api — zéro recopie (Z2). */
  | { kind: "emission"; emissionFixtureId: string; download: "xml" | "facturx-pdf" }
  /** Entrant tiers / cas limite non productible par notre pipeline (CII
   *  partiel, TypeCode absent…) : XML statique assumé, expéditeur dédié
   *  `SENDER_TIERS` (Z5 — jamais Burger Queen). */
  | { kind: "xml"; xml: string; download: "xml" | "facturx-pdf" };

/** Snapshot listing PA (ce que voit le worker `poll-received-invoices`).
 *  Shape alignée `IncomingInvoiceEnData` (`packages/pa-adapter/src/driver.ts`)
 *  — `enInvoice` PARTIEL possible (cas fonctionnel R8 : expand sans totals). */
export interface ReceptionIncomingSnapshot {
  /** ISO timestamp — fixe l'ordre liste (received_at DESC) déterministe. */
  receivedAt: string;
  /** Code statut natif du DERNIER event au snapshot (ex. "fr:209" —
   *  `maybeIngestCancellation`). Absent = défaut fr:204. */
  rawStatusCode?: string;
  enInvoice?: {
    number?: string;
    issueDate?: string;
    dueDate?: string;
    currency?: string;
    sellerSiren?: string;
    sellerName?: string;
    totalTtcCents?: number;
  };
}

export interface ReceptionExpect {
  /** Oracle `parseInvoiceMetadata` (remplace les XML inline des tests
   *  parser — site de duplication §1.3-4). Pour `kind:"emission"`, s'applique
   *  au XML dérivé par le pipeline réel. */
  parsed: {
    documentType: string;
    /** BT-25 — `null` explicite = le document n'a PAS de BG-3. */
    precedingInvoiceNumber?: string | null;
    /** BT-112 en centimes (`totals.totalTtc`). */
    totalTtcCents?: number;
    /** BT-30 (`parties.seller.siren`). */
    sellerSiren?: string;
  };
  /** Oracle worker → row `received_invoices`. */
  row: {
    sellerSiren: string;
    numberExtracted: string | null;
    /** `null` = cas R8 assumé (expand partiel — le récap NE DOIT PAS
     *  inventer un montant). */
    totalTtcCents: number | null;
    /** E2 — `false` = bandeau « Fournisseur non identifié » attendu. Le
     *  wiring configure `searchSiren` du mock en conséquence (cf.
     *  02-contrat-consommation.md §5). */
    supplierMatched: boolean;
    /** E3 / Z4 — branche « colonne `type_code` ajoutée » : valeur attendue
     *  en base. `null` = BT-3 indéterminable au poll (rx-380-sans-typecode
     *  en extraction stricte ; le fallback parser dirait "380" — GAP-5,
     *  décision au récap RECTIF-AFNOR). Branche « sans colonne » :
     *  `expect.parsed.documentType`. */
    typeCodeIfPersisted: "380" | "381" | "384" | null;
  };
  /** Oracle `resolveCreditNoteOrigin` ÉTENDU 381+384 (R6). ⚠ anti-faux-vert
   *  ZG-5 : sur le code actuel (gate `documentType !== "381"`,
   *  `routes/received-invoices/get.ts:79`), l'oracle des 384 DOIT échouer
   *  (payload null) — c'est le détecteur du finding. */
  origin?: { isLinkedDoc: true; matchExpected: boolean };
  /** Oracle UI / recette humaine (libellé type R5, bandeaux, récap R8). */
  ui?: {
    docLabel: "Facture" | "Avoir" | "Facture rectificative";
    humanCheck?: string[];
  };
}

export interface ReceptionFixture {
  meta: ReceptionFixtureMeta;
  source: ReceptionSource;
  incoming: ReceptionIncomingSnapshot;
  /** Chaînage origine : id d'une AUTRE ReceptionFixture du corpus dont le
   *  `incoming.enInvoice.number` = BT-25 de celle-ci. Clé naturelle
   *  (customer_id, seller_siren BT-29, invoice_number_extracted = BT-25),
   *  déjà câblée au code (`findReceivedInvoiceByPrecedingNumber`) — pas
   *  d'UUID fixe nécessaire côté réception. Le seed crée l'origine D'ABORD
   *  (idempotent). */
  originFixtureId?: string;
  expect: ReceptionExpect;
}

// ─────────────────────────────────────────────────────────────────────
// Séquence CDAR entrante (sur factures ÉMISES — finding B + R3 propagation)
// ─────────────────────────────────────────────────────────────────────

/**
 * Événements CDAR ENTRANTS reçus par le VENDEUR (BQ) sur une facture émise.
 * Ce sont des events JSON propriétaires SuperPDP (`data.reason`) — PAS des
 * documents XML CDAR : SuperPDP n'expose pas le XML XSD D22B aujourd'hui
 * (00-analyse-plan.md, divergence prompt↔code ; le XSD reste la référence
 * des codes/motifs — G1 dira si le XML devient accessible).
 *
 * Convention de transport du motif (V1, à CONFIRMER au smoke G1 — cf.
 * GAP-T2-1, 01-matrice-couverture.md §5) : `reason.code` → `CdarEvent.reason`
 * (string, ce que le driver extrait de `data.reason`) ; `reason.text` →
 * `payload.data` (la pose actuelle n'envoie QUE le code à la PA :
 * `details:[{reason: code}]`, le texte libre du motif 11 ne traverse pas).
 */
export interface IncomingCdarSequence {
  meta: { id: string; title: string; findings: string[] };
  /** Facture émise porteuse — fixture émission existante (anti-duplication).
   *  ⚠ une séquence = UN scénario exclusif sur l'instance seedée (deux
   *  séquences sur le même `appliesTo` ne se cumulent pas). */
  appliesToEmissionFixtureId: string;
  /** Events raw SuperPDP, ordonnés. Shape alignée `CdarEvent` /
   *  `__dev/cdar/inject` étendu (wiring §5.2.4). */
  events: {
    /** Code natif PA (ex. "fr:210"). */
    statusCode: string;
    /** Motif Annexe E — cf. `annexe-e-motifs.ts` (table commune Z6). */
    reason?: { code: string; text?: string };
    /** Décalage vs T0 du seed — déterminisme timeline. */
    offsetMinutes: number;
  }[];
  expect: {
    /** `FacturEStatusCode` attendu après la séquence (table
     *  `mapSuperPDPStatusCode`, 21 valeurs post-refonte S05). */
    statusCurrent: string;
    /** Oracle finding B : libellé motif NORMALISÉ attendu en timeline
     *  émission (aujourd'hui `note = ev.reason` brut,
     *  `emit/detail/cdar-events-to-timeline.ts:150` → l'oracle DOIT
     *  échouer avant CDAR-MOTIF — anti-faux-vert ZG-5). */
    timelineNotes?: { code: string; normalizedLabel: string; freeText?: string }[];
  };
}
