/** Fixture réception 2 — 380 CII PUR expéditeur tiers (Z5), download XML,
 *  snapshot `en_invoice` PARTIEL (sans totalTtcCents ni dueDate).
 *
 *  Cible : R8 (le récap NE DOIT PAS inventer un montant quand la row a
 *  total_ttc_cents NULL — alors que la fiche, elle, peut retrouver les
 *  vrais totaux via `parseInvoiceMetadata` on-demand : c'est LA tension du
 *  finding) + R2 chemin `renderPdfFromXml` (XML pur sans PDF embarqué) +
 *  « Fournisseur non identifié » (supplier_matched=false, SIREN tiers hors
 *  annuaire).
 *
 *  XML validé xmllint contre CII D22B
 *  (`docs/external/factur-x-1.07.3/CII-D22B/CrossIndustryInvoice_100pD22B.xsd`)
 *  le 2026-06-11 — cf. 01-matrice-couverture.md §4. */

import type { ReceptionFixture } from "./types.js";

const XML = `<?xml version="1.0" encoding="UTF-8"?>
<rsm:CrossIndustryInvoice xmlns:qdt="urn:un:unece:uncefact:data:standard:QualifiedDataType:100" xmlns:ram="urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:100" xmlns:rsm="urn:un:unece:uncefact:data:standard:CrossIndustryInvoice:100" xmlns:udt="urn:un:unece:uncefact:data:standard:UnqualifiedDataType:100">
  <rsm:ExchangedDocumentContext>
    <ram:GuidelineSpecifiedDocumentContextParameter>
      <ram:ID>urn:cen.eu:en16931:2017</ram:ID>
    </ram:GuidelineSpecifiedDocumentContextParameter>
  </rsm:ExchangedDocumentContext>
  <rsm:ExchangedDocument>
    <ram:ID>FT-2026-0042</ram:ID>
    <ram:TypeCode>380</ram:TypeCode>
    <ram:IssueDateTime><udt:DateTimeString format="102">20260602</udt:DateTimeString></ram:IssueDateTime>
  </rsm:ExchangedDocument>
  <rsm:SupplyChainTradeTransaction>
    <ram:IncludedSupplyChainTradeLineItem>
      <ram:AssociatedDocumentLineDocument><ram:LineID>1</ram:LineID></ram:AssociatedDocumentLineDocument>
      <ram:SpecifiedTradeProduct><ram:Name>Ramettes papier A4</ram:Name></ram:SpecifiedTradeProduct>
      <ram:SpecifiedLineTradeAgreement>
        <ram:NetPriceProductTradePrice><ram:ChargeAmount>4.50</ram:ChargeAmount></ram:NetPriceProductTradePrice>
      </ram:SpecifiedLineTradeAgreement>
      <ram:SpecifiedLineTradeDelivery><ram:BilledQuantity unitCode="C62">10</ram:BilledQuantity></ram:SpecifiedLineTradeDelivery>
      <ram:SpecifiedLineTradeSettlement>
        <ram:ApplicableTradeTax>
          <ram:TypeCode>VAT</ram:TypeCode>
          <ram:CategoryCode>S</ram:CategoryCode>
          <ram:RateApplicablePercent>20.00</ram:RateApplicablePercent>
        </ram:ApplicableTradeTax>
        <ram:SpecifiedTradeSettlementLineMonetarySummation><ram:LineTotalAmount>45.00</ram:LineTotalAmount></ram:SpecifiedTradeSettlementLineMonetarySummation>
      </ram:SpecifiedLineTradeSettlement>
    </ram:IncludedSupplyChainTradeLineItem>
    <ram:ApplicableHeaderTradeAgreement>
      <ram:SellerTradeParty>
        <ram:Name>Fournitures Tiers SARL</ram:Name>
        <ram:SpecifiedLegalOrganization><ram:ID schemeID="0002">123456782</ram:ID></ram:SpecifiedLegalOrganization>
        <ram:PostalTradeAddress>
          <ram:PostcodeCode>69003</ram:PostcodeCode>
          <ram:LineOne>5 rue des Lilas</ram:LineOne>
          <ram:CityName>Lyon</ram:CityName>
          <ram:CountryID>FR</ram:CountryID>
        </ram:PostalTradeAddress>
        <ram:SpecifiedTaxRegistration><ram:ID schemeID="VA">FR11123456782</ram:ID></ram:SpecifiedTaxRegistration>
      </ram:SellerTradeParty>
      <ram:BuyerTradeParty>
        <ram:Name>Tricatel</ram:Name>
        <ram:SpecifiedLegalOrganization><ram:ID schemeID="0002">000000001</ram:ID></ram:SpecifiedLegalOrganization>
        <ram:PostalTradeAddress>
          <ram:PostcodeCode>75011</ram:PostcodeCode>
          <ram:LineOne>1 rue de l'Industrie</ram:LineOne>
          <ram:CityName>Paris</ram:CityName>
          <ram:CountryID>FR</ram:CountryID>
        </ram:PostalTradeAddress>
      </ram:BuyerTradeParty>
    </ram:ApplicableHeaderTradeAgreement>
    <ram:ApplicableHeaderTradeDelivery/>
    <ram:ApplicableHeaderTradeSettlement>
      <ram:InvoiceCurrencyCode>EUR</ram:InvoiceCurrencyCode>
      <ram:ApplicableTradeTax>
        <ram:CalculatedAmount>9.00</ram:CalculatedAmount>
        <ram:TypeCode>VAT</ram:TypeCode>
        <ram:BasisAmount>45.00</ram:BasisAmount>
        <ram:CategoryCode>S</ram:CategoryCode>
        <ram:RateApplicablePercent>20.00</ram:RateApplicablePercent>
      </ram:ApplicableTradeTax>
      <ram:SpecifiedTradeSettlementHeaderMonetarySummation>
        <ram:LineTotalAmount>45.00</ram:LineTotalAmount>
        <ram:TaxBasisTotalAmount>45.00</ram:TaxBasisTotalAmount>
        <ram:TaxTotalAmount currencyID="EUR">9.00</ram:TaxTotalAmount>
        <ram:GrandTotalAmount>54.00</ram:GrandTotalAmount>
        <ram:DuePayableAmount>54.00</ram:DuePayableAmount>
      </ram:SpecifiedTradeSettlementHeaderMonetarySummation>
    </ram:ApplicableHeaderTradeSettlement>
  </rsm:SupplyChainTradeTransaction>
</rsm:CrossIndustryInvoice>`;

export const rx380CiiPartiel: ReceptionFixture = {
  meta: {
    id: "rx-380-cii-partiel",
    title: "Facture 380 reçue — CII pur tiers, en_invoice partiel (sans totaux ni échéance)",
    typeCode: "380",
    btBg: ["BT-1", "BT-2", "BT-3", "BT-30", "BT-31", "BG-5", "BT-112"],
    findings: ["R8", "R2-renderPdfFromXml", "supplier-non-identifie"],
  },
  source: { kind: "xml", xml: XML, download: "xml" },
  incoming: {
    receivedAt: "2026-06-02T11:00:00.000Z",
    // Expand PARTIEL volontaire (cas fonctionnel R8) : ni totalTtcCents,
    // ni dueDate — alors que le XML, lui, porte les vrais totaux (54.00).
    enInvoice: {
      number: "FT-2026-0042",
      issueDate: "2026-06-02",
      currency: "EUR",
      sellerSiren: "123456782",
      sellerName: "Fournitures Tiers SARL",
    },
  },
  expect: {
    parsed: {
      documentType: "380",
      precedingInvoiceNumber: null,
      totalTtcCents: 5400,
      sellerSiren: "123456782",
    },
    row: {
      sellerSiren: "123456782",
      numberExtracted: "FT-2026-0042",
      totalTtcCents: null, // R8 — pas de montant en base, assumé
      supplierMatched: false,
      typeCodeIfPersisted: "380",
    },
    ui: {
      docLabel: "Facture",
      humanCheck: [
        "R8 : récap liste SANS montant inventé — « — » attendu, pas « 0,00 € » ni un TTC affiché en HT ; la fiche peut afficher 54,00 € via parsedMetadata",
        "Bandeau « Fournisseur non identifié » (supplier_matched=false) — n'empêche ni la fiche ni les poses",
        "R2 (chemin renderPdfFromXml) : aperçu = vue lisible reconstituée depuis le XML pur (pas de PDF embarqué) ; échec → 415, pas de page blanche",
      ],
    },
  },
};
