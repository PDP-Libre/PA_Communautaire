/** Fixture réception 4 — Rectificative 384 reçue BQ→Tricatel, BG-3 →
 *  origine rx-380-base-facturx. LA fixture centrale du cluster
 *  RECTIF-AFNOR :
 *   - R5 : affichée « Facture rectificative », PAS « Avoir » ;
 *   - R6/384 : matching origine ÉTENDU aux 384 — ⚠ anti-faux-vert ZG-5 :
 *     sur le code actuel (gate `documentType !== "381"`, get.ts:79),
 *     `expect.origin` DOIT échouer (payload creditNote=null) — c'est le
 *     détecteur du finding ;
 *   - R3 : depuis cette fiche, pose 209 sur l'ORIGINE (pas sur la
 *     rectificative) — nécessite l'ouverture du schéma (GAP-1 :
 *     PostCdarBodySchema interdit 209 aujourd'hui) ; la propagation côté
 *     vendeur est couverte par seq-209-acheteur ;
 *   - R4 : lien inverse depuis l'origine.
 *
 *  Z2 : document dérivé de `fx-384-rectif-bg3`. Cohérence cross-comptes :
 *  number FX-384-RECT-001, montants corrigés GrandTotal 1140.00 (expect.xml
 *  émission), virement 30 j → échéance 2026-07-05. */

import type { ReceptionFixture } from "./types.js";

export const rx384RectifBg3: ReceptionFixture = {
  meta: {
    id: "rx-384-rectif-bg3",
    title: "Rectificative 384 reçue — BG-3 vers origine présente (extension matching + pose 209)",
    typeCode: "384",
    btBg: ["BT-3(384)", "BG-3(BT-25/26)", "BT-30", "BT-112"],
    findings: ["R5", "R6-384", "R3", "R4"],
  },
  source: { kind: "emission", emissionFixtureId: "fx-384-rectif-bg3", download: "facturx-pdf" },
  incoming: {
    receivedAt: "2026-06-05T09:30:00.000Z",
    enInvoice: {
      number: "FX-384-RECT-001",
      issueDate: "2026-06-05",
      dueDate: "2026-07-05",
      currency: "EUR",
      sellerSiren: "000000002",
      sellerName: "Burger Queen",
      totalTtcCents: 114000,
    },
  },
  originFixtureId: "rx-380-base-facturx",
  expect: {
    parsed: {
      documentType: "384",
      precedingInvoiceNumber: "FX-380-BASE-001",
      totalTtcCents: 114000,
      sellerSiren: "000000002",
    },
    row: {
      sellerSiren: "000000002",
      numberExtracted: "FX-384-RECT-001",
      totalTtcCents: 114000,
      supplierMatched: true,
      typeCodeIfPersisted: "384",
    },
    // R6/384 — matching attendu APRÈS extension. Échoue sur le code actuel
    // (gate 381-only) : c'est voulu, l'oracle traverse le chemin du bug.
    origin: { isLinkedDoc: true, matchExpected: true },
    ui: {
      docLabel: "Facture rectificative",
      humanCheck: [
        "R5 : libellé « Facture rectificative » partout (liste si type_code dispo, fiche, bandeau) — JAMAIS « Avoir » ; pas de CTA « Marquer remboursée »",
        "Bandeau « rectification de la facture FX-380-BASE-001 » + lien vers l'origine",
        "R3 : action « Accepter la rectification » → pose 209 sur l'ORIGINE rx-380-base-facturx (statut Annulée côté Tricatel + propagation PA vers BQ — cf. seq-209-acheteur)",
        "GAP-4 : après pose 209 par MOI (acheteur), le bandeau de l'origine ne doit PAS dire « Annulée par le fournisseur »",
      ],
    },
  },
};
