/**
 * Table des motifs de refus 210 — Annexe E PRD, COMMUNE aux deux faces (Z6).
 *
 * SOURCE UNIQUE promue dans `@factur-e/shared-schemas`
 * (`constants/annexe-e-motifs`) par T-CL-RECV-CDAR-MOTIF (finding B, dédup) :
 * ce fichier n'est plus qu'un re-export pour les consommateurs du corpus
 * (séquences `seq-210-*`, oracles `timelineNotes`). Le code fait foi côté
 * shared-schemas.
 */

export {
  ANNEXE_E_MOTIFS,
  motifLabel,
  REFUSAL_REASON_CODES,
  type AnnexeEMotif,
  type RefusalReasonCode,
} from "@factur-e/shared-schemas";
