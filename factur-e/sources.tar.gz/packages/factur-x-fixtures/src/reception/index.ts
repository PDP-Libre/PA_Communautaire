/**
 * Corpus de fixtures de RÉCEPTION — API de consommation (contrat §3.2 du
 * 00-analyse-plan.md, symétrique de l'API émission existante).
 *
 * ⚠ INVARIANTS (identiques au paquet émission, T-CL-FIXTURES-WIRING §2) :
 * TEST-SUPPORT STRICT — deps `@factur-e/shared-schemas` uniquement, jamais
 * importé par du code métier de prod (tests + routes `__dev` seuls), garde-fou
 * ESLint `no-restricted-imports`. Destination wiring :
 * `packages/factur-x-fixtures/src/reception/` — l'API émission
 * (`allFixtures`/`getFixture`/`fixturesBy`) reste INCHANGÉE.
 *
 * Cycle de vie : 1 cas fonctionnel = 1 fichier fixture + 1 ligne de matrice
 * (01-matrice-couverture.md) — plus jamais 3+ sites (constat §1.3 : une
 * fixture entrante lie document + snapshot + events).
 */

import { rx380BaseFacturx } from "./rx-380-base-facturx.js";
import { rx380CiiPartiel } from "./rx-380-cii-partiel.js";
import { rx380SansTypecode } from "./rx-380-sans-typecode.js";
import { rx381AvoirBg3 } from "./rx-381-avoir-bg3.js";
import { rx381SansBg3 } from "./rx-381-sans-bg3.js";
import { rx384OrigineIntrouvable } from "./rx-384-origine-introuvable.js";
import { rx384RectifBg3 } from "./rx-384-rectif-bg3.js";
import { seq209Acheteur } from "./seq-209-acheteur.js";
import { seq210MotifAutre } from "./seq-210-motif-autre.js";
import { seq210MotifCode } from "./seq-210-motif-code.js";
import type { IncomingCdarSequence, ReceptionFixture } from "./types.js";

export * from "./types.js";
export { ANNEXE_E_MOTIFS, motifLabel, type AnnexeEMotif } from "./annexe-e-motifs.js";
export { RECEIVER_TRICATEL, SENDER_BQ, SENDER_TIERS } from "./parties.js";

/** Ordre = receivedAt croissant (l'origine des chaînages en premier — le
 *  seed « tout le corpus » peut itérer tel quel, l'origine est seedée avant
 *  les 381/384 qui la visent). */
const RECEPTION_CORPUS: readonly ReceptionFixture[] = [
  rx380BaseFacturx,
  rx380CiiPartiel,
  rx381AvoirBg3,
  rx384RectifBg3,
  rx384OrigineIntrouvable,
  rx381SansBg3,
  rx380SansTypecode,
];

const CDAR_SEQUENCES: readonly IncomingCdarSequence[] = [
  seq210MotifCode,
  seq210MotifAutre,
  seq209Acheteur,
];

export function allReceptionFixtures(): readonly ReceptionFixture[] {
  return RECEPTION_CORPUS;
}

export function getReceptionFixture(id: string): ReceptionFixture {
  const fx = RECEPTION_CORPUS.find((f) => f.meta.id === id);
  if (fx === undefined) {
    throw new Error(
      `Fixture réception inconnue : "${id}". Ids disponibles : ${RECEPTION_CORPUS.map((f) => f.meta.id).join(", ")}`,
    );
  }
  return fx;
}

export interface ReceptionFixtureFilter {
  finding?: string;
  typeCode?: "380" | "381" | "384";
  sourceKind?: "emission" | "xml";
}

export function receptionFixturesBy(filter: ReceptionFixtureFilter): readonly ReceptionFixture[] {
  return RECEPTION_CORPUS.filter(
    (f) =>
      (filter.finding === undefined || f.meta.findings.includes(filter.finding)) &&
      (filter.typeCode === undefined || f.meta.typeCode === filter.typeCode) &&
      (filter.sourceKind === undefined || f.source.kind === filter.sourceKind),
  );
}

export function allCdarSequences(): readonly IncomingCdarSequence[] {
  return CDAR_SEQUENCES;
}

export function getCdarSequence(id: string): IncomingCdarSequence {
  const seq = CDAR_SEQUENCES.find((s) => s.meta.id === id);
  if (seq === undefined) {
    throw new Error(
      `Séquence CDAR inconnue : "${id}". Ids disponibles : ${CDAR_SEQUENCES.map((s) => s.meta.id).join(", ")}`,
    );
  }
  return seq;
}
