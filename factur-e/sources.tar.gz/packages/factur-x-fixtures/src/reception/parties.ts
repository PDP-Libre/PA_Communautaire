/**
 * Identités du corpus réception — adaptateurs nommés du module UNIQUE
 * `../identities.ts` (T-CL-FIXTURES-RECV-WIRING). Ce fichier ne porte PLUS
 * aucun littéral SIREN : il ré-exporte / restreint le registre `TEST_IDENTITIES`.
 *
 * Côté RÉCEPTION, le tenant est l'ACQUÉREUR (Tricatel `000000001`) ;
 * l'expéditeur n'est PAS le tenant. Deux expéditeurs :
 *  - `SENDER_BQ` : flux cross-comptes BQ→Tricatel (`kind:"emission"`) —
 *    identités portées par `SELLER_BQ` du corpus émission (même registre).
 *  - `SENDER_TIERS` (Z5) : XML statiques tiers — JAMAIS Burger Queen, pour
 *    ne pas polluer la clé naturelle de matching origine.
 */

import { TEST_IDENTITIES } from "../identities.js";

/** Expéditeur tiers des XML statiques (Z5). SIREN fictif Luhn-valide,
 *  ABSENT de l'annuaire sandbox → `supplier_matched=false` attendu
 *  (bandeau « Fournisseur non identifié »). Le wiring configure
 *  `MockPADriver.setSearchSirenOutcome` → `not_found` pour ce SIREN. */
export const SENDER_TIERS = TEST_IDENTITIES.superpdp.senderTiers;

/** Tenant récepteur — Tricatel sandbox (= `BUYER_TRICATEL` émission,
 *  restreint au sous-ensemble utile aux rappels des XML statiques). */
export const RECEIVER_TRICATEL = {
  siren: TEST_IDENTITIES.superpdp.buyerTricatel.siren,
  legalName: TEST_IDENTITIES.superpdp.buyerTricatel.legalName,
} as const;

/** Expéditeur des flux `kind:"emission"` — Burger Queen sandbox
 *  (= `SELLER_BQ.siren` émission). Clé de matching origine BT-29. */
export const SENDER_BQ = {
  siren: TEST_IDENTITIES.superpdp.sellerBq.siren,
  legalName: TEST_IDENTITIES.superpdp.sellerBq.legalName,
} as const;
