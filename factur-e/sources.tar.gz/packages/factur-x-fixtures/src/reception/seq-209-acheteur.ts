/** Séquence CDAR 3 — Annulation 209 posée par l'ACHETEUR, vue VENDEUR (R3
 *  bout-en-bout) : Tricatel accepte la rectificative rx-384-rectif-bg3 →
 *  pose fr:209 sur la facture d'ORIGINE → côté BQ (émission), l'event
 *  entrant fait passer FX-380-BASE-001 à « Annulée ».
 *
 *  Cette séquence est la moitié ÉMISSION du scénario (poll-cdar-events →
 *  cdar_events → status_current) ; la moitié RÉCEPTION (pose) est portée
 *  par rx-384-rectif-bg3 (expect.ui R3). Préalables côté code, à lever par
 *  RECTIF-AFNOR :
 *   - GAP-1 : `PostCdarBodySchema` interdit 209 (`code ∈ {205,210,211}`,
 *     commentaire « 209/212 entrants, non posés par l'Acquéreur » —
 *     contradiction PRD v1.9 AVOIR-11) → ouvrir schéma + route + UI,
 *     pré-condition : 209 sur l'ORIGINE, pas sur la rectificative ;
 *   - GAP-4 : `CancelledNoticeBanner` (RecvDetailPage:152) dit « Annulée
 *     par le fournisseur » sur tout 209 sans regarder `source` — faux
 *     quand c'est MA pose.
 *
 *  fr:204 → fr:205 → fr:209 : la facture avait été approuvée avant que la
 *  rectification ne l'annule (parcours réaliste : approbation, litige,
 *  rectificative, annulation de l'origine). */

import type { IncomingCdarSequence } from "./types.js";

export const seq209Acheteur: IncomingCdarSequence = {
  meta: {
    id: "seq-209-acheteur",
    title: "Annulation 209 posée par l'acheteur — propagation côté vendeur (origine Annulée)",
    findings: ["R3-propagation", "GAP-1", "GAP-4"],
  },
  appliesToEmissionFixtureId: "fx-380-base-iban",
  events: [
    { statusCode: "fr:204", offsetMinutes: 0 },
    { statusCode: "fr:205", offsetMinutes: 30 },
    { statusCode: "fr:209", offsetMinutes: 120 },
  ],
  expect: {
    statusCurrent: "cancelled", // mapSuperPDPStatusCode("fr:209")
    // Pas de timelineNotes : un 209 ne porte pas de motif Annexe E. La
    // timeline émission doit montrer les 3 jalons, le dernier « Annulée ».
  },
};
