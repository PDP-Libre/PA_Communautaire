/** Séquence CDAR 2 — Refus 210 motif "11" (Autre) + texte libre, sur la
 *  facture émise fx-380-adv-riche. Finding B variante : le libellé
 *  normalisé est « Autre » ET le texte libre DOIT rester affiché (il porte
 *  toute l'information).
 *
 *  ⚠ HYPOTHÈSE H-REASON-TEXT (GAP-T2-1, 01-matrice-couverture.md §5) : la
 *  pose 210 actuelle n'envoie QUE le code à la PA
 *  (`details:[{reason: code}]` — cdar.ts:87 + superpdp-driver.ts:441) ; le
 *  `reason_text` du motif 11 n'est persisté QUE localement chez l'acheteur.
 *  Le `freeText` de cet oracle suppose qu'un texte peut arriver côté
 *  vendeur (`data.reason` enrichi ou champ dédié) — à CONFIRMER au smoke G1
 *  SuperPDP-AFNOR. Si infirmé : l'oracle se réduit à `normalizedLabel`
 *  « Autre » et le GAP (texte libre obligatoire perdu cross-comptes) est à
 *  escalader PMO. Convention d'injection (mock/__dev) : reason.code →
 *  `CdarEvent.reason`, reason.text → `payload.data` (cf. types.ts). */

import type { IncomingCdarSequence } from "./types.js";

export const seq210MotifAutre: IncomingCdarSequence = {
  meta: {
    id: "seq-210-motif-autre",
    title: "Refus 210 entrant — motif 11 (Autre) + texte libre préservé",
    findings: ["finding-B", "GAP-T2-1"],
  },
  appliesToEmissionFixtureId: "fx-380-adv-riche",
  events: [
    { statusCode: "fr:204", offsetMinutes: 0 },
    {
      statusCode: "fr:210",
      reason: {
        code: "11",
        text: "Conditions tarifaires renégociées au T2 - merci d'émettre une rectificative.",
      },
      offsetMinutes: 60,
    },
  ],
  expect: {
    statusCurrent: "refused_business",
    timelineNotes: [
      {
        code: "fr:210",
        normalizedLabel: "Autre",
        // Sous hypothèse H-REASON-TEXT (cf. en-tête) — jamais tronqué/masqué.
        freeText: "Conditions tarifaires renégociées au T2 - merci d'émettre une rectificative.",
      },
    ],
  },
};
