/** Fixture réception 3 — Avoir 381 reçu BQ→Tricatel, BG-3 → origine
 *  rx-380-base-facturx (BT-25 = FX-380-BASE-001). Régression du matching
 *  EXISTANT 381 (`resolveCreditNoteOrigin`) pendant l'extension 384 (R6)
 *  + R4 (lien inverse depuis l'origine) + CTA « Marquer remboursée »
 *  (AVOIR-10, pose 211).
 *
 *  Z2 : document dérivé de `fx-381-avoir-bg3` (corpus émission). Cohérence
 *  cross-comptes : number FX-381-AV-001, GrandTotal 960.00 (montants
 *  positifs, sémantique avoir portée par BT-3), BG-3 BT-25 FX-380-BASE-001
 *  / BT-26 2026-06-01, paiement onSight → pas d'échéance au snapshot. */

import type { ReceptionFixture } from "./types.js";

export const rx381AvoirBg3: ReceptionFixture = {
  meta: {
    id: "rx-381-avoir-bg3",
    title: "Avoir 381 reçu — BG-3 vers origine présente (régression matching existant)",
    typeCode: "381",
    btBg: ["BT-3(381)", "BG-3(BT-25/26)", "BT-30", "BT-112"],
    findings: ["R6-381-regression", "R4"],
  },
  source: { kind: "emission", emissionFixtureId: "fx-381-avoir-bg3", download: "facturx-pdf" },
  incoming: {
    receivedAt: "2026-06-05T09:00:00.000Z",
    enInvoice: {
      number: "FX-381-AV-001",
      issueDate: "2026-06-05",
      currency: "EUR",
      sellerSiren: "000000002",
      sellerName: "Burger Queen",
      totalTtcCents: 96000,
    },
  },
  originFixtureId: "rx-380-base-facturx",
  expect: {
    parsed: {
      documentType: "381",
      precedingInvoiceNumber: "FX-380-BASE-001",
      totalTtcCents: 96000,
      sellerSiren: "000000002",
    },
    row: {
      sellerSiren: "000000002",
      numberExtracted: "FX-381-AV-001",
      totalTtcCents: 96000,
      supplierMatched: true,
      typeCodeIfPersisted: "381",
    },
    // Chemin 381 existant : DOIT rester vert avant ET après l'extension 384.
    origin: { isLinkedDoc: true, matchExpected: true },
    ui: {
      docLabel: "Avoir",
      humanCheck: [
        "Bandeau type-aware « Avoir lié à la facture FX-380-BASE-001 » + lien vers la fiche origine",
        "CTA « Marquer remboursée » (pose 211, AVOIR-10) disponible après approbation",
        "R4 : la fiche de rx-380-base-facturx référence cet avoir (lookup inverse)",
      ],
    },
  },
};
