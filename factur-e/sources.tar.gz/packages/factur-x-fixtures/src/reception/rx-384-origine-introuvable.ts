/** Fixture réception 5 — Rectificative 384 reçue d'un tiers (Z5), BG-3 →
 *  numéro INCONNU `FA-INTROUVABLE-01` : variant dégradé R5/R6
 *  (`originFound=false`, bandeau « non retrouvée » type-aware). Cas réel :
 *  l'origine a été reçue hors plateforme / avant l'inscription.
 *
 *  XML validé xmllint contre CII D22B le 2026-06-11 (cf.
 *  01-matrice-couverture.md §4). BG-3 : `ram:InvoiceReferencedDocument`
 *  APRÈS la MonetarySummation (ordre XSD HeaderTradeSettlement). */

import type { ReceptionFixture } from "./types.js";

const XML = `<?xml version="1.0" encoding="UTF-8"?>
<rsm:CrossIndustryInvoice xmlns:qdt="urn:un:unece:uncefact:data:standard:QualifiedDataType:100" xmlns:ram="urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:100" xmlns:rsm="urn:un:unece:uncefact:data:standard:CrossIndustryInvoice:100" xmlns:udt="urn:un:unece:uncefact:data:standard:UnqualifiedDataType:100">
  <rsm:ExchangedDocumentContext>
    <ram:GuidelineSpecifiedDocumentContextParameter>
      <ram:ID>urn:cen.eu:en16931:2017</ram:ID>
    </ram:GuidelineSpecifiedDocumentContextParameter>
  </rsm:ExchangedDocumentContext>
  <rsm:ExchangedDocument>
    <ram:ID>FT-2026-0050-R</ram:ID>
    <ram:TypeCode>384</ram:TypeCode>
    <ram:IssueDateTime><udt:DateTimeString format="102">20260606</udt:DateTimeString></ram:IssueDateTime>
  </rsm:ExchangedDocument>
  <rsm:SupplyChainTradeTransaction>
    <ram:IncludedSupplyChainTradeLineItem>
      <ram:AssociatedDocumentLineDocument><ram:LineID>1</ram:LineID></ram:AssociatedDocumentLineDocument>
      <ram:SpecifiedTradeProduct><ram:Name>Maintenance photocopieur (rectification)</ram:Name></ram:SpecifiedTradeProduct>
      <ram:SpecifiedLineTradeAgreement>
        <ram:NetPriceProductTradePrice><ram:ChargeAmount>120.00</ram:ChargeAmount></ram:NetPriceProductTradePrice>
      </ram:SpecifiedLineTradeAgreement>
      <ram:SpecifiedLineTradeDelivery><ram:BilledQuantity unitCode="C62">1</ram:BilledQuantity></ram:SpecifiedLineTradeDelivery>
      <ram:SpecifiedLineTradeSettlement>
        <ram:ApplicableTradeTax>
          <ram:TypeCode>VAT</ram:TypeCode>
          <ram:CategoryCode>S</ram:CategoryCode>
          <ram:RateApplicablePercent>20.00</ram:RateApplicablePercent>
        </ram:ApplicableTradeTax>
        <ram:SpecifiedTradeSettlementLineMonetarySummation><ram:LineTotalAmount>120.00</ram:LineTotalAmount></ram:SpecifiedTradeSettlementLineMonetarySummation>
      </ram:SpecifiedLineTradeSettlement>
    </ram:IncludedSupplyChainTradeLineItem>
    <ram:ApplicableHeaderTradeAgreement>
      <ram:SellerTradeParty>
        <ram:Name>Fournitures Tiers SARL</ram:Name>
        <ram:SpecifiedLegalOrganization><ram:ID schemeID="0002">123456782</ram:ID></ram:SpecifiedLegalOrganization>
        <ram:PostalTradeAddress>
          <ram:PostcodeCode>69003</ram:PostcodeCode>
          <ram:LineOne>5 rue des Lilas</ram:LineOne>
          <ram:CityName>Lyon</ram:CityName>
          <ram:CountryID>FR</ram:CountryID>
        </ram:PostalTradeAddress>
        <ram:SpecifiedTaxRegistration><ram:ID schemeID="VA">FR11123456782</ram:ID></ram:SpecifiedTaxRegistration>
      </ram:SellerTradeParty>
      <ram:BuyerTradeParty>
        <ram:Name>Tricatel</ram:Name>
        <ram:SpecifiedLegalOrganization><ram:ID schemeID="0002">000000001</ram:ID></ram:SpecifiedLegalOrganization>
        <ram:PostalTradeAddress>
          <ram:PostcodeCode>75011</ram:PostcodeCode>
          <ram:LineOne>1 rue de l'Industrie</ram:LineOne>
          <ram:CityName>Paris</ram:CityName>
          <ram:CountryID>FR</ram:CountryID>
        </ram:PostalTradeAddress>
      </ram:BuyerTradeParty>
    </ram:ApplicableHeaderTradeAgreement>
    <ram:ApplicableHeaderTradeDelivery/>
    <ram:ApplicableHeaderTradeSettlement>
      <ram:InvoiceCurrencyCode>EUR</ram:InvoiceCurrencyCode>
      <ram:ApplicableTradeTax>
        <ram:CalculatedAmount>24.00</ram:CalculatedAmount>
        <ram:TypeCode>VAT</ram:TypeCode>
        <ram:BasisAmount>120.00</ram:BasisAmount>
        <ram:CategoryCode>S</ram:CategoryCode>
        <ram:RateApplicablePercent>20.00</ram:RateApplicablePercent>
      </ram:ApplicableTradeTax>
      <ram:SpecifiedTradePaymentTerms>
        <ram:DueDateDateTime><udt:DateTimeString format="102">20260706</udt:DateTimeString></ram:DueDateDateTime>
      </ram:SpecifiedTradePaymentTerms>
      <ram:SpecifiedTradeSettlementHeaderMonetarySummation>
        <ram:LineTotalAmount>120.00</ram:LineTotalAmount>
        <ram:TaxBasisTotalAmount>120.00</ram:TaxBasisTotalAmount>
        <ram:TaxTotalAmount currencyID="EUR">24.00</ram:TaxTotalAmount>
        <ram:GrandTotalAmount>144.00</ram:GrandTotalAmount>
        <ram:DuePayableAmount>144.00</ram:DuePayableAmount>
      </ram:SpecifiedTradeSettlementHeaderMonetarySummation>
      <ram:InvoiceReferencedDocument>
        <ram:IssuerAssignedID>FA-INTROUVABLE-01</ram:IssuerAssignedID>
        <ram:FormattedIssueDateTime><qdt:DateTimeString format="102">20260410</qdt:DateTimeString></ram:FormattedIssueDateTime>
      </ram:InvoiceReferencedDocument>
    </ram:ApplicableHeaderTradeSettlement>
  </rsm:SupplyChainTradeTransaction>
</rsm:CrossIndustryInvoice>`;

export const rx384OrigineIntrouvable: ReceptionFixture = {
  meta: {
    id: "rx-384-origine-introuvable",
    title: "Rectificative 384 reçue — BG-3 vers origine introuvable (variant dégradé)",
    typeCode: "384",
    btBg: ["BT-3(384)", "BG-3(BT-25/26)", "BT-30", "BT-112"],
    findings: ["R5-degrade", "R6-introuvable"],
  },
  source: { kind: "xml", xml: XML, download: "xml" },
  incoming: {
    receivedAt: "2026-06-06T08:00:00.000Z",
    enInvoice: {
      number: "FT-2026-0050-R",
      issueDate: "2026-06-06",
      dueDate: "2026-07-06",
      currency: "EUR",
      sellerSiren: "123456782",
      sellerName: "Fournitures Tiers SARL",
      totalTtcCents: 14400,
    },
  },
  // PAS d'originFixtureId : BT-25 pointe volontairement hors corpus.
  expect: {
    parsed: {
      documentType: "384",
      precedingInvoiceNumber: "FA-INTROUVABLE-01",
      totalTtcCents: 14400,
      sellerSiren: "123456782",
    },
    row: {
      sellerSiren: "123456782",
      numberExtracted: "FT-2026-0050-R",
      totalTtcCents: 14400,
      supplierMatched: false,
      typeCodeIfPersisted: "384",
    },
    // matchExpected=false : BT-25 présent mais lookup clé naturelle vide.
    origin: { isLinkedDoc: true, matchExpected: false },
    ui: {
      docLabel: "Facture rectificative",
      humanCheck: [
        "Bandeau dégradé type-aware : « rectification de la facture FA-INTROUVABLE-01 (non retrouvée) » — libellé 384, pas « Avoir lié… »",
        "R3 : pose 209 sur l'origine IMPOSSIBLE (pas d'origine en Réception) — l'action doit être absente ou expliquée, pas en erreur",
      ],
    },
  },
};
