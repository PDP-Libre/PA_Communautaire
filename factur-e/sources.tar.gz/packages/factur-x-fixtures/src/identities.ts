/**
 * Module UNIQUE d'identités test — fusion des identités émission (`seller`)
 * et réception (`parties`) du corpus (T-CL-FIXTURES-RECV-WIRING sprint-09,
 * décision Bruno 2026-06-11 option (a)). Toute identité test du monorepo est
 * exportée d'ici : AUCUN SIREN test en littéral ailleurs (les `parties.ts`
 * émission + réception ne font que ré-exporter / adapter ce registre).
 *
 * Invariants (paquet test-support strict) : dépend de `@factur-e/shared-schemas`
 * uniquement, jamais importé par du code métier de prod.
 *
 * ─ Distinction STRUCTURANTE (`knownToPa`, guide howto-fixture.md §5) ─
 *  - `knownToPa: true`  : identité PROVISIONNÉE dans le sandbox SuperPDP
 *    (Burger Queen 000000002, Tricatel 000000001 — on ne les choisit pas,
 *    elles sont imposées par la PA à l'étage 3).
 *  - `knownToPa: false` : identité délibérément ABSENTE de l'annuaire
 *    (`SENDER_TIERS` 123456782) — elle EXERCE `supplier_matched=false`
 *    (bandeau « Fournisseur non identifié »). Ne JAMAIS la « corriger » en
 *    identité sandbox.
 *
 * ─ Indirection (perspective S10 EsaLink, registre provider-aware) ─
 * Le registre est namespacé par provider (`superpdp`). Les consommateurs
 * importent les CONSTANTES NOMMÉES adaptées (`SELLER_BQ`, `SENDER_TIERS`…)
 * ré-exportées des `parties.ts`, jamais `TEST_IDENTITIES` ni un littéral —
 * ce niveau d'indirection laisse S10 brancher `esalink:{…Q6}` sans toucher
 * les ~30 fichiers consommateurs (Q6, gated G2).
 */

/** Adresse postale canonique (camelCase neutre — chaque `parties.ts` la
 *  mappe vers sa casse : snake_case pour le `FixtureSeller` émission). */
export interface TestIdentityAddress {
  lineOne: string;
  lineTwo?: string | null;
  postcode: string;
  city: string;
  countryCode: string;
}

export interface TestIdentity {
  /** SIREN (BT-30/31) — clé naturelle de matching origine côté réception. */
  siren: string;
  legalName: string;
  tradingName?: string;
  /** N° TVA intracom (BT-31/48) — clé dérivée (12 + 3×(SIREN mod 97)) mod 97. */
  vatNumber: string;
  address: TestIdentityAddress;
  /** BT-49 — identifiant annuaire PA (pattern propriétaire SuperPDP, non
   *  dérivable du SIREN). Absent pour les expéditeurs tiers hors annuaire. */
  electronicAddress?: string;
  electronicAddressScheme?: "0225";
  iban?: string;
  bic?: string;
  /** Provisionnée dans l'annuaire sandbox SuperPDP (cf. en-tête). */
  knownToPa: boolean;
}

/**
 * Registre des identités test, namespacé par provider PDP. `superpdp` = seul
 * provider V1 (sandbox du compte Bruno délégué). EsaLink (`esalink:{…}`) à
 * cadrer S10 quand les SIREN test seront connus (Q6).
 */
export const TEST_IDENTITIES = {
  superpdp: {
    /** Vendeur sandbox — Burger Queen, SAS avec IBAN. Connu de la PA. */
    sellerBq: {
      siren: "000000002",
      legalName: "Burger Queen",
      tradingName: "Burger Queen",
      vatNumber: "FR00000000002",
      address: {
        lineOne: "10 avenue des Champs-Élysées",
        postcode: "75008",
        city: "Paris",
        countryCode: "FR",
      },
      electronicAddress: "0225:315143296_3686",
      electronicAddressScheme: "0225",
      iban: "FR7630006000011234567890189",
      bic: "AGRIFRPP",
      knownToPa: true,
    },
    /** Acquéreur sandbox — Tricatel (tenant côté réception). Connu de la PA.
     *  N° TVA dérivé du SIREN 000000001 : (12 + 3×(1 mod 97)) mod 97 = 15. */
    buyerTricatel: {
      siren: "000000001",
      legalName: "Tricatel",
      vatNumber: "FR15000000001",
      address: {
        lineOne: "1 rue de l'Industrie",
        lineTwo: null,
        postcode: "75011",
        city: "Paris",
        countryCode: "FR",
      },
      electronicAddress: "0225:315143296_3685",
      electronicAddressScheme: "0225",
      knownToPa: true,
    },
    /** Expéditeur tiers des XML statiques réception (Z5) — SIREN fictif
     *  Luhn-valide ABSENT de l'annuaire → `supplier_matched=false`. N° TVA
     *  dérivé : (12 + 3×(123456782 mod 97)) mod 97 = 11. JAMAIS Burger Queen
     *  (ne pas polluer la clé naturelle de matching origine). */
    senderTiers: {
      siren: "123456782",
      legalName: "Fournitures Tiers SARL",
      vatNumber: "FR11123456782",
      address: {
        lineOne: "5 rue des Lilas",
        postcode: "69003",
        city: "Lyon",
        countryCode: "FR",
      },
      knownToPa: false,
    },
  },
} as const satisfies Record<string, Record<string, TestIdentity>>;
