/**
 * T-CW-FIXTURES-EMISSION sprint-08 — types du corpus de fixtures d'émission.
 *
 * Importé tel quel depuis la source hors-git (T-CL-FIXTURES-WIRING).
 * Paquet test-support — deps `@factur-e/shared-schemas` UNIQUEMENT. Jamais
 * importé par du code métier de prod (tests + seed `__dev`).
 *
 * Une fixture = description fonctionnelle **source unique** au niveau
 * `{ seller, form }` (correction Temps 1 actée : `formToModel(form, seller)`
 * exige le CustomerRow — IBAN, capital, mentions, régime TVA viennent du
 * seller, pas du form).
 */

import type { InvoiceForm } from "@factur-e/shared-schemas";

// ─────────────────────────────────────────────────────────────────────
// Seller — sous-ensemble structurel de `CustomerRow` (apps/api)
// ─────────────────────────────────────────────────────────────────────

/**
 * Sous-ensemble de `CustomerRow` consommé par `formToModel` +
 * `PdfEnrichment`. Type structurel local : le paquet fixtures ne peut PAS
 * dépendre d'apps/api (cycle). Le wiring le fusionne avec les défauts d'une
 * factory type `makeSeller(overrides)` / `seedCustomer(overrides)`.
 *
 * `default_invoice_values` : clés AFNOR `late_penalties_mention` (PMD) /
 * `discount_mention` (AAB) — la fixture fixe PMD pour rendre l'oracle F2
 * (troncature) déterministe.
 */
export interface FixtureSeller {
  siren: string;
  legal_name: string;
  trading_name: string | null;
  address: {
    line_one: string;
    line_two?: string | null;
    postcode: string;
    city: string;
    country_code: string;
  };
  naf_code: string | null;
  rcs: string | null;
  juridique_code: string | null;
  capital_social: string | null;
  vat_number: string | null;
  /** Régime TVA — valeurs usuelles "real" / "franchise" (adapté du type
   *  source hors-git `"real" | "franchise" | string` : union redondante
   *  réduite à `string`, l'adaptateur wiring mappe vers `VatRegime`). */
  vat_regime: string;
  vat_on_encashment: boolean;
  iban: string | null;
  bic: string | null;
  legal_mentions: string | null;
  /** Identifiant annuaire PA (BT-34) — pattern propriétaire SuperPDP
   *  `0225:<SIREN_partner>_<suffix>`, non dérivable du SIREN customer. */
  directory_address: string;
  default_invoice_values: Record<string, unknown>;
}

// ─────────────────────────────────────────────────────────────────────
// Attentes — oracles par couche consommatrice
// ─────────────────────────────────────────────────────────────────────

/** Nœud XML CII attendu. `path` = chemin abrégé lisible (pas un XPath
 *  exécutable — le wiring le compile vers son outillage d'assertion). */
export interface XmlExpectation {
  path: string;
  /** Valeur exacte attendue (texte du nœud ou attribut). */
  value?: string;
  /** true = le nœud DOIT être absent (ex. IBAN en paiement chèque). */
  absent?: boolean;
  note?: string;
}

/**
 * Attentes de contenu PDF (texte extrait du rendu).
 *
 * Oracles :
 * - `mustContain` : présence — couvre F1 (IBAN), F3 (note), F5 (N° TVA) et
 *   F2 (PMD tronquée : la chaîne PMD COMPLÈTE attrape la troncature).
 * - `mustNotContain` : absence (ex. privateComments jamais rendus).
 * - `mustContainInOrder` : sous-séquence ordonnée dans le texte extrait —
 *   oracle PARTIEL de position pour F7 (mention d'en-tête avant le tableau
 *   de lignes). L'ordre d'extraction texte ≈ ordre de layout, sans garantie
 *   géométrique.
 * - `humanCheck` : résidu explicitement HORS oracle auto (position visuelle
 *   exacte, lisibilité) → recette humaine. Acté GO Bruno Temps 1 : ne pas
 *   marquer F7 « couvert » par la seule présence.
 */
export interface PdfExpectation {
  mustContain: string[];
  mustNotContain?: string[];
  mustContainInOrder?: string[];
  humanCheck?: string[];
}

/** Oracle W3 : champs du `form` d'origine qui doivent survivre au
 *  round-trip persist → `reconstructFormFromPersisted` → re-génération.
 *  Chemins pointés dans `form` (ex. "payment.prepaidAmount"). */
export interface ReconstructionExpectation {
  roundTripFields: string[];
  note?: string;
}

/** Fixtures non conformes (blocage S1) : ids des règles Schematron qui
 *  DOIVENT lever — fatal EN 16931, jamais de contenu FNFE recopié. */
export interface SchematronExpectation {
  expectViolations: string[];
  note?: string;
}

// ─────────────────────────────────────────────────────────────────────
// Fixture
// ─────────────────────────────────────────────────────────────────────

export interface FixtureMeta {
  /** Identifiant stable — clé du seed recette nommé (Levier 2). */
  id: string;
  /** Intitulé fonctionnel. */
  title: string;
  typeCode: "380" | "381" | "384";
  uiMode: "base" | "advanced";
  /** false = fixture de blocage S1 (doit être REJETÉE par la cascade). */
  conformant: boolean;
  /** BT/BG exercés — alimente la matrice de couverture. */
  btBg: string[];
  /** Findings ciblés (F1/F2/F3/F5/F7/F8, G-cheque, G1-381, W3-*). */
  findings: string[];
  /** Règles BR exercées — par id uniquement (BR-…, BR-FR-…, BR-S-…). */
  rules: string[];
}

export interface EmissionFixture {
  meta: FixtureMeta;
  seller: FixtureSeller;
  /** Source unique — DOIT parser `InvoiceFormSchema` (garde-fou : le
   *  wiring exécute `InvoiceFormSchema.parse(fixture.form)` en test). */
  form: InvoiceForm;
  expect: {
    xml: XmlExpectation[];
    pdf: PdfExpectation;
    reconstruction?: ReconstructionExpectation;
    /** Présent ssi `meta.conformant === false`. */
    schematron?: SchematronExpectation;
  };
}
