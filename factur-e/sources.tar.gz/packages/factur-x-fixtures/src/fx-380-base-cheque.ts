/** Fixture 3 — Facture 380 base, vendeur SANS IBAN, paiement chèque.
 *  Couvre finding G-chèque (PaymentMeans 20 sans BG-17) + oracle de
 *  NON-rendu IBAN au PDF. Garde formToModel vérifiée : le blocage
 *  INVALID_PAYMENT_METHOD_MISSING_IBAN ne vise que transfer/direct_debit —
 *  chèque sans IBAN passe (voulu). */

import { BUYER_TRICATEL, PMD_MENTION_CORPUS, SELLER_BQ_SANS_IBAN } from "./parties.js";
import type { EmissionFixture } from "./types.js";

export const fx380BaseCheque: EmissionFixture = {
  meta: {
    id: "fx-380-base-cheque",
    title: "Facture 380 base — vendeur sans IBAN, paiement chèque",
    typeCode: "380",
    uiMode: "base",
    conformant: true,
    btBg: [
      "BT-1",
      "BT-2",
      "BT-3",
      "BT-81(20)",
      "BG-7",
      "BG-16 sans BG-17",
      "BG-22",
      "BG-23",
      "BG-25",
    ],
    findings: ["G-cheque", "F1-negatif"],
    rules: ["BR-16", "BR-49", "BR-CO-16", "BR-S-1", "BR-S-2", "BR-FR-05"],
  },
  seller: SELLER_BQ_SANS_IBAN,
  form: {
    ui_mode: "base",
    document: {
      number: "FX-380-CHQ-001",
      issueDate: "2026-06-01",
      notes: null,
    },
    parties: { buyer: BUYER_TRICATEL },
    lines: [
      {
        label: "Livraison plateaux repas direction",
        description: null,
        quantity: "10",
        unitCode: "C62",
        unitPriceHt: "25.00",
        vatCategory: "S",
        vatRate: "10.00",
        totalHt: "250.00",
      },
    ],
    payment: {
      paymentTerms: { kind: "onSight" },
      paymentMethodKind: "check",
      mentionsLegales: null,
    },
  },
  expect: {
    xml: [
      { path: "ExchangedDocument/TypeCode", value: "380" },
      {
        path: "SpecifiedTradeSettlementPaymentMeans/TypeCode",
        value: "20",
        note: "UNTDID 4461 chèque",
      },
      {
        path: "PayeePartyCreditorFinancialAccount/IBANID",
        absent: true,
        note: "Pas de BG-17 sans IBAN",
      },
      { path: "MonetarySummation/LineTotalAmount", value: "250.00" },
      { path: "MonetarySummation/TaxTotalAmount", value: "25.00" },
      { path: "MonetarySummation/GrandTotalAmount", value: "275.00" },
      { path: "ApplicableTradeTax[S]/RateApplicablePercent", value: "10.00" },
    ],
    pdf: {
      mustContain: ["FX-380-CHQ-001", "275.00", PMD_MENTION_CORPUS],
      mustNotContain: ["IBAN", "FR76"], // F1 négatif — aucun bloc bancaire fantôme
      humanCheck: ["Libellé du mode de règlement affiché (« Chèque » attendu, finding G)"],
    },
    reconstruction: {
      roundTripFields: ["payment.paymentMethodKind"],
      note: "Le mode de paiement chèque doit survivre au round-trip (famille finding G).",
    },
  },
};
