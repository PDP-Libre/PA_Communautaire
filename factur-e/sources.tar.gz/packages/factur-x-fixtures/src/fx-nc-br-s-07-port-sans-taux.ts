/**
 * Fixture NC-3 — frais de port BG-21 catégorie S SANS taux → BR-S-07
 * (EN 16931, fatal) : une charge document « standard rated » exige un taux
 * > 0 (+ breakdown S sans BT-119).
 *
 * Vérifié au code (seul le Schematron attrape) :
 * - Zod : `shippingCostVatRate` est `nullish()` — null passe.
 * - `buildShippingCharge` (invoice-form-to-model.ts) : `taxPercent` n'est
 *   posé QUE si shippingCostVatRate non null — aucune garde, défaut
 *   catégorie "S" conservé.
 * - `aggregateVATBreakdown` : crée un bucket "S|null" → breakdown S sans
 *   RateApplicablePercent.
 * → BR-S-07 (charge) + famille BR-S breakdown.
 */

import { BUYER_TRICATEL, SELLER_BQ } from "./parties.js";
import type { EmissionFixture } from "./types.js";

export const fxNcBrS07PortSansTaux: EmissionFixture = {
  meta: {
    id: "fx-nc-br-s-07-port-sans-taux",
    title: "NC — frais de port BG-21 catégorie S sans taux (BR-S-07)",
    typeCode: "380",
    uiMode: "advanced",
    conformant: false,
    btBg: ["BG-21", "BT-102(S)", "BT-103(absent)", "BG-23"],
    findings: ["S1-blocage"],
    rules: ["BR-S-07"],
  },
  seller: SELLER_BQ,
  form: {
    ui_mode: "advanced",
    document: {
      number: "FX-NC-S07-001",
      issueDate: "2026-06-01",
      typeCode: "380",
      currency: "EUR",
      processingRule: "B2B",
      buyerOrderRef: null,
      sellerOrderRef: null,
      contractRef: null,
      projectRef: null,
      billingPeriod: null,
      notes: null,
      privateComments: null,
      footerMentions: null,
      generalComments: null,
    },
    parties: {
      buyer: BUYER_TRICATEL,
      shipping: null,
      deliveryDate: null,
      clientTaxRegime: "default",
      transporter: null,
      trackingNumber: null,
    },
    lines: [
      {
        label: "Fournitures diverses",
        description: null,
        quantity: "4",
        unitCode: "C62",
        unitPriceHt: "50.00",
        vatCategory: "S",
        vatRate: "20.00",
        totalHt: "200.00",
        vatex: null,
        period: null,
        allowance: null,
        longDescription: null,
        note: null,
        basisQuantity: null,
      },
    ],
    documentLevelAllowance: null,
    shippingCostHt: "50.00", // BG-21 FC…
    shippingCostVatCategory: "S",
    shippingCostVatRate: null, // ← violation : S sans taux
    incoterm: null,
    payment: {
      paymentTerms: { kind: "days", days: 30 },
      paymentMethodKind: "transfer",
      paymentMeansCode: null,
      creditorReference: null,
      prepaidAmount: null,
      customPenalties: null,
      mentionsLegales: null,
    },
  },
  expect: {
    xml: [
      { path: "SpecifiedTradeAllowanceCharge[charge FC]/ActualAmount", value: "50.00" },
      {
        path: "SpecifiedTradeAllowanceCharge[charge FC]/CategoryTradeTax/RateApplicablePercent",
        absent: true,
      },
    ],
    pdf: { mustContain: [], humanCheck: ["N/A — fixture de blocage, jamais rendue"] },
    schematron: {
      expectViolations: ["BR-S-07"],
      note: "Doublon possible côté breakdown (bucket S|null sans BT-119) — le wiring consigne les ids effectivement levés par les SEF patchés W1.",
    },
  },
};
