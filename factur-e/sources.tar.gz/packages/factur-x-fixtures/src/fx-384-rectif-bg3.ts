/** Fixture 6 — Rectificative 384 avec BG-3 (BT-25/26). Montants corrigés
 *  (quantité ajustée vs origine). Exerce aussi la pose 209 auto sur
 *  l'origine à l'envoi (preceding_cancellation, brief L11 §3.1.2). */

import { BUYER_TRICATEL, SELLER_BQ } from "./parties.js";
import { FX_ORIGIN_INVOICE_ID } from "./fx-381-avoir-bg3.js";
import type { EmissionFixture } from "./types.js";

export const fx384RectifBg3: EmissionFixture = {
  meta: {
    id: "fx-384-rectif-bg3",
    title: "Rectificative 384 — BG-3 référence origine, montants corrigés",
    typeCode: "384",
    uiMode: "base",
    conformant: true,
    btBg: ["BT-3(384)", "BG-3(BT-25/26)", "BG-22", "BG-23", "BG-25"],
    findings: ["W3-bg3", "pose-209"],
    rules: ["BR-16", "BR-55", "BR-CO-16", "BR-S-1", "BR-FR-05"],
  },
  seller: SELLER_BQ,
  form: {
    ui_mode: "base",
    document: {
      number: "FX-384-RECT-001",
      issueDate: "2026-06-05",
      typeCode: "384",
      notes: "Rectifie la facture FX-380-BASE-001 (quantité forfait assistance).",
    },
    parties: { buyer: BUYER_TRICATEL },
    lines: [
      {
        label: "Prestation de conseil",
        description: "Audit du processus de facturation.",
        quantity: "1",
        unitCode: "HUR",
        unitPriceHt: "500.00",
        vatCategory: "S",
        vatRate: "20.00",
        totalHt: "500.00",
      },
      {
        label: "Forfait assistance",
        description: "Quantité corrigée : 3 au lieu de 2.",
        quantity: "3",
        unitCode: "C62",
        unitPriceHt: "150.00",
        vatCategory: "S",
        vatRate: "20.00",
        totalHt: "450.00",
      },
    ],
    payment: {
      paymentTerms: { kind: "days", days: 30 },
      paymentMethodKind: "transfer",
      mentionsLegales: null,
    },
    precedingInvoiceId: FX_ORIGIN_INVOICE_ID,
    precedingInvoiceNumber: "FX-380-BASE-001", // BT-25
    precedingIssueDate: "2026-06-01", // BT-26
  },
  expect: {
    xml: [
      { path: "ExchangedDocument/TypeCode", value: "384" },
      { path: "InvoiceReferencedDocument/IssuerAssignedID", value: "FX-380-BASE-001" },
      { path: "InvoiceReferencedDocument/FormattedIssueDateTime", value: "20260601" },
      { path: "MonetarySummation/LineTotalAmount", value: "950.00" },
      { path: "MonetarySummation/TaxTotalAmount", value: "190.00" },
      { path: "MonetarySummation/GrandTotalAmount", value: "1140.00" },
    ],
    pdf: {
      mustContain: [
        "FX-384-RECT-001",
        "rectificative", // template 384 — titre dédié
        "FX-380-BASE-001",
        "1140.00",
      ],
      humanCheck: ["Distinction visuelle claire 384 vs 380 (titre, encart origine)"],
    },
    reconstruction: {
      roundTripFields: [
        "document.typeCode",
        "document.notes",
        "precedingInvoiceNumber",
        "precedingIssueDate",
      ],
    },
  },
};
