/** Fixture 1 — Facture 380 mode base, vendeur avec IBAN, TVA standard S.
 *  Cas nominal Pierre/Claire : peu de lignes, virement 30 j, note publique. */

import { BUYER_TRICATEL, PMT_MENTION_LME, PMD_MENTION_CORPUS, SELLER_BQ } from "./parties.js";
import type { EmissionFixture } from "./types.js";

export const fx380BaseIban: EmissionFixture = {
  meta: {
    id: "fx-380-base-iban",
    title: "Facture 380 base — vendeur avec IBAN, TVA S, note publique",
    typeCode: "380",
    uiMode: "base",
    conformant: true,
    btBg: [
      "BT-1",
      "BT-2",
      "BT-3",
      "BT-22",
      "BG-4",
      "BG-7",
      "BG-17(BT-84)",
      "BG-22(BT-106/109/110/112/115)",
      "BG-23",
      "BG-25(BT-129/130/146/151/152/153)",
    ],
    findings: ["F1", "F3"],
    rules: ["BR-16", "BR-25", "BR-CO-10", "BR-CO-14", "BR-CO-16", "BR-S-1", "BR-S-2", "BR-FR-05"],
  },
  seller: SELLER_BQ,
  form: {
    ui_mode: "base",
    document: {
      number: "FX-380-BASE-001",
      issueDate: "2026-06-01",
      notes: "Note publique corpus : merci de votre confiance.",
    },
    parties: { buyer: BUYER_TRICATEL },
    lines: [
      {
        label: "Prestation de conseil",
        description: "Audit du processus de facturation.",
        quantity: "1",
        unitCode: "HUR",
        unitPriceHt: "500.00",
        vatCategory: "S",
        vatRate: "20.00",
        totalHt: "500.00",
      },
      {
        label: "Forfait assistance",
        description: null,
        quantity: "2",
        unitCode: "C62",
        unitPriceHt: "150.00",
        vatCategory: "S",
        vatRate: "20.00",
        totalHt: "300.00",
      },
    ],
    payment: {
      paymentTerms: { kind: "days", days: 30 },
      paymentMethodKind: "transfer",
      mentionsLegales: null,
    },
  },
  expect: {
    xml: [
      { path: "ExchangedDocument/TypeCode", value: "380" },
      { path: "ExchangedDocument/ID", value: "FX-380-BASE-001" },
      {
        path: "SellerTradeParty/SpecifiedLegalOrganization/ID[@schemeID=0002]",
        value: "000000002",
      },
      {
        path: "SellerTradeParty/SpecifiedTaxRegistration/ID[@schemeID=VA]",
        value: "FR00000000002",
      },
      {
        path: "BuyerTradeParty/URIUniversalCommunication/URIID[@schemeID=0225]",
        value: "315143296_3685",
      },
      {
        path: "PayeePartyCreditorFinancialAccount/IBANID",
        value: "FR7630006000011234567890189",
        note: "BG-17 BT-84 — virement",
      },
      { path: "SpecifiedTradeSettlementHeaderMonetarySummation/LineTotalAmount", value: "800.00" },
      { path: "SpecifiedTradeSettlementHeaderMonetarySummation/TaxTotalAmount", value: "160.00" },
      { path: "SpecifiedTradeSettlementHeaderMonetarySummation/GrandTotalAmount", value: "960.00" },
      { path: "SpecifiedTradeSettlementHeaderMonetarySummation/DuePayableAmount", value: "960.00" },
      { path: "ApplicableTradeTax[S]/RateApplicablePercent", value: "20.00" },
      {
        path: "IncludedNote[content=note publique]",
        value: "Note publique corpus : merci de votre confiance.",
        note: "BT-22 sans subjectCode",
      },
      { path: "IncludedNote[@PMT]", value: PMT_MENTION_LME, note: "BR-FR-05 auto-injectée" },
    ],
    pdf: {
      mustContain: [
        "FX-380-BASE-001",
        "FR7630006000011234567890189", // F1 — IBAN visible
        "Note publique corpus : merci de votre confiance.", // F3 — note publique rendue en base
        "Burger Queen",
        "Tricatel",
        "960.00",
        PMT_MENTION_LME,
        PMD_MENTION_CORPUS,
      ],
      humanCheck: ["Lisibilité bloc coordonnées bancaires (position, police)"],
    },
    reconstruction: {
      roundTripFields: [
        "document.number",
        "document.issueDate",
        "document.notes",
        "lines",
        "payment.paymentMethodKind",
      ],
      note: "Cas témoin W3 : mode base round-trip + notes (F3) réinjectées.",
    },
  },
};
