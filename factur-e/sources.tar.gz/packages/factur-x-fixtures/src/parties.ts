/**
 * Identités canoniques du corpus — alignées sandbox SuperPDP (ADR-010 v2 D6 :
 * le SIREN seller doit matcher le compte OAuth Burger Queen 000000002, sinon
 * 400 hard non bypassable). Réutilisées par le seed recette (Levier 2).
 *
 * Identifiants Peppol = pattern propriétaire SuperPDP `<SIREN_partner>_<suffix>`
 * NON dérivable du SIREN customer (cf. NOTE-COWORK seed-customer.ts) →
 * BR-FR-21 (BT-49 commence par SIREN BT-47) lèvera en WARNING flux2, non
 * bloquant S1. Assumé : cohérence sandbox > cohérence warning.
 *
 * WIRING (T-CL-FIXTURES-WIRING) — divergence assumée vs source hors-git :
 * `PMT_MENTION_LME` et `AAB_MENTION_DEFAULT` étaient des copies-valeur des
 * constantes AFNOR ; ré-exportées ici depuis `@factur-e/shared-schemas`
 * (source de vérité unique BR-FR-05). `PMD_MENTION_CORPUS` reste local : c'est
 * un override CONTRÔLÉ (oracle F2), ≠ du fallback LME paramétrable.
 *
 * FACTORISATION (T-CL-FIXTURES-RECV-WIRING) : les BITS D'IDENTITÉ (SIREN, n°
 * TVA, adresse, IBAN/BIC, identifiant annuaire) viennent désormais du module
 * UNIQUE `./identities.ts` (`TEST_IDENTITIES`) — zéro littéral SIREN ici. Seuls
 * restent locaux les attributs émission-spécifiques (NAF, RCS, capital, régime
 * TVA, mentions, `default_invoice_values`) qui ne sont pas des identités.
 */

import {
  AFNOR_BR_FR_05_AAB_DEFAULT_ABSENCE_ESCOMPTE,
  AFNOR_BR_FR_05_PMT_FORFAIT_40_EUR,
  AFNOR_DEFAULT_INVOICE_VALUES_PMD_KEY,
} from "@factur-e/shared-schemas";

import { TEST_IDENTITIES } from "./identities.js";
import type { FixtureSeller } from "./types.js";

const BQ = TEST_IDENTITIES.superpdp.sellerBq;
const TRICATEL = TEST_IDENTITIES.superpdp.buyerTricatel;

/** Mention PMD contrôlée par le corpus — oracle F2 déterministe : la chaîne
 *  COMPLÈTE doit apparaître dans le PDF (attrape la troncature). Override
 *  custom (≠ fallback LME `AFNOR_BR_FR_05_PMD_DEFAULT_LME_3X_TAUX_LEGAL`). */
export const PMD_MENTION_CORPUS =
  "Pénalités de retard : trois fois le taux d'intérêt légal en vigueur, exigibles sans rappel dès le lendemain de la date d'échéance, conformément aux articles L.441-10 et D.441-5 du Code de commerce.";

/** Mention PMT — fixe loi LME. Ré-exportée depuis `@factur-e/shared-schemas`
 *  (dédup wiring : source de vérité unique). */
export const PMT_MENTION_LME = AFNOR_BR_FR_05_PMT_FORFAIT_40_EUR;

/** Mention AAB par défaut — ré-exportée depuis `@factur-e/shared-schemas`. */
export const AAB_MENTION_DEFAULT = AFNOR_BR_FR_05_AAB_DEFAULT_ABSENCE_ESCOMPTE;

/** Seller canonique 1 — Burger Queen sandbox, AVEC IBAN, SAS au capital.
 *  Identité (SIREN, TVA, adresse, IBAN/BIC, annuaire) issue de
 *  `TEST_IDENTITIES.superpdp.sellerBq` ; reste émission-spécifique en dur. */
export const SELLER_BQ: FixtureSeller = {
  siren: BQ.siren,
  legal_name: BQ.legalName,
  trading_name: BQ.tradingName,
  address: {
    line_one: BQ.address.lineOne,
    postcode: BQ.address.postcode,
    city: BQ.address.city,
    country_code: BQ.address.countryCode,
  },
  naf_code: "5610A",
  rcs: "Paris B 000 000 002",
  juridique_code: "5710", // SAS
  capital_social: "50000.00",
  vat_number: BQ.vatNumber,
  vat_regime: "real",
  vat_on_encashment: false,
  iban: BQ.iban,
  bic: BQ.bic,
  legal_mentions: `RCS Paris B 000 000 002 — TVA ${BQ.vatNumber}`,
  directory_address: BQ.electronicAddress,
  default_invoice_values: {
    [AFNOR_DEFAULT_INVOICE_VALUES_PMD_KEY]: PMD_MENTION_CORPUS,
  },
};

/** Seller canonique 2 — Burger Queen SANS IBAN (paiement chèque, finding
 *  G-chèque + non-rendu IBAN). Même identité sandbox, iban/bic NULL. */
export const SELLER_BQ_SANS_IBAN: FixtureSeller = {
  ...SELLER_BQ,
  iban: null,
  bic: null,
};

/** Buyer canonique — Tricatel sandbox (BG-7). Identité issue de
 *  `TEST_IDENTITIES.superpdp.buyerTricatel`. */
export const BUYER_TRICATEL = {
  siren: TRICATEL.siren,
  legalName: TRICATEL.legalName,
  address: {
    lineOne: TRICATEL.address.lineOne,
    lineTwo: TRICATEL.address.lineTwo,
    postcode: TRICATEL.address.postcode,
    city: TRICATEL.address.city,
    countryCode: TRICATEL.address.countryCode,
  },
  electronicAddress: TRICATEL.electronicAddress,
  electronicAddressScheme: TRICATEL.electronicAddressScheme,
};

/** N° TVA intracom Tricatel dérivé du SIREN 000000001 (clé = (12+3×(SIREN
 *  mod 97)) mod 97 = 15) — cible oracle F5 (W2 doit le calculer/rendre,
 *  BT-48 n'existe pas au form : GAP-2 cf. 01-matrice-couverture.md §4). */
export const BUYER_TRICATEL_VAT = TRICATEL.vatNumber;
