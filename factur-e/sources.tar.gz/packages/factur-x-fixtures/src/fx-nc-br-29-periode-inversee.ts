/**
 * Fixture NC-2 — période de facturation BG-14 inversée (BT-74 < BT-73) →
 * BR-29 (EN 16931, fatal) : la date de fin doit être ≥ date de début.
 *
 * Vérifié au code (seul le Schematron attrape) :
 * - Zod `BillingPeriodSchema.refine` : exige seulement qu'UNE date soit
 *   présente (BR-CO-20) — aucun contrôle d'ordre.
 * - `formToModel` : passe start/end tels quels (lignes ~1052-1072).
 * → XML émis avec StartDateTime 20260610 > EndDateTime 20260601 → BR-29.
 */

import { BUYER_TRICATEL, SELLER_BQ } from "./parties.js";
import type { EmissionFixture } from "./types.js";

export const fxNcBr29PeriodeInversee: EmissionFixture = {
  meta: {
    id: "fx-nc-br-29-periode-inversee",
    title: "NC — période de facturation inversée BT-74 < BT-73 (BR-29)",
    typeCode: "380",
    uiMode: "advanced",
    conformant: false,
    btBg: ["BG-14", "BT-73", "BT-74"],
    findings: ["S1-blocage"],
    rules: ["BR-29"],
  },
  seller: SELLER_BQ,
  form: {
    ui_mode: "advanced",
    document: {
      number: "FX-NC-BR29-001",
      issueDate: "2026-06-15",
      typeCode: "380",
      currency: "EUR",
      processingRule: "B2B",
      buyerOrderRef: null,
      sellerOrderRef: null,
      contractRef: null,
      projectRef: null,
      billingPeriod: { startDate: "2026-06-10", endDate: "2026-06-01" }, // ← inversée
      notes: null,
      privateComments: null,
      footerMentions: null,
      generalComments: null,
    },
    parties: {
      buyer: BUYER_TRICATEL,
      shipping: null,
      deliveryDate: null,
      clientTaxRegime: "default",
      transporter: null,
      trackingNumber: null,
    },
    lines: [
      {
        label: "Abonnement mensuel",
        description: null,
        quantity: "1",
        unitCode: "MON",
        unitPriceHt: "300.00",
        vatCategory: "S",
        vatRate: "20.00",
        totalHt: "300.00",
        vatex: null,
        period: null,
        allowance: null,
        longDescription: null,
        note: null,
        basisQuantity: null,
      },
    ],
    documentLevelAllowance: null,
    shippingCostHt: null,
    shippingCostVatCategory: null,
    shippingCostVatRate: null,
    incoterm: null,
    payment: {
      paymentTerms: { kind: "days", days: 30 },
      paymentMethodKind: "transfer",
      paymentMeansCode: null,
      creditorReference: null,
      prepaidAmount: null,
      customPenalties: null,
      mentionsLegales: null,
    },
  },
  expect: {
    xml: [
      { path: "BillingSpecifiedPeriod/StartDateTime", value: "20260610" },
      { path: "BillingSpecifiedPeriod/EndDateTime", value: "20260601" },
    ],
    pdf: { mustContain: [], humanCheck: ["N/A — fixture de blocage, jamais rendue"] },
    schematron: {
      expectViolations: ["BR-29"],
      note: "Candidat naturel à une future garde Zod (refine ordre) — le jour où elle existe, cette fixture ne parse plus : signal voulu, la déplacer en test Zod.",
    },
  },
};
