/**
 * Corpus de fixtures d'émission — API de consommation (contrat §02).
 *
 * ⚠ INVARIANT (T-CL-FIXTURES-WIRING §2) — TEST-SUPPORT STRICT.
 * Ce paquet ne dépend que de `@factur-e/shared-schemas`. Il NE DOIT JAMAIS
 * être importé par du code métier de prod. Consommateurs autorisés :
 *   - suites de test (`*.test.ts`, `tests/**`) de toutes les apps/packages ;
 *   - endpoints seed `__dev` (`apps/api/src/routes/dev/**`), eux-mêmes
 *     dev-only (gatés `NODE_ENV !== "production"` au runtime).
 * Garde-fou outillé : règle ESLint `no-restricted-imports` sur
 * `@factur-e/factur-x-fixtures` dans `apps/api` (autorisé : tests + routes/dev).
 */

import { fx380AdvExoE } from "./fx-380-adv-exo-e.js";
import { fx380AdvRiche } from "./fx-380-adv-riche.js";
import { fx380BaseCheque } from "./fx-380-base-cheque.js";
import { fx380BaseIban } from "./fx-380-base-iban.js";
import { fx381AvoirBg3 } from "./fx-381-avoir-bg3.js";
import { fx384RectifBg3 } from "./fx-384-rectif-bg3.js";
import { fxNcBr29PeriodeInversee } from "./fx-nc-br-29-periode-inversee.js";
import { fxNcBrS05TauxZero } from "./fx-nc-br-s-05-taux-zero.js";
import { fxNcBrS07PortSansTaux } from "./fx-nc-br-s-07-port-sans-taux.js";
import type { EmissionFixture } from "./types.js";

export * from "./types.js";
export {
  AAB_MENTION_DEFAULT,
  BUYER_TRICATEL,
  BUYER_TRICATEL_VAT,
  PMD_MENTION_CORPUS,
  PMT_MENTION_LME,
  SELLER_BQ,
  SELLER_BQ_SANS_IBAN,
} from "./parties.js";
export { FX_ORIGIN_INVOICE_ID } from "./fx-381-avoir-bg3.js";

// Module UNIQUE d'identités test (T-CL-FIXTURES-RECV-WIRING) — source de
// vérité des SIREN/TVA/adresses sandbox, ré-exporté pour les consommateurs
// provider-aware S10.
export { TEST_IDENTITIES, type TestIdentity, type TestIdentityAddress } from "./identities.js";

// Corpus RÉCEPTION (flux entrants) — API symétrique de l'émission. L'API
// émission ci-dessus reste INCHANGÉE.
export * from "./reception/index.js";

const CORPUS: readonly EmissionFixture[] = [
  // Conformes
  fx380BaseIban,
  fx380AdvRiche,
  fx380BaseCheque,
  fx380AdvExoE,
  fx381AvoirBg3,
  fx384RectifBg3,
  // Non conformes (blocage S1)
  fxNcBrS05TauxZero,
  fxNcBr29PeriodeInversee,
  fxNcBrS07PortSansTaux,
];

export function allFixtures(): readonly EmissionFixture[] {
  return CORPUS;
}

export function getFixture(id: string): EmissionFixture {
  const fx = CORPUS.find((f) => f.meta.id === id);
  if (fx === undefined) {
    throw new Error(
      `Fixture inconnue : "${id}". Ids disponibles : ${CORPUS.map((f) => f.meta.id).join(", ")}`,
    );
  }
  return fx;
}

export interface FixtureFilter {
  finding?: string;
  typeCode?: "380" | "381" | "384";
  uiMode?: "base" | "advanced";
  conformant?: boolean;
}

export function fixturesBy(filter: FixtureFilter): readonly EmissionFixture[] {
  return CORPUS.filter(
    (f) =>
      (filter.finding === undefined || f.meta.findings.includes(filter.finding)) &&
      (filter.typeCode === undefined || f.meta.typeCode === filter.typeCode) &&
      (filter.uiMode === undefined || f.meta.uiMode === filter.uiMode) &&
      (filter.conformant === undefined || f.meta.conformant === filter.conformant),
  );
}
