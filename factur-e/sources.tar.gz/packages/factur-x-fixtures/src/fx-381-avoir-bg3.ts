/** Fixture 5 — Avoir 381 avec BG-3 (BT-25/26) référence à la facture
 *  d'origine fx-380-base-iban. Pattern endpoint credit-note : form base +
 *  typeCode + precedingInvoice* (champs vérifiés au schéma). Reconfirme G1
 *  (titre « Avoir », template 381) + round-trip BG-3 (W3). */

import { BUYER_TRICATEL, SELLER_BQ } from "./parties.js";
import type { EmissionFixture } from "./types.js";

/** UUID de chaînage stable corpus — le seed recette doit créer l'origine
 *  (fx-380-base-iban) avec cet id pour que le lookup pose 209 fonctionne. */
export const FX_ORIGIN_INVOICE_ID = "00000000-0000-4000-8000-00000000f380";

export const fx381AvoirBg3: EmissionFixture = {
  meta: {
    id: "fx-381-avoir-bg3",
    title: "Avoir 381 — BG-3 référence facture d'origine (BT-25/26)",
    typeCode: "381",
    uiMode: "base",
    conformant: true,
    btBg: ["BT-3(381)", "BG-3(BT-25/26)", "BG-22", "BG-23", "BG-25"],
    findings: ["G1-381", "W3-bg3"],
    rules: ["BR-16", "BR-55", "BR-CO-16", "BR-S-1", "BR-FR-05"],
  },
  seller: SELLER_BQ,
  form: {
    ui_mode: "base",
    document: {
      number: "FX-381-AV-001",
      issueDate: "2026-06-05",
      typeCode: "381",
      notes: "Avoir total sur facture FX-380-BASE-001.",
    },
    parties: { buyer: BUYER_TRICATEL },
    lines: [
      {
        label: "Prestation de conseil",
        description: "Annulation — audit du processus de facturation.",
        quantity: "1",
        unitCode: "HUR",
        unitPriceHt: "500.00",
        vatCategory: "S",
        vatRate: "20.00",
        totalHt: "500.00",
      },
      {
        label: "Forfait assistance",
        description: null,
        quantity: "2",
        unitCode: "C62",
        unitPriceHt: "150.00",
        vatCategory: "S",
        vatRate: "20.00",
        totalHt: "300.00",
      },
    ],
    payment: {
      paymentTerms: { kind: "onSight" },
      paymentMethodKind: "transfer",
      mentionsLegales: null,
    },
    precedingInvoiceId: FX_ORIGIN_INVOICE_ID,
    precedingInvoiceNumber: "FX-380-BASE-001", // BT-25
    precedingIssueDate: "2026-06-01", // BT-26
  },
  expect: {
    xml: [
      { path: "ExchangedDocument/TypeCode", value: "381" },
      {
        path: "InvoiceReferencedDocument/IssuerAssignedID",
        value: "FX-380-BASE-001",
        note: "BG-3 BT-25",
      },
      {
        path: "InvoiceReferencedDocument/FormattedIssueDateTime",
        value: "20260601",
        note: "BT-26",
      },
      {
        path: "MonetarySummation/GrandTotalAmount",
        value: "960.00",
        note: "Montants positifs type 381 (sémantique avoir portée par BT-3)",
      },
    ],
    pdf: {
      mustContain: [
        "FX-381-AV-001",
        "Avoir", // G1 — titre/template 381, pas « Facture »
        "FX-380-BASE-001", // référence origine visible
        "960.00",
      ],
      mustNotContain: ["Facture rectificative"],
      humanCheck: ["Bandeau/encart de lien vers la facture d'origine (placement)"],
    },
    reconstruction: {
      roundTripFields: [
        "document.typeCode",
        "document.notes",
        "precedingInvoiceNumber",
        "precedingIssueDate",
      ],
      note: "W3 : BG-3 (BT-25/26) + notes réinjectés à la reconstruction (typeCode déjà couvert).",
    },
  },
};
