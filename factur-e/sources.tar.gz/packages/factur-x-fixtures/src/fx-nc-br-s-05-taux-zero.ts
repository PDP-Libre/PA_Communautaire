/**
 * Fixture NC-1 — ligne catégorie S avec taux 0.00 → BR-S-05 (EN 16931,
 * fatal) : « standard rated » exige un taux > 0.
 *
 * Vérifié au code (seul le Schematron attrape) :
 * - Zod `LineItemBaseSchema.superRefine` : exige seulement vatRate NON NULL
 *   pour S — "0.00" passe (`VatRateStringSchema` accepte 0..100).
 * - `formToModel` : même check null/non-null uniquement.
 * - BR-FR-16 n'aide pas : 0 ∈ liste des taux français autorisés.
 * → XML émis : ligne S à 0% + breakdown S/0 → BR-S-05 (+ BR-S-01 contexte).
 */

import { BUYER_TRICATEL, SELLER_BQ } from "./parties.js";
import type { EmissionFixture } from "./types.js";

export const fxNcBrS05TauxZero: EmissionFixture = {
  meta: {
    id: "fx-nc-br-s-05-taux-zero",
    title: "NC — catégorie S avec taux TVA 0.00 (BR-S-05)",
    typeCode: "380",
    uiMode: "base",
    conformant: false,
    btBg: ["BT-151(S)", "BT-152(0)", "BG-23"],
    findings: ["S1-blocage"],
    rules: ["BR-S-05"],
  },
  seller: SELLER_BQ,
  form: {
    ui_mode: "base",
    document: {
      number: "FX-NC-S05-001",
      issueDate: "2026-06-01",
      notes: null,
    },
    parties: { buyer: BUYER_TRICATEL },
    lines: [
      {
        label: "Prestation taux S erroné",
        description: null,
        quantity: "1",
        unitCode: "C62",
        unitPriceHt: "100.00",
        vatCategory: "S",
        vatRate: "0.00", // ← violation : S exige > 0 (aurait dû être Z ou E)
        totalHt: "100.00",
      },
    ],
    payment: {
      paymentTerms: { kind: "days", days: 30 },
      paymentMethodKind: "transfer",
      mentionsLegales: null,
    },
  },
  expect: {
    xml: [
      {
        path: "ApplicableTradeTax[S]/RateApplicablePercent",
        value: "0.00",
        note: "Le XML EST émis — c'est la cascade S1 qui doit bloquer",
      },
    ],
    pdf: { mustContain: [], humanCheck: ["N/A — fixture de blocage, jamais rendue"] },
    schematron: {
      expectViolations: ["BR-S-05"],
      note: "IT W1 WIRE-EMISSION : POST /api/invoices → 422 + anomalies contenant BR-S-05.",
    },
  },
};
