/**
 * Fixture 4 — Facture 380 avancée intégralement exonérée (catégorie E,
 * BT-120/121 via VATEX). Porte l'oracle F5 (N° TVA acheteur visible PDF).
 *
 * ⚠ GAP-1 (bloquant convergence) : `formToModel` ignore `vatex` →
 * aucun ExemptionReason(Code) émis → BR-E-10 lèvera sur le XML actuel.
 * La fixture décrit la CIBLE fonctionnelle ; le mapping vatex→BT-121 est à
 * câbler (W-task, cf. matrice §4) avant que cette fixture passe la cascade.
 *
 * ⚠ GAP-2 (F5) : BT-48 (N° TVA acheteur) n'existe pas dans `InvoiceForm` —
 * non représentable au form. L'oracle PDF attend le N° TVA dérivé du SIREN
 * (FR15000000001) : à implémenter côté W2 (dérivation SIREN→TVA ou
 * enrichissement), sinon résidu humain.
 */

import { BUYER_TRICATEL, BUYER_TRICATEL_VAT, PMD_MENTION_CORPUS, SELLER_BQ } from "./parties.js";
import type { EmissionFixture } from "./types.js";

export const fx380AdvExoE: EmissionFixture = {
  meta: {
    id: "fx-380-adv-exo-e",
    title: "Facture 380 avancée exonérée — catégorie E + VATEX-EU-132, oracle F5",
    typeCode: "380",
    uiMode: "advanced",
    conformant: true, // sous réserve GAP-1
    btBg: ["BT-3", "BT-120", "BT-121", "BG-22", "BG-23(E)", "BG-25"],
    findings: ["F5"],
    rules: ["BR-E-1", "BR-E-5", "BR-E-9", "BR-E-10(GAP-1)", "BR-FR-05", "BR-FR-15"],
  },
  seller: SELLER_BQ,
  form: {
    ui_mode: "advanced",
    document: {
      number: "FX-380-EXO-001",
      issueDate: "2026-06-01",
      typeCode: "380",
      currency: "EUR",
      processingRule: "B2B",
      buyerOrderRef: null,
      sellerOrderRef: null,
      contractRef: null,
      projectRef: null,
      billingPeriod: null,
      notes: null,
      privateComments: null,
      footerMentions: "Exonération de TVA — article 132 de la directive 2006/112/CE.",
      generalComments: null,
    },
    parties: {
      buyer: BUYER_TRICATEL,
      shipping: null,
      deliveryDate: null,
      clientTaxRegime: "default",
      transporter: null,
      trackingNumber: null,
    },
    lines: [
      {
        label: "Formation hygiène alimentaire — session intra",
        description: "Formation professionnelle continue exonérée.",
        quantity: "1",
        unitCode: "C62",
        unitPriceHt: "1800.00",
        vatCategory: "E",
        vatRate: null,
        totalHt: "1800.00",
        vatex: "VATEX-EU-132", // BT-121
        period: null,
        allowance: null,
        longDescription: null,
        note: null,
        basisQuantity: null,
      },
    ],
    documentLevelAllowance: null,
    shippingCostHt: null,
    shippingCostVatCategory: null,
    shippingCostVatRate: null,
    incoterm: null,
    payment: {
      paymentTerms: { kind: "days", days: 30 },
      paymentMethodKind: "transfer",
      paymentMeansCode: null,
      creditorReference: null,
      prepaidAmount: null,
      customPenalties: null,
      mentionsLegales: null,
    },
  },
  expect: {
    xml: [
      { path: "ApplicableTradeTax[E]/CategoryCode", value: "E" },
      {
        path: "ApplicableTradeTax[E]/ExemptionReasonCode",
        value: "VATEX-EU-132",
        note: "GAP-1 — cible, absent à date",
      },
      { path: "ApplicableTradeTax[E]/CalculatedAmount", value: "0.00" },
      { path: "MonetarySummation/TaxTotalAmount", value: "0.00" },
      { path: "MonetarySummation/GrandTotalAmount", value: "1800.00" },
      {
        path: "ApplicableTradeTax[E]/RateApplicablePercent",
        absent: true,
        note: "Pas de taux pour E (ou 0 selon builder — wiring tranche au code)",
      },
    ],
    pdf: {
      mustContain: [
        "FX-380-EXO-001",
        BUYER_TRICATEL_VAT, // F5 — N° TVA acheteur visible (GAP-2 : dérivation W2)
        "Exonération de TVA — article 132 de la directive 2006/112/CE.",
        "1800.00",
        PMD_MENTION_CORPUS,
      ],
      humanCheck: ["F5 tant que GAP-2 non câblé : vérif visuelle N° TVA acheteur en recette"],
    },
    reconstruction: {
      roundTripFields: ["lines.0.vatex", "document.footerMentions"],
      note: "vatex doit survivre au round-trip (aujourd'hui payload_extended au mieux).",
    },
  },
};
