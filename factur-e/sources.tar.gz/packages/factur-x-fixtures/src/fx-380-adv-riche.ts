/**
 * Fixture 2 — Facture 380 mode avancé « riche » : multi-lignes, multi-TVA
 * (S + E), remise globale % (BG-20), frais de port (BG-21 FC), acompte
 * BT-113→BT-115, INCOTERM, 4 zones notes, expédition BG-13, période BG-14.
 *
 * Pivot des oracles W2 (F2 PMD complète, F7 placement) et W3 (prepaid +
 * allowance + charge round-trip — exactement les champs que
 * `reconstructFormFromPersisted` mode base PERD aujourd'hui).
 *
 * GAP-1 (CÂBLÉ au wiring T-CL-FIXTURES-WIRING) : la ligne E exige BT-121
 * (VATEX) + taux 0 explicite au breakdown/ligne (BR-E-05/10, BR-48) —
 * `formToModel` propage désormais `vatex` et injecte le taux 0 des catégories
 * exonérées.
 *
 * Totaux (REVALIDÉS par exécution au wiring — cf. cycle de vie §5 : correction
 * d'une erreur corpus, la source hors-git documentait remise 600 sur base
 * 12000) :
 *   lignes S : 9000 + 1000 = 10000 · ligne E : 2000 → BT-106 = 12000.00
 *   BG-20 remise 5% catégorie S → base = Σ lignes S = 10000 (PAS 12000 : une
 *     remise document catégorie S ne porte pas la ligne E) → BT-92/107 = 500.00
 *   BG-21 port S 20% : 120.00 → BT-108 = 120.00
 *   BT-109 = 11620.00 · TVA S : (10000−500+120)×20% = 1924.00 → BT-110 = 1924.00
 *   BT-112 = 13544.00 · BT-113 acompte = 3000.00 → BT-115 = 10544.00
 */

import { BUYER_TRICATEL, PMD_MENTION_CORPUS, SELLER_BQ } from "./parties.js";
import type { EmissionFixture } from "./types.js";

export const fx380AdvRiche: EmissionFixture = {
  meta: {
    id: "fx-380-adv-riche",
    title: "Facture 380 avancée riche — S+E, BG-20, BG-21, acompte, INCOTERM, 4 zones notes",
    typeCode: "380",
    uiMode: "advanced",
    conformant: true, // sous réserve GAP-1 (vatex→BT-121)
    btBg: [
      "BT-3",
      "BT-5",
      "BT-9",
      "BT-12",
      "BT-13",
      "BT-14",
      "BT-20",
      "BT-22",
      "BT-72",
      "BT-113",
      "BT-115",
      "BT-X-22(INCOTERM)",
      "BG-13",
      "BG-14(BT-73/74)",
      "BG-20(BT-92/93/94/97/98)",
      "BG-21(FC)",
      "BG-22",
      "BG-23(S+E)",
      "BG-25 multi",
      "BG-26(ligne)",
    ],
    findings: ["F2", "F7", "W3-prepaid", "W3-allowance", "W3-charge"],
    rules: [
      "BR-16",
      "BR-29",
      "BR-31",
      "BR-33",
      "BR-CO-10",
      "BR-CO-11",
      "BR-CO-12",
      "BR-CO-13",
      "BR-CO-16",
      "BR-S-1..8",
      "BR-E-1",
      "BR-E-10(GAP-1)",
      "BR-FR-05",
      "BR-FREXT-CL-27",
    ],
  },
  seller: SELLER_BQ,
  form: {
    ui_mode: "advanced",
    document: {
      number: "FX-380-ADV-001",
      issueDate: "2026-06-01",
      typeCode: "380",
      currency: "EUR",
      processingRule: "B2B",
      buyerOrderRef: "PO-2026-0815",
      sellerOrderRef: "BQ-CMD-202606-01",
      contractRef: "CTR-2026-042",
      projectRef: null,
      billingPeriod: { startDate: "2026-05-01", endDate: "2026-05-31" },
      notes: "Zone publique : facture mensuelle mai 2026.", // BT-22
      privateComments: "INTERNE corpus — ne doit JAMAIS apparaître (XML ni PDF).",
      footerMentions: "Escompte 1% pour paiement sous 8 jours.", // BG-1 REG → pied PDF
      generalComments: "Mention d'en-tête corpus : marché AUDIT-Q2.", // BT-22 → en-tête PDF (F7)
    },
    parties: {
      buyer: BUYER_TRICATEL,
      shipping: {
        name: "Tricatel — Entrepôt Sud",
        locationId: "TRIC-SUD-01",
        address: {
          lineOne: "45 chemin des Usines",
          lineTwo: null,
          postcode: "69200",
          city: "Vénissieux",
          countryCode: "FR",
        },
      },
      deliveryDate: "2026-05-28",
      clientTaxRegime: "default",
      transporter: null,
      trackingNumber: "TRK-889912",
    },
    lines: [
      {
        label: "Audit conformité — forfait mensuel",
        description: "Revue mensuelle des dépôts.",
        quantity: "6",
        unitCode: "MON",
        unitPriceHt: "1500.00",
        vatCategory: "S",
        vatRate: "20.00",
        totalHt: "9000.00",
        vatex: null,
        period: { startDate: "2026-05-01", endDate: "2026-05-31" },
        allowance: null,
        longDescription:
          "Inclut la préparation des dossiers de contrôle et la restitution mensuelle.",
        note: "Prestation forfaitaire mensuelle.",
        basisQuantity: "1",
      },
      {
        label: "Formation professionnelle continue",
        description: "Session intra-entreprise — exonération TVA art. 261.4.4° CGI.",
        quantity: "1",
        unitCode: "C62",
        unitPriceHt: "2000.00",
        vatCategory: "E",
        vatRate: null,
        totalHt: "2000.00",
        vatex: "VATEX-EU-132", // GAP-1 : non mappé BT-121 par formToModel à date
        period: null,
        allowance: null,
        longDescription: null,
        note: null,
        basisQuantity: null,
      },
      {
        label: "Maintenance annuelle plateforme",
        description: null,
        quantity: "2",
        unitCode: "C62",
        unitPriceHt: "500.00",
        vatCategory: "S",
        vatRate: "20.00",
        totalHt: "1000.00",
        vatex: null,
        period: null,
        allowance: null,
        longDescription: null,
        note: null,
        basisQuantity: null,
      },
    ],
    documentLevelAllowance: {
      chargeIndicator: false, // BG-20 remise globale
      // amount/baseAmount sont DÉRIVÉS par formToModel (finding I : % sur la
      // base de la catégorie S = Σ lignes S = 10000). Valeurs cohérentes
      // documentées ici (corrigées vs source hors-git 600/12000).
      amount: "500.00", // BT-92 (dérivé : 10000 × 5%)
      baseAmount: "10000.00", // BT-93 (Σ lignes catégorie S)
      percent: "5.00", // BT-94
      reason: "Remise commerciale corpus", // BT-97
      reasonCode: "95", // BT-98
      vatCategory: "S", // BT-95
      vatRate: "20.00", // BT-96
    },
    shippingCostHt: "120.00", // BG-21 FC
    shippingCostVatCategory: "S",
    shippingCostVatRate: "20.00",
    incoterm: "DAP", // BT-X-22 — whitelist BR-FREXT-CL-27
    payment: {
      paymentTerms: { kind: "fixedDate", dueDate: "2026-06-30" }, // BT-9
      paymentMethodKind: "transfer",
      paymentMeansCode: null,
      creditorReference: null,
      prepaidAmount: "3000.00", // BT-113
      customPenalties: null,
      mentionsLegales: null,
    },
  },
  expect: {
    xml: [
      { path: "ExchangedDocument/TypeCode", value: "380" },
      { path: "BillingSpecifiedPeriod/StartDateTime", value: "20260501" },
      { path: "BillingSpecifiedPeriod/EndDateTime", value: "20260531" },
      { path: "ShipToTradeParty/Name", value: "Tricatel — Entrepôt Sud" },
      {
        path: "ApplicableTradeDeliveryTerms/DeliveryTypeCode",
        value: "DAP",
        note: "BT-X-22 EXTENDED",
      },
      { path: "SpecifiedTradeAllowanceCharge[allowance]/ActualAmount", value: "500.00" },
      { path: "SpecifiedTradeAllowanceCharge[allowance]/CalculationPercent", value: "5.00" },
      { path: "SpecifiedTradeAllowanceCharge[charge FC]/ActualAmount", value: "120.00" },
      { path: "MonetarySummation/LineTotalAmount", value: "12000.00" },
      { path: "MonetarySummation/AllowanceTotalAmount", value: "500.00" },
      { path: "MonetarySummation/ChargeTotalAmount", value: "120.00" },
      { path: "MonetarySummation/TaxBasisTotalAmount", value: "11620.00" },
      { path: "MonetarySummation/TaxTotalAmount", value: "1924.00" },
      { path: "MonetarySummation/GrandTotalAmount", value: "13544.00" },
      { path: "MonetarySummation/TotalPrepaidAmount", value: "3000.00" },
      { path: "MonetarySummation/DuePayableAmount", value: "10544.00" },
      {
        path: "ApplicableTradeTax[E]/ExemptionReasonCode",
        value: "VATEX-EU-132",
        note: "GAP-1 — attendu cible, absent à date (formToModel ignore vatex)",
      },
      {
        path: "IncludedNote[privateComments]",
        absent: true,
        note: "Invariant §4 #8 — jamais dans le XML",
      },
      { path: "DueDateDateTime", value: "20260630" },
    ],
    pdf: {
      mustContain: [
        "FX-380-ADV-001",
        PMD_MENTION_CORPUS, // F2 — chaîne complète = oracle anti-troncature
        "Mention d'en-tête corpus : marché AUDIT-Q2.", // F7 — présence
        "Escompte 1% pour paiement sous 8 jours.",
        "13544.00", // BT-112 TTC — aligné sur expect.xml (remise corrigée 600→500, wiring)
        "3000.00", // acompte visible (BT-113)
        "10544.00", // BT-115 net à payer = 13544 − 3000
        "Tricatel — Entrepôt Sud",
        "DAP",
      ],
      mustNotContain: ["INTERNE corpus"], // privateComments jamais rendus
      mustContainInOrder: [
        "Mention d'en-tête corpus : marché AUDIT-Q2.", // F7 — l'en-tête…
        "Audit conformité — forfait mensuel", // …précède la 1re ligne du tableau
      ],
      humanCheck: [
        "F7 : position visuelle exacte de la mention d'en-tête (au-dessus du tableau, pas en pied) — l'ordre d'extraction texte est un oracle partiel",
      ],
    },
    reconstruction: {
      roundTripFields: [
        "payment.prepaidAmount",
        "documentLevelAllowance",
        "shippingCostHt",
        "shippingCostVatCategory",
        "shippingCostVatRate",
        "incoterm",
        "document.notes",
        "document.generalComments",
        "document.footerMentions",
        "parties.shipping",
      ],
      note: "Cœur W3 : champs perdus par la reconstruction mode base — réinjectés via form avancé.",
    },
  },
};
