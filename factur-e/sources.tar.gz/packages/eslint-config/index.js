import js from "@eslint/js";
import tseslint from "typescript-eslint";

/**
 * Base flat ESLint config for Factur-e TypeScript code.
 *
 * Strict + typed-checked on TS files. JS config files (eslint.config.js,
 * vite.config.ts compiled to .js, etc.) get the type-aware rules disabled.
 * Each package's tsconfig.json is auto-discovered via `projectService: true`.
 */
export default tseslint.config(
  {
    ignores: [
      "dist/**",
      "build/**",
      "coverage/**",
      ".turbo/**",
      "node_modules/**",
      // Build/config files — usually live outside the package's tsconfig include
      // (intentionally, to avoid pulling tooling deps into runtime types).
      "**/*.config.{ts,tsx,mts,cts}",
      "**/vitest.config.{ts,tsx,mts,cts}",
      "**/tailwind.config.{ts,tsx,mts,cts}",
    ],
  },
  js.configs.recommended,
  ...tseslint.configs.strictTypeChecked,
  ...tseslint.configs.stylisticTypeChecked,
  {
    languageOptions: {
      parserOptions: {
        projectService: true,
      },
    },
    rules: {
      "@typescript-eslint/no-floating-promises": "error",
      "@typescript-eslint/no-misused-promises": "error",
      "@typescript-eslint/no-unused-vars": [
        "error",
        { argsIgnorePattern: "^_", varsIgnorePattern: "^_" },
      ],
      "@typescript-eslint/consistent-type-imports": [
        "error",
        { prefer: "type-imports", fixStyle: "inline-type-imports" },
      ],
      "no-console": ["warn", { allow: ["warn", "error"] }],
      eqeqeq: ["error", "always"],
    },
  },
  {
    files: ["**/*.{js,mjs,cjs}"],
    ...tseslint.configs.disableTypeChecked,
  },
);
