import base from "./index.js";

/**
 * Node-flavored config: enables Node globals on top of the base TS rules.
 * Used by `apps/api`, `services/*` Node tooling, scripts, and tests.
 */
export default [
  ...base,
  {
    files: ["**/*.{ts,tsx,js,mjs,cjs}"],
    languageOptions: {
      globals: {
        process: "readonly",
        console: "readonly",
        Buffer: "readonly",
        __dirname: "readonly",
        __filename: "readonly",
        global: "readonly",
        globalThis: "readonly",
      },
    },
  },
];
