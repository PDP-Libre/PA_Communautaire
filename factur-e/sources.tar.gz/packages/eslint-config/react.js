import base from "./index.js";

/**
 * React/browser config placeholder.
 *
 * react-hooks and jsx-a11y plugins will land in T-CL-11 alongside `apps/web`.
 * Extends the base TS rules and adds browser globals.
 */
export default [
  ...base,
  {
    files: ["**/*.{ts,tsx}"],
    languageOptions: {
      globals: {
        window: "readonly",
        document: "readonly",
        navigator: "readonly",
        fetch: "readonly",
      },
    },
  },
];
