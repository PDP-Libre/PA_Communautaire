import type { Preview } from "@storybook/react-vite";

import "../src/styles.css";

const preview: Preview = {
  parameters: {
    backgrounds: {
      default: "canvas",
      values: [
        { name: "canvas", value: "#f8fafc" },
        { name: "surface", value: "#ffffff" },
        { name: "inverse", value: "#0f172a" },
      ],
    },
    viewport: {
      viewports: {
        mobile: {
          name: "Mobile (375×812)",
          styles: { width: "375px", height: "812px" },
          type: "mobile",
        },
        tablet: {
          name: "Tablet (768×1024)",
          styles: { width: "768px", height: "1024px" },
          type: "tablet",
        },
        desktop: {
          name: "Desktop (1280×800)",
          styles: { width: "1280px", height: "800px" },
          type: "desktop",
        },
      },
    },
    a11y: {
      element: "#storybook-root",
      config: {},
      options: {},
    },
    options: {
      storySort: {
        order: ["Foundations", "Layout", "Form", "Feedback", "*"],
      },
    },
  },
  tags: ["autodocs"],
};

export default preview;
