import { createHmac } from "node:crypto";
import type { AddressInfo } from "node:net";

import Fastify, { type FastifyInstance } from "fastify";

/**
 * `fakeSuperPdp` — serveur HTTP Fastify qui imite SuperPDP pour les
 * tests d'intégration `pa-adapter` + `apps/api`. Refondu
 * T-CL-PA-INVOICE-FIX sprint-04 pour matcher l'API propriétaire JSON
 * `/v1.beta/*` réelle (ADR-010 v2) :
 *
 * Endpoints couverts :
 *  - **OAuth** : `GET /oauth2/authorize`, `POST /oauth2/token`,
 *    `POST /oauth2/revoke` (sprint-03 préservés).
 *  - **Identity** : `GET /v1.beta/oauth2_sessions/me` (sprint-03).
 *  - **Annuaire** : `GET /v1.beta/french_directory/{companies,entries}`
 *    (T-CL-09 sprint-03 préservé).
 *  - **POST /v1.beta/invoices** (sprint-04 refactor) — body
 *    `application/pdf` direct + query `external_id` UUID +
 *    `disable_pre_check`. Retourne `{id, events, created_at}` schema
 *    `invoice` (ADR-010 v2 D3).
 *  - **GET /v1.beta/invoice_events** (sprint-04 nouveau) — cursor
 *    Stripe-like `starting_after_id` + `limit`. Retourne
 *    `{data, has_after}` schema `list_events` (ADR-010 v2 D4).
 *  - **POST /v1.beta/validation_reports** (sprint-04 nouveau) —
 *    multipart, retourne `validation_report` minimal (ADR-010 v2 D6).
 *
 * Suppression : `POST /v1.beta/flows` + `GET /v1.beta/flows/:id/events`
 * (paths inventés T-CL-PA-EXT, n'existaient pas côté API).
 *
 * Scénarios paramétrables (`FakeSuperPdpScenario`) :
 *  - `verified` (default) — happy path identity.
 *  - `needs_review` / `rejected` — identity statuses non-verified.
 *  - `5xx_then_ok` — premier `/oauth2/token` retourne 500.
 *  - `invalid_grant` — refresh_token 400 invalid_grant.
 *  - `submit_5xx_then_ok` / `submit_4xx_xsd` / `submit_403_forbidden` /
 *    `submit_429_rate_limit` / `submit_401_token_expired` /
 *    `submit_400_seller_address` (cas spécifique ADR-010 v2 D5).
 *
 * Le fake écoute sur un port aléatoire. La méthode `start()` retourne
 * un objet `{baseUrl, stop}`.
 */

export type FakeSuperPdpScenario =
  | "verified"
  | "needs_review"
  | "rejected"
  | "5xx_then_ok"
  | "invalid_grant"
  | "submit_happy"
  | "submit_5xx_then_ok"
  | "submit_4xx_xsd"
  | "submit_400_seller_address"
  | "submit_403_forbidden"
  | "submit_429_rate_limit"
  | "submit_401_token_expired";

/** Event CDAR seedable côté tests — shape consommée par
 *  `GET /v1.beta/invoice_events`. Le fake auto-assigne `id` séquentiel +
 *  `invoice_id` (per-invoice). */
export interface FakeInvoiceEvent {
  /** ID raw SuperPDP — auto-assigné si non fourni. */
  id?: number;
  /** ID invoice SuperPDP — auto-rempli au seed depuis le contexte parent. */
  invoice_id?: number;
  status_code: string;
  status_text?: string;
  /** ISO timestamp UTC — default `new Date().toISOString()`. */
  created_at?: string;
  /** Détails métier (`{reason: '...'}` typiquement). */
  data?: Record<string, unknown>;
}

export interface FakeSuperPdpConfig {
  scenario?: FakeSuperPdpScenario;
  paUserId?: string;
  accessTtlSeconds?: number;
}

export interface FakeConsentArgs {
  scenario: FakeConsentScenario;
  state: string;
  client_id?: string;
  redirect_uri?: string;
  scope?: string;
  code_challenge?: string;
}

export type FakeConsentScenario = "consent_granted" | "consent_denied";

export interface FakeConsentResult {
  code?: string;
  error?: string;
  state: string;
}

export interface FakeSuperPdp {
  readonly baseUrl: string;
  stop(): Promise<void>;
  setScenario(scenario: FakeSuperPdpScenario): void;
  getTokenRequestCount(): number;
  getSubmitRequestCount(): number;
  reset(): void;
  resetTokenRequestCount(): void;
  simulateUserConsent(args: FakeConsentArgs): FakeConsentResult;
  seedDirectorySiren(args: {
    siren: string;
    company: FakeDirectoryCompany;
    entries: FakeDirectoryEntry[];
  }): void;
  setDirectoryUnavailable(unavailable: boolean): void;
  /** T-CL-SIREN-RECONCILIATION sprint-06 W1 — fixe la société retournée
   *  par `GET /v1.beta/companies/me` (source du SIREN attesté KYC). */
  setConnectedCompany(company: FakeConnectedCompany): void;
  /** T-CL-PA-OWN-DIRECTORY-ENTRIES sprint-06 — fixe les entrées annuaire
   *  PROPRES retournées par `GET /v1.beta/directory_entries`. */
  setOwnDirectoryEntries(entries: FakeOwnDirectoryEntry[]): void;
  /** T-CL-PA-INVOICE-FIX sprint-04 — pré-seed une invoice + sa séquence
   *  d'events CDAR. `paInvoiceId` doit être un integer string (ex.
   *  `'42'`) — c'est ce que retournera `POST /v1.beta/invoices` quand
   *  preassigné via `preassignNextPaInvoiceId`. Les events seront
   *  retournés cumulés (avec id auto-séquentiel global) par
   *  `GET /v1.beta/invoice_events`. */
  seedInvoiceWithEvents(args: { paInvoiceId: string; events: FakeInvoiceEvent[] }): void;
  /** Pré-assigne le `id` (integer) retourné par le prochain
   *  `POST /v1.beta/invoices`. */
  preassignNextPaInvoiceId(id: number): void;
  /** Helper webhook V2 — désactivé V1 (route apps/api retourne 503).
   *  Préservé pour ré-activation future. */
  simulateWebhook(args: {
    callbackUrl: string;
    payload: unknown;
    secret: string;
    overrideSignature?: string;
  }): Promise<{ status: number; body: unknown }>;
}

export interface FakeDirectoryEntry {
  identifier: string;
  is_active: boolean;
  is_replyto?: boolean;
}

export interface FakeDirectoryCompany {
  number: string;
  formal_name: string;
  address: string;
  postcode: string;
  city: string;
  country: string;
}

/** T-CL-SIREN-RECONCILIATION sprint-06 W1 — société retournée par
 *  `GET /v1.beta/companies/me` (schéma `company`). Seul `number` est
 *  requis pour piloter la réconciliation ; le reste a des défauts. */
export interface FakeConnectedCompany {
  number: string;
  number_scheme?: string;
  formal_name?: string;
  trade_name?: string | null;
  address?: string | null;
  postcode?: string | null;
  city?: string | null;
  country?: string | null;
}

/** T-CL-PA-OWN-DIRECTORY-ENTRIES sprint-06 — entrée annuaire propre
 *  (`GET /v1.beta/directory_entries`). `status` ∈ pending/created/error. */
export interface FakeOwnDirectoryEntry {
  identifier: string;
  status?: string;
  is_replyto?: boolean;
}

interface InternalInvoiceRecord {
  id: number;
  events: InternalEventRecord[];
  created_at: string;
}

interface InternalEventRecord {
  id: number;
  invoice_id: number;
  status_code: string;
  status_text: string;
  created_at: string;
  data: Record<string, unknown> | null;
}

interface MutableState {
  scenario: FakeSuperPdpScenario;
  tokenRequestCount: number;
  consumedCodes: Set<string>;
  consumedRefresh: Set<string>;
  validRefresh: Set<string>;
  directoryCompanies: Map<string, FakeDirectoryCompany>;
  directoryEntries: Map<string, FakeDirectoryEntry[]>;
  directoryUnavailable: boolean;
  submitRequestCount: number;
  /** Counter global pour `event.id` — sert au cursor Stripe-like. */
  nextEventId: number;
  /** Counter global pour `invoice.id`. */
  nextInvoiceId: number;
  /** Pré-assignment du prochain `invoice.id` par les tests. */
  pendingPreassignedInvoiceId: number | null;
  /** Invoices seedées ou créées via `POST /v1.beta/invoices`. */
  invoices: Map<number, InternalInvoiceRecord>;
  /** Liste globale des events ordered par id croissant — consommée par
   *  `GET /v1.beta/invoice_events` avec cursor `starting_after_id`. */
  globalEvents: InternalEventRecord[];
  /** T-CL-SIREN-RECONCILIATION sprint-06 W1 — société renvoyée par
   *  `GET /v1.beta/companies/me`. `null` = non configurée (défauts du
   *  handler, SIREN vide → réconciliation no-op). */
  connectedCompany: FakeConnectedCompany | null;
  /** T-CL-PA-OWN-DIRECTORY-ENTRIES sprint-06 — entrées annuaire propres
   *  (`GET /v1.beta/directory_entries`). Default vide → not_found. */
  ownDirectoryEntries: FakeOwnDirectoryEntry[];
}

function buildApp(config: Required<FakeSuperPdpConfig>, state: MutableState): FastifyInstance {
  const app = Fastify({ logger: false });

  // OAuth body parser — form-urlencoded.
  app.addContentTypeParser(
    "application/x-www-form-urlencoded",
    { parseAs: "string" },
    (_req, body, done) => {
      try {
        const params = new URLSearchParams(body as string);
        const out: Record<string, string> = {};
        for (const [k, v] of params.entries()) out[k] = v;
        done(null, out);
      } catch (err) {
        done(err as Error, undefined);
      }
    },
  );

  // PDF direct body parser pour POST /v1.beta/invoices.
  app.addContentTypeParser("application/pdf", { parseAs: "buffer" }, (_req, body, done) => {
    done(null, body);
  });

  // Multipart body parser pour POST /v1.beta/validation_reports.
  app.addContentTypeParser("multipart/form-data", { parseAs: "buffer" }, (_req, body, done) => {
    done(null, body);
  });

  // ─── OAuth — préservé sprint-03 ────────────────────────────────────
  app.get<{
    Querystring: {
      client_id?: string;
      redirect_uri?: string;
      state?: string;
      code_challenge?: string;
      code_challenge_method?: string;
    };
  }>("/oauth2/authorize", async (req, reply) => {
    const q = req.query;
    if (q.client_id === undefined || q.redirect_uri === undefined || q.state === undefined) {
      return reply.code(400).send({ error: "invalid_request" });
    }
    if (q.code_challenge_method !== "S256") {
      return reply.code(400).send({ error: "invalid_request", reason: "S256_required" });
    }
    return reply
      .code(200)
      .send({ ok: true, echoed_state: q.state, echoed_challenge: q.code_challenge });
  });

  app.post<{
    Body: {
      grant_type?: string;
      code?: string;
      code_verifier?: string;
      refresh_token?: string;
      redirect_uri?: string;
    };
  }>("/oauth2/token", async (req, reply) => {
    state.tokenRequestCount += 1;

    if (state.scenario === "5xx_then_ok" && state.tokenRequestCount === 1) {
      return reply.code(500).send({ error: "internal_server_error" });
    }

    const body = req.body;
    const grant = body.grant_type;

    if (grant === "authorization_code") {
      const code = body.code;
      if (code === undefined || code === "") {
        return reply.code(400).send({ error: "invalid_request" });
      }
      if (state.consumedCodes.has(code)) {
        return reply.code(400).send({ error: "invalid_grant" });
      }
      if (body.code_verifier === undefined || body.code_verifier === "") {
        return reply.code(400).send({ error: "invalid_request", reason: "code_verifier_required" });
      }
      state.consumedCodes.add(code);
      const refresh = `r-${code}-${String(Date.now())}`;
      state.validRefresh.add(refresh);
      return reply.code(200).send({
        access_token: `a-${code}`,
        refresh_token: refresh,
        token_type: "bearer",
        expires_in: config.accessTtlSeconds,
        scope: "",
      });
    }

    if (grant === "refresh_token") {
      const refresh = body.refresh_token;
      if (refresh === undefined || refresh === "") {
        return reply.code(400).send({ error: "invalid_request" });
      }
      if (state.scenario === "invalid_grant") {
        return reply.code(400).send({
          error: "invalid_grant",
          error_description: "Refresh token is invalid, expired, revoked, etc.",
        });
      }
      if (state.consumedRefresh.has(refresh) || !state.validRefresh.has(refresh)) {
        return reply.code(400).send({ error: "invalid_grant" });
      }
      state.consumedRefresh.add(refresh);
      state.validRefresh.delete(refresh);
      const next = `r-rotated-${String(state.tokenRequestCount)}`;
      state.validRefresh.add(next);
      return reply.code(200).send({
        access_token: `a-rotated-${String(state.tokenRequestCount)}`,
        refresh_token: next,
        token_type: "bearer",
        expires_in: config.accessTtlSeconds,
        scope: "",
      });
    }

    return reply.code(400).send({ error: "unsupported_grant_type" });
  });

  app.post("/oauth2/revoke", async (_req, reply) => reply.code(200).send({}));

  // ─── Annuaire — T-CL-09 sprint-03 préservé ─────────────────────────
  app.get<{ Querystring: { number?: string } }>(
    "/v1.beta/french_directory/companies",
    async (req, reply) => {
      if (state.directoryUnavailable) {
        return reply.code(503).send({ error: "service_unavailable" });
      }
      const siren = req.query.number;
      if (typeof siren !== "string" || siren === "") {
        return reply.code(400).send({ error: "invalid_request", reason: "number_required" });
      }
      const company = state.directoryCompanies.get(siren);
      return reply
        .code(200)
        .send({ data: company === undefined ? [] : [company], has_more: false });
    },
  );

  app.get<{ Querystring: { number?: string } }>(
    "/v1.beta/french_directory/entries",
    async (req, reply) => {
      if (state.directoryUnavailable) {
        return reply.code(503).send({ error: "service_unavailable" });
      }
      const siren = req.query.number;
      if (typeof siren !== "string" || siren === "") {
        return reply.code(400).send({ error: "invalid_request", reason: "number_required" });
      }
      const entries = state.directoryEntries.get(siren) ?? [];
      return reply.code(200).send({
        data: entries.map((e) => ({
          identifier: e.identifier,
          is_active: e.is_active,
          is_replyto: e.is_replyto === true,
          company: state.directoryCompanies.get(siren) ?? null,
        })),
        has_more: false,
      });
    },
  );

  // ─── Pipeline facture — refactor T-CL-PA-INVOICE-FIX ───────────────

  /** POST /v1.beta/invoices : dépôt facture body application/pdf direct.
   *  Query params `external_id` (UUID idempotence) + `disable_pre_check`
   *  (bool, ADR-010 v2 D6). Retourne `{id, events, created_at}` schema
   *  `invoice` SuperPDP. Format erreur `{http_status_code, message}`. */
  app.post<{ Querystring: { external_id?: string; disable_pre_check?: string } }>(
    "/v1.beta/invoices",
    async (req, reply) => {
      state.submitRequestCount += 1;
      const auth = req.headers.authorization;
      if (typeof auth !== "string" || !auth.startsWith("Bearer ")) {
        return reply.code(401).send({ http_status_code: 401, message: "Unauthorized" });
      }
      const contentType = req.headers["content-type"] ?? "";
      if (!contentType.startsWith("application/pdf")) {
        return reply
          .code(400)
          .send({ http_status_code: 400, message: "Content-Type must be application/pdf" });
      }

      // Scenarios de test (cf. ADR-010 v2 D5 — format erreur SuperPDP).
      if (state.scenario === "submit_401_token_expired") {
        return reply.code(401).send({ http_status_code: 401, message: "Token expiré" });
      }
      if (state.scenario === "submit_403_forbidden") {
        return reply.code(403).send({ http_status_code: 403, message: "Compte non vérifié" });
      }
      if (state.scenario === "submit_400_seller_address") {
        return reply.code(400).send({
          http_status_code: 400,
          message: "L'adresse electronique du vendeur est manquante (Seller.ElectronicAddress)",
        });
      }
      if (state.scenario === "submit_4xx_xsd") {
        return reply
          .code(422)
          .send({ http_status_code: 422, message: "BT-1 missing in CrossIndustryInvoice" });
      }
      if (state.scenario === "submit_429_rate_limit") {
        return reply
          .code(429)
          .header("retry-after", "30")
          .send({ http_status_code: 429, message: "Rate limit" });
      }
      if (state.scenario === "submit_5xx_then_ok" && state.submitRequestCount === 1) {
        return reply.code(500).send({ http_status_code: 500, message: "Internal server error" });
      }

      // Happy path — créer une invoice + event initial `api:uploaded`.
      const invoiceId = state.pendingPreassignedInvoiceId ?? state.nextInvoiceId++;
      state.pendingPreassignedInvoiceId = null;
      if (invoiceId >= state.nextInvoiceId) {
        state.nextInvoiceId = invoiceId + 1;
      }
      const createdAt = new Date().toISOString();
      const initialEvent: InternalEventRecord = {
        id: state.nextEventId++,
        invoice_id: invoiceId,
        status_code: "api:uploaded",
        status_text: "Déposée",
        created_at: createdAt,
        data: null,
      };
      const invoice: InternalInvoiceRecord = {
        id: invoiceId,
        events: [initialEvent],
        created_at: createdAt,
      };
      state.invoices.set(invoiceId, invoice);
      state.globalEvents.push(initialEvent);

      return reply.code(200).send({
        id: invoiceId,
        events: invoice.events,
        created_at: createdAt,
      });
    },
  );

  /** GET /v1.beta/invoice_events?starting_after_id=&limit= — cursor
   *  Stripe-like. Retourne `{data, has_after}`. */
  app.get<{ Querystring: { starting_after_id?: string; limit?: string } }>(
    "/v1.beta/invoice_events",
    async (req, reply) => {
      const auth = req.headers.authorization;
      if (typeof auth !== "string" || !auth.startsWith("Bearer ")) {
        return reply.code(401).send({ http_status_code: 401, message: "Unauthorized" });
      }
      const cursor = Number.parseInt(req.query.starting_after_id ?? "0", 10);
      const limit = Math.min(Number.parseInt(req.query.limit ?? "100", 10), 1000);
      const after = state.globalEvents.filter((e) => e.id > cursor);
      const page = after.slice(0, limit);
      const hasAfter = after.length > page.length;
      return reply.code(200).send({ data: page, has_after: hasAfter });
    },
  );

  /** POST /v1.beta/validation_reports (multipart) — retourne un report
   *  minimal happy path (`is_valid: true`). Tests qui veulent éprouver
   *  un report KO devraient utiliser un scenario dédié (V2). */
  app.post("/v1.beta/validation_reports", async (req, reply) => {
    const auth = req.headers.authorization;
    if (typeof auth !== "string" || !auth.startsWith("Bearer ")) {
      return reply.code(401).send({ http_status_code: 401, message: "Unauthorized" });
    }
    return reply.code(200).send({
      data: [
        {
          file_name: "invoice.pdf",
          file_size: 1024,
          is_valid: true,
          duration: 42,
          format: "urn:cen.eu:en16931:2017",
          conformance_level: "EXTENDED",
          subreports: [],
        },
      ],
    });
  });

  // ─── Identity — T-CL-08 sprint-03 préservé ─────────────────────────
  app.get("/v1.beta/oauth2_sessions/me", async (req, reply) => {
    const auth = req.headers.authorization;
    if (typeof auth !== "string" || !auth.startsWith("Bearer ")) {
      return reply.code(401).send({ http_status_code: 401, message: "Unauthorized" });
    }
    const userStatus =
      state.scenario === "needs_review"
        ? "needs_review"
        : state.scenario === "rejected"
          ? "rejected"
          : "verified";
    const companyStatus = state.scenario === "rejected" ? "rejected" : "verified";
    // Schéma réel `oauth2_session` (swagger v1.21.1.beta) : pas de SIREN.
    return reply.code(200).send({
      client_id: "fake-client-id",
      created_at: new Date().toISOString(),
      user_identity_verification_status: userStatus,
      company_verification_status: companyStatus,
    });
  });

  // ─── Company — T-CL-SIREN-RECONCILIATION sprint-06 W1 ──────────────
  // `GET /v1.beta/companies/me` — société rattachée au token (schéma
  // `company`). Source du SIREN attesté KYC pour la réconciliation.
  app.get("/v1.beta/companies/me", async (req, reply) => {
    const auth = req.headers.authorization;
    if (typeof auth !== "string" || !auth.startsWith("Bearer ")) {
      return reply.code(401).send({ http_status_code: 401, message: "Unauthorized" });
    }
    const c = state.connectedCompany;
    return reply.code(200).send({
      id: 1,
      created_at: new Date().toISOString(),
      env: "sandbox",
      number: c?.number ?? "",
      number_scheme: c?.number_scheme ?? "siren",
      formal_name: c?.formal_name ?? "Société Test",
      trade_name: c?.trade_name ?? "Société Test",
      address: c?.address ?? "1 rue de Test",
      postcode: c?.postcode ?? "75001",
      city: c?.city ?? "Paris",
      country: c?.country ?? "FR",
    });
  });

  // ─── Own directory entries — T-CL-PA-OWN-DIRECTORY-ENTRIES sprint-06 ──
  // `GET /v1.beta/directory_entries` — adresses Peppol PROPRES du compte
  // (authentifié). Source de l'adresse émetteur (vs french_directory public).
  app.get("/v1.beta/directory_entries", async (req, reply) => {
    const auth = req.headers.authorization;
    if (typeof auth !== "string" || !auth.startsWith("Bearer ")) {
      return reply.code(401).send({ http_status_code: 401, message: "Unauthorized" });
    }
    const data = state.ownDirectoryEntries.map((e, i) => ({
      id: i + 1,
      identifier: e.identifier,
      status: e.status ?? "created",
      is_replyto: e.is_replyto ?? false,
      created_at: new Date().toISOString(),
    }));
    return reply.code(200).send({ data });
  });

  return app;
}

/** Spin up the fake on a random free port. Returns a handle for tests. */
export async function startFakeSuperPdp(config: FakeSuperPdpConfig = {}): Promise<FakeSuperPdp> {
  const cfg: Required<FakeSuperPdpConfig> = {
    scenario: config.scenario ?? "verified",
    paUserId: config.paUserId ?? "pa-user-fixture",
    accessTtlSeconds: config.accessTtlSeconds ?? 1800,
  };
  const state: MutableState = {
    scenario: cfg.scenario,
    tokenRequestCount: 0,
    consumedCodes: new Set(),
    consumedRefresh: new Set(),
    validRefresh: new Set(),
    directoryCompanies: new Map(),
    directoryEntries: new Map(),
    directoryUnavailable: false,
    submitRequestCount: 0,
    nextEventId: 1,
    nextInvoiceId: 1,
    pendingPreassignedInvoiceId: null,
    invoices: new Map(),
    globalEvents: [],
    connectedCompany: null,
    ownDirectoryEntries: [],
  };
  const app = buildApp(cfg, state);
  await app.listen({ port: 0, host: "127.0.0.1" });
  const addr: AddressInfo | string | null = app.server.address();
  if (addr === null || typeof addr === "string") {
    await app.close();
    throw new Error("[fakeSuperPdp] expected AddressInfo from server.address()");
  }
  const baseUrl = `http://127.0.0.1:${String(addr.port)}`;

  return {
    baseUrl,
    async stop(): Promise<void> {
      await app.close();
    },
    setScenario(scenario: FakeSuperPdpScenario): void {
      state.scenario = scenario;
    },
    getTokenRequestCount(): number {
      return state.tokenRequestCount;
    },
    getSubmitRequestCount(): number {
      return state.submitRequestCount;
    },
    reset(): void {
      state.tokenRequestCount = 0;
      state.consumedCodes.clear();
      state.consumedRefresh.clear();
      state.validRefresh.clear();
      state.directoryCompanies.clear();
      state.directoryEntries.clear();
      state.directoryUnavailable = false;
      state.submitRequestCount = 0;
      state.nextEventId = 1;
      state.nextInvoiceId = 1;
      state.pendingPreassignedInvoiceId = null;
      state.invoices.clear();
      state.globalEvents = [];
      state.connectedCompany = null;
      state.ownDirectoryEntries = [];
    },
    seedDirectorySiren(args): void {
      state.directoryCompanies.set(args.siren, args.company);
      state.directoryEntries.set(args.siren, args.entries);
    },
    setDirectoryUnavailable(unavailable: boolean): void {
      state.directoryUnavailable = unavailable;
    },
    setConnectedCompany(company: FakeConnectedCompany): void {
      state.connectedCompany = company;
    },
    setOwnDirectoryEntries(entries: FakeOwnDirectoryEntry[]): void {
      state.ownDirectoryEntries = entries;
    },
    resetTokenRequestCount(): void {
      state.tokenRequestCount = 0;
    },
    simulateUserConsent(args: FakeConsentArgs): FakeConsentResult {
      if (args.scenario === "consent_denied") {
        return { error: "access_denied", state: args.state };
      }
      const code = `c-${args.state.slice(0, 8)}-${String(Date.now())}`;
      return { code, state: args.state };
    },
    seedInvoiceWithEvents(args): void {
      const invoiceId = Number.parseInt(args.paInvoiceId, 10);
      if (!Number.isFinite(invoiceId)) {
        throw new Error(
          `[fakeSuperPdp] seedInvoiceWithEvents: paInvoiceId must be a numeric string, got '${args.paInvoiceId}'.`,
        );
      }
      const events: InternalEventRecord[] = args.events.map((e) => ({
        id: e.id ?? state.nextEventId++,
        invoice_id: e.invoice_id ?? invoiceId,
        status_code: e.status_code,
        status_text: e.status_text ?? e.status_code,
        created_at: e.created_at ?? new Date().toISOString(),
        data: e.data ?? null,
      }));
      // Maintenir nextEventId au-dessus des ids seedés.
      for (const ev of events) {
        if (ev.id >= state.nextEventId) state.nextEventId = ev.id + 1;
      }
      state.invoices.set(invoiceId, {
        id: invoiceId,
        events,
        created_at: events[0]?.created_at ?? new Date().toISOString(),
      });
      state.globalEvents.push(...events);
      // Garantir ordering croissant par id pour le cursor.
      state.globalEvents.sort((a, b) => a.id - b.id);
    },
    preassignNextPaInvoiceId(id: number): void {
      state.pendingPreassignedInvoiceId = id;
      if (id >= state.nextInvoiceId) state.nextInvoiceId = id + 1;
    },
    async simulateWebhook(args): Promise<{ status: number; body: unknown }> {
      // V1 webhook désactivé côté apps/api (route retourne 503). Helper
      // préservé pour ré-activation V2 — utile aux tests qui veulent
      // éprouver le scénario d'une PA qui pousserait quand même.
      const payloadStr = JSON.stringify(args.payload);
      const payloadBuf = Buffer.from(payloadStr, "utf8");
      const signature =
        args.overrideSignature ??
        `sha256=${createHmac("sha256", args.secret).update(payloadBuf).digest("hex")}`;
      const res = await fetch(args.callbackUrl, {
        method: "POST",
        headers: {
          "content-type": "application/json",
          "x-superpdp-signature": signature,
        },
        body: payloadStr,
      });
      const text = await res.text();
      let body: unknown;
      try {
        body = JSON.parse(text) as unknown;
      } catch {
        body = text;
      }
      return { status: res.status, body };
    },
  };
}
