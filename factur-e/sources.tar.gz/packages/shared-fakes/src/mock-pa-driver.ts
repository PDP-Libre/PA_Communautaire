import {
  mapSuperPDPStatusCode,
  RefreshExpiredException,
  verifyWebhookSignature,
  type AuthorizeArgs,
  type AuthorizeChallenge,
  type CdarEvent,
  type CreateInvoiceEventInput,
  type CreateInvoiceEventOutput,
  type CustomerContext,
  type DirectorySearchResult,
  type ConnectedCompany,
  type DownloadInvoiceFileInput,
  type DownloadInvoiceFileResult,
  type ExchangeCodeArgs,
  type GetConnectedCompanyArgs,
  type GetOwnDirectoryEntriesArgs,
  type GetIdentityStatusArgs,
  type IdentityStatus,
  type IdentityStatusSnapshot,
  type IncomingInvoice,
  type ListIncomingInvoicesInput,
  type ListIncomingInvoicesOutput,
  type PADriver,
  type PaCustomerSnapshot,
  type PaTokens,
  type PollCdarEventsInput,
  type PollCdarEventsOutput,
  type RefreshTokenArgs,
  type RevokeArgs,
  type SearchSirenArgs,
  type SubmitInvoiceInput,
  type SubmitInvoiceOutput,
  type VerifyWebhookSignatureArgs,
} from "@factur-e/pa-adapter";

/**
 * `MockPADriver` — implémentation `PADriverWebOnboarding` (= `PADriver`)
 * in-process pour les tests côté `apps/api`. Refondue T-CL-PA-INVOICE-FIX
 * sprint-04 (ADR-012 D1) pour matcher la nouvelle interface 3
 * sous-interfaces composées.
 *
 * Distinct de `fakeSuperPdp` (HTTP server) :
 *   - **`fakeSuperPdp`** : teste `SuperPDPDriver` (parsing HTTP, retry,
 *     mapping endpoints réels `/v1.beta/invoices` + `/v1.beta/invoice_events`).
 *   - **`MockPADriver`** : teste les **callers du driver** (routes
 *     `/oauth/*`, job `poll-cdar-events`, `submitInvoice` route).
 *     Pas de réseau, in-process.
 *
 * **Compat sprint-03 préservée** (contrainte Bruno) :
 *  - Compteurs `counts.{authorize, exchange, refresh, revoke, getIdentity, searchSiren, submitInvoice, pollCdarEvents}`.
 *  - Setters `setScenario`, `setIdentityStatus`, `setPaUserId`,
 *    `setSearchSirenOutcome`, `setSubmitInvoiceFailure`,
 *    `preassignNextPaInvoiceId`, `seedPollCdarEventsBatch`.
 *  - `verifyWebhookSignature` conservé comme méthode bonus (pas dans
 *    l'interface — endpoint webhook désactivé V1 mais helper réactivable
 *    V2).
 */

export type MockPaDriverScenario = "verified" | "needs_review" | "rejected" | "refresh_expired";

export interface MockPaDriverConfig {
  scenario?: MockPaDriverScenario;
  paUserId?: string;
  identityUserStatus?: IdentityStatus;
  identityCompanyStatus?: IdentityStatus;
  latencyMs?: number;
}

interface State {
  scenario: MockPaDriverScenario;
  paUserId: string;
  identityUserStatus: IdentityStatus | null;
  identityCompanyStatus: IdentityStatus | null;
  /** T-CL-SIREN-RECONCILIATION sprint-06 W1 — société connectée retournée
   *  par `getConnectedCompany` (`companies/me`). `null` = non configurée
   *  (réconciliation no-op). */
  connectedCompany: ConnectedCompany | null;
  /** T-CL-PA-OWN-DIRECTORY-ENTRIES sprint-06 — résultat de
   *  `getOwnDirectoryEntries` (`directory_entries` propres). Default
   *  `not_found`. */
  ownDirectoryResult: DirectorySearchResult;
  latencyMs: number;
  authorizeCount: number;
  exchangeCount: number;
  refreshCount: number;
  revokeCount: number;
  getIdentityCount: number;
  searchSirenCount: number;
  searchSirenOutcomes: Map<string, DirectorySearchResult>;
  submitInvoiceCount: number;
  pollCdarEventsCount: number;
  submitInvoiceFailure: Error | null;
  nextPaInvoiceId: string | null;
  /** Queue d'outputs `pollCdarEvents` consommés en FIFO par les tests.
   *  Si la queue est vide → retourne `{events: [], nextCursor: input.cursor, hasMore: false}`. */
  pollOutputs: PollCdarEventsOutput[];
  verifyWebhookSignatureOutcome: boolean;
  // Réception — T-CL-RECV-API sprint-05 W2.
  listIncomingInvoicesCount: number;
  createInvoiceEventCount: number;
  /** Queue FIFO d'outputs `listIncomingInvoices`. Vide → batch vide. */
  incomingOutputs: ListIncomingInvoicesOutput[];
  /** Exception pré-configurée levée par `listIncomingInvoices`. */
  listIncomingFailure: Error | null;
  /** Exception pré-configurée levée par `createInvoiceEvent`. */
  createInvoiceEventFailure: Error | null;
  downloadInvoiceFileCount: number;
  /** Résultat pré-configuré de `downloadInvoiceFile` (default PDF stub). */
  downloadResult: DownloadInvoiceFileResult;
  /** Exception pré-configurée levée par `downloadInvoiceFile`. */
  downloadFailure: Error | null;
}

/** Résultat download par défaut — petit PDF stub (header `%PDF-1.4`). */
const DEFAULT_DOWNLOAD_RESULT: DownloadInvoiceFileResult = {
  bytes: Buffer.from("%PDF-1.4\n% mock factur-x\n"),
  contentType: "application/pdf",
};

function statusesForScenario(scenario: MockPaDriverScenario): {
  user: IdentityStatus;
  company: IdentityStatus;
} {
  switch (scenario) {
    case "needs_review":
      return { user: "needs_review", company: "verified" };
    case "rejected":
      return { user: "rejected", company: "rejected" };
    case "verified":
    case "refresh_expired":
      return { user: "verified", company: "verified" };
  }
}

const sleep = (ms: number): Promise<void> =>
  ms > 0 ? new Promise<void>((resolve) => setTimeout(resolve, ms)) : Promise.resolve();

export class MockPADriver implements PADriver {
  readonly providerId = "superpdp" as const;
  readonly onboardingMode = "web-authorization-code" as const;

  private readonly state: State;

  constructor(config: MockPaDriverConfig = {}) {
    this.state = {
      scenario: config.scenario ?? "verified",
      paUserId: config.paUserId ?? "pa-user-mock",
      identityUserStatus: config.identityUserStatus ?? null,
      identityCompanyStatus: config.identityCompanyStatus ?? null,
      connectedCompany: null,
      ownDirectoryResult: { kind: "not_found" },
      latencyMs: config.latencyMs ?? 0,
      authorizeCount: 0,
      exchangeCount: 0,
      refreshCount: 0,
      revokeCount: 0,
      getIdentityCount: 0,
      searchSirenCount: 0,
      searchSirenOutcomes: new Map(),
      submitInvoiceCount: 0,
      pollCdarEventsCount: 0,
      submitInvoiceFailure: null,
      nextPaInvoiceId: null,
      pollOutputs: [],
      verifyWebhookSignatureOutcome: true,
      listIncomingInvoicesCount: 0,
      createInvoiceEventCount: 0,
      incomingOutputs: [],
      listIncomingFailure: null,
      createInvoiceEventFailure: null,
      downloadInvoiceFileCount: 0,
      downloadResult: DEFAULT_DOWNLOAD_RESULT,
      downloadFailure: null,
    };
  }

  setScenario(scenario: MockPaDriverScenario): void {
    this.state.scenario = scenario;
  }

  setIdentityStatus(args: { user?: IdentityStatus; company?: IdentityStatus }): void {
    if (args.user !== undefined) this.state.identityUserStatus = args.user;
    if (args.company !== undefined) this.state.identityCompanyStatus = args.company;
  }

  /** T-CL-SIREN-RECONCILIATION sprint-06 W1 — fixe la société retournée
   *  par `getConnectedCompany` (`companies/me`). `number` suffit pour les
   *  tests de réconciliation ; le SIREN est dérivé comme le vrai driver
   *  (SIRET 14 → 9 premiers, SIREN 9 → tel quel) sauf override `siren`. */
  setConnectedCompany(args: {
    number: string;
    numberScheme?: string;
    siren?: string | null;
    formalName?: string;
    tradeName?: string | null;
    address?: ConnectedCompany["address"];
  }): void {
    const digits = args.number.replace(/\D/g, "");
    const derived = digits.length === 9 ? digits : digits.length === 14 ? digits.slice(0, 9) : null;
    this.state.connectedCompany = {
      siren: args.siren !== undefined ? args.siren : derived,
      number: args.number,
      numberScheme: args.numberScheme ?? "siren",
      formalName: args.formalName ?? "Société Test",
      tradeName: args.tradeName ?? null,
      address: args.address ?? null,
    };
  }

  /** T-CL-PA-OWN-DIRECTORY-ENTRIES sprint-06 — fixe le résultat de
   *  `getOwnDirectoryEntries`. */
  setOwnDirectoryEntries(result: DirectorySearchResult): void {
    this.state.ownDirectoryResult = result;
  }

  /** Convénience — une adresse Peppol propre unique (`found_one_address`). */
  setOwnPeppolAddress(partyId: string): void {
    this.state.ownDirectoryResult = {
      kind: "found_one_address",
      company: { number: "", formal_name: "", address: "", postcode: "", city: "", country: "" },
      address: {
        party_id: partyId,
        scheme_id: partyId.includes(":") ? (partyId.split(":")[0] ?? "") : "",
        is_active: true,
        pa_name: null,
      },
    };
  }

  setPaUserId(id: string): void {
    this.state.paUserId = id;
  }

  /** T-CL-09 sprint-03 — pré-charge l'outcome retourné par
   *  `searchSiren(siren)`. */
  setSearchSirenOutcome(siren: string, outcome: DirectorySearchResult): void {
    this.state.searchSirenOutcomes.set(siren, outcome);
  }

  reset(): void {
    this.state.authorizeCount = 0;
    this.state.exchangeCount = 0;
    this.state.refreshCount = 0;
    this.state.revokeCount = 0;
    this.state.getIdentityCount = 0;
    this.state.connectedCompany = null;
    this.state.ownDirectoryResult = { kind: "not_found" };
    this.state.searchSirenCount = 0;
    this.state.searchSirenOutcomes.clear();
    this.state.submitInvoiceCount = 0;
    this.state.pollCdarEventsCount = 0;
    this.state.submitInvoiceFailure = null;
    this.state.nextPaInvoiceId = null;
    this.state.pollOutputs = [];
    this.state.verifyWebhookSignatureOutcome = true;
    this.state.listIncomingInvoicesCount = 0;
    this.state.createInvoiceEventCount = 0;
    this.state.incomingOutputs = [];
    this.state.listIncomingFailure = null;
    this.state.createInvoiceEventFailure = null;
    this.state.downloadInvoiceFileCount = 0;
    this.state.downloadResult = DEFAULT_DOWNLOAD_RESULT;
    this.state.downloadFailure = null;
  }

  // ── Réception — seeding helpers (T-CL-RECV-API sprint-05 W2) ──────────

  /** Pré-seed un batch d'output `listIncomingInvoices` (FIFO). */
  seedIncomingInvoicesBatch(output: ListIncomingInvoicesOutput): void {
    this.state.incomingOutputs.push(output);
  }

  /** Convénience — convertit une liste de factures entrantes en un batch
   *  unique (`nextCursor` = id de la dernière, `hasMore` false). */
  seedIncomingInvoices(invoices: readonly IncomingInvoice[]): void {
    const last = invoices[invoices.length - 1];
    const nextCursor = last !== undefined ? last.paInvoiceId : "0";
    this.state.incomingOutputs.push({ invoices, nextCursor, hasMore: false });
  }

  /** Pré-configure une exception levée par `listIncomingInvoices`. */
  setListIncomingFailure(err: Error | null): void {
    this.state.listIncomingFailure = err;
  }

  /** Pré-configure une exception levée par `createInvoiceEvent`. */
  setCreateInvoiceEventFailure(err: Error | null): void {
    this.state.createInvoiceEventFailure = err;
  }

  /** Pré-configure le résultat de `downloadInvoiceFile` (PDF ou XML). */
  setDownloadInvoiceFileResult(result: DownloadInvoiceFileResult): void {
    this.state.downloadResult = result;
  }

  /** Pré-configure une exception levée par `downloadInvoiceFile`. */
  setDownloadInvoiceFileFailure(err: Error | null): void {
    this.state.downloadFailure = err;
  }

  /** Pré-configure une exception levée par `submitInvoice`. */
  setSubmitInvoiceFailure(err: Error | null): void {
    this.state.submitInvoiceFailure = err;
  }

  /** Pré-assigne le `paInvoiceId` retourné par le prochain `submitInvoice`.
   *  (Remplace `preassignNextFlowId` sprint-03 — rename T-CL-PA-INVOICE-FIX). */
  preassignNextPaInvoiceId(paInvoiceId: string): void {
    this.state.nextPaInvoiceId = paInvoiceId;
  }

  /** Pré-seed un batch d'output `pollCdarEvents` — chaque appel consomme
   *  le 1er batch de la queue FIFO. Si la queue est vide → retour vide
   *  (`{events: [], nextCursor: input.cursor, hasMore: false}`). */
  seedPollCdarEventsBatch(output: PollCdarEventsOutput): void {
    this.state.pollOutputs.push(output);
  }

  /** Helper de convénience — convertit une liste d'events vers un batch
   *  unique avec `nextCursor` = ID du dernier event (ou cursor inchangé
   *  si vide). Évite la verbosité côté tests qui veulent juste injecter
   *  une séquence d'events. */
  seedCdarEvents(events: readonly CdarEvent[]): void {
    const last = events[events.length - 1];
    const nextCursor = last !== undefined ? last.paEventId : "0";
    this.state.pollOutputs.push({ events, nextCursor, hasMore: false });
  }

  /** Force le résultat de `verifyWebhookSignature` (par défaut true). */
  setVerifyWebhookSignatureOutcome(outcome: boolean): void {
    this.state.verifyWebhookSignatureOutcome = outcome;
  }

  /** Read-only counters — for test assertions. */
  get counts(): {
    authorize: number;
    exchange: number;
    refresh: number;
    revoke: number;
    getIdentity: number;
    searchSiren: number;
    submitInvoice: number;
    pollCdarEvents: number;
    listIncomingInvoices: number;
    createInvoiceEvent: number;
  } {
    return {
      authorize: this.state.authorizeCount,
      exchange: this.state.exchangeCount,
      refresh: this.state.refreshCount,
      revoke: this.state.revokeCount,
      getIdentity: this.state.getIdentityCount,
      searchSiren: this.state.searchSirenCount,
      submitInvoice: this.state.submitInvoiceCount,
      pollCdarEvents: this.state.pollCdarEventsCount,
      listIncomingInvoices: this.state.listIncomingInvoicesCount,
      createInvoiceEvent: this.state.createInvoiceEventCount,
    };
  }

  // ───────────────────────────────────────────────────────────────────
  // PADriverCore
  // ───────────────────────────────────────────────────────────────────

  healthcheck(): Promise<boolean> {
    return Promise.resolve(true);
  }

  async submitInvoice(
    _input: SubmitInvoiceInput,
    _ctx: CustomerContext,
  ): Promise<SubmitInvoiceOutput> {
    this.state.submitInvoiceCount += 1;
    await sleep(this.state.latencyMs);
    if (this.state.submitInvoiceFailure !== null) {
      throw this.state.submitInvoiceFailure;
    }
    const paInvoiceId =
      this.state.nextPaInvoiceId ?? `mock-invoice-${String(this.state.submitInvoiceCount)}`;
    this.state.nextPaInvoiceId = null;
    return {
      paInvoiceId,
      status: "submitted",
      rawStatusCode: "api:uploaded",
      submittedAt: new Date(),
    };
  }

  async pollCdarEvents(
    input: PollCdarEventsInput,
    _ctx: CustomerContext,
  ): Promise<PollCdarEventsOutput> {
    this.state.pollCdarEventsCount += 1;
    await sleep(this.state.latencyMs);
    const next = this.state.pollOutputs.shift();
    if (next === undefined) {
      return { events: [], nextCursor: input.cursor, hasMore: false };
    }
    return next;
  }

  async searchSiren(args: SearchSirenArgs, _ctx: CustomerContext): Promise<DirectorySearchResult> {
    this.state.searchSirenCount += 1;
    await sleep(this.state.latencyMs);
    return this.state.searchSirenOutcomes.get(args.siren) ?? { kind: "not_found" };
  }

  async listIncomingInvoices(
    input: ListIncomingInvoicesInput,
    _ctx: CustomerContext,
  ): Promise<ListIncomingInvoicesOutput> {
    this.state.listIncomingInvoicesCount += 1;
    await sleep(this.state.latencyMs);
    if (this.state.listIncomingFailure !== null) {
      throw this.state.listIncomingFailure;
    }
    const next = this.state.incomingOutputs.shift();
    if (next === undefined) {
      return { invoices: [], nextCursor: input.cursor, hasMore: false };
    }
    return next;
  }

  async createInvoiceEvent(
    input: CreateInvoiceEventInput,
    _ctx: CustomerContext,
  ): Promise<CreateInvoiceEventOutput> {
    this.state.createInvoiceEventCount += 1;
    await sleep(this.state.latencyMs);
    if (this.state.createInvoiceEventFailure !== null) {
      throw this.state.createInvoiceEventFailure;
    }
    const mapped = mapSuperPDPStatusCode(input.statusCode);
    return {
      paEventId: `mock-event-${String(this.state.createInvoiceEventCount)}`,
      rawStatusCode: input.statusCode,
      status: mapped.status,
      occurredAt: new Date().toISOString(),
    };
  }

  async downloadInvoiceFile(
    _input: DownloadInvoiceFileInput,
    _ctx: CustomerContext,
  ): Promise<DownloadInvoiceFileResult> {
    this.state.downloadInvoiceFileCount += 1;
    await sleep(this.state.latencyMs);
    if (this.state.downloadFailure !== null) {
      throw this.state.downloadFailure;
    }
    return this.state.downloadResult;
  }

  /** T-CL-PA-DIRECTORY-PEPPOL sprint-05 — délégation à `searchSiren` mock
   *  (même outcome map). Tests d'intégration `oauth-callback-with-peppol-*`
   *  seedent via `seedSearchSirenOutcome(siren, result)`. */
  async fetchOwnPeppolAddresses(siren: string): Promise<DirectorySearchResult> {
    const dummyCtx: CustomerContext = {
      customerId: "mock-self-lookup",
      credentials: {
        kind: "superpdp-oauth-cc",
        accessToken: "",
        accessExpiresAt: new Date(0),
      },
    };
    return await this.searchSiren({ siren }, dummyCtx);
  }

  getCustomerSnapshot(_ctx: CustomerContext): Promise<PaCustomerSnapshot> {
    const fromScenario = statusesForScenario(this.state.scenario);
    return Promise.resolve({
      provider: "superpdp",
      identity: {
        paUserId: this.state.paUserId,
        user: this.state.identityUserStatus ?? fromScenario.user,
        company: this.state.identityCompanyStatus ?? fromScenario.company,
      },
    });
  }

  // ───────────────────────────────────────────────────────────────────
  // PADriverWebOnboarding (OAuth — sprint-03)
  // ───────────────────────────────────────────────────────────────────

  async authorize(args: AuthorizeArgs): Promise<AuthorizeChallenge> {
    this.state.authorizeCount += 1;
    await sleep(this.state.latencyMs);
    const id = this.state.authorizeCount;
    return {
      authorizeUrl: `https://mock-superpdp.test/oauth2/authorize?client_id=mock&state=mock-state-${String(id)}&customer=${args.customerId}`,
      state: `mock-state-${String(id)}`,
      codeVerifier: `mock-verifier-${String(id)}`,
    };
  }

  async exchangeCode(args: ExchangeCodeArgs): Promise<PaTokens> {
    this.state.exchangeCount += 1;
    await sleep(this.state.latencyMs);
    if (args.state !== args.expectedState) {
      throw new Error("Mock exchangeCode: state mismatch (caller should validate before).");
    }
    const id = this.state.exchangeCount;
    return {
      accessToken: `mock-access-${String(id)}`,
      refreshToken: `mock-refresh-${String(id)}`,
      accessExpiresAt: new Date(Date.now() + 1800 * 1000),
      paUserId: this.state.paUserId,
    };
  }

  async refreshToken(_args: RefreshTokenArgs): Promise<PaTokens> {
    this.state.refreshCount += 1;
    await sleep(this.state.latencyMs);
    if (this.state.scenario === "refresh_expired") {
      throw new RefreshExpiredException();
    }
    const id = this.state.refreshCount;
    return {
      accessToken: `mock-access-r${String(id)}`,
      refreshToken: `mock-refresh-r${String(id)}`,
      accessExpiresAt: new Date(Date.now() + 1800 * 1000),
      paUserId: null,
    };
  }

  async revoke(_args: RevokeArgs): Promise<void> {
    this.state.revokeCount += 1;
    await sleep(this.state.latencyMs);
  }

  async getIdentityStatus(_args: GetIdentityStatusArgs): Promise<IdentityStatusSnapshot> {
    this.state.getIdentityCount += 1;
    await sleep(this.state.latencyMs);
    const fromScenario = statusesForScenario(this.state.scenario);
    return {
      paUserId: this.state.paUserId,
      user: this.state.identityUserStatus ?? fromScenario.user,
      company: this.state.identityCompanyStatus ?? fromScenario.company,
    };
  }

  async getConnectedCompany(_args: GetConnectedCompanyArgs): Promise<ConnectedCompany> {
    await sleep(this.state.latencyMs);
    // Non configurée → société "vide" SIREN null → réconciliation no-op
    // (fail-safe). Les tests de réconciliation appellent
    // `setConnectedCompany(...)` au préalable.
    return (
      this.state.connectedCompany ?? {
        siren: null,
        number: "",
        numberScheme: "",
        formalName: "",
        tradeName: null,
        address: null,
      }
    );
  }

  async getOwnDirectoryEntries(_args: GetOwnDirectoryEntriesArgs): Promise<DirectorySearchResult> {
    await sleep(this.state.latencyMs);
    return this.state.ownDirectoryResult;
  }

  // ───────────────────────────────────────────────────────────────────
  // Méthode bonus (pas dans PADriverWebOnboarding) — préservée pour les
  // tests sprint-03 qui pilotent le scénario `signature KO`. Endpoint
  // webhook désactivé V1, mais helper réactivable V2.
  // ───────────────────────────────────────────────────────────────────

  verifyWebhookSignature(args: VerifyWebhookSignatureArgs): boolean {
    if (!this.state.verifyWebhookSignatureOutcome) return false;
    return verifyWebhookSignature(args);
  }
}
