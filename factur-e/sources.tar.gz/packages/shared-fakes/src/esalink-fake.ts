import { Buffer } from "node:buffer";
import { createHmac } from "node:crypto";
import type { AddressInfo } from "node:net";

import Fastify, { type FastifyInstance } from "fastify";

/**
 * `fakeHubtimize` — serveur HTTP Fastify qui imite l'API EsaLink
 * (Hubtimize anonymisé) pour les tests d'intégration `EsaLinkDriver`
 * (T-CL-PA-INVOICE-FIX sprint-04, ADR-011).
 *
 * **V1 partiel** : mocks pour les 3 méthodes implémentées V1 +
 * validation du header firewall `hubtimize-api-key` (ADR-011 D4).
 *
 * Endpoints couverts :
 *  - `POST /v1/oauth2/token` — Keycloak Client Credentials. Body
 *    form-urlencoded `{grant_type, client_id, client_secret}`. Header
 *    `hubtimize-api-key` requis. Retourne `AccessTokenResponse` avec
 *    un JWT minimal signé HS256 (payload décodable local par
 *    `decodeEsaLinkJwt`).
 *  - `GET /v1/healthcheck` — 200 OK vide. Auth Bearer + firewall key
 *    requis.
 *  - `GET /v1/siren/code-insee:<siren>` — retour `LegalUnitPayloadHistory`
 *    AFNOR minimal. 403 si flag `sandboxDemoMode` (cf. compte démo
 *    sandbox limité 2026-05-17).
 *  - `POST /v1/directory-line/search` — retour `{data: [...]}` AFNOR.
 *
 * **Pas implémenté V1** : les 9 endpoints `/v1/customerPA/*` et
 * `/v1/flows/*` ne sont pas mockés (méthodes driver stubbées
 * `NotImplementedYetException`).
 *
 * Le fake écoute sur un port aléatoire.
 */

const FAKE_KEYCLOAK_HMAC_SECRET = "fake-keycloak-secret-not-verified-by-driver";

/** Scénarios paramétrables — pilotent les réponses du fake pour les
 *  cas négatifs. */
export type FakeHubtimizeScenario =
  | "happy"
  | "auth_401_invalid_credentials"
  | "auth_403_missing_firewall_key"
  | "siren_403_sandbox_demo"
  | "siren_500_internal";

export interface FakeHubtimizeConfig {
  scenario?: FakeHubtimizeScenario;
  /** Valeur attendue pour le header `hubtimize-api-key`. Si la requête
   *  reçoit une valeur différente → 403. */
  expectedFirewallApiKey?: string;
  /** Username Keycloak attendu — peut contenir `+`. */
  expectedClientId?: string;
  expectedClientSecret?: string;
  /** TTL access token en secondes (default 3600). */
  accessTtlSeconds?: number;
}

export interface FakeHubtimize {
  readonly baseUrl: string;
  stop(): Promise<void>;
  setScenario(scenario: FakeHubtimizeScenario): void;
  getTokenRequestCount(): number;
  getHealthcheckRequestCount(): number;
  getSearchSirenRequestCount(): number;
  reset(): void;
}

/** Construit un JWT minimal HS256 dont le payload contient les claims
 *  fournis. Sert aux tests qui veulent vérifier le décodage côté
 *  `decodeEsaLinkJwt`. La signature n'est pas vérifiée par le driver
 *  (le serveur Hubtimize fait foi — cf. ADR-011 D3). */
export function buildFakeKeycloakJwt(claims: Record<string, unknown>): string {
  const header = { alg: "HS256", typ: "JWT" };
  const headerSeg = Buffer.from(JSON.stringify(header)).toString("base64url");
  const payloadSeg = Buffer.from(JSON.stringify(claims)).toString("base64url");
  const signature = createHmac("sha256", FAKE_KEYCLOAK_HMAC_SECRET)
    .update(`${headerSeg}.${payloadSeg}`)
    .digest("base64url");
  return `${headerSeg}.${payloadSeg}.${signature}`;
}

interface MutableState {
  scenario: FakeHubtimizeScenario;
  expectedFirewallApiKey: string;
  expectedClientId: string;
  expectedClientSecret: string;
  accessTtlSeconds: number;
  tokenRequestCount: number;
  healthcheckRequestCount: number;
  searchSirenRequestCount: number;
}

function buildApp(state: MutableState): FastifyInstance {
  const app = Fastify({ logger: false });

  app.addContentTypeParser(
    "application/x-www-form-urlencoded",
    { parseAs: "string" },
    (_req, body, done) => {
      try {
        const params = new URLSearchParams(body as string);
        const out: Record<string, string> = {};
        for (const [k, v] of params.entries()) out[k] = v;
        done(null, out);
      } catch (err) {
        done(err as Error, undefined);
      }
    },
  );

  // ─── POST /v1/oauth2/token (Keycloak Client Credentials) ───────────
  app.post<{
    Body: { grant_type?: string; client_id?: string; client_secret?: string };
  }>("/v1/oauth2/token", async (req, reply) => {
    state.tokenRequestCount += 1;

    // Validation header firewall (ADR-011 D4).
    const firewall = req.headers["hubtimize-api-key"];
    if (typeof firewall !== "string" || firewall !== state.expectedFirewallApiKey) {
      return reply
        .code(403)
        .send({ errorCode: "FORBIDDEN_ACCESS", errorMessage: "Missing or invalid firewall key" });
    }

    if (state.scenario === "auth_403_missing_firewall_key") {
      return reply
        .code(403)
        .send({ errorCode: "FORBIDDEN_ACCESS", errorMessage: "Sandbox firewall denied" });
    }

    const body = req.body;
    if (body.grant_type !== "client_credentials") {
      return reply
        .code(400)
        .send({ errorCode: "MISSING_REQUIRED_FIELD", errorMessage: "grant_type required" });
    }

    if (state.scenario === "auth_401_invalid_credentials") {
      return reply
        .code(401)
        .send({ errorCode: "MISSING_TOKEN", errorMessage: "Invalid credentials" });
    }

    // Validation credentials. Le client_id reçu via form-urlencoded a
    // déjà été URL-decoded par Fastify (ex. `contact+fl@mona.re` →
    // `contact fl@mona.re` si le caller a oublié --data-urlencode).
    // On vérifie l'égalité stricte avec `expectedClientId`.
    if (body.client_id !== state.expectedClientId) {
      return reply.code(401).send({
        errorCode: "MISSING_TOKEN",
        errorMessage: `Invalid client_id: '${body.client_id ?? ""}' (expected '${state.expectedClientId}')`,
      });
    }
    if (body.client_secret !== state.expectedClientSecret) {
      return reply
        .code(401)
        .send({ errorCode: "MISSING_TOKEN", errorMessage: "Invalid client_secret" });
    }

    const accessToken = buildFakeKeycloakJwt({
      iss: "https://keycloak.hubtimize.test/realms/distributor",
      sub: "uuid-distributor-mock",
      azp: state.expectedClientId,
      entityId: 42,
      email: state.expectedClientId,
      email_verified: true,
      preferred_username: state.expectedClientId,
      resource_access: {
        hubtimize: { roles: ["hubtimize-pa-distributor"] },
      },
      groups: ["/distributors/factur-e"],
      session_state: "mock-session",
      exp: Math.floor(Date.now() / 1000) + state.accessTtlSeconds,
      iat: Math.floor(Date.now() / 1000),
    });
    const refreshToken = buildFakeKeycloakJwt({
      typ: "Refresh",
      sub: "uuid-distributor-mock",
      exp: Math.floor(Date.now() / 1000) + state.accessTtlSeconds * 2,
    });
    return reply.code(200).send({
      access_token: accessToken,
      refresh_token: refreshToken,
      expires_in: state.accessTtlSeconds,
      refresh_expires_in: state.accessTtlSeconds * 2,
      token_type: "Bearer",
      scope: "email profile",
      session_state: "mock-session",
    });
  });

  // ─── GET /v1/healthcheck ───────────────────────────────────────────
  app.get("/v1/healthcheck", async (req, reply) => {
    state.healthcheckRequestCount += 1;
    if (!validateAuth(req, state)) {
      return reply.code(401).send({ errorCode: "MISSING_TOKEN", errorMessage: "Bearer required" });
    }
    return reply.code(200).send({});
  });

  // ─── GET /v1/siren/code-insee:<siren> ──────────────────────────────
  // Le pattern AFNOR a un colon non-séparateur dans le path
  // (`code-insee:<siren>`) — Fastify path-to-regexp ne le parse pas
  // proprement comme param. On utilise un wildcard + parse manuel.
  app.get<{ Params: { "*": string } }>("/v1/siren/*", async (req, reply) => {
    state.searchSirenRequestCount += 1;
    if (!validateAuth(req, state)) {
      return reply.code(401).send({ errorCode: "MISSING_TOKEN", errorMessage: "Bearer required" });
    }
    if (state.scenario === "siren_403_sandbox_demo") {
      return reply
        .code(403)
        .send({ errorCode: "FORBIDDEN_ACCESS", errorMessage: "Sandbox demo limited" });
    }
    if (state.scenario === "siren_500_internal") {
      return reply.code(500).send({ errorCode: "INTERNAL_ERROR", errorMessage: "Internal" });
    }
    const rest = req.params["*"];
    const match = /^code-insee:(\d{9})$/.exec(rest);
    if (match === null) {
      return reply
        .code(400)
        .send({ errorCode: "MISSING_REQUIRED_FIELD", errorMessage: `bad path: ${rest}` });
    }
    const siren = match[1];
    return reply.code(200).send({
      siren,
      businessName: "FAKE COMPANY SAS",
      entityType: "COMPANY",
      administrativeStatus: "ACTIVE",
      address: {
        street: "10 rue de la Paix",
        postcode: "75002",
        city: "Paris",
        country: "FR",
      },
    });
  });

  // ─── POST /v1/directory-line/search ────────────────────────────────
  app.post<{ Body: { sirenNumber?: string } }>("/v1/directory-line/search", async (req, reply) => {
    if (!validateAuth(req, state)) {
      return reply.code(401).send({ errorCode: "MISSING_TOKEN", errorMessage: "Bearer required" });
    }
    if (state.scenario === "siren_403_sandbox_demo") {
      return reply
        .code(403)
        .send({ errorCode: "FORBIDDEN_ACCESS", errorMessage: "Sandbox demo limited" });
    }
    const siren = req.body.sirenNumber ?? "000000000";
    return reply.code(200).send({
      data: [
        {
          identifier: `0225:${siren}_dgfip`,
          qualifier: "0225",
          isActive: true,
          paName: "EsaLink",
        },
      ],
    });
  });

  return app;
}

function validateAuth(
  req: { headers: Record<string, string | string[] | undefined> },
  state: MutableState,
): boolean {
  const auth = req.headers.authorization;
  const firewall = req.headers["hubtimize-api-key"];
  if (typeof auth !== "string" || !auth.startsWith("Bearer ")) return false;
  if (typeof firewall !== "string" || firewall !== state.expectedFirewallApiKey) return false;
  return true;
}

export async function startFakeHubtimize(config: FakeHubtimizeConfig = {}): Promise<FakeHubtimize> {
  const state: MutableState = {
    scenario: config.scenario ?? "happy",
    expectedFirewallApiKey: config.expectedFirewallApiKey ?? "fake-firewall-api-key-mock",
    expectedClientId: config.expectedClientId ?? "contact+fl@mona.re",
    expectedClientSecret: config.expectedClientSecret ?? "fake-keycloak-password",
    accessTtlSeconds: config.accessTtlSeconds ?? 3600,
    tokenRequestCount: 0,
    healthcheckRequestCount: 0,
    searchSirenRequestCount: 0,
  };
  const app = buildApp(state);
  await app.listen({ port: 0, host: "127.0.0.1" });
  const addr: AddressInfo | string | null = app.server.address();
  if (addr === null || typeof addr === "string") {
    await app.close();
    throw new Error("[fakeHubtimize] expected AddressInfo from server.address()");
  }
  const baseUrl = `http://127.0.0.1:${String(addr.port)}`;

  return {
    baseUrl,
    async stop(): Promise<void> {
      await app.close();
    },
    setScenario(scenario: FakeHubtimizeScenario): void {
      state.scenario = scenario;
    },
    getTokenRequestCount(): number {
      return state.tokenRequestCount;
    },
    getHealthcheckRequestCount(): number {
      return state.healthcheckRequestCount;
    },
    getSearchSirenRequestCount(): number {
      return state.searchSirenRequestCount;
    },
    reset(): void {
      state.tokenRequestCount = 0;
      state.healthcheckRequestCount = 0;
      state.searchSirenRequestCount = 0;
      state.scenario = "happy";
    },
  };
}
