import { z } from "zod";

/**
 * Export ZIP + rétention RGPD contracts (T-CL-EXPORT-ZIP-RETENTION sprint-06
 * L12 — endpoints `/api/exports/*` + `/api/dashboard/retention-alerts`).
 *
 * Couvre :
 *  - `POST /api/exports/zip` (création demande — rôle Full)
 *  - `GET /api/exports` (liste paginée Mes exports)
 *  - `GET /api/exports/:id/download` (redirect presigned S3)
 *  - `GET /api/dashboard/retention-alerts` (counts J-30/J-7/bloquées)
 *
 * Glossaire T-CW-11 : pas de "RGPD"/"purge" en libellé base. La purge est un
 * mécanisme serveur ; l'UI parle de "conservation 6 mois". Pas de chaîne UI
 * dans ce périmètre (libellés portés par les composants Storybook L12).
 */

// ─────────────────────────────────────────────────────────────────────────
// Primitives
// ─────────────────────────────────────────────────────────────────────────

/** Périmètre d'un export : factures émises, reçues, ou les deux. */
export const ExportScopeSchema = z.enum(["emission", "reception", "all"]);
export type ExportScope = z.infer<typeof ExportScopeSchema>;

/** Statut de cycle de vie d'une demande d'export (= CHECK BDD). */
export const ExportStatusSchema = z.enum([
  "pending",
  "processing",
  "completed",
  "failed",
  "purged",
]);
export type ExportStatus = z.infer<typeof ExportStatusSchema>;

/** Filtres repris depuis la liste Émission/Réception (sous-ensemble commun).
 *  `dateFrom`/`dateTo` au format ISO `YYYY-MM-DD`. */
export const ExportFiltersSchema = z
  .object({
    status: z.string().min(1).max(200).optional(),
    dateFrom: z
      .string()
      .regex(/^\d{4}-\d{2}-\d{2}$/, "Date attendue au format YYYY-MM-DD.")
      .optional(),
    dateTo: z
      .string()
      .regex(/^\d{4}-\d{2}-\d{2}$/, "Date attendue au format YYYY-MM-DD.")
      .optional(),
    search: z.string().max(200).optional(),
  })
  .strict();
export type ExportFilters = z.infer<typeof ExportFiltersSchema>;

// ─────────────────────────────────────────────────────────────────────────
// POST /api/exports/zip — body
// ─────────────────────────────────────────────────────────────────────────

export const CreateExportRequestSchema = z
  .object({
    scope: ExportScopeSchema,
    filters: ExportFiltersSchema.default({}),
  })
  .strict();
export type CreateExportRequest = z.infer<typeof CreateExportRequestSchema>;

/** Réponse 202 Accepted — la génération est asynchrone (worker pgboss). */
export const CreateExportResponseSchema = z.object({
  export_id: z.string().uuid(),
  correlation_id: z.string().uuid(),
});
export type CreateExportResponse = z.infer<typeof CreateExportResponseSchema>;

// ─────────────────────────────────────────────────────────────────────────
// GET /api/exports — item de liste
// ─────────────────────────────────────────────────────────────────────────

export const ExportRequestSchema = z.object({
  id: z.string().uuid(),
  scope: ExportScopeSchema,
  filters: ExportFiltersSchema,
  invoice_count: z.number().int().nonnegative(),
  status: ExportStatusSchema,
  file_size_bytes: z.number().int().nonnegative().nullable(),
  purge_at: z.string(),
  created_at: z.string(),
  /** `true` si `status='completed'` ET `created_at` < 7 jours → lien
   *  download actif (Z5 — endpoint accessible 7 jours). */
  download_available: z.boolean(),
});
export type ExportRequestDto = z.infer<typeof ExportRequestSchema>;

export const ExportListResponseSchema = z.object({
  items: z.array(ExportRequestSchema),
  total: z.number().int().nonnegative(),
  page: z.number().int().positive(),
  page_size: z.number().int().positive(),
});
export type ExportListResponse = z.infer<typeof ExportListResponseSchema>;

// ─────────────────────────────────────────────────────────────────────────
// GET /api/dashboard/retention-alerts
// ─────────────────────────────────────────────────────────────────────────

/** Counts d'alertes rétention pour le bandeau dashboard (severity priority
 *  `blocked > j7 > j30`, géré côté front). `blockedCount` = factures dont la
 *  date de purge est dépassée mais jamais exportées (signal de perte). */
export const RetentionAlertSchema = z.object({
  j30Count: z.number().int().nonnegative(),
  j7Count: z.number().int().nonnegative(),
  blockedCount: z.number().int().nonnegative(),
});
export type RetentionAlert = z.infer<typeof RetentionAlertSchema>;
