import { z } from "zod";

/**
 * Enveloppe d'erreur API standard (NC-15 sprint-05, cohérent ADR-009).
 *
 * Contrat **forward** pour toute réponse d'erreur user-facing 4xx/5xx :
 *  - `message` : texte neutre obligatoire (anti-énumération), affichable
 *    tel quel côté UI.
 *  - `code` : code machine optionnel pour brancher un comportement front
 *    (ex. `mfa_reset_required`). Côté legacy, le champ historique `reason`
 *    joue ce rôle — le parser front (`apps/web/src/lib/api.ts:parseApiError`)
 *    reconnaît les deux.
 *  - `issues` : détails de validation optionnels (champ + message), pour un
 *    affichage inline. Côté legacy, `errors` (erreurs métier formToModel /
 *    XSD `{code, field, message}`) est normalisé vers `issues` par le parser.
 *
 * Les 4 familles legacy + ce contrat sont documentés dans
 * `docs/engineering/error-response.md`.
 *
 * **Non `.strict()`** à dessein : certaines routes ajoutent un champ de
 * contexte métier (ex. `existingInvoiceId` sur un 409 numéro). Les réponses
 * *typées de domaine* (annuaire `{kind}`, webhooks PA, unions de succès) ne
 * sont PAS des enveloppes d'erreur et ne suivent pas ce schéma.
 */

export const ApiErrorIssueSchema = z.object({
  /** Chemin du champ concerné (ex. `["document", "number"]`). */
  path: z.array(z.union([z.string(), z.number()])).optional(),
  message: z.string(),
  /** Code de l'issue (Zod `invalid_type`… ou métier `INVALID_VAT_RATE`…). */
  code: z.string().optional(),
});
export type ApiErrorIssue = z.infer<typeof ApiErrorIssueSchema>;

export const ApiErrorResponseSchema = z.object({
  message: z.string(),
  code: z.string().optional(),
  issues: z.array(ApiErrorIssueSchema).optional(),
});
export type ApiErrorResponse = z.infer<typeof ApiErrorResponseSchema>;

/** Construit une enveloppe d'erreur standard. */
export function apiError(
  message: string,
  opts?: { code?: string; issues?: readonly ApiErrorIssue[] },
): ApiErrorResponse {
  const body: ApiErrorResponse = { message };
  if (opts?.code !== undefined) body.code = opts.code;
  if (opts?.issues !== undefined && opts.issues.length > 0) {
    body.issues = opts.issues.map((i) => ({ ...i }));
  }
  return body;
}

/** Forme minimale d'une issue Zod (`ZodIssue`) consommée par le mapping —
 *  on ne dépend pas du type exact de la version de Zod. */
interface ZodIssueLike {
  readonly path: readonly (string | number | symbol)[];
  readonly message: string;
  readonly code: string;
}

/** Convertit des issues Zod en `ApiErrorIssue[]` (symboles de path écartés). */
export function zodIssuesToApiIssues(issues: readonly ZodIssueLike[]): ApiErrorIssue[] {
  return issues.map((i) => ({
    path: i.path.filter((p): p is string | number => typeof p !== "symbol"),
    message: i.message,
    code: i.code,
  }));
}
