/**
 * AFNOR XP Z12-012 BR-FR-05 — mentions légales obligatoires sur facture
 * électronique réforme France (3 IncludedNote PMT/PMD/AAB).
 *
 * Source : `docs/standards/afnor-xp-z12-012-br-fr-05-included-notes.md` §3
 * (verbatim exemples officiels Annexe B page 89).
 *
 * - PMT : indemnité forfaitaire 40 € Loi LME D.441-5 — fixe FR, immuable.
 * - PMD : pénalités de retard — paramétrable via `customers.default_invoice_values
 *         .late_penalties_mention`, fallback Loi LME 3× taux d'intérêt légal.
 * - AAB : mention escompte ou absence — paramétrable via
 *         `customers.default_invoice_values.discount_mention`, fallback absence.
 */

export const AFNOR_BR_FR_05_PMT_FORFAIT_40_EUR =
  "Indemnité forfaitaire pour frais de recouvrement en cas de retard de paiement : 40 €.";

export const AFNOR_BR_FR_05_PMD_DEFAULT_LME_3X_TAUX_LEGAL =
  "Tout retard de paiement engendre une pénalité exigible à compter de la date d'échéance, calculée sur la base de trois fois le taux d'intérêt légal.";

export const AFNOR_BR_FR_05_AAB_DEFAULT_ABSENCE_ESCOMPTE =
  "Les règlements reçus avant la date d'échéance ne donneront pas lieu à escompte.";

/** Clés JSONB libres dans `customers.default_invoice_values` (sprint-02 schéma) :
 *  - `late_penalties_mention` : override PMD (string, max 500 chars).
 *  - `discount_mention` : override AAB (string, max 500 chars).
 *  PMT n'est jamais paramétrable (loi LME immuable). */
export const AFNOR_DEFAULT_INVOICE_VALUES_PMD_KEY = "late_penalties_mention" as const;
export const AFNOR_DEFAULT_INVOICE_VALUES_AAB_KEY = "discount_mention" as const;
