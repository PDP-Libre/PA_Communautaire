/**
 * INSEE `categorieJuridiqueUniteLegale` codes that legally require a
 * declared `capital_social` on invoices (brief §6.17). Source: French
 * Code de commerce L210-2 (SA, SAS), L223-2 (SARL), L227-1 (SAS),
 * L210-3 (SCA), and the SELARL/SELAS/SELCA derivatives.
 *
 * Any code NOT in this list (entrepreneur individuel, association,
 * coopérative…) does not require capital_social — the field stays
 * optional in the API.
 *
 * Lives in `shared-schemas` (vs `apps/api`) so both the API (conditional
 * Zod gate on PATCH /customers/me/profile) and the web Paramètres >
 * Entreprise form (conditional "Capital social" input) consume a single
 * source of truth — T-CL-WEB-EMIT-CAPITAL-SOCIAL sprint-06 W1.
 */

const CAPITAL_REQUIRED_CODES = new Set<string>([
  // SARL et dérivés
  "5410",
  "5415",
  "5422",
  "5426",
  "5430",
  "5431",
  "5432",
  "5442",
  "5485",
  "5498", // EURL
  "5499", // SARL générique
  // SA — Conseil d'administration
  "5505",
  "5510",
  "5515",
  "5520",
  "5522",
  "5525",
  "5530",
  "5531",
  "5532",
  "5585",
  "5599",
  // SA — Directoire
  "5605",
  "5610",
  "5615",
  "5625",
  "5630",
  "5631",
  "5632",
  "5685",
  "5699",
  // SAS et dérivés
  "5710",
  "5720", // SASU
  "5785", // SELAS
  // Société européenne
  "5800",
]);

export function capitalRequiredFor(juridiqueCode: string | null): boolean {
  if (juridiqueCode === null) return false;
  return CAPITAL_REQUIRED_CODES.has(juridiqueCode);
}
