import { z } from "zod";

/**
 * Users + invitations contracts (T-CL-07).
 *
 * 3 roles + cumulative `can_purchase` flag (PRD §6.2 + brief sprint-02 §5.5).
 * Invitations: token shape `<invitation_id>.<32-hex-secret>`, bcrypt-hashed
 * server-side. MFA setup deferred to first login (mfa_reset_required = true
 * at user creation), reuses T-CL-03 flow.
 */

export const RoleSchema = z.enum(["deposit_simple", "deposit_states", "full"]);
export type Role = z.infer<typeof RoleSchema>;

const passwordSchema = z
  .string()
  .min(12, "Mot de passe trop court (12 caractères minimum).")
  .max(256)
  .refine((v) => /[A-Z]/.test(v), "Mot de passe doit contenir au moins une majuscule.")
  .refine((v) => /[0-9]/.test(v), "Mot de passe doit contenir au moins un chiffre.")
  .refine(
    (v) => /[^A-Za-z0-9]/.test(v),
    "Mot de passe doit contenir au moins un caractère spécial.",
  );

// ─────────────────────────────────────────────────────────────────────────
// Inviting (Full only) — POST /users/invite
// ─────────────────────────────────────────────────────────────────────────

export const InvitationCreateBodySchema = z
  .object({
    email: z.string().email().max(254),
    role: RoleSchema,
    can_purchase: z.boolean().default(false),
  })
  .strict();
export type InvitationCreateBody = z.infer<typeof InvitationCreateBodySchema>;

export const InvitationCreateResponseSchema = z
  .object({
    invitation_id: z.string().uuid(),
    expires_at: z.string().datetime(),
  })
  .strict();
export type InvitationCreateResponse = z.infer<typeof InvitationCreateResponseSchema>;

// ─────────────────────────────────────────────────────────────────────────
// Pending invitations list (Full only) — GET /invitations
// ─────────────────────────────────────────────────────────────────────────

export const PendingInvitationSchema = z
  .object({
    id: z.string().uuid(),
    email: z.string().email(),
    role: RoleSchema,
    can_purchase: z.boolean(),
    inviter_id: z.string().uuid(),
    expires_at: z.string().datetime(),
    created_at: z.string().datetime(),
  })
  .strict();
export type PendingInvitation = z.infer<typeof PendingInvitationSchema>;

export const PendingInvitationsResponseSchema = z
  .object({ invitations: z.array(PendingInvitationSchema) })
  .strict();
export type PendingInvitationsResponse = z.infer<typeof PendingInvitationsResponseSchema>;

// ─────────────────────────────────────────────────────────────────────────
// Public preview — GET /invitations/:token/preview (no auth, used by accept page)
// ─────────────────────────────────────────────────────────────────────────

export const InvitationPreviewSchema = z
  .object({
    email: z.string().email(),
    role: RoleSchema,
    can_purchase: z.boolean(),
    customer_legal_name: z.string(),
    inviter_email: z.string().email(),
  })
  .strict();
export type InvitationPreview = z.infer<typeof InvitationPreviewSchema>;

// ─────────────────────────────────────────────────────────────────────────
// Accepting an invitation — POST /invitations/:token/accept
// ─────────────────────────────────────────────────────────────────────────

export const AcceptInvitationBodySchema = z
  .object({
    password: passwordSchema,
    terms_accepted: z.literal(true),
  })
  .strict();
export type AcceptInvitationBody = z.infer<typeof AcceptInvitationBodySchema>;

export const AcceptInvitationResponseSchema = z
  .object({
    access_token: z.string(),
    expires_in: z.number().int().positive(),
    mfa_setup_required: z.literal(true),
  })
  .strict();
export type AcceptInvitationResponse = z.infer<typeof AcceptInvitationResponseSchema>;

// ─────────────────────────────────────────────────────────────────────────
// User listing + admin — GET /users, PATCH /users/:id/role, etc.
// ─────────────────────────────────────────────────────────────────────────

export const UserListItemSchema = z
  .object({
    id: z.string().uuid(),
    email: z.string().email(),
    role: RoleSchema,
    can_purchase: z.boolean(),
    mfa_mode: z.enum(["none", "email", "totp"]),
    last_login_at: z.string().datetime().nullable(),
    created_at: z.string().datetime(),
  })
  .strict();
export type UserListItem = z.infer<typeof UserListItemSchema>;

export const UserListResponseSchema = z.object({ users: z.array(UserListItemSchema) }).strict();
export type UserListResponse = z.infer<typeof UserListResponseSchema>;

export const PatchUserRoleBodySchema = z.object({ role: RoleSchema }).strict();
export type PatchUserRoleBody = z.infer<typeof PatchUserRoleBodySchema>;

export const PatchUserCanPurchaseBodySchema = z.object({ can_purchase: z.boolean() }).strict();
export type PatchUserCanPurchaseBody = z.infer<typeof PatchUserCanPurchaseBodySchema>;
