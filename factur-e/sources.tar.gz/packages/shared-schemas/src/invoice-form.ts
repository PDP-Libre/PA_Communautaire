import { z } from "zod";

import { VatCategorySchema } from "./products.js";

/**
 * Invoice form schemas — contrat partagé front/back pour le formulaire
 * d'émission B2B (sprint-04 L08). Discriminated union sur `ui_mode` :
 *
 *  - `base` (mode UI base — Pierre/Claire) : 15 champs essentiels, le
 *    reste est pré-rempli côté serveur depuis le customer (devise,
 *    régime TVA, IBAN, mentions, processingRule, type 380…).
 *  - `advanced` (mode UI avancé — Sophie / cas particulier) : 54 champs
 *    couvrant EN 16931 EXTENDED — BT-13/14, BG-13 expédition,
 *    BG-20 remise globale, VATEX, 4 zones commentaires distinctes,
 *    modalités de paiement hybrides, etc.
 *
 * Le mapping vers `CrossIndustryInvoice` de `factur-x-model` est porté
 * par `apps/api/src/services/invoice-form-to-model.ts` (fonction pure).
 *
 * Référence mapping BT/BG : `docs/product/mapping-bt-bg.md`.
 * Référence couverture EN 16931 : `docs/design/sprint-04-invariants.md` §5.
 */

// ─────────────────────────────────────────────────────────────────────
// Primitives décimales — strings pour préserver la précision EN 16931
// ─────────────────────────────────────────────────────────────────────

/** Quantité (BT-129) : 4 décimales, > 0 (BR-22). */
const QuantityStringSchema = z
  .string()
  .regex(/^\d+(\.\d{1,4})?$/, "Quantité invalide (au plus 4 décimales).")
  .refine((s) => Number(s) > 0, "Quantité strictement positive requise.");

/** Prix unitaire HT (BT-146) : 4 décimales, ≥ 0. */
const PriceStringSchema = z
  .string()
  .regex(/^\d+(\.\d{1,4})?$/, "Prix invalide (au plus 4 décimales).")
  .refine((s) => Number(s) >= 0, "Prix ≥ 0 requis.");

/** Montant agrégé (BT-131, BT-106..115) : 2 décimales, ≥ 0. */
const AmountStringSchema = z
  .string()
  .regex(/^\d+(\.\d{1,2})?$/, "Montant invalide (au plus 2 décimales).")
  .refine((s) => Number(s) >= 0, "Montant ≥ 0 requis.");

/** Taux TVA en pourcentage (BT-119, BT-152) : 2 décimales, 0..100. */
const VatRateStringSchema = z
  .string()
  .regex(/^\d+(\.\d{1,2})?$/, "Taux TVA invalide (au plus 2 décimales).")
  .refine((s) => {
    const n = Number(s);
    return n >= 0 && n <= 100;
  }, "Taux TVA entre 0 et 100 attendu.");

/** Pourcentage 0..100 (remise globale, etc.). */
const PercentStringSchema = z
  .string()
  .regex(/^\d+(\.\d{1,2})?$/)
  .refine((s) => {
    const n = Number(s);
    return n >= 0 && n <= 100;
  }, "Pourcentage entre 0 et 100 attendu.");

// ─────────────────────────────────────────────────────────────────────
// Numéro de facture (BT-1)
// ─────────────────────────────────────────────────────────────────────

/** 1-30 caractères, alphanumérique + tirets + underscores + slash
 *  (US-EMIT-002 critère 1). */
const InvoiceNumberSchema = z
  .string()
  .min(1)
  .max(30)
  .regex(/^[\w\-/]+$/, "Caractères autorisés : lettres, chiffres, - _ /.");

// ─────────────────────────────────────────────────────────────────────
// Adresse postale (BG-5/8/12/15 — réutilisable buyer / shipping)
// ─────────────────────────────────────────────────────────────────────

const PostalAddressSchema = z
  .object({
    lineOne: z.string().max(200).nullish(),
    lineTwo: z.string().max(200).nullish(),
    postcode: z.string().max(20),
    city: z.string().max(100),
    countryCode: z.string().length(2), // BT-40/55 ISO 3166-1 alpha-2
  })
  .strict();

// ─────────────────────────────────────────────────────────────────────
// Buyer (BG-7 BuyerTradeParty) — commun mode base + avancé
// ─────────────────────────────────────────────────────────────────────

/** Schémas Peppol/AFNOR pour l'adresse électronique BT-49 :
 *  0225 SIREN+suffixe DGFiP (France B2B), 0223 TVA intracom UE,
 *  0227 hors UE, 0228 RIDET DROM, 0229 TAHITI, 0009 SIRET tiers.
 *  Sprint-04 = 0225 défaut (B2B domestique). */
const ElectronicAddressSchemeSchema = z.enum(["0225", "0223", "0227", "0228", "0229", "0009"]);

const BuyerSchema = z
  .object({
    /** BT-47 SIREN 9 chiffres (B2B domestique). Pour B2BInt (V1+),
     *  la validation sera assouplie via discriminator processingRule. */
    siren: z.string().regex(/^\d{9}$/, "SIREN attendu : 9 chiffres."),
    /** BT-44 raison sociale, peuplée par l'annuaire SuperPDP côté UI. */
    legalName: z.string().min(1).max(200),
    /** BT-50..55 adresse de facturation. */
    address: PostalAddressSchema,
    /** BT-49 adresse électronique Peppol (ex `0225:123456789_dgfip`). */
    electronicAddress: z.string().min(1).max(100),
    /** Scheme ID de BT-49 — défaut 0225 France B2B. */
    electronicAddressScheme: ElectronicAddressSchemeSchema.default("0225"),
  })
  .strict();

// ─────────────────────────────────────────────────────────────────────
// Conditions de paiement — modalités hybrides Express Invoice
// ─────────────────────────────────────────────────────────────────────

/** Discriminated union sur `kind` :
 *  - onSight = règlement à vue (immédiat)
 *  - days = règlement net à N jours après émission
 *  - endOfMonth = règlement fin de mois + N jours
 *  - fixedDate = échéance fixe BT-9
 *  Couvre mode base + avancé. */
const PaymentTermsSchema = z.discriminatedUnion("kind", [
  z.object({ kind: z.literal("onSight") }).strict(),
  z
    .object({
      kind: z.literal("days"),
      days: z.number().int().min(1).max(365),
    })
    .strict(),
  z
    .object({
      kind: z.literal("endOfMonth"),
      days: z.number().int().min(0).max(180),
    })
    .strict(),
  z
    .object({
      kind: z.literal("fixedDate"),
      dueDate: z.string().date(), // BT-9 YYYY-MM-DD
    })
    .strict(),
]);
export type InvoicePaymentTerms = z.infer<typeof PaymentTermsSchema>;

/** Familles UI mode base (libellés humains). Mapping vers
 *  BT-81 UNTDID 4461 fait par formToModel selon préférence customer
 *  ou override mode avancé. */
const PaymentMethodKindSchema = z.enum([
  "transfer", // 30 / 58 SEPA credit transfer (défaut B2B)
  "direct_debit", // 49 / 59 SEPA direct debit
  "card", // 48 carte
  "check", // 20 chèque
  "cash", // 10 espèces
]);
export type PaymentMethodKind = z.infer<typeof PaymentMethodKindSchema>;

/** BT-81 codes UNTDID 4461 — exposés en mode avancé pour override
 *  explicite ; mapping family → code par défaut côté formToModel. */
const PaymentMeansCodeSchema = z.enum(["10", "20", "30", "48", "49", "58", "59"]);

// ─────────────────────────────────────────────────────────────────────
// Période de facturation (BG-14 header / BG-26 ligne)
// ─────────────────────────────────────────────────────────────────────

const BillingPeriodSchema = z
  .object({
    startDate: z.string().date().nullish(), // BT-73
    endDate: z.string().date().nullish(), // BT-74
  })
  .strict()
  .refine(
    (p) => p.startDate !== null || p.endDate !== null,
    "Au moins une date début/fin requise (BR-CO-20).",
  );

// ─────────────────────────────────────────────────────────────────────
// Remise / charge (BG-20 header + BG-27/28 ligne)
// ─────────────────────────────────────────────────────────────────────

/** Codes raison remise/charge UN/CEFACT 5189 / ALC :
 *  remise courante (95 discount), commerciale (40), volume (44),
 *  charge transport (41 freight), assurance (62). Liste non exhaustive. */
const AllowanceChargeReasonCodeSchema = z
  .string()
  .max(10)
  .regex(/^[0-9]{1,3}$/);

/** Remise (chargeIndicator=false) ou charge (chargeIndicator=true).
 *  BR-42/43 : `reason` OU `reasonCode` requis. */
const AllowanceChargeSchema = z
  .object({
    chargeIndicator: z.boolean(), // false = remise BG-20, true = charge BG-21
    amount: AmountStringSchema, // BT-92 / BT-99
    baseAmount: AmountStringSchema.nullish(), // BT-93 / BT-100
    percent: PercentStringSchema.nullish(), // BT-94 / BT-101
    reason: z.string().max(200).nullish(), // BT-97 / BT-104
    reasonCode: AllowanceChargeReasonCodeSchema.nullish(), // BT-98 / BT-105
    vatCategory: VatCategorySchema, // BT-95 / BT-102
    vatRate: VatRateStringSchema.nullish(), // BT-96 / BT-103
  })
  .strict()
  .refine(
    (a) =>
      (a.reason !== null && a.reason !== undefined && a.reason !== "") ||
      (a.reasonCode !== null && a.reasonCode !== undefined && a.reasonCode !== ""),
    "Reason ou reasonCode requis (BR-42/43).",
  );

// ─────────────────────────────────────────────────────────────────────
// LineItem — mode base + extension mode avancé
// ─────────────────────────────────────────────────────────────────────

const LineItemBaseSchema = z
  .object({
    /** BT-153 désignation produit (BR-25 non vide). */
    label: z.string().min(1).max(200),
    /** BT-154 ou note simple sous le label — visible PDF. */
    description: z.string().max(2000).nullish(),
    /** BT-129 quantité (BR-22 > 0). */
    quantity: QuantityStringSchema,
    /** BT-130 unité UN/ECE Rec 20 (C62 each, HUR hour, KGM kg, MTR m…). */
    unitCode: z.string().min(1).max(10).default("C62"),
    /** BT-146 prix unitaire HT. */
    unitPriceHt: PriceStringSchema,
    /** BT-151 catégorie TVA (S standard / AE autoliquid. / Z 0% /
     *  E exonéré / K intracom / G export hors UE / O hors champ). */
    vatCategory: VatCategorySchema,
    /** BT-152 taux TVA. Null pour AE/Z/E/K/G/O. */
    vatRate: VatRateStringSchema.nullable(),
    /** BT-131 total ligne HT calculé côté UI, revalidé côté serveur. */
    totalHt: AmountStringSchema,
  })
  .strict()
  .superRefine((line, ctx) => {
    if (line.vatCategory === "S" && line.vatRate === null) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["vatRate"],
        message: "Taux TVA requis pour la catégorie standard (S).",
      });
    }
    if (line.vatCategory !== "S" && line.vatRate !== null) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["vatRate"],
        message: "Taux TVA doit être null pour cette catégorie.",
      });
    }
  });
export type LineItemBase = z.infer<typeof LineItemBaseSchema>;

/** Codes VATEX exemption TVA (BT-121) — sous-ensemble Factur-X. */
const VatexCodeSchema = z.enum([
  "VATEX-EU-G", // exportation hors UE
  "VATEX-EU-IC", // livraison intracommunautaire
  "VATEX-EU-AE", // autoliquidation TVA
  "VATEX-EU-O", // hors champ d'application
  "VATEX-EU-79", // exonération art. 79 directive
  "VATEX-EU-132", // exonération art. 132 directive
  "VATEX-FR-CGI293B", // franchise base TVA art. 293B CGI
]);

/** Forme line mode avancé — base + extensions EXTENDED.
 *  Pas de superRefine ici (z.object).extend() ne le supporte pas sur
 *  un schema déjà refine. La cohérence vat est revérifiée par
 *  `formToModel` côté serveur. */
const LineItemAdvancedShapeSchema = z
  .object({
    label: z.string().min(1).max(200),
    description: z.string().max(2000).nullish(),
    quantity: QuantityStringSchema,
    unitCode: z.string().min(1).max(10).default("C62"),
    unitPriceHt: PriceStringSchema,
    vatCategory: VatCategorySchema,
    vatRate: VatRateStringSchema.nullable(),
    totalHt: AmountStringSchema,
    /** BT-121 code VATEX exonération (requis si catégorie K/G/O/E/AE
     *  selon BR-E/K/G/O — validé côté formToModel). */
    vatex: VatexCodeSchema.nullish(),
    /** BG-26 période ligne (BT-134/135). */
    period: BillingPeriodSchema.nullish(),
    /** BG-27 remise ligne ou BG-28 charge ligne (BT-136..145). */
    allowance: AllowanceChargeSchema.nullish(),
    /** BT-154 description longue (mode avancé expand-row). */
    longDescription: z.string().max(5000).nullish(),
    /** BT-127 note ligne (cardinalité 0..n simplifiée 1 texte joint). */
    note: z.string().max(2000).nullish(),
    /** BT-149 quantité de base (ex prix pour 100 unités). */
    basisQuantity: QuantityStringSchema.nullish(),
  })
  .strict();
export type LineItemAdvanced = z.infer<typeof LineItemAdvancedShapeSchema>;

// ─────────────────────────────────────────────────────────────────────
// Shipping (BG-13 ShipToTradeParty — mode avancé only)
// ─────────────────────────────────────────────────────────────────────

const ShippingPartySchema = z
  .object({
    /** BT-70 nom destinataire (BR-57 obligatoire si BG-13 émis). */
    name: z.string().max(200).nullish(),
    /** BT-71 identifiant lieu livraison. */
    locationId: z.string().max(100).nullish(),
    /** BG-15 adresse de livraison (BT-50..55 réutilisés). */
    address: PostalAddressSchema,
  })
  .strict();

/** BR-FREXT-CL-27 — INCOTERM (BT-X-22 DeliveryTypeCode) whitelist 13 codes FR
 *  EXTENDED-CTC-FR (finding K1). Source de vérité builder `INCOTERM_WHITELIST_FR`
 *  (br-fr-codes.ts) répliquée ici pour la validation form ; le builder re-valide
 *  (`isValidIncotermFr` → FacturXCodeError). Inclut les 2 codes FR non-standard
 *  "1"/"2" (cf. EXTENDED-CTC-FR §4.3). */
export const IncotermCodeSchema = z.enum([
  "1",
  "2",
  "CFR",
  "CIF",
  "CIP",
  "CPT",
  "DAP",
  "DDP",
  "DPU",
  "EXW",
  "FAS",
  "FCA",
  "FOB",
]);
export type IncotermCode = z.infer<typeof IncotermCodeSchema>;

/** Régime TVA spécifique au client (Section Parties mode avancé) —
 *  override le régime customer pour cette facture. Impacte les
 *  catégories TVA générées sur les lignes à taux 0. */
const ClientTaxRegimeSchema = z.enum([
  "default", // utilise le régime du vendeur (customer)
  "franchise_293b", // exonération art. 293B (auto-entrepreneur)
  "reverse_charge_eu", // autoliquidation TVA intracom
  "export_outside_eu", // exonération hors UE
]);

// ─────────────────────────────────────────────────────────────────────
// InvoiceFormBaseSchema — 15 champs mode UI base
// ─────────────────────────────────────────────────────────────────────

/** Codes type facture EN 16931 BT-3 (380 facture, 381 avoir, 384
 *  rectificative, 386 acompte, 389 auto-facture, 261 avoir self-billed).
 *  Exporté pour réutilisation côté endpoint credit-note + formToModel. */
export const InvoiceTypeCodeSchema = z.enum(["380", "381", "384", "386", "389", "261"]);

/** Sous-ensemble L11 — types créables via POST /api/invoices/:id/credit-note
 *  (381 Avoir total / 384 Rectificative). */
export const CreditNoteTypeCodeSchema = z.enum(["381", "384"]);
export type CreditNoteTypeCode = z.infer<typeof CreditNoteTypeCodeSchema>;

/** Métadonnées lien BG-3 (BR-55) facture d'origine → avoir/rectificative.
 *  Émises par POST /api/invoices/:id/credit-note, conservées au draft, puis
 *  consommées par formToModel (BT-25 numéro + BT-26 date → precedingInvoices)
 *  et persistées en colonne `invoices.preceding_invoice_id` à l'envoi.
 *  Pattern identique aux métadonnées Repartir `restartedFromInvoiceId`. */
const PrecedingInvoiceFields = {
  /** UUID de la facture d'origine — `invoices.preceding_invoice_id` + lookup pose 209. */
  precedingInvoiceId: z.string().uuid().nullish(),
  /** BT-25 numéro de la facture d'origine (BG-3). */
  precedingInvoiceNumber: z.string().nullish(),
  /** BT-26 date d'émission de la facture d'origine (BG-3, optionnel). */
  precedingIssueDate: z.string().date().nullish(),
} as const;

/**
 * Mode UI base — saisie minimale. Le serveur infère le reste depuis
 * `customers.default_invoice_values` + heuristiques (type 380, currency
 * EUR, processingRule B2B, paymentMeansCode par défaut selon
 * paymentMethodKind). `typeCode` reste 380 sauf pour un avoir/rectificative
 * (L11) dont le brouillon est pré-rempli par l'endpoint credit-note.
 */
export const InvoiceFormBaseSchema = z
  .object({
    ui_mode: z.literal("base"),
    document: z
      .object({
        number: InvoiceNumberSchema, // BT-1
        issueDate: z.string().date(), // BT-2
        // BT-3 — optionnel en base (absent ⇒ 380 côté formToModel). Pré-rempli
        // 381/384 par l'endpoint credit-note (L11). `.optional()` plutôt que
        // `.default()` pour ne pas rendre le champ requis sur le type de sortie
        // (rétro-compat fixtures base existantes).
        typeCode: InvoiceTypeCodeSchema.optional(),
        notes: z.string().max(500).nullish(), // BT-22 zone Notes simple
      })
      .strict(),
    parties: z
      .object({
        buyer: BuyerSchema,
      })
      .strict(),
    lines: z.array(LineItemBaseSchema).min(1, "Au moins une ligne requise (BR-16)."),
    payment: z
      .object({
        paymentTerms: PaymentTermsSchema,
        paymentMethodKind: PaymentMethodKindSchema,
        /** BT-20 description mentions légales libres (chargement défaut
         *  customer côté UI puis éditable). */
        mentionsLegales: z.string().max(500).nullish(),
      })
      .strict(),
    /** Métadonnées Repartir (T-CL-UI-01 `<RestartedFromBanner>`) — émises
     *  par `POST /api/invoices/:id/restart`, conservées au draft puis
     *  consommées par l'UI pour afficher le bandeau. Pas mappées Factur-X. */
    restartedFromInvoiceId: z.string().uuid().nullish(),
    restartedFromNumber: z.string().nullish(),
    ...PrecedingInvoiceFields,
  })
  .strict();
export type InvoiceFormBase = z.infer<typeof InvoiceFormBaseSchema>;

// ─────────────────────────────────────────────────────────────────────
// InvoiceFormAdvancedSchema — 54 champs mode UI avancé
// ─────────────────────────────────────────────────────────────────────

export const InvoiceFormAdvancedSchema = z
  .object({
    ui_mode: z.literal("advanced"),
    document: z
      .object({
        number: InvoiceNumberSchema, // BT-1
        issueDate: z.string().date(), // BT-2
        typeCode: InvoiceTypeCodeSchema.default("380"), // BT-3
        currency: z.string().length(3).default("EUR"), // BT-5
        processingRule: z.enum(["B2B", "B2BInt"]).default("B2B"),
        buyerOrderRef: z.string().max(100).nullish(), // BT-13
        sellerOrderRef: z.string().max(100).nullish(), // BT-14
        contractRef: z.string().max(100).nullish(), // BT-12
        projectRef: z.string().max(100).nullish(), // extension UI
        billingPeriod: BillingPeriodSchema.nullish(), // BG-14
        /** 4 zones commentaires distinctes (acté T-CW-09 §10.1 patches
         *  PRD §5.6). Mode base utilise uniquement `notes` (équivalent
         *  zone publique). Les 3 autres apparaissent dans l'onglet
         *  Commentaires repliable de Section Document mode avancé. */
        notes: z.string().max(500).nullish(), // BT-22 zone publique
        privateComments: z.string().max(2000).nullish(), // INTERNE — jamais XML
        footerMentions: z.string().max(500).nullish(), // BT-20 footer PDF
        generalComments: z.string().max(500).nullish(), // BT-22 multi-occurrence en-tête PDF
      })
      .strict(),
    parties: z
      .object({
        buyer: BuyerSchema,
        /** BG-13 ShipToTradeParty — adresse expédition distincte. */
        shipping: ShippingPartySchema.nullish(),
        /** BT-72 date livraison effective. */
        deliveryDate: z.string().date().nullish(),
        /** Régime TVA spécifique au client (override defaults). */
        clientTaxRegime: ClientTaxRegimeSchema.default("default"),
        /** Transporteur (extension UI — pas standard EN 16931). */
        transporter: z.string().max(200).nullish(),
        /** BT-15 / BT-16 numéro suivi expédition/réception. */
        trackingNumber: z.string().max(100).nullish(),
      })
      .strict(),
    lines: z.array(LineItemAdvancedShapeSchema).min(1, "Au moins une ligne requise (BR-16)."),
    /** BG-20 DocumentLevelAllowanceCharge — remise globale modal
     *  (acté T-CW-09 §10.1 patches PRD §5.6). Distinct des remises
     *  par ligne (BT-136/137). */
    documentLevelAllowance: AllowanceChargeSchema.nullish(),
    /** Frais de port HT — BG-21 charge document (reasonCode UNTDID 7161
     *  "FC"). Finding J : distinct de `documentLevelAllowance` (remise
     *  globale) — les deux coexistent dans les totaux. Toggle = montant
     *  absent/0 → pas de charge. `shippingCostVatCategory`/`Rate` alimentent
     *  la CategoryTradeTax obligatoire BG-21 + la ventilation TVA BG-23. */
    shippingCostHt: AmountStringSchema.nullish(),
    shippingCostVatCategory: VatCategorySchema.nullish(), // BT-102 (défaut "S")
    shippingCostVatRate: VatRateStringSchema.nullish(), // BT-103
    /** BT-X-22 INCOTERM (finding K1) — whitelist 13 codes FR EXTENDED-CTC-FR.
     *  null = aucun (clé omise XML). Mode avancé (persona Claire B2BInt). */
    incoterm: IncotermCodeSchema.nullish(),
    payment: z
      .object({
        paymentTerms: PaymentTermsSchema,
        paymentMethodKind: PaymentMethodKindSchema,
        /** BT-81 UNTDID 4461 — override mode avancé (sinon mapping
         *  automatique côté formToModel selon paymentMethodKind). */
        paymentMeansCode: PaymentMeansCodeSchema.nullish(),
        /** BT-90 référence créancier SEPA (ICS). */
        creditorReference: z.string().max(35).nullish(),
        /** BT-113 acompte versé — déduit du DuePayableAmount BT-115. */
        prepaidAmount: AmountStringSchema.nullish(),
        /** Pénalités custom (override defaults customer). */
        customPenalties: z.string().max(500).nullish(),
        mentionsLegales: z.string().max(500).nullish(),
      })
      .strict(),
    /** Métadonnées Repartir (T-CL-UI-01 `<RestartedFromBanner>`) — émises
     *  par `POST /api/invoices/:id/restart`, conservées au draft puis
     *  consommées par l'UI pour afficher le bandeau. Pas mappées Factur-X. */
    restartedFromInvoiceId: z.string().uuid().nullish(),
    restartedFromNumber: z.string().nullish(),
    ...PrecedingInvoiceFields,
  })
  .strict();
export type InvoiceFormAdvanced = z.infer<typeof InvoiceFormAdvancedSchema>;

// ─────────────────────────────────────────────────────────────────────
// InvoiceFormSchema — discriminated union
// ─────────────────────────────────────────────────────────────────────

export const InvoiceFormSchema = z.discriminatedUnion("ui_mode", [
  InvoiceFormBaseSchema,
  InvoiceFormAdvancedSchema,
]);
export type InvoiceForm = z.infer<typeof InvoiceFormSchema>;

// ─────────────────────────────────────────────────────────────────────
// Draft permissif (auto-save 5s côté UI — POST /api/invoice-drafts)
// ─────────────────────────────────────────────────────────────────────

/** Le brouillon stocke l'état partiel/cassé du formulaire. La
 *  validation stricte n'a lieu qu'au POST /api/invoices (envoi
 *  effectif). On accepte donc n'importe quelle forme JSON ici, avec
 *  un seul invariant : `ui_mode` reste un discriminator lisible. */
export const InvoiceFormDraftPayloadSchema = z
  .object({
    ui_mode: z.enum(["base", "advanced"]).default("base"),
  })
  .passthrough();
export type InvoiceFormDraftPayload = z.infer<typeof InvoiceFormDraftPayloadSchema>;

/** Complétion % par section pour le Stepper UI (consommée par le
 *  composant `InvoiceFormStepper` T-CL-UI-01). */
export const InvoiceDraftStepCompletedSchema = z
  .object({
    document: z.number().min(0).max(100),
    parties: z.number().min(0).max(100),
    lines: z.number().min(0).max(100),
    payment: z.number().min(0).max(100),
  })
  .partial();
export type InvoiceDraftStepCompleted = z.infer<typeof InvoiceDraftStepCompletedSchema>;

// ─────────────────────────────────────────────────────────────────────
// Contrats endpoints — POST /api/invoices/preview + create + restart
// + check-number-unique + CRUD drafts
// ─────────────────────────────────────────────────────────────────────

/** POST /api/invoices/preview — pipeline complet SANS persist. */
export const InvoicePreviewResponseSchema = z
  .object({
    /** PDF Factur-X encodé base64 (consommable iframe / canvas UI). */
    pdfBytes: z.string(),
    /** XML CII brut — seulement en mode avancé (panneau "Voir l'XML"). */
    xmlPreview: z.string().nullable(),
    /** Avertissements non bloquants (cardinality conseillée, BR douces). */
    warnings: z
      .array(
        z
          .object({
            code: z.string(),
            message: z.string(),
            field: z.string().nullable(),
          })
          .strict(),
      )
      .default([]),
  })
  .strict();
export type InvoicePreviewResponse = z.infer<typeof InvoicePreviewResponseSchema>;

/** POST /api/invoices/check-number-unique — débounce 400ms UI. */
export const CheckNumberUniqueRequestSchema = z
  .object({
    number: InvoiceNumberSchema,
  })
  .strict();
export type CheckNumberUniqueRequest = z.infer<typeof CheckNumberUniqueRequestSchema>;

export const CheckNumberUniqueResponseSchema = z
  .object({
    available: z.boolean(),
    /** Prochain numéro suggéré (détection pattern + increment +
     *  fallback `F-<year>-0001`). */
    suggestion: z.string(),
    /** Si !available, id de la facture en collision pour CTA UI
     *  "Voir la facture F-2026-0029". */
    existingInvoiceId: z.string().uuid().nullable(),
  })
  .strict();
export type CheckNumberUniqueResponse = z.infer<typeof CheckNumberUniqueResponseSchema>;

/** Forme renvoyée par GET /api/invoices/:id + créée par POST. */
export const InvoiceResponseSchema = z
  .object({
    id: z.string().uuid(),
    customer_id: z.string().uuid(),
    number: z.string(),
    issue_date: z.string(), // ISO date
    tracking_id: z.string().uuid(),
    total_ht: z.string(),
    total_vat: z.string(),
    total_ttc: z.string(),
    currency: z.string(),
    processing_rule: z.enum(["B2B", "B2BInt"]),
    type_code: z.string(),
    /** BG-3 — UUID de la facture d'origine (L11 avoir/rectificative). NULL
     *  pour une facture standard. */
    preceding_invoice_id: z.string().uuid().nullable(),
    pa_invoice_id: z.string().nullable(),
    pa_provider: z.string(),
    sha256: z.string().nullable(),
    submitted_at: z.string().nullable(),
    status_current: z.string().nullable(),
    payload_extended: z.record(z.unknown()),
    created_at: z.string(),
    updated_at: z.string(),
  })
  .strict();
export type InvoiceResponse = z.infer<typeof InvoiceResponseSchema>;

/** Forme ligne renvoyée GET /api/invoices/:id. */
export const InvoiceLineResponseSchema = z
  .object({
    id: z.string().uuid(),
    invoice_id: z.string().uuid(),
    line_number: z.number().int(),
    label: z.string(),
    description: z.string().nullable(),
    quantity: z.string(),
    unit_code: z.string(),
    unit_price_ht: z.string(),
    vat_rate: z.string().nullable(),
    vat_category: VatCategorySchema,
    total_ht: z.string(),
    period_start: z.string().nullable(),
    period_end: z.string().nullable(),
    allowance_amount: z.string().nullable(),
    charge_amount: z.string().nullable(),
    payload_extended: z.record(z.unknown()),
  })
  .strict();
export type InvoiceLineResponse = z.infer<typeof InvoiceLineResponseSchema>;

/** Forme event CDAR renvoyée GET /api/invoices/:id + SSE stream.
 *  Schéma aligné avec la migration T-CL-PA-EXT `cdar_events` :
 *  pas de `received_at` séparé — on utilise `created_at`. */
export const CdarEventResponseSchema = z
  .object({
    id: z.string().uuid(),
    invoice_id: z.string().uuid(),
    code: z.string(),
    label: z.string().nullable(),
    occurred_at: z.string(),
    payload: z.record(z.unknown()),
    // 'app' = CDAR posé par l'utilisateur via l'app (pose 212 Encaissée
    // mark-paid sprint-06) — aligne l'émission sur incoming_cdar_events.
    source: z.enum(["webhook", "polling", "synthetic", "app"]),
    reason: z.string().nullable(),
    created_at: z.string(),
  })
  .strict();
export type CdarEventResponse = z.infer<typeof CdarEventResponseSchema>;

/** POST /api/invoices — réponse 201 du pipeline transactionnel.
 *  T-CL-PA-INVOICE-FIX rename `flow_id → pa_invoice_id` (ADR-010 v2 D7
 *  — SuperPDP `invoice.id` integer stringifié). Le frontend Bloc 3
 *  n'étant pas encore livré, le rename n'introduit pas de breaking
 *  change. */
/** Résultat de la pose automatique 209 sur la facture d'origine à l'envoi
 *  d'une rectificative 384 (brief §3.1.2). `cancelled = false` = pose
 *  tentée mais non transmise (PA indisponible / origine non transmise) →
 *  toast dégradé côté UI (Z2 non bloquant, ADR-009). `null` = pas une
 *  rectificative liée. */
export const PrecedingCancellationSchema = z
  .object({
    preceding_invoice_id: z.string().uuid(),
    preceding_number: z.string(),
    cancelled: z.boolean(),
  })
  .strict();
export type PrecedingCancellation = z.infer<typeof PrecedingCancellationSchema>;

export const InvoiceCreateResponseSchema = z
  .object({
    invoice: InvoiceResponseSchema,
    lines: z.array(InvoiceLineResponseSchema),
    cdar_events: z.array(CdarEventResponseSchema),
    pa_invoice_id: z.string(),
    /** L11 — pose 209 auto sur l'origine (rectificative 384 uniquement). */
    preceding_cancellation: PrecedingCancellationSchema.nullable().default(null),
  })
  .strict();
export type InvoiceCreateResponse = z.infer<typeof InvoiceCreateResponseSchema>;

/** POST /api/invoices/:id/restart — réponse 201 clone vers draft. */
export const InvoiceRestartResponseSchema = z
  .object({
    newDraftId: z.string().uuid(),
  })
  .strict();
export type InvoiceRestartResponse = z.infer<typeof InvoiceRestartResponseSchema>;

// ─────────────────────────────────────────────────────────────────────
// L11 — POST /api/invoices/:id/credit-note (avoir 381 / rectificative 384)
// ─────────────────────────────────────────────────────────────────────

/** Body POST /api/invoices/:id/credit-note — seul le type est requis ;
 *  l'origine est l'`:id` de l'URL, les lignes sont copiées côté backend. */
export const CreditNoteRequestSchema = z
  .object({
    type_code: CreditNoteTypeCodeSchema,
  })
  .strict();
export type CreditNoteRequest = z.infer<typeof CreditNoteRequestSchema>;

/** Réponse 201 — l'avoir/rectificative est matérialisé comme un brouillon
 *  pré-rempli (table `invoice_drafts`, pattern `POST /:id/restart`). Le
 *  frontend redirige vers `/emission/new?draft_id={newDraftId}`. La ligne
 *  `invoices` définitive n'est créée qu'à l'envoi PA (POST /api/invoices). */
export const CreditNoteResponseSchema = z
  .object({
    newDraftId: z.string().uuid(),
    type_code: CreditNoteTypeCodeSchema,
  })
  .strict();
export type CreditNoteResponse = z.infer<typeof CreditNoteResponseSchema>;

/** Résumé compact d'une facture liée (origine ou enfant) — consommé par
 *  `LinkedInvoiceBanner` (slot data injection runtime ADR-013 D4). */
export const LinkedInvoiceSummarySchema = z
  .object({
    id: z.string().uuid(),
    number: z.string(),
    issue_date: z.string(),
    type_code: z.string(),
    status_current: z.string().nullable(),
  })
  .strict();
export type LinkedInvoiceSummary = z.infer<typeof LinkedInvoiceSummarySchema>;

/** GET /api/invoices/:id — réponse fiche enrichie L11. `preceding_invoice`
 *  = origine (pour un avoir/rectificative) ; `linked_invoices` = documents
 *  enfants (pour une facture d'origine ayant des avoirs/rectificatives). */
export const InvoiceDetailResponseSchema = z
  .object({
    invoice: InvoiceResponseSchema,
    lines: z.array(InvoiceLineResponseSchema),
    cdar_events: z.array(CdarEventResponseSchema),
    preceding_invoice: LinkedInvoiceSummarySchema.nullable(),
    linked_invoices: z.array(LinkedInvoiceSummarySchema),
  })
  .strict();
export type InvoiceDetailResponse = z.infer<typeof InvoiceDetailResponseSchema>;

// ─────────────────────────────────────────────────────────────────────
// GET /api/invoices — liste filtrée + pagination
// ─────────────────────────────────────────────────────────────────────

/** Booléen-string pour query params HTTP. */
const BoolQuerySchema = z
  .union([z.literal("true"), z.literal("false")])
  .optional()
  .transform((v) => v === "true");

export const InvoiceListQuerySchema = z
  .object({
    /**
     * Statut(s) CDAR filtré(s). Accepte une valeur unique (`"submitted"`) OU
     * un CSV (`"submitted,validated,transmitting,received,available_to_recipient,in_process"`)
     * pour les pills multi-statuts (cf. `FILTER_STATUS_MAP` apps/web). Le repo
     * `findActiveInvoicesByCustomerId` split sur `,` et utilise `ANY(text[])`.
     * Max 500 pour permettre un CSV de tous les `FacturEStatusCode` (T-CL-UI
     * pivot 2026-05-18 — Z2 levée du bug filtres "refresh hang"). Enum 21
     * valeurs post refonte AFNOR XP Z12-013 T-CL-PA-STATUS-RFC sprint-05.
     */
    status: z.string().min(1).max(500).optional(),
    /** Filtre type de document BT-3 (pills L11 "Avoirs" 381 / "Rectificatives"
     *  384). Accepte une valeur unique ou un CSV (`"381,384"`). */
    type_code: z.string().min(1).max(50).optional(),
    client: z
      .string()
      .regex(/^\d{9}$/)
      .optional(),
    date_from: z.string().date().optional(),
    date_to: z.string().date().optional(),
    min_amount: z.coerce.number().min(0).optional(),
    max_amount: z.coerce.number().min(0).optional(),
    search: z.string().min(1).max(200).optional(),
    /**
     * Filtre rétention (sprint-07 T-CL-W3-C finding S). `"expiring"` = factures
     * éligibles export approchant leur purge : `exported_at IS NULL` et
     * `purge_at <= NOW() + 30 jours` (purge_at = `created_at + 6 mois`, même
     * ancre que `GET /api/dashboard/retention-alerts`). Alimente le lien
     * `ExportRappelBanner` "Voir les factures pour lancer l'export".
     */
    retention: z.literal("expiring").optional(),
    include_drafts: BoolQuerySchema,
    limit: z.coerce.number().int().min(1).max(200).optional().default(50),
    offset: z.coerce.number().int().min(0).optional().default(0),
  })
  .strict();
export type InvoiceListQuery = z.infer<typeof InvoiceListQuerySchema>;

/** Item liste enrichi L11 : `InvoiceResponse` + résolution du lien BG-3 pour
 *  afficher l'icône "Lien" + le badge "Type" sans re-fetch (brief §3.2.4 /
 *  §4.7). `preceding_invoice_number` = numéro origine (avoir/rectificative) ;
 *  `linked_children_count` = nb d'avoirs/rectificatives pointant cette facture. */
export const InvoiceListItemSchema = InvoiceResponseSchema.extend({
  preceding_invoice_number: z.string().nullable().default(null),
  linked_children_count: z.number().int().min(0).default(0),
});
export type InvoiceListItem = z.infer<typeof InvoiceListItemSchema>;

export const InvoiceListResponseSchema = z
  .object({
    items: z.array(InvoiceListItemSchema),
    total: z.number().int().min(0),
    limit: z.number().int().min(1),
    offset: z.number().int().min(0),
  })
  .strict();
export type InvoiceListResponse = z.infer<typeof InvoiceListResponseSchema>;

// ─────────────────────────────────────────────────────────────────────
// CRUD /api/invoice-drafts
// ─────────────────────────────────────────────────────────────────────

export const InvoiceDraftResponseSchema = z
  .object({
    id: z.string().uuid(),
    customer_id: z.string().uuid(),
    payload: z.record(z.unknown()),
    step_completed: z.record(z.unknown()),
    last_modified_at: z.string(),
    created_at: z.string(),
  })
  .strict();
export type InvoiceDraftResponse = z.infer<typeof InvoiceDraftResponseSchema>;

export const InvoiceDraftCreateBodySchema = z
  .object({
    payload: InvoiceFormDraftPayloadSchema,
    step_completed: InvoiceDraftStepCompletedSchema.optional(),
  })
  .strict();
export type InvoiceDraftCreateBody = z.infer<typeof InvoiceDraftCreateBodySchema>;

export const InvoiceDraftUpdateBodySchema = z
  .object({
    payload: InvoiceFormDraftPayloadSchema.optional(),
    step_completed: InvoiceDraftStepCompletedSchema.optional(),
  })
  .strict()
  .refine(
    (b) => b.payload !== undefined || b.step_completed !== undefined,
    "Au moins un champ à mettre à jour requis.",
  );
export type InvoiceDraftUpdateBody = z.infer<typeof InvoiceDraftUpdateBodySchema>;

export const InvoiceDraftListResponseSchema = z
  .object({
    items: z.array(InvoiceDraftResponseSchema),
  })
  .strict();
export type InvoiceDraftListResponse = z.infer<typeof InvoiceDraftListResponseSchema>;
