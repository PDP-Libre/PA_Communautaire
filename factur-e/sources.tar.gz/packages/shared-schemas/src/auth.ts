import { z } from "zod";

export const SIGNUP_STEPS = [
  "siren",
  "siret",
  "email_verify",
  "secondary_email",
  "mfa_choice",
  "mfa_setup",
  "recovery_codes",
] as const;

export const SignupStepSchema = z.enum(SIGNUP_STEPS);
export type SignupStep = z.infer<typeof SignupStepSchema>;

const passwordSchema = z
  .string()
  .min(12, "Mot de passe trop court (12 caractères minimum).")
  .max(256)
  .refine((v) => /[A-Z]/.test(v), "Mot de passe doit contenir au moins une majuscule.")
  .refine((v) => /[0-9]/.test(v), "Mot de passe doit contenir au moins un chiffre.")
  .refine(
    (v) => /[^A-Za-z0-9]/.test(v),
    "Mot de passe doit contenir au moins un caractère spécial.",
  );

export const SignupBodySchema = z
  .object({
    email: z.string().email().max(254),
    password: passwordSchema,
    terms_accepted: z.literal(true),
  })
  .strict();
export type SignupBody = z.infer<typeof SignupBodySchema>;

export const LoginBodySchema = z
  .object({
    email: z.string().email().max(254),
    password: z.string().min(1).max(256),
  })
  .strict();
export type LoginBody = z.infer<typeof LoginBodySchema>;

export const SignupResponseSchema = z
  .object({
    state: z.literal("pending"),
    current_step: SignupStepSchema,
  })
  .strict();
export type SignupResponse = z.infer<typeof SignupResponseSchema>;

export const LoginResponseSchema = z
  .object({
    access_token: z.string(),
    expires_in: z.number().int().positive(),
  })
  .strict();
export type LoginResponse = z.infer<typeof LoginResponseSchema>;

export const MfaModeSchema = z.enum(["none", "email", "totp"]);
export type MfaMode = z.infer<typeof MfaModeSchema>;

export const MfaModeChoiceSchema = z.enum(["email", "totp"]);
export type MfaModeChoice = z.infer<typeof MfaModeChoiceSchema>;

export const PublicUserSchema = z
  .object({
    id: z.string().uuid(),
    email: z.string().email(),
    role: z.enum(["deposit_simple", "deposit_states", "full"]),
    can_purchase: z.boolean(),
    email_verified_at: z.string().datetime().nullable(),
    mfa_mode: MfaModeSchema,
    mfa_reset_required: z.boolean(),
    /** TRUE quand `secondary_email_verified_at IS NOT NULL` côté BDD.
     *  Le router SPA combine `mfa_reset_required=TRUE` + `secondary_email_set=FALSE`
     *  pour détecter un user invité en milieu d'onboarding et l'envoyer
     *  vers `/onboarding/invite/secondary-email` (T-CL-15 sprint-03).
     *  L'email de secours lui-même n'est pas exposé (PII). */
    secondary_email_set: z.boolean(),
  })
  .strict();
export type PublicUser = z.infer<typeof PublicUserSchema>;

export const PublicCustomerSchema = z
  .object({
    id: z.string().uuid(),
    siren: z.string().regex(/^\d{9}$/),
    legal_name: z.string(),
    trading_name: z.string().nullable(),
    primary_color: z.string().regex(/^#[0-9A-Fa-f]{6}$/),
    /** TRUE quand le profil légal (legal_name + adresse) a été saisi
     *  manuellement (diffusion partielle INSEE typiquement) et n'a pas
     *  encore été confirmé par la PA. Les UIs doivent afficher un badge
     *  "à confirmer" tant que ce flag est vrai. */
    profile_unverified: z.boolean(),
  })
  .strict();
export type PublicCustomer = z.infer<typeof PublicCustomerSchema>;

export const AuthMeResponseSchema = z.discriminatedUnion("state", [
  z
    .object({
      state: z.literal("pending"),
      current_step: SignupStepSchema,
      email: z.string().email(),
    })
    .strict(),
  z
    .object({
      state: z.literal("authenticated"),
      user: PublicUserSchema,
      customer: PublicCustomerSchema,
    })
    .strict(),
]);
export type AuthMeResponse = z.infer<typeof AuthMeResponseSchema>;

export const AuthErrorBodySchema = z
  .object({
    message: z.string(),
  })
  .strict();
export type AuthErrorBody = z.infer<typeof AuthErrorBodySchema>;

// ─────────────────────────────────────────────────────────────────────────
// MFA — phase 1 setup (T-CL-03 §3a)
// ─────────────────────────────────────────────────────────────────────────

export const MfaChooseBodySchema = z
  .object({
    mode: MfaModeChoiceSchema,
  })
  .strict();
export type MfaChooseBody = z.infer<typeof MfaChooseBodySchema>;

export const MfaChooseResponseSchema = z.discriminatedUnion("mode", [
  z
    .object({
      mode: z.literal("email"),
      otp_sent_to: z.string().email(),
    })
    .strict(),
  z
    .object({
      mode: z.literal("totp"),
      otpauth_uri: z.string(),
      qr_svg: z.string(),
    })
    .strict(),
]);
export type MfaChooseResponse = z.infer<typeof MfaChooseResponseSchema>;

export const Phase1MfaVerifyBodySchema = z
  .object({
    code: z.string().regex(/^\d{6}$/, "Code à 6 chiffres."),
  })
  .strict();
export type Phase1MfaVerifyBody = z.infer<typeof Phase1MfaVerifyBodySchema>;

export const Phase1MfaVerifyResponseSchema = z
  .object({
    recovery_codes: z.array(z.string()).length(10),
  })
  .strict();
export type Phase1MfaVerifyResponse = z.infer<typeof Phase1MfaVerifyResponseSchema>;

export const RecoveryCodesAckBodySchema = z
  .object({
    ack: z.literal(true),
  })
  .strict();
export type RecoveryCodesAckBody = z.infer<typeof RecoveryCodesAckBodySchema>;

// `recovery-codes/ack` triggers `finalizePhase1` internally; on success it
// returns the same shape as a normal login (access token in body + refresh
// cookie set in headers).
export const RecoveryCodesAckResponseSchema = LoginResponseSchema;
export type RecoveryCodesAckResponse = LoginResponse;

// ─────────────────────────────────────────────────────────────────────────
// MFA — login challenge (T-CL-03 §3b)
// ─────────────────────────────────────────────────────────────────────────

export const LoginMfaRequiredResponseSchema = z
  .object({
    state: z.literal("mfa_required"),
    mfa_challenge_token: z.string(),
    mfa_mode: MfaModeChoiceSchema,
  })
  .strict();
export type LoginMfaRequiredResponse = z.infer<typeof LoginMfaRequiredResponseSchema>;

export const LoginMfaResetRequiredResponseSchema = z
  .object({
    state: z.literal("mfa_reset_required"),
    reset_token: z.string(),
  })
  .strict();
export type LoginMfaResetRequiredResponse = z.infer<typeof LoginMfaResetRequiredResponseSchema>;

export const AuthMfaVerifyBodySchema = z
  .object({
    mfa_challenge_token: z.string().min(1),
    code: z
      .string()
      .regex(/^\d{6}$/, "Code à 6 chiffres.")
      .optional(),
    recovery_code: z.string().min(1).max(32).optional(),
  })
  .strict()
  .refine(
    (b) => (b.code === undefined) !== (b.recovery_code === undefined),
    "Fournissez exactement un de `code` ou `recovery_code`.",
  );
export type AuthMfaVerifyBody = z.infer<typeof AuthMfaVerifyBodySchema>;

// ─────────────────────────────────────────────────────────────────────────
// MFA — reset via recovery (T-CL-03 §3d)
// ─────────────────────────────────────────────────────────────────────────

export const MfaResetViaRecoveryBodySchema = z
  .object({
    recovery_code: z.string().min(1).max(32),
  })
  .strict();
export type MfaResetViaRecoveryBody = z.infer<typeof MfaResetViaRecoveryBodySchema>;

// ─────────────────────────────────────────────────────────────────────────
// Email verify + secondary email + password reset (T-CL-04)
// ─────────────────────────────────────────────────────────────────────────

export const Phase1SecondaryEmailSetBodySchema = z
  .object({
    email: z.string().email().max(254),
  })
  .strict();
export type Phase1SecondaryEmailSetBody = z.infer<typeof Phase1SecondaryEmailSetBodySchema>;

export const Phase1SecondaryEmailVerifyBodySchema = z
  .object({
    code: z.string().regex(/^\d{6}$/, "Code à 6 chiffres."),
  })
  .strict();
export type Phase1SecondaryEmailVerifyBody = z.infer<typeof Phase1SecondaryEmailVerifyBodySchema>;

export const PasswordResetRequestBodySchema = z
  .object({
    email: z.string().email().max(254),
  })
  .strict();
export type PasswordResetRequestBody = z.infer<typeof PasswordResetRequestBodySchema>;

const passwordResetPasswordSchema = z
  .string()
  .min(12, "Mot de passe trop court (12 caractères minimum).")
  .max(256)
  .refine((v) => /[A-Z]/.test(v), "Mot de passe doit contenir au moins une majuscule.")
  .refine((v) => /[0-9]/.test(v), "Mot de passe doit contenir au moins un chiffre.")
  .refine(
    (v) => /[^A-Za-z0-9]/.test(v),
    "Mot de passe doit contenir au moins un caractère spécial.",
  );

export const PasswordResetCompleteBodySchema = z
  .object({
    token: z.string().min(1),
    password: passwordResetPasswordSchema,
  })
  .strict();
export type PasswordResetCompleteBody = z.infer<typeof PasswordResetCompleteBodySchema>;

// ─────────────────────────────────────────────────────────────────────────
// Invitation accept — secondary email funnel (T-CL-15 sprint-03)
// ─────────────────────────────────────────────────────────────────────────

/** POST /auth/accept-invitation/secondary-email/set — saisie de l'email
 *  de secours par un user invité. La validation `≠ primary` se fait côté
 *  serveur (le serveur connaît l'email primaire via user_id du Bearer). */
export const InviteSecondaryEmailSetBodySchema = z
  .object({
    email: z.string().email().max(254),
  })
  .strict();
export type InviteSecondaryEmailSetBody = z.infer<typeof InviteSecondaryEmailSetBodySchema>;

/** POST /auth/accept-invitation/secondary-email/verify — saisie de l'OTP
 *  reçu sur l'email de secours. */
export const InviteSecondaryEmailVerifyBodySchema = z
  .object({
    code: z.string().regex(/^\d{6}$/, "Code à 6 chiffres."),
  })
  .strict();
export type InviteSecondaryEmailVerifyBody = z.infer<typeof InviteSecondaryEmailVerifyBodySchema>;

/** Réponse `/verify` : le `reset_token` permet d'enchaîner sur
 *  `/auth/setup-mfa` (T-CL-09 sprint-02) sans repasser par /auth/login. */
export const InviteSecondaryEmailVerifyResponseSchema = z
  .object({
    reset_token: z.string().min(1),
    expires_in: z.number().int().positive(),
  })
  .strict();
export type InviteSecondaryEmailVerifyResponse = z.infer<
  typeof InviteSecondaryEmailVerifyResponseSchema
>;

/** POST /auth/mfa/setup-context — hints policy pour SetupMfa.tsx
 *  (T-CL-15 sprint-03 + ADR-006 §D3 enforcement TOTP-only). Permet au
 *  SPA de masquer l'option email pour les rôles privilégiés et de
 *  choisir le wording « Configurez » vs « Reconfigurez ». */
export const MfaSetupContextBodySchema = z
  .object({
    reset_token: z.string().min(1),
  })
  .strict();
export type MfaSetupContextBody = z.infer<typeof MfaSetupContextBodySchema>;

export const MfaSetupContextResponseSchema = z
  .object({
    /** TRUE si `role === 'full'` OU `can_purchase === true` (ADR-006 D3).
     *  SPA doit masquer l'option email et afficher la copie pédagogique D4. */
    requires_totp: z.boolean(),
    /** TRUE si `mfa_mode === 'none'` côté BDD — invité en première
     *  configuration. SPA bascule sur "Configurez votre 2FA" plutôt que
     *  "Reconfigurez". */
    is_first_time: z.boolean(),
  })
  .strict();
export type MfaSetupContextResponse = z.infer<typeof MfaSetupContextResponseSchema>;
