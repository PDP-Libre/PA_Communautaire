import { z } from "zod";

/**
 * Profile contracts — phase 2 onboarding (brief §6.16 to §6.19) + the
 * post-onboarding edits ("Paramètres" page once the customer is live).
 *
 * IBAN/BIC validation is left to the route layer (uses `apps/api/src/
 * profile/iban.ts` MOD 97 check); here we just enforce format envelope.
 */

// ─────────────────────────────────────────────────────────────────────────
// §6.16 User profile
// ─────────────────────────────────────────────────────────────────────────

export const UserProfilePatchBodySchema = z
  .object({
    first_name: z.string().min(1).max(50),
    last_name: z.string().min(1).max(50),
    function_title: z.string().max(80).optional(),
  })
  .strict();
export type UserProfilePatchBody = z.infer<typeof UserProfilePatchBodySchema>;

// ─────────────────────────────────────────────────────────────────────────
// §6.17 Seller profile
// ─────────────────────────────────────────────────────────────────────────

const ibanShape = z.string().min(15).max(42); // 34 + spaces tolerance
const bicShape = z.string().min(8).max(11);
const colorShape = z.string().regex(/^#[0-9A-Fa-f]{6}$/, "Code couleur hex #RRGGBB.");
const capitalShape = z.union([
  z.number().nonnegative().finite(),
  z.string().regex(/^\d+(\.\d{1,2})?$/, "Capital social numérique avec 2 décimales max."),
]);

export const CustomerProfilePatchBodySchema = z
  .object({
    trading_name: z.string().min(1).max(100).optional(),
    iban: ibanShape.optional(),
    bic: bicShape.optional(),
    capital_social: capitalShape.optional(),
    mentions_legales: z.string().max(500).optional(),
    primary_color: colorShape.optional(),
  })
  .strict()
  .refine((b) => Object.keys(b).length > 0, "Au moins un champ à mettre à jour.");
export type CustomerProfilePatchBody = z.infer<typeof CustomerProfilePatchBodySchema>;

// ─────────────────────────────────────────────────────────────────────────
// §6.19 Default invoice values (JSONB on customers.default_invoice_values)
// ─────────────────────────────────────────────────────────────────────────

export const PaymentTermsSchema = z.enum([
  "on_receipt",
  "net_15",
  "net_30",
  "net_30_eom",
  "net_45_eom",
]);
export type PaymentTerms = z.infer<typeof PaymentTermsSchema>;

/** Standard French VAT rates (PRD §7.7.4). 0 = exonéré (mention TVA non
 *  applicable, art. 293 B CGI). */
export const VatRateSchema = z.union([
  z.literal(0),
  z.literal(2.1),
  z.literal(5.5),
  z.literal(10),
  z.literal(20),
]);
export type VatRate = z.infer<typeof VatRateSchema>;

/** ISO 4217 — three uppercase letters. We don't enumerate (USD/GBP/CHF…
 *  are common; EUR is the default for FR-billing TPEs). */
export const CurrencyCodeSchema = z
  .string()
  .length(3)
  .regex(/^[A-Z]{3}$/);

export const PenaltyConfigSchema = z
  .object({
    rate: z.number().nonnegative().max(50),
    base: z.enum(["monthly_legal", "fixed"]),
  })
  .strict();
export type PenaltyConfig = z.infer<typeof PenaltyConfigSchema>;

export const DefaultInvoiceValuesSchema = z
  .object({
    currency: CurrencyCodeSchema.default("EUR"),
    payment_terms: PaymentTermsSchema.default("net_30"),
    vat_rate_default: VatRateSchema.default(20),
    footer_mention: z.string().max(200).optional(),
    vat_on_encashment: z.boolean().default(false),
    penalty: PenaltyConfigSchema.optional(),
  })
  .strict();
export type DefaultInvoiceValues = z.infer<typeof DefaultInvoiceValuesSchema>;

export const DefaultInvoiceValuesPutBodySchema = DefaultInvoiceValuesSchema;
export type DefaultInvoiceValuesPutBody = DefaultInvoiceValues;

// ─────────────────────────────────────────────────────────────────────────
// Paramètres > Entreprise (T-CL-WEB-SETTINGS-ENTREPRISE-V1 sprint-05)
// ─────────────────────────────────────────────────────────────────────────

/** Numéro de TVA intracommunautaire FR (BR-S-02 / BT-31). Format strict :
 *  FR + 2 caractères de contrôle (chiffre OU lettre A-H/J-N/P-Z, pas I/O) +
 *  SIREN 9 chiffres. Schematron BR-FR strict consomme `customers.vat_number`
 *  comme `BT-31 Seller VAT Identifier` à l'émission.
 *
 *  Saisie tolérante (sprint-05 followups #2) : on accepte les espaces et
 *  variations de casse à la saisie (les users copient typiquement la TVA
 *  depuis des docs officiels avec des espaces — "FR 12 821 456 789"). Le
 *  `.transform()` strip les espaces + uppercase AVANT le regex check. La
 *  valeur stockée en BDD est toujours la version normalisée. */
const vatNumberShape = z
  .string()
  .transform((s) => s.replace(/\s+/g, "").toUpperCase())
  .refine(
    (s) => /^FR[0-9A-HJ-NP-Z]{2}\d{9}$/.test(s),
    "Format attendu : FR + 2 caractères + SIREN (9 chiffres).",
  );

export const UiModeDefaultSchema = z.enum(["basic", "advanced"]);
export type UiModeDefault = z.infer<typeof UiModeDefaultSchema>;

/** Body PATCH /customers/me/settings — 3 champs nouveaux exposés sprint-05
 *  W1 SETTINGS (les autres champs entreprise sont déjà couverts par les
 *  endpoints PATCH /customers/me/profile, POST /customers/me/logo,
 *  PUT /customers/me/default-invoice-values). */
export const CustomerSettingsPatchBodySchema = z
  .object({
    vat_number: vatNumberShape.optional(),
    vat_on_encashment: z.boolean().optional(),
    ui_mode_default: UiModeDefaultSchema.optional(),
  })
  .strict()
  .refine((b) => Object.keys(b).length > 0, "Au moins un champ à mettre à jour.");
export type CustomerSettingsPatchBody = z.infer<typeof CustomerSettingsPatchBodySchema>;

/** Réponse GET /customers/me/settings — vue consolidée pour la page
 *  Paramètres > Entreprise. Données INSEE lecture seule + champs éditables
 *  exposés par les différents endpoints existants + 3 champs sprint-05.
 *
 *  IBAN n'est jamais retourné en clair (chiffré applicatif `v1:`
 *  AES-256-GCM côté BDD). Deux vues exposées : `has_iban` (booléen, pour
 *  l'état du formulaire Paramètres) et `iban_display` (masqué — code pays
 *  + clé + 4 derniers chiffres, pour l'affichage lecture seule en émission
 *  / aperçu PDF, NC-3 sprint-05). Logo via URL signée si présent. Peppol
 *  address en lecture seule (édition déléguée à PaConnection.tsx). */
export const CustomerSettingsResponseSchema = z
  .object({
    // INSEE lecture seule
    siren: z.string().regex(/^\d{9}$/),
    legal_name: z.string(),
    naf_code: z.string().nullable(),
    juridique_code: z.string().nullable(),
    rcs: z.string().nullable(),
    capital_social: z.string().nullable(),
    address: z.record(z.string(), z.unknown()),
    profile_unverified: z.boolean(),
    // T-CL-SIREN-RECONCILIATION sprint-06 W1 — flags champ-spécifiques
    // (Mécanisme 1, ADR-007ter D1 candidat). Pilotent le badge "À
    // confirmer" par attribut. V1 UI : seul `siren_unverified` (+
    // `legal_name_unverified`) est rendu (Entreprise.tsx) ; les 2 autres
    // sont exposés pour la cascade W1 suivante (CAPITAL-SOCIAL/LIBELLES).
    siren_unverified: z.boolean(),
    legal_name_unverified: z.boolean(),
    address_unverified: z.boolean(),
    vat_number_unverified: z.boolean(),
    // Identité commerciale
    trading_name: z.string().nullable(),
    vat_number: z.string().nullable(),
    // Bancaire (IBAN jamais en clair — voir commentaire ci-dessus)
    has_iban: z.boolean(),
    iban_display: z.string().nullable(),
    bic: z.string().nullable(),
    // Branding
    logo_url: z.string().nullable(),
    primary_color: z.string().regex(/^#[0-9A-Fa-f]{6}$/),
    // Mentions légales
    legal_mentions: z.string().nullable(),
    // Défauts facture (structure existante sprint-02, pas brief §4)
    default_invoice_values: z.record(z.string(), z.unknown()),
    // Préférences (sprint-05)
    vat_on_encashment: z.boolean(),
    ui_mode_default: UiModeDefaultSchema,
    // Peppol (lecture seule — édition via PaConnection)
    directory_address: z.string().nullable(),
  })
  .strict();
export type CustomerSettingsResponse = z.infer<typeof CustomerSettingsResponseSchema>;
