import { z } from "zod";

/**
 * Onboarding INSEE Sirene contracts (T-CL-05) — phase 1 §6.2/§6.3.
 */

export const SirenLookupBodySchema = z
  .object({
    siren: z.string().regex(/^\d{9}$/, "Le SIREN doit contenir exactement 9 chiffres."),
  })
  .strict();
export type SirenLookupBody = z.infer<typeof SirenLookupBodySchema>;

const SirenAddressSchema = z
  .object({
    street: z.string().min(1).max(200),
    zip: z.string().min(1).max(10),
    city: z.string().min(1).max(100),
    country_code: z
      .string()
      .length(2)
      .transform((v) => v.toUpperCase()),
  })
  .strict();

const PublicEtablissementSchema = z
  .object({
    siret: z.string().regex(/^\d{14}$/),
    is_siege: z.boolean(),
    creation_date: z.string().nullable(),
    address: SirenAddressSchema,
  })
  .strict();
export type PublicEtablissement = z.infer<typeof PublicEtablissementSchema>;

export const SirenLookupResponseSchema = z.discriminatedUnion("kind", [
  z
    .object({
      kind: z.literal("found"),
      legal_name: z.string(),
      juridique_code: z.string().nullable(),
      juridique_label: z.string(),
      naf_code: z.string().nullable(),
      creation_date: z.string().nullable(),
      establishments: z.array(PublicEtablissementSchema),
    })
    .strict(),
  z.object({ kind: z.literal("not_found") }).strict(),
  z.object({ kind: z.literal("already_bound") }).strict(),
  z.object({ kind: z.literal("restricted") }).strict(),
  z.object({ kind: z.literal("unavailable") }).strict(),
]);
export type SirenLookupResponse = z.infer<typeof SirenLookupResponseSchema>;

/**
 * Phase 1 §6.3 — user picks a SIRET from the INSEE list, OR provides a
 * manual address. Discriminated union keeps the contract explicit.
 *
 * `legal_name` is optional under `kind: "manual"`: when the entreprise is
 * partially diffused (statutDiffusionUniteLegale = "P", typical for
 * personnes physiques), INSEE masks the dénomination as `"[ND]"` and the
 * adapter surfaces an empty `legal_name`. The user is then prompted to
 * type their raison sociale by hand on §6.3 — we accept it here so the
 * route can persist it into `customer_data_prefilled.legal_name`.
 */
export const SiretChooseBodySchema = z.discriminatedUnion("kind", [
  z
    .object({
      kind: z.literal("siret"),
      siret: z.string().regex(/^\d{14}$/),
    })
    .strict(),
  z
    .object({
      kind: z.literal("manual"),
      address: SirenAddressSchema,
      legal_name: z.string().min(1).max(150).optional(),
    })
    .strict(),
]);
export type SiretChooseBody = z.infer<typeof SiretChooseBodySchema>;
