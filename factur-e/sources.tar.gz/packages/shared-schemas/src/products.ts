import { z } from "zod";

/**
 * Products CRUD contracts (T-CL-12 sprint-03 — endpoints `/api/products/*`).
 *
 * Couvre :
 *  - `GET /api/products` (list + filtres + cursor pagination)
 *  - `GET /api/products/:id`
 *  - `POST /api/products`
 *  - `PATCH /api/products/:id`
 *  - `DELETE /api/products/:id?hard=...`
 *
 * Glossaire T-CW-11 : UI dira « Articles » côté SPA (T-CL-14), mais ici
 * les schémas Zod et libellés API restent "products" pour cohérence
 * EN 16931/Factur-X (modèle BT-146 unit_price_ht + BT-151 vat_category).
 * Pas de chaîne UI dans ce périmètre.
 */

// ─────────────────────────────────────────────────────────────────────────
// Primitives partagées
// ─────────────────────────────────────────────────────────────────────────

/** 7 codes TVA EN 16931 BT-151 (cf. migration T-CL-11 CHECK BDD). */
export const VatCategorySchema = z.enum(["S", "AE", "Z", "E", "K", "G", "O"]);
export type VatCategory = z.infer<typeof VatCategorySchema>;

/** Prix HT — string conservée côté serveur pour préserver la précision
 *  décimale EN 16931 BT-146 (4 décimales). On valide la forme numérique
 *  + range positif ; pas de cast `number` (perte de précision possible
 *  pour > 2^53). */
const PriceStringSchema = z
  .string()
  .regex(/^\d+(\.\d{1,4})?$/, "Le prix doit avoir au plus 4 décimales (BT-146).")
  .refine((s) => Number(s) >= 0, "Le prix doit être ≥ 0.");

/** Taux TVA en pourcentage — null pour AE/Z/E/K/G/O qui n'ont pas de
 *  taux applicable, ou string décimale `0..100`. */
const VatRateStringSchema = z
  .string()
  .regex(/^\d+(\.\d{1,2})?$/, "Le taux TVA doit avoir au plus 2 décimales.")
  .refine((s) => {
    const n = Number(s);
    return n >= 0 && n <= 100;
  }, "Le taux TVA doit être compris entre 0 et 100.");

/** Cohérence vat_category ↔ vat_rate : seule la catégorie `S`
 *  (standard) exige un taux explicite non-null. Les autres acceptent
 *  null (AE/Z/E/K/G/O = sans taux applicable). */
function refineVatCoherence(
  obj: { vat_category?: VatCategory; vat_rate?: string | null },
  ctx: z.RefinementCtx,
): void {
  if (obj.vat_category === "S" && (obj.vat_rate === undefined || obj.vat_rate === null)) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      path: ["vat_rate"],
      message: "Le taux TVA est requis pour la catégorie standard (S).",
    });
  }
  if (
    obj.vat_category !== undefined &&
    obj.vat_category !== "S" &&
    obj.vat_rate !== undefined &&
    obj.vat_rate !== null
  ) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      path: ["vat_rate"],
      message: "Le taux TVA doit être null pour cette catégorie de TVA.",
    });
  }
}

// ─────────────────────────────────────────────────────────────────────────
// Response shape
// ─────────────────────────────────────────────────────────────────────────

/** Représentation d'un product dans les réponses API (lecture). */
export const ProductResponseSchema = z
  .object({
    id: z.string().uuid(),
    label: z.string(),
    description: z.string().nullable(),
    internal_code: z.string().nullable(),
    unit_price_ht: z.string(),
    unit: z.string(),
    vat_category: VatCategorySchema,
    vat_rate: z.string().nullable(),
    category_id: z.string().uuid().nullable(),
    is_archived: z.boolean(),
    created_at: z.string(),
    updated_at: z.string(),
  })
  .strict();
export type ProductResponse = z.infer<typeof ProductResponseSchema>;

// ─────────────────────────────────────────────────────────────────────────
// Warnings (non bloquants — retournés au create/update)
// ─────────────────────────────────────────────────────────────────────────

/** Warning `duplicate_internal_code` : retourné quand le `internal_code`
 *  du payload matche un product existant du même customer. Les doublons
 *  sont autorisés (T-CW-10 Q5 acté Bruno) mais l'UI badge la collision
 *  pour avertir l'utilisateur. Discriminated union extensible pour
 *  d'autres warnings futurs. */
export const ProductWarningSchema = z.discriminatedUnion("code", [
  z
    .object({
      code: z.literal("duplicate_internal_code"),
      existing_id: z.string().uuid(),
      existing_label: z.string(),
    })
    .strict(),
]);
export type ProductWarning = z.infer<typeof ProductWarningSchema>;

// ─────────────────────────────────────────────────────────────────────────
// POST /api/products
// ─────────────────────────────────────────────────────────────────────────

export const ProductCreateBodySchema = z
  .object({
    label: z.string().min(1).max(200),
    description: z.string().max(2000).nullish(),
    internal_code: z.string().max(50).nullish(),
    unit_price_ht: PriceStringSchema,
    unit: z.string().min(1).max(20).optional(),
    vat_category: VatCategorySchema,
    vat_rate: VatRateStringSchema.nullish(),
    category_id: z.string().uuid().nullish(),
  })
  .strict()
  .superRefine(refineVatCoherence);
export type ProductCreateBody = z.infer<typeof ProductCreateBodySchema>;

export const ProductCreateResponseSchema = z
  .object({
    product: ProductResponseSchema,
    warnings: z.array(ProductWarningSchema).default([]),
  })
  .strict();
export type ProductCreateResponse = z.infer<typeof ProductCreateResponseSchema>;

// ─────────────────────────────────────────────────────────────────────────
// PATCH /api/products/:id
// ─────────────────────────────────────────────────────────────────────────

/** Update partiel — tous les champs optionnels. La cohérence
 *  `vat_category ↔ vat_rate` est revérifiée mais ne peut s'appliquer
 *  qu'aux champs présents dans le payload ; la route charge le row
 *  existant et le merge avant validation finale. */
export const ProductUpdateBodySchema = z
  .object({
    label: z.string().min(1).max(200).optional(),
    description: z.string().max(2000).nullish(),
    internal_code: z.string().max(50).nullish(),
    unit_price_ht: PriceStringSchema.optional(),
    unit: z.string().min(1).max(20).optional(),
    vat_category: VatCategorySchema.optional(),
    vat_rate: VatRateStringSchema.nullish(),
    category_id: z.string().uuid().nullish(),
  })
  .strict();
export type ProductUpdateBody = z.infer<typeof ProductUpdateBodySchema>;

export const ProductUpdateResponseSchema = ProductCreateResponseSchema;
export type ProductUpdateResponse = z.infer<typeof ProductUpdateResponseSchema>;

// ─────────────────────────────────────────────────────────────────────────
// GET /api/products (list + filtres + pagination cursor)
// ─────────────────────────────────────────────────────────────────────────

/** Cursor opaque encodé `base64url(JSON({label, id}))`. Permet la
 *  pagination stable sur l'ordre `(label ASC, id ASC)` même si des
 *  rows sont insérées entre 2 pages. Le client ne doit pas chercher
 *  à le décoder, juste le renvoyer tel quel pour la page suivante. */
const CursorSchema = z.string().min(1).max(500).optional();

export const ProductListQuerySchema = z
  .object({
    search: z.string().min(1).max(200).optional(),
    category_id: z.string().uuid().optional(),
    /** "true" / "false" en query string ; default false. */
    include_archived: z
      .union([z.literal("true"), z.literal("false")])
      .optional()
      .transform((v) => v === "true"),
    cursor: CursorSchema,
    /** Default 50 ; max 200 pour éviter le rinçage DB. */
    limit: z.coerce.number().int().min(1).max(200).optional(),
  })
  .strict();
export type ProductListQuery = z.infer<typeof ProductListQuerySchema>;

export const ProductListResponseSchema = z
  .object({
    items: z.array(ProductResponseSchema),
    /** Cursor pour la page suivante, ou null si dernière page. */
    next_cursor: z.string().nullable(),
  })
  .strict();
export type ProductListResponse = z.infer<typeof ProductListResponseSchema>;
