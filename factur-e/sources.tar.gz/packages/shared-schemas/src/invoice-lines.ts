import { z } from "zod";

import { VatCategorySchema } from "./products.js";

/**
 * Invoice line drafts — formes consommées par `LineItemPicker` avant
 * que le formulaire facture (sprint-04 L08) ne persiste la ligne.
 *
 * Une ligne est créée soit :
 *  - depuis un Article (initialisation, pas binding — cf. glossaire
 *    T-CW-11 §2.3 « Mécanique Article = initialiseur ») ;
 *  - en saisie libre.
 *
 * Une fois la ligne « prête » (l'utilisateur a renseigné un libellé +
 * un prix + une quantité), le picker appelle `onLineReady` avec cette
 * shape. Le sprint-04 étendra ce schéma (taxes complémentaires, remises
 * niveau ligne, codes UN/ECE, etc.). Pour l'instant on garde le strict
 * minimum nécessaire au picker + tests.
 */

const PriceStringSchema = z
  .string()
  .regex(/^\d+(\.\d{1,4})?$/, "Prix invalide (au plus 4 décimales).")
  .refine((s) => Number(s) >= 0, "Prix ≥ 0 requis.");

const QuantityStringSchema = z
  .string()
  .regex(/^\d+(\.\d{1,4})?$/, "Quantité invalide.")
  .refine((s) => Number(s) > 0, "Quantité > 0 requise.");

const DiscountPercentSchema = z
  .string()
  .regex(/^\d+(\.\d{1,2})?$/, "Remise invalide (0-100).")
  .refine((s) => {
    const n = Number(s);
    return n >= 0 && n <= 100;
  }, "Remise entre 0 et 100 attendue.");

const VatRateStringSchema = z.string().regex(/^\d+(\.\d{1,2})?$/, "Taux TVA invalide.");

/** Origine d'une ligne — sert au badge UI « Depuis liste d'articles ». */
export const InvoiceLineOriginSchema = z.enum(["catalog", "freeform"]);
export type InvoiceLineOrigin = z.infer<typeof InvoiceLineOriginSchema>;

export const InvoiceLineDraftSchema = z
  .object({
    origin: InvoiceLineOriginSchema,
    /** Si origin === "catalog", `source_product_id` pointe sur l'article
     *  utilisé pour l'initialisation. Pas de binding persistant — la
     *  ligne reste autonome ensuite. */
    source_product_id: z.string().uuid().nullable(),
    label: z.string().min(1).max(200),
    description: z.string().max(2000).nullable(),
    quantity: QuantityStringSchema,
    unit: z.string().min(1).max(20),
    unit_price_ht: PriceStringSchema,
    discount_percent: DiscountPercentSchema,
    vat_category: VatCategorySchema,
    vat_rate: VatRateStringSchema.nullable(),
  })
  .strict();
export type InvoiceLineDraft = z.infer<typeof InvoiceLineDraftSchema>;
