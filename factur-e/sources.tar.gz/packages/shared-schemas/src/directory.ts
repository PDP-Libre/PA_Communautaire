import { z } from "zod";

/**
 * Directory search contracts (T-CL-10 sprint-03 — annuaire SuperPDP).
 *
 * Couvre :
 *  - `POST /api/directory/search` : input siren validé Luhn + format,
 *    output discriminé selon outcome adapter (cf. `DirectorySearchResult`
 *    pa-adapter T-CL-09).
 *  - `POST /api/directory/preference` : mémorisation préférence Peppol
 *    par couple (customer_id, buyer_siren). Le customer_id vient de
 *    l'auth context, pas du body.
 */

/**
 * SIREN qui ne respectent pas Luhn mais sont **réels et valides**. On
 * bypasse la vérif Luhn pour ces cas connus, sinon ils sont rejetés à
 * l'inscription / à la recherche annuaire alors qu'ils existent vraiment.
 *
 * Entrées actuelles :
 *  - `000000001`, `000000002` : tenants de test du sandbox SuperPDP
 *    (smoke testing T-CL-10 : Bruno a un compte sandbox sur ce SIREN).
 *  - `356000000` : La Poste (cas administratif documenté).
 *
 * Toute nouvelle entrée doit citer la source (INSEE / sandbox / arrêté
 * administratif). Si la liste devient longue, externaliser en
 * configuration (env var, migration).
 */
const LUHN_ALLOWLIST: ReadonlySet<string> = new Set(["000000001", "000000002", "356000000"]);

/**
 * Algorithme Luhn appliqué à un SIREN 9 chiffres. Le SIREN est valide si
 * la somme pondérée modulo 10 vaut 0. Cf. INSEE — algorithme identique au
 * SIRET (14 chiffres) restreint aux 9 premiers.
 *
 * Bypass pour les SIREN listés dans `LUHN_ALLOWLIST` (cas administratifs
 * + sandbox SuperPDP). Ces SIRENs existent réellement mais ne passent pas
 * Luhn — les rejeter casserait des parcours valides (signup + recherche
 * acheteur).
 */
export function isValidSirenLuhn(siren: string): boolean {
  if (!/^\d{9}$/.test(siren)) return false;
  if (LUHN_ALLOWLIST.has(siren)) return true;
  let sum = 0;
  for (let i = 0; i < 9; i += 1) {
    const digitChar = siren.charAt(i);
    let digit = parseInt(digitChar, 10);
    // Position 1-indexed depuis la droite ; chiffres en position paire
    // sont doublés. Ici i 0-indexed depuis la gauche : position pair
    // (1-indexed depuis la droite) ↔ i pair (depuis la gauche).
    if (i % 2 === 1) {
      digit *= 2;
      if (digit > 9) digit -= 9;
    }
    sum += digit;
  }
  return sum % 10 === 0;
}

const SirenSchema = z
  .string()
  .regex(/^\d{9}$/, "Le SIREN doit contenir exactement 9 chiffres.")
  .refine(isValidSirenLuhn, "Le SIREN ne respecte pas la clé de contrôle Luhn.");

export const DirectorySearchBodySchema = z
  .object({
    siren: SirenSchema,
  })
  .strict();
export type DirectorySearchBody = z.infer<typeof DirectorySearchBodySchema>;

const DirectoryAddressSchema = z
  .object({
    party_id: z.string().min(1),
    scheme_id: z.string().min(1),
    is_active: z.boolean(),
    pa_name: z.string().nullable(),
  })
  .strict();
export type DirectoryAddressDto = z.infer<typeof DirectoryAddressSchema>;

const DirectoryCompanySchema = z
  .object({
    number: z.string(),
    formal_name: z.string(),
    address: z.string(),
    postcode: z.string(),
    city: z.string(),
    country: z.string(),
  })
  .strict();
export type DirectoryCompanyDto = z.infer<typeof DirectoryCompanySchema>;

/**
 * Réponse `POST /api/directory/search` — discriminée par `kind` qui
 * mirroir 1:1 les outcomes `DirectorySearchResult` de pa-adapter, sans
 * la branche `cause`/`status` interne de `unavailable`. Le SPA n'a pas
 * besoin du status HTTP exact, juste de l'état UX.
 */
export const DirectorySearchResponseSchema = z.discriminatedUnion("kind", [
  z
    .object({
      kind: z.literal("found_one_address"),
      company: DirectoryCompanySchema,
      address: DirectoryAddressSchema,
    })
    .strict(),
  z
    .object({
      kind: z.literal("found_multi_address"),
      company: DirectoryCompanySchema,
      addresses: z.array(DirectoryAddressSchema).min(2),
    })
    .strict(),
  z.object({ kind: z.literal("not_found") }).strict(),
  z
    .object({
      kind: z.literal("disabled"),
      company: DirectoryCompanySchema,
    })
    .strict(),
  z.object({ kind: z.literal("unavailable") }).strict(),
]);
export type DirectorySearchResponse = z.infer<typeof DirectorySearchResponseSchema>;

/**
 * `POST /api/directory/preference` — mémorise le choix utilisateur
 * d'une adresse Peppol parmi un `found_multi_address`. Le `customer_id`
 * vient de l'auth context (pas du body).
 *
 * En T-CL-10 cet endpoint stocke uniquement, sans application au 2e
 * search (différé sprint-04+ — décision Bruno : on déroge à l'optim
 * 2e affichage, sélecteur réaffiché à chaque recherche).
 */
export const DirectoryPreferenceBodySchema = z
  .object({
    buyer_siren: SirenSchema,
    party_id: z.string().min(1).max(200),
  })
  .strict();
export type DirectoryPreferenceBody = z.infer<typeof DirectoryPreferenceBodySchema>;
