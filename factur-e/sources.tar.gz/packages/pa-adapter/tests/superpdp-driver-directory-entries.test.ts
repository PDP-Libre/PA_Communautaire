import { describe, expect, it } from "vitest";

import { PaUnavailableException, SuperPDPDriver } from "../src/index.js";

/**
 * T-CL-PA-OWN-DIRECTORY-ENTRIES sprint-06 — `getOwnDirectoryEntries`
 * (`GET /v1.beta/directory_entries`, authentifié). `fetch` injecté.
 *
 * Couvre : filtre `status="created"` + `!is_replyto` → party_id, found_one
 * / found_multi / not_found (vide ou tout filtré) + 5xx épuisé →
 * PaUnavailableException (ADR-009 D1).
 */

function makeFetch(body: unknown, status = 200): typeof globalThis.fetch {
  const fetchFn: typeof globalThis.fetch = (input) => {
    const url = input instanceof URL ? input.href : typeof input === "string" ? input : input.url;
    expect(url).toContain("/v1.beta/directory_entries");
    return Promise.resolve(
      new Response(JSON.stringify(body), {
        status,
        headers: { "content-type": "application/json" },
      }),
    );
  };
  return fetchFn;
}

function driverWith(body: unknown, status = 200): SuperPDPDriver {
  return new SuperPDPDriver({ clientId: "x", clientSecret: "y", fetch: makeFetch(body, status) });
}

describe("SuperPDPDriver.getOwnDirectoryEntries (T-CL-PA-OWN-DIRECTORY-ENTRIES)", () => {
  it("1 entrée created non-replyto → found_one_address (party_id = identifier)", async () => {
    const driver = driverWith({
      data: [{ id: 1, identifier: "0225:315143296_3685", status: "created", is_replyto: false }],
    });
    const result = await driver.getOwnDirectoryEntries({ accessToken: "a" });
    expect(result.kind).toBe("found_one_address");
    if (result.kind === "found_one_address") {
      expect(result.address.party_id).toBe("0225:315143296_3685");
      expect(result.address.scheme_id).toBe("0225");
    }
  });

  it("plusieurs entrées created → found_multi_address", async () => {
    const driver = driverWith({
      data: [
        { id: 1, identifier: "0225:111", status: "created", is_replyto: false },
        { id: 2, identifier: "0225:222", status: "created", is_replyto: false },
      ],
    });
    const result = await driver.getOwnDirectoryEntries({ accessToken: "a" });
    expect(result.kind).toBe("found_multi_address");
    if (result.kind === "found_multi_address") {
      expect(result.addresses.map((a) => a.party_id)).toEqual(["0225:111", "0225:222"]);
    }
  });

  it("entrées pending/error/replyto filtrées → not_found", async () => {
    const driver = driverWith({
      data: [
        { id: 1, identifier: "0225:pending", status: "pending", is_replyto: false },
        { id: 2, identifier: "0225:error", status: "error", is_replyto: false },
        { id: 3, identifier: "0225:replyto", status: "created", is_replyto: true },
      ],
    });
    const result = await driver.getOwnDirectoryEntries({ accessToken: "a" });
    expect(result.kind).toBe("not_found");
  });

  it("data vide → not_found", async () => {
    const driver = driverWith({ data: [] });
    const result = await driver.getOwnDirectoryEntries({ accessToken: "a" });
    expect(result.kind).toBe("not_found");
  });

  it("5xx épuisé → PaUnavailableException", async () => {
    const driver = driverWith({ message: "down" }, 503);
    await expect(driver.getOwnDirectoryEntries({ accessToken: "a" })).rejects.toBeInstanceOf(
      PaUnavailableException,
    );
  });
});
