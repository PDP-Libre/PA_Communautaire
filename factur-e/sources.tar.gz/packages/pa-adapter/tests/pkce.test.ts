import { createHash } from "node:crypto";

import { describe, expect, it } from "vitest";

import { deriveS256Challenge, generateCodeVerifier, generateState } from "../src/pkce.js";

describe("PKCE S256 helpers (RFC 7636)", () => {
  it("generateCodeVerifier returns base64url of 32 random bytes (43-char unpadded)", () => {
    const v = generateCodeVerifier();
    // 32 bytes → 43 chars base64url unpadded.
    expect(v).toHaveLength(43);
    // base64url alphabet only — no `=`, `+`, or `/`.
    expect(v).toMatch(/^[A-Za-z0-9_-]+$/);
    // Imprédictibilité — deux appels successifs doivent diverger
    // (probabilité de collision ≈ 1/2^256, négligeable).
    expect(v).not.toBe(generateCodeVerifier());
  });

  it("deriveS256Challenge applies SHA-256 then base64url-encodes the digest", () => {
    const verifier = "fixed-verifier-value-1234567890abcdef";
    const challenge = deriveS256Challenge(verifier);
    // 32-byte SHA-256 digest → 43 chars base64url unpadded.
    expect(challenge).toHaveLength(43);
    expect(challenge).toMatch(/^[A-Za-z0-9_-]+$/);
    // Reproduce the expected output independently to lock the
    // contract: hash → base64 → URL-safe transformation.
    const expected = createHash("sha256")
      .update(verifier)
      .digest("base64")
      .replace(/=+$/, "")
      .replace(/\+/g, "-")
      .replace(/\//g, "_");
    expect(challenge).toBe(expected);
  });

  it("generateState produces a short URL-safe random token", () => {
    const s = generateState();
    // 16 bytes → 22 chars base64url unpadded.
    expect(s).toHaveLength(22);
    expect(s).toMatch(/^[A-Za-z0-9_-]+$/);
    expect(s).not.toBe(generateState());
  });
});
