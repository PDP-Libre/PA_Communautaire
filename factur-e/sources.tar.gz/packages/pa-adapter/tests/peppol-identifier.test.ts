import { describe, expect, it } from "vitest";

import {
  formatPeppolIdentifier,
  formatPeppolIdentifierForUI,
  parsePeppolIdentifier,
  type PeppolIdentifier,
} from "../src/peppol-identifier.js";

/**
 * T-CL-PA-DIRECTORY-PEPPOL sprint-05 — Tests helper invariant Peppol
 * 4 formats AFNOR XP Z12-013 (FR).
 *
 * Q2 sprint-05 levé : helper invariant cross-PA (consommé par SuperPDP
 * + future EsaLink V2 + UI Paramètres). Algorithme split sur 1er `_`,
 * SIRET strict `^\d{14}$`, suffix `[A-Za-z0-9_]+` (accepte minuscules
 * + underscores internes, arbitrage Bruno récap pré-code).
 *
 * Source de vérité Annuaire.txt : `SuperPDP/InfoGenerales/Annuaire.txt`.
 */
describe("parsePeppolIdentifier (AFNOR XP Z12-013 — 4 formats FR)", () => {
  describe("happy path — 4 formats officiels Annuaire.txt", () => {
    it("0225:853322915 → mesh:'siren' (cas majoritaire mono-entité)", () => {
      const result = parsePeppolIdentifier("0225:853322915");
      expect(result).toEqual({
        scheme: "0225",
        siren: "853322915",
        mesh: "siren",
      });
    });

    it("0225:853322915_85332291500010 → mesh:'siren_siret' (SIRET 14 digits)", () => {
      const result = parsePeppolIdentifier("0225:853322915_85332291500010");
      expect(result).toEqual({
        scheme: "0225",
        siren: "853322915",
        siret: "85332291500010",
        mesh: "siren_siret",
      });
    });

    it("0225:853322915_DEPARTEMENTJURIDIQUE → mesh:'siren_suffix' (suffix uppercase)", () => {
      const result = parsePeppolIdentifier("0225:853322915_DEPARTEMENTJURIDIQUE");
      expect(result).toEqual({
        scheme: "0225",
        siren: "853322915",
        suffix: "DEPARTEMENTJURIDIQUE",
        mesh: "siren_suffix",
      });
    });

    it("0225:853322915_85332291500010_FACTURESPUBLIQUES → mesh:'siren_siret_routing'", () => {
      const result = parsePeppolIdentifier("0225:853322915_85332291500010_FACTURESPUBLIQUES");
      expect(result).toEqual({
        scheme: "0225",
        siren: "853322915",
        siret: "85332291500010",
        routingCode: "FACTURESPUBLIQUES",
        mesh: "siren_siret_routing",
      });
    });
  });

  describe("cas concrets sandbox sprint-04 + arbitrage Bruno suffix avec `_` internes", () => {
    it("0225:315143296_3686 (suffix court SuperPDP partner BQ/Tricatel) → mesh:'siren_suffix'", () => {
      const result = parsePeppolIdentifier("0225:315143296_3686");
      expect(result).toEqual({
        scheme: "0225",
        siren: "315143296",
        suffix: "3686",
        mesh: "siren_suffix",
      });
    });

    it("0225:315143296_3686_fe (suffix multi-`_` lowercase) → mesh:'siren_suffix' suffix='3686_fe'", () => {
      const result = parsePeppolIdentifier("0225:315143296_3686_fe");
      expect(result).toEqual({
        scheme: "0225",
        siren: "315143296",
        suffix: "3686_fe",
        mesh: "siren_suffix",
      });
    });

    it("0225:853322915_dpt_juridique_2024 (suffix lowercase multi-`_`) → mesh:'siren_suffix'", () => {
      const result = parsePeppolIdentifier("0225:853322915_dpt_juridique_2024");
      expect(result).toEqual({
        scheme: "0225",
        siren: "853322915",
        suffix: "dpt_juridique_2024",
        mesh: "siren_suffix",
      });
    });

    it("0225:853322915__replyto (suffix technique reply-to) → mesh:'siren_suffix' (helper accepte raw, filtrage côté driver)", () => {
      const result = parsePeppolIdentifier("0225:853322915__replyto");
      expect(result).toEqual({
        scheme: "0225",
        siren: "853322915",
        suffix: "_replyto",
        mesh: "siren_suffix",
      });
    });
  });

  describe("schemes Peppol autres pays", () => {
    it("0208:0869763267 (Belgique BCE) → mesh:'siren' (parser réutilise siren slot)", () => {
      const result = parsePeppolIdentifier("0208:0869763267");
      // Note : 0869763267 = 10 digits, ne match pas SIREN 9 digits FR → null
      expect(result).toBeNull();
    });

    it("9999:123456789 (scheme inconnu) → null (scheme doit être 0xxx)", () => {
      // Note : scheme '9999' commence par '9' pas '0' → rejette
      const result = parsePeppolIdentifier("9999:123456789");
      expect(result).toBeNull();
    });
  });

  describe("edge cases — invalid input", () => {
    it("null → null", () => {
      expect(parsePeppolIdentifier(null)).toBeNull();
    });

    it("undefined → null", () => {
      expect(parsePeppolIdentifier(undefined)).toBeNull();
    });

    it("chaîne vide → null", () => {
      expect(parsePeppolIdentifier("")).toBeNull();
    });

    it("'0225' sans `:` → null", () => {
      expect(parsePeppolIdentifier("0225")).toBeNull();
    });

    it("'853322915' SIREN brut sans scheme → null", () => {
      expect(parsePeppolIdentifier("853322915")).toBeNull();
    });

    it("':853322915' scheme vide → null", () => {
      expect(parsePeppolIdentifier(":853322915")).toBeNull();
    });

    it("'0225:' participant vide → null", () => {
      expect(parsePeppolIdentifier("0225:")).toBeNull();
    });

    it("'abc:853322915' scheme non-0xxx → null", () => {
      expect(parsePeppolIdentifier("abc:853322915")).toBeNull();
    });

    it("'02255:853322915' scheme 5 digits → null", () => {
      expect(parsePeppolIdentifier("02255:853322915")).toBeNull();
    });

    it("'0225:abc123def' SIREN non-9-digits → null", () => {
      expect(parsePeppolIdentifier("0225:abc123def")).toBeNull();
    });

    it("'0225:12345678' SIREN 8 digits → null", () => {
      expect(parsePeppolIdentifier("0225:12345678")).toBeNull();
    });

    it("'0225:1234567890' SIREN 10 digits → null (sans `_`, doit être exactement 9)", () => {
      expect(parsePeppolIdentifier("0225:1234567890")).toBeNull();
    });

    it("'0225:853322915_' SIREN avec `_` trailing vide → null", () => {
      expect(parsePeppolIdentifier("0225:853322915_")).toBeNull();
    });

    it("'0225:853322915_8533229150001' SIRET 13 digits → mesh:'siren_suffix' (pas SIRET strict)", () => {
      // SIRET strict 14 chars → 13 chars tombe en suffix
      const result = parsePeppolIdentifier("0225:853322915_8533229150001");
      expect(result).toEqual({
        scheme: "0225",
        siren: "853322915",
        suffix: "8533229150001",
        mesh: "siren_suffix",
      });
    });

    it("'0225:853322915_85332291500010_' routing vide trailing → null", () => {
      expect(parsePeppolIdentifier("0225:853322915_85332291500010_")).toBeNull();
    });

    it("'0225:853322915 espace' caractère invalide → null", () => {
      expect(parsePeppolIdentifier("0225:853322915 ")).toBeNull();
    });
  });
});

describe("formatPeppolIdentifier — roundtrip avec parser", () => {
  const cases: readonly [string, PeppolIdentifier][] = [
    ["0225:853322915", { scheme: "0225", siren: "853322915", mesh: "siren" }],
    [
      "0225:853322915_85332291500010",
      { scheme: "0225", siren: "853322915", siret: "85332291500010", mesh: "siren_siret" },
    ],
    [
      "0225:315143296_3686_fe",
      { scheme: "0225", siren: "315143296", suffix: "3686_fe", mesh: "siren_suffix" },
    ],
    [
      "0225:853322915_85332291500010_FACTURESPUBLIQUES",
      {
        scheme: "0225",
        siren: "853322915",
        siret: "85332291500010",
        routingCode: "FACTURESPUBLIQUES",
        mesh: "siren_siret_routing",
      },
    ],
  ];

  for (const [raw, parsed] of cases) {
    it(`roundtrip ${raw}`, () => {
      expect(formatPeppolIdentifier(parsed)).toBe(raw);
      expect(parsePeppolIdentifier(raw)).toEqual(parsed);
    });
  }
});

describe("formatPeppolIdentifierForUI (FR — labels adaptatifs mesh)", () => {
  it("mesh:'siren' → 'Adresse principale'", () => {
    const parsed: PeppolIdentifier = { scheme: "0225", siren: "853322915", mesh: "siren" };
    expect(formatPeppolIdentifierForUI(parsed, "fr")).toBe("Adresse principale");
  });

  it("mesh:'siren_siret' → 'Établissement {SIRET}'", () => {
    const parsed: PeppolIdentifier = {
      scheme: "0225",
      siren: "853322915",
      siret: "85332291500010",
      mesh: "siren_siret",
    };
    expect(formatPeppolIdentifierForUI(parsed, "fr")).toBe("Établissement 85332291500010");
  });

  it("mesh:'siren_suffix' simple → 'Division {SUFFIXE}'", () => {
    const parsed: PeppolIdentifier = {
      scheme: "0225",
      siren: "315143296",
      suffix: "3686",
      mesh: "siren_suffix",
    };
    expect(formatPeppolIdentifierForUI(parsed, "fr")).toBe("Division 3686");
  });

  it("mesh:'siren_suffix' multi-`_` lowercase → 'Division 3686_fe'", () => {
    const parsed: PeppolIdentifier = {
      scheme: "0225",
      siren: "315143296",
      suffix: "3686_fe",
      mesh: "siren_suffix",
    };
    expect(formatPeppolIdentifierForUI(parsed, "fr")).toBe("Division 3686_fe");
  });

  it("mesh:'siren_siret_routing' → 'Service {CODEROUTAGE}'", () => {
    const parsed: PeppolIdentifier = {
      scheme: "0225",
      siren: "853322915",
      siret: "85332291500010",
      routingCode: "FACTURESPUBLIQUES",
      mesh: "siren_siret_routing",
    };
    expect(formatPeppolIdentifierForUI(parsed, "fr")).toBe("Service FACTURESPUBLIQUES");
  });
});
