import { describe, expect, it } from "vitest";

import { PaUnavailableException, SuperPDPDriver } from "../src/index.js";

/**
 * T-CL-SIREN-RECONCILIATION sprint-06 W1 — `getConnectedCompany`
 * (`GET /v1.beta/companies/me`). `fetch` injecté (pas de réseau).
 *
 * Couvre : parse schéma `company` + dérivation SIREN (SIREN 9 / SIRET 14
 * → 9 premiers / autre → null) + adresse agrégée + 5xx épuisé →
 * PaUnavailableException (ADR-009 D1).
 */

function makeFetch(body: unknown, status = 200): typeof globalThis.fetch {
  const fetchFn: typeof globalThis.fetch = (input) => {
    const url = input instanceof URL ? input.href : typeof input === "string" ? input : input.url;
    expect(url).toContain("/v1.beta/companies/me");
    return Promise.resolve(
      new Response(JSON.stringify(body), {
        status,
        headers: { "content-type": "application/json" },
      }),
    );
  };
  return fetchFn;
}

function driverWith(body: unknown, status = 200): SuperPDPDriver {
  return new SuperPDPDriver({ clientId: "x", clientSecret: "y", fetch: makeFetch(body, status) });
}

const COMPANY_BASE = {
  id: 1,
  created_at: "2026-05-27T00:00:00Z",
  env: "sandbox",
  number_scheme: "siren",
  formal_name: "Tricatel SAS",
  trade_name: "Tricatel",
  address: "1 rue de Test",
  postcode: "75001",
  city: "Paris",
  country: "FR",
};

describe("SuperPDPDriver.getConnectedCompany (T-CL-SIREN-RECONCILIATION)", () => {
  it("SIREN 9 chiffres → siren = number + parse formal_name/adresse", async () => {
    const driver = driverWith({ ...COMPANY_BASE, number: "000000001" });
    const company = await driver.getConnectedCompany({ accessToken: "a" });
    expect(company.siren).toBe("000000001");
    expect(company.number).toBe("000000001");
    expect(company.formalName).toBe("Tricatel SAS");
    expect(company.tradeName).toBe("Tricatel");
    expect(company.address).toEqual({
      line: "1 rue de Test",
      postcode: "75001",
      city: "Paris",
      country: "FR",
    });
  });

  it("SIRET 14 chiffres → siren = 9 premiers", async () => {
    const driver = driverWith({
      ...COMPANY_BASE,
      number: "00000000100015",
      number_scheme: "siret",
    });
    const company = await driver.getConnectedCompany({ accessToken: "a" });
    expect(company.siren).toBe("000000001");
    expect(company.number).toBe("00000000100015");
  });

  it("number non numérique / longueur inattendue → siren null (fail-safe)", async () => {
    const driver = driverWith({ ...COMPANY_BASE, number: "FR-UNKNOWN" });
    const company = await driver.getConnectedCompany({ accessToken: "a" });
    expect(company.siren).toBeNull();
  });

  it("5xx épuisé → PaUnavailableException", async () => {
    const driver = driverWith({ message: "down" }, 503);
    await expect(driver.getConnectedCompany({ accessToken: "a" })).rejects.toBeInstanceOf(
      PaUnavailableException,
    );
  });
});
