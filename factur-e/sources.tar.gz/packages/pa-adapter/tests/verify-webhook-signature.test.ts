/**
 * T-CL-PA-EXT sprint-04 — Tests `verifyWebhookSignature` (HMAC SHA-256
 * constant-time). Couvre :
 *  (1) Signature `sha256=<hex>` correcte → true.
 *  (2) Signature hex nu (sans préfixe) correcte → true.
 *  (3) Signature incorrecte (mauvais secret) → false.
 *  (4) Payload altéré (1 byte modifié) → false.
 *  (5) Edge cases : signature/secret vide → false ; signature non-hex
 *      → false ; signature longueur ≠ → false.
 */

import { createHmac } from "node:crypto";

import { describe, expect, it } from "vitest";

import { verifyWebhookSignature } from "../src/webhook.js";

const SECRET = "test-webhook-secret-32-bytes-min";
const PAYLOAD = Buffer.from(
  JSON.stringify({ flowId: "abc", code: "204", occurred_at: "2026-05-16T10:00:00Z" }),
  "utf8",
);

function sign(payload: Buffer, secret: string): string {
  return createHmac("sha256", secret).update(payload).digest("hex");
}

describe("verifyWebhookSignature", () => {
  it("accepts a sha256=<hex> prefixed signature", () => {
    const sig = `sha256=${sign(PAYLOAD, SECRET)}`;
    expect(verifyWebhookSignature({ payload: PAYLOAD, signature: sig, secret: SECRET })).toBe(true);
  });

  it("accepts a bare hex signature (no prefix)", () => {
    const sig = sign(PAYLOAD, SECRET);
    expect(verifyWebhookSignature({ payload: PAYLOAD, signature: sig, secret: SECRET })).toBe(true);
  });

  it("rejects signature computed with wrong secret", () => {
    const sig = sign(PAYLOAD, "wrong-secret");
    expect(verifyWebhookSignature({ payload: PAYLOAD, signature: sig, secret: SECRET })).toBe(
      false,
    );
  });

  it("rejects when payload is altered by 1 byte", () => {
    const sig = sign(PAYLOAD, SECRET);
    const tampered = Buffer.from(PAYLOAD);
    const original = tampered[0] ?? 0;
    tampered[0] = original ^ 0x01;
    expect(verifyWebhookSignature({ payload: tampered, signature: sig, secret: SECRET })).toBe(
      false,
    );
  });

  it("rejects empty signature", () => {
    expect(verifyWebhookSignature({ payload: PAYLOAD, signature: "", secret: SECRET })).toBe(false);
  });

  it("rejects empty secret", () => {
    const sig = sign(PAYLOAD, SECRET);
    expect(verifyWebhookSignature({ payload: PAYLOAD, signature: sig, secret: "" })).toBe(false);
  });

  it("rejects non-hex signature (alphabet check)", () => {
    expect(
      verifyWebhookSignature({
        payload: PAYLOAD,
        signature: "not-hex-chars!!!",
        secret: SECRET,
      }),
    ).toBe(false);
  });

  it("rejects signature with wrong length (≠ 64 hex chars)", () => {
    expect(
      verifyWebhookSignature({
        payload: PAYLOAD,
        signature: "abc123",
        secret: SECRET,
      }),
    ).toBe(false);
  });

  it("is case-insensitive on hex", () => {
    const sig = sign(PAYLOAD, SECRET).toUpperCase();
    expect(verifyWebhookSignature({ payload: PAYLOAD, signature: sig, secret: SECRET })).toBe(true);
  });
});
