import { describe, expect, it } from "vitest";

import {
  FACTUR_E_STATUS_CODES,
  type FacturEStatusCode,
  mapSuperPDPStatusCode,
  SUPERPDP_STATUS_CODE_MAP,
  TERMINAL_FACTUR_E_STATUS_CODES,
} from "../src/index.js";

/**
 * T-CL-PA-STATUS-RFC sprint-05 — Tests mapping `status_code` SuperPDP
 * 43 valeurs raw → `FacturEStatusCode` 21 valeurs (ADR-012 D2 amendée).
 *
 * Refonte sémantique AFNOR XP Z12-013 stricte (NC-19 sprint-04 levée) :
 *  - 7 entrées `fr:*` re-mappées (fr:204/205/206/207/208/211/213).
 *  - Enum étendu de 17 → 21 valeurs (5 nouvelles : `in_process`,
 *    `under_query`, `info_complete`, `payment_transmitted`,
 *    `rejected_compliance` ; `completed` supprimé).
 *  - `on_hold` orphelin conservé (forward-compat + consommateurs UI).
 *
 * Source de vérité : `docs/guides/cdar.md` (371 lignes, T-BR-CDAR
 * sprint-04, input AFNOR XP Z12-013 officiel).
 */
describe("mapSuperPDPStatusCode (ADR-012 D2 amendée + D7 fallback)", () => {
  describe("cardinalité + invariants enum", () => {
    it("cardinalité du map = 43 entrées (8 api: + 15 fr: + 20 ppf:)", () => {
      expect(SUPERPDP_STATUS_CODE_MAP.size).toBe(43);
    });

    it("compte par préfixe : api:8, fr:15, ppf:20", () => {
      const byPrefix = { api: 0, fr: 0, ppf: 0, other: 0 };
      for (const raw of SUPERPDP_STATUS_CODE_MAP.keys()) {
        if (raw.startsWith("api:")) byPrefix.api += 1;
        else if (raw.startsWith("fr:")) byPrefix.fr += 1;
        else if (raw.startsWith("ppf:")) byPrefix.ppf += 1;
        else byPrefix.other += 1;
      }
      expect(byPrefix).toEqual({ api: 8, fr: 15, ppf: 20, other: 0 });
    });

    it("toutes les valeurs cibles appartiennent à FACTUR_E_STATUS_CODES (21)", () => {
      expect(FACTUR_E_STATUS_CODES.size).toBe(21);
      for (const [raw, mapped] of SUPERPDP_STATUS_CODE_MAP) {
        expect(FACTUR_E_STATUS_CODES.has(mapped), `raw='${raw}' → mapped='${mapped}'`).toBe(true);
      }
    });

    it("TERMINAL_FACTUR_E_STATUS_CODES (7) cohérent enum (toutes valeurs valides)", () => {
      expect(TERMINAL_FACTUR_E_STATUS_CODES.size).toBe(7);
      for (const terminal of TERMINAL_FACTUR_E_STATUS_CODES) {
        expect(FACTUR_E_STATUS_CODES.has(terminal), `terminal='${terminal}'`).toBe(true);
      }
    });
  });

  describe("api:* (pipeline technique pré-transmission SuperPDP)", () => {
    it.each<[string, FacturEStatusCode]>([
      ["api:uploaded", "submitted"],
      ["api:invalid", "rejected_xsd"],
      ["api:validated", "validated"],
      ["api:sent", "transmitting"],
      ["api:rejected", "rejected_xsd"],
      ["api:received", "received"],
      ["api:acknowledged", "received"],
      ["api:accepted", "accepted_business"],
    ])("mapSuperPDPStatusCode(%s) → %s", (raw, expected) => {
      const result = mapSuperPDPStatusCode(raw);
      expect(result.status).toBe(expected);
      expect(result.fellBack).toBe(false);
    });
  });

  describe("fr:* (AFNOR XP Z12-013 officiels — refonte sémantique sprint-05)", () => {
    // 15 codes AFNOR. 7 entrées re-mappées vs sprint-04 (NC-19) marquées REFONTE.
    it.each<[string, FacturEStatusCode, string]>([
      ["fr:200", "validated", "Déposée (Document valid)"],
      ["fr:201", "transmitting", "Émise (Emitted)"],
      ["fr:202", "received", "Reçue par la PA destinataire"],
      ["fr:203", "available_to_recipient", "Mise à disposition"],
      ["fr:204", "in_process", "REFONTE — Prise en charge (In Process)"],
      ["fr:205", "accepted_business", "REFONTE — Approuvée (Accepted)"],
      [
        "fr:206",
        "partially_accepted",
        "REFONTE — Approuvée partiellement (Conditionally accepted)",
      ],
      ["fr:207", "under_query", "REFONTE — En litige (Under Query)"],
      ["fr:208", "info_complete", "REFONTE — Complétée (donnée fournie)"],
      ["fr:209", "cancelled", "Annulée"],
      ["fr:210", "refused_business", "Refusée"],
      ["fr:211", "payment_transmitted", "REFONTE — Paiement transmis info Acquéreur"],
      ["fr:212", "paid", "Encaissée (fiscal exigibilité TVA Vendeur)"],
      ["fr:213", "rejected_compliance", "REFONTE — Rejet plateforme (réglementaire/doublon)"],
      ["fr:501", "transmission_failed", "Irrecevable (XSD/antivirus)"],
    ])("mapSuperPDPStatusCode(%s) → %s [%s]", (raw, expected) => {
      const result = mapSuperPDPStatusCode(raw);
      expect(result.status).toBe(expected);
      expect(result.fellBack).toBe(false);
    });

    it("distinction sémantique stricte fr:211 vs fr:212 (info Acquéreur vs fiscal Vendeur)", () => {
      expect(mapSuperPDPStatusCode("fr:211").status).toBe("payment_transmitted");
      expect(mapSuperPDPStatusCode("fr:212").status).toBe("paid");
      expect(TERMINAL_FACTUR_E_STATUS_CODES.has("paid")).toBe(true);
      expect(TERMINAL_FACTUR_E_STATUS_CODES.has("payment_transmitted")).toBe(false);
    });
  });

  describe("ppf:* (échanges DGFiP Portail Public Facturation — préservés)", () => {
    it.each<[string, FacturEStatusCode]>([
      ["ppf:validated", "validated"],
      ["ppf:validated-ack", "validated"],
      ["ppf:validated-ack-error", "validated"],
      ["ppf:validated-rejected", "rejected_xsd"],
      ["ppf:refused", "refused_business"],
      ["ppf:refused-ack", "refused_business"],
      ["ppf:refused-ack-error", "refused_business"],
      ["ppf:refused-rejected", "refused_business"],
      ["ppf:payment-received", "paid"],
      ["ppf:payment-received-ack", "paid"],
      ["ppf:payment-received-ack-error", "paid"],
      ["ppf:payment-received-rejected", "paid"],
      ["ppf:rejected", "rejected_xsd"],
      ["ppf:rejected-ack", "rejected_xsd"],
      ["ppf:rejected-ack-error", "rejected_xsd"],
      ["ppf:rejected-rejected", "rejected_xsd"],
      ["ppf:flow-1", "transmitting"],
      ["ppf:flow-1-ack", "transmitting"],
      ["ppf:flow-1-ack-error", "transmitting"],
      ["ppf:flow-1-rejected", "transmission_failed"],
    ])("mapSuperPDPStatusCode(%s) → %s", (raw, expected) => {
      const result = mapSuperPDPStatusCode(raw);
      expect(result.status).toBe(expected);
      expect(result.fellBack).toBe(false);
    });
  });

  describe("ADR-012 D7 forward-compat — fallback unknown + fellBack=true", () => {
    it("code raw inconnu → unknown + fellBack=true", () => {
      const result = mapSuperPDPStatusCode("totally:made_up_code");
      expect(result.status).toBe("unknown");
      expect(result.fellBack).toBe(true);
    });

    it("null/undefined/empty → unknown + fellBack=true (préserve comportement sprint-04)", () => {
      for (const raw of [null, undefined, ""] as const) {
        const result = mapSuperPDPStatusCode(raw);
        expect(result.status, `raw=${String(raw)}`).toBe("unknown");
        expect(result.fellBack, `raw=${String(raw)}`).toBe(true);
      }
    });

    it("préfixe non-standard (ex xx:foo) → unknown + fellBack=true", () => {
      const result = mapSuperPDPStatusCode("xx:foo");
      expect(result.status).toBe("unknown");
      expect(result.fellBack).toBe(true);
    });

    it("code AFNOR futur hors mapping (ex fr:214) → unknown + fellBack=true", () => {
      const result = mapSuperPDPStatusCode("fr:214");
      expect(result.status).toBe("unknown");
      expect(result.fellBack).toBe(true);
    });
  });

  describe("orphelin on_hold (refonte sprint-05)", () => {
    it("aucun code raw SuperPDP ne mappe sur on_hold (réservé forward-compat)", () => {
      for (const [, mapped] of SUPERPDP_STATUS_CODE_MAP) {
        expect(mapped).not.toBe("on_hold");
      }
    });

    it("on_hold est néanmoins une valeur valide de FacturEStatusCode (FACTUR_E_STATUS_CODES set)", () => {
      expect(FACTUR_E_STATUS_CODES.has("on_hold")).toBe(true);
    });
  });

  describe("completed retiré de l'enum (refonte sprint-05)", () => {
    it("aucun code raw SuperPDP ne mappe sur 'completed' (fr:213 → rejected_compliance désormais)", () => {
      for (const [, mapped] of SUPERPDP_STATUS_CODE_MAP) {
        expect(mapped as string).not.toBe("completed");
      }
    });
  });
});
