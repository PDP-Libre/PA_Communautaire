import { describe, expect, it } from "vitest";

import {
  InvoiceRejectedXsdException,
  PaUnavailableException,
  SuperPDPDriver,
  type CustomerContext,
} from "../src/index.js";

/**
 * T-CL-RECV-API sprint-05 W2 — Tests unitaires `SuperPDPDriver` réception
 * (ADR-010 v2). `fetch` injecté (pas de réseau, pas de fakeSuperPdp).
 *
 * Couvre :
 *  - listIncomingInvoices happy path (GET /invoices?direction=in + parse
 *    en_invoice → seller SIREN / totals cents / dates)
 *  - listIncomingInvoices nextCursor (= dernier invoice.id) + has_after
 *  - listIncomingInvoices batch vide → cursor inchangé
 *  - listIncomingInvoices 5xx épuisé → PaUnavailableException (ADR-009 D1)
 *  - createInvoiceEvent 205 happy (POST /invoice_events body)
 *  - createInvoiceEvent 210 + reasonCode → details[].reason
 *  - createInvoiceEvent 422 → InvoiceRejectedXsdException
 */

const CTX: CustomerContext = {
  customerId: "c-test",
  credentials: {
    kind: "superpdp-oauth-ac",
    accessToken: "a-test",
    refreshToken: "r-test",
    accessExpiresAt: new Date(Date.now() + 1800 * 1000),
    paUserId: null,
  },
};

interface CapturedRequest {
  url: string;
  init?: RequestInit;
}

/** Construit un `fetch` stub qui renvoie des `Response` canned et capture
 *  les requêtes pour assertions. */
function makeFetch(
  handler: (url: string, init?: RequestInit) => { status: number; body: unknown },
): { fetch: typeof globalThis.fetch; calls: CapturedRequest[] } {
  const calls: CapturedRequest[] = [];
  const fetchFn: typeof globalThis.fetch = (input, init) => {
    const url = input instanceof URL ? input.href : typeof input === "string" ? input : input.url;
    calls.push({ url, init });
    const { status, body } = handler(url, init);
    const res = new Response(JSON.stringify(body), {
      status,
      headers: { "content-type": "application/json" },
    });
    return Promise.resolve(res);
  };
  return { fetch: fetchFn, calls };
}

/** Parse un body JSON capturé (toujours une string `JSON.stringify` côté driver). */
function parseBody(init: RequestInit | undefined): Record<string, unknown> {
  const raw = init?.body;
  return JSON.parse(typeof raw === "string" ? raw : "{}") as Record<string, unknown>;
}

function incomingInvoiceFixture(id: number): Record<string, unknown> {
  return {
    id,
    direction: "in",
    created_at: "2026-05-20T09:00:00.000Z",
    en_invoice: {
      number: `FA-2026-${String(id)}`,
      issue_date: "2026-05-18",
      payment_due_date: "2026-06-17",
      currency_code: "EUR",
      seller: {
        name: "Tricatel SAS",
        legal_registration_identifier: { scheme: "0002", value: "552100554" },
        vat_identifier: "FR55552100554",
      },
      totals: { total_with_vat: "1200.50", total_without_vat: "1000.00" },
    },
    events: [{ id: 999, status_code: "fr:202", created_at: "2026-05-20T09:00:00.000Z" }],
  };
}

describe("SuperPDPDriver — réception (T-CL-RECV-API sprint-05 W2)", () => {
  it("listIncomingInvoices happy path → GET /invoices?direction=in + parse en_invoice", async () => {
    const { fetch, calls } = makeFetch(() => ({
      status: 200,
      body: { data: [incomingInvoiceFixture(45933)], has_after: false },
    }));
    const driver = new SuperPDPDriver({ clientId: "x", clientSecret: "y", fetch });

    const result = await driver.listIncomingInvoices({ cursor: "0", limit: 100 }, CTX);

    // Requête : direction=in + expand[]=en_invoice + cursor.
    expect(calls[0]?.url).toContain("/v1.beta/invoices?");
    expect(calls[0]?.url).toContain("direction=in");
    expect(calls[0]?.url).toContain("starting_after_id=0");
    expect(calls[0]?.url).toContain("expand%5B%5D=en_invoice");

    expect(result.invoices).toHaveLength(1);
    const inv = result.invoices[0];
    expect(inv?.paInvoiceId).toBe("45933");
    expect(inv?.direction).toBe("in");
    expect(inv?.receivedAt).toBe("2026-05-20T09:00:00.000Z");
    expect(inv?.rawStatusCode).toBe("fr:202");
    expect(inv?.enInvoice?.sellerSiren).toBe("552100554");
    expect(inv?.enInvoice?.sellerName).toBe("Tricatel SAS");
    expect(inv?.enInvoice?.number).toBe("FA-2026-45933");
    expect(inv?.enInvoice?.issueDate).toBe("2026-05-18");
    expect(inv?.enInvoice?.dueDate).toBe("2026-06-17");
    expect(inv?.enInvoice?.currency).toBe("EUR");
    // BT-112 1200.50 € → 120050 cents.
    expect(inv?.enInvoice?.totalTtcCents).toBe(120050);
    expect(result.nextCursor).toBe("45933");
    expect(result.hasMore).toBe(false);
  });

  it("listIncomingInvoices nextCursor = dernier id + has_after", async () => {
    const { fetch } = makeFetch(() => ({
      status: 200,
      body: {
        data: [incomingInvoiceFixture(10), incomingInvoiceFixture(11)],
        has_after: true,
      },
    }));
    const driver = new SuperPDPDriver({ clientId: "x", clientSecret: "y", fetch });

    const result = await driver.listIncomingInvoices({ cursor: "0", limit: 2 }, CTX);
    expect(result.invoices).toHaveLength(2);
    expect(result.nextCursor).toBe("11");
    expect(result.hasMore).toBe(true);
  });

  it("listIncomingInvoices batch vide → cursor inchangé", async () => {
    const { fetch } = makeFetch(() => ({ status: 200, body: { data: [], has_after: false } }));
    const driver = new SuperPDPDriver({ clientId: "x", clientSecret: "y", fetch });

    const result = await driver.listIncomingInvoices({ cursor: "777", limit: 100 }, CTX);
    expect(result.invoices).toHaveLength(0);
    expect(result.nextCursor).toBe("777");
    expect(result.hasMore).toBe(false);
  });

  it("listIncomingInvoices 5xx épuisé → PaUnavailableException (ADR-009 D1)", async () => {
    const { fetch } = makeFetch(() => ({ status: 503, body: { message: "down" } }));
    const driver = new SuperPDPDriver({
      clientId: "x",
      clientSecret: "y",
      fetch,
      retryOptions: { maxRetries: 1, backoffMs: [0] },
    });

    await expect(driver.listIncomingInvoices({ cursor: "0" }, CTX)).rejects.toBeInstanceOf(
      PaUnavailableException,
    );
  });

  it("createInvoiceEvent 205 happy → POST /invoice_events body {invoice_id, status_code}", async () => {
    const { fetch, calls } = makeFetch(() => ({
      status: 200,
      body: { id: 5001, status_code: "fr:205", created_at: "2026-05-21T10:00:00.000Z" },
    }));
    const driver = new SuperPDPDriver({ clientId: "x", clientSecret: "y", fetch });

    const result = await driver.createInvoiceEvent(
      { paInvoiceId: "45933", statusCode: "fr:205" },
      CTX,
    );

    expect(calls[0]?.url).toContain("/v1.beta/invoice_events");
    expect(calls[0]?.init?.method).toBe("POST");
    const body = parseBody(calls[0]?.init);
    expect(body.invoice_id).toBe(45933);
    expect(body.status_code).toBe("fr:205");
    expect(body.details).toBeUndefined();

    expect(result.rawStatusCode).toBe("fr:205");
    expect(result.status).toBe("accepted_business");
    expect(result.paEventId).toBe("5001");
  });

  it("createInvoiceEvent 210 + reasonCode → details[].reason", async () => {
    const { fetch, calls } = makeFetch(() => ({
      status: 200,
      body: { id: 5002, status_code: "fr:210", created_at: "2026-05-21T10:05:00.000Z" },
    }));
    const driver = new SuperPDPDriver({ clientId: "x", clientSecret: "y", fetch });

    const result = await driver.createInvoiceEvent(
      { paInvoiceId: "45933", statusCode: "fr:210", reasonCode: "03" },
      CTX,
    );

    const body = parseBody(calls[0]?.init);
    expect(body.status_code).toBe("fr:210");
    expect(body.details).toEqual([{ reason: "03" }]);
    expect(result.status).toBe("refused_business");
  });

  it("createInvoiceEvent 422 → InvoiceRejectedXsdException", async () => {
    const { fetch } = makeFetch(() => ({
      status: 422,
      body: { http_status_code: 422, message: "Transition de statut invalide." },
    }));
    const driver = new SuperPDPDriver({ clientId: "x", clientSecret: "y", fetch });

    await expect(
      driver.createInvoiceEvent({ paInvoiceId: "45933", statusCode: "fr:210" }, CTX),
    ).rejects.toBeInstanceOf(InvoiceRejectedXsdException);
  });
});
