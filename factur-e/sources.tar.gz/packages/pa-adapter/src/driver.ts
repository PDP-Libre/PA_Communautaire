/**
 * Interfaces `PADriver*` — abstraction multi-PA consommée par
 * `apps/api`. Refondue T-CL-PA-INVOICE-FIX sprint-04 en 3 sous-interfaces
 * composées (cf. ADR-012 D1) :
 *
 *  - `PADriverCore` : capability obligatoire (healthcheck + pipeline
 *    facture + annuaire + customer snapshot). Toute implémentation PA
 *    DOIT implémenter Core.
 *
 *  - `PADriverWebOnboarding extends PADriverCore` : connexion customer
 *    via tunnel OAuth Authorization Code (SuperPDP — ADR-005 préservé
 *    sprint-03 D1-D12).
 *
 *  - `PADriverApiOnboarding extends PADriverCore` : connexion customer
 *    via Customer Managed workflow (EsaLink V2 — ADR-011 D5).
 *
 * **Capability detection runtime** (D6) : les call sites côté apps/api
 * utilisent `isWebOnboarding(driver)` / `isApiOnboarding(driver)` pour
 * narrower avant d'appeler les méthodes spécifiques (pas de méthode
 * optionnelle, pas de null ambigu — TypeScript narrowing exhaustif).
 *
 * Convention. L'adapter est **pur** : il n'écrit ni en BDD ni dans le
 * secret manager. Il consomme/produit des objets en mémoire, le caller
 * (`apps/api/src/routes/*` + jobs) décide où persister.
 *
 * Forward-compat. La V2 d'EsaLink (sprint-07/08) remplace les méthodes
 * stubbées `NotImplementedYetException` sans toucher cette interface.
 * Les autres adapters AFNOR XP Z12-013 V2+ implémentent `PADriverCore` +
 * la sous-interface adaptée à leur modèle d'onboarding.
 *
 * cf. ADR-005 (OAuth SuperPDP) + ADR-010 v2 (SuperPDP propriétaire) +
 *     ADR-011 (EsaLink V1 partiel + V2 progressif) + ADR-012 (abstraction).
 */

import type {
  ConnectedCompany,
  EsaLinkJwtClaims,
  FacturEStatusCode,
  IdentityStatusSnapshot,
  IdentifierSnapshot,
  OnboardingMode,
  PaCredentials,
  PaCustomerSnapshot,
  ProviderId,
} from "./types.js";

// Re-export pour back-compat sprint-03 (callers qui importaient
// `IdentityStatus`/`IdentityStatusSnapshot` depuis `./driver.js`).
export type {
  IdentityStatus,
  IdentityStatusSnapshot,
  ConnectedCompany,
  ConnectedCompanyAddress,
} from "./types.js";

// ─────────────────────────────────────────────────────────────────────
// OAuth — types préservés sprint-03 (ADR-005 D1-D12)
// ─────────────────────────────────────────────────────────────────────

/** Bundle de tokens OAuth retourné par `exchangeCode` / `refreshToken`.
 *  Le caller persiste ce bundle dans le SecretStore référencé par
 *  `pa_connections.secret_ref`. Préservé sprint-03 — la migration vers
 *  `PaCredentials` discriminated union (ADR-012 D3) interviendra V2
 *  quand on encrypt-rotate les SecretStores existants. */
export interface PaTokens {
  /** Bearer access token. TTL 1800 s côté SuperPDP (sandbox 30/04). */
  accessToken: string;
  /** Refresh token rotation imposée — chaque `refreshToken` invalide
   *  l'ancien. Le caller doit persister le nouveau immédiatement. */
  refreshToken: string;
  /** Wall-clock UTC d'expiration du access token. */
  accessExpiresAt: Date;
  /** Identifiant utilisateur retourné par SuperPDP. Null car la spec
   *  `oauth2_session` n'expose pas d'id user (audit T-CW-08 §3.1 +
   *  patch T-CL-08 smoke test 11 mai 2026). */
  paUserId: string | null;
}

/** Challenge généré pendant `authorize` — le caller pose `state` et
 *  `codeVerifier` en cookie HttpOnly avant de rediriger l'utilisateur. */
export interface AuthorizeChallenge {
  /** URL complète à laquelle rediriger l'utilisateur (vers SuperPDP). */
  authorizeUrl: string;
  /** Anti-CSRF token. À comparer en callback. */
  state: string;
  /** PKCE — secret côté Factur-e, à envoyer à `exchangeCode` plain text. */
  codeVerifier: string;
}

export interface AuthorizeArgs {
  customerId: string;
  redirectUri: string;
}

export interface ExchangeCodeArgs {
  code: string;
  state: string;
  expectedState: string;
  codeVerifier: string;
  redirectUri: string;
}

export interface RefreshTokenArgs {
  refreshToken: string;
}

export interface RevokeArgs {
  refreshToken: string;
}

export interface GetIdentityStatusArgs {
  accessToken: string;
}

export interface GetConnectedCompanyArgs {
  accessToken: string;
}

export interface GetOwnDirectoryEntriesArgs {
  accessToken: string;
}

// ─────────────────────────────────────────────────────────────────────
// Customer context (commun PADriverCore — passé à toutes les méthodes
// qui dépendent du customer connecté)
// ─────────────────────────────────────────────────────────────────────

/** Contexte customer passé aux méthodes Core qui ont besoin de
 *  credentials et/ou d'un identifiant Factur-E. Le caller (routes +
 *  jobs) lit les credentials depuis le SecretStore et les fournit ici —
 *  l'adapter ne fait pas d'IO secret. */
export interface CustomerContext {
  /** Identifiant Factur-E du customer (UUID v7). Utilisé pour audit +
   *  traceability log. */
  customerId: string;
  /** Bundle de credentials per-driver (cf. `PaCredentials`). */
  credentials: PaCredentials;
}

// ─────────────────────────────────────────────────────────────────────
// Directory (T-CL-09 sprint-03 — annuaire, préservé)
// ─────────────────────────────────────────────────────────────────────

/** Une adresse Peppol issue de `french_directory_entry` SuperPDP, déjà
 *  filtrée `is_replyto=false` côté adapter (audit T-CW-08 §3.2). Côté
 *  EsaLink V1 : mapping AFNOR `LegalUnitPayloadHistory` +
 *  `DirectoryLine` vers la même shape (pour compat UI sprint-03). */
export interface DirectoryAddress {
  party_id: string;
  scheme_id: string;
  is_active: boolean;
  pa_name: string | null;
}

/** Snapshot company retourné côté UI (raison sociale + adresse postale,
 *  PRD §5.5 critère 2). */
export interface DirectoryCompany {
  number: string;
  formal_name: string;
  address: string;
  postcode: string;
  city: string;
  country: string;
}

/** Outcome discriminated de `searchSiren` — préservé sprint-03 +
 *  élargissement cause `unavailable` à `'forbidden'` (EsaLink V1
 *  retourne 403 sur compte démo sandbox, mappé proprement plutôt que
 *  remonter une exception). */
export type DirectorySearchResult =
  | {
      kind: "found_one_address";
      company: DirectoryCompany;
      address: DirectoryAddress;
    }
  | {
      kind: "found_multi_address";
      company: DirectoryCompany;
      addresses: DirectoryAddress[];
    }
  | { kind: "not_found" }
  | {
      kind: "disabled";
      company: DirectoryCompany;
    }
  | {
      kind: "unavailable";
      cause: "timeout" | "5xx" | "network" | "forbidden";
      status?: number;
    };

export interface SearchSirenArgs {
  siren: string;
}

// ─────────────────────────────────────────────────────────────────────
// Pipeline facture (cœur T-CL-PA-INVOICE-FIX — ADR-010 v2)
// ─────────────────────────────────────────────────────────────────────

/** Règle de traitement AFNOR XP Z12-013 — domestic B2B ou B2B
 *  international. Sprint-04 MVP : B2B uniquement (B2BInt sprint-05+). */
export type ProcessingRule = "B2B" | "B2BInt";

/** Profil Factur-X consommé par la PA — MVP : EXTENDED (le plus riche
 *  et conforme BR-FR-CTC). */
export type FacturXProfile = "MINIMUM" | "BASIC_WL" | "BASIC" | "EN16931" | "EXTENDED";

export interface SubmitInvoiceInput {
  /** Bytes du PDF/A-3 Factur-X (XML CII embarqué dedans). SuperPDP
   *  accepte le PDF en body direct (`Content-Type: application/pdf`)
   *  cf. ADR-010 v2 D3 — pas de multipart. */
  pdfBytes: Buffer;
  /** UUID v7 Factur-E (`invoices.tracking_id`) utilisé comme
   *  `external_id` query param SuperPDP pour idempotence (ADR-010 v2 D3).
   *  Si SuperPDP reçoit 2 fois le même `external_id` → retour idempotent. */
  trackingId: string;
  /** SHA-256 hex digest du PDF (64 chars). Stocké en BDD pour audit. */
  sha256: string;
  processingRule: ProcessingRule;
  profile: FacturXProfile;
  /** Numéro de facture BT-1 — sert au log / traçabilité côté caller,
   *  pas envoyé hors XML. */
  invoiceNumber: string;
  /** Identifiant Peppol du destinataire BT-49 (ex. `0225:111111111`). */
  recipientPeppolId: string;
  /** Identifiant Peppol du vendeur BT-30. */
  senderPeppolId: string;
  /** Désactive la pré-validation Schematron BR-FR V1.3.0 côté SuperPDP
   *  (ADR-010 v2 D6 + arbitrage Bruno Z3). **Default false** — Schematron
   *  appliqué en prod pour sécurité. Tests d'intégration peuvent setter
   *  `true` si le sample factur-x-builder n'est pas conforme BR-FR (la
   *  validation structurelle BT-34/BT-49 reste hard, non bypassable). */
  disablePreCheck?: boolean;
}

export interface SubmitInvoiceOutput {
  /** Identifiant facture côté PA. SuperPDP : `invoice.id` integer
   *  stringifié (ADR-010 v2 D7). Persisté dans `invoices.pa_invoice_id`. */
  paInvoiceId: string;
  /** Statut normalisé `FacturEStatusCode` (ADR-012 D2 — mapping depuis
   *  `invoice.events[0].status_code` SuperPDP). Typiquement `'submitted'`
   *  à l'instant T0. */
  status: FacturEStatusCode;
  /** Code raw natif PA (ex. `'api:uploaded'`) — conservé pour audit +
   *  traçabilité timeline. */
  rawStatusCode: string;
  /** Wall-clock UTC retournée par la PA (`invoice.created_at`). */
  submittedAt: Date;
}

/**
 * Event CDAR retourné par `pollCdarEvents`. Clé naturelle d'idempotence
 * côté BDD : `(invoice_id, code, occurred_at)` — cf. ADR-009 D4 + repo
 * `cdar_events.ts`.
 *
 * Shape T-CL-PA-INVOICE-FIX (ADR-012 D2) :
 *  - `rawStatusCode` : code natif PA (`fr:200`, `api:uploaded`, etc.).
 *    Stocké en BDD `cdar_events.code` pour timeline UI détaillée.
 *  - `status` : mapping normalisé `FacturEStatusCode`. Utilisé pour
 *    UPDATE `invoices.status_current`. Fallback `'unknown'` + audit
 *    `pa_status_code_unmapped` si code natif non-mappé (D7).
 *  - `paEventId` / `paInvoiceId` : identifiants natifs PA (integer
 *    SuperPDP stringifiés). Permettent join + traceability.
 */
export interface CdarEvent {
  /** Identifiant event côté PA (integer SuperPDP stringifié). Sert au
   *  curseur de pagination `pollCdarEvents` et au log. */
  paEventId: string;
  /** Identifiant facture côté PA (integer SuperPDP stringifié). Le
   *  caller (job polling) join `invoices.pa_invoice_id` pour router
   *  l'event vers la bonne facture Factur-E. */
  paInvoiceId: string;
  /** Code natif PA (ex. `fr:200`, `api:uploaded`). Stocké tel quel en
   *  BDD `cdar_events.code`. */
  rawStatusCode: string;
  /** Mapping normalisé `FacturEStatusCode` — 17 valeurs. Caller utilise
   *  pour UPDATE `invoices.status_current`. */
  status: FacturEStatusCode;
  /** Libellé humain optionnel (`event.status_text` SuperPDP). */
  label?: string;
  /** ISO timestamp UTC de l'événement côté PA (`event.created_at`). */
  occurredAt: string;
  /** Payload brut PA sérialisable (raison, détails métier). Persisté
   *  en `cdar_events.payload jsonb` pour audit. */
  payload?: unknown;
  /** Motif libre — obligatoire pour code `fr:204|205` (refus métier). */
  reason?: string;
}

export interface PollCdarEventsInput {
  /** Curseur de pagination — `event.id` integer SuperPDP stringifié.
   *  Initial : `'0'`. Le caller (job polling) lit depuis
   *  `pa_polling_state.cursor` (ADR-012 D5). */
  cursor: string;
  /** Taille de page — default 100, max 1000 côté SuperPDP. */
  limit?: number;
}

export interface PollCdarEventsOutput {
  /** Events ordered par `event.id` croissant (= chronologie PA). */
  events: readonly CdarEvent[];
  /** Curseur à persister pour la prochaine tick. Si `events.length > 0`
   *  : `String(events[last].paEventId)`. Sinon : cursor inchangé. */
  nextCursor: string;
  /** Indique s'il existe d'autres events après ce batch — le caller
   *  peut décider de re-poller immédiatement (catch-up) ou attendre
   *  le prochain tick cron. */
  hasMore: boolean;
}

// ─────────────────────────────────────────────────────────────────────
// Réception (T-CL-RECV-API sprint-05 W2 — ADR-010 v2)
//
// Pivot prompt v1→v2 : le prompt §7.5 visait `GET /flows/search?direction=In`
// (paths ADR-010 v1 SUPERSEDED, inexistants au swagger). Le vrai endpoint
// est `GET /v1.beta/invoices?direction=in&starting_after_id=&expand[]=en_invoice`
// (listing cursor Stripe-like, miroir de `pollCdarEvents`). La pose CDAR
// passe par `POST /v1.beta/invoice_events` (cf. `createInvoiceEvent`).
// ─────────────────────────────────────────────────────────────────────

/** Données EN 16931 extraites de `en_invoice` (expand SuperPDP) — gain de
 *  perf : le worker alimente `received_invoices` sans parser le XML en
 *  boucle. Tous champs optionnels (expand peut être partiel / absent → le
 *  caller fallback parsing XML on-demand pour la fiche). */
export interface IncomingInvoiceEnData {
  /** BT-1 numéro de facture fournisseur. */
  number?: string;
  /** BT-2 date d'émission (ISO date). */
  issueDate?: string;
  /** BT-9 échéance (ISO date). */
  dueDate?: string;
  /** BT-5 devise (`currency_code`). */
  currency?: string;
  /** BT-30 SIREN émetteur (`seller.legal_registration_identifier.value`). */
  sellerSiren?: string;
  /** BT-27/44 raison sociale émetteur (`seller.name`). */
  sellerName?: string;
  /** BT-112 total TTC en centimes (`totals.total_with_vat` × 100). */
  totalTtcCents?: number;
}

/** Une facture entrante listée via `GET /v1.beta/invoices?direction=in`. */
export interface IncomingInvoice {
  /** `invoice.id` integer SuperPDP stringifié → `received_invoices.pa_invoice_id_in`. */
  paInvoiceId: string;
  /** Direction PA — toujours `'in'` ici (filtre côté driver). */
  direction: "in" | "out";
  /** ISO timestamp réception PA (`invoice.created_at`). */
  receivedAt: string;
  /** Métadonnées EN 16931 issues de `expand[]=en_invoice` (optionnel). */
  enInvoice?: IncomingInvoiceEnData;
  /** Code statut natif du dernier event PA (`invoice.events[last]`), si
   *  fourni — sinon le caller part du default `in_process` (fr:204). */
  rawStatusCode?: string;
}

export interface ListIncomingInvoicesInput {
  /** Curseur `starting_after_id` (= `invoice.id` integer stringifié).
   *  Initial : `'0'`. Lu depuis `pa_polling_state` direction `'in'`. */
  cursor: string;
  /** Taille de page — default 100, max 1000 côté SuperPDP. */
  limit?: number;
}

export interface ListIncomingInvoicesOutput {
  /** Factures entrantes ordered par `invoice.id` croissant. */
  invoices: readonly IncomingInvoice[];
  /** Curseur à persister (= id de la dernière facture, ou cursor inchangé
   *  si batch vide). */
  nextCursor: string;
  /** S'il existe d'autres factures après ce batch (`has_after`). */
  hasMore: boolean;
}

export interface CreateInvoiceEventInput {
  /** `invoice.id` integer SuperPDP (= `received_invoices.pa_invoice_id_in`). */
  paInvoiceId: string;
  /** Code AFNOR à poser. Réception sprint-05 : `'fr:205'` | `'fr:210'`. */
  statusCode: string;
  /** Motif de refus 210 — code Annexe E PRD (01..11), envoyé à SuperPDP
   *  via `details[].reason` (ReasonCode MDT-113). */
  reasonCode?: string;
}

export interface CreateInvoiceEventOutput {
  /** `event.id` PA stringifié (si retourné). */
  paEventId: string | null;
  /** Code natif posé (echo). */
  rawStatusCode: string;
  /** Statut normalisé `FacturEStatusCode` résultant. */
  status: FacturEStatusCode;
  /** ISO timestamp de l'event PA. */
  occurredAt: string;
}

export interface DownloadInvoiceFileInput {
  /** `invoice.id` integer SuperPDP (= `received_invoices.pa_invoice_id_in`). */
  paInvoiceId: string;
}

export interface DownloadInvoiceFileResult {
  /** Octets bruts du fichier (PDF Factur-X ou XML pur selon la source). */
  bytes: Buffer;
  /** Content-Type renvoyé par la PA (`application/pdf` | `application/xml`).
   *  Le caller (proxy route) classe pdf vs xml pour le streaming. */
  contentType: string;
}

// ─────────────────────────────────────────────────────────────────────
// EsaLink — types V2 stubbés V1 (signatures déclarées pour les stubs)
// ─────────────────────────────────────────────────────────────────────

export interface AuthenticateOrchestratorOutput {
  accessToken: string;
  expiresAt: Date;
  /** Claims JWT décodés pour observabilité (ADR-011 D3). */
  jwtClaims: EsaLinkJwtClaims;
}

export interface CreateCustomerInput {
  /** Email KYC envoyé au customer pour OPTIN Docusign (ADR-011 D5). */
  contactEmail: string;
  /** Raison sociale légale. */
  legalName: string;
  /** SIREN 9 chiffres. */
  siren: string;
}

export interface UpdateCustomerInput {
  legalName?: string;
  contactEmail?: string;
}

export interface ProvisionIdentifierInput {
  /** Identifier Peppol complet (ex. `0225:123456789`). */
  identifier: string;
  qualifier: string;
}

// ─────────────────────────────────────────────────────────────────────
// Webhook — type préservé sprint-04 T-CL-PA-EXT (dormant V1)
// ─────────────────────────────────────────────────────────────────────

export interface VerifyWebhookSignatureArgs {
  /** Body brut tel que reçu (avant parsing JSON — la signature porte
   *  sur les octets). */
  payload: Buffer;
  /** Header `X-Superpdp-Signature` — format `sha256=<hex>` ou hex nu. */
  signature: string;
  /** Secret HMAC partagé. */
  secret: string;
}

// ─────────────────────────────────────────────────────────────────────
// PADriverCore — capability obligatoire (ADR-012 D1)
// ─────────────────────────────────────────────────────────────────────

/**
 * Interface obligatoire commune à toute implémentation PA. Couvre :
 *  - Healthcheck (sanity ping connecteur).
 *  - Pipeline facture (`submitInvoice` + `pollCdarEvents`).
 *  - Annuaire (`searchSiren`).
 *  - Customer snapshot (`getCustomerSnapshot` — V1 SuperPDP = identity ;
 *    V2 EsaLink = customer + identifiers).
 *
 * Les sous-interfaces `PADriverWebOnboarding` et `PADriverApiOnboarding`
 * étendent Core avec leurs méthodes d'onboarding spécifiques.
 */
export interface PADriverCore {
  readonly providerId: ProviderId;
  readonly onboardingMode: OnboardingMode;

  /** Ping de sanity — true si le connecteur est opérationnel. Tolérant
   *  aux 5xx (retourne false plutôt que throw). */
  healthcheck(): Promise<boolean>;

  /** Dépose une facture côté PA. Retry plafonné 5xx (max 2, backoff
   *  1s/2s — ADR-005 D11 préservé sprint-03). Exceptions typées :
   *   - `PaAccessTokenExpiredException` (401)
   *   - `PaForbiddenException` (403)
   *   - `InvoiceRejectedXsdException` (400 SuperPDP `Seller.ElectronicAddress` / 422)
   *   - `PaRateLimitException` (429)
   *   - `PaSubmissionFailedException` (5xx épuisé)
   *   - `PaProtocolException` (4xx non mappé). */
  submitInvoice(input: SubmitInvoiceInput, ctx: CustomerContext): Promise<SubmitInvoiceOutput>;

  /** Récupère les events CDAR via cursor global (ADR-010 v2 D4 — pattern
   *  Stripe-like). Pattern fail-safe ADR-009 D1 : sur 5xx épuisé, lève
   *  `PaUnavailableException` — le caller (job polling) log + retry au
   *  prochain tick sans avancer le cursor. */
  pollCdarEvents(input: PollCdarEventsInput, ctx: CustomerContext): Promise<PollCdarEventsOutput>;

  /** Recherche annuaire — SuperPDP cascade `french_directory/{companies,entries}`,
   *  EsaLink cascade `/v1/siren/code-insee:<siren>` +
   *  `POST /v1/directory-line/search`. Pattern T-CL-09 sprint-03 préservé. */
  searchSiren(args: SearchSirenArgs, ctx: CustomerContext): Promise<DirectorySearchResult>;

  /** T-CL-PA-DIRECTORY-PEPPOL sprint-05 — Lecture annuaire customer self
   *  à l'onboarding (Scénario A retenu T-CW-02). Variante sémantique de
   *  `searchSiren` dédiée au customer self : endpoint public (security
   *  `[]` côté SuperPDP), pas de Bearer requis, filtre `_replyto`
   *  défensif côté driver.
   *
   *  Cross-PA invariant (Q2 sprint-05 levé). EsaLink V2 wrappera son
   *  propre `searchSiren` AFNOR Directory cascade. */
  fetchOwnPeppolAddresses(siren: string): Promise<DirectorySearchResult>;

  /** Snapshot customer — SuperPDP : 2 statuts d'identité + paUserId.
   *  EsaLink V2 : customer Hubtimize + identifiers Peppol. V1 EsaLink :
   *  throw `NotImplementedYetException`. */
  getCustomerSnapshot(ctx: CustomerContext): Promise<PaCustomerSnapshot>;

  /** T-CL-RECV-API sprint-05 W2 — liste les factures REÇUES via cursor
   *  Stripe-like (`GET /v1.beta/invoices?direction=in&starting_after_id=`,
   *  ADR-010 v2). Miroir de `pollCdarEvents` côté réception. Pattern
   *  fail-safe ADR-009 D1 : sur 5xx épuisé lève `PaUnavailableException`
   *  — le worker log + retry au prochain tick sans avancer le cursor.
   *  EsaLink V1 : `NotImplementedYetException`. */
  listIncomingInvoices(
    input: ListIncomingInvoicesInput,
    ctx: CustomerContext,
  ): Promise<ListIncomingInvoicesOutput>;

  /** T-CL-RECV-API sprint-05 W2 — pose un statut CDAR sur une facture
   *  (`POST /v1.beta/invoice_events`, ADR-010 v2). Réception sprint-05 :
   *  205 Approuvée / 210 Refusée (motif Annexe E). Exceptions typées
   *  identiques `submitInvoice` (401/403/422/429/5xx). EsaLink V1 :
   *  `NotImplementedYetException`. */
  createInvoiceEvent(
    input: CreateInvoiceEventInput,
    ctx: CustomerContext,
  ): Promise<CreateInvoiceEventOutput>;

  /** T-CL-RECV-API sprint-05 W2 — télécharge le fichier brut d'une facture
   *  (`GET /v1.beta/invoices/:id/download`, ADR-010 v2 — pas de param
   *  `docType`, renvoie PDF Factur-X ou XML pur selon la source).
   *  Consommé par les proxy routes `/:id/{pdf,xml}`. Fail-safe : 5xx
   *  épuisé → `PaUnavailableException`. EsaLink V1 : `NotImplementedYetException`. */
  downloadInvoiceFile(
    input: DownloadInvoiceFileInput,
    ctx: CustomerContext,
  ): Promise<DownloadInvoiceFileResult>;
}

// ─────────────────────────────────────────────────────────────────────
// PADriverWebOnboarding — OAuth Authorization Code (SuperPDP)
// ─────────────────────────────────────────────────────────────────────

/**
 * Driver dont l'onboarding customer passe par un tunnel OAuth
 * Authorization Code per-customer (cf. ADR-005 D1-D12 SuperPDP — préservé
 * sprint-04 sans modification). Le customer redirige vers la PA,
 * autorise Factur-E, retour avec `code` → `exchangeCode` → tokens
 * persistés per-customer.
 */
export interface PADriverWebOnboarding extends PADriverCore {
  readonly onboardingMode: "web-authorization-code";

  /** Construit l'URL d'autorisation + génère `state` + PKCE verifier. */
  authorize(args: AuthorizeArgs): Promise<AuthorizeChallenge>;

  /** Échange le `code` du callback contre un bundle de tokens. Lève
   *  `PaInvalidStateException` si `state !== expectedState`. */
  exchangeCode(args: ExchangeCodeArgs): Promise<PaTokens>;

  /** Refresh du access token. Lève `RefreshExpiredException` sur
   *  `400 + invalid_grant` (rotation imposée OAuth 2.1 — ADR-005 D8). */
  refreshToken(args: RefreshTokenArgs): Promise<PaTokens>;

  /** Révocation conforme RFC 7009 — HTTP 200 attendu. Idempotente. */
  revoke(args: RevokeArgs): Promise<void>;

  /** **Préservé sprint-03** — snapshot des 2 statuts d'identité (user +
   *  company) consommé par callback OAuth + sub-job
   *  `poll-pa-identity-status`. Distinct de `getCustomerSnapshot` qui
   *  retourne un objet plus large `PaCustomerSnapshot`. */
  getIdentityStatus(args: GetIdentityStatusArgs): Promise<IdentityStatusSnapshot>;

  /** **T-CL-SIREN-RECONCILIATION sprint-06 W1** — société rattachée au
   *  token d'accès courant (`GET /v1.beta/companies/me` côté SuperPDP).
   *  Source de vérité du SIREN attesté KYC pour la réconciliation
   *  silencieuse (Mécanisme 3) — `oauth2_sessions/me` n'expose PAS de
   *  SIREN. Toute PA OAuth future implémente ce contrat (encapsulation
   *  ADR-012). */
  getConnectedCompany(args: GetConnectedCompanyArgs): Promise<ConnectedCompany>;

  /** **T-CL-PA-OWN-DIRECTORY-ENTRIES sprint-06** — adresses Peppol PROPRES
   *  du compte connecté (`GET /v1.beta/directory_entries`, authentifié).
   *  Source de vérité de l'adresse émetteur (`customers.directory_address`)
   *  — distincte de `searchSiren`/`fetchOwnPeppolAddresses` qui interroge
   *  l'annuaire PUBLIC `french_directory` (lookup de TIERS/acheteurs et ne
   *  référence pas les comptes sandbox). Retourne le même
   *  `DirectorySearchResult` (consommé tel quel par le callback OAuth +
   *  le job d'enrôlement). */
  getOwnDirectoryEntries(args: GetOwnDirectoryEntriesArgs): Promise<DirectorySearchResult>;
}

// ─────────────────────────────────────────────────────────────────────
// PADriverApiOnboarding — Customer Managed workflow (EsaLink V2)
// ─────────────────────────────────────────────────────────────────────

/**
 * Driver dont l'onboarding customer passe par une API serveur-à-serveur
 * (`POST /v1/customerPA` côté Hubtimize) + email KYC + Docusign OPTIN
 * envoyés directement au customer (ADR-011 D5). Pas de tunnel OAuth
 * côté UI — Factur-E orchestre depuis un compte distributeur partagé.
 *
 * **V1 partiel** : 3 méthodes implem (authenticateOrchestrator,
 * healthcheck, searchSiren via Core) + 9 stubs `NotImplementedYetException`
 * (cf. ADR-011 V1 + ADR-012 D8 feature flag `ENABLE_ESALINK_PROVIDER`).
 */
export interface PADriverApiOnboarding extends PADriverCore {
  readonly onboardingMode: "api-customer-managed";

  /** Authentification du compte distributeur partagé via Keycloak
   *  Client Credentials (ADR-011 D2). Pré-requis pour toutes les autres
   *  méthodes API. JWT décodé exposé via `jwtClaims` (D3 observabilité). */
  authenticateOrchestrator(): Promise<AuthenticateOrchestratorOutput>;

  /** **V2 stub** — Crée un customer Hubtimize (`POST /v1/customerPA`).
   *  Hubtimize envoie email KYC + Docusign OPTIN au customer. */
  createCustomer(input: CreateCustomerInput): Promise<PaCustomerSnapshot>;

  /** **V2 stub** — Met à jour un customer existant (`PUT /v1/customerPA/{id}`). */
  updateCustomer(paCustomerId: string, input: UpdateCustomerInput): Promise<PaCustomerSnapshot>;

  /** **V2 stub** — Provisionne un identifiant Peppol pour un customer
   *  (`POST /v1/customerPA/{id}/identifier`). */
  provisionIdentifier(
    paCustomerId: string,
    input: ProvisionIdentifierInput,
  ): Promise<IdentifierSnapshot>;

  /** **V2 stub** — Liste les identifiants Peppol provisionnés
   *  (`POST /v1/customerPA/{id}/identifier/search`). */
  listIdentifiers(paCustomerId: string): Promise<readonly IdentifierSnapshot[]>;

  /** **V2 stub** — Crée un utilisateur EDI per-customer
   *  (`POST /v1/customerPA/{id}/user`). Retourne les credentials EDI à
   *  persister Keychain (`factur-e-esalink-{customerId}-edi-{...}`). */
  createEdiUser(paCustomerId: string): Promise<PaCredentials>;

  /** **V2 stub** — Régénère le client secret d'un EDI user existant
   *  (`POST /v1/customerPA/{id}/user/{userId}/clientSecret`). */
  regenerateEdiUserSecret(paCustomerId: string, ediUserId: string): Promise<PaCredentials>;
}

// ─────────────────────────────────────────────────────────────────────
// Capability detection (D6 — type guards)
// ─────────────────────────────────────────────────────────────────────

/** Type guard runtime — narrow un `PADriverCore` vers
 *  `PADriverWebOnboarding` si le driver implémente l'onboarding OAuth
 *  Authorization Code (SuperPDP). */
export function isWebOnboarding(driver: PADriverCore): driver is PADriverWebOnboarding {
  return (
    driver.onboardingMode === "web-authorization-code" &&
    "authorize" in driver &&
    typeof (driver as PADriverWebOnboarding).authorize === "function"
  );
}

/** Type guard runtime — narrow un `PADriverCore` vers
 *  `PADriverApiOnboarding` si le driver implémente le workflow
 *  Customer Managed (EsaLink). */
export function isApiOnboarding(driver: PADriverCore): driver is PADriverApiOnboarding {
  return (
    driver.onboardingMode === "api-customer-managed" &&
    "authenticateOrchestrator" in driver &&
    typeof (driver as PADriverApiOnboarding).authenticateOrchestrator === "function"
  );
}

// ─────────────────────────────────────────────────────────────────────
// Alias back-compat sprint-03 (callers historiques `PADriver`)
// ─────────────────────────────────────────────────────────────────────

/** Alias `PADriver = PADriverWebOnboarding` — préservation des callers
 *  sprint-03 qui consomment l'instance unique `app.paDriver`
 *  (= SuperPDP). À déprécier sprint-05+ une fois la migration vers
 *  `PADriverCore` (le plus permissif) faite côté apps/api. */
export type PADriver = PADriverWebOnboarding;
