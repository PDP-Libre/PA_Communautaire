// Driver interfaces — 3 sous-interfaces composées (ADR-012 D1).
export type {
  PADriver,
  PADriverCore,
  PADriverWebOnboarding,
  PADriverApiOnboarding,
  PaTokens,
  AuthorizeChallenge,
  AuthorizeArgs,
  ExchangeCodeArgs,
  RefreshTokenArgs,
  RevokeArgs,
  GetIdentityStatusArgs,
  GetConnectedCompanyArgs,
  GetOwnDirectoryEntriesArgs,
  IdentityStatus,
  IdentityStatusSnapshot,
  CustomerContext,
  SearchSirenArgs,
  DirectorySearchResult,
  DirectoryAddress,
  DirectoryCompany,
  ProcessingRule,
  FacturXProfile,
  SubmitInvoiceInput,
  SubmitInvoiceOutput,
  CdarEvent,
  PollCdarEventsInput,
  PollCdarEventsOutput,
  IncomingInvoice,
  IncomingInvoiceEnData,
  ListIncomingInvoicesInput,
  ListIncomingInvoicesOutput,
  CreateInvoiceEventInput,
  CreateInvoiceEventOutput,
  DownloadInvoiceFileInput,
  DownloadInvoiceFileResult,
  AuthenticateOrchestratorOutput,
  CreateCustomerInput,
  UpdateCustomerInput,
  ProvisionIdentifierInput,
  VerifyWebhookSignatureArgs,
} from "./driver.js";

export { isWebOnboarding, isApiOnboarding } from "./driver.js";

// Types unifiés multi-PA (ADR-012 D2/D3).
export type {
  ProviderId,
  OnboardingMode,
  FacturEStatusCode,
  PaCredentials,
  EsaLinkJwtClaims,
  PaCustomerSnapshot,
  ConnectedCompany,
  ConnectedCompanyAddress,
  EsaLinkCustomerSnapshot,
  EsaLinkCustomerStatus,
  IdentifierSnapshot,
  IdentifierStatus,
} from "./types.js";

export { FACTUR_E_STATUS_CODES, TERMINAL_FACTUR_E_STATUS_CODES } from "./types.js";

// Exceptions typées (sprint-03 préservées + sprint-04 ajouts).
export {
  RefreshExpiredException,
  PaUnavailableException,
  PaInvalidStateException,
  PaProtocolException,
  PaAccessTokenExpiredException,
  PaForbiddenException,
  InvoiceRejectedXsdException,
  PaRateLimitException,
  PaSubmissionFailedException,
  NotImplementedYetException,
  UnknownProviderException,
  KeycloakAuthException,
} from "./errors.js";

export { generateCodeVerifier, deriveS256Challenge, generateState } from "./pkce.js";

// Webhook helper — préservé dormant V1 (endpoint webhook désactivé,
// route 503). Réactivable V2 si webhook livré côté SuperPDP propriétaire
// ou EsaLink.
export { verifyWebhookSignature } from "./webhook.js";

// Drivers — SuperPDP (refactor T-CL-PA-INVOICE-FIX vers vrais paths
// /v1.beta/invoices + /v1.beta/invoice_events) + EsaLink (partiel V1
// sous feature flag ENABLE_ESALINK_PROVIDER).
export { SuperPDPDriver, type SuperPDPDriverConfig } from "./superpdp-driver.js";
export { EsaLinkDriver, type EsaLinkDriverConfig } from "./esalink-driver.js";

// Helpers de mapping per-provider — re-exportés pour consommation par
// les tests d'intégration HTTP + jobs caller (lève [DEBT-low] arbitrage
// post-merge T-CL-TEST-INTEGRATION sprint-04, T-CL-PA-STATUS-RFC sprint-05).
export {
  mapSuperPDPStatusCode,
  SUPERPDP_STATUS_CODE_MAP,
  type MapSuperPDPStatusCodeResult,
} from "./superpdp/map-status-code.js";

// Helper invariant Peppol — 4 formats AFNOR XP Z12-013 FR
// (T-CL-PA-DIRECTORY-PEPPOL sprint-05 Q2 levé). Consommé par UI
// Paramètres > Connexion PA + future SETTINGS-ENTREPRISE-V1.
export type { PeppolIdentifier } from "./peppol-identifier.js";
export {
  parsePeppolIdentifier,
  formatPeppolIdentifier,
  formatPeppolIdentifierForUI,
} from "./peppol-identifier.js";
