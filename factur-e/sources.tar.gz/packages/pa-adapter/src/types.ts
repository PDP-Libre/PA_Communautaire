/**
 * Types unifiés multi-PA — ADR-012 (T-CL-PA-INVOICE-FIX sprint-04).
 *
 * Ce module pose les contrats portables consommés par toutes les
 * implémentations `PADriver*` :
 *
 *  - `FacturEStatusCode` : enum normalisé 17 valeurs (D2). Chaque driver
 *    mappe son propre vocabulaire (SuperPDP `status_code` 45 valeurs,
 *    EsaLink `AcknowledgementDto` + XML CDAR XP Z12) vers ces 17 valeurs.
 *    Tout code propriétaire non-mappé tombe sur `'unknown'` + audit
 *    `pa_status_code_unmapped` (D7, forward-compat safe).
 *
 *  - `PaCredentials` : discriminated union 4 variantes (D3). Chaque
 *    variante porte les champs strictement nécessaires (pas de null
 *    ambigu). La variante `esalink-keycloak-distributor` inclut
 *    `jwtClaims` décodés pour observabilité — **jamais pour
 *    autorisation**, le serveur Hubtimize fait foi (cf. ADR-011 D3).
 *
 *  - `PaCustomerSnapshot` : shape unifié retourné par
 *    `PADriverCore.getCustomerSnapshot(ctx)`. Champs optionnels (pas
 *    discriminated union) pour V1 — V1 ne consomme que `identity` pour
 *    SuperPDP. EsaLink V2 ajoutera `customer` + `identifiers`.
 *
 * cf. ADR-012 D1-D8 + ADR-011 D1-D10 (EsaLink V1 partiel).
 */

// ─────────────────────────────────────────────────────────────────────
// Provider identity (D6 capability detection runtime)
// ─────────────────────────────────────────────────────────────────────

/** Identifiant stable d'un provider PA. V1 : `'superpdp' | 'esalink'`.
 *  V2+ peut s'étendre (autres PA AFNOR). String literal preservé pour
 *  narrowing TypeScript côté apps/api. */
export type ProviderId = "superpdp" | "esalink";

/** Mode d'onboarding du provider — gating capability detection sur
 *  `PADriverWebOnboarding` (SuperPDP) vs `PADriverApiOnboarding`
 *  (EsaLink). Cf. ADR-012 D1 + D6. */
export type OnboardingMode = "web-authorization-code" | "api-customer-managed";

// ─────────────────────────────────────────────────────────────────────
// Status code unifié (D2 enum 21 valeurs + D7 fallback)
// ─────────────────────────────────────────────────────────────────────

/**
 * Statuts unifiés `FacturEStatusCode` — 21 valeurs (ADR-012 D2 amendée
 * T-CL-PA-STATUS-RFC sprint-05, refonte AFNOR XP Z12-013 stricte). Tout
 * provider mappe ses codes natifs vers cet enum via un helper dédié
 * (`packages/pa-adapter/src/superpdp/map-status-code.ts` et son
 * équivalent EsaLink V2).
 *
 * Catégories :
 *  - **Pipeline technique pré-transmission** (5) : `submitted`,
 *    `validated`, `rejected_xsd`, `rejected_virus`, `rejected_duplicate`.
 *  - **Transmission AFNOR XP Z12-013** (12, alignés codes fr:201..212) :
 *    `transmitting` (fr:201 Émise), `received` (fr:202 Reçue par la PA
 *    destinataire), `available_to_recipient` (fr:203 Mise à disposition),
 *    `in_process` (fr:204 Prise en charge — In Process), `accepted_business`
 *    (fr:205 Approuvée — Accepted), `partially_accepted` (fr:206 Approuvée
 *    partiellement — Conditionally accepted), `under_query` (fr:207 En
 *    litige — Under Query), `info_complete` (fr:208 Complétée — donnée
 *    manquante fournie), `cancelled` (fr:209 Annulée), `refused_business`
 *    (fr:210 Refusée), `payment_transmitted` (fr:211 Paiement transmis
 *    info Acquéreur, distinct de `paid`), `paid` (fr:212 Encaissée —
 *    exigibilité TVA fiscale Vendeur).
 *  - **Défaillance + rejets terminaux** (2) : `rejected_compliance`
 *    (fr:213 Rejet réglementaire / doublon plateforme),
 *    `transmission_failed` (fr:501 Irrecevable XSD/antivirus).
 *  - **Orphelin conservé** (1) : `on_hold` — non mappé par aucun code
 *    SuperPDP post-refonte (fr:211 → `payment_transmitted` désormais).
 *    Conservé pour forward-compat + consommateurs UI (`FilterPills`
 *    groupe "in_progress", `KpiCards` "En attente paiement"). À
 *    ré-affecter si un futur code PA AFNOR émerge avec sémantique
 *    "mise en attente générique".
 *  - **Fallback** (1) : `unknown` — toute valeur native non-mappée
 *    tombe ici + audit `pa_status_code_unmapped` (D7).
 *
 * **Distinction sémantique critique** : `paid` (fr:212 Encaissée —
 * exigibilité TVA fiscale Vendeur) ≠ `payment_transmitted` (fr:211
 * Paiement transmis — info Acquéreur a donné l'ordre de virement).
 *
 * Stocké tel quel dans `invoices.status_current TEXT` (D2 préserve text
 * non enum BDD pour forward-compat ADR-009 D2). Les codes natifs raw
 * sont conservés dans `cdar_events.code` pour timeline UI détaillée.
 *
 * Référence source : `docs/guides/cdar.md` (371 lignes, T-BR-CDAR
 * sprint-04, input AFNOR XP Z12-013 officiel).
 */
export type FacturEStatusCode =
  | "submitted"
  | "validated"
  | "rejected_xsd"
  | "rejected_virus"
  | "rejected_duplicate"
  | "transmitting"
  | "received"
  | "available_to_recipient"
  | "in_process"
  | "accepted_business"
  | "partially_accepted"
  | "under_query"
  | "info_complete"
  | "cancelled"
  | "refused_business"
  | "payment_transmitted"
  | "paid"
  | "rejected_compliance"
  | "transmission_failed"
  | "on_hold"
  | "unknown";

/** Set immuable des valeurs valides — utilisé par les helpers de mapping
 *  pour valider qu'une valeur retournée par un parseur est bien une
 *  valeur de l'enum (forward-compat safety net). */
export const FACTUR_E_STATUS_CODES: ReadonlySet<FacturEStatusCode> = new Set([
  "submitted",
  "validated",
  "rejected_xsd",
  "rejected_virus",
  "rejected_duplicate",
  "transmitting",
  "received",
  "available_to_recipient",
  "in_process",
  "accepted_business",
  "partially_accepted",
  "under_query",
  "info_complete",
  "cancelled",
  "refused_business",
  "payment_transmitted",
  "paid",
  "rejected_compliance",
  "transmission_failed",
  "on_hold",
  "unknown",
]);

/** Statuts terminaux — `invoices` qui les portent ne sont plus pollés
 *  côté UI (cf. ADR-010 v2 D4 cursor global SuperPDP : on poll quand
 *  même au niveau customer, mais une invoice à `paid|cancelled|
 *  rejected_*|transmission_failed` ne re-progresse plus côté UI). Liste
 *  consommée par les filtres SQL du job poll-cdar-events.
 *
 *  Post-refonte sprint-05 T-CL-PA-STATUS-RFC : `completed` retiré (jamais
 *  produit par aucun code raw post-AFNOR, fr:213 → `rejected_compliance`
 *  désormais). `rejected_compliance` ajouté (fr:213 rejet plateforme
 *  réglementaire/doublon, terminal côté cycle de vie facture). */
export const TERMINAL_FACTUR_E_STATUS_CODES: ReadonlySet<FacturEStatusCode> = new Set([
  "paid",
  "cancelled",
  "rejected_xsd",
  "rejected_virus",
  "rejected_duplicate",
  "rejected_compliance",
  "transmission_failed",
]);

// ─────────────────────────────────────────────────────────────────────
// Credentials discriminated union (D3)
// ─────────────────────────────────────────────────────────────────────

/**
 * Claims JWT Keycloak Hubtimize décodés en local pour observabilité
 * (ADR-011 D3). **Ne jamais utiliser pour autorisation** — le serveur
 * Hubtimize fait foi. Sert à log `entityId` (ID interne PA), `sub`
 * (sujet Keycloak), `roles` (rôles fonctionnels), `groups` pour le
 * debug et l'audit.
 */
export interface EsaLinkJwtClaims {
  /** Sujet Keycloak (UUID utilisateur Keycloak). */
  sub: string;
  /** Identifiant interne PA côté Hubtimize (integer, non-stable
   *  cross-environnements). */
  entityId: number | null;
  /** Email associé au compte distributeur (= `preferred_username`
   *  Keycloak en pratique). */
  email: string | null;
  /** Rôles fonctionnels — typiquement `["hubtimize-pa-distributor"]`. */
  roles: readonly string[];
  /** Groupes Keycloak — utile pour multi-tenant côté Hubtimize. */
  groups: readonly string[];
  /** Issuer Keycloak (URL realm). */
  iss: string | null;
}

/**
 * Bundle de credentials per-driver — discriminated union sur `kind`.
 * Persisté par le caller dans le SecretStore référencé par
 * `pa_connections.secret_ref`. La variante choisie détermine quel
 * driver l'a produit + quels champs sont garantis présents.
 *
 * Cf. ADR-012 D3 + ADR-005 D1-D12 (SuperPDP) + ADR-011 D1-D2 (EsaLink).
 *
 * Variantes :
 *  - `superpdp-oauth-cc` : Client Credentials (utilitaire — pour
 *    `companies/me`, `validation_reports`). Pas de user context, pas
 *    de refresh.
 *  - `superpdp-oauth-ac` : Authorization Code per-customer (cœur MVP).
 *    Rotation refresh imposée par OAuth 2.1 (ADR-005 D8).
 *  - `esalink-keycloak-distributor` : compte distributeur partagé
 *    Factur-E unique côté Keycloak Hubtimize (ADR-011 D1). Multi-tenant
 *    100% côté serveur Hubtimize via `entityId` du JWT.
 *  - `esalink-edi-user` : utilisateur EDI per-customer créé via
 *    `POST /v1/customerPA/{id}/user` (ADR-011 D5, V2). V1 : variante
 *    déclarée mais stubbée — pas de provisionnement actif.
 */
export type PaCredentials =
  | {
      kind: "superpdp-oauth-cc";
      accessToken: string;
      accessExpiresAt: Date;
    }
  | {
      kind: "superpdp-oauth-ac";
      accessToken: string;
      refreshToken: string;
      accessExpiresAt: Date;
      /** Identifiant utilisateur PA. Null pour SuperPDP — l'API
       *  `oauth2_session` n'expose pas d'id user (audit T-CW-08 §3.1 +
       *  patch T-CL-08 smoke test 11 mai 2026). Conservé pour
       *  forward-compat V2 multi-PA. */
      paUserId: string | null;
    }
  | {
      kind: "esalink-keycloak-distributor";
      /** Username Keycloak = login email du compte distributeur partagé
       *  (ex. `contact+fl@mona.re`). À URL-encoder via
       *  `--data-urlencode` pour les `+` (cf. tests S2 sandbox). */
      username: string;
      /** Password Keycloak (= client_secret stocké Keychain). */
      password: string;
      accessToken: string;
      refreshToken: string;
      accessExpiresAt: Date;
      refreshExpiresAt: Date;
      scope: string;
      sessionState: string;
      jwtClaims: EsaLinkJwtClaims;
    }
  | {
      kind: "esalink-edi-user";
      /** ID customer côté Hubtimize (retourné par `POST /v1/customerPA`). */
      paCustomerId: string;
      clientId: string;
      clientSecret: string;
      /** Tokens Bearer optionnels — émis à la première authentification
       *  EDI user (V2). V1 : non utilisé (méthode stubbée). */
      accessToken?: string;
      refreshToken?: string;
      accessExpiresAt?: Date;
      refreshExpiresAt?: Date;
    };

// ─────────────────────────────────────────────────────────────────────
// Customer snapshot (D1 + D6 — méthode commune `getCustomerSnapshot`)
// ─────────────────────────────────────────────────────────────────────

/** Statut d'identité tel que reporté par la PA (ADR-005 D5+D7 SuperPDP
 *  vocabulaire). Forward-compat : tout statut inconnu côté driver est
 *  mappé sur `needs_review` (le polling sub-job ré-essaiera). */
export type IdentityStatus = "verified" | "needs_review" | "rejected";

/** Snapshot des statuts d'identité — exposé par SuperPDP via
 *  `GET /v1.beta/oauth2_sessions/me`. Consommé par le callback OAuth +
 *  le sub-job `poll-pa-identity-status` (sprint-03).
 *
 *  Le schéma réel `oauth2_session` (swagger v1.21.1.beta) ne contient
 *  QUE `client_id` + `created_at` + les 2 statuts de vérification — pas
 *  de SIREN. Le SIREN attesté de la société connectée vient de
 *  `GET /v1.beta/companies/me` (cf. `ConnectedCompany` +
 *  `getConnectedCompany`), pas d'ici (correction T-CL-SIREN-
 *  RECONCILIATION sprint-06 — fix companies/me). */
export interface IdentityStatusSnapshot {
  /** Null pour SuperPDP (spec `oauth2_session` n'expose pas d'id user).
   *  Conservé `string | null` pour forward-compat V2 multi-PA. */
  paUserId: string | null;
  user: IdentityStatus;
  company: IdentityStatus;
}

/** Société rattachée au token d'accès courant, retournée par
 *  `GET /v1.beta/companies/me` (schéma `company` SuperPDP). Source de
 *  vérité du SIREN/SIRET attesté KYC pour la réconciliation silencieuse
 *  (Mécanisme 3, T-CL-SIREN-RECONCILIATION sprint-06 W1).
 *
 *  Provider-agnostique : toute PA OAuth (`PADriverWebOnboarding`) expose
 *  cette vue via `getConnectedCompany`. */
export interface ConnectedCompany {
  /** SIREN normalisé (9 chiffres) dérivé de `number` + `numberScheme`.
   *  `null` si non dérivable (ni SIREN ni SIRET reconnaissable) → aucune
   *  réconciliation déclenchée (fail-safe ADR-009). */
  siren: string | null;
  /** Identifiant brut de la société (`company.number`) — SIREN, SIRET ou
   *  autre selon `numberScheme`. */
  number: string;
  /** Schéma/source de l'identifiant (`company.number_scheme`). */
  numberScheme: string;
  /** Raison sociale officielle (`company.formal_name`) — V1.1
   *  réconciliation `legal_name` (backlog sprint-07+). */
  formalName: string;
  /** Nom commercial (`company.trade_name`). */
  tradeName: string | null;
  /** Adresse postale agrégée (`address`/`postcode`/`city`/`country`) —
   *  V1.1 réconciliation `address` (backlog sprint-07+). `null` si la PA
   *  ne la retourne pas. */
  address: ConnectedCompanyAddress | null;
}

export interface ConnectedCompanyAddress {
  line: string | null;
  postcode: string | null;
  city: string | null;
  country: string | null;
}

/** Lifecycle d'un customer côté EsaLink (V2 — Customer Managed
 *  workflow, ADR-011 D5). Stubbé V1. */
export type EsaLinkCustomerStatus = "WAITING_VALIDATION" | "ACTIVE" | "REJECTED" | "INACTIVE";

/** Snapshot customer EsaLink — V2 only. Renvoyé par
 *  `EsaLinkDriver.getCustomerSnapshot` quand cette méthode sera
 *  implémentée (sprint-07+). V1 : la méthode throw
 *  `NotImplementedYetException`. */
export interface EsaLinkCustomerSnapshot {
  paCustomerId: string;
  status: EsaLinkCustomerStatus;
  /** Email KYC envoyé au customer (ADR-011 D5). */
  contactEmail: string | null;
}

/**
 * Snapshot unifié retourné par `PADriverCore.getCustomerSnapshot(ctx)`.
 * Champs optionnels (pas discriminated union) — V1 ne consomme que
 * `identity` pour SuperPDP. EsaLink V2 peuplera `customer` + l'array
 * `identifiers`.
 *
 * Cf. ADR-012 D1 (méthode commune `PADriverCore`) + D6 (capability
 * detection : un caller qui a besoin de `customer` doit narrow via
 * `isApiOnboarding(driver)` puis appeler les méthodes spécifiques).
 */
export interface PaCustomerSnapshot {
  /** Provider qui a produit ce snapshot (traceability). */
  provider: ProviderId;
  /** SuperPDP : 2 statuts d'identité (user + company). EsaLink V2 :
   *  potentiellement absent (status porté par `customer.status`). */
  identity?: IdentityStatusSnapshot;
  /** EsaLink V2 — customer Hubtimize. Absent pour SuperPDP. */
  customer?: EsaLinkCustomerSnapshot;
  /** EsaLink V2 — identifiants Peppol provisionnés pour ce customer.
   *  V1 : tableau vide. */
  identifiers?: readonly IdentifierSnapshot[];
}

/** Lifecycle d'un identifiant Peppol côté EsaLink (V2). Stubbé V1. */
export type IdentifierStatus = "NEW" | "WAITINGOPTIN" | "IN_PROGRESS" | "WAITINGPEPPOL" | "Active";

/** Snapshot d'un identifiant Peppol provisionné côté PA (V2). */
export interface IdentifierSnapshot {
  paIdentifierId: string;
  /** Identifier Peppol complet (ex. `0225:123456789_dgfip`). */
  identifier: string;
  qualifier: string;
  status: IdentifierStatus;
}
