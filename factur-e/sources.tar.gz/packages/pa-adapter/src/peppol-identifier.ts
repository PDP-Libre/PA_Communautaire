/**
 * Parser / formatter invariant adresse Peppol AFNOR XP Z12-013 (FR).
 *
 * Source de vérité : `SuperPDP/InfoGenerales/Annuaire.txt` — 4 formats
 * officiels d'adresses électroniques de facturation France :
 *
 *   - `SIREN` (cas majoritaire mono-entité)
 *   - `SIREN_SIRET` (établissement séparé)
 *   - `SIREN_SUFFIXE` (mesh interne division / département)
 *   - `SIREN_SIRET_CODEROUTAGE` (routage sous-service public)
 *
 * Exemples Annuaire.txt :
 *   - `853322915`
 *   - `853322915_85332291500010`
 *   - `853322915_DEPARTEMENTJURIDIQUE`
 *   - `853322915_85332291500010_FACTURESPUBLIQUES`
 *
 * Format Peppol complet : `<scheme>:<participant_id>` avec scheme `0225`
 * pour la France (cf. liste Scheme ID OpenPeppol).
 *
 * Invariant cross-PA acté T-CW-02 sprint-05 + Investigation EsaLink
 * 2026-05-22 (cf. `docs/external/esalink/Directory.yml` modèle
 * `DirectoryLine` — `addressingIdentifier` + `siren` + `siret` +
 * `addressingSuffix` + `routingCode` cohérent SuperPDP `directory_entry`).
 *
 * **Algorithme de parsing** (arbitrage Bruno récap pré-code T-CL-PA-DIRECTORY-PEPPOL) :
 *
 *   1. Split sur `:` → scheme + participant_id.
 *   2. Split participant_id sur le **1er `_`** (préserve underscores
 *      internes dans suffix). siren = avant le 1er `_`, rest = après.
 *   3. Discriminate sur `rest` :
 *      - 0 underscore (pas de `_`) → mesh `siren`
 *      - rest match `^\d{14}$` strict → mesh `siren_siret` (SIRET pur)
 *      - rest match `^\d{14}_.+` → mesh `siren_siret_routing`
 *      - sinon → mesh `siren_suffix` (suffix = rest brut, peut contenir
 *        `_` internes et minuscules, ex. `3686_fe` ou `dpt_juridique_2024`)
 *
 * **Pattern suffix / routingCode** : `[A-Za-z0-9_]+` (accepte minuscules
 * ET underscore interne, arbitrage Bruno).
 *
 * **`_replyto` suffixes techniques** : le helper accepte la valeur brute
 * (`mesh: 'siren_suffix'` avec `suffix='_replyto'` ou similaire). Le
 * filtrage des entries reply-to est responsabilité du driver PA (cf.
 * `SuperPDPDriver.fetchOwnPeppolAddresses`).
 */

const SCHEME_REGEX = /^0\d{3}$/;
const SIREN_REGEX = /^\d{9}$/;
const SIRET_REGEX = /^\d{14}$/;
const PARTICIPANT_TAIL_REGEX = /^[A-Za-z0-9_]+$/;

/** Discriminated union — 4 formats AFNOR XP Z12-013 officiels FR. */
export type PeppolIdentifier =
  | {
      readonly scheme: string;
      readonly siren: string;
      readonly mesh: "siren";
    }
  | {
      readonly scheme: string;
      readonly siren: string;
      readonly siret: string;
      readonly mesh: "siren_siret";
    }
  | {
      readonly scheme: string;
      readonly siren: string;
      readonly suffix: string;
      readonly mesh: "siren_suffix";
    }
  | {
      readonly scheme: string;
      readonly siren: string;
      readonly siret: string;
      readonly routingCode: string;
      readonly mesh: "siren_siret_routing";
    };

/**
 * Parse un identifiant Peppol brut vers la discriminated union typée.
 * Retourne `null` si le format est invalide (scheme non `0xxx`, SIREN
 * non 9 digits, participant_id vide ou caractères hors `[A-Za-z0-9_]`).
 *
 * Le helper est **tolérant aux suffixes techniques** : `_replyto` est
 * accepté comme suffix valide (filtrage côté driver PA si nécessaire).
 *
 * @param raw Chaîne brute `<scheme>:<participant_id>` (ex. `0225:853322915`).
 * @returns `PeppolIdentifier` typé ou `null` si format invalide.
 */
export function parsePeppolIdentifier(raw: string | null | undefined): PeppolIdentifier | null {
  if (raw === null || raw === undefined || raw === "") return null;
  const colonIdx = raw.indexOf(":");
  if (colonIdx <= 0 || colonIdx === raw.length - 1) return null;

  const scheme = raw.slice(0, colonIdx);
  const participant = raw.slice(colonIdx + 1);

  if (!SCHEME_REGEX.test(scheme)) return null;
  if (!PARTICIPANT_TAIL_REGEX.test(participant)) return null;

  // Split sur le 1er `_` uniquement (préserve underscores internes suffix).
  const firstUnderscoreIdx = participant.indexOf("_");
  if (firstUnderscoreIdx === -1) {
    // Cas 1 : SIREN seul.
    if (!SIREN_REGEX.test(participant)) return null;
    return { scheme, siren: participant, mesh: "siren" };
  }

  const siren = participant.slice(0, firstUnderscoreIdx);
  const rest = participant.slice(firstUnderscoreIdx + 1);
  if (!SIREN_REGEX.test(siren)) return null;
  if (rest.length === 0) return null;

  // Cas 2 : SIREN_SIRET — rest est exactement 14 digits.
  if (SIRET_REGEX.test(rest)) {
    return { scheme, siren, siret: rest, mesh: "siren_siret" };
  }

  // Cas 4 : SIREN_SIRET_CODEROUTAGE — rest commence par 14 digits + `_` + suite.
  if (/^\d{14}_/.test(rest)) {
    const sepIdx = rest.indexOf("_", 14);
    const siret = rest.slice(0, sepIdx);
    const routingCode = rest.slice(sepIdx + 1);
    if (routingCode.length === 0) return null;
    return { scheme, siren, siret, routingCode, mesh: "siren_siret_routing" };
  }

  // Cas 3 : SIREN_SUFFIXE — rest est un suffix libre `[A-Za-z0-9_]+`
  // (peut contenir underscores internes et minuscules, ex. `3686_fe`).
  return { scheme, siren, suffix: rest, mesh: "siren_suffix" };
}

/**
 * Formatte une `PeppolIdentifier` typée vers sa représentation canonique
 * `<scheme>:<participant_id>`. Roundtrip avec `parsePeppolIdentifier`.
 */
export function formatPeppolIdentifier(parsed: PeppolIdentifier): string {
  switch (parsed.mesh) {
    case "siren":
      return `${parsed.scheme}:${parsed.siren}`;
    case "siren_siret":
      return `${parsed.scheme}:${parsed.siren}_${parsed.siret}`;
    case "siren_suffix":
      return `${parsed.scheme}:${parsed.siren}_${parsed.suffix}`;
    case "siren_siret_routing":
      return `${parsed.scheme}:${parsed.siren}_${parsed.siret}_${parsed.routingCode}`;
  }
}

/**
 * Formatte une `PeppolIdentifier` pour affichage UI utilisateur FR.
 * Libellés adaptatifs selon `mesh` (arbitrage Bruno récap pré-code) :
 *
 *  - `siren` → "Adresse principale"
 *  - `siren_siret` → "Établissement {SIRET}"
 *  - `siren_suffix` → "Division {SUFFIXE}"
 *  - `siren_siret_routing` → "Service {CODEROUTAGE}"
 *
 * Consommé par `<PeppolAddressDisplay>` côté UI Paramètres → Connexion PA
 * + future page Entreprise (T-CL-WEB-SETTINGS-ENTREPRISE-V1).
 */
export function formatPeppolIdentifierForUI(parsed: PeppolIdentifier, lang: "fr"): string {
  // `lang` paramètre réservé pour i18n future (V2 EN/ES). V1 = FR only.
  void lang;
  switch (parsed.mesh) {
    case "siren":
      return "Adresse principale";
    case "siren_siret":
      return `Établissement ${parsed.siret}`;
    case "siren_suffix":
      return `Division ${parsed.suffix}`;
    case "siren_siret_routing":
      return `Service ${parsed.routingCode}`;
  }
}
