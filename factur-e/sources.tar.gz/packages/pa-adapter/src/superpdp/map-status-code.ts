import type { FacturEStatusCode } from "../types.js";

/**
 * Mapping `status_code` SuperPDP propriétaire (43 valeurs, 3 préfixes
 * `api:` / `fr:` / `ppf:`) vers l'enum unifié `FacturEStatusCode` 21
 * valeurs (cf. ADR-012 D2 amendée T-CL-PA-STATUS-RFC sprint-05). Tout
 * code non-mappé tombe sur `'unknown'` (D7 forward-compat safe — le
 * caller émet audit `pa_status_code_unmapped`).
 *
 * Sources :
 *  - `docs/external/superpdp/proprietary/superpdp.json` v1.21.1.beta
 *    enum `status_code` (categories `api`, `fr`, `ppf`).
 *  - Investigation Cowork 2026-05-16/17 sandbox (testsuperpdp.txt) :
 *    `fr:200 → 'validated'` confirmé S2a, séquence happy path
 *    `api:uploaded → fr:200 → fr:201 → fr:202 → fr:205`.
 *  - **AFNOR XP Z12-013 officiel DGFiP** (refonte sprint-05) — cf.
 *    `docs/guides/cdar.md` (T-BR-CDAR sprint-04, 371 lignes).
 *
 * Mapping `fr:*` aligné sémantique AFNOR XP Z12-013 stricte. Mapping
 * `api:*` SuperPDP propriétaire + `ppf:*` Portail Public Facturation
 * préservés (sémantique pipeline technique + ack DGFiP).
 *
 * Tout statut **terminal** côté Factur-E (`paid`, `cancelled`,
 * `rejected_*`, `transmission_failed`) est listé dans
 * `TERMINAL_FACTUR_E_STATUS_CODES` (`types.ts`) — le job polling ne
 * re-poll plus une invoice qui les porte.
 *
 * **Distinction sémantique critique** :
 *  - `fr:211` → `payment_transmitted` (info Acquéreur a donné l'ordre
 *    de virement — observable mais pas fiscal).
 *  - `fr:212` → `paid` (Encaissée — exigibilité TVA fiscale Vendeur).
 *
 * **6 entrées re-mappées sprint-05 vs sprint-04 (NC-19 audit)** :
 *  - fr:204 : `refused_business` → `in_process` (Prise en charge)
 *  - fr:205 : `refused_business` → `accepted_business` (Approuvée)
 *  - fr:206 : `accepted_business` → `partially_accepted` (Approuvée partiellement)
 *  - fr:207 : `accepted_business` → `under_query` (En litige)
 *  - fr:208 : `partially_accepted` → `info_complete` (Complétée — donnée fournie)
 *  - fr:211 : `on_hold` → `payment_transmitted` (Paiement transmis info)
 *  - fr:213 : `completed` → `rejected_compliance` (Rejet réglementaire/doublon plateforme)
 */

/**
 * Table de mapping immuable. Toute valeur SuperPDP qui n'apparaît pas ici
 * → fallback `'unknown'` + audit `pa_status_code_unmapped` (D7).
 *
 * Cardinalité figée : 43 entrées (8 `api:` + 15 `fr:` + 20 `ppf:`).
 */
export const SUPERPDP_STATUS_CODE_MAP: ReadonlyMap<string, FacturEStatusCode> = new Map([
  // ─── api:* — pipeline technique pré-transmission SuperPDP ───
  ["api:uploaded", "submitted"],
  ["api:invalid", "rejected_xsd"],
  ["api:validated", "validated"],
  ["api:sent", "transmitting"],
  ["api:rejected", "rejected_xsd"],
  ["api:received", "received"],
  ["api:acknowledged", "received"],
  ["api:accepted", "accepted_business"],

  // ─── fr:* — codes AFNOR XP Z12-013 officiels DGFiP (refonte sprint-05) ───
  ["fr:200", "validated"], // Déposée (Document valid PA émettrice)
  ["fr:201", "transmitting"], // Émise (Emitted) — terme AFNOR "Émise par la plateforme"
  ["fr:202", "received"], // Reçue par la PA destinataire
  ["fr:203", "available_to_recipient"], // Mise à disposition de l'acheteur
  ["fr:204", "in_process"], // Prise en charge (In Process) — refonte sprint-05
  ["fr:205", "accepted_business"], // Approuvée (Accepted) — refonte sprint-05
  ["fr:206", "partially_accepted"], // Approuvée partiellement (Conditionally accepted) — refonte sprint-05
  ["fr:207", "under_query"], // En litige (Under Query) — refonte sprint-05
  ["fr:208", "info_complete"], // Complétée (donnée manquante fournie) — refonte sprint-05
  ["fr:209", "cancelled"], // Annulée par l'émetteur
  ["fr:210", "refused_business"], // Refusée (Rejected/Refused commercial)
  ["fr:211", "payment_transmitted"], // Paiement transmis info Acquéreur — refonte sprint-05
  ["fr:212", "paid"], // Encaissée (Paid - fiscal exigibilité TVA Vendeur)
  ["fr:213", "rejected_compliance"], // Rejet plateforme (réglementaire / doublon) — refonte sprint-05
  ["fr:501", "transmission_failed"], // Irrecevable (XSD/antivirus échec)

  // ─── ppf:* — statuts échanges DGFiP Portail Public Facturation ───
  ["ppf:validated", "validated"],
  ["ppf:validated-ack", "validated"],
  ["ppf:validated-ack-error", "validated"],
  ["ppf:validated-rejected", "rejected_xsd"],
  ["ppf:refused", "refused_business"],
  ["ppf:refused-ack", "refused_business"],
  ["ppf:refused-ack-error", "refused_business"],
  ["ppf:refused-rejected", "refused_business"],
  ["ppf:payment-received", "paid"],
  ["ppf:payment-received-ack", "paid"],
  ["ppf:payment-received-ack-error", "paid"],
  ["ppf:payment-received-rejected", "paid"],
  ["ppf:rejected", "rejected_xsd"],
  ["ppf:rejected-ack", "rejected_xsd"],
  ["ppf:rejected-ack-error", "rejected_xsd"],
  ["ppf:rejected-rejected", "rejected_xsd"],
  ["ppf:flow-1", "transmitting"],
  ["ppf:flow-1-ack", "transmitting"],
  ["ppf:flow-1-ack-error", "transmitting"],
  ["ppf:flow-1-rejected", "transmission_failed"],
]);

/** Résultat du mapping — distingue l'issue happy path (`'mapped'`) du
 *  fallback (`'unmapped'`) pour permettre au caller d'émettre l'audit
 *  `pa_status_code_unmapped` (ADR-012 D7) sans avoir à comparer
 *  `status === 'unknown'` (l'enum unifié contient `'unknown'` comme
 *  valeur légitime de plein droit — un code raw `unknown` non-fallback
 *  pourrait théoriquement exister). */
export interface MapSuperPDPStatusCodeResult {
  status: FacturEStatusCode;
  /** `true` si le `rawStatusCode` n'est pas dans la table de mapping —
   *  l'audit `pa_status_code_unmapped` doit être émis côté caller. */
  fellBack: boolean;
}

/**
 * Mappe un raw `status_code` SuperPDP vers l'enum unifié. Pure (pas
 * d'IO). Le caller est responsable d'émettre l'audit
 * `pa_status_code_unmapped` quand `result.fellBack === true`.
 *
 * @param rawStatusCode Valeur native SuperPDP (ex. `'fr:200'`, `'api:uploaded'`).
 *                       Tolère `null|undefined|''` → `unknown` + fallback.
 */
export function mapSuperPDPStatusCode(
  rawStatusCode: string | null | undefined,
): MapSuperPDPStatusCodeResult {
  if (rawStatusCode === null || rawStatusCode === undefined || rawStatusCode === "") {
    return { status: "unknown", fellBack: true };
  }
  const mapped = SUPERPDP_STATUS_CODE_MAP.get(rawStatusCode);
  if (mapped === undefined) {
    return { status: "unknown", fellBack: true };
  }
  return { status: mapped, fellBack: false };
}
