import type {
  AuthenticateOrchestratorOutput,
  CdarEvent,
  CreateCustomerInput,
  CreateInvoiceEventInput,
  CreateInvoiceEventOutput,
  CustomerContext,
  DirectoryAddress,
  DirectorySearchResult,
  DownloadInvoiceFileInput,
  DownloadInvoiceFileResult,
  ListIncomingInvoicesInput,
  ListIncomingInvoicesOutput,
  PADriverApiOnboarding,
  PollCdarEventsInput,
  PollCdarEventsOutput,
  ProvisionIdentifierInput,
  SearchSirenArgs,
  SubmitInvoiceInput,
  SubmitInvoiceOutput,
  UpdateCustomerInput,
} from "./driver.js";
import { NotImplementedYetException, PaProtocolException } from "./errors.js";
import { type mapEsaLinkHttpError, throwKeycloakAuthError } from "./esalink/errors.js";
import { decodeEsaLinkJwt } from "./esalink/jwt-claims.js";
import { mapAfnorDirectoryLines, mapAfnorLegalUnitToCompany } from "./esalink/map-afnor.js";
import { withRetry, type AttemptResult, type WithRetryOptions } from "./retry.js";
import type { IdentifierSnapshot, PaCredentials, PaCustomerSnapshot } from "./types.js";

/**
 * `EsaLinkDriver` — implémentation `PADriverApiOnboarding` partielle V1
 * pour la 2ᵉ PA EsaLink (Hubtimize anonymisé). Cf. ADR-011 (V1 partiel
 * + V2 progressif) + ADR-012 D8 feature flag `ENABLE_ESALINK_PROVIDER`.
 *
 * **V1 partiel** :
 *  - **3 méthodes implem** testables contre sandbox Hubtimize 2026-05-17 :
 *    - `authenticateOrchestrator` : Keycloak Client Credentials avec
 *      `--data-urlencode` pattern pour caractère `+` dans `client_id`
 *      (cf. tests S2 testesalink.txt). Décode JWT RS256 → `jwtClaims`
 *      observabilité (ADR-011 D3).
 *    - `healthcheck` : `GET /v1/healthcheck` + bearer + header firewall.
 *    - `searchSiren` : cascade `GET /v1/siren/code-insee:<siren>` +
 *      `POST /v1/directory-line/search`. Mapping AFNOR → shape compat
 *      sprint-03 (`DirectoryCompany` + `DirectoryAddress`).
 *
 *  - **9 méthodes stubbées** `throw NotImplementedYetException` : leur
 *    implémentation est conditionnée au partenariat commercial avec
 *    Hubtimize finalisé (sprint-07/08 V2 progressif) :
 *    `submitInvoice`, `pollCdarEvents`, `getCustomerSnapshot`,
 *    `createCustomer`, `updateCustomer`, `provisionIdentifier`,
 *    `listIdentifiers`, `createEdiUser`, `regenerateEdiUserSecret`.
 *
 * Configuration (constructor injection) :
 *  - `keycloakUsername` / `keycloakPassword` : compte distributeur
 *    partagé Factur-E unique côté Keycloak Hubtimize. Convention
 *    Keychain : `factur-e-esalink-{env}-orchestrator-{client-id,client-secret}`
 *    (ADR-012 D4).
 *  - `firewallApiKey` : valeur du header `hubtimize-api-key`
 *    obligatoire sur toutes les requêtes (ADR-011 D4 firewall amont).
 *    Convention Keychain : `factur-e-esalink-{env}-firewall-api-key`.
 *  - `baseUrl` : `https://api.hubtimize.com` (prod) ou `fakeHubtimize`
 *    en tests.
 *
 * Sécurité : aucune autorisation locale n'est dérivée du JWT décodé —
 * le serveur Hubtimize fait foi (ADR-011 D3). Le décodage sert
 * uniquement à `entityId` / `sub` / `roles` en log.
 */

const DEFAULT_BASE_URL = "https://api.hubtimize.com";

export interface EsaLinkDriverConfig {
  /** Username Keycloak = login email du compte distributeur partagé
   *  (ex. `contact+fl@mona.re`). À URL-encoder pour le `+`. */
  keycloakUsername: string;
  /** Password Keycloak (= client_secret côté form-urlencoded). */
  keycloakPassword: string;
  /** Header `hubtimize-api-key` firewall amont. */
  firewallApiKey: string;
  baseUrl?: string;
  fetch?: typeof globalThis.fetch;
  retryOptions?: WithRetryOptions;
}

export class EsaLinkDriver implements PADriverApiOnboarding {
  readonly providerId = "esalink" as const;
  readonly onboardingMode = "api-customer-managed" as const;

  private readonly keycloakUsername: string;
  private readonly keycloakPassword: string;
  private readonly firewallApiKey: string;
  private readonly baseUrl: string;
  private readonly fetchFn: typeof globalThis.fetch;
  private readonly retryOptions: WithRetryOptions;

  constructor(cfg: EsaLinkDriverConfig) {
    this.keycloakUsername = cfg.keycloakUsername;
    this.keycloakPassword = cfg.keycloakPassword;
    this.firewallApiKey = cfg.firewallApiKey;
    this.baseUrl = cfg.baseUrl ?? DEFAULT_BASE_URL;
    this.fetchFn = cfg.fetch ?? globalThis.fetch;
    this.retryOptions = cfg.retryOptions ?? {};
  }

  // ───────────────────────────────────────────────────────────────────
  // PADriverCore — capability obligatoire
  // ───────────────────────────────────────────────────────────────────

  async healthcheck(): Promise<boolean> {
    try {
      // Le healthcheck Hubtimize requiert le bearer distributeur +
      // header firewall. On chaîne l'auth pour avoir un test bout en
      // bout du connecteur, mais on swallow les erreurs (true/false
      // uniquement — pas d'exception).
      const auth = await this.authenticateOrchestrator();
      const res = await this.fetchFn(`${this.baseUrl}/v1/healthcheck`, {
        method: "GET",
        headers: {
          authorization: `Bearer ${auth.accessToken}`,
          "hubtimize-api-key": this.firewallApiKey,
          accept: "application/json",
        },
      });
      return res.ok;
    } catch {
      return false;
    }
  }

  async searchSiren(args: SearchSirenArgs, _ctx: CustomerContext): Promise<DirectorySearchResult> {
    // V1 : on chaîne l'auth orchestrator avant chaque appel (pas de
    // cache du token). V2 : token caché dans la SecretStore avec TTL.
    let auth: AuthenticateOrchestratorOutput;
    try {
      auth = await this.authenticateOrchestrator();
    } catch {
      return { kind: "unavailable", cause: "5xx" };
    }
    const headers = {
      authorization: `Bearer ${auth.accessToken}`,
      "hubtimize-api-key": this.firewallApiKey,
      accept: "application/json",
    };

    // Step 1: GET /v1/siren/code-insee:<siren>
    let companyRes: Response;
    try {
      companyRes = await this.fetchFn(
        `${this.baseUrl}/v1/siren/code-insee:${encodeURIComponent(args.siren)}`,
        { method: "GET", headers },
      );
    } catch {
      return { kind: "unavailable", cause: "network" };
    }
    if (companyRes.status === 403) {
      // Sandbox compte démo limité — surfacé au caller comme
      // `unavailable forbidden` (UX : "annuaire momentanément
      // indisponible — réessayez").
      return { kind: "unavailable", cause: "forbidden", status: 403 };
    }
    if (companyRes.status === 404) return { kind: "not_found" };
    if (companyRes.status >= 500) {
      return { kind: "unavailable", cause: "5xx", status: companyRes.status };
    }
    if (!companyRes.ok) {
      return { kind: "unavailable", cause: "5xx", status: companyRes.status };
    }
    const companyJson: unknown = await companyRes.json().catch(() => null);
    const company = mapAfnorLegalUnitToCompany(companyJson);
    if (company === null) return { kind: "not_found" };

    // Step 2: POST /v1/directory-line/search body {sirenNumber}
    let linesRes: Response;
    try {
      linesRes = await this.fetchFn(`${this.baseUrl}/v1/directory-line/search`, {
        method: "POST",
        headers: { ...headers, "content-type": "application/json" },
        body: JSON.stringify({ sirenNumber: args.siren }),
      });
    } catch {
      return { kind: "unavailable", cause: "network" };
    }
    if (linesRes.status === 403) {
      return { kind: "unavailable", cause: "forbidden", status: 403 };
    }
    if (linesRes.status >= 500) {
      return { kind: "unavailable", cause: "5xx", status: linesRes.status };
    }
    if (!linesRes.ok) {
      return { kind: "unavailable", cause: "5xx", status: linesRes.status };
    }
    const linesJson: unknown = await linesRes.json().catch(() => null);
    const addresses: DirectoryAddress[] = mapAfnorDirectoryLines(linesJson);
    const active = addresses.filter((a) => a.is_active);
    if (active.length === 0) {
      return { kind: "disabled", company };
    }
    if (active.length === 1) {
      const first = active[0];
      if (first === undefined) return { kind: "disabled", company };
      return { kind: "found_one_address", company, address: first };
    }
    return { kind: "found_multi_address", company, addresses: active };
  }

  /** T-CL-PA-DIRECTORY-PEPPOL sprint-05 — V1 partiel feature flag.
   *  Implémentation V2 sprint-07/08 (Lot L-PA-3) — pattern annuaire
   *  AFNOR EsaLink différent de SuperPDP (cf. ADR-011 D8). Stub V1. */
  fetchOwnPeppolAddresses(_siren: string): Promise<DirectorySearchResult> {
    return Promise.reject(
      new NotImplementedYetException(
        "EsaLink V2 — fetchOwnPeppolAddresses (T-CL-PA-DIRECTORY-PEPPOL sprint-05 SuperPDP only). Pattern AFNOR Directory cascade à implémenter sprint-07/08.",
      ),
    );
  }

  // ───────────────────────────────────────────────────────────────────
  // PADriverApiOnboarding — implem V1
  // ───────────────────────────────────────────────────────────────────

  async authenticateOrchestrator(): Promise<AuthenticateOrchestratorOutput> {
    // Form-urlencoded avec encoding manuel (= `--data-urlencode` curl)
    // pour `client_id` qui contient potentiellement `+` (cf. compte
    // démo `contact+fl@mona.re` testé sandbox 2026-05-17). Sans
    // l'encoding, le `+` est interprété comme espace côté serveur Keycloak.
    const form = new URLSearchParams();
    form.set("grant_type", "client_credentials");
    form.set("client_id", this.keycloakUsername);
    form.set("client_secret", this.keycloakPassword);

    const result = await withRetry(
      async (): Promise<AttemptResult<AuthenticateOrchestratorOutput>> => {
        const res = await this.fetchFn(`${this.baseUrl}/v1/oauth2/token`, {
          method: "POST",
          headers: {
            "content-type": "application/x-www-form-urlencoded",
            "hubtimize-api-key": this.firewallApiKey,
            accept: "application/json",
          },
          body: form.toString(),
        });
        if (res.status >= 500) return { kind: "retry", status: res.status };
        if (!res.ok) {
          try {
            await throwKeycloakAuthError(res);
          } catch (err) {
            return { kind: "fatal", error: err as Error };
          }
        }
        let json: Record<string, unknown>;
        try {
          json = (await res.json()) as Record<string, unknown>;
        } catch {
          return {
            kind: "fatal",
            error: new PaProtocolException({
              status: res.status,
              message: "EsaLink token endpoint returned non-JSON body.",
            }),
          };
        }
        const accessToken =
          typeof json.access_token === "string" && json.access_token !== ""
            ? json.access_token
            : null;
        const expiresIn = typeof json.expires_in === "number" ? json.expires_in : null;
        if (accessToken === null || expiresIn === null) {
          return {
            kind: "fatal",
            error: new PaProtocolException({
              status: res.status,
              message: "EsaLink token response missing access_token or expires_in.",
            }),
          };
        }
        const jwtClaims = decodeEsaLinkJwt(accessToken);
        return {
          kind: "ok",
          value: {
            accessToken,
            expiresAt: new Date(Date.now() + expiresIn * 1000),
            jwtClaims,
          },
        };
      },
      this.retryOptions,
    );
    if (result.kind === "exhausted") {
      throw new PaProtocolException({
        status: result.status,
        message: "EsaLink token endpoint unavailable after retries.",
      });
    }
    return result.value;
  }

  // ───────────────────────────────────────────────────────────────────
  // PADriverCore + PADriverApiOnboarding — stubs V1 (9 méthodes)
  // ───────────────────────────────────────────────────────────────────

  submitInvoice(_input: SubmitInvoiceInput, _ctx: CustomerContext): Promise<SubmitInvoiceOutput> {
    return Promise.reject(
      new NotImplementedYetException(
        "EsaLink submitInvoice — V2.3 conditionné partenariat commercial Hubtimize (sprint-07/08).",
      ),
    );
  }

  pollCdarEvents(
    _input: PollCdarEventsInput,
    _ctx: CustomerContext,
  ): Promise<PollCdarEventsOutput> {
    return Promise.reject(
      new NotImplementedYetException(
        "EsaLink pollCdarEvents — V2.3 conditionné parser XML CDAR AFNOR XP Z12-013.",
      ),
    );
  }

  getCustomerSnapshot(_ctx: CustomerContext): Promise<PaCustomerSnapshot> {
    return Promise.reject(
      new NotImplementedYetException(
        "EsaLink getCustomerSnapshot — V2.1 conditionné GET /v1/customerPA/{id}.",
      ),
    );
  }

  listIncomingInvoices(
    _input: ListIncomingInvoicesInput,
    _ctx: CustomerContext,
  ): Promise<ListIncomingInvoicesOutput> {
    return Promise.reject(
      new NotImplementedYetException(
        "EsaLink listIncomingInvoices — Réception V2 (sprint-07/08+). Pattern pull AFNOR POST /v1/flows/search à implémenter (ADR-011 D7).",
      ),
    );
  }

  createInvoiceEvent(
    _input: CreateInvoiceEventInput,
    _ctx: CustomerContext,
  ): Promise<CreateInvoiceEventOutput> {
    return Promise.reject(
      new NotImplementedYetException(
        "EsaLink createInvoiceEvent — pose CDAR Réception V2 (sprint-07/08+). Génération CDAR XML AFNOR XP Z12-013 à implémenter.",
      ),
    );
  }

  downloadInvoiceFile(
    _input: DownloadInvoiceFileInput,
    _ctx: CustomerContext,
  ): Promise<DownloadInvoiceFileResult> {
    return Promise.reject(
      new NotImplementedYetException(
        "EsaLink downloadInvoiceFile — Réception V2 (sprint-07/08+). Téléchargement flux AFNOR à implémenter.",
      ),
    );
  }

  createCustomer(_input: CreateCustomerInput): Promise<PaCustomerSnapshot> {
    return Promise.reject(
      new NotImplementedYetException(
        "EsaLink createCustomer — V2.1 conditionné Customer Managed workflow ADR-011 D5.",
      ),
    );
  }

  updateCustomer(_paCustomerId: string, _input: UpdateCustomerInput): Promise<PaCustomerSnapshot> {
    return Promise.reject(
      new NotImplementedYetException(
        "EsaLink updateCustomer — V2.4 (livré en dernier — moins prioritaire).",
      ),
    );
  }

  provisionIdentifier(
    _paCustomerId: string,
    _input: ProvisionIdentifierInput,
  ): Promise<IdentifierSnapshot> {
    return Promise.reject(
      new NotImplementedYetException(
        "EsaLink provisionIdentifier — V2.1 conditionné POST /v1/customerPA/{id}/identifier.",
      ),
    );
  }

  listIdentifiers(_paCustomerId: string): Promise<readonly IdentifierSnapshot[]> {
    return Promise.reject(
      new NotImplementedYetException(
        "EsaLink listIdentifiers — V2.1 conditionné POST /v1/customerPA/{id}/identifier/search.",
      ),
    );
  }

  createEdiUser(_paCustomerId: string): Promise<PaCredentials> {
    return Promise.reject(
      new NotImplementedYetException(
        "EsaLink createEdiUser — V2.2 conditionné POST /v1/customerPA/{id}/user.",
      ),
    );
  }

  regenerateEdiUserSecret(_paCustomerId: string, _ediUserId: string): Promise<PaCredentials> {
    return Promise.reject(
      new NotImplementedYetException(
        "EsaLink regenerateEdiUserSecret — V2.2 conditionné POST /v1/customerPA/{id}/user/{userId}/clientSecret.",
      ),
    );
  }
}

// Helper interne réservé V2 (utilisé par submitInvoice + pollCdarEvents
// quand livrés). Préservé sous forme de fonction inutilisée pour
// signaler l'intent et faciliter la livraison V2. Suppression possible
// si non-utilisé V1 cause warnings strict — laissé volontairement.
type _UnusedV2HttpErrorHandler = typeof mapEsaLinkHttpError;
// CdarEvent référencé pour signaler que V2 produira ce type côté
// pollCdarEvents (parser XML AFNOR XP Z12-013).
type _UnusedV2CdarEvent = CdarEvent;
