/**
 * Erreurs typées levées par les implémentations de `PADriver`.
 *
 * Pourquoi des classes (vs union literal) :
 *  - `instanceof` côté caller pour brancher cleanement (T-CL-06 jobs +
 *    endpoints).
 *  - Capture stack trace pour debug.
 *  - Sérialisable avec contexte (status HTTP, response body) pour audit.
 */

/**
 * Levée par `refreshToken` quand SuperPDP retourne `400 + invalid_grant`.
 * Cf. ADR-005 D8 — rotation imposée par OAuth 2.1 ; tout refresh token
 * consommé est invalidé côté serveur. La cause exacte
 * (mismatch redirect, autre client, malformé, expiré) n'est pas
 * distinguable côté SuperPDP — on traite tout `invalid_grant` au refresh
 * comme une expiration/perte de session.
 *
 * Conséquence côté caller (T-CL-06) : INCREMENT
 * `pa_connections.refresh_failures_count`. À 3 → soft-delete + audit
 * `pa_token_lost` + email customer.
 */
export class RefreshExpiredException extends Error {
  readonly code = "refresh_expired" as const;
  constructor(message = "Refresh token rejected by PA (invalid_grant).") {
    super(message);
    this.name = "RefreshExpiredException";
  }
}

/**
 * Levée par toute méthode après épuisement de `withRetry` sur 5xx
 * (cf. ADR-005 D11 retry plafonné max 2 + backoff 1s/2s). Le caller
 * remonte un message UX "SuperPDP momentanément indisponible —
 * réessayez ou contactez le support" (cf. brief sprint-03 §6.5).
 */
export class PaUnavailableException extends Error {
  readonly code = "pa_unavailable" as const;
  readonly status: number | null;
  constructor(args: { status: number | null; message?: string }) {
    super(
      args.message ??
        `PA unavailable after retries${args.status === null ? "" : ` (last status: ${String(args.status)})`}.`,
    );
    this.name = "PaUnavailableException";
    this.status = args.status;
  }
}

/**
 * Levée par `exchangeCode` si `state !== expectedState` — défense CSRF
 * standard OAuth 2.1. Le caller (T-CL-06 callback) retourne 401 +
 * cookies cleared, sans logger le state utilisateur (audit minimal).
 */
export class PaInvalidStateException extends Error {
  readonly code = "invalid_state" as const;
  constructor(message = "OAuth state does not match the expected value.") {
    super(message);
    this.name = "PaInvalidStateException";
  }
}

/**
 * Levée pour toute autre erreur inattendue côté SuperPDP (4xx non
 * mappés, JSON malformé, etc.). Le caller log l'exception complète
 * pour diagnostic et surface un message UX générique.
 */
export class PaProtocolException extends Error {
  readonly code = "pa_protocol" as const;
  readonly status: number | null;
  readonly responseBody: string | null;
  constructor(args: { status: number | null; responseBody?: string | null; message?: string }) {
    super(
      args.message ??
        `Unexpected PA response${args.status === null ? "" : ` (status ${String(args.status)})`}.`,
    );
    this.name = "PaProtocolException";
    this.status = args.status;
    this.responseBody = args.responseBody ?? null;
  }
}

// ───────────────────────────────────────────────────────────────────
// Sprint-04 (T-CL-PA-EXT) — exceptions dépôt facture + CDAR
// ───────────────────────────────────────────────────────────────────

/**
 * Levée par `submitInvoice` quand SuperPDP retourne 401 sur un appel
 * authentifié — le access token est expiré ou révoqué côté PA.
 *
 * Distincte de `RefreshExpiredException` (400 invalid_grant sur refresh).
 * Le caller (route `POST /api/invoices`) peut déclencher un refresh
 * préventif via `driver.refreshToken()` puis retry `submitInvoice`,
 * ou bien signaler à l'utilisateur de reconnecter sa PA si le refresh
 * lui-même échoue (cascade ADR-005 D8).
 */
export class PaAccessTokenExpiredException extends Error {
  readonly code = "access_token_expired" as const;
  constructor(message = "Access token rejected by PA (401).") {
    super(message);
    this.name = "PaAccessTokenExpiredException";
  }
}

/**
 * Levée par `submitInvoice` sur 403 — compte SuperPDP non vérifié, ou
 * suspendu, ou le flux demandé n'est pas autorisé (ex. `B2BInt` sans
 * agrément PA international). État rare hors sandbox.
 *
 * Le caller surface un toast UX dur "Votre Plateforme Agréée refuse
 * l'opération — contactez le support."
 */
export class PaForbiddenException extends Error {
  readonly code = "pa_forbidden" as const;
  readonly detail: string | null;
  constructor(args: { detail?: string | null; message?: string } = {}) {
    super(args.message ?? "PA refused the operation (403).");
    this.name = "PaForbiddenException";
    this.detail = args.detail ?? null;
  }
}

/**
 * Levée par `submitInvoice` sur 422 — la PA refuse la facture pour
 * cause de XSD invalide côté serveur (validation supplémentaire au-delà
 * de la nôtre, ou divergence Factur-X EN 16931 vs schema PA).
 *
 * Aligne plan.md sprint-04 T-CL-PA-EXT ligne 264. Distincte d'une
 * erreur 4xx générique : un XSD KO est un état utilisateur récupérable
 * (corriger la facture), pas un bug technique.
 *
 * Le caller (route `POST /api/invoices`) ROLLBACK la transaction +
 * surface une modal bloquante "La facture comporte des erreurs : {liste}"
 * (acté brief §6.10).
 */
export class InvoiceRejectedXsdException extends Error {
  readonly code = "invoice_rejected_xsd" as const;
  readonly detail: string | null;
  constructor(args: { detail?: string | null; message?: string } = {}) {
    super(args.message ?? "PA rejected invoice (XSD invalid, 422).");
    this.name = "InvoiceRejectedXsdException";
    this.detail = args.detail ?? null;
  }
}

/**
 * Levée par `submitInvoice` / `pollDocumentStatus` sur 429 (rate limit
 * PA). Le caller back-off + retry au prochain tick polling, ou propage
 * un toast UX "Service surchargé — réessayez dans quelques minutes."
 */
export class PaRateLimitException extends Error {
  readonly code = "pa_rate_limit" as const;
  /** Valeur du header `Retry-After` en secondes si fourni par la PA. */
  readonly retryAfterSeconds: number | null;
  constructor(args: { retryAfterSeconds?: number | null; message?: string } = {}) {
    super(args.message ?? "PA rate limit hit (429).");
    this.name = "PaRateLimitException";
    this.retryAfterSeconds = args.retryAfterSeconds ?? null;
  }
}

/**
 * Levée par `submitInvoice` après épuisement de `withRetry` sur 5xx
 * (ADR-005 D11 — workaround bug 500 sandbox SuperPDP). Distincte de
 * `PaUnavailableException` (qui couvre tous les autres appels
 * authentifiés) pour permettre au caller de différencier la déposition
 * facture des autres flux côté audit / KPI.
 */
export class PaSubmissionFailedException extends Error {
  readonly code = "pa_submission_failed" as const;
  readonly retries: number;
  readonly lastStatus: number | null;
  constructor(args: { retries: number; lastStatus: number | null; message?: string }) {
    super(
      args.message ??
        `PA submission failed after ${String(args.retries)} retries${
          args.lastStatus === null ? "" : ` (last status: ${String(args.lastStatus)})`
        }.`,
    );
    this.name = "PaSubmissionFailedException";
    this.retries = args.retries;
    this.lastStatus = args.lastStatus;
  }
}

// ───────────────────────────────────────────────────────────────────
// Sprint-04 (T-CL-PA-INVOICE-FIX) — exceptions multi-PA + EsaLink
// ───────────────────────────────────────────────────────────────────

/**
 * Levée par les méthodes stubbées V1 d'un driver dont l'implémentation
 * est différée à un sprint ultérieur (cf. ADR-011 V1 EsaLink — 9 des 12
 * méthodes conditionnées au partenariat commercial Hubtimize, livraison
 * V2 sprint-07/08).
 *
 * Le caller traite cette exception comme une faute de programmation
 * (l'UI ne devrait jamais router vers une méthode stubbée si le
 * `ProviderDescriptor.onboardingMode` est correctement filtré) — log
 * niveau `error` + 500.
 */
export class NotImplementedYetException extends Error {
  readonly code = "not_implemented_yet" as const;
  constructor(message: string) {
    super(message);
    this.name = "NotImplementedYetException";
  }
}

/**
 * Levée par le registry `apps/api/src/pa/registry.ts` quand un caller
 * demande un provider non enregistré ou désactivé par feature flag.
 * Cf. ADR-012 D8 — `ENABLE_<provider>_PROVIDER` gating.
 */
export class UnknownProviderException extends Error {
  readonly code = "unknown_provider" as const;
  readonly provider: string;
  constructor(provider: string, message?: string) {
    super(message ?? `Unknown or disabled provider: ${provider}`);
    this.name = "UnknownProviderException";
    this.provider = provider;
  }
}

/**
 * Levée par `EsaLinkDriver.authenticateOrchestrator` quand le serveur
 * Keycloak Hubtimize retourne 401/403 ou un payload d'erreur non
 * récupérable (cf. ADR-011 D9 format `{errorCode, errorMessage}`).
 * Distincte de `PaForbiddenException` car la racine est OAuth/Keycloak,
 * pas un refus métier PA.
 */
export class KeycloakAuthException extends Error {
  readonly code = "keycloak_auth_failed" as const;
  readonly status: number | null;
  readonly errorCode: string | null;
  constructor(args: { status: number | null; errorCode?: string | null; message?: string }) {
    super(
      args.message ??
        `Keycloak auth failed${args.status === null ? "" : ` (status ${String(args.status)})`}${
          args.errorCode === null || args.errorCode === undefined ? "" : ` [${args.errorCode}]`
        }.`,
    );
    this.name = "KeycloakAuthException";
    this.status = args.status;
    this.errorCode = args.errorCode ?? null;
  }
}
