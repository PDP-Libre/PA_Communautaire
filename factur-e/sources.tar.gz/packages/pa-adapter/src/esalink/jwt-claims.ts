import { Buffer } from "node:buffer";

import type { EsaLinkJwtClaims } from "../types.js";

/**
 * Décodage local du payload JWT Keycloak Hubtimize pour observabilité
 * (ADR-011 D3). Le JWT est signé RS256 côté serveur Keycloak — la
 * signature **n'est pas vérifiée localement** : le serveur Hubtimize
 * fait foi pour l'autorisation. Le décodage ne sert qu'à exposer les
 * claims utiles pour log + audit (`entityId`, `sub`, `roles`, `groups`).
 *
 * Pure, pas d'IO. Tolérant aux variantes de format (JWT mal formé,
 * payload non-JSON, champs absents) → retourne des claims avec champs
 * `null` plutôt que throw.
 */

/** Extrait le payload (segment 2) d'un JWT et le décode base64url → JSON. */
function decodeJwtPayload(jwt: string): Record<string, unknown> | null {
  const parts = jwt.split(".");
  if (parts.length !== 3) return null;
  const payloadSegment = parts[1];
  if (payloadSegment === undefined || payloadSegment === "") return null;
  try {
    // `base64url` (Node 22 natif) tolère l'absence de padding et
    // remplace `-` / `_` par `+` / `/` automatiquement.
    const decoded = Buffer.from(payloadSegment, "base64url").toString("utf8");
    const parsed: unknown = JSON.parse(decoded);
    if (parsed === null || typeof parsed !== "object") return null;
    return parsed as Record<string, unknown>;
  } catch {
    return null;
  }
}

function asString(v: unknown): string | null {
  return typeof v === "string" && v.length > 0 ? v : null;
}

function asStringArray(v: unknown): string[] {
  if (!Array.isArray(v)) return [];
  return v.filter((x): x is string => typeof x === "string");
}

/**
 * Décode un JWT Keycloak Hubtimize en `EsaLinkJwtClaims`. Champs
 * absents → `null` ou `[]`. Si le JWT est mal formé → tous les champs
 * sont des défauts (la méthode ne throw jamais — observabilité best
 * effort).
 *
 * Claims attendus (cf. tests sandbox 2026-05-17 testesalink.txt) :
 *  - `sub` : UUID utilisateur Keycloak
 *  - `entityId` : ID interne PA Hubtimize (integer)
 *  - `preferred_username` / `email` : email du compte distributeur
 *  - `resource_access.hubtimize.roles[]` : rôles fonctionnels
 *  - `groups[]` : groupes Keycloak
 *  - `iss` : issuer Keycloak (URL realm)
 */
export function decodeEsaLinkJwt(accessToken: string): EsaLinkJwtClaims {
  const payload = decodeJwtPayload(accessToken);
  if (payload === null) {
    return {
      sub: "",
      entityId: null,
      email: null,
      roles: [],
      groups: [],
      iss: null,
    };
  }
  // entityId : integer dans le JWT — préservé en number.
  const entityIdRaw = payload.entityId;
  const entityId = typeof entityIdRaw === "number" ? entityIdRaw : null;
  const email = asString(payload.email) ?? asString(payload.preferred_username);
  // Roles nichés dans `resource_access.hubtimize.roles`.
  let roles: string[] = [];
  const resourceAccess = payload.resource_access;
  if (resourceAccess !== null && typeof resourceAccess === "object") {
    const hubtimize = (resourceAccess as Record<string, unknown>).hubtimize;
    if (hubtimize !== null && typeof hubtimize === "object") {
      roles = asStringArray((hubtimize as Record<string, unknown>).roles);
    }
  }
  return {
    sub: asString(payload.sub) ?? "",
    entityId,
    email,
    roles,
    groups: asStringArray(payload.groups),
    iss: asString(payload.iss),
  };
}
