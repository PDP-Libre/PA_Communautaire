import {
  InvoiceRejectedXsdException,
  KeycloakAuthException,
  PaAccessTokenExpiredException,
  PaForbiddenException,
  PaProtocolException,
  PaRateLimitException,
} from "../errors.js";

type RetryOrFatal = { kind: "retry"; status: number } | { kind: "fatal"; error: Error };

/**
 * Mapping erreurs EsaLink/Hubtimize vers exceptions typées pa-adapter
 * (ADR-011 D9 + ADR-012 D8).
 *
 * Format erreur EsaLink : `{errorCode: string, errorMessage: string|null}`
 * (= schema `ErrorMessage` v1.2.5). Codes observés sandbox 2026-05-17 :
 *  - `MISSING_REQUIRED_FIELD` (400)
 *  - `MISSING_TOKEN` (401)
 *  - `FORBIDDEN_ACCESS` (403)
 *  - `MISSING_RESOURCE` (404)
 *  - `REQUEST_TIMEOUT` (408)
 *  - `UNPROCESSABLE_ENTITY` (422)
 *  - `TOO_MANY_REQUESTS` (429)
 *  - `INTERNAL_ERROR` (500)
 *  - `NOT_IMPLEMENTED` (501)
 *  - `RESOURCE_ERROR` (503)
 */

interface EsaLinkErrorBody {
  errorCode: string | null;
  errorMessage: string | null;
}

async function readEsaLinkErrorBody(res: Response): Promise<EsaLinkErrorBody> {
  try {
    const json = (await res.json()) as Record<string, unknown>;
    const errorCode =
      typeof json.errorCode === "string" && json.errorCode !== "" ? json.errorCode : null;
    const errorMessage = typeof json.errorMessage === "string" ? json.errorMessage : null;
    return { errorCode, errorMessage };
  } catch {
    return { errorCode: null, errorMessage: null };
  }
}

function parseRetryAfter(value: string | null): number | null {
  if (value === null || value === "") return null;
  const parsed = Number.parseInt(value, 10);
  if (!Number.isFinite(parsed) || parsed < 0) return null;
  return parsed;
}

/** Mappe une réponse HTTP EsaLink non-ok vers `RetryOrFatal`. Retourne
 *  `null` si la réponse est 2xx (le caller continue le parsing). */
export async function mapEsaLinkHttpError(res: Response): Promise<RetryOrFatal | null> {
  if (res.status >= 200 && res.status < 300) return null;
  if (res.status >= 500) {
    // Retry plafonné sur 5xx (cohérent ADR-005 D11 SuperPDP).
    return { kind: "retry", status: res.status };
  }
  const body = await readEsaLinkErrorBody(res);
  const detail = body.errorMessage ?? body.errorCode;

  if (res.status === 401) {
    return { kind: "fatal", error: new PaAccessTokenExpiredException() };
  }
  if (res.status === 403) {
    return { kind: "fatal", error: new PaForbiddenException({ detail }) };
  }
  if (res.status === 422) {
    return { kind: "fatal", error: new InvoiceRejectedXsdException({ detail }) };
  }
  if (res.status === 429) {
    const retryAfter = parseRetryAfter(res.headers.get("retry-after"));
    return {
      kind: "fatal",
      error: new PaRateLimitException({ retryAfterSeconds: retryAfter }),
    };
  }
  return {
    kind: "fatal",
    error: new PaProtocolException({
      status: res.status,
      responseBody: detail,
      message: detail ?? `EsaLink ${String(res.status)} (no errorMessage).`,
    }),
  };
}

/** Spécifique authenticateOrchestrator : tout échec du token endpoint
 *  Keycloak → `KeycloakAuthException` (distinct de `PaProtocolException`
 *  pour permettre au caller de retry / re-prompt credentials). */
export async function throwKeycloakAuthError(res: Response): Promise<never> {
  const body = await readEsaLinkErrorBody(res);
  throw new KeycloakAuthException({
    status: res.status,
    errorCode: body.errorCode,
    message: body.errorMessage ?? undefined,
  });
}
