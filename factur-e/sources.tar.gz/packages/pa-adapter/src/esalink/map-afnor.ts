import type { DirectoryAddress, DirectoryCompany } from "../driver.js";

/**
 * Mapping AFNOR/INSEE EsaLink → shape sprint-03 `DirectoryCompany` /
 * `DirectoryAddress` (compat UI sprint-03 `BuyerSearch`).
 *
 * Sources :
 *  - `GET /v1/siren/code-insee:<siren>` (Directory.yml v1.2.5) →
 *    schema `LegalUnitPayloadHistory` (AFNOR, à valider sandbox V2).
 *  - `POST /v1/directory-line/search` body `{sirenNumber}` →
 *    schema `Directory_line_search_post_200_response`.
 *
 * V1 sandbox compte démo : 403 FORBIDDEN_ACCESS observé sur les 2
 * endpoints — mapping testé contre `fakeHubtimize` mocks only.
 * V2 : raffiner les shapes une fois compte sandbox réel provisionné.
 */

type AsRecord = Record<string, unknown>;

function asString(v: unknown): string | null {
  return typeof v === "string" && v.length > 0 ? v : null;
}

function isRecord(v: unknown): v is AsRecord {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

/**
 * Mappe une réponse `GET /v1/siren/code-insee:<siren>` (AFNOR
 * LegalUnitPayloadHistory) vers `DirectoryCompany`. Fields tolérés
 * (champ exact AFNOR à valider sandbox V2) :
 *  - `siren` ou `sirenNumber` → number
 *  - `businessName` ou `formal_name` → formal_name
 *  - `address.street` / `address.postcode` / `address.city` / `address.country`
 *
 * Retourne `null` si le payload est trop incomplet (au moins siren +
 * formal_name doivent être présents).
 */
export function mapAfnorLegalUnitToCompany(raw: unknown): DirectoryCompany | null {
  if (!isRecord(raw)) return null;
  const number = asString(raw.siren) ?? asString(raw.sirenNumber);
  const formalName = asString(raw.businessName) ?? asString(raw.formal_name);
  if (number === null || formalName === null) return null;
  const address = isRecord(raw.address) ? raw.address : null;
  return {
    number,
    formal_name: formalName,
    address: address === null ? "" : (asString(address.street) ?? ""),
    postcode: address === null ? "" : (asString(address.postcode) ?? ""),
    city: address === null ? "" : (asString(address.city) ?? ""),
    country: address === null ? "" : (asString(address.country) ?? ""),
  };
}

/**
 * Mappe une réponse `POST /v1/directory-line/search` vers `DirectoryAddress[]`.
 * Shape source supposée :
 *   `{data: [{identifier, qualifier, isActive, paName?}, ...]}`
 * (alias `routingCode` / `peppolId` tolérés). Filtre les entrées
 * incomplètes silencieusement.
 */
export function mapAfnorDirectoryLines(raw: unknown): DirectoryAddress[] {
  if (!isRecord(raw)) return [];
  const data = raw.data;
  if (!Array.isArray(data)) return [];
  const out: DirectoryAddress[] = [];
  for (const item of data) {
    if (!isRecord(item)) continue;
    const identifier =
      asString(item.identifier) ?? asString(item.routingCode) ?? asString(item.peppolId);
    if (identifier === null) continue;
    const colonIdx = identifier.indexOf(":");
    const schemeId = colonIdx === -1 ? "0225" : identifier.slice(0, colonIdx);
    const isActive = item.isActive === true || item.is_active === true;
    const paName = asString(item.paName) ?? asString(item.pa_name);
    out.push({
      party_id: identifier,
      scheme_id: schemeId,
      is_active: isActive,
      pa_name: paName,
    });
  }
  return out;
}
