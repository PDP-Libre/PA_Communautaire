/**
 * `verifyWebhookSignature` — vérification HMAC-SHA256 d'un payload
 * webhook PA. Fonction pure (pas d'IO, pas d'état driver) — utilisable
 * indépendamment du `SuperPDPDriver`.
 *
 * Convention SuperPDP (à confirmer T-BR-EMIT partenaire — pas exposé
 * en OpenAPI sandbox) :
 *  - Header `X-Superpdp-Signature` au format `sha256=<hex>` OU hex nu.
 *    Le parseur tolère les deux formats.
 *  - HMAC calculé sur les **octets bruts** du body HTTP (avant parsing
 *    JSON Fastify). Le caller route doit consommer le raw body.
 *
 * Sécurité :
 *  - `crypto.timingSafeEqual` pour la comparaison — pas de fuite par
 *    timing attack.
 *  - Si les deux buffers n'ont pas la même longueur, `timingSafeEqual`
 *    throw — on retourne `false` en pré-check explicite.
 *  - Pas de log du secret ni de la signature reçue (ADR-009 D5 audit
 *    `pa_webhook_signature_invalid` n'enregistre que metadata IP /
 *    headers non sensibles).
 *
 * cf. ADR-009 D4 (idempotence webhook + polling), §11.1 secrets management.
 */

import { createHmac, timingSafeEqual } from "node:crypto";

import type { VerifyWebhookSignatureArgs } from "./driver.js";

/** Préfixe optionnel `sha256=` qui peut être présent dans le header
 *  (convention GitHub / Stripe / certaines PA). Stripped si présent. */
const SIGNATURE_PREFIX = "sha256=";

export function verifyWebhookSignature(args: VerifyWebhookSignatureArgs): boolean {
  if (args.signature === "" || args.secret === "") return false;

  const provided = args.signature.startsWith(SIGNATURE_PREFIX)
    ? args.signature.slice(SIGNATURE_PREFIX.length)
    : args.signature;

  // Hex chars only — reject malformed signatures sans laisser fuiter
  // l'info via une exception node:crypto.
  if (!/^[0-9a-fA-F]+$/.test(provided)) return false;

  const computed = createHmac("sha256", args.secret).update(args.payload).digest("hex");

  // `timingSafeEqual` requires equal-length buffers. Si la longueur
  // diffère, c'est forcément KO — pas de raison de comparer.
  if (provided.length !== computed.length) return false;

  const providedBuf = Buffer.from(provided.toLowerCase(), "utf8");
  const computedBuf = Buffer.from(computed.toLowerCase(), "utf8");
  return timingSafeEqual(providedBuf, computedBuf);
}
