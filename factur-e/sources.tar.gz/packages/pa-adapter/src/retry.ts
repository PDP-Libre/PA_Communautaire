/**
 * `withRetry` — backoff plafonné pour les appels SuperPDP soumis aux
 * 5xx sandbox ADR-005 D11. Max 2 retry, backoff exponentiel 1s/2s.
 *
 * Le caller fournit un `attempt` async qui :
 *  - retourne `{ kind: 'ok', value }` sur succès → renvoyé tel quel.
 *  - retourne `{ kind: 'retry', status }` sur 5xx → ré-essai après
 *    backoff (jusqu'à `maxRetries`).
 *  - retourne `{ kind: 'fatal', error }` sur 4xx ou erreur typée → la
 *    chaîne `withRetry` termine immédiatement et propage l'erreur sans
 *    retry (pas de retry sur 4xx — erreur logique).
 *
 * Sur épuisement des retries, le caller récupère le dernier `status` 5xx
 * via `last5xxStatus` pour construire `PaUnavailableException`.
 */

export interface RetryOk<T> {
  kind: "ok";
  value: T;
}
export interface RetryRetry {
  kind: "retry";
  status: number;
}
export interface RetryFatal {
  kind: "fatal";
  error: unknown;
}
export type AttemptResult<T> = RetryOk<T> | RetryRetry | RetryFatal;

export interface WithRetryOptions {
  /** Nombre max de retries (max 2 par ADR-005 D11). */
  maxRetries?: number;
  /** Backoff en ms entre les retries — 1ère valeur après 1er échec, etc.
   *  Si la liste est plus courte que `maxRetries`, la dernière valeur
   *  est répétée. Default ADR-005 : `[1000, 2000]`. */
  backoffMs?: readonly number[];
  /** Override `setTimeout` pour tests (instant retries). */
  sleep?: (ms: number) => Promise<void>;
}

export type WithRetryResult<T> = { kind: "ok"; value: T } | { kind: "exhausted"; status: number };

const defaultSleep = (ms: number): Promise<void> =>
  new Promise<void>((resolve) => setTimeout(resolve, ms));

/** Run `attempt` with up to `maxRetries` retries on 5xx. Throws fatal
 *  errors (4xx, typed exceptions) immediately. */
export async function withRetry<T>(
  attempt: () => Promise<AttemptResult<T>>,
  options: WithRetryOptions = {},
): Promise<WithRetryResult<T>> {
  const maxRetries = options.maxRetries ?? 2;
  const backoffMs = options.backoffMs ?? [1000, 2000];
  const sleep = options.sleep ?? defaultSleep;

  let lastStatus = 500;
  for (let i = 0; i <= maxRetries; i += 1) {
    const result = await attempt();
    if (result.kind === "ok") return { kind: "ok", value: result.value };
    if (result.kind === "fatal") throw result.error;
    lastStatus = result.status;
    if (i === maxRetries) break;
    const wait = backoffMs[Math.min(i, backoffMs.length - 1)] ?? 0;
    if (wait > 0) await sleep(wait);
  }
  return { kind: "exhausted", status: lastStatus };
}
