import type {
  AuthorizeArgs,
  AuthorizeChallenge,
  CdarEvent,
  CreateInvoiceEventInput,
  CreateInvoiceEventOutput,
  CustomerContext,
  DirectoryAddress,
  ConnectedCompany,
  ConnectedCompanyAddress,
  DirectoryCompany,
  DirectorySearchResult,
  DownloadInvoiceFileInput,
  DownloadInvoiceFileResult,
  ExchangeCodeArgs,
  GetConnectedCompanyArgs,
  GetOwnDirectoryEntriesArgs,
  GetIdentityStatusArgs,
  IdentityStatus,
  IdentityStatusSnapshot,
  IncomingInvoice,
  IncomingInvoiceEnData,
  ListIncomingInvoicesInput,
  ListIncomingInvoicesOutput,
  PADriverWebOnboarding,
  PaTokens,
  PollCdarEventsInput,
  PollCdarEventsOutput,
  RefreshTokenArgs,
  RevokeArgs,
  SearchSirenArgs,
  SubmitInvoiceInput,
  SubmitInvoiceOutput,
} from "./driver.js";
import {
  InvoiceRejectedXsdException,
  PaAccessTokenExpiredException,
  PaForbiddenException,
  PaInvalidStateException,
  PaProtocolException,
  PaRateLimitException,
  PaSubmissionFailedException,
  PaUnavailableException,
  RefreshExpiredException,
} from "./errors.js";
import { deriveS256Challenge, generateCodeVerifier, generateState } from "./pkce.js";
import { withRetry, type AttemptResult, type WithRetryOptions } from "./retry.js";
import { mapSuperPDPStatusCode } from "./superpdp/map-status-code.js";
import type { PaCredentials, PaCustomerSnapshot } from "./types.js";

/**
 * `SuperPDPDriver` — implémentation `PADriverWebOnboarding` pour SuperPDP
 * partenaire MVP. Refondue T-CL-PA-INVOICE-FIX sprint-04 (ADR-010 v2)
 * pour consommer l'API propriétaire JSON `/v1.beta/*` réelle :
 *
 *  - **OAuth + searchSiren + identity** : préservés sprint-03 (D1-D12
 *    ADR-005 inchangés — `authorize` / `exchangeCode` / `refreshToken` /
 *    `revoke` / `getIdentityStatus` / `searchSiren`).
 *  - **submitInvoice** : `POST /v1.beta/invoices?external_id={trackingId}&disable_pre_check={bool}`
 *    body `application/pdf` direct (ADR-010 v2 D3). Idempotence garantie
 *    par `external_id` UUID v7 Factur-E (D7).
 *  - **pollCdarEvents** : `GET /v1.beta/invoice_events?starting_after_id={cursor}&limit={n}`
 *    cursor Stripe-like global (D4). Remplace l'ancien
 *    `GET /v1.beta/flows/{id}/events` per-invoice de T-CL-PA-EXT (paths
 *    inventés — n'existaient pas).
 *  - **getCustomerSnapshot** : wrapper `getIdentityStatus` exposant un
 *    `PaCustomerSnapshot` unifié (ADR-012 D1).
 *  - **healthcheck** : placeholder `true` V1 (pas d'endpoint dédié
 *    documenté côté SuperPDP propriétaire). À raffiner V2 si besoin.
 *
 * Format erreur SuperPDP `{http_status_code, message}` (ADR-010 v2 D5)
 * mappé vers exceptions typées sprint-03 (`PaAccessTokenExpiredException`,
 * `PaForbiddenException`, `InvoiceRejectedXsdException`,
 * `PaRateLimitException`, `PaSubmissionFailedException`,
 * `PaProtocolException`). Le `message` français explicatif est préservé
 * via le champ `detail` des exceptions.
 *
 * Configuration (constructor injection) :
 *  - `clientId` / `clientSecret` : credentials Factur-e -> SuperPDP.
 *    En dev : Keychain `superpdp-sandbox-client-{id,secret}` (convention
 *    sprint-03 préservée — arbitrage Bruno Z1).
 *  - `baseUrl` : `https://api.superpdp.tech` (prod) ou `fakeSuperPdp`
 *    en tests.
 *  - `fetch` : injectable pour tests.
 *  - `retryOptions` : override defaults ADR-005 D11.
 */

const DEFAULT_BASE_URL = "https://api.superpdp.tech";

/** Timeout des appels annuaire. 8 s = 16x la latence p99 GET sandbox. */
const DIRECTORY_FETCH_TIMEOUT_MS = 8000;

/** Limite default pour `pollCdarEvents` — SuperPDP max 1000.
 *  100 = trade-off bandwidth × fréquence tick (cron every-15-min default). */
const DEFAULT_POLL_LIMIT = 100;

export interface SuperPDPDriverConfig {
  clientId: string;
  clientSecret: string;
  baseUrl?: string;
  /** Override `fetch` for tests. */
  fetch?: typeof globalThis.fetch;
  retryOptions?: WithRetryOptions;
}

export class SuperPDPDriver implements PADriverWebOnboarding {
  readonly providerId = "superpdp" as const;
  readonly onboardingMode = "web-authorization-code" as const;

  private readonly clientId: string;
  private readonly clientSecret: string;
  private readonly baseUrl: string;
  private readonly fetchFn: typeof globalThis.fetch;
  private readonly retryOptions: WithRetryOptions;

  constructor(cfg: SuperPDPDriverConfig) {
    this.clientId = cfg.clientId;
    this.clientSecret = cfg.clientSecret;
    this.baseUrl = cfg.baseUrl ?? DEFAULT_BASE_URL;
    this.fetchFn = cfg.fetch ?? globalThis.fetch;
    this.retryOptions = cfg.retryOptions ?? {};
  }

  // ───────────────────────────────────────────────────────────────────
  // PADriverCore — capability obligatoire (ADR-012 D1)
  // ───────────────────────────────────────────────────────────────────

  /** Placeholder V1 — SuperPDP propriétaire n'expose pas d'endpoint
   *  `/health` documenté côté `superpdp.json`. Retourne `true`. À
   *  raffiner V2 (probe sur `GET /v1.beta/companies/me` avec credentials
   *  Client Credentials utilitaire si on en provisionne un côté
   *  registry). */
  healthcheck(): Promise<boolean> {
    return Promise.resolve(true);
  }

  // ───────────────────────────────────────────────────────────────────
  // PADriverWebOnboarding — OAuth (préservés sprint-03 ADR-005)
  // ───────────────────────────────────────────────────────────────────

  authorize(args: AuthorizeArgs): Promise<AuthorizeChallenge> {
    const codeVerifier = generateCodeVerifier();
    const state = generateState();
    const challenge = deriveS256Challenge(codeVerifier);
    const params = new URLSearchParams({
      client_id: this.clientId,
      redirect_uri: args.redirectUri,
      state,
      code_challenge: challenge,
      code_challenge_method: "S256",
      response_type: "code",
    });
    // No `scope` parameter — ADR-005 D3 (SuperPDP `scopes: {}`).
    const authorizeUrl = `${this.baseUrl}/oauth2/authorize?${params.toString()}`;
    return Promise.resolve({ authorizeUrl, state, codeVerifier });
  }

  async exchangeCode(args: ExchangeCodeArgs): Promise<PaTokens> {
    if (args.state !== args.expectedState) {
      throw new PaInvalidStateException();
    }
    const tokenResp = await this.callTokenEndpoint(
      new URLSearchParams({
        grant_type: "authorization_code",
        code: args.code,
        code_verifier: args.codeVerifier,
        redirect_uri: args.redirectUri,
        client_id: this.clientId,
        client_secret: this.clientSecret,
      }),
    );
    const tokens = parseTokenResponse(tokenResp);
    const identity = await this.getIdentityStatusInternal(tokens.accessToken);
    return { ...tokens, paUserId: identity.paUserId };
  }

  async refreshToken(args: RefreshTokenArgs): Promise<PaTokens> {
    const result = await withRetry(async (): Promise<AttemptResult<unknown>> => {
      const res = await this.fetchFn(`${this.baseUrl}/oauth2/token`, {
        method: "POST",
        headers: { "content-type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          grant_type: "refresh_token",
          refresh_token: args.refreshToken,
          client_id: this.clientId,
          client_secret: this.clientSecret,
        }).toString(),
      });
      if (res.status >= 500) return { kind: "retry", status: res.status };
      if (res.status === 400) {
        const body = (await readJsonSafe(res)) as { error?: unknown } | null;
        if (body !== null && body.error === "invalid_grant") {
          return { kind: "fatal", error: new RefreshExpiredException() };
        }
        return {
          kind: "fatal",
          error: new PaProtocolException({
            status: 400,
            responseBody: body === null ? null : JSON.stringify(body),
          }),
        };
      }
      if (!res.ok) {
        return {
          kind: "fatal",
          error: new PaProtocolException({ status: res.status, responseBody: null }),
        };
      }
      const json: unknown = await res.json();
      return { kind: "ok", value: json };
    }, this.retryOptions);
    if (result.kind === "exhausted") {
      throw new PaUnavailableException({ status: result.status });
    }
    const tokens = parseTokenResponse(result.value);
    return { ...tokens, paUserId: null };
  }

  async revoke(args: RevokeArgs): Promise<void> {
    const result = await withRetry(async (): Promise<AttemptResult<unknown>> => {
      const res = await this.fetchFn(`${this.baseUrl}/oauth2/revoke`, {
        method: "POST",
        headers: { "content-type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          token: args.refreshToken,
          token_type_hint: "refresh_token",
          client_id: this.clientId,
          client_secret: this.clientSecret,
        }).toString(),
      });
      if (res.status >= 500) return { kind: "retry", status: res.status };
      if (!res.ok) {
        return {
          kind: "fatal",
          error: new PaProtocolException({ status: res.status, responseBody: null }),
        };
      }
      return { kind: "ok", value: null };
    }, this.retryOptions);
    if (result.kind === "exhausted") {
      throw new PaUnavailableException({ status: result.status });
    }
  }

  getIdentityStatus(args: GetIdentityStatusArgs): Promise<IdentityStatusSnapshot> {
    return this.getIdentityStatusInternal(args.accessToken);
  }

  /** T-CL-SIREN-RECONCILIATION sprint-06 W1 — société rattachée au token
   *  via `GET /v1.beta/companies/me` (schéma `company`). Source du SIREN
   *  attesté KYC pour la réconciliation (Mécanisme 3). Retry 5xx + même
   *  mapping d'erreurs que les autres lectures (`PaUnavailableException`
   *  sur épuisement, `PaProtocolException` sur 4xx non géré). */
  getConnectedCompany(args: GetConnectedCompanyArgs): Promise<ConnectedCompany> {
    return this.getConnectedCompanyInternal(args.accessToken);
  }

  /** T-CL-PA-OWN-DIRECTORY-ENTRIES sprint-06 — adresses Peppol propres via
   *  `GET /v1.beta/directory_entries` (authentifié). Source de l'adresse
   *  émetteur, vs `french_directory` (public, lookup de tiers). */
  getOwnDirectoryEntries(args: GetOwnDirectoryEntriesArgs): Promise<DirectorySearchResult> {
    return this.getOwnDirectoryEntriesInternal(args.accessToken);
  }

  /** Snapshot customer unifié (ADR-012 D1). Pour SuperPDP : wrap
   *  `getIdentityStatus` + populate `provider` discriminator. */
  async getCustomerSnapshot(ctx: CustomerContext): Promise<PaCustomerSnapshot> {
    const accessToken = extractSuperPDPAccessToken(ctx.credentials);
    const identity = await this.getIdentityStatusInternal(accessToken);
    return {
      provider: "superpdp",
      identity,
    };
  }

  // ───────────────────────────────────────────────────────────────────
  // Pipeline facture — refactor T-CL-PA-INVOICE-FIX (ADR-010 v2 D3+D4)
  // ───────────────────────────────────────────────────────────────────

  async submitInvoice(
    input: SubmitInvoiceInput,
    ctx: CustomerContext,
  ): Promise<SubmitInvoiceOutput> {
    const accessToken = extractSuperPDPAccessToken(ctx.credentials);

    // Query params : `external_id` UUID v7 Factur-E pour idempotence,
    // `disable_pre_check` arbitrage Bruno Z3 (default false en prod —
    // Schematron BR-FR appliqué ; tests intégration peuvent setter true
    // si le sample factur-x-builder ne passe pas BR-FR).
    const params = new URLSearchParams({
      external_id: input.trackingId,
      disable_pre_check: input.disablePreCheck === true ? "true" : "false",
    });
    const url = `${this.baseUrl}/v1.beta/invoices?${params.toString()}`;

    const result = await withRetry(async (): Promise<AttemptResult<SubmitInvoiceOutput>> => {
      // Body `application/pdf` direct (ADR-010 v2 D3) — pas de
      // multipart. `Uint8Array` clone du Buffer pour BodyInit fetch
      // (Node 22 fetch accepte Buffer mais on garantit la primitive
      // pour TypeScript strict).
      const res = await this.fetchFn(url, {
        method: "POST",
        headers: {
          authorization: `Bearer ${accessToken}`,
          "content-type": "application/pdf",
          accept: "application/json",
        },
        body: new Uint8Array(input.pdfBytes),
      });

      const submitErr = await mapSuperPDPHttpError(res, "submitInvoice");
      if (submitErr !== null) return submitErr;

      const json = (await res.json()) as Record<string, unknown>;
      const parsed = parseInvoiceResponse(json);
      if (parsed === null) {
        return {
          kind: "fatal",
          error: new PaProtocolException({
            status: res.status,
            message: "POST /v1.beta/invoices: missing id or created_at in response.",
          }),
        };
      }
      return { kind: "ok", value: parsed };
    }, this.retryOptions);
    if (result.kind === "exhausted") {
      throw new PaSubmissionFailedException({
        retries: this.retryOptions.maxRetries ?? 2,
        lastStatus: result.status,
      });
    }
    return result.value;
  }

  async pollCdarEvents(
    input: PollCdarEventsInput,
    ctx: CustomerContext,
  ): Promise<PollCdarEventsOutput> {
    const accessToken = extractSuperPDPAccessToken(ctx.credentials);

    // Cursor Stripe-like `starting_after_id` (ADR-010 v2 D4). Cursor
    // initial passé par le caller = `'0'` (cf. repo `pa_polling_state`).
    const params = new URLSearchParams({
      starting_after_id: input.cursor,
      limit: String(input.limit ?? DEFAULT_POLL_LIMIT),
    });
    const url = `${this.baseUrl}/v1.beta/invoice_events?${params.toString()}`;

    const result = await withRetry(async (): Promise<AttemptResult<PollCdarEventsOutput>> => {
      const res = await this.fetchFn(url, {
        method: "GET",
        headers: {
          authorization: `Bearer ${accessToken}`,
          accept: "application/json",
        },
      });

      const pollErr = await mapSuperPDPHttpError(res, "pollCdarEvents");
      if (pollErr !== null) return pollErr;

      const json = (await res.json()) as Record<string, unknown>;
      const events = parseEventsListResponse(json);

      // nextCursor = id du dernier event reçu (cursor SuperPDP). Si
      // batch vide → cursor inchangé (caller stocke `input.cursor`
      // pour que le tick suivant retente exactement le même range).
      const last = events[events.length - 1];
      const nextCursor = last !== undefined ? last.paEventId : input.cursor;
      const hasMore = json.has_after === true;

      return { kind: "ok", value: { events, nextCursor, hasMore } };
    }, this.retryOptions);
    if (result.kind === "exhausted") {
      throw new PaUnavailableException({ status: result.status });
    }
    return result.value;
  }

  // ───────────────────────────────────────────────────────────────────
  // Réception — T-CL-RECV-API sprint-05 W2 (ADR-010 v2)
  // ───────────────────────────────────────────────────────────────────

  async listIncomingInvoices(
    input: ListIncomingInvoicesInput,
    ctx: CustomerContext,
  ): Promise<ListIncomingInvoicesOutput> {
    const accessToken = extractSuperPDPAccessToken(ctx.credentials);

    // `GET /v1.beta/invoices?direction=in&starting_after_id=&limit=&order=asc`
    // + `expand[]=en_invoice` (+ `en_invoice.seller`) pour récupérer les
    // données EN 16931 structurées (number / dates / totals / seller) sans
    // parser le XML en boucle. Pagination cursor Stripe-like (`has_after`).
    const params = new URLSearchParams({
      direction: "in",
      starting_after_id: input.cursor,
      limit: String(input.limit ?? DEFAULT_POLL_LIMIT),
      order: "asc",
    });
    params.append("expand[]", "en_invoice");
    params.append("expand[]", "en_invoice.seller");
    const url = `${this.baseUrl}/v1.beta/invoices?${params.toString()}`;

    const result = await withRetry(async (): Promise<AttemptResult<ListIncomingInvoicesOutput>> => {
      const res = await this.fetchFn(url, {
        method: "GET",
        headers: { authorization: `Bearer ${accessToken}`, accept: "application/json" },
      });

      const listErr = await mapSuperPDPHttpError(res, "listIncomingInvoices");
      if (listErr !== null) return listErr;

      const json = (await res.json()) as Record<string, unknown>;
      const invoices = parseIncomingInvoicesResponse(json);
      const last = invoices[invoices.length - 1];
      const nextCursor = last !== undefined ? last.paInvoiceId : input.cursor;
      const hasMore = json.has_after === true;
      return { kind: "ok", value: { invoices, nextCursor, hasMore } };
    }, this.retryOptions);
    if (result.kind === "exhausted") {
      throw new PaUnavailableException({ status: result.status });
    }
    return result.value;
  }

  async createInvoiceEvent(
    input: CreateInvoiceEventInput,
    ctx: CustomerContext,
  ): Promise<CreateInvoiceEventOutput> {
    const accessToken = extractSuperPDPAccessToken(ctx.credentials);

    // `POST /v1.beta/invoice_events` body `{invoice_id, status_code,
    // details[]}`. Le motif de refus 210 (code Annexe E) part dans
    // `details[].reason` (ReasonCode MDT-113 AFNOR XP Z12-012). Le
    // `invoice_id` SuperPDP est un integer → cast depuis le string.
    const invoiceIdNum = Number.parseInt(input.paInvoiceId, 10);
    const body: Record<string, unknown> = {
      invoice_id: Number.isFinite(invoiceIdNum) ? invoiceIdNum : input.paInvoiceId,
      status_code: input.statusCode,
    };
    if (input.reasonCode !== undefined && input.reasonCode !== "") {
      body.details = [{ reason: input.reasonCode }];
    }
    const url = `${this.baseUrl}/v1.beta/invoice_events`;

    const result = await withRetry(async (): Promise<AttemptResult<CreateInvoiceEventOutput>> => {
      const res = await this.fetchFn(url, {
        method: "POST",
        headers: {
          authorization: `Bearer ${accessToken}`,
          "content-type": "application/json",
          accept: "application/json",
        },
        body: JSON.stringify(body),
      });

      const postErr = await mapSuperPDPHttpError(res, "createInvoiceEvent");
      if (postErr !== null) return postErr;

      const json = (await res.json()) as Record<string, unknown>;
      const parsed = parseCreateEventResponse(json, input.statusCode);
      return { kind: "ok", value: parsed };
    }, this.retryOptions);
    if (result.kind === "exhausted") {
      throw new PaSubmissionFailedException({
        retries: this.retryOptions.maxRetries ?? 2,
        lastStatus: result.status,
      });
    }
    return result.value;
  }

  async downloadInvoiceFile(
    input: DownloadInvoiceFileInput,
    ctx: CustomerContext,
  ): Promise<DownloadInvoiceFileResult> {
    const accessToken = extractSuperPDPAccessToken(ctx.credentials);
    const url = `${this.baseUrl}/v1.beta/invoices/${encodeURIComponent(input.paInvoiceId)}/download`;

    const result = await withRetry(async (): Promise<AttemptResult<DownloadInvoiceFileResult>> => {
      const res = await this.fetchFn(url, {
        method: "GET",
        headers: { authorization: `Bearer ${accessToken}` },
      });
      const dlErr = await mapSuperPDPHttpError(res, "downloadInvoiceFile");
      if (dlErr !== null) return dlErr;
      const contentType = res.headers.get("content-type") ?? "application/octet-stream";
      const ab = await res.arrayBuffer();
      return { kind: "ok", value: { bytes: Buffer.from(ab), contentType } };
    }, this.retryOptions);
    if (result.kind === "exhausted") {
      throw new PaUnavailableException({ status: result.status });
    }
    return result.value;
  }

  // ───────────────────────────────────────────────────────────────────
  // Directory (T-CL-09 sprint-03 — préservé)
  // ───────────────────────────────────────────────────────────────────

  async searchSiren(args: SearchSirenArgs, _ctx: CustomerContext): Promise<DirectorySearchResult> {
    // Cascade `companies` → `entries`. No auth required (security: []
    // côté SuperPDP, audit T-CW-08 §3.1). Le `ctx` est accepté pour
    // cohérence multi-PA (EsaLink l'utilisera) mais non consommé ici.
    const companyResult = await this.fetchDirectoryCompanies(args.siren);
    if (companyResult.kind === "unavailable") return companyResult;
    if (companyResult.company === null) return { kind: "not_found" };

    const entriesResult = await this.fetchDirectoryEntries(args.siren);
    if (entriesResult.kind === "unavailable") return entriesResult;

    const activeAddresses = entriesResult.addresses.filter((a) => a.is_active);
    if (activeAddresses.length === 0) {
      return { kind: "disabled", company: companyResult.company };
    }
    if (activeAddresses.length === 1) {
      const onlyAddress = activeAddresses[0];
      if (onlyAddress === undefined) {
        return { kind: "disabled", company: companyResult.company };
      }
      return {
        kind: "found_one_address",
        company: companyResult.company,
        address: onlyAddress,
      };
    }
    return {
      kind: "found_multi_address",
      company: companyResult.company,
      addresses: activeAddresses,
    };
  }

  /**
   * Lecture annuaire customer self à l'onboarding — Scénario A retenu
   * T-CW-02 sprint-05 (cf. `Travail-horsGit/peppol-directory-study-2026-05-22/`).
   *
   * Endpoint `GET /v1.beta/french_directory/entries?number=<siren>`
   * `security: []` public côté SuperPDP. Pas de Bearer requis. Wrap
   * `searchSiren` avec filtre défensif des suffixes `_replyto` techniques
   * (cf. `SuperPDP/InfoGenerales/Annuaire.txt` — adresses de retour PA
   * réception ≠ PA émission, non utilisables comme destinataire facture).
   *
   * Réutilise `searchSiren` interne avec un ctx dummy `superpdp-oauth-cc`
   * à creds vides (pattern acquis sprint-03 `directory/search.ts:62`).
   *
   * @param siren SIREN customer self à résoudre dans l'annuaire SuperPDP.
   * @returns `DirectorySearchResult` avec entries `_replyto` filtrées.
   */
  async fetchOwnPeppolAddresses(siren: string): Promise<DirectorySearchResult> {
    const dummyCtx: CustomerContext = {
      customerId: "directory-self-lookup",
      credentials: {
        kind: "superpdp-oauth-cc",
        accessToken: "",
        accessExpiresAt: new Date(0),
      },
    };
    const result = await this.searchSiren({ siren }, dummyCtx);

    // Filtre défensif `_replyto` (cf. risque Phase 4 §4 + Annuaire.txt
    // section reply-to). L'endpoint public ne semble pas exposer le flag
    // `is_replyto` mais le `party_id` lui-même peut contenir le suffixe
    // technique selon l'historique de l'entry.
    if (result.kind === "found_one_address") {
      if (isReplyToIdentifier(result.address.party_id)) {
        return { kind: "disabled", company: result.company };
      }
      return result;
    }
    if (result.kind === "found_multi_address") {
      const filtered = result.addresses.filter((a) => !isReplyToIdentifier(a.party_id));
      if (filtered.length === 0) {
        return { kind: "disabled", company: result.company };
      }
      if (filtered.length === 1) {
        const only = filtered[0];
        if (only === undefined) return { kind: "disabled", company: result.company };
        return { kind: "found_one_address", company: result.company, address: only };
      }
      return { kind: "found_multi_address", company: result.company, addresses: filtered };
    }
    return result;
  }

  // ───────────────────────────────────────────────────────────────────
  // Internals
  // ───────────────────────────────────────────────────────────────────

  private async callTokenEndpoint(body: URLSearchParams): Promise<unknown> {
    const result = await withRetry(async (): Promise<AttemptResult<unknown>> => {
      const res = await this.fetchFn(`${this.baseUrl}/oauth2/token`, {
        method: "POST",
        headers: { "content-type": "application/x-www-form-urlencoded" },
        body: body.toString(),
      });
      if (res.status >= 500) return { kind: "retry", status: res.status };
      if (!res.ok) {
        const responseBody = await readTextSafe(res);
        return {
          kind: "fatal",
          error: new PaProtocolException({ status: res.status, responseBody }),
        };
      }
      const json: unknown = await res.json();
      return { kind: "ok", value: json };
    }, this.retryOptions);
    if (result.kind === "exhausted") {
      throw new PaUnavailableException({ status: result.status });
    }
    return result.value;
  }

  private async getIdentityStatusInternal(accessToken: string): Promise<IdentityStatusSnapshot> {
    const result = await withRetry(async (): Promise<AttemptResult<IdentityStatusSnapshot>> => {
      const res = await this.fetchFn(`${this.baseUrl}/v1.beta/oauth2_sessions/me`, {
        method: "GET",
        headers: { authorization: `Bearer ${accessToken}` },
      });
      if (res.status >= 500) return { kind: "retry", status: res.status };
      if (!res.ok) {
        const responseBody = await readTextSafe(res);
        return {
          kind: "fatal",
          error: new PaProtocolException({ status: res.status, responseBody }),
        };
      }
      const json = (await res.json()) as Record<string, unknown>;
      return { kind: "ok", value: parseIdentityResponse(json) };
    }, this.retryOptions);
    if (result.kind === "exhausted") {
      throw new PaUnavailableException({ status: result.status });
    }
    return result.value;
  }

  private async getConnectedCompanyInternal(accessToken: string): Promise<ConnectedCompany> {
    const result = await withRetry(async (): Promise<AttemptResult<ConnectedCompany>> => {
      const res = await this.fetchFn(`${this.baseUrl}/v1.beta/companies/me`, {
        method: "GET",
        headers: { authorization: `Bearer ${accessToken}` },
      });
      if (res.status >= 500) return { kind: "retry", status: res.status };
      if (!res.ok) {
        const responseBody = await readTextSafe(res);
        return {
          kind: "fatal",
          error: new PaProtocolException({ status: res.status, responseBody }),
        };
      }
      const json = (await res.json()) as Record<string, unknown>;
      return { kind: "ok", value: parseConnectedCompany(json) };
    }, this.retryOptions);
    if (result.kind === "exhausted") {
      throw new PaUnavailableException({ status: result.status });
    }
    return result.value;
  }

  private async getOwnDirectoryEntriesInternal(
    accessToken: string,
  ): Promise<DirectorySearchResult> {
    const result = await withRetry(async (): Promise<AttemptResult<DirectorySearchResult>> => {
      const res = await this.fetchFn(`${this.baseUrl}/v1.beta/directory_entries`, {
        method: "GET",
        headers: { authorization: `Bearer ${accessToken}`, accept: "application/json" },
      });
      if (res.status >= 500) return { kind: "retry", status: res.status };
      if (!res.ok) {
        const responseBody = await readTextSafe(res);
        return {
          kind: "fatal",
          error: new PaProtocolException({ status: res.status, responseBody }),
        };
      }
      const json = (await res.json()) as Record<string, unknown>;
      return { kind: "ok", value: parseOwnDirectoryEntries(json) };
    }, this.retryOptions);
    if (result.kind === "exhausted") {
      throw new PaUnavailableException({ status: result.status });
    }
    return result.value;
  }

  private async fetchDirectoryCompanies(
    siren: string,
  ): Promise<
    | { kind: "ok"; company: DirectoryCompany | null }
    | { kind: "unavailable"; cause: "timeout" | "5xx" | "network"; status?: number }
  > {
    let response: Response;
    try {
      response = await this.fetchFn(
        `${this.baseUrl}/v1.beta/french_directory/companies?number=${encodeURIComponent(siren)}`,
        {
          method: "GET",
          headers: { accept: "application/json" },
          signal: AbortSignal.timeout(DIRECTORY_FETCH_TIMEOUT_MS),
        },
      );
    } catch (err) {
      const isAbort =
        err instanceof Error && (err.name === "AbortError" || err.name === "TimeoutError");
      return { kind: "unavailable", cause: isAbort ? "timeout" : "network" };
    }
    if (response.status >= 500) {
      return { kind: "unavailable", cause: "5xx", status: response.status };
    }
    if (response.status === 404) {
      return { kind: "ok", company: null };
    }
    if (!response.ok) {
      return { kind: "unavailable", cause: "5xx", status: response.status };
    }
    const json = (await response.json()) as Record<string, unknown>;
    const list = json.data;
    if (!Array.isArray(list) || list.length === 0) {
      return { kind: "ok", company: null };
    }
    const first: unknown = list[0];
    if (first === null || typeof first !== "object") {
      return { kind: "ok", company: null };
    }
    const parsed = parseDirectoryCompany(first as Record<string, unknown>);
    return { kind: "ok", company: parsed };
  }

  private async fetchDirectoryEntries(
    siren: string,
  ): Promise<
    | { kind: "ok"; addresses: DirectoryAddress[] }
    | { kind: "unavailable"; cause: "timeout" | "5xx" | "network"; status?: number }
  > {
    let response: Response;
    try {
      response = await this.fetchFn(
        `${this.baseUrl}/v1.beta/french_directory/entries?number=${encodeURIComponent(siren)}`,
        {
          method: "GET",
          headers: { accept: "application/json" },
          signal: AbortSignal.timeout(DIRECTORY_FETCH_TIMEOUT_MS),
        },
      );
    } catch (err) {
      const isAbort =
        err instanceof Error && (err.name === "AbortError" || err.name === "TimeoutError");
      return { kind: "unavailable", cause: isAbort ? "timeout" : "network" };
    }
    if (response.status >= 500) {
      return { kind: "unavailable", cause: "5xx", status: response.status };
    }
    if (response.status === 404) {
      return { kind: "ok", addresses: [] };
    }
    if (!response.ok) {
      return { kind: "unavailable", cause: "5xx", status: response.status };
    }
    const json = (await response.json()) as Record<string, unknown>;
    const list = json.data;
    if (!Array.isArray(list)) return { kind: "ok", addresses: [] };
    const out: DirectoryAddress[] = [];
    for (const raw of list) {
      if (raw === null || typeof raw !== "object") continue;
      const r = raw as Record<string, unknown>;
      if (r.is_replyto === true) continue;
      const parsed = parseDirectoryEntry(r);
      if (parsed !== null) out.push(parsed);
    }
    return { kind: "ok", addresses: out };
  }
}

// ─────────────────────────────────────────────────────────────────────
// Credentials extraction helper
// ─────────────────────────────────────────────────────────────────────

/** Extrait l'access token utilisable par SuperPDP depuis le bundle
 *  `PaCredentials`. Accepte les 2 variantes SuperPDP (`-oauth-cc` ou
 *  `-oauth-ac`). Throws `PaProtocolException` si le kind du bundle est
 *  EsaLink — c'est une faute de programmation (le caller a passé le
 *  mauvais driver). */
function extractSuperPDPAccessToken(credentials: PaCredentials): string {
  if (credentials.kind === "superpdp-oauth-ac" || credentials.kind === "superpdp-oauth-cc") {
    return credentials.accessToken;
  }
  throw new PaProtocolException({
    status: null,
    message: `SuperPDPDriver received credentials of kind '${credentials.kind}' — expected 'superpdp-oauth-*'.`,
  });
}

// ─────────────────────────────────────────────────────────────────────
// HTTP error mapping — format SuperPDP {http_status_code, message}
// (ADR-010 v2 D5)
// ─────────────────────────────────────────────────────────────────────

/** Lit le body en JSON `{http_status_code, message}` ou null si parse
 *  KO. Le `message` SuperPDP est français explicatif et préservé via
 *  les exceptions typées (`detail` champ). */
async function readSuperPDPErrorBody(
  res: Response,
): Promise<{ http_status_code: number | null; message: string | null }> {
  const json = (await readJsonSafe(res)) as Record<string, unknown> | null;
  if (json === null) return { http_status_code: null, message: null };
  const httpStatus = typeof json.http_status_code === "number" ? json.http_status_code : null;
  const message = typeof json.message === "string" && json.message !== "" ? json.message : null;
  return { http_status_code: httpStatus, message };
}

type RetryOrFatal = { kind: "retry"; status: number } | { kind: "fatal"; error: Error };

/** Mappe une réponse HTTP SuperPDP non-ok vers un `RetryOrFatal`. Retourne
 *  `null` si la réponse est 2xx (le caller continue le parsing). Le type
 *  retourné est une sous-union de `AttemptResult<T>` — assignable au
 *  return type des callbacks `withRetry<T>` pour toute valeur de `T`. */
async function mapSuperPDPHttpError(res: Response, _method: string): Promise<RetryOrFatal | null> {
  if (res.status >= 200 && res.status < 300) return null;

  if (res.status >= 500) {
    return { kind: "retry", status: res.status };
  }

  const errBody = await readSuperPDPErrorBody(res);
  const detail = errBody.message;

  if (res.status === 401) {
    return { kind: "fatal", error: new PaAccessTokenExpiredException() };
  }
  if (res.status === 403) {
    return { kind: "fatal", error: new PaForbiddenException({ detail }) };
  }
  if (res.status === 422) {
    // Validation Factur-X / CII KO côté PA (Schematron BR-FR ou
    // structurelle BT-34/49 non bypassable). Le `message` SuperPDP
    // décrit l'erreur — surfacé au user via le `detail` de l'exception.
    return { kind: "fatal", error: new InvoiceRejectedXsdException({ detail }) };
  }
  if (res.status === 429) {
    const retryAfter = parseRetryAfter(res.headers.get("retry-after"));
    return {
      kind: "fatal",
      error: new PaRateLimitException({ retryAfterSeconds: retryAfter }),
    };
  }
  if (res.status === 400) {
    // Cas spécifiques SuperPDP — message contient
    // `Seller.ElectronicAddress` quand BT-34 est absent (validation
    // structurelle hard non bypassable, cf. tests sandbox 2026-05-16).
    if (detail?.includes("Seller.ElectronicAddress") === true) {
      return { kind: "fatal", error: new InvoiceRejectedXsdException({ detail }) };
    }
    return {
      kind: "fatal",
      error: new PaProtocolException({
        status: 400,
        responseBody: detail,
        message: detail ?? "SuperPDP 400 (no message in body).",
      }),
    };
  }
  // 4xx non mappé — fallback générique.
  return {
    kind: "fatal",
    error: new PaProtocolException({
      status: res.status,
      responseBody: detail,
      message: detail ?? `SuperPDP ${String(res.status)} (no message in body).`,
    }),
  };
}

// ─────────────────────────────────────────────────────────────────────
// Response parsing
// ─────────────────────────────────────────────────────────────────────

function parseTokenResponse(body: unknown): {
  accessToken: string;
  refreshToken: string;
  accessExpiresAt: Date;
} {
  if (body === null || typeof body !== "object") {
    throw new PaProtocolException({ status: null, message: "Token response is not an object." });
  }
  const r = body as Record<string, unknown>;
  const access = r.access_token;
  const refresh = r.refresh_token;
  const expiresInRaw = r.expires_in;
  if (typeof access !== "string" || access === "") {
    throw new PaProtocolException({
      status: null,
      message: "Token response missing access_token.",
    });
  }
  if (typeof refresh !== "string" || refresh === "") {
    throw new PaProtocolException({
      status: null,
      message: "Token response missing refresh_token.",
    });
  }
  const expiresIn = typeof expiresInRaw === "number" ? expiresInRaw : 1800;
  return {
    accessToken: access,
    refreshToken: refresh,
    accessExpiresAt: new Date(Date.now() + expiresIn * 1000),
  };
}

function parseIdentityStatus(value: unknown): IdentityStatus {
  if (value === "verified") return "verified";
  if (value === "needs_review") return "needs_review";
  if (value === "rejected") return "rejected";
  // Forward-compat ADR-005 D5 — unknown → needs_review.
  return "needs_review";
}

function parseIdentityResponse(body: Record<string, unknown>): IdentityStatusSnapshot {
  return {
    paUserId: null,
    user: parseIdentityStatus(body.user_identity_verification_status),
    company: parseIdentityStatus(body.company_verification_status),
  };
}

/** T-CL-SIREN-RECONCILIATION sprint-06 W1 — parse le schéma `company`
 *  (`GET /v1.beta/companies/me`). `number` + `number_scheme` → SIREN
 *  normalisé via `extractSiren`. Champs adresse agrégés (V1.1). */
function parseConnectedCompany(body: Record<string, unknown>): ConnectedCompany {
  const number = asString(body.number) ?? "";
  const numberScheme = asString(body.number_scheme) ?? "";
  const line = asString(body.address);
  const postcode = asString(body.postcode);
  const city = asString(body.city);
  const country = asString(body.country);
  const hasAddress = line !== null || postcode !== null || city !== null || country !== null;
  const address: ConnectedCompanyAddress | null = hasAddress
    ? { line, postcode, city, country }
    : null;
  return {
    siren: extractSiren(number, numberScheme),
    number,
    numberScheme,
    formalName: asString(body.formal_name) ?? "",
    tradeName: asString(body.trade_name),
    address,
  };
}

/** Dérive le SIREN (9 chiffres) depuis l'identifiant société SuperPDP.
 *  `company.number` peut être un SIRET (14 chiffres — SIREN = 9 premiers)
 *  ou un SIREN (9). Tout autre format → `null` (pas de réconciliation,
 *  fail-safe ADR-009). On ne se fie pas au libellé `numberScheme` (valeurs
 *  non garanties stables) : on raisonne sur la longueur des chiffres. */
function extractSiren(number: string, _numberScheme: string): string | null {
  const digits = number.replace(/\D/g, "");
  if (digits.length === 9) return digits;
  if (digits.length === 14) return digits.slice(0, 9);
  return null;
}

/** Société « propre » non exposée par `directory_entries` (le caller ne
 *  consomme que `address.party_id`) — placeholder pour satisfaire le type
 *  partagé `DirectorySearchResult`. */
const OWN_DIRECTORY_COMPANY: DirectoryCompany = {
  number: "",
  formal_name: "",
  address: "",
  postcode: "",
  city: "",
  country: "",
};

/** T-CL-PA-OWN-DIRECTORY-ENTRIES sprint-06 — parse `list_directory_entries`
 *  (`{ data: directory_entry[] }`). Ne garde que les entrées **enrôlées**
 *  (`status="created"`) et **non reply-to** (`is_replyto=false`). Mappe
 *  `identifier` (ex. `0225:853322915`) → `DirectoryAddress.party_id`. */
function parseOwnDirectoryEntries(body: Record<string, unknown>): DirectorySearchResult {
  const data = Array.isArray(body.data) ? (body.data as unknown[]) : [];
  const addresses: DirectoryAddress[] = [];
  for (const raw of data) {
    if (raw === null || typeof raw !== "object") continue;
    const entry = raw as Record<string, unknown>;
    const identifier = asString(entry.identifier);
    const status = asString(entry.status);
    if (identifier === null || status !== "created" || entry.is_replyto === true) continue;
    addresses.push({
      party_id: identifier,
      scheme_id: identifier.includes(":") ? (identifier.split(":")[0] ?? "") : "",
      is_active: true,
      pa_name: null,
    });
  }
  if (addresses.length === 0) return { kind: "not_found" };
  const only = addresses[0];
  if (addresses.length === 1 && only !== undefined) {
    return { kind: "found_one_address", company: OWN_DIRECTORY_COMPANY, address: only };
  }
  return { kind: "found_multi_address", company: OWN_DIRECTORY_COMPANY, addresses };
}

/** Parse `invoice` schema (SuperPDP) — `{id, events[], created_at}`.
 *  Extrait le statut initial depuis `events[0].status_code` (`api:uploaded`
 *  typiquement à T0). */
function parseInvoiceResponse(raw: Record<string, unknown>): SubmitInvoiceOutput | null {
  const idVal = raw.id;
  const paInvoiceId = typeof idVal === "number" ? String(idVal) : asString(idVal);
  const createdAtRaw = asString(raw.created_at);
  if (paInvoiceId === null || createdAtRaw === null) return null;

  // Premier event = statut initial (`api:uploaded` ou similaire).
  // Tolérant : si `events` absent ou vide, on retombe sur `'submitted'`.
  const events: unknown[] = Array.isArray(raw.events) ? (raw.events as unknown[]) : [];
  const firstEvent: unknown = events[0];
  let rawStatusCode = "api:uploaded";
  if (firstEvent !== undefined && typeof firstEvent === "object" && firstEvent !== null) {
    const sc = asString((firstEvent as Record<string, unknown>).status_code);
    if (sc !== null) rawStatusCode = sc;
  }
  const mapped = mapSuperPDPStatusCode(rawStatusCode);

  return {
    paInvoiceId,
    status: mapped.status,
    rawStatusCode,
    submittedAt: new Date(createdAtRaw),
  };
}

/** Parse `list_events` schema (`{data: [event], has_after}`) en array
 *  de `CdarEvent` mappés. Skip silencieux des events malformés (champ
 *  manquant) — le caller (job polling) reverra le batch au prochain
 *  tick si nécessaire. */
function parseEventsListResponse(raw: Record<string, unknown>): CdarEvent[] {
  const data = raw.data;
  if (!Array.isArray(data)) return [];
  const out: CdarEvent[] = [];
  for (const item of data) {
    if (item === null || typeof item !== "object") continue;
    const parsed = parseCdarEvent(item as Record<string, unknown>);
    if (parsed !== null) out.push(parsed);
  }
  return out;
}

/** Parse un `event` SuperPDP (`{id, invoice_id, status_code, status_text,
 *  created_at, data?}`) vers `CdarEvent`. Mapping `status_code` →
 *  `FacturEStatusCode` via `mapSuperPDPStatusCode`. */
function parseCdarEvent(raw: Record<string, unknown>): CdarEvent | null {
  const eventIdVal = raw.id;
  const paEventId = typeof eventIdVal === "number" ? String(eventIdVal) : asString(eventIdVal);
  const invoiceIdVal = raw.invoice_id;
  const paInvoiceId =
    typeof invoiceIdVal === "number" ? String(invoiceIdVal) : asString(invoiceIdVal);
  const rawStatusCode = asString(raw.status_code);
  const occurredAt = asString(raw.created_at);
  if (paEventId === null || paInvoiceId === null || rawStatusCode === null || occurredAt === null) {
    return null;
  }
  const mapped = mapSuperPDPStatusCode(rawStatusCode);
  const label = asString(raw.status_text) ?? undefined;

  // `data` event SuperPDP — payload optionnel (raison, détails). Stocké
  // tel quel en BDD pour audit.
  let payload: unknown = undefined;
  let reason: string | undefined = undefined;
  if (raw.data !== null && typeof raw.data === "object") {
    payload = raw.data;
    const reasonStr = asString((raw.data as Record<string, unknown>).reason);
    if (reasonStr !== null) reason = reasonStr;
  }

  return {
    paEventId,
    paInvoiceId,
    rawStatusCode,
    status: mapped.status,
    label,
    occurredAt,
    payload,
    reason,
  };
}

// ─────────────────────────────────────────────────────────────────────
// Réception — parsing (T-CL-RECV-API sprint-05 W2)
// ─────────────────────────────────────────────────────────────────────

/** Parse `{data: [invoice], has_after}` → `IncomingInvoice[]`. Skip
 *  silencieux des entrées malformées (re-vues au tick suivant). */
function parseIncomingInvoicesResponse(raw: Record<string, unknown>): IncomingInvoice[] {
  const data = raw.data;
  if (!Array.isArray(data)) return [];
  const out: IncomingInvoice[] = [];
  for (const item of data) {
    if (item === null || typeof item !== "object") continue;
    const parsed = parseIncomingInvoice(item as Record<string, unknown>);
    if (parsed !== null) out.push(parsed);
  }
  return out;
}

/** Parse une `invoice` SuperPDP (direction=in) → `IncomingInvoice`. Le
 *  `en_invoice` (expand) alimente les métadonnées EN 16931 (tolérant :
 *  champs optionnels). Retourne `null` si `id`/`created_at` absents. */
function parseIncomingInvoice(raw: Record<string, unknown>): IncomingInvoice | null {
  const idVal = raw.id;
  const paInvoiceId = typeof idVal === "number" ? String(idVal) : asString(idVal);
  const receivedAt = asString(raw.created_at);
  if (paInvoiceId === null || receivedAt === null) return null;

  const direction = asString(raw.direction) === "out" ? "out" : "in";

  let enInvoice: IncomingInvoiceEnData | undefined;
  if (raw.en_invoice !== null && typeof raw.en_invoice === "object") {
    enInvoice = parseEnInvoiceData(raw.en_invoice as Record<string, unknown>);
  }

  let rawStatusCode: string | undefined;
  if (Array.isArray(raw.events) && raw.events.length > 0) {
    const last: unknown = raw.events[raw.events.length - 1];
    if (last !== null && typeof last === "object") {
      const sc = asString((last as Record<string, unknown>).status_code);
      if (sc !== null) rawStatusCode = sc;
    }
  }

  return { paInvoiceId, direction, receivedAt, enInvoice, rawStatusCode };
}

/** Extrait les BT essentiels depuis `en_invoice` (expand). */
function parseEnInvoiceData(en: Record<string, unknown>): IncomingInvoiceEnData {
  const data: IncomingInvoiceEnData = {};
  const number = asString(en.number);
  if (number !== null) data.number = number;
  const issueDate = asString(en.issue_date);
  if (issueDate !== null) data.issueDate = issueDate;
  const dueDate = asString(en.payment_due_date);
  if (dueDate !== null) data.dueDate = dueDate;
  const currency = asString(en.currency_code);
  if (currency !== null) data.currency = currency;

  if (en.seller !== null && typeof en.seller === "object") {
    const seller = en.seller as Record<string, unknown>;
    const name = asString(seller.name);
    if (name !== null) data.sellerName = name;
    const siren = extractSellerSiren(seller);
    if (siren !== null) data.sellerSiren = siren;
  }

  if (en.totals !== null && typeof en.totals === "object") {
    const totals = en.totals as Record<string, unknown>;
    const cents = decimalToCents(asString(totals.total_with_vat));
    if (cents !== null) data.totalTtcCents = cents;
  }
  return data;
}

/** SIREN émetteur = `seller.legal_registration_identifier.value` (object
 *  `{scheme, value}`, BT-30). Fallback : 9 premiers digits du
 *  `vat_identifier` (BT-31). */
function extractSellerSiren(seller: Record<string, unknown>): string | null {
  const lri = seller.legal_registration_identifier;
  if (lri !== null && typeof lri === "object") {
    const value = asString((lri as Record<string, unknown>).value);
    if (value !== null) {
      const digits = value.replace(/\D/g, "");
      if (digits.length >= 9) return digits.slice(0, 9);
    }
  }
  const vat = asString(seller.vat_identifier);
  if (vat !== null) {
    const digits = vat.replace(/\D/g, "");
    if (digits.length >= 9) return digits.slice(0, 9);
  }
  return null;
}

/** Decimal string (`"123.45"`) → cents (`12345`). Null si non parsable. */
function decimalToCents(value: string | null): number | null {
  if (value === null) return null;
  const num = Number.parseFloat(value);
  if (!Number.isFinite(num)) return null;
  return Math.round(num * 100);
}

/** Parse la réponse `POST /invoice_events` (`event` `{id, status_code,
 *  created_at}`) → `CreateInvoiceEventOutput`. Tolérant : echo du
 *  `postedStatusCode` si l'event renvoyé est minimal. */
function parseCreateEventResponse(
  raw: Record<string, unknown>,
  postedStatusCode: string,
): CreateInvoiceEventOutput {
  const eventIdVal = raw.id;
  const paEventId = typeof eventIdVal === "number" ? String(eventIdVal) : asString(eventIdVal);
  const rawStatusCode = asString(raw.status_code) ?? postedStatusCode;
  const occurredAt = asString(raw.created_at) ?? new Date().toISOString();
  const mapped = mapSuperPDPStatusCode(rawStatusCode);
  return { paEventId, rawStatusCode, status: mapped.status, occurredAt };
}

async function readJsonSafe(res: Response): Promise<unknown> {
  try {
    return await res.json();
  } catch {
    return null;
  }
}
async function readTextSafe(res: Response): Promise<string | null> {
  try {
    return await res.text();
  } catch {
    return null;
  }
}

function asString(v: unknown): string | null {
  return typeof v === "string" && v.length > 0 ? v : null;
}

/**
 * Filtre défensif `_replyto` (T-CL-PA-DIRECTORY-PEPPOL sprint-05) — cf.
 * `SuperPDP/InfoGenerales/Annuaire.txt` section reply-to.
 *
 * Une entry dont le `party_id` se termine par `_replyto` est une adresse
 * technique de retour PA réception (≠ PA émission), non utilisable comme
 * destinataire facture émise vers un client. Filtrée systématiquement
 * côté `fetchOwnPeppolAddresses` pour ne jamais l'exposer comme adresse
 * customer self.
 */
function isReplyToIdentifier(partyId: string): boolean {
  return partyId.endsWith("_replyto");
}

function parseDirectoryCompany(raw: Record<string, unknown>): DirectoryCompany {
  return {
    number: asString(raw.number) ?? "",
    formal_name: asString(raw.formal_name) ?? "",
    address: asString(raw.address) ?? "",
    postcode: asString(raw.postcode) ?? "",
    city: asString(raw.city) ?? "",
    country: asString(raw.country) ?? "",
  };
}

function parseDirectoryEntry(raw: Record<string, unknown>): DirectoryAddress | null {
  const identifier = asString(raw.identifier);
  if (identifier === null) return null;
  const colonIdx = identifier.indexOf(":");
  if (colonIdx === -1) return null;
  const scheme = identifier.slice(0, colonIdx);
  const isActive = raw.is_active === true;
  return {
    party_id: identifier,
    scheme_id: scheme,
    is_active: isActive,
    pa_name: null,
  };
}

function parseRetryAfter(value: string | null): number | null {
  if (value === null || value === "") return null;
  const parsed = Number.parseInt(value, 10);
  if (!Number.isFinite(parsed) || parsed < 0) return null;
  return parsed;
}
