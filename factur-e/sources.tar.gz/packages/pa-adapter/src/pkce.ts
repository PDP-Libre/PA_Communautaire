import { createHash, randomBytes } from "node:crypto";

/**
 * PKCE S256 helpers — RFC 7636.
 *
 * `code_verifier` : 32 octets cryptographiques encodés en base64url
 * (sans padding `=`, `+→-`, `/→_`). Longueur résultat ≈ 43 chars,
 * dans la plage RFC 7636 [43, 128].
 *
 * `code_challenge` : SHA-256(`code_verifier`) base64url-encoded.
 *
 * Cf. ADR-005 D2 sprint-03 — PKCE S256 obligatoire côté pa-adapter
 * pour défense en profondeur OAuth 2.1.
 */

/** RFC 4648 §5 base64url — pas de padding, `+→-`, `/→_`. */
function toBase64Url(buf: Buffer): string {
  return buf.toString("base64").replace(/=+$/, "").replace(/\+/g, "-").replace(/\//g, "_");
}

/** Génère un `code_verifier` PKCE — 32 octets aléatoires base64url. */
export function generateCodeVerifier(): string {
  return toBase64Url(randomBytes(32));
}

/** Dérive le `code_challenge` S256 depuis un verifier. */
export function deriveS256Challenge(codeVerifier: string): string {
  return toBase64Url(createHash("sha256").update(codeVerifier).digest());
}

/** Génère un `state` CSRF — 16 octets aléatoires base64url. Plus court
 *  que le verifier (la longueur n'est pas normée par RFC, juste
 *  imprédictibilité requise). */
export function generateState(): string {
  return toBase64Url(randomBytes(16));
}
