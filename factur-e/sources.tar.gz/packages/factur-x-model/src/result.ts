// Type Result<T, E> minimal pour l'API de validation.
// Évite les exceptions pour porter une liste d'erreurs structurées.

export type Result<T, E> = { ok: true; value: T } | { ok: false; errors: E[] };

export function ok<T>(value: T): { ok: true; value: T } {
  return { ok: true, value };
}

export function err<E>(errors: E[]): { ok: false; errors: E[] } {
  return { ok: false, errors };
}
