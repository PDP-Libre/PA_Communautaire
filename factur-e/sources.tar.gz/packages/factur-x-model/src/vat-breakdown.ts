// BG-23 VATBreakdown — ventilation de la TVA.
// Référence : codebase-facturx-swift.md §3 + §5.6 + §9.4 #7.
//
// Ordre XSD strict (cf. §9.1) :
//   CalculatedAmount → TypeCode("VAT") → ExemptionReason → BasisAmount →
//   CategoryCode → ExemptionReasonCode → RateApplicablePercent.
// La sortie déterministe est de la responsabilité du sérialiseur (T-CL-02).
//
// BR-CO-18 : tableau non vide (au moins un breakdown).
// BR-S-/Z-/E-/AE-/K-/G-/O-/L-/M- : cohérence catégorie ↔ rate ↔ exemptionReason(Code) — voir validateInvoice.

import { z } from "zod";
import { CodeTypeSchema, TextTypeSchema } from "./base-types.js";

export const VATBreakdownSchema = z.object({
  taxBasisAmount: z.number().finite(), // BT-116
  calculatedAmount: z.number().finite(), // BT-117
  categoryCode: CodeTypeSchema, // BT-118 (S/Z/E/AE/K/G/O/L/M)
  ratePercent: z.number().finite().optional(), // BT-119
  exemptionReason: TextTypeSchema.optional(), // BT-120
  exemptionReasonCode: CodeTypeSchema.optional(), // BT-121
});
export type VATBreakdown = z.infer<typeof VATBreakdownSchema>;
