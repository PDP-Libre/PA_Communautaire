// SupplyChainTradeTransaction — transaction commerciale.
// Sous-blocs : HeaderTradeAgreement (BG-4/7/11/24), HeaderTradeDelivery (BG-13/15),
// HeaderTradeSettlement (BG-3/10/14/16/20/21/22/23 + payment terms).
// Référence : codebase-facturx-swift.md §3 + §5.5/§5.7/§5.8/§5.9 + §9.4 #1/#3/#4/#5/#20.
//
// Bug §9.4 #1 : `SellerOrderReferencedDocument` (BT-14) **avant** `BuyerOrderReferencedDocument` (BT-13)
//   — l'ordre des champs ici est documentaire ; l'ordre XML est imposé par T-CL-02.
// Bug §9.4 #4 : `TaxCurrencyCode` (BT-6) **avant** `InvoiceCurrencyCode` (BT-5) à la sérialisation.
// Bug §9.4 #5 : `InvoiceReferencedDocument` (BG-3) **après** `MonetarySummation` (BG-22).
// Bug §9.4 #20 : `creditorReferenceID` (BT-90) au niveau HeaderTradeSettlement (absent du modèle Swift).

import { z } from "zod";
import { CodeTypeSchema, DateTypeSchema, IdentifierSchema, TextTypeSchema } from "./base-types.js";
import { BillingPeriodSchema } from "./billing-period.js";
import { DocumentAllowanceChargeSchema } from "./allowance-charge.js";
import { MonetarySummationSchema } from "./monetary-summation.js";
import { PaymentMeansSchema } from "./payment.js";
import {
  AdditionalReferenceDocumentSchema,
  PrecedingInvoiceReferenceSchema,
} from "./reference-document.js";
import { SupplyChainTradeLineItemSchema } from "./invoice-line-item.js";
import {
  PostalAddressSchema,
  SellerTaxRepresentativePartySchema,
  TradePartySchema,
} from "./trade-party.js";
import { VATBreakdownSchema } from "./vat-breakdown.js";

// BG-4 + BG-7 + BG-11 + BG-24 (header).
export const HeaderTradeAgreementSchema = z.object({
  sellerTradeParty: TradePartySchema, // BG-4
  buyerTradeParty: TradePartySchema, // BG-7
  sellerTaxRepresentative: SellerTaxRepresentativePartySchema.optional(), // BG-11
  buyerReference: TextTypeSchema.optional(), // BT-10
  buyerOrderReference: z.string().min(1).optional(), // BT-13
  contractReference: z.string().min(1).optional(), // BT-12
  // BT-14 — élément XML cible : <ram:SellerOrderReferencedDocument> (cf. Bug §9.4 #1
  // du doc Swift). Le modèle TS utilise le même nom que l'XML pour cohérence.
  sellerOrderReference: z.string().min(1).optional(), // BT-14
  additionalReferencedDocuments: z.array(AdditionalReferenceDocumentSchema).optional(), // BG-24
  /** BT-X-22 INCOTERM (ApplicableTradeDeliveryTerms/DeliveryTypeCode) —
   *  EXTENDED-CTC-FR BR-FREXT-CL-27, whitelist 13 codes FR. */
  incoterm: z.string().min(1).optional(),
});
export type HeaderTradeAgreement = z.infer<typeof HeaderTradeAgreementSchema>;

// BG-13 + BG-15.
export const HeaderTradeDeliverySchema = z.object({
  // BG-15 — adresse de livraison (élément ShipToTradeParty/PostalAddress).
  deliveryAddress: PostalAddressSchema.optional(),
  actualDeliveryDate: DateTypeSchema.optional(), // BT-72
  shipToPartyName: TextTypeSchema.optional(), // BT-70 — BR-57 si BG-13 émis
  shipToPartyID: IdentifierSchema.optional(), // BT-71
  despatchAdviceReference: z.string().min(1).optional(), // BT-16
  receivingAdviceReference: z.string().min(1).optional(), // BT-15
});
export type HeaderTradeDelivery = z.infer<typeof HeaderTradeDeliverySchema>;

// BG-3 + BG-10 + BG-14 + BG-16 + BG-20/21 + BG-22 + BG-23 + paymentTerms.
export const HeaderTradeSettlementSchema = z.object({
  invoiceCurrencyCode: CodeTypeSchema, // BT-5 (ISO 4217)
  vatAccountingCurrencyCode: CodeTypeSchema.optional(), // BT-6
  // BT-90 — Bug §9.4 #20 : émis tôt dans HeaderTradeSettlement à la sérialisation.
  creditorReferenceID: IdentifierSchema.optional(),
  paymentReference: TextTypeSchema.optional(), // BT-83
  vatBreakdowns: z
    .array(VATBreakdownSchema)
    .min(1, "BR-CO-18 — BG-23 must contain at least one VATBreakdown"), // BG-23
  monetarySummation: MonetarySummationSchema, // BG-22
  paymentTermsDescription: TextTypeSchema.optional(), // BT-20
  dueDate: DateTypeSchema.optional(), // BT-9
  precedingInvoices: z.array(PrecedingInvoiceReferenceSchema).optional(), // BG-3
  paymentMeans: z.array(PaymentMeansSchema).optional(), // BG-16
  payeeParty: TradePartySchema.optional(), // BG-10
  documentAllowances: z.array(DocumentAllowanceChargeSchema).optional(), // BG-20
  documentCharges: z.array(DocumentAllowanceChargeSchema).optional(), // BG-21
  billingPeriod: BillingPeriodSchema.optional(), // BG-14
});
export type HeaderTradeSettlement = z.infer<typeof HeaderTradeSettlementSchema>;

// rsm:SupplyChainTradeTransaction — racine de la transaction.
export const SupplyChainTradeTransactionSchema = z.object({
  // BR-16 — au moins une ligne ; reflété par `.min(1)`.
  lineItems: z
    .array(SupplyChainTradeLineItemSchema)
    .min(1, "BR-16 — transaction must contain at least one line item"), // BG-25
  tradeAgreement: HeaderTradeAgreementSchema,
  tradeDelivery: HeaderTradeDeliverySchema,
  tradeSettlement: HeaderTradeSettlementSchema,
});
export type SupplyChainTradeTransaction = z.infer<typeof SupplyChainTradeTransactionSchema>;
