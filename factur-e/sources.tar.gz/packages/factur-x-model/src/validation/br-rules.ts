// validateInvoice — règles BR-* EN 16931 / Factur-X.
// Référence : codebase-facturx-swift.md §6 + §9.4 (Risques Schematron) + ADR-003.
//
// Couverture cible (cf. ADR-003 §"Validation BR-* — niveau de couverture") :
//   BR-1, BR-2, BR-6, BR-7, BR-9, BR-11, BR-16, BR-21, BR-22, BR-25  (déjà Swift)
//   BR-CO-9, BR-CO-15, BR-CO-18, BR-CO-20, BR-CO-25                  (T-CL-01)
//   BR-DEC-13/14 (currencyID requis sur les Amount totalisateurs)
//   BR-42 / BR-43 (allowance/charge — Reason ou ReasonCode)
//   BR-51 (PaymentCard — 4 à 6 derniers chiffres)
//   BR-55 (avoir → BG-3 obligatoire)
//   BR-57 (BG-13 → ShipToTradeParty.Name obligatoire)
//   BR-S-/Z-/E-/AE-/K-/G-/O- (cohérence catégorie TVA)
//
// Ajouts T-CL-03 (cf. audit-migration §4.2) :
//   BR-CO-10  : allowanceTotalAmount = Σ documentAllowances.actualAmount.
//   BR-CO-11  : chargeTotalAmount    = Σ documentCharges.actualAmount.
//   BR-CO-13  : lineTotalAmount      = Σ lineItems.tradeSettlement.netLineAmount.
//   BR-CO-16  : duePayableAmount = grandTotalAmount − paidAmount (− roundingAmount).
//   BR-CO-17  : par catégorie, BT-117 = round(BT-116 × BT-119 / 100, 2).
//   BR-CO-26  : si vendeur sans BT-31 (vatID), au moins BT-30 (legalRegistrationID)
//               ou BT-32 (taxRegistrationLocalID) requis.
//   BR-AE-03  : autoliquidation (AE) — vendeur OU acheteur doit avoir vatID.
//   BR-E-03   : exonération (E)     — vendeur doit avoir vatID OR taxRegistrationLocalID.
//   BR-G-03   : export (G)          — vendeur doit avoir vatID OR taxRegistrationLocalID.
//   BR-IC-03  : intracom (K)        — vendeur ET acheteur doivent avoir vatID.
//   BR-DEC-01 : actualAmount BG-20 (BT-92) — max 2 décimales.
//   BR-DEC-02 : basisAmount   BG-20 (BT-93) — max 2 décimales.
//   BR-DEC-05 : actualAmount BG-21 (BT-99) — max 2 décimales.
//   BR-DEC-06 : basisAmount   BG-21 (BT-100) — max 2 décimales.

import { CREDIT_NOTE_CODES, FACTUR_X_PROFILES } from "../codes.js";
import type { CrossIndustryInvoice } from "../invoice.js";
import type { DocumentAllowanceCharge, LineAllowanceCharge } from "../allowance-charge.js";
import type { VATBreakdown } from "../vat-breakdown.js";
import { type Result, err, ok } from "../result.js";

export interface BRError {
  /** Code de la règle BR-* violée (ex: "BR-1", "BR-CO-9", "BR-S-1"). */
  code: string;
  /** Chemin BG-X.BT-Y dans le document (ex: "tradeTransaction.lineItems[0].lineID"). */
  path: string;
  /** Message en français à destination de l'utilisateur. */
  message: string;
}

const ACCEPTED_PROFILE_VALUES: readonly string[] = Object.values(FACTUR_X_PROFILES);

const VAT_CARD_PAN_REGEX = /^\d{4,6}$/;

// Catégories TVA exigeant un taux non nul (S = standard).
const RATE_REQUIRED_CATEGORIES = new Set(["S"]);
// Catégories TVA exigeant un taux à 0 (Z = zero rated).
const RATE_ZERO_CATEGORIES = new Set(["Z"]);
// Catégories TVA exigeant exemptionReason ou exemptionReasonCode.
//
// Note sur L (Canaries / IGIC) et M (Ceuta-Melilla / IPSI) : ces deux catégories
// codent des taxes territoriales spécifiques (impôt général indirect canarien et
// impôt sur la production / services / importation), pas des exonérations de TVA
// au sens strict. Schematron officiel BR-AF-* (L) et BR-AG-* (M) traite ces
// taxes avec leurs propres règles de cohérence, sans imposer un motif
// d'exonération. Elles ne sont donc PAS dans ce Set — sciemment.
const EXEMPTION_REQUIRED_CATEGORIES = new Set(["E", "AE", "K", "G", "O"]);

function pushError(errors: BRError[], code: string, path: string, message: string): void {
  errors.push({ code, path, message });
}

function validateAllowanceCharge(
  ac: DocumentAllowanceCharge | LineAllowanceCharge,
  basePath: string,
  errors: BRError[],
): void {
  // BR-42 / BR-43 — Reason OR ReasonCode obligatoire.
  if (
    (ac.reason === undefined || ac.reason === "") &&
    (ac.reasonCode === undefined || ac.reasonCode === "")
  ) {
    pushError(
      errors,
      ac.isCharge ? "BR-43" : "BR-42",
      `${basePath}.reason|reasonCode`,
      `${ac.isCharge ? "Charge" : "Remise"} — un motif (texte ou code) est obligatoire.`,
    );
  }
}

function validateVatBreakdown(v: VATBreakdown, index: number, errors: BRError[]): void {
  const path = `tradeTransaction.tradeSettlement.vatBreakdowns[${String(index)}]`;
  // BR-S-* / BR-Z-* — taux requis pour S, taux nul pour Z.
  if (RATE_REQUIRED_CATEGORIES.has(v.categoryCode)) {
    if (v.ratePercent === undefined || v.ratePercent <= 0) {
      pushError(
        errors,
        `BR-${v.categoryCode}-1`,
        `${path}.ratePercent`,
        `Catégorie TVA "${v.categoryCode}" — un taux > 0 est obligatoire (BT-119).`,
      );
    }
  } else if (RATE_ZERO_CATEGORIES.has(v.categoryCode)) {
    if (v.ratePercent !== undefined && v.ratePercent !== 0) {
      pushError(
        errors,
        `BR-${v.categoryCode}-1`,
        `${path}.ratePercent`,
        `Catégorie TVA "${v.categoryCode}" — le taux doit être 0.`,
      );
    }
  }
  // BR-E/AE/K/G/O — exemption reason ou reasonCode requis.
  if (EXEMPTION_REQUIRED_CATEGORIES.has(v.categoryCode)) {
    if (
      (v.exemptionReason === undefined || v.exemptionReason === "") &&
      (v.exemptionReasonCode === undefined || v.exemptionReasonCode === "")
    ) {
      pushError(
        errors,
        `BR-${v.categoryCode}-1`,
        `${path}.exemptionReason|exemptionReasonCode`,
        `Catégorie TVA "${v.categoryCode}" — un motif d'exonération (BT-120) ou son code (BT-121) est obligatoire.`,
      );
    }
  }
}

/**
 * Valide une facture EN 16931 / Factur-X par rapport aux règles BR-* couvertes.
 *
 * Retourne `Result.ok(invoice)` si toutes les règles passent, sinon
 * `Result.err(errors)` avec une liste exhaustive (pas de fail-fast — toutes
 * les violations sont collectées pour une UI utilisateur).
 *
 * NB : les contraintes structurelles (cardinalités, types, formats) sont
 * vérifiées en amont par les schemas Zod. Ne sont vérifiées ici que les
 * règles métier qui dépassent le typage.
 */
export function validateInvoice(
  invoice: CrossIndustryInvoice,
): Result<CrossIndustryInvoice, BRError> {
  const errors: BRError[] = [];

  // BR-1 — profil figé (BT-24).
  if (!ACCEPTED_PROFILE_VALUES.includes(invoice.documentContext.specificationID.value)) {
    pushError(
      errors,
      "BR-1",
      "documentContext.specificationID.value",
      `Profil Factur-X non reconnu : "${invoice.documentContext.specificationID.value}".`,
    );
  }

  // BR-2 — invoiceNumber non vide.
  if (invoice.exchangedDocument.invoiceNumber.trim() === "") {
    pushError(
      errors,
      "BR-2",
      "exchangedDocument.invoiceNumber",
      "Le numéro de facture (BT-1) est obligatoire.",
    );
  }

  const ta = invoice.tradeTransaction.tradeAgreement;
  const td = invoice.tradeTransaction.tradeDelivery;
  const ts = invoice.tradeTransaction.tradeSettlement;

  // BR-6 — vendeur.name.
  if (ta.sellerTradeParty.name.trim() === "") {
    pushError(
      errors,
      "BR-6",
      "tradeTransaction.tradeAgreement.sellerTradeParty.name",
      "Le nom du vendeur (BT-27) est obligatoire.",
    );
  }
  // BR-7 — acheteur.name.
  if (ta.buyerTradeParty.name.trim() === "") {
    pushError(
      errors,
      "BR-7",
      "tradeTransaction.tradeAgreement.buyerTradeParty.name",
      "Le nom de l'acheteur (BT-44) est obligatoire.",
    );
  }
  // BR-9 — vendeur.countryCode.
  if (ta.sellerTradeParty.postalAddress.countryCode.trim() === "") {
    pushError(
      errors,
      "BR-9",
      "tradeTransaction.tradeAgreement.sellerTradeParty.postalAddress.countryCode",
      "Le code pays du vendeur (BT-40) est obligatoire.",
    );
  }
  // BR-11 — acheteur.countryCode.
  if (ta.buyerTradeParty.postalAddress.countryCode.trim() === "") {
    pushError(
      errors,
      "BR-11",
      "tradeTransaction.tradeAgreement.buyerTradeParty.postalAddress.countryCode",
      "Le code pays de l'acheteur (BT-55) est obligatoire.",
    );
  }

  // BR-CO-9 — vatID schemeID="VA" si présent.
  for (const [partyKey, party] of [
    ["sellerTradeParty", ta.sellerTradeParty],
    ["buyerTradeParty", ta.buyerTradeParty],
  ] as const) {
    if (party.vatID !== undefined && party.vatID.schemeID !== "VA") {
      pushError(
        errors,
        "BR-CO-9",
        `tradeTransaction.tradeAgreement.${partyKey}.vatID.schemeID`,
        `Le schemeID de l'identifiant TVA doit être "VA".`,
      );
    }
  }
  if (
    ta.sellerTaxRepresentative !== undefined &&
    ta.sellerTaxRepresentative.vatID.schemeID !== "VA"
  ) {
    pushError(
      errors,
      "BR-CO-9",
      "tradeTransaction.tradeAgreement.sellerTaxRepresentative.vatID.schemeID",
      `Le schemeID de l'identifiant TVA du représentant fiscal doit être "VA".`,
    );
  }

  // BR-16 — au moins une ligne (déjà refusé par le schema Zod, double-check pour sécurité).
  if (invoice.tradeTransaction.lineItems.length === 0) {
    pushError(
      errors,
      "BR-16",
      "tradeTransaction.lineItems",
      "Au moins une ligne de facture (BG-25) est obligatoire.",
    );
  }

  // BR-21, BR-22, BR-25 — par ligne.
  invoice.tradeTransaction.lineItems.forEach((line, idx) => {
    const linePath = `tradeTransaction.lineItems[${String(idx)}]`;
    if (line.lineID.trim() === "") {
      pushError(
        errors,
        "BR-21",
        `${linePath}.lineID`,
        `Ligne ${String(idx + 1)} — l'identifiant de ligne (BT-126) est obligatoire.`,
      );
    }
    if (line.product.name.trim() === "") {
      pushError(
        errors,
        "BR-25",
        `${linePath}.product.name`,
        `Ligne ${String(idx + 1)} — le nom de l'article (BT-153) est obligatoire.`,
      );
    }
    if (line.tradeDelivery.billedQuantity <= 0) {
      pushError(
        errors,
        "BR-22",
        `${linePath}.tradeDelivery.billedQuantity`,
        `Ligne ${String(idx + 1)} — la quantité facturée (BT-129) doit être > 0.`,
      );
    }
    // BR-S/Z/E/AE/K/G/O sur la TVA de ligne (cohérence catégorie/taux).
    const cat = line.tradeSettlement.vatInformation.categoryCode;
    const rate = line.tradeSettlement.vatInformation.ratePercent;
    if (RATE_REQUIRED_CATEGORIES.has(cat) && (rate === undefined || rate <= 0)) {
      pushError(
        errors,
        `BR-${cat}-1`,
        `${linePath}.tradeSettlement.vatInformation.ratePercent`,
        `Ligne ${String(idx + 1)} — TVA "${cat}" : un taux > 0 est obligatoire (BT-152).`,
      );
    }
    if (RATE_ZERO_CATEGORIES.has(cat) && rate !== undefined && rate !== 0) {
      pushError(
        errors,
        `BR-${cat}-1`,
        `${linePath}.tradeSettlement.vatInformation.ratePercent`,
        `Ligne ${String(idx + 1)} — TVA "${cat}" : le taux doit être 0.`,
      );
    }
    // BR-42/43 sur les allowances/charges de ligne.
    line.tradeSettlement.lineAllowances?.forEach((ac, i) => {
      validateAllowanceCharge(
        ac,
        `${linePath}.tradeSettlement.lineAllowances[${String(i)}]`,
        errors,
      );
    });
    line.tradeSettlement.lineCharges?.forEach((ac, i) => {
      validateAllowanceCharge(ac, `${linePath}.tradeSettlement.lineCharges[${String(i)}]`, errors);
    });
    // BR-CO-20 (ligne) — BG-26 sans aucune date est invalide.
    const lp = line.tradeSettlement.lineBillingPeriod;
    if (lp !== undefined && lp.startDate === undefined && lp.endDate === undefined) {
      pushError(
        errors,
        "BR-CO-20",
        `${linePath}.tradeSettlement.lineBillingPeriod`,
        `Ligne ${String(idx + 1)} — une période de facturation doit avoir au moins une date (BT-134/BT-135).`,
      );
    }
  });

  // BR-CO-18 — au moins un VAT breakdown (renforcement schema).
  if (ts.vatBreakdowns.length === 0) {
    pushError(
      errors,
      "BR-CO-18",
      "tradeTransaction.tradeSettlement.vatBreakdowns",
      "Au moins une ventilation de TVA (BG-23) est obligatoire.",
    );
  } else {
    ts.vatBreakdowns.forEach((v, i) => {
      validateVatBreakdown(v, i, errors);
    });
  }

  // BR-CO-15 — grandTotalAmount = taxBasisTotalAmount + Σ vatTotalAmount + roundingAmount.
  // BT-112 = BT-109 + Σ BT-117 + BT-114 (cf. EN 16931 §5.1).
  // Tolérance 0.005 € (demi-centime).
  const sumVat = ts.vatBreakdowns.reduce((acc, v) => acc + v.calculatedAmount, 0);
  const expectedGrand =
    ts.monetarySummation.taxBasisTotalAmount + sumVat + (ts.monetarySummation.roundingAmount ?? 0);
  if (Math.abs(expectedGrand - ts.monetarySummation.grandTotalAmount) > 0.005) {
    pushError(
      errors,
      "BR-CO-15",
      "tradeTransaction.tradeSettlement.monetarySummation.grandTotalAmount",
      `Le montant TTC (BT-112=${ts.monetarySummation.grandTotalAmount.toFixed(2)}) doit égaler la base HT (BT-109=${ts.monetarySummation.taxBasisTotalAmount.toFixed(2)}) + Σ TVA (${sumVat.toFixed(2)}).`,
    );
  }

  // BR-CO-25 — duePayableAmount > 0 → dueDate OR paymentTermsDescription.
  if (
    ts.monetarySummation.duePayableAmount > 0 &&
    ts.dueDate === undefined &&
    (ts.paymentTermsDescription === undefined || ts.paymentTermsDescription === "")
  ) {
    pushError(
      errors,
      "BR-CO-25",
      "tradeTransaction.tradeSettlement.dueDate|paymentTermsDescription",
      "Si un montant à payer est dû, la date d'échéance (BT-9) ou les conditions de paiement (BT-20) sont obligatoires.",
    );
  }

  // BR-CO-20 — header BillingPeriod.
  if (
    ts.billingPeriod !== undefined &&
    ts.billingPeriod.startDate === undefined &&
    ts.billingPeriod.endDate === undefined
  ) {
    pushError(
      errors,
      "BR-CO-20",
      "tradeTransaction.tradeSettlement.billingPeriod",
      "La période de facturation (BG-14) doit comporter au moins une date (BT-73 ou BT-74).",
    );
  }

  // BR-DEC-13 — vatTotalAmount.currencyID requis si présent.
  if (
    ts.monetarySummation.vatTotalAmount !== undefined &&
    ts.monetarySummation.vatTotalAmount.currencyID === undefined
  ) {
    pushError(
      errors,
      "BR-DEC-13",
      "tradeTransaction.tradeSettlement.monetarySummation.vatTotalAmount.currencyID",
      "Le montant total de TVA (BT-110) doit porter un currencyID.",
    );
  }
  // BR-DEC-14 — taxCurrencyVATTotalAmount.currencyID requis si présent.
  if (
    ts.monetarySummation.taxCurrencyVATTotalAmount !== undefined &&
    ts.monetarySummation.taxCurrencyVATTotalAmount.currencyID === undefined
  ) {
    pushError(
      errors,
      "BR-DEC-14",
      "tradeTransaction.tradeSettlement.monetarySummation.taxCurrencyVATTotalAmount.currencyID",
      "Le montant total de TVA en devise de comptabilisation (BT-111) doit porter un currencyID.",
    );
  }

  // BR-42 / BR-43 sur allowances/charges au niveau document.
  ts.documentAllowances?.forEach((ac, i) => {
    validateAllowanceCharge(
      ac,
      `tradeTransaction.tradeSettlement.documentAllowances[${String(i)}]`,
      errors,
    );
  });
  ts.documentCharges?.forEach((ac, i) => {
    validateAllowanceCharge(
      ac,
      `tradeTransaction.tradeSettlement.documentCharges[${String(i)}]`,
      errors,
    );
  });

  // BR-51 — PaymentCard.primaryAccountNumber : 4 à 6 derniers chiffres.
  ts.paymentMeans?.forEach((pm, i) => {
    if (pm.paymentCard !== undefined) {
      if (!VAT_CARD_PAN_REGEX.test(pm.paymentCard.primaryAccountNumber)) {
        pushError(
          errors,
          "BR-51",
          `tradeTransaction.tradeSettlement.paymentMeans[${String(i)}].paymentCard.primaryAccountNumber`,
          "Le numéro de carte (BT-87) doit comporter uniquement les 4 à 6 derniers chiffres.",
        );
      }
    }
  });

  // BR-55 — avoir → BG-3 obligatoire.
  if (
    (CREDIT_NOTE_CODES as readonly string[]).includes(invoice.exchangedDocument.invoiceTypeCode) &&
    (ts.precedingInvoices === undefined || ts.precedingInvoices.length === 0)
  ) {
    pushError(
      errors,
      "BR-55",
      "tradeTransaction.tradeSettlement.precedingInvoices",
      "Pour un avoir (BT-3 = 381 ou 261), au moins une référence à la facture antérieure (BG-3) est obligatoire.",
    );
  }

  // BR-57 — Si une adresse de livraison (BG-15 = `deliveryAddress`) est
  // fournie, le nom du destinataire (BT-70 = `shipToPartyName`) est obligatoire.
  // Strictement BG-15 et non BG-13 entier : émettre BT-72 (date) ou un
  // identifiant de bordereau seul ne déclenche pas BR-57 — seule l'adresse
  // physique de livraison impose un destinataire nommé.
  if (
    td.deliveryAddress !== undefined &&
    (td.shipToPartyName === undefined || td.shipToPartyName === "")
  ) {
    pushError(
      errors,
      "BR-57",
      "tradeTransaction.tradeDelivery.shipToPartyName",
      "Si une adresse de livraison (BG-15) est fournie, le nom du destinataire (BT-70) est obligatoire.",
    );
  }

  // BR-CO-10 — allowanceTotalAmount = Σ documentAllowances.actualAmount.
  if (ts.documentAllowances !== undefined && ts.documentAllowances.length > 0) {
    const sumAllow = ts.documentAllowances.reduce((acc, ac) => acc + ac.actualAmount, 0);
    const declared = ts.monetarySummation.allowanceTotalAmount ?? 0;
    if (Math.abs(sumAllow - declared) > 0.005) {
      pushError(
        errors,
        "BR-CO-10",
        "tradeTransaction.tradeSettlement.monetarySummation.allowanceTotalAmount",
        `Somme des remises documents (${sumAllow.toFixed(2)}) ≠ allowanceTotalAmount (${declared.toFixed(2)}).`,
      );
    }
  }

  // BR-CO-11 — chargeTotalAmount = Σ documentCharges.actualAmount.
  if (ts.documentCharges !== undefined && ts.documentCharges.length > 0) {
    const sumCharge = ts.documentCharges.reduce((acc, ac) => acc + ac.actualAmount, 0);
    const declared = ts.monetarySummation.chargeTotalAmount ?? 0;
    if (Math.abs(sumCharge - declared) > 0.005) {
      pushError(
        errors,
        "BR-CO-11",
        "tradeTransaction.tradeSettlement.monetarySummation.chargeTotalAmount",
        `Somme des charges documents (${sumCharge.toFixed(2)}) ≠ chargeTotalAmount (${declared.toFixed(2)}).`,
      );
    }
  }

  // BR-CO-13 — lineTotalAmount = Σ lineItems.tradeSettlement.netLineAmount.
  const sumLines = invoice.tradeTransaction.lineItems.reduce(
    (acc, line) => acc + line.tradeSettlement.netLineAmount,
    0,
  );
  if (Math.abs(sumLines - ts.monetarySummation.lineTotalAmount) > 0.005) {
    pushError(
      errors,
      "BR-CO-13",
      "tradeTransaction.tradeSettlement.monetarySummation.lineTotalAmount",
      `Somme des montants nets des lignes (${sumLines.toFixed(2)}) ≠ lineTotalAmount (${ts.monetarySummation.lineTotalAmount.toFixed(2)}).`,
    );
  }

  // BR-CO-16 — duePayableAmount = grandTotalAmount − paidAmount (− roundingAmount).
  const expectedDue =
    ts.monetarySummation.grandTotalAmount -
    (ts.monetarySummation.paidAmount ?? 0) -
    (ts.monetarySummation.roundingAmount ?? 0);
  if (Math.abs(expectedDue - ts.monetarySummation.duePayableAmount) > 0.005) {
    pushError(
      errors,
      "BR-CO-16",
      "tradeTransaction.tradeSettlement.monetarySummation.duePayableAmount",
      `duePayableAmount (${ts.monetarySummation.duePayableAmount.toFixed(2)}) ≠ grandTotalAmount − paidAmount − roundingAmount (${expectedDue.toFixed(2)}).`,
    );
  }

  // BR-CO-17 — par catégorie TVA : calculatedAmount ≈ basis × ratePercent / 100.
  ts.vatBreakdowns.forEach((v, i) => {
    if (v.ratePercent === undefined) return;
    const expectedTax = (v.taxBasisAmount * v.ratePercent) / 100;
    if (Math.abs(expectedTax - v.calculatedAmount) > 0.005) {
      pushError(
        errors,
        "BR-CO-17",
        `tradeTransaction.tradeSettlement.vatBreakdowns[${String(i)}].calculatedAmount`,
        `Catégorie "${v.categoryCode}" : TVA calculée (${v.calculatedAmount.toFixed(2)}) ≠ base × taux / 100 (${expectedTax.toFixed(2)}).`,
      );
    }
  });

  // BR-CO-26 — si vendeur sans vatID (BT-31), au moins legalRegistrationID (BT-30)
  // ou taxRegistrationLocalID (BT-32) requis (le client doit pouvoir identifier le vendeur).
  const seller = ta.sellerTradeParty;
  if (
    seller.vatID === undefined &&
    seller.legalRegistrationID === undefined &&
    seller.taxRegistrationLocalID === undefined
  ) {
    pushError(
      errors,
      "BR-CO-26",
      "tradeTransaction.tradeAgreement.sellerTradeParty",
      "Le vendeur doit avoir au moins un identifiant : BT-31 (vatID) OU BT-30 (legalRegistrationID) OU BT-32 (taxRegistrationLocalID).",
    );
  }

  // BR-AE-03 — Autoliquidation : vendeur OU acheteur doit avoir vatID.
  const hasAEBreakdown = ts.vatBreakdowns.some((v) => v.categoryCode === "AE");
  if (hasAEBreakdown && seller.vatID === undefined && ta.buyerTradeParty.vatID === undefined) {
    pushError(
      errors,
      "BR-AE-03",
      "tradeTransaction.tradeAgreement",
      "Autoliquidation (AE) : le vendeur OU l'acheteur doit avoir un identifiant TVA (BT-31 ou BT-48).",
    );
  }

  // BR-E-03 — Exonération : vendeur doit avoir vatID OR taxRegistrationLocalID.
  const hasEBreakdown = ts.vatBreakdowns.some((v) => v.categoryCode === "E");
  if (hasEBreakdown && seller.vatID === undefined && seller.taxRegistrationLocalID === undefined) {
    pushError(
      errors,
      "BR-E-03",
      "tradeTransaction.tradeAgreement.sellerTradeParty",
      "Exonération (E) : le vendeur doit avoir BT-31 (vatID) OU BT-32 (taxRegistrationLocalID).",
    );
  }

  // BR-G-03 — Export : vendeur doit avoir vatID OR taxRegistrationLocalID.
  const hasGBreakdown = ts.vatBreakdowns.some((v) => v.categoryCode === "G");
  if (hasGBreakdown && seller.vatID === undefined && seller.taxRegistrationLocalID === undefined) {
    pushError(
      errors,
      "BR-G-03",
      "tradeTransaction.tradeAgreement.sellerTradeParty",
      "Export (G) : le vendeur doit avoir BT-31 (vatID) OU BT-32 (taxRegistrationLocalID).",
    );
  }

  // BR-IC-03 — Intracommunautaire (K) : vendeur ET acheteur doivent avoir vatID.
  const hasKBreakdown = ts.vatBreakdowns.some((v) => v.categoryCode === "K");
  if (hasKBreakdown) {
    if (seller.vatID === undefined) {
      pushError(
        errors,
        "BR-IC-03",
        "tradeTransaction.tradeAgreement.sellerTradeParty.vatID",
        "Intracommunautaire (K) : le vendeur doit avoir un identifiant TVA (BT-31).",
      );
    }
    if (ta.buyerTradeParty.vatID === undefined) {
      pushError(
        errors,
        "BR-IC-03",
        "tradeTransaction.tradeAgreement.buyerTradeParty.vatID",
        "Intracommunautaire (K) : l'acheteur doit avoir un identifiant TVA (BT-48).",
      );
    }
  }

  // BR-DEC-01 / -02 / -05 / -06 — max 2 décimales sur amounts allowance/charge.
  const checkMax2Decimals = (code: string, path: string, value: number, label: string): void => {
    const rounded = Math.round(value * 100) / 100;
    if (Math.abs(rounded - value) > 1e-9) {
      pushError(errors, code, path, `${label} (${String(value)}) doit avoir au plus 2 décimales.`);
    }
  };
  ts.documentAllowances?.forEach((ac, i) => {
    const base = `tradeTransaction.tradeSettlement.documentAllowances[${String(i)}]`;
    checkMax2Decimals("BR-DEC-01", `${base}.actualAmount`, ac.actualAmount, "BT-92");
    if (ac.basisAmount !== undefined) {
      checkMax2Decimals("BR-DEC-02", `${base}.basisAmount`, ac.basisAmount, "BT-93");
    }
  });
  ts.documentCharges?.forEach((ac, i) => {
    const base = `tradeTransaction.tradeSettlement.documentCharges[${String(i)}]`;
    checkMax2Decimals("BR-DEC-05", `${base}.actualAmount`, ac.actualAmount, "BT-99");
    if (ac.basisAmount !== undefined) {
      checkMax2Decimals("BR-DEC-06", `${base}.basisAmount`, ac.basisAmount, "BT-100");
    }
  });

  return errors.length === 0 ? ok(invoice) : err(errors);
}
