// BG-25 SupplyChainTradeLineItem et ses sous-groupes :
//   BG-29 LineTradeAgreement, BG-30 LineVATInformation, BG-31 TradeProduct,
//   BG-32 ItemAttribute, BG-26 LineBillingPeriod, BG-27/28 LineAllowanceCharge.
// Référence : codebase-facturx-swift.md §3 + §5.12-§5.16 + §9.4 #12/#13/#18.
//
// Bug §9.4 #13 (TradeProduct) : ordre XSD GlobalID → SellerAssignedID → BuyerAssignedID → Name → …
// Bug §9.4 #12 (AppliedTradeAllowanceCharge) : `<ram:ChargeIndicator>` obligatoire avant ActualAmount.
// Bug §9.4 #18 (BT-128) : `invoicedObjectID` émis comme AdditionalReferencedDocument typeCode="130"
//   au niveau LineTradeSettlement.
// La gestion XML est de la responsabilité du sérialiseur (T-CL-02) ; le modèle TS
// porte les bons champs ici.

import { z } from "zod";
import { CodeTypeSchema, IdentifierSchema, TextTypeSchema } from "./base-types.js";
import { LineAllowanceChargeSchema } from "./allowance-charge.js";
import { LineBillingPeriodSchema } from "./billing-period.js";
import { AdditionalReferenceDocumentSchema } from "./reference-document.js";

// BG-32 — attribut d'article (clé/valeur).
export const ItemAttributeSchema = z.object({
  attributeName: TextTypeSchema.min(1), // BT-160
  attributeValue: TextTypeSchema.min(1), // BT-161
});
export type ItemAttribute = z.infer<typeof ItemAttributeSchema>;

// BG-31 — informations sur l'article.
export const TradeProductSchema = z.object({
  // Ordre XSD : GlobalID → SellerAssignedID → BuyerAssignedID → Name → Description →
  // ApplicableProductCharacteristic → DesignatedProductClassification → OriginTradeCountry.
  name: TextTypeSchema.min(1, "BT-153 product name must be non-empty"), // BT-153
  description: TextTypeSchema.optional(), // BT-154
  standardID: IdentifierSchema.optional(), // BT-157 (ex: GTIN/EAN)
  sellerAssignedID: IdentifierSchema.optional(), // BT-155
  buyerAssignedID: IdentifierSchema.optional(), // BT-156
  itemAttributes: z.array(ItemAttributeSchema).optional(), // BG-32
  classificationID: IdentifierSchema.optional(), // BT-158
  countryOfOriginCode: CodeTypeSchema.optional(), // BT-159 (ISO 3166-1 alpha-2)
});
export type TradeProduct = z.infer<typeof TradeProductSchema>;

// BG-29 — détails du prix.
export const LineTradeAgreementSchema = z.object({
  netPrice: z.number().finite(), // BT-146
  grossPrice: z.number().finite().optional(), // BT-148
  basisQuantity: z.number().finite().optional(), // BT-149
  basisQuantityUnitCode: CodeTypeSchema.optional(), // BT-150
  priceDiscount: z.number().finite().optional(), // BT-147
  buyerOrderLineReference: z.string().min(1).optional(), // BT-133 (ligne)
});
export type LineTradeAgreement = z.infer<typeof LineTradeAgreementSchema>;

// Quantité facturée + unité.
export const LineTradeDeliverySchema = z.object({
  billedQuantity: z.number().finite(), // BT-129
  unitCode: CodeTypeSchema, // BT-130 (UN/ECE Recommendation 20)
});
export type LineTradeDelivery = z.infer<typeof LineTradeDeliverySchema>;

// BG-30 — TVA de ligne.
export const LineVATInformationSchema = z.object({
  categoryCode: CodeTypeSchema, // BT-151
  ratePercent: z.number().finite().optional(), // BT-152
});
export type LineVATInformation = z.infer<typeof LineVATInformationSchema>;

// LineTradeSettlement — règlement de la ligne.
export const LineTradeSettlementSchema = z.object({
  vatInformation: LineVATInformationSchema, // BG-30
  netLineAmount: z.number().finite(), // BT-131
  lineAllowances: z.array(LineAllowanceChargeSchema).optional(), // BG-27
  lineCharges: z.array(LineAllowanceChargeSchema).optional(), // BG-28
  lineBillingPeriod: LineBillingPeriodSchema.optional(), // BG-26
  invoicedObjectID: AdditionalReferenceDocumentSchema.optional(), // BT-128 (typeCode="130")
  accountingReference: TextTypeSchema.optional(), // BT-133 (header) — note doc Swift
});
export type LineTradeSettlement = z.infer<typeof LineTradeSettlementSchema>;

// BG-25 — ligne de facture.
export const SupplyChainTradeLineItemSchema = z.object({
  lineID: z.string().min(1, "BT-126 lineID must be non-empty"), // BT-126
  product: TradeProductSchema, // BG-31
  tradeAgreement: LineTradeAgreementSchema, // BG-29
  tradeDelivery: LineTradeDeliverySchema, // billedQuantity + unit
  tradeSettlement: LineTradeSettlementSchema, // BG-30 + totaux ligne
  note: TextTypeSchema.optional(), // BT-127
});
export type SupplyChainTradeLineItem = z.infer<typeof SupplyChainTradeLineItemSchema>;
