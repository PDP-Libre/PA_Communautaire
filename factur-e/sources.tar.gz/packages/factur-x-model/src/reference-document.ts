// BG-3 PrecedingInvoiceReference, BG-24 AdditionalReferenceDocument,
// BT-125 AttachedBinaryObject.
// Référence : codebase-facturx-swift.md §3 + §5.5 + §9.4 #2/#15.

import { z } from "zod";
import { CodeTypeSchema, DateTypeSchema, TextTypeSchema } from "./base-types.js";

export const PrecedingInvoiceReferenceSchema = z.object({
  invoiceNumber: z.string().min(1, "BT-25 preceding invoiceNumber must be non-empty"), // BT-25
  issueDate: DateTypeSchema.optional(), // BT-26 — Bug §9.4 #15 : émis sous <qdt:DateTimeString>
});
export type PrecedingInvoiceReference = z.infer<typeof PrecedingInvoiceReferenceSchema>;

export const AttachedBinaryObjectSchema = z.object({
  mimeCode: CodeTypeSchema, // BT-125-1
  filename: z.string().min(1), // BT-125-2
  // Contenu binaire — encodé base64 par le sérialiseur (T-CL-02).
  content: z.instanceof(Uint8Array),
});
export type AttachedBinaryObject = z.infer<typeof AttachedBinaryObjectSchema>;

export const AdditionalReferenceDocumentSchema = z.object({
  documentID: z.string().min(1), // BT-122 / BT-17 / BT-18 / BT-128 selon typeCode
  typeCode: CodeTypeSchema, // "916" / "50" / "130"
  referenceTypeCode: CodeTypeSchema.optional(), // BT-18-1
  externalLocationURI: TextTypeSchema.optional(), // BT-124
  description: TextTypeSchema.optional(), // BT-123
  attachedDocument: AttachedBinaryObjectSchema.optional(), // BT-125
});
export type AdditionalReferenceDocument = z.infer<typeof AdditionalReferenceDocumentSchema>;
