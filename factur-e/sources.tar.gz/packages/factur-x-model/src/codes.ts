// Constantes Factur-X (codes, schemes, namespaces, profils, XMP).
// Référence : codebase-facturx-swift.md §7 + ADR-003 + audit-migration §6.
//
// Toute valeur figée par la spec Factur-X / EN 16931 vit ici. Les
// consommateurs (factur-x-builder, apps) importent depuis ce module — pas de
// hardcode dispersé.

// ---------------------------------------------------------------------------
// Profils Factur-X (BT-24 — `specificationID`).
// ---------------------------------------------------------------------------

export const FACTUR_X_PROFILES = {
  MINIMUM: "urn:factur-x.eu:1p0:minimum",
  BASIC_WL: "urn:factur-x.eu:1p0:basicwl",
  BASIC: "urn:cen.eu:en16931:2017#compliant#urn:factur-x.eu:1p0:basic",
  EN16931: "urn:cen.eu:en16931:2017",
  EXTENDED: "urn:cen.eu:en16931:2017#conformant#urn:factur-x.eu:1p0:extended",
} as const;

export type FacturXProfile = (typeof FACTUR_X_PROFILES)[keyof typeof FACTUR_X_PROFILES];

// ---------------------------------------------------------------------------
// BT-3 — type de document.
// ---------------------------------------------------------------------------

export const INVOICE_TYPE_CODES = {
  COMMERCIAL: "380",
  CREDIT_NOTE: "381",
  CORRECTIVE: "384",
  PARTIAL: "326",
  PREPAYMENT: "386",
  TAX_INVOICE: "388",
  SELF_BILLED: "389",
  CREDIT_NOTE_ALT: "261",
} as const;

export const CREDIT_NOTE_CODES = ["381", "261"] as const;

// ---------------------------------------------------------------------------
// BT-118 / BT-151 — catégorie TVA.
// ---------------------------------------------------------------------------

export const VAT_CATEGORY_CODES = {
  STANDARD: "S",
  ZERO_RATED: "Z",
  EXEMPT: "E",
  REVERSE_CHARGE: "AE",
  INTRA_COMMUNITY: "K",
  EXPORT: "G",
  OUTSIDE_SCOPE: "O",
  CANARY: "L",
  CEUTA_MELILLA: "M",
} as const;

export type VATCategoryCode = (typeof VAT_CATEGORY_CODES)[keyof typeof VAT_CATEGORY_CODES];

// ---------------------------------------------------------------------------
// BT-81 — moyen de paiement (UNTDID 4461 — sous-ensemble usuel).
// ---------------------------------------------------------------------------

export const PAYMENT_MEANS_CODES = {
  CASH: "10",
  CHEQUE: "20",
  CREDIT_TRANSFER: "30",
  BANK_PAYMENT: "42", // paiement sur compte bancaire (UNTDID 42)
  CARD: "48",
  DIRECT_DEBIT: "49",
  STANDING_AGREEMENT: "57", // accord permanent (UNTDID 57)
  SEPA_CREDIT_TRANSFER: "58",
  SEPA_DIRECT_DEBIT: "59",
} as const;

// ---------------------------------------------------------------------------
// schemeID — qualifiants identifiants.
// Voir glossaire + Peppol EAS code list (https://docs.peppol.eu/poacc/billing/3.0/codelist/eas/).
// Note : les libellés correspondent aux usages courants ; les codes 0223/0225/0227/
// 0228/0229 sont à recroiser avec la liste EAS officielle au prochain audit
// (audit-migration §6 — résiduel non bloquant).
// ---------------------------------------------------------------------------

export const SCHEME_IDS = {
  SIREN_SIRET: "0002",
  GLN: "0088",
  EORI: "0096",
  ODETTE: "0177",
  DUNS: "0060",
  ISO_6523_PEPPOL: "0223",
  AGENCY_PEPPOL: "0225",
  SUPPLIER_TRANSACTION: "0227",
  BUYER_TRANSACTION: "0228",
  PROCUREMENT: "0229",
  EMAIL: "EM",
  VAT: "VA",
  LOCAL_TAX_ID: "FC", // BT-32 — identifiant fiscal local
} as const;

// ---------------------------------------------------------------------------
// BG-24 — typeCode du document additionnel.
// ---------------------------------------------------------------------------

export const ADDITIONAL_DOC_TYPE_CODES = {
  SUPPORTING: "916", // BT-122
  TENDER: "50", // BT-17
  INVOICED_OBJECT: "130", // BT-18 / BT-128
} as const;

// ---------------------------------------------------------------------------
// BT-130 — unités de mesure (UN/ECE Recommendation 20 + Rec 21, sous-ensemble
// usuel). Source : Factur-X 1.07.3 v15 (`Rec20r20 + Rec21r20`) — cf.
// `docs/standards/factur-x-1.07.3-unit-codes-un-cefact-rec-20.md` §2.
// PIECE conservé à "C62" (one/dimensionless) pour cohérence interne acquise
// sprint-01 (vs "H87" piece recommandé Cowork — choix repo Factur-E inchangé).
// ---------------------------------------------------------------------------

export const UNIT_CODES = {
  PIECE: "C62",
  HOUR: "HUR",
  MINUTE: "MIN",
  SECOND: "SEC",
  DAY: "DAY",
  MONTH: "MON",
  YEAR: "ANN",
  MAN_MONTH: "3C",
  KILOGRAM: "KGM",
  GRAM: "GRM",
  TONNE: "TNE",
  LITRE: "LTR",
  MILLILITRE: "MLT",
  METRE: "MTR",
  CENTIMETRE: "CMT",
  MILLIMETRE: "MMT",
  KILOMETRE: "KMT",
  SQUARE_METRE: "MTK",
  CUBIC_METRE: "MTQ",
  // Rec 21 — packaging (FR : colis, boîte, paquet).
  PACKAGE_PIECE: "XPP",
  BOX: "XBX",
  PACKAGE: "XPK",
} as const;

// ---------------------------------------------------------------------------
// BT-21 — codes de sujet de note (UNTDID 4451, sous-ensemble usuel).
// Codes PMT/PMD/AAB obligatoires AFNOR XP Z12-012 §5.2 BR-FR-05 — mentions
// légales facture électronique réforme France (cf.
// `docs/standards/afnor-xp-z12-012-br-fr-05-included-notes.md` §3).
// ---------------------------------------------------------------------------

export const NOTE_SUBJECT_CODES = {
  TAX_INFO: "TXD",
  REGULATORY_INFO: "REG",
  GENERAL: "AAI",
  /** BR-FR-05 — indemnité forfaitaire 40 € Loi LME (fixe FR). */
  PAYMENT_TERMS: "PMT",
  /** BR-FR-05 — pénalités de retard (paramétrable customer, default LME 3× taux légal). */
  PAYMENT_MEANS_NOTE: "PMD",
  /** BR-FR-05 — mention escompte ou absence (paramétrable customer). */
  ADDITIONAL_BUYER_REF: "AAB",
} as const;

export type NoteSubjectCode = (typeof NOTE_SUBJECT_CODES)[keyof typeof NOTE_SUBJECT_CODES];

// ---------------------------------------------------------------------------
// Constantes XML / sérialisation Factur-X.
// ---------------------------------------------------------------------------

/** Format d'échange daté constant (BT-2, BT-72, BT-73, BT-74, BT-134, BT-135, BT-26). */
export const DATE_FORMAT_102 = "102" as const;

/** Code TVA technique (interne aux blocs ApplicableTradeTax / CategoryTradeTax). */
export const TAX_TYPE_VAT = "VAT" as const;

/** Précision des amounts (BT-92..BT-115, BT-117, BT-131, BT-146, etc.) — 2 décimales. */
export const DECIMALS_AMOUNT = 2 as const;

/** Précision des quantités (BT-129 BilledQuantity, BT-149 BasisQuantity) — 4 décimales. */
export const DECIMALS_QUANTITY = 4 as const;

// ---------------------------------------------------------------------------
// Contrat XMP / Associated File pour le PDF Factur-X
// (cf. doc Factur-X §8.2 / §8.3 + audit-migration §6).
// ---------------------------------------------------------------------------

/** AFRelationship par défaut pour le XML embarqué — compatible filière FR + DE. */
export const FACTUR_X_AF_RELATIONSHIP = "Alternative" as const;

/** Nom de fichier obligatoire du XML embarqué. */
export const FACTUR_X_XML_FILENAME = "factur-x.xml" as const;

/** MIME type du XML embarqué. */
export const FACTUR_X_XML_MIME_TYPE = "text/xml" as const;

/**
 * URI namespace de l'extension XMP Factur-X.
 * **Le `#` final est obligatoire** (cf. spec Factur-X §8.2).
 */
export const FX_XMP_NAMESPACE_URI = "urn:factur-x:pdfa:CrossIndustryDocument:invoice:1p0#" as const;

/** Préfixe XML utilisé pour le namespace Factur-X dans le XMP. */
export const FX_XMP_PREFIX = "fx" as const;

/** Valeur de `fx:DocumentType` — figée à `INVOICE` pour les factures Factur-X. */
export const FX_DOCUMENT_TYPE = "INVOICE" as const;

/** Valeur de `fx:Version` — version Factur-X cible. */
export const FX_VERSION = "1.0" as const;

/**
 * Valeurs admises pour `fx:ConformanceLevel` (cf. extension-schema-xmp.txt).
 *
 * **NB :** `EN 16931` contient un espace et est distinct de l'URN
 * `FACTUR_X_PROFILES.EN16931 = "urn:cen.eu:en16931:2017"` qui sert au BT-24
 * dans le XML interne.
 */
export const FX_CONFORMANCE_LEVELS = {
  MINIMUM: "MINIMUM",
  BASIC_WL: "BASIC WL",
  BASIC: "BASIC",
  EN16931: "EN 16931",
  EXTENDED: "EXTENDED",
} as const;

export type FxConformanceLevel = (typeof FX_CONFORMANCE_LEVELS)[keyof typeof FX_CONFORMANCE_LEVELS];
