// Types sémantiques de base EN 16931.
// Mapping XML : Identifier → <ram:ID schemeID="…">VALUE</ram:ID>,
//               DateType   → <udt:DateTimeString format="102">YYYYMMDD</udt:DateTimeString>,
//               AmountType → <ram:Xxx currencyID="EUR">12.34</ram:Xxx>.
// Référence : codebase-facturx-swift.md §3.1.

import { z } from "zod";
import { DATE_FORMAT_102 } from "./codes.js";

const YYYYMMDD_REGEX = /^\d{8}$/;

export const IdentifierSchema = z.object({
  value: z.string().min(1, "Identifier.value must be a non-empty string"),
  schemeID: z.string().min(1).optional(),
});
export type Identifier = z.infer<typeof IdentifierSchema>;

export const DateTypeSchema = z.object({
  value: z.string().regex(YYYYMMDD_REGEX, "DateType.value must be yyyyMMdd (8 digits)"),
  format: z.literal(DATE_FORMAT_102),
});
export type DateType = z.infer<typeof DateTypeSchema>;

// ISO 4217 currency code (3 uppercase letters).
const CURRENCY_REGEX = /^[A-Z]{3}$/;

export const AmountTypeSchema = z.object({
  value: z.number().finite(),
  currencyID: z
    .string()
    .regex(CURRENCY_REGEX, "currencyID must be ISO 4217 (3 uppercase letters)")
    .optional(),
});
export type AmountType = z.infer<typeof AmountTypeSchema>;

// Aliases sémantiques pour la lisibilité du modèle. La validation Zod
// associée vit dans les schemas qui consomment ces alias.
export type CodeType = string;
export const CodeTypeSchema = z.string().min(1);

export type TextType = string;
export const TextTypeSchema = z.string();

// Helpers — construction depuis JS Date / nombre.

/** Convertit une `Date` en `DateType` au format yyyyMMdd. */
export function dateOf(date: Date): DateType {
  const yyyy = String(date.getUTCFullYear()).padStart(4, "0");
  const mm = String(date.getUTCMonth() + 1).padStart(2, "0");
  const dd = String(date.getUTCDate()).padStart(2, "0");
  return { value: `${yyyy}${mm}${dd}`, format: DATE_FORMAT_102 };
}

/** Convertit un `DateType` en `Date` UTC à minuit. Retourne `null` si invalide. */
export function dateTypeToDate(dt: DateType): Date | null {
  if (!YYYYMMDD_REGEX.test(dt.value)) return null;
  const yyyy = Number(dt.value.slice(0, 4));
  const mm = Number(dt.value.slice(4, 6));
  const dd = Number(dt.value.slice(6, 8));
  const d = new Date(Date.UTC(yyyy, mm - 1, dd));
  if (d.getUTCFullYear() !== yyyy || d.getUTCMonth() !== mm - 1 || d.getUTCDate() !== dd) {
    return null;
  }
  return d;
}

/** Construit un `Identifier`. `schemeID` reste optionnel à ce niveau ; les
 * défauts (`"VA"` pour BT-31/48/63, `"EM"` pour BT-34/49) sont appliqués par
 * la couche de sérialisation (T-CL-02). */
export function identifier(value: string, schemeID?: string): Identifier {
  return schemeID === undefined ? { value } : { value, schemeID };
}

/** Construit un `AmountType`. */
export function amount(value: number, currencyID?: string): AmountType {
  return currencyID === undefined ? { value } : { value, currencyID };
}
