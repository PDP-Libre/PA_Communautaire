// BG-22 MonetarySummation — totaux du document.
// Référence : codebase-facturx-swift.md §3 + §5.9 + §9.4 #6.
//
// Ordre XSD strict (cf. §9.1 doc) :
//   LineTotalAmount → ChargeTotalAmount → AllowanceTotalAmount → TaxBasisTotalAmount →
//   TaxTotalAmount(BT-110) → TaxTotalAmount(BT-111) → RoundingAmount → GrandTotalAmount →
//   TotalPrepaidAmount → DuePayableAmount.
// La sortie déterministe est de la responsabilité du sérialiseur (T-CL-02).
//
// BR-CO-15 : grandTotalAmount = taxBasisTotalAmount + Σ vatTotalAmount.
// BR-DEC-13/14 : tous les `…Amount` doivent porter `currencyID="<BT-5>"` à la sérialisation.

import { z } from "zod";
import { AmountTypeSchema } from "./base-types.js";

export const MonetarySummationSchema = z.object({
  lineTotalAmount: z.number().finite(), // BT-106
  chargeTotalAmount: z.number().finite().optional(), // BT-108
  allowanceTotalAmount: z.number().finite().optional(), // BT-107
  taxBasisTotalAmount: z.number().finite(), // BT-109
  vatTotalAmount: AmountTypeSchema.optional(), // BT-110 (currencyID requis)
  taxCurrencyVATTotalAmount: AmountTypeSchema.optional(), // BT-111 (devise BT-6)
  roundingAmount: z.number().finite().optional(), // BT-114
  grandTotalAmount: z.number().finite(), // BT-112
  paidAmount: z.number().finite().optional(), // BT-113
  duePayableAmount: z.number().finite(), // BT-115
});
export type MonetarySummation = z.infer<typeof MonetarySummationSchema>;
