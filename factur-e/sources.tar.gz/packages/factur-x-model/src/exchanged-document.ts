// BG-2 ExchangedDocumentContext, ExchangedDocument, BG-1 DocumentNote.
// Référence : codebase-facturx-swift.md §3.2 + §5.4.

import { z } from "zod";
import { CodeTypeSchema, DateTypeSchema, IdentifierSchema, TextTypeSchema } from "./base-types.js";

export const DocumentNoteSchema = z.object({
  content: TextTypeSchema, // BT-22
  subjectCode: CodeTypeSchema.optional(), // BT-21
});
export type DocumentNote = z.infer<typeof DocumentNoteSchema>;

export const ExchangedDocumentContextSchema = z.object({
  // BT-23 — process metier (identifiant URN ou texte libre).
  businessProcessID: TextTypeSchema.optional(),
  // BT-24 — profil cible. La valeur fixe est imposée par BR-1 et acte le
  // profil EXTENDED ou EN16931 (cf. ADR-003 et codes.ts:FACTUR_X_PROFILES).
  specificationID: IdentifierSchema,
});
export type ExchangedDocumentContext = z.infer<typeof ExchangedDocumentContextSchema>;

export const ExchangedDocumentSchema = z.object({
  invoiceNumber: z.string().min(1, "BT-1 invoiceNumber must be non-empty"), // BT-1
  invoiceTypeCode: CodeTypeSchema, // BT-3
  issueDate: DateTypeSchema, // BT-2
  includedNotes: z.array(DocumentNoteSchema).optional(), // BG-1
});
export type ExchangedDocument = z.infer<typeof ExchangedDocumentSchema>;
