// BG-20 / BG-21 DocumentAllowanceCharge (header),
// BG-27 / BG-28 LineAllowanceCharge (ligne).
// Référence : codebase-facturx-swift.md §3 + §5.10 + §9.4 #6/#8/#9/#10/#11/#12.
//
// Conventions :
//   - `isCharge: false` → BG-20 (remise, BT-92..BT-98)  / BG-27 (remise ligne, BT-136..BT-140)
//   - `isCharge: true`  → BG-21 (charge, BT-99..BT-105) / BG-28 (charge ligne, BT-141..BT-145)
//
// BR-42 / BR-43 (validateInvoice) : `reason` ou `reasonCode` doit être présent.

import { z } from "zod";
import { CodeTypeSchema, TextTypeSchema } from "./base-types.js";

export const DocumentAllowanceChargeSchema = z.object({
  isCharge: z.boolean(),
  actualAmount: z.number().finite(), // BT-92 / BT-99
  taxCategoryCode: CodeTypeSchema, // BT-95 / BT-102 — référence catégorie TVA (S/Z/E/AE/K/G/O/L/M)
  taxPercent: z.number().finite().optional(), // BT-96 / BT-103
  basisAmount: z.number().finite().optional(), // BT-93 / BT-100
  calculationPercent: z.number().finite().optional(), // BT-94 / BT-101
  reason: TextTypeSchema.optional(), // BT-97 / BT-104
  reasonCode: CodeTypeSchema.optional(), // BT-98 / BT-105
});
export type DocumentAllowanceCharge = z.infer<typeof DocumentAllowanceChargeSchema>;

export const LineAllowanceChargeSchema = z.object({
  isCharge: z.boolean(),
  actualAmount: z.number().finite(), // BT-136 / BT-141
  basisAmount: z.number().finite().optional(), // BT-138 / BT-143
  calculationPercent: z.number().finite().optional(), // BT-137 / BT-142
  reason: TextTypeSchema.optional(), // BT-139 / BT-144
  reasonCode: CodeTypeSchema.optional(), // BT-140 / BT-145
});
export type LineAllowanceCharge = z.infer<typeof LineAllowanceChargeSchema>;
