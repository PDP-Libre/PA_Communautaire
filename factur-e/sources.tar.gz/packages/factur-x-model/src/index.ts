// Public surface du modèle Factur-X / EN 16931.
//
// Architecture : un schema Zod par structure logique (≈ par BG), composables —
// cf. ADR-003 D5. Aucune dépendance vers la sérialisation, le PDF, le XML.

export * from "./codes.js";
export * from "./base-types.js";
export * from "./exchanged-document.js";
export * from "./trade-party.js";
export * from "./billing-period.js";
export * from "./reference-document.js";
export * from "./allowance-charge.js";
export * from "./monetary-summation.js";
export * from "./vat-breakdown.js";
export * from "./payment.js";
export * from "./invoice-line-item.js";
export * from "./trade-transaction.js";
export * from "./invoice.js";
export * from "./result.js";
