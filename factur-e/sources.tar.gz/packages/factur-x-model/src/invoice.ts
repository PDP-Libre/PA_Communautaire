// rsm:CrossIndustryInvoice — structure racine, composition.
// Référence : codebase-facturx-swift.md §3.2 + §5 + ADR-003 D5.

import { z } from "zod";
import { ExchangedDocumentContextSchema, ExchangedDocumentSchema } from "./exchanged-document.js";
import { SupplyChainTradeTransactionSchema } from "./trade-transaction.js";

export const CrossIndustryInvoiceSchema = z.object({
  documentContext: ExchangedDocumentContextSchema,
  exchangedDocument: ExchangedDocumentSchema,
  tradeTransaction: SupplyChainTradeTransactionSchema,
});
export type CrossIndustryInvoice = z.infer<typeof CrossIndustryInvoiceSchema>;
