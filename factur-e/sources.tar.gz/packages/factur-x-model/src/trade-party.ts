// BG-4/BG-7/BG-10 TradeParty, BG-5/BG-8/BG-12/BG-15 PostalAddress,
// BG-6/BG-9 TradeContact, BG-11 SellerTaxRepresentativeParty.
// Référence : codebase-facturx-swift.md §3.3 + §5.11 (ordre XSD TradePartyType).
//
// Bug §9.4 #19 corrigé : `taxRegistrationLocalID` (BT-32, schemeID="FC") — second
// `<ram:SpecifiedTaxRegistration>` admis par la XSD (`maxOccurs="2"`), absent du modèle Swift.
// Bug §9.4 #22 : `tradingName` (BT-28/BT-45) doit être émis sous
// `<ram:SpecifiedLegalOrganization><ram:TradingBusinessName>`, pas sous `<ram:Description>`.
// Le modèle TS porte la donnée ; la translation est de la responsabilité du sérialiseur (T-CL-02).

import { z } from "zod";
import { CodeTypeSchema, IdentifierSchema, TextTypeSchema } from "./base-types.js";

// Code pays ISO 3166-1 alpha-2.
const COUNTRY_CODE_REGEX = /^[A-Z]{2}$/;

export const PostalAddressSchema = z.object({
  countryCode: CodeTypeSchema.refine(
    (v) => COUNTRY_CODE_REGEX.test(v),
    "countryCode must be ISO 3166-1 alpha-2 (2 uppercase letters)",
  ), // BT-40 / BT-55 / BT-69 / BT-80
  postalCode: TextTypeSchema.optional(), // BT-38 / BT-53 / BT-67 / BT-78
  cityName: TextTypeSchema.optional(), // BT-37 / BT-52 / BT-66 / BT-77
  lineOne: TextTypeSchema.optional(), // BT-35 / BT-50 / BT-64 / BT-75
  lineTwo: TextTypeSchema.optional(), // BT-36 / BT-51 / BT-65 / BT-76
  lineThree: TextTypeSchema.optional(), // BT-162 / BT-163 / BT-165 / BT-166
  countrySubDivisionName: TextTypeSchema.optional(), // BT-39 / BT-54 / BT-68 / BT-79
});
export type PostalAddress = z.infer<typeof PostalAddressSchema>;

export const TradeContactSchema = z.object({
  personName: TextTypeSchema.optional(), // BT-41 / BT-56
  telephoneNumber: TextTypeSchema.optional(), // BT-42 / BT-57
  emailAddress: TextTypeSchema.optional(), // BT-43 / BT-58
});
export type TradeContact = z.infer<typeof TradeContactSchema>;

export const TradePartySchema = z.object({
  name: TextTypeSchema.min(1, "BT-27/BT-44 name must be non-empty"), // BT-27 / BT-44
  postalAddress: PostalAddressSchema, // BG-5 / BG-8 / BG-10's address
  legalRegistrationID: IdentifierSchema.optional(), // BT-30 / BT-47 (SIREN/SIRET → schemeID="0002")
  vatID: IdentifierSchema.optional(), // BT-31 / BT-48 (schemeID="VA")
  taxRegistrationLocalID: IdentifierSchema.optional(), // BT-32 (schemeID="FC") — Bug §9.4 #19
  tradingName: TextTypeSchema.optional(), // BT-28 / BT-45 — Bug §9.4 #22
  globalID: IdentifierSchema.optional(), // BT-29 / BT-46 (ex: GLN schemeID="0088")
  electronicAddress: IdentifierSchema.optional(), // BT-34 / BT-49 (schemeID requis, défaut "EM")
  // Profil EN16931 = 0..1 contact (Bug §9.4 #23 : Swift ne borne pas).
  // Le profil EXTENDED autorise 0..n. On reste permissif au niveau du
  // modèle ; le sérialiseur (T-CL-02) appliquera la cardinalité du profil.
  definedContacts: z.array(TradeContactSchema).optional(),
});
export type TradeParty = z.infer<typeof TradePartySchema>;

export const SellerTaxRepresentativePartySchema = z.object({
  name: TextTypeSchema.min(1, "BT-62 name must be non-empty"),
  vatID: IdentifierSchema, // BT-63 (schemeID="VA" forcé par BR-CO-9)
  postalAddress: PostalAddressSchema, // BG-12
});
export type SellerTaxRepresentativeParty = z.infer<typeof SellerTaxRepresentativePartySchema>;
