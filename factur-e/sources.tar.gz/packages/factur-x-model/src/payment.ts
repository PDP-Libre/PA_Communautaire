// BG-16 PaymentMeans, BG-17 FinancialAccountDetails, BG-18 PaymentCard,
// FinancialAccount (compte à débiter pour prélèvement).
// Référence : codebase-facturx-swift.md §3 + §5.8 + §9.4 #14/#16/#17/#25/#26.
//
// Bug §9.4 #16 : BT-90 (creditorReferenceID) est porté par HeaderTradeSettlement,
// pas par PaymentMeans. Le champ est donc retiré ici par rapport au modèle Swift.
// Bug §9.4 #17 : BT-89 (directDebitMandateID) est sérialisé sous
// SpecifiedTradePaymentTerms ; on le conserve néanmoins logiquement attaché à PaymentMeans
// au niveau modèle (ergonomie data-first), le sérialiseur (T-CL-02) le déplace.
// Bug §9.4 #25 : un bloc PaymentMeans XML peut contenir 0..1 PayeeFinancialAccount —
// pour multi-comptes, la sérialisation produit un PaymentMeans XML par compte. Le
// modèle TS expose un tableau `payeeFinancialAccounts: FinancialAccountDetails[]` ;
// la responsabilité du fan-out est dans T-CL-02.
// Bug §9.4 #26 : `<ram:IBANID>` vs `<ram:ProprietaryID>` selon le `schemeID`
// de `accountID` — porté par le modèle (Identifier.schemeID) ; choix XML dans T-CL-02.

import { z } from "zod";
import { CodeTypeSchema, IdentifierSchema, TextTypeSchema } from "./base-types.js";

export const FinancialAccountSchema = z.object({
  // Identifiant du compte à débiter (BT-91 — payeur, prélèvement).
  accountID: IdentifierSchema,
});
export type FinancialAccount = z.infer<typeof FinancialAccountSchema>;

export const FinancialAccountDetailsSchema = z.object({
  accountID: IdentifierSchema, // BT-84 (IBAN ou ProprietaryID selon schemeID)
  accountName: TextTypeSchema.optional(), // BT-85
  financialInstitutionID: IdentifierSchema.optional(), // BT-86 (BIC du PSP du bénéficiaire)
});
export type FinancialAccountDetails = z.infer<typeof FinancialAccountDetailsSchema>;

export const PaymentCardSchema = z.object({
  // BT-87 — BR-51 : 4 à 6 derniers chiffres uniquement (vérifié par validateInvoice).
  primaryAccountNumber: TextTypeSchema.min(1),
  cardholderName: TextTypeSchema.optional(), // BT-88
});
export type PaymentCard = z.infer<typeof PaymentCardSchema>;

export const PaymentMeansSchema = z.object({
  typeCode: CodeTypeSchema, // BT-81
  information: TextTypeSchema.optional(), // BT-82
  // BT-89 — mandate ID (SEPA prélèvement). Émis dans PaymentTerms à la sérialisation.
  directDebitMandateID: IdentifierSchema.optional(),
  payerFinancialAccount: FinancialAccountSchema.optional(), // BT-91
  payeeFinancialAccounts: z.array(FinancialAccountDetailsSchema).optional(), // BG-17
  paymentCard: PaymentCardSchema.optional(), // BG-18
});
export type PaymentMeans = z.infer<typeof PaymentMeansSchema>;
