// BG-14 BillingPeriod, BG-26 LineBillingPeriod.
// Référence : codebase-facturx-swift.md §3 + §5.7.
//
// BR-CO-20 (vérifiée par validateInvoice) : si la période est émise, au moins
// une de startDate / endDate doit être présente — interdit le wrapper vide.

import { z } from "zod";
import { DateTypeSchema } from "./base-types.js";

export const BillingPeriodSchema = z.object({
  startDate: DateTypeSchema.optional(), // BT-73
  endDate: DateTypeSchema.optional(), // BT-74
});
export type BillingPeriod = z.infer<typeof BillingPeriodSchema>;

export const LineBillingPeriodSchema = z.object({
  startDate: DateTypeSchema.optional(), // BT-134
  endDate: DateTypeSchema.optional(), // BT-135
});
export type LineBillingPeriod = z.infer<typeof LineBillingPeriodSchema>;
