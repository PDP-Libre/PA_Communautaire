import { describe, expect, it } from "vitest";
import {
  AmountTypeSchema,
  DateTypeSchema,
  IdentifierSchema,
  amount,
  dateOf,
  dateTypeToDate,
  identifier,
} from "../src/index.js";

describe("IdentifierSchema", () => {
  it("accepte une valeur seule", () => {
    expect(IdentifierSchema.parse({ value: "FR12345" })).toEqual({
      value: "FR12345",
    });
  });

  it("accepte un schemeID", () => {
    const id = IdentifierSchema.parse({ value: "123", schemeID: "0002" });
    expect(id.schemeID).toBe("0002");
  });

  it("rejette une valeur vide", () => {
    expect(() => IdentifierSchema.parse({ value: "" })).toThrow();
  });
});

describe("DateTypeSchema", () => {
  it("accepte yyyyMMdd", () => {
    const d = DateTypeSchema.parse({ value: "20260415", format: "102" });
    expect(d.value).toBe("20260415");
  });

  it("rejette un format invalide", () => {
    expect(() => DateTypeSchema.parse({ value: "2026-04-15", format: "102" })).toThrow();
    expect(() => DateTypeSchema.parse({ value: "20260415", format: "101" })).toThrow();
  });
});

describe("AmountTypeSchema", () => {
  it("accepte un montant sans devise", () => {
    expect(AmountTypeSchema.parse({ value: 12.34 })).toEqual({ value: 12.34 });
  });

  it("accepte un montant avec ISO 4217", () => {
    expect(AmountTypeSchema.parse({ value: 100, currencyID: "EUR" })).toEqual({
      value: 100,
      currencyID: "EUR",
    });
  });

  it("rejette un currencyID minuscule", () => {
    expect(() => AmountTypeSchema.parse({ value: 100, currencyID: "eur" })).toThrow();
  });

  it("rejette une valeur infinie", () => {
    expect(() => AmountTypeSchema.parse({ value: Infinity })).toThrow();
  });
});

describe("dateOf / dateTypeToDate (round-trip)", () => {
  it("convertit Date → DateType → Date en UTC", () => {
    const d = new Date(Date.UTC(2026, 3, 15)); // 15 avril 2026
    const dt = dateOf(d);
    expect(dt.value).toBe("20260415");
    expect(dt.format).toBe("102");
    const back = dateTypeToDate(dt);
    expect(back).not.toBeNull();
    expect(back?.toISOString()).toBe("2026-04-15T00:00:00.000Z");
  });

  it("zero-pad les composantes (mois et jour à 1 chiffre)", () => {
    const d = new Date(Date.UTC(2026, 0, 9)); // 9 janvier 2026
    expect(dateOf(d).value).toBe("20260109");
  });

  it("zero-pad l'année à 4 chiffres", () => {
    // setUTCFullYear évite le mapping JS 0..99 → 1900 + x.
    const d = new Date(Date.UTC(2026, 2, 1));
    d.setUTCFullYear(7);
    expect(dateOf(d).value).toBe("00070301");
  });

  it("retourne null pour une chaîne incohérente", () => {
    expect(dateTypeToDate({ value: "20269999", format: "102" })).toBeNull();
  });
});

describe("identifier() helper", () => {
  it("omet schemeID si non fourni", () => {
    const id = identifier("FR12");
    expect(id).toEqual({ value: "FR12" });
    expect("schemeID" in id).toBe(false);
  });

  it("inclut schemeID si fourni", () => {
    expect(identifier("FR12", "VA")).toEqual({ value: "FR12", schemeID: "VA" });
  });
});

describe("amount() helper", () => {
  it("omet currencyID si non fourni", () => {
    const a = amount(42);
    expect(a).toEqual({ value: 42 });
    expect("currencyID" in a).toBe(false);
  });

  it("inclut currencyID si fourni", () => {
    expect(amount(42, "EUR")).toEqual({ value: 42, currencyID: "EUR" });
  });
});
