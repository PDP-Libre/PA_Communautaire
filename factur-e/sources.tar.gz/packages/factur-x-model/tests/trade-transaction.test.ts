import { describe, expect, it } from "vitest";
import {
  HeaderTradeAgreementSchema,
  HeaderTradeDeliverySchema,
  HeaderTradeSettlementSchema,
  SupplyChainTradeTransactionSchema,
} from "../src/index.js";
import { extendedInvoice } from "./fixtures/extended-invoice.js";
import { minimalInvoice } from "./fixtures/minimal-invoice.js";

describe("HeaderTradeAgreementSchema", () => {
  it("parse seller + buyer minimum (BG-4 + BG-7)", () => {
    const parsed = HeaderTradeAgreementSchema.parse({
      sellerTradeParty: { name: "S", postalAddress: { countryCode: "FR" } },
      buyerTradeParty: { name: "B", postalAddress: { countryCode: "FR" } },
    });
    expect(parsed.sellerTradeParty.name).toBe("S");
  });

  it("accepte sellerTaxRepresentative (BG-11) + additionalReferencedDocuments (BG-24)", () => {
    const parsed = HeaderTradeAgreementSchema.parse(
      extendedInvoice.tradeTransaction.tradeAgreement,
    );
    expect(parsed.sellerTaxRepresentative).toBeDefined();
    expect(parsed.additionalReferencedDocuments).toHaveLength(1);
  });
});

describe("HeaderTradeDeliverySchema (BG-13/15)", () => {
  it("accepte un objet vide (tous les champs sont 0..1)", () => {
    expect(HeaderTradeDeliverySchema.parse({})).toEqual({});
  });

  it("parse une livraison complète", () => {
    const parsed = HeaderTradeDeliverySchema.parse(extendedInvoice.tradeTransaction.tradeDelivery);
    expect(parsed.shipToPartyName).toBe("Boulangerie du Centre");
  });
});

describe("HeaderTradeSettlementSchema", () => {
  it("exige currency + au moins 1 vatBreakdown + monetarySummation (BR-CO-18)", () => {
    expect(() =>
      HeaderTradeSettlementSchema.parse({
        invoiceCurrencyCode: "EUR",
        vatBreakdowns: [],
        monetarySummation: {
          lineTotalAmount: 0,
          taxBasisTotalAmount: 0,
          grandTotalAmount: 0,
          duePayableAmount: 0,
        },
      }),
    ).toThrow();
  });

  it("parse le settlement EXTENDED complet", () => {
    const parsed = HeaderTradeSettlementSchema.parse(
      extendedInvoice.tradeTransaction.tradeSettlement,
    );
    expect(parsed.creditorReferenceID?.value).toBe("FR76ZZZ123456");
    expect(parsed.payeeParty?.name).toBe("Audit Pro Recouvrement");
  });
});

describe("SupplyChainTradeTransactionSchema", () => {
  it("BR-16 — au moins une ligne", () => {
    expect(() =>
      SupplyChainTradeTransactionSchema.parse({
        ...minimalInvoice.tradeTransaction,
        lineItems: [],
      }),
    ).toThrow();
  });

  it("parse la transaction de la fixture EXTENDED", () => {
    const parsed = SupplyChainTradeTransactionSchema.parse(extendedInvoice.tradeTransaction);
    expect(parsed.lineItems).toHaveLength(2);
  });
});
