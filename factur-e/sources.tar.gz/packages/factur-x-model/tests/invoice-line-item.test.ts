import { describe, expect, it } from "vitest";
import {
  ItemAttributeSchema,
  LineTradeAgreementSchema,
  LineTradeDeliverySchema,
  LineTradeSettlementSchema,
  LineVATInformationSchema,
  SupplyChainTradeLineItemSchema,
  TradeProductSchema,
  UNIT_CODES,
  VAT_CATEGORY_CODES,
} from "../src/index.js";

describe("TradeProductSchema (BG-31)", () => {
  it("accepte un produit minimal (nom seulement)", () => {
    expect(TradeProductSchema.parse({ name: "Service" })).toEqual({
      name: "Service",
    });
  });

  it("rejette un nom vide (BR-25 — pré-validation structurelle)", () => {
    expect(() => TradeProductSchema.parse({ name: "" })).toThrow();
  });

  it("accepte les attributs (BG-32) et le pays d'origine (BT-159)", () => {
    const parsed = TradeProductSchema.parse({
      name: "Boîte de chocolats",
      itemAttributes: [
        { attributeName: "Poids", attributeValue: "250g" },
        { attributeName: "Marque", attributeValue: "X" },
      ],
      countryOfOriginCode: "BE",
    });
    expect(parsed.itemAttributes).toHaveLength(2);
    expect(parsed.countryOfOriginCode).toBe("BE");
  });
});

describe("ItemAttributeSchema", () => {
  it("rejette des champs vides", () => {
    expect(() => ItemAttributeSchema.parse({ attributeName: "", attributeValue: "x" })).toThrow();
    expect(() => ItemAttributeSchema.parse({ attributeName: "x", attributeValue: "" })).toThrow();
  });
});

describe("LineTradeAgreementSchema (BG-29)", () => {
  it("exige netPrice (BT-146)", () => {
    expect(() => LineTradeAgreementSchema.parse({})).toThrow();
  });

  it("accepte tous les champs optionnels", () => {
    const parsed = LineTradeAgreementSchema.parse({
      netPrice: 100,
      grossPrice: 120,
      basisQuantity: 1,
      basisQuantityUnitCode: UNIT_CODES.PIECE,
      priceDiscount: 20,
      buyerOrderLineReference: "BC-1",
    });
    expect(parsed.priceDiscount).toBe(20);
  });
});

describe("LineTradeDeliverySchema", () => {
  it("exige billedQuantity et unitCode", () => {
    expect(() => LineTradeDeliverySchema.parse({ billedQuantity: 1 })).toThrow();
  });
});

describe("LineVATInformationSchema (BG-30)", () => {
  it("exige categoryCode (BT-151)", () => {
    expect(() => LineVATInformationSchema.parse({})).toThrow();
  });

  it("accepte ratePercent à 0 (catégorie Z)", () => {
    expect(
      LineVATInformationSchema.parse({
        categoryCode: VAT_CATEGORY_CODES.ZERO_RATED,
        ratePercent: 0,
      }),
    ).toMatchObject({ ratePercent: 0 });
  });
});

describe("LineTradeSettlementSchema", () => {
  it("compose vatInformation + netLineAmount", () => {
    const parsed = LineTradeSettlementSchema.parse({
      vatInformation: {
        categoryCode: VAT_CATEGORY_CODES.STANDARD,
        ratePercent: 20,
      },
      netLineAmount: 100,
    });
    expect(parsed.netLineAmount).toBe(100);
  });
});

describe("SupplyChainTradeLineItemSchema (BG-25)", () => {
  it("parse une ligne complète", () => {
    const parsed = SupplyChainTradeLineItemSchema.parse({
      lineID: "1",
      product: { name: "Service" },
      tradeAgreement: { netPrice: 100 },
      tradeDelivery: { billedQuantity: 2, unitCode: UNIT_CODES.PIECE },
      tradeSettlement: {
        vatInformation: {
          categoryCode: VAT_CATEGORY_CODES.STANDARD,
          ratePercent: 20,
        },
        netLineAmount: 200,
      },
      note: "Détail",
    });
    expect(parsed.lineID).toBe("1");
    expect(parsed.note).toBe("Détail");
  });

  it("rejette un lineID vide (BR-21 — pré-validation structurelle)", () => {
    expect(() =>
      SupplyChainTradeLineItemSchema.parse({
        lineID: "",
        product: { name: "x" },
        tradeAgreement: { netPrice: 1 },
        tradeDelivery: { billedQuantity: 1, unitCode: UNIT_CODES.PIECE },
        tradeSettlement: {
          vatInformation: {
            categoryCode: VAT_CATEGORY_CODES.STANDARD,
          },
          netLineAmount: 1,
        },
      }),
    ).toThrow();
  });
});
