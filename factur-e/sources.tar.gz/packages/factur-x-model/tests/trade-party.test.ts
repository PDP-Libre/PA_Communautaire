import { describe, expect, it } from "vitest";
import {
  PostalAddressSchema,
  SCHEME_IDS,
  SellerTaxRepresentativePartySchema,
  TradeContactSchema,
  TradePartySchema,
} from "../src/index.js";

describe("PostalAddressSchema", () => {
  it("accepte une adresse minimale (countryCode seulement)", () => {
    expect(PostalAddressSchema.parse({ countryCode: "FR" })).toEqual({
      countryCode: "FR",
    });
  });

  it("rejette un countryCode non ISO 3166-1 alpha-2", () => {
    expect(() => PostalAddressSchema.parse({ countryCode: "France" })).toThrow();
    expect(() => PostalAddressSchema.parse({ countryCode: "fr" })).toThrow();
  });

  it("accepte tous les champs optionnels", () => {
    const parsed = PostalAddressSchema.parse({
      countryCode: "FR",
      postalCode: "75001",
      cityName: "Paris",
      lineOne: "1 rue",
      lineTwo: "App 2",
      lineThree: "Étage 3",
      countrySubDivisionName: "Île-de-France",
    });
    expect(parsed.countrySubDivisionName).toBe("Île-de-France");
  });
});

describe("TradeContactSchema (BG-6/BG-9)", () => {
  it("accepte un contact vide (tous champs 0..1)", () => {
    expect(TradeContactSchema.parse({})).toEqual({});
  });

  it("accepte des champs partiels", () => {
    expect(
      TradeContactSchema.parse({
        personName: "S. Martin",
        emailAddress: "s.martin@example.com",
      }),
    ).toMatchObject({ personName: "S. Martin" });
  });
});

describe("TradePartySchema (BG-4/BG-7/BG-10)", () => {
  it("parse un vendeur complet", () => {
    const parsed = TradePartySchema.parse({
      name: "Mon Entreprise SAS",
      postalAddress: { countryCode: "FR" },
      legalRegistrationID: { value: "123456789", schemeID: SCHEME_IDS.SIREN_SIRET },
      vatID: { value: "FR12123456789", schemeID: SCHEME_IDS.VAT },
      taxRegistrationLocalID: { value: "123456789", schemeID: SCHEME_IDS.LOCAL_TAX_ID },
      tradingName: "MonEntreprise",
      globalID: { value: "3033333000010", schemeID: SCHEME_IDS.GLN },
      electronicAddress: { value: "facturation@me.fr", schemeID: SCHEME_IDS.EMAIL },
      definedContacts: [{ personName: "Sophie" }],
    });
    expect(parsed.name).toBe("Mon Entreprise SAS");
    expect(parsed.taxRegistrationLocalID?.schemeID).toBe(SCHEME_IDS.LOCAL_TAX_ID);
  });

  it("rejette un name vide (BT-27 doit être non vide)", () => {
    expect(() =>
      TradePartySchema.parse({ name: "", postalAddress: { countryCode: "FR" } }),
    ).toThrow();
  });
});

describe("SellerTaxRepresentativePartySchema (BG-11)", () => {
  it("exige name + vatID + postalAddress", () => {
    const parsed = SellerTaxRepresentativePartySchema.parse({
      name: "Cabinet Fiscal France",
      vatID: { value: "FR99888777666", schemeID: SCHEME_IDS.VAT },
      postalAddress: { countryCode: "FR", cityName: "Paris" },
    });
    expect(parsed.vatID.value).toBe("FR99888777666");
  });

  it("rejette si vatID absent", () => {
    expect(() =>
      SellerTaxRepresentativePartySchema.parse({
        name: "X",
        postalAddress: { countryCode: "FR" },
      }),
    ).toThrow();
  });
});
