import { describe, expect, it } from "vitest";
import {
  CREDIT_NOTE_CODES,
  DECIMALS_AMOUNT,
  DECIMALS_QUANTITY,
  FACTUR_X_AF_RELATIONSHIP,
  FACTUR_X_PROFILES,
  FACTUR_X_XML_FILENAME,
  FACTUR_X_XML_MIME_TYPE,
  FX_CONFORMANCE_LEVELS,
  FX_DOCUMENT_TYPE,
  FX_VERSION,
  FX_XMP_NAMESPACE_URI,
  FX_XMP_PREFIX,
  INVOICE_TYPE_CODES,
  PAYMENT_MEANS_CODES,
  SCHEME_IDS,
  TAX_TYPE_VAT,
  VAT_CATEGORY_CODES,
} from "../src/index.js";

describe("Constantes Factur-X", () => {
  it("référence le profil EN16931", () => {
    expect(FACTUR_X_PROFILES.EN16931).toBe("urn:cen.eu:en16931:2017");
  });

  it("référence le profil EXTENDED", () => {
    expect(FACTUR_X_PROFILES.EXTENDED).toContain("urn:factur-x.eu:1p0:extended");
  });

  it("expose les codes type document", () => {
    expect(INVOICE_TYPE_CODES.COMMERCIAL).toBe("380");
    expect(INVOICE_TYPE_CODES.CREDIT_NOTE).toBe("381");
    expect(INVOICE_TYPE_CODES.CORRECTIVE).toBe("384");
    expect(INVOICE_TYPE_CODES.TAX_INVOICE).toBe("388");
  });

  it("expose les codes moyen de paiement (UNTDID 4461 — sous-ensemble)", () => {
    expect(PAYMENT_MEANS_CODES.CREDIT_TRANSFER).toBe("30");
    expect(PAYMENT_MEANS_CODES.BANK_PAYMENT).toBe("42");
    expect(PAYMENT_MEANS_CODES.STANDING_AGREEMENT).toBe("57");
    expect(PAYMENT_MEANS_CODES.SEPA_DIRECT_DEBIT).toBe("59");
  });

  it("liste les codes d'avoir", () => {
    expect(CREDIT_NOTE_CODES).toContain("381");
    expect(CREDIT_NOTE_CODES).toContain("261");
  });

  it("expose les catégories TVA", () => {
    expect(VAT_CATEGORY_CODES.STANDARD).toBe("S");
    expect(VAT_CATEGORY_CODES.REVERSE_CHARGE).toBe("AE");
  });

  it("expose les schemeIDs", () => {
    expect(SCHEME_IDS.SIREN_SIRET).toBe("0002");
    expect(SCHEME_IDS.VAT).toBe("VA");
    expect(SCHEME_IDS.EMAIL).toBe("EM");
    expect(SCHEME_IDS.LOCAL_TAX_ID).toBe("FC");
  });

  it("fixe le contrat XML embarqué Factur-X", () => {
    expect(FACTUR_X_XML_FILENAME).toBe("factur-x.xml");
    expect(FACTUR_X_XML_MIME_TYPE).toBe("text/xml");
    expect(FACTUR_X_AF_RELATIONSHIP).toBe("Alternative");
    expect(TAX_TYPE_VAT).toBe("VAT");
  });

  it("fixe le contrat XMP `fx:` (terminaison # obligatoire)", () => {
    expect(FX_XMP_NAMESPACE_URI).toBe("urn:factur-x:pdfa:CrossIndustryDocument:invoice:1p0#");
    expect(FX_XMP_NAMESPACE_URI.endsWith("#")).toBe(true);
    expect(FX_XMP_PREFIX).toBe("fx");
    expect(FX_DOCUMENT_TYPE).toBe("INVOICE");
    expect(FX_VERSION).toBe("1.0");
  });

  it("expose les niveaux de conformance Factur-X (avec espace pour EN 16931)", () => {
    expect(FX_CONFORMANCE_LEVELS.EN16931).toBe("EN 16931");
    expect(FX_CONFORMANCE_LEVELS.EXTENDED).toBe("EXTENDED");
    expect(FX_CONFORMANCE_LEVELS.BASIC_WL).toBe("BASIC WL");
    // Le label XMP `EN 16931` (avec espace) est distinct de l'URN `BT-24` du XML.
    expect(FX_CONFORMANCE_LEVELS.EN16931).not.toBe(FACTUR_X_PROFILES.EN16931);
  });

  it("fixe les précisions décimales", () => {
    expect(DECIMALS_AMOUNT).toBe(2);
    expect(DECIMALS_QUANTITY).toBe(4);
  });
});
