import { describe, expect, it } from "vitest";
import { VATBreakdownSchema, VAT_CATEGORY_CODES } from "../src/index.js";

describe("VATBreakdownSchema (BG-23)", () => {
  it("parse une TVA standard 20%", () => {
    const parsed = VATBreakdownSchema.parse({
      taxBasisAmount: 100,
      calculatedAmount: 20,
      categoryCode: VAT_CATEGORY_CODES.STANDARD,
      ratePercent: 20,
    });
    expect(parsed.categoryCode).toBe("S");
  });

  it("parse une exonération avec motif (catégorie E)", () => {
    const parsed = VATBreakdownSchema.parse({
      taxBasisAmount: 100,
      calculatedAmount: 0,
      categoryCode: VAT_CATEGORY_CODES.EXEMPT,
      exemptionReason: "Article 261 CGI",
    });
    expect(parsed.exemptionReason).toBe("Article 261 CGI");
  });

  it("rejette un categoryCode vide", () => {
    expect(() =>
      VATBreakdownSchema.parse({
        taxBasisAmount: 0,
        calculatedAmount: 0,
        categoryCode: "",
      }),
    ).toThrow();
  });
});
