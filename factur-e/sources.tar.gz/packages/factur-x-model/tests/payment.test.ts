import { describe, expect, it } from "vitest";
import {
  FinancialAccountDetailsSchema,
  FinancialAccountSchema,
  PAYMENT_MEANS_CODES,
  PaymentCardSchema,
  PaymentMeansSchema,
} from "../src/index.js";

describe("FinancialAccountSchema", () => {
  it("exige accountID", () => {
    expect(() => FinancialAccountSchema.parse({})).toThrow();
  });

  it("accepte un IBAN", () => {
    const parsed = FinancialAccountSchema.parse({
      accountID: { value: "FR7630006000011234567890189", schemeID: "IBAN" },
    });
    expect(parsed.accountID.schemeID).toBe("IBAN");
  });
});

describe("FinancialAccountDetailsSchema (BG-17)", () => {
  it("accepte juste accountID", () => {
    const parsed = FinancialAccountDetailsSchema.parse({
      accountID: { value: "FR7630006000011234567890189" },
    });
    expect(parsed.accountID.value).toMatch(/^FR/);
  });

  it("accepte accountName + financialInstitutionID (BIC)", () => {
    const parsed = FinancialAccountDetailsSchema.parse({
      accountID: { value: "FR7630006000011234567890189", schemeID: "IBAN" },
      accountName: "Audit Pro SAS",
      financialInstitutionID: { value: "AGRIFRPP", schemeID: "BIC" },
    });
    expect(parsed.financialInstitutionID?.value).toBe("AGRIFRPP");
  });
});

describe("PaymentCardSchema (BG-18)", () => {
  it("exige primaryAccountNumber non vide (BT-87 — BR-51 vérifié dans validateInvoice)", () => {
    expect(() => PaymentCardSchema.parse({ primaryAccountNumber: "" })).toThrow();
  });

  it("accepte les 4 derniers chiffres", () => {
    expect(PaymentCardSchema.parse({ primaryAccountNumber: "4567" })).toMatchObject({
      primaryAccountNumber: "4567",
    });
  });
});

describe("PaymentMeansSchema (BG-16)", () => {
  it("accepte un virement minimal", () => {
    const parsed = PaymentMeansSchema.parse({
      typeCode: PAYMENT_MEANS_CODES.CREDIT_TRANSFER,
    });
    expect(parsed.typeCode).toBe("30");
  });

  it("accepte tout : SEPA + IBAN + BIC + carte + mandate", () => {
    const parsed = PaymentMeansSchema.parse({
      typeCode: PAYMENT_MEANS_CODES.SEPA_DIRECT_DEBIT,
      information: "Prélèvement SEPA",
      directDebitMandateID: { value: "MANDATE-2026-001" },
      payerFinancialAccount: {
        accountID: { value: "FR7630003000011234567890189", schemeID: "IBAN" },
      },
      payeeFinancialAccounts: [
        {
          accountID: {
            value: "FR7630006000011234567890189",
            schemeID: "IBAN",
          },
        },
      ],
      paymentCard: { primaryAccountNumber: "1234" },
    });
    expect(parsed.directDebitMandateID?.value).toBe("MANDATE-2026-001");
    expect(parsed.payeeFinancialAccounts).toHaveLength(1);
  });
});
