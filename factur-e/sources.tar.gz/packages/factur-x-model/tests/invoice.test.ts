import { describe, expect, it } from "vitest";
import { CrossIndustryInvoiceSchema } from "../src/index.js";
import { creditNote } from "./fixtures/credit-note.js";
import { extendedInvoice } from "./fixtures/extended-invoice.js";
import { minimalInvoice } from "./fixtures/minimal-invoice.js";

describe("CrossIndustryInvoiceSchema — fixtures", () => {
  it("parse la fixture minimale", () => {
    const parsed = CrossIndustryInvoiceSchema.parse(minimalInvoice);
    expect(parsed.exchangedDocument.invoiceNumber).toBe("FA-2026-001");
    expect(parsed.tradeTransaction.lineItems).toHaveLength(1);
  });

  it("parse la fixture EXTENDED (couverture BT/BG large)", () => {
    const parsed = CrossIndustryInvoiceSchema.parse(extendedInvoice);
    expect(parsed.tradeTransaction.tradeAgreement.sellerTradeParty.tradingName).toBe("AuditPro");
    expect(
      parsed.tradeTransaction.tradeAgreement.sellerTradeParty.taxRegistrationLocalID?.schemeID,
    ).toBe("FC");
    expect(parsed.tradeTransaction.tradeSettlement.creditorReferenceID?.value).toBe(
      "FR76ZZZ123456",
    );
  });

  it("parse un avoir (BT-3 = 381) avec BG-3 référence", () => {
    const parsed = CrossIndustryInvoiceSchema.parse(creditNote);
    expect(parsed.exchangedDocument.invoiceTypeCode).toBe("381");
    expect(parsed.tradeTransaction.tradeSettlement.precedingInvoices).toHaveLength(1);
  });
});

// ============================================================================
// T-CL-03 — edge cases plan.md (rectificative 384, B2BInt 0227, TVA exonérée).
// ============================================================================

import { validateInvoice } from "../src/index.js";

describe("CrossIndustryInvoiceSchema — edge case rectificative (BT-3 = 384)", () => {
  it("parse une facture rectificative", () => {
    const inv = structuredClone(minimalInvoice);
    inv.exchangedDocument.invoiceTypeCode = "384";
    // Une rectificative référence aussi la facture précédente.
    inv.tradeTransaction.tradeSettlement.precedingInvoices = [
      { invoiceNumber: "FA-2026-001", issueDate: { value: "20260415", format: "102" } },
    ];
    const parsed = CrossIndustryInvoiceSchema.parse(inv);
    expect(parsed.exchangedDocument.invoiceTypeCode).toBe("384");
    // Note : BR-55 ne déclenche que pour 381/261 (avoirs), pas 384 (rectificative).
    const result = validateInvoice(parsed);
    expect(result.ok).toBe(true);
  });
});

describe("CrossIndustryInvoiceSchema — edge case B2BInt qualifiant 0227", () => {
  it("parse un identifiant transaction fournisseur (schemeID=0227)", () => {
    const inv = structuredClone(minimalInvoice);
    // 0227 = Peppol Supplier Transaction Identifier. Utilisé sur identifier
    // d'une référence transaction dans BG-24 ou ailleurs.
    inv.tradeTransaction.tradeAgreement.additionalReferencedDocuments = [
      {
        documentID: "TX-2026-0227-XYZ",
        typeCode: "916",
        referenceTypeCode: "0227", // qualifiant Peppol
        description: "Référence transaction fournisseur (Peppol 0227)",
      },
    ];
    const parsed = CrossIndustryInvoiceSchema.parse(inv);
    expect(
      parsed.tradeTransaction.tradeAgreement.additionalReferencedDocuments?.[0]?.referenceTypeCode,
    ).toBe("0227");
  });
});

describe("CrossIndustryInvoiceSchema — TVA exonérée (catégorie E)", () => {
  it("parse + valide une facture exonérée avec exemptionReason", () => {
    const inv = structuredClone(minimalInvoice);
    // Pose la catégorie E partout : breakdown + ligne.
    inv.tradeTransaction.tradeSettlement.vatBreakdowns = [
      {
        taxBasisAmount: 100,
        calculatedAmount: 0,
        categoryCode: "E",
        ratePercent: 0,
        exemptionReason: "Article 261 CGI — exonération TVA",
      },
    ];
    inv.tradeTransaction.tradeSettlement.monetarySummation.vatTotalAmount = {
      value: 0,
      currencyID: "EUR",
    };
    inv.tradeTransaction.tradeSettlement.monetarySummation.grandTotalAmount = 100;
    inv.tradeTransaction.tradeSettlement.monetarySummation.duePayableAmount = 100;
    const line = inv.tradeTransaction.lineItems[0];
    if (line === undefined) throw new Error("missing line");
    line.tradeSettlement.vatInformation = {
      categoryCode: "E",
      ratePercent: 0,
    };
    const parsed = CrossIndustryInvoiceSchema.parse(inv);
    const result = validateInvoice(parsed);
    if (!result.ok) {
      throw new Error(`Expected ok: ${JSON.stringify(result.errors.map((e) => e.code))}`);
    }
  });
});

describe("CrossIndustryInvoiceSchema — multi-VAT breakdown (S + E)", () => {
  it("parse + valide une facture avec deux taux", () => {
    const inv = structuredClone(minimalInvoice);
    // Ajoute une ligne exonérée à la fixture.
    inv.tradeTransaction.lineItems.push({
      lineID: "2",
      product: { name: "Service exonéré" },
      tradeAgreement: { netPrice: 50 },
      tradeDelivery: { billedQuantity: 1, unitCode: "C62" },
      tradeSettlement: {
        vatInformation: { categoryCode: "E", ratePercent: 0 },
        netLineAmount: 50,
      },
    });
    // Ajoute le breakdown E.
    inv.tradeTransaction.tradeSettlement.vatBreakdowns.push({
      taxBasisAmount: 50,
      calculatedAmount: 0,
      categoryCode: "E",
      ratePercent: 0,
      exemptionReason: "Article 261 CGI",
    });
    // Ajuste les totaux : 100 + 50 = 150 net, 20 TVA, 170 total.
    inv.tradeTransaction.tradeSettlement.monetarySummation.lineTotalAmount = 150;
    inv.tradeTransaction.tradeSettlement.monetarySummation.taxBasisTotalAmount = 150;
    inv.tradeTransaction.tradeSettlement.monetarySummation.grandTotalAmount = 170;
    inv.tradeTransaction.tradeSettlement.monetarySummation.duePayableAmount = 170;
    const parsed = CrossIndustryInvoiceSchema.parse(inv);
    const result = validateInvoice(parsed);
    if (!result.ok) {
      throw new Error(
        `Expected ok: ${JSON.stringify(result.errors.map((e) => `${e.code}@${e.path}`))}`,
      );
    }
  });
});

describe("BG-22 totaux — couverture détaillée", () => {
  it("accepte un montant payé partiel", () => {
    const inv = structuredClone(minimalInvoice);
    inv.tradeTransaction.tradeSettlement.monetarySummation.paidAmount = 30;
    inv.tradeTransaction.tradeSettlement.monetarySummation.duePayableAmount = 90;
    expect(validateInvoice(inv).ok).toBe(true);
  });

  it("accepte un roundingAmount", () => {
    const inv = structuredClone(minimalInvoice);
    inv.tradeTransaction.tradeSettlement.monetarySummation.roundingAmount = 0.05;
    inv.tradeTransaction.tradeSettlement.monetarySummation.grandTotalAmount = 120.05;
    inv.tradeTransaction.tradeSettlement.monetarySummation.duePayableAmount = 120;
    expect(validateInvoice(inv).ok).toBe(true);
  });
});

describe("BG-25 lignes — couverture détaillée", () => {
  it("accepte une ligne avec attributs produit (BG-32)", () => {
    const inv = structuredClone(minimalInvoice);
    const line = inv.tradeTransaction.lineItems[0];
    if (line === undefined) throw new Error("missing line");
    line.product = {
      name: "Service",
      itemAttributes: [
        { attributeName: "Catégorie", attributeValue: "Conseil" },
        { attributeName: "Durée", attributeValue: "2h" },
      ],
    };
    expect(validateInvoice(inv).ok).toBe(true);
  });

  it("accepte une ligne avec période de facturation (BG-26)", () => {
    const inv = structuredClone(minimalInvoice);
    const line = inv.tradeTransaction.lineItems[0];
    if (line === undefined) throw new Error("missing line");
    line.tradeSettlement.lineBillingPeriod = {
      startDate: { value: "20260101", format: "102" },
      endDate: { value: "20260131", format: "102" },
    };
    expect(validateInvoice(inv).ok).toBe(true);
  });
});

describe("Dates BT-2/BT-72/BT-73 — couverture", () => {
  it("BT-2 issueDate accepte yyyyMMdd valide", () => {
    const inv = structuredClone(minimalInvoice);
    inv.exchangedDocument.issueDate = { value: "20260415", format: "102" };
    expect(validateInvoice(inv).ok).toBe(true);
  });

  it("BT-72 actualDeliveryDate accepte (sans déclencher BR-57)", () => {
    const inv = structuredClone(minimalInvoice);
    inv.tradeTransaction.tradeDelivery = {
      actualDeliveryDate: { value: "20260415", format: "102" },
    };
    expect(validateInvoice(inv).ok).toBe(true);
  });

  it("BT-73/74 BillingPeriod (BG-14) accepte les deux dates", () => {
    const inv = structuredClone(minimalInvoice);
    inv.tradeTransaction.tradeSettlement.billingPeriod = {
      startDate: { value: "20260101", format: "102" },
      endDate: { value: "20260131", format: "102" },
    };
    expect(validateInvoice(inv).ok).toBe(true);
  });
});
