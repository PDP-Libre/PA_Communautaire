import { describe, expect, it } from "vitest";
import {
  ADDITIONAL_DOC_TYPE_CODES,
  AdditionalReferenceDocumentSchema,
  AttachedBinaryObjectSchema,
  PrecedingInvoiceReferenceSchema,
} from "../src/index.js";

describe("PrecedingInvoiceReferenceSchema (BG-3)", () => {
  it("parse un numéro seul", () => {
    expect(PrecedingInvoiceReferenceSchema.parse({ invoiceNumber: "FA-2026-001" })).toEqual({
      invoiceNumber: "FA-2026-001",
    });
  });

  it("parse un numéro + date", () => {
    const parsed = PrecedingInvoiceReferenceSchema.parse({
      invoiceNumber: "FA-2026-001",
      issueDate: { value: "20260415", format: "102" },
    });
    expect(parsed.issueDate?.value).toBe("20260415");
  });
});

describe("AttachedBinaryObjectSchema (BT-125)", () => {
  it("exige Uint8Array pour content", () => {
    const obj = AttachedBinaryObjectSchema.parse({
      mimeCode: "application/pdf",
      filename: "devis.pdf",
      content: new Uint8Array([1, 2, 3]),
    });
    expect(obj.content).toBeInstanceOf(Uint8Array);
  });

  it("rejette un content string", () => {
    expect(() =>
      AttachedBinaryObjectSchema.parse({
        mimeCode: "application/pdf",
        filename: "x.pdf",
        content: "abcdef",
      }),
    ).toThrow();
  });
});

describe("AdditionalReferenceDocumentSchema (BG-24)", () => {
  it("parse un document justificatif (typeCode 916)", () => {
    const parsed = AdditionalReferenceDocumentSchema.parse({
      documentID: "DEVIS-001",
      typeCode: ADDITIONAL_DOC_TYPE_CODES.SUPPORTING,
      description: "Devis signé",
    });
    expect(parsed.typeCode).toBe("916");
  });

  it("accepte un PDF attaché", () => {
    const parsed = AdditionalReferenceDocumentSchema.parse({
      documentID: "DEVIS-001",
      typeCode: ADDITIONAL_DOC_TYPE_CODES.SUPPORTING,
      attachedDocument: {
        mimeCode: "application/pdf",
        filename: "devis.pdf",
        content: new Uint8Array([0x25, 0x50, 0x44, 0x46]),
      },
    });
    expect(parsed.attachedDocument?.filename).toBe("devis.pdf");
  });
});
