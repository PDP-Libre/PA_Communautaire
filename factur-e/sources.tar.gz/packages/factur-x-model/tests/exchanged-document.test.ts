import { describe, expect, it } from "vitest";
import {
  DocumentNoteSchema,
  ExchangedDocumentContextSchema,
  ExchangedDocumentSchema,
  FACTUR_X_PROFILES,
  INVOICE_TYPE_CODES,
} from "../src/index.js";

describe("DocumentNoteSchema (BG-1)", () => {
  it("accepte une note minimale", () => {
    expect(DocumentNoteSchema.parse({ content: "Note libre" })).toEqual({
      content: "Note libre",
    });
  });

  it("accepte un subjectCode (BT-21)", () => {
    expect(
      DocumentNoteSchema.parse({ content: "TVA acquittée", subjectCode: "TXD" }),
    ).toMatchObject({ subjectCode: "TXD" });
  });
});

describe("ExchangedDocumentContextSchema (BG-2)", () => {
  it("parse un context EXTENDED", () => {
    const parsed = ExchangedDocumentContextSchema.parse({
      specificationID: { value: FACTUR_X_PROFILES.EXTENDED },
    });
    expect(parsed.specificationID.value).toBe(FACTUR_X_PROFILES.EXTENDED);
  });

  it("accepte businessProcessID", () => {
    const parsed = ExchangedDocumentContextSchema.parse({
      businessProcessID: "A1",
      specificationID: { value: FACTUR_X_PROFILES.EN16931 },
    });
    expect(parsed.businessProcessID).toBe("A1");
  });

  it("rejette un specificationID sans value", () => {
    expect(() =>
      ExchangedDocumentContextSchema.parse({
        specificationID: { value: "" },
      }),
    ).toThrow();
  });
});

describe("ExchangedDocumentSchema", () => {
  it("parse un document commercial", () => {
    const parsed = ExchangedDocumentSchema.parse({
      invoiceNumber: "FA-001",
      invoiceTypeCode: INVOICE_TYPE_CODES.COMMERCIAL,
      issueDate: { value: "20260415", format: "102" },
    });
    expect(parsed.invoiceNumber).toBe("FA-001");
    expect(parsed.invoiceTypeCode).toBe("380");
  });

  it("rejette un invoiceNumber vide (BR-2 — pré-vérification structurelle)", () => {
    expect(() =>
      ExchangedDocumentSchema.parse({
        invoiceNumber: "",
        invoiceTypeCode: "380",
        issueDate: { value: "20260415", format: "102" },
      }),
    ).toThrow();
  });
});
