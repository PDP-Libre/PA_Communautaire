import { describe, expect, it } from "vitest";
import { MonetarySummationSchema } from "../src/index.js";

describe("MonetarySummationSchema (BG-22)", () => {
  it("exige les 5 montants obligatoires", () => {
    expect(() => MonetarySummationSchema.parse({})).toThrow();
  });

  it("parse une totalisation minimale", () => {
    const parsed = MonetarySummationSchema.parse({
      lineTotalAmount: 100,
      taxBasisTotalAmount: 100,
      grandTotalAmount: 120,
      duePayableAmount: 120,
    });
    expect(parsed.grandTotalAmount).toBe(120);
  });

  it("accepte vatTotalAmount avec currencyID (BR-DEC-13)", () => {
    const parsed = MonetarySummationSchema.parse({
      lineTotalAmount: 100,
      taxBasisTotalAmount: 100,
      vatTotalAmount: { value: 20, currencyID: "EUR" },
      grandTotalAmount: 120,
      duePayableAmount: 120,
    });
    expect(parsed.vatTotalAmount?.currencyID).toBe("EUR");
  });

  it("accepte taxCurrencyVATTotalAmount (BT-111, devise de comptabilisation)", () => {
    const parsed = MonetarySummationSchema.parse({
      lineTotalAmount: 100,
      taxBasisTotalAmount: 100,
      vatTotalAmount: { value: 20, currencyID: "USD" },
      taxCurrencyVATTotalAmount: { value: 18.5, currencyID: "EUR" },
      grandTotalAmount: 120,
      duePayableAmount: 120,
    });
    expect(parsed.taxCurrencyVATTotalAmount?.value).toBe(18.5);
  });

  it("accepte allowance/charge/rounding/paid", () => {
    const parsed = MonetarySummationSchema.parse({
      lineTotalAmount: 1000,
      chargeTotalAmount: 50,
      allowanceTotalAmount: 200,
      taxBasisTotalAmount: 850,
      vatTotalAmount: { value: 170, currencyID: "EUR" },
      roundingAmount: 0.05,
      grandTotalAmount: 1020.05,
      paidAmount: 100,
      duePayableAmount: 920.05,
    });
    expect(parsed.allowanceTotalAmount).toBe(200);
    expect(parsed.paidAmount).toBe(100);
  });
});
