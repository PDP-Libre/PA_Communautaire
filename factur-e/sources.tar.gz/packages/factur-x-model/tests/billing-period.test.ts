import { describe, expect, it } from "vitest";
import { BillingPeriodSchema, LineBillingPeriodSchema } from "../src/index.js";

describe("BillingPeriodSchema (BG-14)", () => {
  it("accepte un objet vide (BR-CO-20 délégué à validateInvoice)", () => {
    expect(BillingPeriodSchema.parse({})).toEqual({});
  });

  it("accepte une période complète", () => {
    const parsed = BillingPeriodSchema.parse({
      startDate: { value: "20260101", format: "102" },
      endDate: { value: "20260131", format: "102" },
    });
    expect(parsed.endDate?.value).toBe("20260131");
  });
});

describe("LineBillingPeriodSchema (BG-26)", () => {
  it("accepte une seule date", () => {
    const parsed = LineBillingPeriodSchema.parse({
      startDate: { value: "20260101", format: "102" },
    });
    expect(parsed.endDate).toBeUndefined();
  });
});
