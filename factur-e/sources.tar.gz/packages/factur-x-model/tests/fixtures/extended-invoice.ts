// Fixture EXTENDED — couvre la majorité des BG/BT du profil :
//   BG-1 (notes), BG-3 (avoir/référence), BG-4/5/6/7/8/9/10/11/12 (parties),
//   BG-13/15 (livraison), BG-14/26 (périodes), BG-16/17/18 (paiement),
//   BG-20/21/27/28 (allowances/charges), BG-22/23 (totaux/TVA),
//   BG-24 (docs additionnels), BG-25/29/30/31/32 (lignes).
//
// Toutes les BR-* couvertes par validateInvoice doivent passer sur cette fixture.

import type { CrossIndustryInvoice } from "../../src/index.js";
import {
  ADDITIONAL_DOC_TYPE_CODES,
  FACTUR_X_PROFILES,
  INVOICE_TYPE_CODES,
  NOTE_SUBJECT_CODES,
  PAYMENT_MEANS_CODES,
  SCHEME_IDS,
  UNIT_CODES,
  VAT_CATEGORY_CODES,
} from "../../src/index.js";

export const extendedInvoice: CrossIndustryInvoice = {
  documentContext: {
    businessProcessID: "A1",
    specificationID: { value: FACTUR_X_PROFILES.EXTENDED },
  },
  exchangedDocument: {
    invoiceNumber: "FA-2026-EXT-042",
    invoiceTypeCode: INVOICE_TYPE_CODES.COMMERCIAL,
    issueDate: { value: "20260417", format: "102" },
    includedNotes: [
      {
        content: "TVA acquittée sur les débits.",
        subjectCode: NOTE_SUBJECT_CODES.TAX_INFO,
      },
      { content: "Paiement net sans escompte." },
    ],
  },
  tradeTransaction: {
    lineItems: [
      {
        lineID: "1",
        note: "Prestation forfaitaire mensuelle.",
        product: {
          name: "Audit conformité — forfait mensuel",
          description: "Revue mensuelle des dépôts et statuts.",
          standardID: { value: "0123456789012", schemeID: "0160" },
          sellerAssignedID: { value: "AUDIT-MM" },
          itemAttributes: [
            { attributeName: "Catégorie", attributeValue: "Service" },
            { attributeName: "Durée", attributeValue: "1 mois" },
          ],
          countryOfOriginCode: "FR",
        },
        tradeAgreement: {
          netPrice: 1500,
          grossPrice: 1800,
          basisQuantity: 1,
          basisQuantityUnitCode: UNIT_CODES.MONTH,
          priceDiscount: 300,
          buyerOrderLineReference: "BC-2026-009-1",
        },
        tradeDelivery: {
          billedQuantity: 6,
          unitCode: UNIT_CODES.MONTH,
        },
        tradeSettlement: {
          vatInformation: {
            categoryCode: VAT_CATEGORY_CODES.STANDARD,
            ratePercent: 20,
          },
          netLineAmount: 9000,
          lineAllowances: [
            {
              isCharge: false,
              actualAmount: 200,
              calculationPercent: 2,
              basisAmount: 9200,
              reason: "Remise commerciale",
            },
          ],
          lineCharges: [
            {
              isCharge: true,
              actualAmount: 50,
              reason: "Frais de dossier",
            },
          ],
          lineBillingPeriod: {
            startDate: { value: "20260101", format: "102" },
            endDate: { value: "20260630", format: "102" },
          },
        },
      },
      {
        lineID: "2",
        product: { name: "Frais d'expertise comptable" },
        tradeAgreement: { netPrice: 500 },
        tradeDelivery: { billedQuantity: 1, unitCode: UNIT_CODES.PIECE },
        tradeSettlement: {
          vatInformation: {
            categoryCode: VAT_CATEGORY_CODES.STANDARD,
            ratePercent: 20,
          },
          netLineAmount: 500,
        },
      },
    ],
    tradeAgreement: {
      sellerTradeParty: {
        name: "Audit Pro SAS",
        tradingName: "AuditPro",
        postalAddress: {
          countryCode: "FR",
          postalCode: "69002",
          cityName: "Lyon",
          lineOne: "10 quai Saint-Antoine",
          countrySubDivisionName: "Auvergne-Rhône-Alpes",
        },
        legalRegistrationID: {
          value: "552120222",
          schemeID: SCHEME_IDS.SIREN_SIRET,
        },
        vatID: { value: "FR40552120222", schemeID: SCHEME_IDS.VAT },
        taxRegistrationLocalID: {
          value: "552120222",
          schemeID: SCHEME_IDS.LOCAL_TAX_ID,
        },
        globalID: { value: "3033333000010", schemeID: SCHEME_IDS.GLN },
        electronicAddress: {
          value: "facturation@auditpro.fr",
          schemeID: SCHEME_IDS.EMAIL,
        },
        definedContacts: [
          {
            personName: "Sophie Martin",
            telephoneNumber: "+33478000000",
            emailAddress: "sophie.martin@auditpro.fr",
          },
        ],
      },
      buyerTradeParty: {
        name: "Boulangerie du Centre SARL",
        postalAddress: {
          countryCode: "FR",
          postalCode: "13001",
          cityName: "Marseille",
          lineOne: "5 cours Belsunce",
        },
        legalRegistrationID: {
          value: "789456123",
          schemeID: SCHEME_IDS.SIREN_SIRET,
        },
        vatID: { value: "FR67789456123", schemeID: SCHEME_IDS.VAT },
        electronicAddress: {
          value: "compta@boulangeriecentre.fr",
          schemeID: SCHEME_IDS.EMAIL,
        },
      },
      sellerTaxRepresentative: {
        name: "Cabinet Fiscal France",
        vatID: { value: "FR99888777666", schemeID: SCHEME_IDS.VAT },
        postalAddress: {
          countryCode: "FR",
          cityName: "Paris",
          postalCode: "75008",
          lineOne: "12 rue La Boétie",
        },
      },
      buyerReference: "REF-CLIENT-AUDIT",
      buyerOrderReference: "BC-2026-009",
      contractReference: "CONTRAT-AUDIT-2026",
      sellerOrderReference: "DV-2026-009",
      additionalReferencedDocuments: [
        {
          documentID: "DEVIS-2026-009",
          typeCode: ADDITIONAL_DOC_TYPE_CODES.SUPPORTING,
          description: "Devis signé du 15/12/2025",
        },
      ],
    },
    tradeDelivery: {
      shipToPartyName: "Boulangerie du Centre",
      shipToPartyID: { value: "ETAB-PRINCIPAL" },
      deliveryAddress: {
        countryCode: "FR",
        postalCode: "13001",
        cityName: "Marseille",
        lineOne: "5 cours Belsunce",
      },
      actualDeliveryDate: { value: "20260417", format: "102" },
    },
    tradeSettlement: {
      invoiceCurrencyCode: "EUR",
      creditorReferenceID: { value: "FR76ZZZ123456" },
      paymentReference: "FA-2026-EXT-042",
      vatBreakdowns: [
        {
          taxBasisAmount: 9450,
          calculatedAmount: 1890,
          categoryCode: VAT_CATEGORY_CODES.STANDARD,
          ratePercent: 20,
        },
      ],
      monetarySummation: {
        // 9500 lineTotal - 100 allowance + 50 charge = 9450 base. 20% = 1890 TVA. Grand = 11340.
        lineTotalAmount: 9500,
        chargeTotalAmount: 50,
        allowanceTotalAmount: 100,
        taxBasisTotalAmount: 9450,
        vatTotalAmount: { value: 1890, currencyID: "EUR" },
        grandTotalAmount: 11340,
        duePayableAmount: 11340,
      },
      paymentTermsDescription: "Paiement à 30 jours fin de mois.",
      dueDate: { value: "20260531", format: "102" },
      paymentMeans: [
        {
          typeCode: PAYMENT_MEANS_CODES.CREDIT_TRANSFER,
          information: "Virement IBAN",
          payeeFinancialAccounts: [
            {
              accountID: {
                value: "FR7630006000011234567890189",
                schemeID: "IBAN",
              },
              accountName: "Audit Pro SAS",
              financialInstitutionID: {
                value: "AGRIFRPP",
                schemeID: "BIC",
              },
            },
          ],
        },
      ],
      payeeParty: {
        name: "Audit Pro Recouvrement",
        postalAddress: { countryCode: "FR" },
        legalRegistrationID: {
          value: "552120222",
          schemeID: SCHEME_IDS.SIREN_SIRET,
        },
      },
      documentAllowances: [
        {
          isCharge: false,
          actualAmount: 100,
          taxCategoryCode: VAT_CATEGORY_CODES.STANDARD,
          taxPercent: 20,
          reason: "Remise fidélité",
        },
      ],
      documentCharges: [
        {
          isCharge: true,
          actualAmount: 50,
          taxCategoryCode: VAT_CATEGORY_CODES.STANDARD,
          taxPercent: 20,
          reason: "Frais d'envoi recommandé",
        },
      ],
      billingPeriod: {
        startDate: { value: "20260101", format: "102" },
        endDate: { value: "20260630", format: "102" },
      },
    },
  },
};
