// Avoir (BT-3 = "381") — déclenche BR-55 : `precedingInvoices` obligatoire.

import type { CrossIndustryInvoice } from "../../src/index.js";
import {
  FACTUR_X_PROFILES,
  INVOICE_TYPE_CODES,
  SCHEME_IDS,
  UNIT_CODES,
  VAT_CATEGORY_CODES,
} from "../../src/index.js";

export const creditNote: CrossIndustryInvoice = {
  documentContext: {
    specificationID: { value: FACTUR_X_PROFILES.EXTENDED },
  },
  exchangedDocument: {
    invoiceNumber: "AV-2026-007",
    invoiceTypeCode: INVOICE_TYPE_CODES.CREDIT_NOTE,
    issueDate: { value: "20260420", format: "102" },
  },
  tradeTransaction: {
    lineItems: [
      {
        lineID: "1",
        product: { name: "Avoir prestation conseil" },
        tradeAgreement: { netPrice: 100 },
        tradeDelivery: { billedQuantity: 1, unitCode: UNIT_CODES.PIECE },
        tradeSettlement: {
          vatInformation: {
            categoryCode: VAT_CATEGORY_CODES.STANDARD,
            ratePercent: 20,
          },
          netLineAmount: 100,
        },
      },
    ],
    tradeAgreement: {
      sellerTradeParty: {
        name: "Mon Entreprise SAS",
        postalAddress: { countryCode: "FR" },
        vatID: { value: "FR12123456789", schemeID: SCHEME_IDS.VAT },
      },
      buyerTradeParty: {
        name: "Client SARL",
        postalAddress: { countryCode: "FR" },
      },
    },
    tradeDelivery: {},
    tradeSettlement: {
      invoiceCurrencyCode: "EUR",
      vatBreakdowns: [
        {
          taxBasisAmount: 100,
          calculatedAmount: 20,
          categoryCode: VAT_CATEGORY_CODES.STANDARD,
          ratePercent: 20,
        },
      ],
      monetarySummation: {
        lineTotalAmount: 100,
        taxBasisTotalAmount: 100,
        vatTotalAmount: { value: 20, currencyID: "EUR" },
        grandTotalAmount: 120,
        duePayableAmount: 120,
      },
      paymentTermsDescription: "Avoir compensé sur prochaine facture.",
      precedingInvoices: [
        {
          invoiceNumber: "FA-2026-001",
          issueDate: { value: "20260415", format: "102" },
        },
      ],
    },
  },
};
