// Suite de validation BR-* — couvre toutes les règles implémentées dans
// src/validation/br-rules.ts. Pattern : cloner une fixture passante et muter
// le champ déclencheur, vérifier que l'erreur attendue remonte.

import { describe, expect, it } from "vitest";
import {
  FACTUR_X_PROFILES,
  INVOICE_TYPE_CODES,
  PAYMENT_MEANS_CODES,
  VAT_CATEGORY_CODES,
  validateInvoice,
} from "../src/index.js";
import type { CrossIndustryInvoice } from "../src/index.js";
import { creditNote } from "./fixtures/credit-note.js";
import { extendedInvoice } from "./fixtures/extended-invoice.js";
import { minimalInvoice } from "./fixtures/minimal-invoice.js";

function clone<T>(value: T): T {
  return structuredClone(value);
}

function expectErrorCode(invoice: CrossIndustryInvoice, code: string): void {
  const result = validateInvoice(invoice);
  if (result.ok) {
    throw new Error(`Expected validation error ${code}, got ok`);
  }
  const codes = result.errors.map((e) => e.code);
  expect(codes).toContain(code);
}

describe("validateInvoice — happy paths", () => {
  it("accepte la fixture minimale", () => {
    const result = validateInvoice(minimalInvoice);
    expect(result.ok).toBe(true);
  });

  it("accepte la fixture EXTENDED", () => {
    const result = validateInvoice(extendedInvoice);
    if (!result.ok) {
      // Fournit un diagnostic clair en cas de régression.
      throw new Error(
        `Extended fixture should pass; got: ${JSON.stringify(result.errors, null, 2)}`,
      );
    }
  });

  it("accepte un avoir avec BG-3 (BR-55 satisfaite)", () => {
    const result = validateInvoice(creditNote);
    expect(result.ok).toBe(true);
  });
});

describe("validateInvoice — BR-1 / BR-2", () => {
  it("BR-1 — profil non reconnu", () => {
    const inv = clone(minimalInvoice);
    inv.documentContext.specificationID.value = "urn:custom:profile";
    expectErrorCode(inv, "BR-1");
  });

  it("BR-2 — invoiceNumber vide après whitespace", () => {
    const inv = clone(minimalInvoice);
    inv.exchangedDocument.invoiceNumber = "   ";
    expectErrorCode(inv, "BR-2");
  });
});

describe("validateInvoice — BR-6 / BR-7 / BR-9 / BR-11", () => {
  it("BR-6 — vendeur sans nom", () => {
    const inv = clone(minimalInvoice);
    inv.tradeTransaction.tradeAgreement.sellerTradeParty.name = "  ";
    expectErrorCode(inv, "BR-6");
  });

  it("BR-7 — acheteur sans nom", () => {
    const inv = clone(minimalInvoice);
    inv.tradeTransaction.tradeAgreement.buyerTradeParty.name = "";
    expectErrorCode(inv, "BR-7");
  });

  it("BR-9 — vendeur sans pays", () => {
    const inv = clone(minimalInvoice);
    inv.tradeTransaction.tradeAgreement.sellerTradeParty.postalAddress.countryCode = "  ";
    expectErrorCode(inv, "BR-9");
  });

  it("BR-11 — acheteur sans pays", () => {
    const inv = clone(minimalInvoice);
    inv.tradeTransaction.tradeAgreement.buyerTradeParty.postalAddress.countryCode = "";
    expectErrorCode(inv, "BR-11");
  });
});

describe("validateInvoice — BR-CO-9 (schemeID VA)", () => {
  it("rejette un vatID dont le schemeID n'est pas VA", () => {
    const inv = clone(minimalInvoice);
    inv.tradeTransaction.tradeAgreement.sellerTradeParty.vatID = {
      value: "FR12",
      schemeID: "FR",
    };
    expectErrorCode(inv, "BR-CO-9");
  });

  it("rejette un sellerTaxRepresentative.vatID avec mauvais schemeID", () => {
    const inv = clone(extendedInvoice);
    if (inv.tradeTransaction.tradeAgreement.sellerTaxRepresentative !== undefined) {
      inv.tradeTransaction.tradeAgreement.sellerTaxRepresentative.vatID.schemeID = "WRONG";
    }
    expectErrorCode(inv, "BR-CO-9");
  });
});

describe("validateInvoice — BR-21 / BR-22 / BR-25", () => {
  it("BR-22 — quantité ≤ 0", () => {
    const inv = clone(minimalInvoice);
    const line = inv.tradeTransaction.lineItems[0];
    if (line === undefined) throw new Error("fixture has no line[0]");
    line.tradeDelivery.billedQuantity = 0;
    expectErrorCode(inv, "BR-22");
  });

  // Note : BR-21 (lineID vide) et BR-25 (product.name vide) sont déjà refusés
  // par les schemas Zod en amont (z.string().min(1)) — ils sont donc impossibles
  // à atteindre via une fixture parsée. validateInvoice les inclut comme
  // ceinture+bretelles si le code amont contourne Zod.
});

describe("validateInvoice — TVA cohérence (BR-S/Z/E)", () => {
  it("BR-S-1 (header) — catégorie S sans taux", () => {
    const inv = clone(minimalInvoice);
    const breakdown = inv.tradeTransaction.tradeSettlement.vatBreakdowns[0];
    if (breakdown === undefined) throw new Error("fixture missing breakdown");
    breakdown.ratePercent = undefined;
    expectErrorCode(inv, "BR-S-1");
  });

  it("BR-Z-1 — catégorie Z avec taux non nul", () => {
    const inv = clone(minimalInvoice);
    inv.tradeTransaction.tradeSettlement.vatBreakdowns = [
      {
        taxBasisAmount: 100,
        calculatedAmount: 0,
        categoryCode: VAT_CATEGORY_CODES.ZERO_RATED,
        ratePercent: 5,
      },
    ];
    expectErrorCode(inv, "BR-Z-1");
  });

  it("BR-E-1 — catégorie E sans motif d'exonération", () => {
    const inv = clone(minimalInvoice);
    inv.tradeTransaction.tradeSettlement.vatBreakdowns = [
      {
        taxBasisAmount: 100,
        calculatedAmount: 0,
        categoryCode: VAT_CATEGORY_CODES.EXEMPT,
      },
    ];
    expectErrorCode(inv, "BR-E-1");
  });

  it("BR-S-1 (ligne) — TVA de ligne S sans taux", () => {
    const inv = clone(minimalInvoice);
    const line = inv.tradeTransaction.lineItems[0];
    if (line === undefined) throw new Error("fixture missing line");
    line.tradeSettlement.vatInformation.ratePercent = undefined;
    expectErrorCode(inv, "BR-S-1");
  });
});

describe("validateInvoice — BR-CO-15 (cohérence totaux)", () => {
  it("rejette un grandTotalAmount incohérent", () => {
    const inv = clone(minimalInvoice);
    inv.tradeTransaction.tradeSettlement.monetarySummation.grandTotalAmount = 999;
    expectErrorCode(inv, "BR-CO-15");
  });

  it("accepte une tolérance ≤ 1 centime", () => {
    const inv = clone(minimalInvoice);
    inv.tradeTransaction.tradeSettlement.monetarySummation.grandTotalAmount = 120 + 0.005;
    const result = validateInvoice(inv);
    expect(result.ok).toBe(true);
  });
});

describe("validateInvoice — BR-CO-25 (échéance vs paiement)", () => {
  it("rejette duePayable > 0 sans dueDate ni paymentTerms", () => {
    const inv = clone(minimalInvoice);
    inv.tradeTransaction.tradeSettlement.dueDate = undefined;
    inv.tradeTransaction.tradeSettlement.paymentTermsDescription = undefined;
    expectErrorCode(inv, "BR-CO-25");
  });

  it("accepte si dueDate présent (sans paymentTerms)", () => {
    const inv = clone(minimalInvoice);
    inv.tradeTransaction.tradeSettlement.paymentTermsDescription = undefined;
    inv.tradeTransaction.tradeSettlement.dueDate = {
      value: "20260601",
      format: "102",
    };
    const result = validateInvoice(inv);
    expect(result.ok).toBe(true);
  });
});

describe("validateInvoice — BR-CO-20 (période de facturation vide)", () => {
  it("rejette une BG-14 sans aucune date", () => {
    const inv = clone(minimalInvoice);
    inv.tradeTransaction.tradeSettlement.billingPeriod = {};
    expectErrorCode(inv, "BR-CO-20");
  });

  it("rejette une BG-26 (ligne) sans aucune date", () => {
    const inv = clone(minimalInvoice);
    const line = inv.tradeTransaction.lineItems[0];
    if (line === undefined) throw new Error("fixture missing line");
    line.tradeSettlement.lineBillingPeriod = {};
    expectErrorCode(inv, "BR-CO-20");
  });
});

describe("validateInvoice — BR-DEC-13 / BR-DEC-14 (currencyID)", () => {
  it("BR-DEC-13 — vatTotalAmount sans currencyID", () => {
    const inv = clone(minimalInvoice);
    if (inv.tradeTransaction.tradeSettlement.monetarySummation.vatTotalAmount !== undefined) {
      inv.tradeTransaction.tradeSettlement.monetarySummation.vatTotalAmount = {
        value: 20,
      };
    }
    expectErrorCode(inv, "BR-DEC-13");
  });

  it("BR-DEC-14 — taxCurrencyVATTotalAmount sans currencyID", () => {
    const inv = clone(minimalInvoice);
    inv.tradeTransaction.tradeSettlement.monetarySummation.taxCurrencyVATTotalAmount = {
      value: 20,
    };
    expectErrorCode(inv, "BR-DEC-14");
  });
});

describe("validateInvoice — BR-42 / BR-43 (allowance/charge reason)", () => {
  it("BR-42 — remise document sans motif", () => {
    const inv = clone(minimalInvoice);
    inv.tradeTransaction.tradeSettlement.documentAllowances = [
      {
        isCharge: false,
        actualAmount: 10,
        taxCategoryCode: VAT_CATEGORY_CODES.STANDARD,
      },
    ];
    expectErrorCode(inv, "BR-42");
  });

  it("BR-43 — charge document sans motif", () => {
    const inv = clone(minimalInvoice);
    inv.tradeTransaction.tradeSettlement.documentCharges = [
      {
        isCharge: true,
        actualAmount: 10,
        taxCategoryCode: VAT_CATEGORY_CODES.STANDARD,
      },
    ];
    expectErrorCode(inv, "BR-43");
  });

  it("BR-42 — remise de ligne sans motif", () => {
    const inv = clone(minimalInvoice);
    const line = inv.tradeTransaction.lineItems[0];
    if (line === undefined) throw new Error("fixture missing line");
    line.tradeSettlement.lineAllowances = [{ isCharge: false, actualAmount: 5 }];
    expectErrorCode(inv, "BR-42");
  });
});

describe("validateInvoice — BR-51 (PaymentCard PAN)", () => {
  it("rejette un PAN > 6 chiffres", () => {
    const inv = clone(minimalInvoice);
    inv.tradeTransaction.tradeSettlement.paymentMeans = [
      {
        typeCode: PAYMENT_MEANS_CODES.CARD,
        paymentCard: { primaryAccountNumber: "1234567890123456" },
      },
    ];
    expectErrorCode(inv, "BR-51");
  });

  it("accepte un PAN à 4 chiffres", () => {
    const inv = clone(minimalInvoice);
    inv.tradeTransaction.tradeSettlement.paymentMeans = [
      {
        typeCode: PAYMENT_MEANS_CODES.CARD,
        paymentCard: { primaryAccountNumber: "4567" },
      },
    ];
    const result = validateInvoice(inv);
    expect(result.ok).toBe(true);
  });
});

describe("validateInvoice — BR-55 (avoir)", () => {
  it("rejette un avoir sans BG-3", () => {
    const inv = clone(minimalInvoice);
    inv.exchangedDocument.invoiceTypeCode = INVOICE_TYPE_CODES.CREDIT_NOTE;
    inv.tradeTransaction.tradeSettlement.precedingInvoices = undefined;
    expectErrorCode(inv, "BR-55");
  });

  it("rejette aussi le code 261 sans BG-3", () => {
    const inv = clone(minimalInvoice);
    inv.exchangedDocument.invoiceTypeCode = INVOICE_TYPE_CODES.CREDIT_NOTE_ALT;
    inv.tradeTransaction.tradeSettlement.precedingInvoices = [];
    expectErrorCode(inv, "BR-55");
  });
});

describe("validateInvoice — BR-57 (BG-15 sans shipToPartyName)", () => {
  it("rejette une adresse de livraison (BG-15) sans BT-70", () => {
    const inv = clone(minimalInvoice);
    inv.tradeTransaction.tradeDelivery = {
      deliveryAddress: { countryCode: "FR", cityName: "Marseille" },
    };
    expectErrorCode(inv, "BR-57");
  });

  it("accepte si shipToPartyName est présent avec l'adresse", () => {
    const inv = clone(minimalInvoice);
    inv.tradeTransaction.tradeDelivery = {
      deliveryAddress: { countryCode: "FR", cityName: "Marseille" },
      shipToPartyName: "Magasin central",
    };
    const result = validateInvoice(inv);
    expect(result.ok).toBe(true);
  });

  it("accepte une date de livraison seule (pas de BG-15 → BR-57 non déclenché)", () => {
    const inv = clone(minimalInvoice);
    inv.tradeTransaction.tradeDelivery = {
      actualDeliveryDate: { value: "20260415", format: "102" },
    };
    const result = validateInvoice(inv);
    expect(result.ok).toBe(true);
  });
});

describe("validateInvoice — collecte exhaustive", () => {
  it("accumule plusieurs erreurs sans fail-fast", () => {
    const inv = clone(minimalInvoice);
    inv.exchangedDocument.invoiceNumber = "";
    inv.tradeTransaction.tradeAgreement.sellerTradeParty.name = "";
    inv.tradeTransaction.tradeSettlement.monetarySummation.grandTotalAmount = 999;
    const result = validateInvoice(inv);
    expect(result.ok).toBe(false);
    if (result.ok) throw new Error("expected errors");
    const codes = new Set(result.errors.map((e) => e.code));
    expect(codes.has("BR-2")).toBe(true);
    expect(codes.has("BR-6")).toBe(true);
    expect(codes.has("BR-CO-15")).toBe(true);
  });
});

describe("validateInvoice — profil EN16931 (compatibilité)", () => {
  it("accepte le profil EN16931 stricto sensu", () => {
    const inv = clone(minimalInvoice);
    inv.documentContext.specificationID.value = FACTUR_X_PROFILES.EN16931;
    expect(validateInvoice(inv).ok).toBe(true);
  });
});

// ============================================================================
// T-CL-03 — règles BR-* additionnelles (audit-migration §4.2).
// ============================================================================

describe("validateInvoice — BR-CO-10 (cohérence allowanceTotal)", () => {
  it("rejette si allowanceTotalAmount ≠ Σ documentAllowances", () => {
    const inv = clone(minimalInvoice);
    inv.tradeTransaction.tradeSettlement.documentAllowances = [
      { isCharge: false, actualAmount: 50, taxCategoryCode: "S", reason: "x" },
      { isCharge: false, actualAmount: 30, taxCategoryCode: "S", reason: "y" },
    ];
    inv.tradeTransaction.tradeSettlement.monetarySummation.allowanceTotalAmount = 100; // attendu 80
    expectErrorCode(inv, "BR-CO-10");
  });

  it("accepte si la somme correspond", () => {
    const inv = clone(minimalInvoice);
    inv.tradeTransaction.tradeSettlement.documentAllowances = [
      { isCharge: false, actualAmount: 10, taxCategoryCode: "S", reason: "x" },
    ];
    inv.tradeTransaction.tradeSettlement.monetarySummation.allowanceTotalAmount = 10;
    // Refaire la cohérence des autres totaux pour ne pas déclencher BR-CO-15.
    inv.tradeTransaction.tradeSettlement.monetarySummation.taxBasisTotalAmount = 90;
    inv.tradeTransaction.tradeSettlement.monetarySummation.vatTotalAmount = {
      value: 18,
      currencyID: "EUR",
    };
    inv.tradeTransaction.tradeSettlement.monetarySummation.grandTotalAmount = 108;
    inv.tradeTransaction.tradeSettlement.monetarySummation.duePayableAmount = 108;
    inv.tradeTransaction.tradeSettlement.vatBreakdowns = [
      { taxBasisAmount: 90, calculatedAmount: 18, categoryCode: "S", ratePercent: 20 },
    ];
    const result = validateInvoice(inv);
    if (!result.ok) {
      throw new Error(`Expected ok, got: ${JSON.stringify(result.errors.map((e) => e.code))}`);
    }
  });
});

describe("validateInvoice — BR-CO-11 (cohérence chargeTotal)", () => {
  it("rejette si chargeTotalAmount ≠ Σ documentCharges", () => {
    const inv = clone(minimalInvoice);
    inv.tradeTransaction.tradeSettlement.documentCharges = [
      { isCharge: true, actualAmount: 20, taxCategoryCode: "S", reason: "frais" },
    ];
    inv.tradeTransaction.tradeSettlement.monetarySummation.chargeTotalAmount = 30;
    expectErrorCode(inv, "BR-CO-11");
  });
});

describe("validateInvoice — BR-CO-13 (cohérence lineTotal)", () => {
  it("rejette si lineTotalAmount ≠ Σ netLineAmount", () => {
    const inv = clone(minimalInvoice);
    inv.tradeTransaction.tradeSettlement.monetarySummation.lineTotalAmount = 999;
    expectErrorCode(inv, "BR-CO-13");
  });
});

describe("validateInvoice — BR-CO-16 (équilibre paiement)", () => {
  it("rejette duePayable ≠ grandTotal − paid − rounding", () => {
    const inv = clone(minimalInvoice);
    inv.tradeTransaction.tradeSettlement.monetarySummation.paidAmount = 50;
    inv.tradeTransaction.tradeSettlement.monetarySummation.duePayableAmount = 999;
    expectErrorCode(inv, "BR-CO-16");
  });

  it("accepte duePayable = grandTotal − paid", () => {
    const inv = clone(minimalInvoice);
    inv.tradeTransaction.tradeSettlement.monetarySummation.paidAmount = 50;
    inv.tradeTransaction.tradeSettlement.monetarySummation.duePayableAmount = 70; // 120 − 50
    expect(validateInvoice(inv).ok).toBe(true);
  });
});

describe("validateInvoice — BR-CO-17 (TVA = base × taux / 100)", () => {
  it("rejette si calculatedAmount ≠ base × taux / 100", () => {
    const inv = clone(minimalInvoice);
    const breakdown = inv.tradeTransaction.tradeSettlement.vatBreakdowns[0];
    if (breakdown === undefined) throw new Error("missing breakdown");
    breakdown.calculatedAmount = 99; // attendu 100 × 20% = 20
    expectErrorCode(inv, "BR-CO-17");
  });
});

describe("validateInvoice — BR-CO-26 (vendeur identifiable)", () => {
  it("rejette un vendeur sans BT-30 ni BT-31 ni BT-32", () => {
    const inv = clone(minimalInvoice);
    inv.tradeTransaction.tradeAgreement.sellerTradeParty.vatID = undefined;
    inv.tradeTransaction.tradeAgreement.sellerTradeParty.legalRegistrationID = undefined;
    inv.tradeTransaction.tradeAgreement.sellerTradeParty.taxRegistrationLocalID = undefined;
    expectErrorCode(inv, "BR-CO-26");
  });

  it("accepte un vendeur avec BT-30 seul (legalRegistrationID)", () => {
    const inv = clone(minimalInvoice);
    inv.tradeTransaction.tradeAgreement.sellerTradeParty.vatID = undefined;
    // legalRegistrationID est déjà présent dans la fixture minimale.
    const result = validateInvoice(inv);
    expect(result.ok).toBe(true);
  });
});

describe("validateInvoice — BR-AE/E/G/IC-03 (cohérence catégorie ↔ vatID)", () => {
  it("BR-AE-03 — autoliquidation sans vatID seller ni buyer", () => {
    const inv = clone(minimalInvoice);
    inv.tradeTransaction.tradeSettlement.vatBreakdowns = [
      {
        taxBasisAmount: 100,
        calculatedAmount: 0,
        categoryCode: "AE",
        ratePercent: 0,
        exemptionReason: "Autoliquidation",
      },
    ];
    inv.tradeTransaction.tradeAgreement.sellerTradeParty.vatID = undefined;
    inv.tradeTransaction.tradeAgreement.buyerTradeParty.vatID = undefined;
    expectErrorCode(inv, "BR-AE-03");
  });

  it("BR-E-03 — exonération E sans vatID ni FC", () => {
    const inv = clone(minimalInvoice);
    inv.tradeTransaction.tradeSettlement.vatBreakdowns = [
      {
        taxBasisAmount: 100,
        calculatedAmount: 0,
        categoryCode: "E",
        ratePercent: 0,
        exemptionReason: "Article 261 CGI",
      },
    ];
    inv.tradeTransaction.tradeAgreement.sellerTradeParty.vatID = undefined;
    inv.tradeTransaction.tradeAgreement.sellerTradeParty.taxRegistrationLocalID = undefined;
    expectErrorCode(inv, "BR-E-03");
  });

  it("BR-G-03 — export G sans vatID ni FC", () => {
    const inv = clone(minimalInvoice);
    inv.tradeTransaction.tradeSettlement.vatBreakdowns = [
      {
        taxBasisAmount: 100,
        calculatedAmount: 0,
        categoryCode: "G",
        ratePercent: 0,
        exemptionReason: "Export hors UE",
      },
    ];
    inv.tradeTransaction.tradeAgreement.sellerTradeParty.vatID = undefined;
    inv.tradeTransaction.tradeAgreement.sellerTradeParty.taxRegistrationLocalID = undefined;
    expectErrorCode(inv, "BR-G-03");
  });

  it("BR-IC-03 — intracom K sans vatID acheteur", () => {
    const inv = clone(minimalInvoice);
    inv.tradeTransaction.tradeSettlement.vatBreakdowns = [
      {
        taxBasisAmount: 100,
        calculatedAmount: 0,
        categoryCode: "K",
        ratePercent: 0,
        exemptionReason: "Livraison intracommunautaire",
      },
    ];
    // Vendeur a vatID dans la fixture, mais pas le buyer.
    expectErrorCode(inv, "BR-IC-03");
  });
});

describe("validateInvoice — BR-DEC-01/02/05/06 (max 2 décimales allowance/charge)", () => {
  it("BR-DEC-01 — actualAmount allowance avec 3 décimales", () => {
    const inv = clone(minimalInvoice);
    inv.tradeTransaction.tradeSettlement.documentAllowances = [
      { isCharge: false, actualAmount: 1.234, taxCategoryCode: "S", reason: "x" },
    ];
    inv.tradeTransaction.tradeSettlement.monetarySummation.allowanceTotalAmount = 1.234;
    expectErrorCode(inv, "BR-DEC-01");
  });

  it("BR-DEC-05 — actualAmount charge avec 3 décimales", () => {
    const inv = clone(minimalInvoice);
    inv.tradeTransaction.tradeSettlement.documentCharges = [
      { isCharge: true, actualAmount: 5.678, taxCategoryCode: "S", reason: "y" },
    ];
    inv.tradeTransaction.tradeSettlement.monetarySummation.chargeTotalAmount = 5.678;
    expectErrorCode(inv, "BR-DEC-05");
  });
});

// ============================================================================
// T-CL-03 — couverture des chemins ceinture+bretelles (bypass Zod) et edge cases.
// ============================================================================
//
// Plusieurs vérifications de validateInvoice doublonnent la validation Zod
// (BR-16, BR-21, BR-25, BR-CO-18). On les teste en passant un objet directement
// (cast `as CrossIndustryInvoice`) — utile pour défense en profondeur si du
// code amont contournait Zod.

describe("validateInvoice — chemins ceinture+bretelles (bypass Zod)", () => {
  it("BR-16 — lineItems vide via bypass Zod", () => {
    const inv = clone(minimalInvoice);
    (inv.tradeTransaction as { lineItems: unknown[] }).lineItems = [];
    expectErrorCode(inv, "BR-16");
  });

  it("BR-21 — lineID vide via bypass Zod", () => {
    const inv = clone(minimalInvoice);
    const line = inv.tradeTransaction.lineItems[0];
    if (line === undefined) throw new Error("missing line");
    (line as { lineID: string }).lineID = "";
    expectErrorCode(inv, "BR-21");
  });

  it("BR-25 — product.name vide via bypass Zod", () => {
    const inv = clone(minimalInvoice);
    const line = inv.tradeTransaction.lineItems[0];
    if (line === undefined) throw new Error("missing line");
    (line.product as { name: string }).name = "";
    expectErrorCode(inv, "BR-25");
  });

  it("BR-CO-18 — vatBreakdowns vide via bypass Zod", () => {
    const inv = clone(minimalInvoice);
    (inv.tradeTransaction.tradeSettlement as { vatBreakdowns: unknown[] }).vatBreakdowns = [];
    expectErrorCode(inv, "BR-CO-18");
  });
});

describe("validateInvoice — couverture branches manquantes", () => {
  it("BR-Z-1 (ligne) — catégorie Z avec taux non nul à la ligne", () => {
    const inv = clone(minimalInvoice);
    const line = inv.tradeTransaction.lineItems[0];
    if (line === undefined) throw new Error("missing line");
    line.tradeSettlement.vatInformation = {
      categoryCode: VAT_CATEGORY_CODES.ZERO_RATED,
      ratePercent: 5,
    };
    expectErrorCode(inv, "BR-Z-1");
  });

  it("BR-IC-03 — vendeur sans vatID en intracom", () => {
    const inv = clone(minimalInvoice);
    inv.tradeTransaction.tradeSettlement.vatBreakdowns = [
      {
        taxBasisAmount: 100,
        calculatedAmount: 0,
        categoryCode: "K",
        ratePercent: 0,
        exemptionReason: "Intracom",
      },
    ];
    inv.tradeTransaction.tradeAgreement.sellerTradeParty.vatID = undefined;
    inv.tradeTransaction.tradeAgreement.buyerTradeParty.vatID = {
      value: "DE12",
      schemeID: "VA",
    };
    expectErrorCode(inv, "BR-IC-03");
  });

  it("BR-DEC-02 — basisAmount allowance avec 3 décimales", () => {
    const inv = clone(minimalInvoice);
    inv.tradeTransaction.tradeSettlement.documentAllowances = [
      {
        isCharge: false,
        actualAmount: 1.23,
        basisAmount: 5.678,
        taxCategoryCode: "S",
        reason: "x",
      },
    ];
    inv.tradeTransaction.tradeSettlement.monetarySummation.allowanceTotalAmount = 1.23;
    expectErrorCode(inv, "BR-DEC-02");
  });

  it("BR-DEC-06 — basisAmount charge avec 3 décimales", () => {
    const inv = clone(minimalInvoice);
    inv.tradeTransaction.tradeSettlement.documentCharges = [
      {
        isCharge: true,
        actualAmount: 1.23,
        basisAmount: 7.891,
        taxCategoryCode: "S",
        reason: "y",
      },
    ];
    inv.tradeTransaction.tradeSettlement.monetarySummation.chargeTotalAmount = 1.23;
    expectErrorCode(inv, "BR-DEC-06");
  });
});
