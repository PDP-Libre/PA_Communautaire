import { describe, expect, it } from "vitest";
import {
  DocumentAllowanceChargeSchema,
  LineAllowanceChargeSchema,
  VAT_CATEGORY_CODES,
} from "../src/index.js";

describe("DocumentAllowanceChargeSchema (BG-20/21)", () => {
  it("parse une remise minimale", () => {
    const parsed = DocumentAllowanceChargeSchema.parse({
      isCharge: false,
      actualAmount: 100,
      taxCategoryCode: VAT_CATEGORY_CODES.STANDARD,
    });
    expect(parsed.isCharge).toBe(false);
  });

  it("parse une charge avec base + pourcentage", () => {
    const parsed = DocumentAllowanceChargeSchema.parse({
      isCharge: true,
      actualAmount: 50,
      taxCategoryCode: VAT_CATEGORY_CODES.STANDARD,
      taxPercent: 20,
      basisAmount: 1000,
      calculationPercent: 5,
      reason: "Frais administratifs",
    });
    expect(parsed.calculationPercent).toBe(5);
  });
});

describe("LineAllowanceChargeSchema (BG-27/28)", () => {
  it("parse une remise de ligne", () => {
    const parsed = LineAllowanceChargeSchema.parse({
      isCharge: false,
      actualAmount: 10,
      reason: "Quantité",
    });
    expect(parsed.actualAmount).toBe(10);
  });

  it("autorise reasonCode sans reason texte", () => {
    const parsed = LineAllowanceChargeSchema.parse({
      isCharge: false,
      actualAmount: 5,
      reasonCode: "95",
    });
    expect(parsed.reasonCode).toBe("95");
  });
});
