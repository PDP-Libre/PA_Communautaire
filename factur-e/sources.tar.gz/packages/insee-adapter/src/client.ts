/**
 * INSEE Sirene v3.11 contract.
 *
 * The adapter exposes a single `lookupSiren(siren)` returning a discriminated
 * outcome. Callers (onboarding service in `apps/api`) decide what to do per
 * outcome — store in cache, surface to UI as 404, retry on 5xx, etc.
 *
 * Data shape mirrors the Sirene 3.11 JSON response narrowed to the fields
 * the onboarding flow actually consumes (brief Design §6.3) — we keep the
 * raw payload too in `customer_data_prefilled` so future fields can be
 * mined without re-querying.
 */

export interface InseeUniteLegale {
  siren: string;
  /** `denominationUniteLegale` ?? `nomUsageUniteLegale` ?? `nomUniteLegale`. */
  legal_name: string;
  /** `categorieJuridiqueUniteLegale` (4-digit INSEE code). */
  juridique_code: string | null;
  /** `activitePrincipaleUniteLegale` (NAF rev2 — e.g. `6201Z`). */
  naf_code: string | null;
  /** `dateCreationUniteLegale` ISO date. */
  creation_date: string | null;
  /** `etatAdministratifUniteLegale` — "A" active, "C" cessée (or any other
   *  Sirene-defined code; we don't enforce the enum to stay forward-compatible). */
  etat_administratif: string;
}

export interface InseeEtablissement {
  siret: string;
  /** `etablissementSiege`. */
  is_siege: boolean;
  /** `etatAdministratifEtablissement` — "A" active, "F" fermé (open-ended
   *  to stay forward-compatible with Sirene additions). */
  etat_administratif: string;
  /** `dateCreationEtablissement` ISO date. */
  creation_date: string | null;
  /** Composed from the SIREN address block (numeroVoie / typeVoie / libelleVoie / codePostal / libelleCommune / codePaysEtrangerEtablissement). */
  address: {
    street: string;
    zip: string;
    city: string;
    country_code: string;
  };
}

export type InseeLookupResult =
  | {
      kind: "found";
      unite: InseeUniteLegale;
      etablissements: InseeEtablissement[];
      /** Raw payload from `/siren/{siren}` — stored verbatim in
       *  `signup_pending.customer_data_prefilled` to avoid re-queries. */
      raw: Record<string, unknown>;
    }
  | { kind: "not_found" }
  /** Loi Informatique et Libertés — entreprise non-diffusable (article L. 561-2 CC). */
  | { kind: "restricted" }
  | { kind: "unavailable"; cause: "timeout" | "5xx" | "network"; status?: number };

export interface InseeClient {
  lookupSiren(siren: string): Promise<InseeLookupResult>;
}
