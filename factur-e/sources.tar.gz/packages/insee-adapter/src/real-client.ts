import type {
  InseeClient,
  InseeEtablissement,
  InseeLookupResult,
  InseeUniteLegale,
} from "./client.js";

/**
 * INSEE Sirene v3.11 HTTP client.
 *
 * Auth: header `X-INSEE-Api-Key-Integration: <key>` (long-lived API key
 * obtained at https://api.insee.fr/catalogue/, scoped to the Sirene
 * product). NO OAuth2 — distinct from the older v3.0 historic Bearer.
 *
 * Endpoints used:
 *  - `GET /siren/{siren}` → uniteLegale.
 *  - `GET /siret?q=siren:{siren} AND etatAdministratifEtablissement:A&nombre=50`
 *    → list of active establishments. The `&nombre=50` cap is a safety
 *    net (Sirene returns 20 by default, max 1000) — onboarding UI tops
 *    out around 10 in practice.
 *
 * Error mapping:
 *  - 200 → `found`
 *  - 404 → `not_found` (siren absent of register)
 *  - 403 with `header.statut === 403` and "non-diffusable" message → `restricted`
 *  - 5xx → `unavailable, cause: '5xx'`
 *  - timeout / TypeError fetch → `unavailable, cause: 'timeout' | 'network'`
 *
 * Timeout: 8s (brief §6.2 mentions 10s "Sirene indisponible" upper bound;
 * we leave 2s margin for the secondary `/siret` call before the user-side
 * deadline kicks in).
 */

const DEFAULT_BASE_URL = "https://api.insee.fr/api-sirene/3.11";
const DEFAULT_TIMEOUT_MS = 8_000;
const DEFAULT_NOMBRE = 50;

export interface RealInseeClientConfig {
  apiKey: string;
  baseUrl?: string;
  timeoutMs?: number;
  /** Override `fetch` for tests. */
  fetch?: typeof globalThis.fetch;
}

export class RealInseeClient implements InseeClient {
  private readonly baseUrl: string;
  private readonly timeoutMs: number;
  private readonly fetchFn: typeof globalThis.fetch;
  private readonly apiKey: string;

  constructor(cfg: RealInseeClientConfig) {
    this.baseUrl = cfg.baseUrl ?? DEFAULT_BASE_URL;
    this.timeoutMs = cfg.timeoutMs ?? DEFAULT_TIMEOUT_MS;
    this.fetchFn = cfg.fetch ?? globalThis.fetch;
    this.apiKey = cfg.apiKey;
  }

  async lookupSiren(siren: string): Promise<InseeLookupResult> {
    if (!/^\d{9}$/.test(siren)) {
      return { kind: "not_found" };
    }

    const sirenRes = await this.callJson(`/siren/${siren}`);
    if (sirenRes.kind !== "ok") return sirenRes.result;
    const sirenJson = sirenRes.json;

    const unite = parseUniteLegale(sirenJson);
    if (unite === null) return { kind: "not_found" };

    // Sirene 3.11 a une syntaxe `q=` Lucene-like notoirement fragile (le
    // `+`, `%20 AND %20`, et même les parenthèses sont rejetés selon les
    // combinaisons). On garde donc le filtre minimal `q=siren:X` et on
    // filtre les établissements `etat = 'A'` côté client. Robuste, pas
    // dépendant de la syntaxe exacte de l'opérateur AND.
    const siretRes = await this.callJson(
      `/siret?q=siren:${siren}&nombre=${String(DEFAULT_NOMBRE)}`,
    );
    const allEtabs: InseeEtablissement[] =
      siretRes.kind === "ok" ? parseEtablissements(siretRes.json) : [];
    const etablissements = allEtabs.filter((e) => e.etat_administratif === "A");

    return { kind: "found", unite, etablissements, raw: sirenJson };
  }

  private async callJson(
    path: string,
  ): Promise<
    { kind: "ok"; json: Record<string, unknown> } | { kind: "result"; result: InseeLookupResult }
  > {
    const url = `${this.baseUrl}${path}`;
    const ctrl = new AbortController();
    const timer = setTimeout(() => {
      ctrl.abort();
    }, this.timeoutMs);
    try {
      const res = await this.fetchFn(url, {
        method: "GET",
        headers: {
          "X-INSEE-Api-Key-Integration": this.apiKey,
          Accept: "application/json",
        },
        signal: ctrl.signal,
      });

      if (res.status === 404) {
        return { kind: "result", result: { kind: "not_found" } };
      }
      if (res.status === 403) {
        return { kind: "result", result: { kind: "restricted" } };
      }
      if (res.status >= 500) {
        return {
          kind: "result",
          result: { kind: "unavailable", cause: "5xx", status: res.status },
        };
      }
      if (!res.ok) {
        return {
          kind: "result",
          result: { kind: "unavailable", cause: "5xx", status: res.status },
        };
      }
      const json = (await res.json()) as Record<string, unknown>;
      return { kind: "ok", json };
    } catch (err: unknown) {
      const isAbort = err instanceof Error && err.name === "AbortError";
      return {
        kind: "result",
        result: { kind: "unavailable", cause: isAbort ? "timeout" : "network" },
      };
    } finally {
      clearTimeout(timer);
    }
  }
}

export function inseeClientFromEnv(): RealInseeClient | undefined {
  const apiKey = process.env.INSEE_API_KEY;
  if (apiKey === undefined || apiKey === "") return undefined;
  return new RealInseeClient({ apiKey });
}

// ─────────────────────────────────────────────────────────────────────────
// Sirene 3.11 payload parsing — narrow to the fields onboarding uses.
// ─────────────────────────────────────────────────────────────────────────

/**
 * Sirene 3.11 returns `"[ND]"` ("Non Diffusé") in place of any field that
 * is masked under the partial-diffusion rule (statutDiffusion = "P", typical
 * for natural persons / sole proprietors). The string is *not* meaningful
 * data — treat it like an absent value so callers can fall back to manual
 * input without surfacing the sentinel to the UI.
 */
function asString(v: unknown): string | null {
  if (typeof v !== "string" || v.length === 0) return null;
  if (v === "[ND]") return null;
  return v;
}

function parseUniteLegale(payload: Record<string, unknown>): InseeUniteLegale | null {
  const wrap = payload.uniteLegale;
  if (wrap === null || typeof wrap !== "object") return null;
  const u = wrap as Record<string, unknown>;
  const siren = asString(u.siren);
  if (siren === null) return null;

  // Sirene 3.11 nests current values under `periodesUniteLegale[0]`.
  const periodes = u.periodesUniteLegale;
  const current =
    Array.isArray(periodes) && periodes.length > 0 && typeof periodes[0] === "object"
      ? (periodes[0] as Record<string, unknown>)
      : {};

  // Sirene returns `denomination*UniteLegale` for légal entities (SARL,
  // SAS, …) and `nom*UniteLegale` (+ `prenom*` at top level) for personnes
  // physiques. We pick the first non-null in this order:
  //   1. denominationUniteLegale  (SARL/SAS/SCI/EURL/…)
  //   2. denominationUsuelle{1,2,3}UniteLegale  (enseigne d'un PI)
  //   3. nomUsageUniteLegale  (nom d'usage = nom marital, ex.)
  //   4. `prenomUsuel|prenom1 + nomUniteLegale`  (cas PI standard)
  //   5. nomUniteLegale alone
  function fromCurrent(): string | null {
    return (
      asString(current.denominationUniteLegale) ??
      asString(current.denominationUsuelle1UniteLegale) ??
      asString(current.denominationUsuelle2UniteLegale) ??
      asString(current.denominationUsuelle3UniteLegale) ??
      asString(current.nomUsageUniteLegale) ??
      null
    );
  }
  function fromTop(): string | null {
    return (
      asString(u.denominationUniteLegale) ??
      asString(u.denominationUsuelle1UniteLegale) ??
      asString(u.nomUsageUniteLegale) ??
      null
    );
  }
  const denominationLike = fromCurrent() ?? fromTop();
  const familyName = asString(current.nomUniteLegale) ?? asString(u.nomUniteLegale);
  const givenName = asString(u.prenomUsuelUniteLegale) ?? asString(u.prenom1UniteLegale);
  let legalName = denominationLike ?? "";
  if (legalName === "" && familyName !== null) {
    // Personne physique : "PIERRE HEYRIES" plutôt que juste "HEYRIES".
    legalName = givenName !== null ? `${givenName} ${familyName}` : familyName;
  }
  const juridique =
    asString(current.categorieJuridiqueUniteLegale) ?? asString(u.categorieJuridiqueUniteLegale);
  const naf =
    asString(current.activitePrincipaleUniteLegale) ?? asString(u.activitePrincipaleUniteLegale);
  const creation = asString(u.dateCreationUniteLegale);
  const etat =
    asString(current.etatAdministratifUniteLegale) ??
    asString(u.etatAdministratifUniteLegale) ??
    "A";

  return {
    siren,
    legal_name: legalName,
    juridique_code: juridique,
    naf_code: naf,
    creation_date: creation,
    etat_administratif: etat,
  };
}

function parseEtablissements(payload: Record<string, unknown>): InseeEtablissement[] {
  const list = payload.etablissements;
  if (!Array.isArray(list)) return [];
  const out: InseeEtablissement[] = [];
  for (const raw of list) {
    if (raw === null || typeof raw !== "object") continue;
    const r = raw as Record<string, unknown>;
    const siret = asString(r.siret);
    if (siret === null) continue;
    const adresseWrap = r.adresseEtablissement;
    const adresse =
      adresseWrap !== null && typeof adresseWrap === "object"
        ? (adresseWrap as Record<string, unknown>)
        : {};
    const street = [
      asString(adresse.numeroVoieEtablissement),
      asString(adresse.typeVoieEtablissement),
      asString(adresse.libelleVoieEtablissement),
    ]
      .filter((p): p is string => p !== null)
      .join(" ");
    const zip = asString(adresse.codePostalEtablissement) ?? "";
    const city =
      asString(adresse.libelleCommuneEtablissement) ??
      asString(adresse.libelleCommuneEtrangerEtablissement) ??
      "";
    const country = asString(adresse.codePaysEtrangerEtablissement) ?? "FR";

    // Current-period fields nested in `periodesEtablissement[0]` (3.11).
    const periodes = r.periodesEtablissement;
    const current =
      Array.isArray(periodes) && periodes.length > 0 && typeof periodes[0] === "object"
        ? (periodes[0] as Record<string, unknown>)
        : {};
    const etat =
      asString(current.etatAdministratifEtablissement) ??
      asString(r.etatAdministratifEtablissement) ??
      "A";

    const isSiegeRaw = r.etablissementSiege ?? current.etablissementSiege;
    const isSiege = isSiegeRaw === true || isSiegeRaw === "true";

    out.push({
      siret,
      is_siege: isSiege,
      etat_administratif: etat,
      creation_date: asString(r.dateCreationEtablissement),
      address: { street, zip, city, country_code: country },
    });
  }
  return out;
}
