export { RealInseeClient, inseeClientFromEnv } from "./real-client.js";
export type {
  InseeClient,
  InseeLookupResult,
  InseeUniteLegale,
  InseeEtablissement,
} from "./client.js";
