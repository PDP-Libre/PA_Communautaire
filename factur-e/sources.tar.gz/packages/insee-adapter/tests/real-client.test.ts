import { describe, expect, it } from "vitest";

import { RealInseeClient } from "../src/real-client.js";

interface CapturedCall {
  url: string;
  headers: Record<string, string>;
}

function makeFetchSpy(responder: (path: string) => Response | Promise<Response>): {
  calls: CapturedCall[];
  fetch: typeof globalThis.fetch;
} {
  const calls: CapturedCall[] = [];
  const fetch: typeof globalThis.fetch = (input, init) => {
    const url =
      typeof input === "string" ? input : input instanceof URL ? input.toString() : input.url;
    const headersRecord: Record<string, string> = {};
    const rawHeaders = init?.headers;
    if (rawHeaders !== undefined) {
      if (rawHeaders instanceof Headers) {
        rawHeaders.forEach((v, k) => {
          headersRecord[k.toLowerCase()] = v;
        });
      } else if (Array.isArray(rawHeaders)) {
        for (const pair of rawHeaders as [string, string][]) {
          headersRecord[pair[0].toLowerCase()] = pair[1];
        }
      } else {
        for (const [k, v] of Object.entries(rawHeaders as Record<string, string>)) {
          headersRecord[k.toLowerCase()] = v;
        }
      }
    }
    calls.push({ url, headers: headersRecord });
    return Promise.resolve(responder(url));
  };
  return { calls, fetch };
}

const SIREN_FIXTURE = {
  uniteLegale: {
    siren: "552120222",
    dateCreationUniteLegale: "1955-04-01",
    periodesUniteLegale: [
      {
        denominationUniteLegale: "ACME SAS",
        categorieJuridiqueUniteLegale: "5710",
        activitePrincipaleUniteLegale: "6201Z",
        etatAdministratifUniteLegale: "A",
      },
    ],
  },
};

const SIRET_FIXTURE = {
  etablissements: [
    {
      siret: "55212022200015",
      etablissementSiege: true,
      dateCreationEtablissement: "2010-01-01",
      adresseEtablissement: {
        numeroVoieEtablissement: "1",
        typeVoieEtablissement: "RUE",
        libelleVoieEtablissement: "DE LA PAIX",
        codePostalEtablissement: "75002",
        libelleCommuneEtablissement: "PARIS 2",
      },
      periodesEtablissement: [{ etatAdministratifEtablissement: "A" }],
    },
    {
      siret: "55212022200023",
      etablissementSiege: false,
      dateCreationEtablissement: "2018-06-15",
      adresseEtablissement: {
        numeroVoieEtablissement: "12",
        typeVoieEtablissement: "AVENUE",
        libelleVoieEtablissement: "VICTOR HUGO",
        codePostalEtablissement: "33000",
        libelleCommuneEtablissement: "BORDEAUX",
      },
      periodesEtablissement: [{ etatAdministratifEtablissement: "A" }],
    },
  ],
};

describe("RealInseeClient.lookupSiren", () => {
  it("returns `found` with parsed unite + establishments on a 200/200 success", async () => {
    const { calls, fetch } = makeFetchSpy((url) => {
      if (url.includes("/siren/")) return new Response(JSON.stringify(SIREN_FIXTURE));
      return new Response(JSON.stringify(SIRET_FIXTURE));
    });
    const client = new RealInseeClient({ apiKey: "fake-api-key", fetch });

    const result = await client.lookupSiren("552120222");
    expect(result.kind).toBe("found");
    if (result.kind !== "found") return;
    expect(result.unite.siren).toBe("552120222");
    expect(result.unite.legal_name).toBe("ACME SAS");
    expect(result.unite.juridique_code).toBe("5710");
    expect(result.unite.naf_code).toBe("6201Z");
    expect(result.etablissements).toHaveLength(2);
    expect(result.etablissements[0]?.is_siege).toBe(true);
    expect(result.etablissements[0]?.address.zip).toBe("75002");
    expect(result.etablissements[0]?.address.country_code).toBe("FR");

    expect(calls[0]?.url).toContain("/api-sirene/3.11/siren/552120222");
    expect(calls[0]?.headers["x-insee-api-key-integration"]).toBe("fake-api-key");
    expect(calls[1]?.url).toContain("/siret?q=siren:552120222");
    // Plus de filtre AND etatAdministratif côté query (Lucene Sirene 3.11
    // trop fragile) — le filtre est appliqué côté client.
    expect(calls[1]?.url).not.toContain("AND");
  });

  it("returns `not_found` on 404", async () => {
    const { fetch } = makeFetchSpy(() => new Response("", { status: 404 }));
    const client = new RealInseeClient({ apiKey: "k", fetch });
    const result = await client.lookupSiren("999999999");
    expect(result.kind).toBe("not_found");
  });

  it("returns `restricted` on 403", async () => {
    const { fetch } = makeFetchSpy(() => new Response("", { status: 403 }));
    const client = new RealInseeClient({ apiKey: "k", fetch });
    const result = await client.lookupSiren("123456789");
    expect(result.kind).toBe("restricted");
  });

  it("returns `unavailable` cause=5xx on 503", async () => {
    const { fetch } = makeFetchSpy(() => new Response("", { status: 503 }));
    const client = new RealInseeClient({ apiKey: "k", fetch });
    const result = await client.lookupSiren("123456789");
    expect(result.kind).toBe("unavailable");
    if (result.kind === "unavailable") {
      expect(result.cause).toBe("5xx");
      expect(result.status).toBe(503);
    }
  });

  it("returns `unavailable` cause=network on fetch throw", async () => {
    const fakeFetch: typeof globalThis.fetch = () => Promise.reject(new TypeError("network down"));
    const client = new RealInseeClient({ apiKey: "k", fetch: fakeFetch });
    const result = await client.lookupSiren("123456789");
    expect(result.kind).toBe("unavailable");
    if (result.kind === "unavailable") {
      expect(result.cause).toBe("network");
    }
  });

  it("rejects non-9-digit SIREN client-side", async () => {
    const { calls, fetch } = makeFetchSpy(() => new Response("{}"));
    const client = new RealInseeClient({ apiKey: "k", fetch });
    const result = await client.lookupSiren("ABC");
    expect(result.kind).toBe("not_found");
    expect(calls).toHaveLength(0);
  });

  it("filtre les établissements fermés côté client (etat != 'A')", async () => {
    const FIXTURE = {
      uniteLegale: {
        siren: "552120222",
        periodesUniteLegale: [
          { denominationUniteLegale: "ACME", categorieJuridiqueUniteLegale: "5710" },
        ],
      },
    };
    const SIRET_MIXED = {
      etablissements: [
        {
          siret: "55212022200015",
          etablissementSiege: true,
          adresseEtablissement: {
            numeroVoieEtablissement: "1",
            typeVoieEtablissement: "RUE",
            libelleVoieEtablissement: "PAIX",
            codePostalEtablissement: "75002",
            libelleCommuneEtablissement: "PARIS",
          },
          periodesEtablissement: [{ etatAdministratifEtablissement: "A" }],
        },
        {
          siret: "55212022200023",
          etablissementSiege: false,
          adresseEtablissement: {
            numeroVoieEtablissement: "12",
            typeVoieEtablissement: "RUE",
            libelleVoieEtablissement: "FERMEE",
            codePostalEtablissement: "75003",
            libelleCommuneEtablissement: "PARIS",
          },
          periodesEtablissement: [{ etatAdministratifEtablissement: "F" }],
        },
      ],
    };
    const { fetch } = makeFetchSpy((url) => {
      if (url.includes("/siren/")) return new Response(JSON.stringify(FIXTURE));
      return new Response(JSON.stringify(SIRET_MIXED));
    });
    const client = new RealInseeClient({ apiKey: "k", fetch });
    const result = await client.lookupSiren("552120222");
    expect(result.kind).toBe("found");
    if (result.kind !== "found") return;
    expect(result.etablissements).toHaveLength(1);
    expect(result.etablissements[0]?.siret).toBe("55212022200015");
  });

  it("personne physique non-masquée : concat prénom + nom comme legal_name", async () => {
    const PI_SIREN = {
      uniteLegale: {
        siren: "750793739",
        statutDiffusionUniteLegale: "O",
        prenomUsuelUniteLegale: "PIERRE",
        prenom1UniteLegale: "PIERRE",
        periodesUniteLegale: [
          {
            denominationUniteLegale: null,
            nomUsageUniteLegale: null,
            nomUniteLegale: "HEYRIES",
            categorieJuridiqueUniteLegale: "1000",
            activitePrincipaleUniteLegale: "74.90B",
            etatAdministratifUniteLegale: "A",
          },
        ],
      },
    };
    const { fetch } = makeFetchSpy((url) => {
      if (url.includes("/siren/")) return new Response(JSON.stringify(PI_SIREN));
      return new Response(JSON.stringify({ etablissements: [] }));
    });
    const client = new RealInseeClient({ apiKey: "k", fetch });
    const result = await client.lookupSiren("750793739");
    expect(result.kind).toBe("found");
    if (result.kind !== "found") return;
    expect(result.unite.legal_name).toBe("PIERRE HEYRIES");
    expect(result.unite.juridique_code).toBe("1000");
  });

  it("personne physique sans prénom : retourne juste le nom", async () => {
    const PI_NO_FIRSTNAME = {
      uniteLegale: {
        siren: "750793739",
        statutDiffusionUniteLegale: "O",
        prenomUsuelUniteLegale: null,
        prenom1UniteLegale: null,
        periodesUniteLegale: [
          {
            denominationUniteLegale: null,
            nomUsageUniteLegale: null,
            nomUniteLegale: "HEYRIES",
            categorieJuridiqueUniteLegale: "1000",
            activitePrincipaleUniteLegale: "74.90B",
            etatAdministratifUniteLegale: "A",
          },
        ],
      },
    };
    const { fetch } = makeFetchSpy((url) => {
      if (url.includes("/siren/")) return new Response(JSON.stringify(PI_NO_FIRSTNAME));
      return new Response(JSON.stringify({ etablissements: [] }));
    });
    const client = new RealInseeClient({ apiKey: "k", fetch });
    const result = await client.lookupSiren("750793739");
    expect(result.kind).toBe("found");
    if (result.kind !== "found") return;
    expect(result.unite.legal_name).toBe("HEYRIES");
  });

  it("treats `[ND]` (Non Diffusé) as null on partially-diffused entreprises", async () => {
    // Personne physique / entrepreneur individuel : statutDiffusion = "P",
    // tous les champs identifiants sont remplacés par "[ND]" par INSEE.
    const NDSiren = {
      uniteLegale: {
        siren: "523950236",
        statutDiffusionUniteLegale: "P",
        dateCreationUniteLegale: "2010-07-12",
        periodesUniteLegale: [
          {
            denominationUniteLegale: "[ND]",
            nomUniteLegale: "[ND]",
            nomUsageUniteLegale: "[ND]",
            categorieJuridiqueUniteLegale: "1000",
            activitePrincipaleUniteLegale: "70.22Z",
            etatAdministratifUniteLegale: "A",
          },
        ],
      },
    };
    const NDSiret = {
      etablissements: [
        {
          siret: "52395023600027",
          etablissementSiege: true,
          dateCreationEtablissement: "2010-07-12",
          adresseEtablissement: {
            numeroVoieEtablissement: "[ND]",
            typeVoieEtablissement: "[ND]",
            libelleVoieEtablissement: "[ND]",
            codePostalEtablissement: "[ND]",
            libelleCommuneEtablissement: "[ND]",
          },
          periodesEtablissement: [{ etatAdministratifEtablissement: "A" }],
        },
      ],
    };
    const { fetch } = makeFetchSpy((url) => {
      if (url.includes("/siren/")) return new Response(JSON.stringify(NDSiren));
      return new Response(JSON.stringify(NDSiret));
    });
    const client = new RealInseeClient({ apiKey: "k", fetch });
    const result = await client.lookupSiren("523950236");
    expect(result.kind).toBe("found");
    if (result.kind !== "found") return;

    // Identifiants sensibles purgés -> chaînes vides exposables au front.
    expect(result.unite.legal_name).toBe("");
    // Codes "techniques" non sensibles -> conservés.
    expect(result.unite.juridique_code).toBe("1000");
    expect(result.unite.naf_code).toBe("70.22Z");

    // Adresse complètement masquée -> tous les sous-champs vides.
    expect(result.etablissements).toHaveLength(1);
    expect(result.etablissements[0]?.address.street).toBe("");
    expect(result.etablissements[0]?.address.zip).toBe("");
    expect(result.etablissements[0]?.address.city).toBe("");
    // is_siege reste lisible (info technique non sensible).
    expect(result.etablissements[0]?.is_siege).toBe(true);
  });
});
