// Facture EXTENDED de référence pour `pnpm factur-x:generate-sample`.
// Cf. plan.md sprint-01 T-CL-06.
//
// Cette facture exerce un échantillon large des BG/BT du profil EXTENDED :
// - BG-1 (notes auto BR-FR-05 + TAX_INFO), BG-4/5/6/7/8 (parties + adresse + contact),
// - BG-11/12 (représentant fiscal), BG-22 (totaux + BT-114 rounding), BG-23 (TVA),
// - BG-25 (lignes), BG-29/30/31/32 (sous-groupes ligne, BG-32 itemAttributes,
//   BT-128 invoicedObjectID, BT-159 countryOfOriginCode),
// - BG-13/15 (livraison), BG-14 (période), BG-16/17 (paiement),
// - BG-20/21 (allowance/charge document), BG-24 (docs additionnels),
// - BG-3 (BT-25 référence facture précédente), BG-10 (PayeeParty distincte du seller).
//
// T-CL-FACTURX-AUDIT-V1 sprint-05 — enrichissements : BG-11 sellerTaxRepresentative,
// BG-10 payeeParty, BG-3 precedingInvoices, BG-6 DefinedTradeContact seller,
// BT-114 roundingAmount + ajustement BT-115 BR-CO-16, BT-128 invoicedObjectID ligne.
//
// Le PDF généré doit passer veraPDF flavour 3b avec isCompliant=true
// (cf. ADR-004 §"Test golden").
//
// Identités sandbox SuperPDP (cf. T-CL-FACTURX-SAMPLE-FIX sprint-04) :
// - Seller = Burger Queen, SIREN 000000002 (compte sandbox SuperPDP),
//   Peppol 0225:315143296_3686 → utilisé en BT-34.
// - Buyer = Tricatel, SIREN 000000001, Peppol 0225:315143296_3685 → BT-49.
// Le SIREN seller doit matcher le compte authentifié OAuth Client Credentials
// (Burger Queen 000000002) sinon SuperPDP rejette en 400 hard non bypassable
// "L'entreprise liée à cette session ne correspond pas au vendeur" (ADR-010 v2 D6).

import type { CrossIndustryInvoice } from "@factur-e/factur-x-model";
import {
  FACTUR_X_PROFILES,
  INVOICE_TYPE_CODES,
  NOTE_SUBJECT_CODES,
  PAYMENT_MEANS_CODES,
  SCHEME_IDS,
  UNIT_CODES,
  VAT_CATEGORY_CODES,
} from "@factur-e/factur-x-model";

export const extendedSampleInvoice: CrossIndustryInvoice = {
  documentContext: {
    // BR-FR-08 (FNFE CTC Flux 2 v1.3.0) — `businessProcessID` (BT-23) doit
    // appartenir à la liste FR : B1/S1/M1/B2/S2/M2/B4/S4/M4/S5/S6/B7/S7. "B1" =
    // e-invoicing B2B France (mode de facturation standard réforme). "A1"
    // (héritage Factur-X ZUGFeRD germano-français) rejeté par le Schematron
    // FNFE FR CTC validateur SuperPDP web.
    businessProcessID: "B1",
    specificationID: { value: FACTUR_X_PROFILES.EXTENDED },
  },
  exchangedDocument: {
    invoiceNumber: "FA-2026-EXT-001",
    invoiceTypeCode: INVOICE_TYPE_CODES.COMMERCIAL,
    issueDate: { value: "20260415", format: "102" },
    // BR-FR-05 (AFNOR XP Z12-012 §5.2, sprint-05 SCHEMATRON NC-17) — 3 mentions
    // légales obligatoires : PMT (indemnité forfaitaire 40 € Loi LME), PMD
    // (pénalités retard, default LME 3× taux légal), AAB (mention escompte,
    // default absence). Cf. `docs/standards/afnor-xp-z12-012-br-fr-05-included
    // -notes.md` §3. Sample EXTENDED illustre ces 3 + une note libre TAX_INFO.
    includedNotes: [
      {
        content: "TVA acquittée sur les débits.",
        subjectCode: NOTE_SUBJECT_CODES.TAX_INFO,
      },
      {
        content:
          "Indemnité forfaitaire pour frais de recouvrement en cas de retard de paiement : 40 €.",
        subjectCode: NOTE_SUBJECT_CODES.PAYMENT_TERMS,
      },
      {
        content:
          "Tout retard de paiement engendre une pénalité exigible à compter de la date d'échéance, calculée sur la base de trois fois le taux d'intérêt légal.",
        subjectCode: NOTE_SUBJECT_CODES.PAYMENT_MEANS_NOTE,
      },
      {
        content: "Les règlements reçus avant la date d'échéance ne donneront pas lieu à escompte.",
        subjectCode: NOTE_SUBJECT_CODES.ADDITIONAL_BUYER_REF,
      },
    ],
  },
  tradeTransaction: {
    lineItems: [
      {
        lineID: "1",
        note: "Prestation forfaitaire mensuelle.",
        product: {
          name: "Audit conformité — forfait mensuel",
          description: "Revue mensuelle des dépôts.",
          itemAttributes: [{ attributeName: "Catégorie", attributeValue: "Service" }],
          countryOfOriginCode: "FR",
        },
        tradeAgreement: {
          netPrice: 1500,
          basisQuantity: 1,
          basisQuantityUnitCode: UNIT_CODES.MONTH,
        },
        tradeDelivery: { billedQuantity: 6, unitCode: UNIT_CODES.MONTH },
        tradeSettlement: {
          vatInformation: {
            categoryCode: VAT_CATEGORY_CODES.STANDARD,
            ratePercent: 20,
          },
          netLineAmount: 9000,
          // BT-128 invoicedObjectID — exerce ligne EXTENDED level (sérialisé en
          // AdditionalReferencedDocument typeCode="130" cf. line-item.ts).
          invoicedObjectID: {
            documentID: "MARCHE-2026-AUDIT-Q2",
            typeCode: "130",
          },
        },
      },
      {
        lineID: "2",
        product: {
          name: "Frais d'expertise comptable",
          countryOfOriginCode: "FR",
          itemAttributes: [{ attributeName: "Nature", attributeValue: "Honoraires" }],
        },
        tradeAgreement: { netPrice: 500 },
        tradeDelivery: { billedQuantity: 1, unitCode: UNIT_CODES.PIECE },
        tradeSettlement: {
          vatInformation: {
            categoryCode: VAT_CATEGORY_CODES.STANDARD,
            ratePercent: 20,
          },
          netLineAmount: 500,
        },
      },
    ],
    tradeAgreement: {
      sellerTradeParty: {
        name: "Burger Queen",
        tradingName: "Burger Queen [sandbox]",
        postalAddress: {
          countryCode: "FR",
          postalCode: "75008",
          cityName: "Paris",
          lineOne: "10 avenue des Champs-Élysées",
        },
        legalRegistrationID: {
          value: "000000002",
          schemeID: SCHEME_IDS.SIREN_SIRET,
        },
        vatID: { value: "FR00000000002", schemeID: SCHEME_IDS.VAT },
        // BT-34 — adresse Peppol annuaire SuperPDP sandbox (schemeID="0225" SIRET EAS).
        electronicAddress: { value: "315143296_3686", schemeID: "0225" },
        // BG-6 DefinedTradeContact seller (0..1 EN16931, 0..n EXTENDED — code
        // émet le premier seulement). Exerce branche `<ram:DefinedTradeContact>`.
        definedContacts: [
          {
            personName: "Service Facturation Burger Queen",
            telephoneNumber: "+33145789200",
            emailAddress: "facturation@burger-queen.sandbox",
          },
        ],
      },
      // BG-11 SellerTaxRepresentative — exerce branche
      // `<ram:SellerTaxRepresentativeTradeParty>` (Name + PostalTradeAddress +
      // SpecifiedTaxRegistration BT-63 schemeID="VA").
      sellerTaxRepresentative: {
        name: "Cabinet Représentant Fiscal SAS",
        postalAddress: {
          countryCode: "FR",
          postalCode: "75002",
          cityName: "Paris",
          lineOne: "1 rue de la Bourse",
        },
        vatID: { value: "FR99999999999", schemeID: SCHEME_IDS.VAT },
      },
      buyerTradeParty: {
        name: "Tricatel",
        postalAddress: {
          countryCode: "FR",
          postalCode: "75011",
          cityName: "Paris",
          lineOne: "1 rue de l'Industrie",
        },
        legalRegistrationID: {
          value: "000000001",
          schemeID: SCHEME_IDS.SIREN_SIRET,
        },
        // BT-49 — adresse Peppol annuaire SuperPDP sandbox (schemeID="0225" SIRET EAS).
        electronicAddress: { value: "315143296_3685", schemeID: "0225" },
      },
      buyerReference: "REF-CLIENT-TRICATEL",
      // BR-FR-17 (FNFE CTC Flux 2 v1.3.0) — la liste FR de codes de qualification
      // pièce jointe (BT-123) restreint le code list UNTDID 1001. `916`
      // (SUPPORTING) déclenche warning Schematron FNFE FR CTC. Bloc
      // `additionalReferencedDocuments` retiré du sample tant que la liste
      // valide BR-FR-17 n'est pas extraite Cowork PMO dans `docs/standards/`
      // (à acter T-CL-FACTURX-AUDIT-V1 ou extraction dédiée sprint-06+).
      // `formToModel()` production ne génère pas ce champ aujourd'hui — impact
      // sample-only.
    },
    tradeDelivery: {
      shipToPartyName: "Tricatel",
      deliveryAddress: {
        countryCode: "FR",
        postalCode: "75011",
        cityName: "Paris",
        lineOne: "1 rue de l'Industrie",
      },
      actualDeliveryDate: { value: "20260415", format: "102" },
    },
    tradeSettlement: {
      invoiceCurrencyCode: "EUR",
      paymentReference: "FA-2026-EXT-001",
      vatBreakdowns: [
        {
          taxBasisAmount: 9500,
          calculatedAmount: 1900,
          categoryCode: VAT_CATEGORY_CODES.STANDARD,
          ratePercent: 20,
        },
      ],
      monetarySummation: {
        // BR-CO-10/13/14/15/16 :
        //   lineTotal = Σ BT-131 = 9000 + 500 = 9500
        //   taxBasis = lineTotal − allowance + charge = 9500 (pas de doc-level a/c)
        //   vatTotal = Σ BG-23 calculatedAmount = 1900 (9500 × 20 %)
        //   grandTotal = taxBasis + vatTotal = 11400 (BR-CO-15 strict)
        //   duePayable = grandTotal − paidAmount + rounding = 11400 + 0.50 = 11400.50 (BR-CO-16)
        // BT-114 RoundingAmount (EN16931+) — exerce branche XML
        // `<ram:RoundingAmount>` (cf. monetary-summation.ts l. 52-54).
        lineTotalAmount: 9500,
        taxBasisTotalAmount: 9500,
        vatTotalAmount: { value: 1900, currencyID: "EUR" },
        roundingAmount: 0.5,
        grandTotalAmount: 11400,
        duePayableAmount: 11400.5,
      },
      // BG-10 PayeeTradeParty — bénéficiaire du paiement distinct du vendeur
      // (factoring / cession de créance). Exerce branche restreinte EN16931
      // (ID + Name + SpecifiedLegalOrganization seuls cf. trade-party.ts).
      payeeParty: {
        name: "Société de Factoring SA",
        globalID: { value: "FACTORING-BQ-2026", schemeID: SCHEME_IDS.AGENCY_PEPPOL },
        legalRegistrationID: {
          value: "555666777",
          schemeID: SCHEME_IDS.SIREN_SIRET,
        },
        // BG-10 EN16931 restreint → postalAddress non sérialisé même si fourni.
        postalAddress: { countryCode: "FR" },
      },
      // BG-3 PrecedingInvoiceReference — référence facture précédente
      // (corrective, refacturation). Exerce branche
      // `<ram:InvoiceReferencedDocument>` post-BG-22 (bug §9.4 #5 doc Swift).
      precedingInvoices: [
        {
          invoiceNumber: "FA-2026-EXT-000",
          issueDate: { value: "20260315", format: "102" },
        },
      ],
      paymentTermsDescription: "Paiement à 30 jours fin de mois.",
      dueDate: { value: "20260531", format: "102" },
      paymentMeans: [
        {
          typeCode: PAYMENT_MEANS_CODES.CREDIT_TRANSFER,
          information: "Virement IBAN",
          payeeFinancialAccounts: [
            {
              accountID: {
                value: "FR7630006000011234567890189",
                schemeID: "IBAN",
              },
              accountName: "Burger Queen",
              financialInstitutionID: {
                value: "AGRIFRPP",
                schemeID: "BIC",
              },
            },
          ],
        },
      ],
      billingPeriod: {
        startDate: { value: "20260101", format: "102" },
        endDate: { value: "20260630", format: "102" },
      },
    },
  },
};
