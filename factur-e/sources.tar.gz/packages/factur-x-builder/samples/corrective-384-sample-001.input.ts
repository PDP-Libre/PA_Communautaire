// Sample Facture rectificative (BT-3 = 384) — sprint-07 V2 Axe B
// (T-CL-FACTURX-PDF-TEMPLATE-ENGINE). Exerce le template `corrective-invoice.njk`
// : titre "Facture rectificative", référence BG-3 facture origine (libellés
// verbatim LinkedInvoiceBanner W4). Structure alignée sur le sample EXTENDED.

import type { CrossIndustryInvoice } from "@factur-e/factur-x-model";
import {
  FACTUR_X_PROFILES,
  INVOICE_TYPE_CODES,
  NOTE_SUBJECT_CODES,
  PAYMENT_MEANS_CODES,
  SCHEME_IDS,
  UNIT_CODES,
  VAT_CATEGORY_CODES,
} from "@factur-e/factur-x-model";

export const corrective384Sample: CrossIndustryInvoice = {
  documentContext: {
    businessProcessID: "B1",
    specificationID: { value: FACTUR_X_PROFILES.EXTENDED },
  },
  exchangedDocument: {
    invoiceNumber: "FR-2026-EXT-001",
    invoiceTypeCode: INVOICE_TYPE_CODES.CORRECTIVE, // 384
    issueDate: { value: "20260422", format: "102" },
    includedNotes: [
      {
        content:
          "Indemnité forfaitaire pour frais de recouvrement en cas de retard de paiement : 40 €.",
        subjectCode: NOTE_SUBJECT_CODES.PAYMENT_TERMS,
      },
      {
        content:
          "Tout retard de paiement engendre une pénalité exigible à compter de la date d'échéance, calculée sur la base de trois fois le taux d'intérêt légal.",
        subjectCode: NOTE_SUBJECT_CODES.PAYMENT_MEANS_NOTE,
      },
      {
        content: "Les règlements reçus avant la date d'échéance ne donneront pas lieu à escompte.",
        subjectCode: NOTE_SUBJECT_CODES.ADDITIONAL_BUYER_REF,
      },
    ],
  },
  tradeTransaction: {
    lineItems: [
      {
        lineID: "1",
        product: {
          name: "Audit conformité — forfait mensuel (corrigé)",
          description: "Quantité rectifiée : 5 mois au lieu de 6.",
          countryOfOriginCode: "FR",
        },
        tradeAgreement: {
          netPrice: 1500,
          basisQuantity: 1,
          basisQuantityUnitCode: UNIT_CODES.MONTH,
        },
        tradeDelivery: { billedQuantity: 5, unitCode: UNIT_CODES.MONTH },
        tradeSettlement: {
          vatInformation: { categoryCode: VAT_CATEGORY_CODES.STANDARD, ratePercent: 20 },
          netLineAmount: 7500,
        },
      },
    ],
    tradeAgreement: {
      sellerTradeParty: {
        name: "Burger Queen",
        postalAddress: {
          countryCode: "FR",
          postalCode: "75008",
          cityName: "Paris",
          lineOne: "10 avenue des Champs-Élysées",
        },
        legalRegistrationID: { value: "000000002", schemeID: SCHEME_IDS.SIREN_SIRET },
        vatID: { value: "FR00000000002", schemeID: SCHEME_IDS.VAT },
        electronicAddress: { value: "315143296_3686", schemeID: "0225" },
      },
      buyerTradeParty: {
        name: "Tricatel",
        postalAddress: {
          countryCode: "FR",
          postalCode: "75011",
          cityName: "Paris",
          lineOne: "1 rue de l'Industrie",
        },
        legalRegistrationID: { value: "000000001", schemeID: SCHEME_IDS.SIREN_SIRET },
        electronicAddress: { value: "315143296_3685", schemeID: "0225" },
      },
      buyerReference: "REF-CLIENT-TRICATEL",
    },
    tradeDelivery: {},
    tradeSettlement: {
      invoiceCurrencyCode: "EUR",
      paymentReference: "FR-2026-EXT-001",
      vatBreakdowns: [
        {
          taxBasisAmount: 7500,
          calculatedAmount: 1500,
          categoryCode: VAT_CATEGORY_CODES.STANDARD,
          ratePercent: 20,
        },
      ],
      monetarySummation: {
        lineTotalAmount: 7500,
        taxBasisTotalAmount: 7500,
        vatTotalAmount: { value: 1500, currencyID: "EUR" },
        grandTotalAmount: 9000,
        duePayableAmount: 9000,
      },
      // BG-3 — facture d'origine remplacée par cette rectificative.
      precedingInvoices: [
        { invoiceNumber: "FA-2026-EXT-001", issueDate: { value: "20260415", format: "102" } },
      ],
      paymentTermsDescription: "Paiement à 30 jours fin de mois.",
      dueDate: { value: "20260531", format: "102" },
      paymentMeans: [
        {
          typeCode: PAYMENT_MEANS_CODES.CREDIT_TRANSFER,
          payeeFinancialAccounts: [
            {
              accountID: { value: "FR7630006000011234567890189", schemeID: "IBAN" },
              accountName: "Burger Queen",
              financialInstitutionID: { value: "AGRIFRPP", schemeID: "BIC" },
            },
          ],
        },
      ],
    },
  },
};
