// Sample profil Factur-X EN16931 (T-CL-FACTURX-AUDIT-V1 sprint-05).
// Conformité norme européenne EN 16931:2017 stricte — référence interop UE
// PEPPOL. BASIC + couverture EN16931 : BuyerReference (BT-10), BG-13 ShipTo,
// BG-14 BillingPeriod, BG-11 SellerTaxRepresentative, BT-32 taxRegistrationLocalID,
// BG-32 ItemAttribute ligne, BG-27 allowance ligne, BG-26 LineBillingPeriod,
// BT-159 country of origin produit. AUCUN élément EXTENDED-only (cf. delta
// `docs/standards/factur-x-1.07.3-extended-vs-en16931-delta.md` §3 + §4).
//
// Spec : `docs/standards/factur-x-1.07.3-en16931-business-rules.md` §2 BR-*
// core + §3 BR-CO-* cohérence intra-document.

import type { CrossIndustryInvoice } from "@factur-e/factur-x-model";
import {
  FACTUR_X_PROFILES,
  INVOICE_TYPE_CODES,
  NOTE_SUBJECT_CODES,
  PAYMENT_MEANS_CODES,
  SCHEME_IDS,
  UNIT_CODES,
  VAT_CATEGORY_CODES,
} from "@factur-e/factur-x-model";

export const en16931SampleInvoice: CrossIndustryInvoice = {
  documentContext: {
    specificationID: { value: FACTUR_X_PROFILES.EN16931 },
  },
  exchangedDocument: {
    invoiceNumber: "FA-2026-EN-001",
    invoiceTypeCode: INVOICE_TYPE_CODES.COMMERCIAL,
    issueDate: { value: "20260415", format: "102" },
    includedNotes: [
      {
        content: "Facture conforme EN 16931:2017 — référence interop UE.",
        subjectCode: NOTE_SUBJECT_CODES.GENERAL,
      },
    ],
  },
  tradeTransaction: {
    lineItems: [
      {
        lineID: "1",
        note: "Note de ligne — référence projet 2026-Q2.",
        product: {
          name: "Audit conformité — forfait trimestriel",
          description: "Revue trimestrielle des dépôts comptables.",
          sellerAssignedID: { value: "ART-2026-AUDIT" },
          itemAttributes: [
            { attributeName: "Domaine", attributeValue: "Conformité" },
            { attributeName: "Fréquence", attributeValue: "Trimestrielle" },
          ],
          countryOfOriginCode: "FR",
        },
        tradeAgreement: { netPrice: 2500 },
        tradeDelivery: { billedQuantity: 1, unitCode: UNIT_CODES.MONTH },
        tradeSettlement: {
          vatInformation: {
            categoryCode: VAT_CATEGORY_CODES.STANDARD,
            ratePercent: 20,
          },
          // BT-131 = (qté 1 × prix 2500) − remise ligne 250 = 2250 (BR-CO-10).
          netLineAmount: 2250,
          lineBillingPeriod: {
            startDate: { value: "20260401", format: "102" },
            endDate: { value: "20260630", format: "102" },
          },
          lineAllowances: [
            {
              isCharge: false,
              actualAmount: 250,
              reason: "Remise fidélité",
              reasonCode: "95",
            },
          ],
        },
      },
      {
        lineID: "2",
        product: {
          name: "Frais déplacement",
          countryOfOriginCode: "FR",
        },
        tradeAgreement: { netPrice: 150 },
        tradeDelivery: { billedQuantity: 2, unitCode: UNIT_CODES.DAY },
        tradeSettlement: {
          vatInformation: {
            categoryCode: VAT_CATEGORY_CODES.STANDARD,
            ratePercent: 20,
          },
          netLineAmount: 300,
        },
      },
    ],
    tradeAgreement: {
      sellerTradeParty: {
        name: "Société Émettrice SAS",
        tradingName: "Émettrice [EN16931 sample]",
        postalAddress: {
          countryCode: "FR",
          postalCode: "75008",
          cityName: "Paris",
          lineOne: "10 avenue des Champs-Élysées",
        },
        legalRegistrationID: {
          value: "111111111",
          schemeID: SCHEME_IDS.SIREN_SIRET,
        },
        vatID: { value: "FR11111111111", schemeID: SCHEME_IDS.VAT },
        electronicAddress: { value: "EN16931-emetteur", schemeID: "0225" },
        definedContacts: [
          {
            personName: "Service Facturation",
            telephoneNumber: "+33145789200",
            emailAddress: "facturation@emettrice.fr",
          },
        ],
      },
      buyerTradeParty: {
        name: "Société Réceptrice SARL",
        postalAddress: {
          countryCode: "FR",
          postalCode: "69001",
          cityName: "Lyon",
          lineOne: "5 rue de la République",
        },
        legalRegistrationID: {
          value: "222222222",
          schemeID: SCHEME_IDS.SIREN_SIRET,
        },
        vatID: { value: "FR22222222222", schemeID: SCHEME_IDS.VAT },
        electronicAddress: { value: "EN16931-receveur", schemeID: "0225" },
      },
      // BG-11 SellerTaxRepresentative (cardinalité 0..1 EN16931, exercé ici).
      sellerTaxRepresentative: {
        name: "Cabinet Représentant Fiscal SAS",
        postalAddress: {
          countryCode: "FR",
          postalCode: "75002",
          cityName: "Paris",
          lineOne: "1 rue de la Bourse",
        },
        vatID: { value: "FR33333333333", schemeID: SCHEME_IDS.VAT },
      },
      buyerReference: "REF-CLIENT-EN16931",
      buyerOrderReference: "PO-2026-EN-789",
    },
    tradeDelivery: {
      // BG-13 ShipToTradeParty exercé.
      shipToPartyName: "Société Réceptrice — Site Lyon",
      deliveryAddress: {
        countryCode: "FR",
        postalCode: "69001",
        cityName: "Lyon",
        lineOne: "5 rue de la République",
      },
      actualDeliveryDate: { value: "20260420", format: "102" },
    },
    tradeSettlement: {
      invoiceCurrencyCode: "EUR",
      paymentReference: "FA-2026-EN-001",
      vatBreakdowns: [
        {
          // Base = 2250 (ligne 1 nette) + 300 (ligne 2) = 2550 ; TVA 20 % = 510.
          taxBasisAmount: 2550,
          calculatedAmount: 510,
          categoryCode: VAT_CATEGORY_CODES.STANDARD,
          ratePercent: 20,
        },
      ],
      monetarySummation: {
        // BT-106 lineTotalAmount = Σ BT-131 = 2250 + 300 = 2550.
        lineTotalAmount: 2550,
        // Pas de remise document-level → BT-107 absent.
        // BT-109 taxBasisTotalAmount = Σ BT-131 = 2550 (BR-CO-13).
        taxBasisTotalAmount: 2550,
        vatTotalAmount: { value: 510, currencyID: "EUR" },
        grandTotalAmount: 3060,
        duePayableAmount: 3060,
      },
      paymentTermsDescription: "Règlement à 30 jours fin de mois",
      dueDate: { value: "20260531", format: "102" },
      paymentMeans: [
        {
          typeCode: PAYMENT_MEANS_CODES.SEPA_CREDIT_TRANSFER,
          information: "Virement IBAN",
          payeeFinancialAccounts: [
            {
              accountID: { value: "FR7611111000011234567890121", schemeID: "IBAN" },
              accountName: "Société Émettrice SAS",
              financialInstitutionID: { value: "AGRIFRPP", schemeID: "BIC" },
            },
          ],
        },
      ],
      billingPeriod: {
        startDate: { value: "20260401", format: "102" },
        endDate: { value: "20260630", format: "102" },
      },
    },
  },
};
