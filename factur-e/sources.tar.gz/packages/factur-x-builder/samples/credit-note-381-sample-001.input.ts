// Sample Avoir total (BT-3 = 381) — sprint-07 V2 Axe B (T-CL-FACTURX-PDF-
// TEMPLATE-ENGINE). Exerce le template `credit-note.njk` : titre "Avoir",
// référence BG-3 facture origine (libellés verbatim LinkedInvoiceBanner W4).
// Structure alignée sur le sample EXTENDED (mêmes parties sandbox SuperPDP).

import type { CrossIndustryInvoice } from "@factur-e/factur-x-model";
import {
  FACTUR_X_PROFILES,
  INVOICE_TYPE_CODES,
  NOTE_SUBJECT_CODES,
  PAYMENT_MEANS_CODES,
  SCHEME_IDS,
  UNIT_CODES,
  VAT_CATEGORY_CODES,
} from "@factur-e/factur-x-model";

export const creditNote381Sample: CrossIndustryInvoice = {
  documentContext: {
    businessProcessID: "B1",
    specificationID: { value: FACTUR_X_PROFILES.EXTENDED },
  },
  exchangedDocument: {
    invoiceNumber: "AV-2026-EXT-001",
    invoiceTypeCode: INVOICE_TYPE_CODES.CREDIT_NOTE, // 381
    issueDate: { value: "20260420", format: "102" },
    includedNotes: [
      {
        content:
          "Indemnité forfaitaire pour frais de recouvrement en cas de retard de paiement : 40 €.",
        subjectCode: NOTE_SUBJECT_CODES.PAYMENT_TERMS,
      },
      {
        content:
          "Tout retard de paiement engendre une pénalité exigible à compter de la date d'échéance, calculée sur la base de trois fois le taux d'intérêt légal.",
        subjectCode: NOTE_SUBJECT_CODES.PAYMENT_MEANS_NOTE,
      },
      {
        content: "Les règlements reçus avant la date d'échéance ne donneront pas lieu à escompte.",
        subjectCode: NOTE_SUBJECT_CODES.ADDITIONAL_BUYER_REF,
      },
    ],
  },
  tradeTransaction: {
    lineItems: [
      {
        lineID: "1",
        product: {
          name: "Avoir prestation audit — forfait mensuel",
          countryOfOriginCode: "FR",
        },
        tradeAgreement: {
          netPrice: 1500,
          basisQuantity: 1,
          basisQuantityUnitCode: UNIT_CODES.MONTH,
        },
        tradeDelivery: { billedQuantity: 1, unitCode: UNIT_CODES.MONTH },
        tradeSettlement: {
          vatInformation: { categoryCode: VAT_CATEGORY_CODES.STANDARD, ratePercent: 20 },
          netLineAmount: 1500,
        },
      },
    ],
    tradeAgreement: {
      sellerTradeParty: {
        name: "Burger Queen",
        postalAddress: {
          countryCode: "FR",
          postalCode: "75008",
          cityName: "Paris",
          lineOne: "10 avenue des Champs-Élysées",
        },
        legalRegistrationID: { value: "000000002", schemeID: SCHEME_IDS.SIREN_SIRET },
        vatID: { value: "FR00000000002", schemeID: SCHEME_IDS.VAT },
        electronicAddress: { value: "315143296_3686", schemeID: "0225" },
      },
      buyerTradeParty: {
        name: "Tricatel",
        postalAddress: {
          countryCode: "FR",
          postalCode: "75011",
          cityName: "Paris",
          lineOne: "1 rue de l'Industrie",
        },
        legalRegistrationID: { value: "000000001", schemeID: SCHEME_IDS.SIREN_SIRET },
        electronicAddress: { value: "315143296_3685", schemeID: "0225" },
      },
      buyerReference: "REF-CLIENT-TRICATEL",
    },
    tradeDelivery: {},
    tradeSettlement: {
      invoiceCurrencyCode: "EUR",
      paymentReference: "AV-2026-EXT-001",
      vatBreakdowns: [
        {
          taxBasisAmount: 1500,
          calculatedAmount: 300,
          categoryCode: VAT_CATEGORY_CODES.STANDARD,
          ratePercent: 20,
        },
      ],
      monetarySummation: {
        lineTotalAmount: 1500,
        taxBasisTotalAmount: 1500,
        vatTotalAmount: { value: 300, currencyID: "EUR" },
        grandTotalAmount: 1800,
        duePayableAmount: 1800,
      },
      // BG-3 — facture d'origine annulée par cet avoir.
      precedingInvoices: [
        { invoiceNumber: "FA-2026-EXT-001", issueDate: { value: "20260415", format: "102" } },
      ],
      paymentTermsDescription: "Avoir imputable sur la prochaine facture.",
      dueDate: { value: "20260520", format: "102" },
      paymentMeans: [
        {
          typeCode: PAYMENT_MEANS_CODES.CREDIT_TRANSFER,
          payeeFinancialAccounts: [
            {
              accountID: { value: "FR7630006000011234567890189", schemeID: "IBAN" },
              accountName: "Burger Queen",
              financialInstitutionID: { value: "AGRIFRPP", schemeID: "BIC" },
            },
          ],
        },
      ],
    },
  },
};
