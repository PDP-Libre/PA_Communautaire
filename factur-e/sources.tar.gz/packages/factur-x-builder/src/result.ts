// Type Result<T, E> minimal — utilisé par `validateExtendedXsd` et toute API
// qui doit porter un succès ou une liste d'erreurs structurées sans exception.
//
// Choix : duplique le type équivalent de `@factur-e/factur-x-model` plutôt que
// de créer une dépendance pour ce seul utilitaire. T-CL-06 décidera s'il faut
// unifier (fusion en un type partagé `@factur-e/shared-types`) ou conserver la
// duplication minime (15 lignes).

export type Result<T, E> = { ok: true; value: T } | { ok: false; errors: E[] };

export function ok<T>(value: T): { ok: true; value: T } {
  return { ok: true, value };
}

export function err<E>(errors: E[]): { ok: false; errors: E[] } {
  return { ok: false, errors };
}
