// Surface publique de `@factur-e/factur-x-builder`.
//
// Pipeline complet :
//   modèle → `generateCII` → `validateExtendedXsd` → `assembleFacturXPdfA3`
//   → `structuralChecks` (fallback veraPDF).
//
// CLI exposés à la racine via `pnpm factur-x:generate-sample` et
// `pnpm factur-x:validate <pdf>` (cf. `scripts/factur-x/`).

export { generateCII } from "./generate-cii.js";
export {
  resetSchemaCache,
  validateExtendedXsd,
  validateXsd,
  type FacturXProfileKey,
  type ValidateXsdOutcome,
  XSD_PATH,
  type ValidationError,
} from "./validate-xsd.js";
export type { Result } from "./result.js";
export { err, ok } from "./result.js";
export * from "./xml/index.js";

// Cascade Schematron (S1 — validation métier FNFE câblée à l'émission).
export {
  type CascadeResult,
  type CascadeStepResult,
  type SchematronKey,
  type SvrlAssertion,
  schematronRuleLabel,
  validateCascade,
} from "./schematron/index.js";

// Constantes BR-FR-CTC-Flux2 + EXTENDED-CTC-FR V1.3.1 (listes fermées + gardes).
// Consommées par le builder ET par `apps/api` (restrictions A-strict + C1).
export * from "./constants/index.js";

// Helpers de sérialisation enrichis (défensifs anti-empty + EXTENDED-CTC-FR).
export { buildIncludedNote } from "./serialize/included-note.js";
export { buildApplicableProductCharacteristic, buildLineSubtype } from "./serialize/line-item.js";
export {
  buildAdditionalReferencedDocument,
  buildAttachmentDocument,
} from "./serialize/reference-document.js";
export {
  buildPayeeTradeParty,
  buildSellerTaxRepresentativeTradeParty,
} from "./serialize/trade-party.js";
export { buildDeliveryTermsIncoterm } from "./serialize/header-trade-agreement.js";
export {
  buildSpecifiedLogisticsServiceCharge,
  type LogisticsServiceCharge,
} from "./serialize/header-trade-settlement.js";

// PDF/A-3 assembly + validation (promu de spikes/pdfa3 à T-CL-06, cf. ADR-004).
export {
  assembleFacturXPdfA3,
  type AssembleInput,
  type PdfRenderContent,
} from "./pdf-assembly/assemble.js";
export { buildFacturXXmp, type XmpInput } from "./pdf-assembly/xmp.js";

// Moteur de template PDF facture (Axe B sprint-07 V2 — Nunjucks → HTML → pdf-lib).
export {
  renderInvoicePdfFromModel,
  renderInvoiceTextLines,
  type RenderInvoicePdfInput,
} from "./pdf-assembly/render-invoice-pdf.js";
export {
  buildTemplateContext,
  templateNameFor,
  type PdfEnrichment,
  type PdfLogo,
  type PdfSellerEnrichment,
  type PdfTemplateContext,
} from "./pdf-assembly/template-context.js";
export {
  renderInvoiceTemplate,
  formatAmountFr,
  formatDateFr,
  formatVatRateFr,
  resetTemplateEnv,
} from "./pdf-assembly/render-template.js";
export {
  parseHtmlToBlocks,
  type PdfBlock,
  type PdfTextBlock,
  type PdfTableBlock,
} from "./pdf-assembly/html-to-pdf-blocks.js";
export { paginateBlocks, LAYOUT } from "./pdf-assembly/pagination.js";
export { extractEmbeddedXml } from "./pdf-validation/extract-xml.js";
export { structuralChecks } from "./pdf-validation/structural-check.js";

// Parser de métadonnées (factures REÇUES, T-CL-RECV-API sprint-05 W2).
// Lecture seule CII/Factur-X + UBL — distinct du pipeline d'émission.
export { parseInvoiceMetadata } from "./parser/parse-invoice-metadata.js";
// Rendu PDF lisible « maison » (readable-view fallback XML pur, sprint-07 Axe B).
export { renderPdfFromXml } from "./pdf-render-from-xml.js";
export {
  InvoiceParsingError,
  type InvoiceFormat,
  type InvoiceMetadata,
  type ParsedSeller,
  type ParsedBuyer,
  type ParsedLine,
} from "./parser/types.js";
