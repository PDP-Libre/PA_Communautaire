// Sérialisation BG-5/BG-8/BG-12/BG-15 (PostalAddress) → `<ram:PostalTradeAddress>`.
// Référence : codebase-facturx-swift.md §3.3 + §9.1.
//
// Ordre XSD strict (§9.1) :
//   PostcodeCode → LineOne → LineTwo → LineThree → CityName → CountryID → CountrySubDivisionName.

import type { PostalAddress } from "@factur-e/factur-x-model";

import { ram, type XMLNode } from "../xml/index.js";

/**
 * Sérialise une adresse postale.
 * @param wrapperName  Nom de l'élément wrapper (`PostalTradeAddress` standard,
 *                     `PostalAddress` parfois pour ShipToTradeParty BG-15).
 */
export function serializePostalAddress(wrapperName: string, address: PostalAddress): XMLNode {
  const children: XMLNode[] = [];
  if (address.postalCode !== undefined) {
    children.push(ram("PostcodeCode", { text: address.postalCode }));
  }
  if (address.lineOne !== undefined) {
    children.push(ram("LineOne", { text: address.lineOne }));
  }
  if (address.lineTwo !== undefined) {
    children.push(ram("LineTwo", { text: address.lineTwo }));
  }
  if (address.lineThree !== undefined) {
    children.push(ram("LineThree", { text: address.lineThree }));
  }
  if (address.cityName !== undefined) {
    children.push(ram("CityName", { text: address.cityName }));
  }
  children.push(ram("CountryID", { text: address.countryCode }));
  if (address.countrySubDivisionName !== undefined) {
    children.push(ram("CountrySubDivisionName", { text: address.countrySubDivisionName }));
  }
  return ram(wrapperName, { children });
}
