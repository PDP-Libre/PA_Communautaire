// Sérialisation BG-4 / BG-7 / BG-10 / BG-11 (TradeParty et variantes).
// Référence : codebase-facturx-swift.md §5.11 + §9.4 #19/#22/#23/#24.
//
// Ordre XSD strict (TradePartyType) :
//   ID (0..n) → GlobalID (0..n) → Name → Description → SpecifiedLegalOrganization
//   → DefinedTradeContact (0..1 EN16931) → PostalTradeAddress
//   → URIUniversalCommunication → SpecifiedTaxRegistration (0..2).
//
// SpecifiedTaxRegistration peut contenir jusqu'à 2 blocs (XSD `maxOccurs="2"`) :
//   - BT-31/48/63 — vatID, schemeID="VA" forcé (BR-CO-9, bug §9.4 #21).
//   - BT-32 — taxRegistrationLocalID, schemeID="FC" forcé (bug §9.4 #19).
//
// PayeeTradeParty (BG-10) : restriction profil EN16931 — uniquement
// ID, Name, SpecifiedLegalOrganization (bug §9.4 #24).
// SellerTaxRepresentativeTradeParty (BG-11) : Name + PostalTradeAddress +
// SpecifiedTaxRegistration (cf. `serializeSellerTaxRepresentativeParty`).

import type { SellerTaxRepresentativeParty, TradeParty } from "@factur-e/factur-x-model";
import { SCHEME_IDS } from "@factur-e/factur-x-model";

import { ram, type XMLNode } from "../xml/index.js";
import {
  serializeEmailIdentifier,
  serializeIdentifier,
  serializeVatIdentifier,
} from "./identifier.js";
import { serializePostalAddress } from "./postal-address.js";
import { serializeTradeContact } from "./trade-contact.js";

/** Sérialise BG-4 (Seller) ou BG-7 (Buyer). */
export function serializeTradeParty(
  elementName: "SellerTradeParty" | "BuyerTradeParty",
  party: TradeParty,
): XMLNode {
  const children: XMLNode[] = [];

  // 2. GlobalID — BT-29/46 (skip ID local non modélisé pour le moment).
  if (party.globalID !== undefined) {
    children.push(serializeIdentifier("GlobalID", party.globalID));
  }

  // 3. Name (1..1).
  children.push(ram("Name", { text: party.name }));

  // 5. SpecifiedLegalOrganization — porte BT-30/47 (legalRegistrationID) +
  //    BT-28/45 (tradingName) sous TradingBusinessName.
  if (party.legalRegistrationID !== undefined || party.tradingName !== undefined) {
    const legalChildren: XMLNode[] = [];
    if (party.legalRegistrationID !== undefined) {
      legalChildren.push(serializeIdentifier("ID", party.legalRegistrationID));
    }
    if (party.tradingName !== undefined) {
      legalChildren.push(ram("TradingBusinessName", { text: party.tradingName }));
    }
    children.push(ram("SpecifiedLegalOrganization", { children: legalChildren }));
  }

  // 6. DefinedTradeContact — profil EN16931 = 0..1, on prend le premier.
  const contact = party.definedContacts?.[0];
  if (contact !== undefined) {
    children.push(serializeTradeContact(contact));
  }

  // 7. PostalTradeAddress (1..1).
  children.push(serializePostalAddress("PostalTradeAddress", party.postalAddress));

  // 8. URIUniversalCommunication — BT-34/49 electronicAddress, schemeID="EM" forcé.
  if (party.electronicAddress !== undefined) {
    children.push(
      ram("URIUniversalCommunication", {
        children: [serializeEmailIdentifier("URIID", party.electronicAddress)],
      }),
    );
  }

  // 9. SpecifiedTaxRegistration — BT-31/48 (vatID schemeID="VA") +
  //    BT-32 (taxRegistrationLocalID schemeID="FC", bug §9.4 #19).
  if (party.vatID !== undefined) {
    children.push(
      ram("SpecifiedTaxRegistration", {
        children: [serializeVatIdentifier("ID", party.vatID)],
      }),
    );
  }
  if (party.taxRegistrationLocalID !== undefined) {
    const localId =
      party.taxRegistrationLocalID.schemeID === undefined
        ? { value: party.taxRegistrationLocalID.value, schemeID: SCHEME_IDS.LOCAL_TAX_ID }
        : party.taxRegistrationLocalID;
    children.push(
      ram("SpecifiedTaxRegistration", {
        children: [serializeIdentifier("ID", localId)],
      }),
    );
  }

  return ram(elementName, { children });
}

/**
 * Sérialise BG-10 PayeeTradeParty — profil EN16931 restreint :
 * ID, Name, SpecifiedLegalOrganization uniquement (bug §9.4 #24).
 */
export function serializePayeeTradeParty(party: TradeParty): XMLNode {
  const children: XMLNode[] = [];
  if (party.globalID !== undefined) {
    children.push(serializeIdentifier("ID", party.globalID));
  }
  children.push(ram("Name", { text: party.name }));
  if (party.legalRegistrationID !== undefined) {
    children.push(
      ram("SpecifiedLegalOrganization", {
        children: [serializeIdentifier("ID", party.legalRegistrationID)],
      }),
    );
  }
  return ram("PayeeTradeParty", { children });
}

/**
 * Sérialise BG-11 SellerTaxRepresentativeTradeParty.
 * Ordre : Name → PostalTradeAddress → SpecifiedTaxRegistration (BT-63 schemeID="VA").
 */
export function serializeSellerTaxRepresentativeParty(rep: SellerTaxRepresentativeParty): XMLNode {
  return ram("SellerTaxRepresentativeTradeParty", {
    children: [
      ram("Name", { text: rep.name }),
      serializePostalAddress("PostalTradeAddress", rep.postalAddress),
      ram("SpecifiedTaxRegistration", {
        children: [serializeVatIdentifier("ID", rep.vatID)],
      }),
    ],
  });
}

/**
 * Helper défensif BG-10 PayeeTradeParty (BR-FR-09 + BR-FR-CO-10) — anti-empty.
 * Source : fnfe-ctc-v1.3.1-br-fr-flux2-schematron.md §6.1 (#4).
 * Retourne `undefined` si BG-10 absent ; sinon délègue à
 * `serializePayeeTradeParty` (ordre XSD préservé).
 */
export function buildPayeeTradeParty(party: TradeParty | undefined): XMLNode | undefined {
  if (party === undefined) return undefined;
  return serializePayeeTradeParty(party);
}

/**
 * Helper défensif BG-11 SellerTaxRepresentativeTradeParty (BR-FR-CO-15) — anti-empty.
 * Source : fnfe-ctc-v1.3.1-br-fr-flux2-schematron.md §6.1 (#5).
 * Retourne `undefined` si BG-11 absent ; sinon délègue à
 * `serializeSellerTaxRepresentativeParty`.
 */
export function buildSellerTaxRepresentativeTradeParty(
  rep: SellerTaxRepresentativeParty | undefined,
): XMLNode | undefined {
  if (rep === undefined) return undefined;
  return serializeSellerTaxRepresentativeParty(rep);
}
