// Sérialisation BG-2 ExchangedDocumentContext, BG-1 DocumentNote, et le bloc
// ExchangedDocument (header). Référence : codebase-facturx-swift.md §5.2 + §5.3.

import type {
  DocumentNote,
  ExchangedDocument,
  ExchangedDocumentContext,
} from "@factur-e/factur-x-model";

import { rsm, ram, type XMLNode } from "../xml/index.js";
import { serializeDateWrapper } from "./date.js";
import { serializeIdentifier } from "./identifier.js";
import { buildIncludedNote } from "./included-note.js";

/**
 * Sérialise BG-2 ExchangedDocumentContext.
 * Ordre :
 *   1. BusinessProcessSpecifiedDocumentContextParameter (0..1) → ID (BT-23)
 *   2. GuidelineSpecifiedDocumentContextParameter (1..1) → ID (BT-24, profil)
 */
export function serializeExchangedDocumentContext(ctx: ExchangedDocumentContext): XMLNode {
  const children: XMLNode[] = [];
  if (ctx.businessProcessID !== undefined) {
    children.push(
      ram("BusinessProcessSpecifiedDocumentContextParameter", {
        children: [ram("ID", { text: ctx.businessProcessID })],
      }),
    );
  }
  children.push(
    ram("GuidelineSpecifiedDocumentContextParameter", {
      children: [serializeIdentifier("ID", ctx.specificationID)],
    }),
  );
  return rsm("ExchangedDocumentContext", { children });
}

/**
 * Sérialise une note BG-1. Réutilise le helper défensif `buildIncludedNote`
 * quand le SubjectCode est présent (BR-FR-05/06) ; sinon émet la note
 * Content-seule (comportement historique préservé, sortie inchangée).
 */
function serializeDocumentNote(note: DocumentNote): XMLNode {
  const strict = buildIncludedNote(note.content, note.subjectCode);
  if (strict !== undefined) return strict;
  return ram("IncludedNote", { children: [ram("Content", { text: note.content })] });
}

/**
 * Sérialise le bloc rsm:ExchangedDocument.
 * Ordre :
 *   1. ID (BT-1) → 2. TypeCode (BT-3) → 3. IssueDateTime (BT-2) → 4. IncludedNote* (BG-1).
 */
export function serializeExchangedDocument(doc: ExchangedDocument): XMLNode {
  const children: XMLNode[] = [
    ram("ID", { text: doc.invoiceNumber }),
    ram("TypeCode", { text: doc.invoiceTypeCode }),
    serializeDateWrapper("IssueDateTime", doc.issueDate),
  ];
  if (doc.includedNotes !== undefined) {
    for (const n of doc.includedNotes) {
      children.push(serializeDocumentNote(n));
    }
  }
  return rsm("ExchangedDocument", { children });
}
