// Sérialisation BG-13 + BG-15 → ApplicableHeaderTradeDelivery.
// Référence : codebase-facturx-swift.md §5.14.
//
// Ordre XSD strict :
//   1. ShipToTradeParty (BG-13/BG-15)  — ID → GlobalID → Name → PostalTradeAddress
//   2. ActualDeliverySupplyChainEvent/OccurrenceDateTime (BT-72)
//   3. DespatchAdviceReferencedDocument (BT-16)
//   4. ReceivingAdviceReferencedDocument (BT-15)
//
// BR-57 (vérifiée par validateInvoice) : si BG-15 (deliveryAddress) émis,
// shipToPartyName (BT-70) est obligatoire — la sérialisation suppose que la
// validation BR-* a passé.

import type { HeaderTradeDelivery } from "@factur-e/factur-x-model";

import { ram, type XMLNode } from "../xml/index.js";
import { serializeDateWrapper } from "./date.js";
import { serializeIdentifier } from "./identifier.js";
import { serializePostalAddress } from "./postal-address.js";

function serializeShipToTradeParty(td: HeaderTradeDelivery): XMLNode | null {
  const hasShipTo =
    td.shipToPartyID !== undefined ||
    td.shipToPartyName !== undefined ||
    td.deliveryAddress !== undefined;
  if (!hasShipTo) return null;
  const children: XMLNode[] = [];
  if (td.shipToPartyID !== undefined) {
    children.push(serializeIdentifier("ID", td.shipToPartyID));
  }
  if (td.shipToPartyName !== undefined) {
    children.push(ram("Name", { text: td.shipToPartyName }));
  }
  if (td.deliveryAddress !== undefined) {
    children.push(serializePostalAddress("PostalTradeAddress", td.deliveryAddress));
  }
  return ram("ShipToTradeParty", { children });
}

export function serializeHeaderTradeDelivery(td: HeaderTradeDelivery): XMLNode {
  const children: XMLNode[] = [];
  const shipTo = serializeShipToTradeParty(td);
  if (shipTo !== null) {
    children.push(shipTo);
  }
  if (td.actualDeliveryDate !== undefined) {
    children.push(
      ram("ActualDeliverySupplyChainEvent", {
        children: [serializeDateWrapper("OccurrenceDateTime", td.actualDeliveryDate)],
      }),
    );
  }
  if (td.despatchAdviceReference !== undefined) {
    children.push(
      ram("DespatchAdviceReferencedDocument", {
        children: [ram("IssuerAssignedID", { text: td.despatchAdviceReference })],
      }),
    );
  }
  if (td.receivingAdviceReference !== undefined) {
    children.push(
      ram("ReceivingAdviceReferencedDocument", {
        children: [ram("IssuerAssignedID", { text: td.receivingAdviceReference })],
      }),
    );
  }
  return ram("ApplicableHeaderTradeDelivery", { children });
}
