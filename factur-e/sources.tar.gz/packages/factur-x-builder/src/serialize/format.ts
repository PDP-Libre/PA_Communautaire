// Helpers de formatage pour la sérialisation CII.
// Référence : codebase-facturx-swift.md §9.2 + §9.3.
//
// Toutes les valeurs numériques utilisent un point décimal POSIX (jamais
// `toLocaleString` qui peut introduire un séparateur localisé). 2 décimales
// pour montants et pourcentages, 4 pour quantités (cf. constantes
// `DECIMALS_AMOUNT` / `DECIMALS_QUANTITY` du modèle).

import { DECIMALS_AMOUNT, DECIMALS_QUANTITY } from "@factur-e/factur-x-model";

/** Formate un montant à 2 décimales avec point POSIX. Ex: 12 → "12.00". */
export function formatAmount(value: number): string {
  return value.toFixed(DECIMALS_AMOUNT);
}

/** Formate un pourcentage à 2 décimales avec point POSIX. Ex: 20 → "20.00". */
export function formatPercent(value: number): string {
  return value.toFixed(DECIMALS_AMOUNT);
}

/** Formate une quantité à 4 décimales avec point POSIX. Ex: 1.5 → "1.5000". */
export function formatQuantity(value: number): string {
  return value.toFixed(DECIMALS_QUANTITY);
}
