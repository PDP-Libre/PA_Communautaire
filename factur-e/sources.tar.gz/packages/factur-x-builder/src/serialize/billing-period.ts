// Sérialisation BG-14 BillingPeriod (header) et BG-26 LineBillingPeriod.
// Référence : codebase-facturx-swift.md §5.15 + §5.X (line) + BR-CO-20.
//
// Wrapper XML : `<ram:BillingSpecifiedPeriod>` (mêmes éléments enfants header
// et ligne) — `StartDateTime` puis `EndDateTime`, avec `udt:DateTimeString`.
//
// BR-CO-20 (validateInvoice côté modèle) : si BG-14/BG-26 émis, au moins une
// des deux dates doit être présente. Le sérialiseur ne pose pas le wrapper
// si les deux dates sont undefined (économie de validation).

import type { BillingPeriod, LineBillingPeriod } from "@factur-e/factur-x-model";

import { ram, type XMLNode } from "../xml/index.js";
import { serializeDateWrapper } from "./date.js";

export function serializeBillingPeriod(period: BillingPeriod | LineBillingPeriod): XMLNode | null {
  if (period.startDate === undefined && period.endDate === undefined) {
    return null;
  }
  const children: XMLNode[] = [];
  if (period.startDate !== undefined) {
    children.push(serializeDateWrapper("StartDateTime", period.startDate));
  }
  if (period.endDate !== undefined) {
    children.push(serializeDateWrapper("EndDateTime", period.endDate));
  }
  return ram("BillingSpecifiedPeriod", { children });
}
