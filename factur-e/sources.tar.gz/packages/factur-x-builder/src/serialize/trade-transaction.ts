// Sérialisation rsm:SupplyChainTradeTransaction.
// Référence : codebase-facturx-swift.md §5.4.
//
// Ordre :
//   1. IncludedSupplyChainTradeLineItem (BG-25, 1..n)  ← LIGNES en premier
//   2. ApplicableHeaderTradeAgreement
//   3. ApplicableHeaderTradeDelivery
//   4. ApplicableHeaderTradeSettlement

import type { SupplyChainTradeTransaction } from "@factur-e/factur-x-model";

import { rsm, type XMLNode } from "../xml/index.js";
import { serializeHeaderTradeAgreement } from "./header-trade-agreement.js";
import { serializeHeaderTradeDelivery } from "./header-trade-delivery.js";
import { serializeHeaderTradeSettlement } from "./header-trade-settlement.js";
import { serializeLineItem } from "./line-item.js";

export function serializeSupplyChainTradeTransaction(tx: SupplyChainTradeTransaction): XMLNode {
  const children: XMLNode[] = [];

  for (const line of tx.lineItems) {
    children.push(serializeLineItem(line));
  }
  children.push(serializeHeaderTradeAgreement(tx.tradeAgreement));
  children.push(serializeHeaderTradeDelivery(tx.tradeDelivery));
  children.push(serializeHeaderTradeSettlement(tx.tradeSettlement));

  return rsm("SupplyChainTradeTransaction", { children });
}
