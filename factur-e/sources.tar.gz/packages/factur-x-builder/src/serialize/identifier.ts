// Sérialisation `Identifier` → `<ram:Element schemeID="…">VALUE</ram:Element>`.
// Référence : codebase-facturx-swift.md §3.1 + §9.3.
//
// Defaults schemeID forcés (codebase-facturx-swift.md §9.3) :
//   - BT-31/48/63 (TVA) → schemeID="VA" (BR-CO-9, bug §9.4 #21).
//   - BT-34/49 (electronicAddress) → schemeID="EM" (déjà dans le doc Swift).

import type { Identifier } from "@factur-e/factur-x-model";
import { SCHEME_IDS } from "@factur-e/factur-x-model";

import { ram, type XMLNode } from "../xml/index.js";

/** Sérialise un `Identifier` quelconque. `schemeID` posé seulement si présent. */
export function serializeIdentifier(elementName: string, id: Identifier): XMLNode {
  return ram(elementName, {
    text: id.value,
    ...(id.schemeID !== undefined ? { attributes: { schemeID: id.schemeID } } : {}),
  });
}

/**
 * Sérialise un `Identifier` TVA — force `schemeID="VA"` si absent (BR-CO-9 +
 * bug §9.4 #21). Utilisé pour BT-31 (vendeur), BT-48 (acheteur), BT-63
 * (représentant fiscal).
 */
export function serializeVatIdentifier(elementName: string, id: Identifier): XMLNode {
  const schemeID = id.schemeID ?? SCHEME_IDS.VAT;
  return ram(elementName, {
    text: id.value,
    attributes: { schemeID },
  });
}

/**
 * Sérialise un `Identifier` adresse électronique — force `schemeID="EM"` si
 * absent (BR-49). Utilisé pour BT-34 (vendeur) et BT-49 (acheteur).
 */
export function serializeEmailIdentifier(elementName: string, id: Identifier): XMLNode {
  const schemeID = id.schemeID ?? SCHEME_IDS.EMAIL;
  return ram(elementName, {
    text: id.value,
    attributes: { schemeID },
  });
}
