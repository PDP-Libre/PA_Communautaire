// Sérialisation des montants CII.
// Référence : codebase-facturx-swift.md §3.1 + §9.2.
//
// Règle CII-DT-031 (EN16931 + Factur-X) : `@currencyID` est INTERDIT sur les
// montants SAUF `ram:TaxTotalAmount` (BT-110 devise BT-5 / BT-111 devise BT-6).
// L'appelant ne fournit donc `currencyID` que pour TaxTotalAmount ; partout
// ailleurs l'attribut est omis. (Correction sprint-06 du choix sprint-05 qui
// citait à tort BR-DEC-13/14 — règle de décimales, sans rapport avec la devise.)

import { ram, type XMLNode } from "../xml/index.js";
import { formatAmount } from "./format.js";

/**
 * Sérialise un montant scalaire `<ram:Element currencyID="EUR">12.34</ram:Element>`.
 * Le `currencyID` est requis pour les amounts du document — l'appelant le passe.
 *
 * @param elementName  Nom de l'élément `ram:` (ex : `LineTotalAmount`).
 * @param value        Valeur numérique (formatée avec 2 décimales POSIX).
 * @param currencyID   Code ISO 4217 (BT-5 typique : "EUR"). Optionnel pour les
 *                     amounts de ligne (BG-29 BT-146/148/149) qui n'en portent pas.
 */
export function serializeAmount(elementName: string, value: number, currencyID?: string): XMLNode {
  return ram(elementName, {
    text: formatAmount(value),
    ...(currencyID !== undefined ? { attributes: { currencyID } } : {}),
  });
}
