// Sérialisation BG-23 ApplicableTradeTax (header) → ram:ApplicableTradeTax.
// Référence : codebase-facturx-swift.md §5.16 + §9.4 #7.
//
// Ordre XSD strict (TradeTaxType, header) — DIFFÉRENT de la TVA ligne :
//   CalculatedAmount → TypeCode("VAT") → ExemptionReason → BasisAmount →
//   CategoryCode → ExemptionReasonCode → RateApplicablePercent.

import type { VATBreakdown } from "@factur-e/factur-x-model";
import { TAX_TYPE_VAT } from "@factur-e/factur-x-model";

import { ram, type XMLNode } from "../xml/index.js";
import { serializeAmount } from "./amount.js";
import { formatPercent } from "./format.js";

// CII-DT-031 : CalculatedAmount / BasisAmount ne portent PAS @currencyID.
export function serializeVATBreakdown(vb: VATBreakdown): XMLNode {
  const children: XMLNode[] = [
    serializeAmount("CalculatedAmount", vb.calculatedAmount),
    ram("TypeCode", { text: TAX_TYPE_VAT }),
  ];
  if (vb.exemptionReason !== undefined) {
    children.push(ram("ExemptionReason", { text: vb.exemptionReason }));
  }
  children.push(serializeAmount("BasisAmount", vb.taxBasisAmount));
  children.push(ram("CategoryCode", { text: vb.categoryCode }));
  if (vb.exemptionReasonCode !== undefined) {
    children.push(ram("ExemptionReasonCode", { text: vb.exemptionReasonCode }));
  }
  if (vb.ratePercent !== undefined) {
    children.push(ram("RateApplicablePercent", { text: formatPercent(vb.ratePercent) }));
  }
  return ram("ApplicableTradeTax", { children });
}
