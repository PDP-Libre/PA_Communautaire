// Sérialisation BG-4 + BG-7 + BG-11 + BG-24 (header agreement).
// Référence : codebase-facturx-swift.md §5.10 + bug §9.4 #1.
//
// Ordre XSD strict :
//   1. BuyerReference (BT-10)
//   2. SellerTradeParty (BG-4)
//   3. BuyerTradeParty (BG-7)
//   4. SellerTaxRepresentativeTradeParty (BG-11)
//   5. SellerOrderReferencedDocument (BT-14)  ← bug §9.4 #1 — élément XML correct
//   6. BuyerOrderReferencedDocument (BT-13)
//   7. ContractReferencedDocument (BT-12)
//   8. AdditionalReferencedDocument (BG-24, 0..n)

import type { HeaderTradeAgreement } from "@factur-e/factur-x-model";

import { ram, type XMLNode } from "../xml/index.js";
import { FacturXCodeError, isValidIncotermFr } from "../constants/index.js";
import { serializeAdditionalReferencedDocument } from "./reference-document.js";
import { serializeSellerTaxRepresentativeParty, serializeTradeParty } from "./trade-party.js";

/**
 * Helper EXTENDED-CTC-FR — INCOTERM BT-X-22 `ram:ApplicableTradeDeliveryTerms /
 * ram:DeliveryTypeCode` (BR-FREXT-CL-27). Source :
 * fnfe-ctc-v1.3.1-extended-ctc-fr-schematron.md §4.3.
 * Retourne `undefined` si `incoterm` absent. Valide ∈ `INCOTERM_WHITELIST_FR`
 * (13 valeurs) — lève `FacturXCodeError` sinon. Ordre XSD : à placer APRÈS les
 * `*TradeParty` et AVANT les `*ReferencedDocument` dans
 * `ApplicableHeaderTradeAgreement`.
 */
export function buildDeliveryTermsIncoterm(incoterm: string | undefined): XMLNode | undefined {
  if (incoterm === undefined || incoterm.trim() === "") return undefined;
  if (!isValidIncotermFr(incoterm)) {
    throw new FacturXCodeError(
      `INCOTERM "${incoterm}" hors whitelist FR BR-FREXT-CL-27 (13 valeurs autorisées).`,
    );
  }
  return ram("ApplicableTradeDeliveryTerms", {
    children: [ram("DeliveryTypeCode", { text: incoterm })],
  });
}

function refDoc(elementName: string, value: string): XMLNode {
  return ram(elementName, {
    children: [ram("IssuerAssignedID", { text: value })],
  });
}

export function serializeHeaderTradeAgreement(ta: HeaderTradeAgreement): XMLNode {
  const children: XMLNode[] = [];

  if (ta.buyerReference !== undefined) {
    children.push(ram("BuyerReference", { text: ta.buyerReference }));
  }

  children.push(serializeTradeParty("SellerTradeParty", ta.sellerTradeParty));
  children.push(serializeTradeParty("BuyerTradeParty", ta.buyerTradeParty));

  if (ta.sellerTaxRepresentative !== undefined) {
    children.push(serializeSellerTaxRepresentativeParty(ta.sellerTaxRepresentative));
  }

  // BT-X-22 INCOTERM — ordre XSD : ApplicableTradeDeliveryTerms se place APRÈS
  // les *TradeParty (tax representative inclus) et AVANT les *ReferencedDocument
  // (cf. HeaderTradeAgreementType, CII-D22B ReusableAggregate). NB : le commentaire
  // historique du helper ("dernier enfant") est erroné — vérifié XSD.
  const deliveryTerms = buildDeliveryTermsIncoterm(ta.incoterm);
  if (deliveryTerms !== undefined) {
    children.push(deliveryTerms);
  }

  // BT-14 — SellerOrderReferencedDocument (et non SalesOrderReferencedDocument).
  if (ta.sellerOrderReference !== undefined) {
    children.push(refDoc("SellerOrderReferencedDocument", ta.sellerOrderReference));
  }
  if (ta.buyerOrderReference !== undefined) {
    children.push(refDoc("BuyerOrderReferencedDocument", ta.buyerOrderReference));
  }
  if (ta.contractReference !== undefined) {
    children.push(refDoc("ContractReferencedDocument", ta.contractReference));
  }

  if (ta.additionalReferencedDocuments !== undefined) {
    for (const doc of ta.additionalReferencedDocuments) {
      children.push(serializeAdditionalReferencedDocument(doc));
    }
  }

  return ram("ApplicableHeaderTradeAgreement", { children });
}
