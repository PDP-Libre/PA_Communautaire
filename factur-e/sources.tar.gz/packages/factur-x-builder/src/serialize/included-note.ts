// Helper défensif BG-1 IncludedNote — pattern anti-empty R008-like sélectif.
// Source : docs/standards/fnfe-ctc-v1.3.1-br-fr-flux2-schematron.md §6.1 (#1)
// + §2.2 (BR-FR-05 présence PMT/PMD/AAB, BR-FR-06 unicité, BR-FR-20/31 BAR).
//
// Enrichit la sérialisation existante (`serializeDocumentNote`,
// `serializeLineItem`) : produit un `IncludedNote` strict (Content + SubjectCode)
// ou `undefined` si l'un des deux est vide — évite d'émettre un élément vide qui
// échouerait BR-FR-05/06.

import { ram, type XMLNode } from "../xml/index.js";

function isBlank(s: string | undefined): boolean {
  return s === undefined || s.trim() === "";
}

/**
 * Construit un `ram:IncludedNote` strict (Content BT-21/BT-127 + SubjectCode
 * BT-21-0/BT-127-0). Retourne `undefined` si `content` OU `subjectCode` est vide.
 * Ordre XSD : Content → SubjectCode.
 */
export function buildIncludedNote(
  content: string | undefined,
  subjectCode: string | undefined,
): XMLNode | undefined {
  if (isBlank(content) || isBlank(subjectCode)) return undefined;
  return ram("IncludedNote", {
    children: [ram("Content", { text: content }), ram("SubjectCode", { text: subjectCode })],
  });
}
