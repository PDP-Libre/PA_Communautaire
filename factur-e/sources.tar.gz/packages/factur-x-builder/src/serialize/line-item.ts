// Sérialisation BG-25 SupplyChainTradeLineItem et ses sous-groupes
// (BG-26 à BG-32). Référence : codebase-facturx-swift.md §5.5 à §5.9 +
// bugs §9.4 #12/#13/#18.
//
// Structure :
//   IncludedSupplyChainTradeLineItem
//     ├ AssociatedDocumentLineDocument
//     │   ├ LineID (BT-126)
//     │   └ IncludedNote/Content (BT-127, 0..n)
//     ├ SpecifiedTradeProduct (BG-31)
//     │   ├ GlobalID → SellerAssignedID → BuyerAssignedID → Name → Description
//     │   ├ ApplicableProductCharacteristic (BG-32, n)
//     │   ├ DesignatedProductClassification/ClassCode (BT-158)
//     │   └ OriginTradeCountry/ID (BT-159)
//     ├ SpecifiedLineTradeAgreement (BG-29)
//     │   ├ BuyerOrderReferencedDocument/LineID (BT-133-line)
//     │   ├ GrossPriceProductTradePrice (BT-148/149)
//     │   │   ├ ChargeAmount
//     │   │   ├ BasisQuantity (4 dec)
//     │   │   └ AppliedTradeAllowanceCharge (BT-147)
//     │   │       ├ ChargeIndicator/Indicator(false)  ← bug §9.4 #12
//     │   │       └ ActualAmount
//     │   └ NetPriceProductTradePrice (BT-146/149)
//     ├ SpecifiedLineTradeDelivery
//     │   └ BilledQuantity (BT-129) avec unitCode (BT-130) — 4 dec
//     └ SpecifiedLineTradeSettlement
//         ├ ApplicableTradeTax (BG-30) : TypeCode("VAT") → CategoryCode → RateApplicablePercent
//         ├ BillingSpecifiedPeriod (BG-26)
//         ├ SpecifiedTradeAllowanceCharge (BG-27, false)
//         ├ SpecifiedTradeAllowanceCharge (BG-28, true)
//         ├ SpecifiedTradeSettlementLineMonetarySummation/LineTotalAmount (BT-131)
//         ├ AdditionalReferencedDocument (BT-128, TypeCode=130)  ← bug §9.4 #18
//         └ ReceivableSpecifiedTradeAccountingAccount/ID (BT-133-line)

import type {
  ItemAttribute,
  LineTradeAgreement,
  LineTradeDelivery,
  LineTradeSettlement,
  LineVATInformation,
  SupplyChainTradeLineItem,
  TradeProduct,
} from "@factur-e/factur-x-model";
import { TAX_TYPE_VAT } from "@factur-e/factur-x-model";

import { ram, udt, type XMLNode } from "../xml/index.js";
import { type LineSubtypeCode, isValidLineSubtype } from "../constants/index.js";
import { serializeAmount } from "./amount.js";
import { serializeLineAllowanceCharge } from "./allowance-charge.js";
import { serializeBillingPeriod } from "./billing-period.js";
import { formatPercent, formatQuantity } from "./format.js";
import { serializeIdentifier } from "./identifier.js";
import { serializeAdditionalReferencedDocument } from "./reference-document.js";

/**
 * Helper défensif BG-32 ApplicableProductCharacteristic (BR-FR-27/28) — anti-empty.
 * Source : fnfe-ctc-v1.3.1-br-fr-flux2-schematron.md §6.1 (#3) + §2.8.
 * Retourne `undefined` si `name` (BT-160) OU `value` (BT-161) est vide — évite
 * d'émettre une caractéristique vide qui échouerait BR-FR-27/BR-FR-28.
 * Ordre XSD : Description → Value.
 */
export function buildApplicableProductCharacteristic(
  name: string | undefined,
  value: string | undefined,
): XMLNode | undefined {
  if (name === undefined || name.trim() === "" || value === undefined || value.trim() === "") {
    return undefined;
  }
  return ram("ApplicableProductCharacteristic", {
    children: [ram("Description", { text: name }), ram("Value", { text: value })],
  });
}

/**
 * Helper EXTENDED-CTC-FR — sous-type de ligne `ram:LineStatusReasonCode`
 * (EXT-FR-FE-163 / BT-X-8) à placer dans `AssociatedDocumentLineDocument`.
 * Source : fnfe-ctc-v1.3.1-extended-ctc-fr-schematron.md §4 (BR-FREXT-05/06/08/
 * 11/12 + 22..27 + CO-04). Valeurs ∈ {DETAIL, GROUP, INFORMATION}.
 *
 * Retourne `undefined` si `subtype` absent OU égal à `DETAIL` (DETAIL = défaut
 * implicite, inutile de l'émettre). Lève si la valeur est hors énumération.
 */
export function buildLineSubtype(subtype: string | undefined): XMLNode | undefined {
  if (subtype === undefined || subtype.trim() === "" || subtype === "DETAIL") return undefined;
  if (!isValidLineSubtype(subtype)) {
    throw new Error(
      `Sous-type de ligne "${subtype}" hors énumération EXTENDED-CTC-FR {DETAIL, GROUP, INFORMATION}.`,
    );
  }
  const code: LineSubtypeCode = subtype;
  return ram("LineStatusReasonCode", { text: code });
}

function serializeProductCharacteristic(attr: ItemAttribute): XMLNode | undefined {
  return buildApplicableProductCharacteristic(attr.attributeName, attr.attributeValue);
}

function serializeTradeProduct(product: TradeProduct): XMLNode {
  const children: XMLNode[] = [];
  if (product.standardID !== undefined) {
    children.push(serializeIdentifier("GlobalID", product.standardID));
  }
  if (product.sellerAssignedID !== undefined) {
    children.push(serializeIdentifier("SellerAssignedID", product.sellerAssignedID));
  }
  if (product.buyerAssignedID !== undefined) {
    children.push(serializeIdentifier("BuyerAssignedID", product.buyerAssignedID));
  }
  children.push(ram("Name", { text: product.name }));
  if (product.description !== undefined) {
    children.push(ram("Description", { text: product.description }));
  }
  if (product.itemAttributes !== undefined) {
    for (const attr of product.itemAttributes) {
      const node = serializeProductCharacteristic(attr);
      if (node !== undefined) children.push(node);
    }
  }
  if (product.classificationID !== undefined) {
    children.push(
      ram("DesignatedProductClassification", {
        children: [serializeIdentifier("ClassCode", product.classificationID)],
      }),
    );
  }
  if (product.countryOfOriginCode !== undefined) {
    children.push(
      ram("OriginTradeCountry", {
        children: [ram("ID", { text: product.countryOfOriginCode })],
      }),
    );
  }
  return ram("SpecifiedTradeProduct", { children });
}

/**
 * Sérialise BG-29 SpecifiedLineTradeAgreement. Le `currencyID` n'est PAS
 * porté sur les amounts de prix (BT-146/148/147) — convention Factur-X
 * (les prix unitaires sont implicitement dans la devise du document).
 */
function serializeLineTradeAgreement(agreement: LineTradeAgreement): XMLNode {
  const children: XMLNode[] = [];

  if (agreement.buyerOrderLineReference !== undefined) {
    children.push(
      ram("BuyerOrderReferencedDocument", {
        children: [ram("LineID", { text: agreement.buyerOrderLineReference })],
      }),
    );
  }

  // GrossPriceProductTradePrice — émis seulement si grossPrice ou priceDiscount.
  if (agreement.grossPrice !== undefined || agreement.priceDiscount !== undefined) {
    const grossChildren: XMLNode[] = [];
    if (agreement.grossPrice !== undefined) {
      grossChildren.push(serializeAmount("ChargeAmount", agreement.grossPrice));
    }
    if (agreement.basisQuantity !== undefined && agreement.basisQuantityUnitCode !== undefined) {
      grossChildren.push(
        ram("BasisQuantity", {
          text: formatQuantity(agreement.basisQuantity),
          attributes: { unitCode: agreement.basisQuantityUnitCode },
        }),
      );
    }
    if (agreement.priceDiscount !== undefined) {
      // BT-147 — AppliedTradeAllowanceCharge avec ChargeIndicator=false (bug §9.4 #12).
      grossChildren.push(
        ram("AppliedTradeAllowanceCharge", {
          children: [
            ram("ChargeIndicator", {
              children: [udt("Indicator", { text: "false" })],
            }),
            serializeAmount("ActualAmount", agreement.priceDiscount),
          ],
        }),
      );
    }
    children.push(ram("GrossPriceProductTradePrice", { children: grossChildren }));
  }

  // NetPriceProductTradePrice — toujours émis.
  const netChildren: XMLNode[] = [serializeAmount("ChargeAmount", agreement.netPrice)];
  if (agreement.basisQuantity !== undefined && agreement.basisQuantityUnitCode !== undefined) {
    netChildren.push(
      ram("BasisQuantity", {
        text: formatQuantity(agreement.basisQuantity),
        attributes: { unitCode: agreement.basisQuantityUnitCode },
      }),
    );
  }
  children.push(ram("NetPriceProductTradePrice", { children: netChildren }));

  return ram("SpecifiedLineTradeAgreement", { children });
}

function serializeLineTradeDelivery(delivery: LineTradeDelivery): XMLNode {
  return ram("SpecifiedLineTradeDelivery", {
    children: [
      ram("BilledQuantity", {
        text: formatQuantity(delivery.billedQuantity),
        attributes: { unitCode: delivery.unitCode },
      }),
    ],
  });
}

function serializeLineVATInformation(info: LineVATInformation): XMLNode {
  // Ordre TVA ligne : TypeCode → CategoryCode → RateApplicablePercent.
  const children: XMLNode[] = [
    ram("TypeCode", { text: TAX_TYPE_VAT }),
    ram("CategoryCode", { text: info.categoryCode }),
  ];
  if (info.ratePercent !== undefined) {
    children.push(ram("RateApplicablePercent", { text: formatPercent(info.ratePercent) }));
  }
  return ram("ApplicableTradeTax", { children });
}

function serializeLineTradeSettlement(settlement: LineTradeSettlement): XMLNode {
  const children: XMLNode[] = [serializeLineVATInformation(settlement.vatInformation)];

  const period =
    settlement.lineBillingPeriod !== undefined
      ? serializeBillingPeriod(settlement.lineBillingPeriod)
      : null;
  if (period !== null) {
    children.push(period);
  }

  if (settlement.lineAllowances !== undefined) {
    for (const ac of settlement.lineAllowances) {
      children.push(serializeLineAllowanceCharge(ac));
    }
  }
  if (settlement.lineCharges !== undefined) {
    for (const ac of settlement.lineCharges) {
      children.push(serializeLineAllowanceCharge(ac));
    }
  }

  children.push(
    ram("SpecifiedTradeSettlementLineMonetarySummation", {
      // CII-DT-031 : LineTotalAmount ligne sans @currencyID.
      children: [serializeAmount("LineTotalAmount", settlement.netLineAmount)],
    }),
  );

  // BT-128 (bug §9.4 #18) — émet AdditionalReferencedDocument typeCode="130".
  if (settlement.invoicedObjectID !== undefined) {
    children.push(serializeAdditionalReferencedDocument(settlement.invoicedObjectID));
  }

  if (settlement.accountingReference !== undefined) {
    children.push(
      ram("ReceivableSpecifiedTradeAccountingAccount", {
        children: [ram("ID", { text: settlement.accountingReference })],
      }),
    );
  }

  return ram("SpecifiedLineTradeSettlement", { children });
}

/**
 * Sérialise BG-25 IncludedSupplyChainTradeLineItem.
 * @param line  Ligne de facture. CII-DT-031 : les amounts de ligne ne portent
 *              pas @currencyID (seul TaxTotalAmount header le porte).
 */
export function serializeLineItem(line: SupplyChainTradeLineItem): XMLNode {
  const associatedChildren: XMLNode[] = [ram("LineID", { text: line.lineID })];
  if (line.note !== undefined) {
    associatedChildren.push(
      ram("IncludedNote", {
        children: [ram("Content", { text: line.note })],
      }),
    );
  }

  return ram("IncludedSupplyChainTradeLineItem", {
    children: [
      ram("AssociatedDocumentLineDocument", { children: associatedChildren }),
      serializeTradeProduct(line.product),
      serializeLineTradeAgreement(line.tradeAgreement),
      serializeLineTradeDelivery(line.tradeDelivery),
      serializeLineTradeSettlement(line.tradeSettlement),
    ],
  });
}
