// Sérialisation `<ram:SpecifiedTradePaymentTerms>` — header BG-19-like (description
// libre + dueDate + mandate ID). Référence : codebase-facturx-swift.md §5.15.
//
// Ordre XSD strict :
//   Description (BT-20) → DueDateDateTime (BT-9) → DirectDebitMandateID (BT-89).
//
// BT-89 vit côté modèle dans `PaymentMeans.directDebitMandateID` (ergonomie
// data-first) — le sérialiseur le déplace ici pour respecter la XSD
// (bug §9.4 #17 du doc Swift).

import type { DateType, Identifier } from "@factur-e/factur-x-model";

import { ram, type XMLNode } from "../xml/index.js";
import { serializeDateWrapper } from "./date.js";

export interface PaymentTermsInput {
  description?: string;
  dueDate?: DateType;
  /** BT-89 — collecté depuis le premier `PaymentMeans.directDebitMandateID` rencontré. */
  directDebitMandateID?: Identifier;
}

export function serializePaymentTerms(input: PaymentTermsInput): XMLNode | null {
  const hasContent =
    input.description !== undefined ||
    input.dueDate !== undefined ||
    input.directDebitMandateID !== undefined;
  if (!hasContent) return null;

  const children: XMLNode[] = [];
  if (input.description !== undefined) {
    children.push(ram("Description", { text: input.description }));
  }
  if (input.dueDate !== undefined) {
    children.push(serializeDateWrapper("DueDateDateTime", input.dueDate));
  }
  if (input.directDebitMandateID !== undefined) {
    children.push(ram("DirectDebitMandateID", { text: input.directDebitMandateID.value }));
  }
  return ram("SpecifiedTradePaymentTerms", { children });
}
