// Sérialisation `DateType` → `<ram:Wrapper><udt:DateTimeString format="102">YYYYMMDD</udt:DateTimeString></ram:Wrapper>`.
// Référence : codebase-facturx-swift.md §3.1 + §9.3 + §9.4 #15.
//
// Particularité bug §9.4 #15 : `BT-26 FormattedIssueDateTime` (BG-3 — référence
// facture antérieure) utilise `<qdt:DateTimeString>` (et non `<udt:>`) car le
// type est `qdt:FormattedDateTimeType`. Le helper `serializeDate` ci-dessous
// expose un paramètre `qualified` pour basculer.

import type { DateType } from "@factur-e/factur-x-model";

import { qdt, ram, udt, type XMLNode } from "../xml/index.js";

/**
 * Sérialise un wrapper de date `<ram:Wrapper><udt:DateTimeString format="102">…</udt:DateTimeString></ram:Wrapper>`.
 * @param wrapperName Nom du wrapper `ram:` (ex : `IssueDateTime`, `OccurrenceDateTime`).
 * @param date        Le `DateType` à sérialiser.
 * @param qualified   Si vrai, utilise `<qdt:DateTimeString>` au lieu de `<udt:>`. Réservé à BT-26.
 */
export function serializeDateWrapper(
  wrapperName: string,
  date: DateType,
  qualified = false,
): XMLNode {
  const inner = qualified
    ? qdt("DateTimeString", { text: date.value, attributes: { format: date.format } })
    : udt("DateTimeString", { text: date.value, attributes: { format: date.format } });
  return ram(wrapperName, { children: [inner] });
}
