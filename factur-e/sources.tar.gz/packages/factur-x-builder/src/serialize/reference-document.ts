// Sérialisation BG-3 PrecedingInvoiceReference, BG-24 AdditionalReferencedDocument,
// BT-125 AttachedBinaryObject. Référence : codebase-facturx-swift.md §5.13 + §9.4 #2/#15.
//
// AdditionalReferencedDocument (BG-24) — ordre XSD strict (bug §9.4 #2) :
//   IssuerAssignedID → URIID → LineID → TypeCode → Name → AttachmentBinaryObject
//   → ReferenceTypeCode → FormattedIssueDateTime.
//
// PrecedingInvoiceReference (BG-3) — InvoiceReferencedDocument :
//   IssuerAssignedID (BT-25) → FormattedIssueDateTime (BT-26) avec `<qdt:>` (bug §9.4 #15).

import type {
  AdditionalReferenceDocument,
  AttachedBinaryObject,
  PrecedingInvoiceReference,
} from "@factur-e/factur-x-model";

import { ram, type XMLNode } from "../xml/index.js";
import { FacturXCodeError, isAllowedAttachmentCode } from "../constants/index.js";
import { serializeDateWrapper } from "./date.js";

/** TypeCode UNTDID 1153 d'une pièce jointe binaire (BG-24 / BT-125). */
const ATTACHMENT_TYPE_CODE = "916";

/**
 * Encode un `Uint8Array` en chaîne base64 standard (RFC 4648).
 * Node 22+ : `Buffer.from(...).toString("base64")` est dispo et déterministe.
 */
function encodeBase64(bytes: Uint8Array): string {
  return Buffer.from(bytes).toString("base64");
}

function serializeAttachedBinaryObject(obj: AttachedBinaryObject): XMLNode {
  return ram("AttachmentBinaryObject", {
    text: encodeBase64(obj.content),
    attributes: {
      filename: obj.filename,
      mimeCode: obj.mimeCode,
    },
  });
}

/**
 * Sérialise un AdditionalReferencedDocument (BG-24).
 * @param wrapperName  Nom de l'élément wrapper :
 *                     `AdditionalReferencedDocument` (BG-24 header / BT-128 ligne)
 *                     est le cas standard.
 */
export function serializeAdditionalReferencedDocument(
  doc: AdditionalReferenceDocument,
  wrapperName = "AdditionalReferencedDocument",
): XMLNode {
  const children: XMLNode[] = [ram("IssuerAssignedID", { text: doc.documentID })];
  if (doc.externalLocationURI !== undefined) {
    children.push(ram("URIID", { text: doc.externalLocationURI }));
  }
  // LineID — non modélisé (réservé BG-3 ligne) : skip.
  children.push(ram("TypeCode", { text: doc.typeCode }));
  if (doc.description !== undefined) {
    children.push(ram("Name", { text: doc.description }));
  }
  if (doc.attachedDocument !== undefined) {
    children.push(serializeAttachedBinaryObject(doc.attachedDocument));
  }
  if (doc.referenceTypeCode !== undefined) {
    children.push(ram("ReferenceTypeCode", { text: doc.referenceTypeCode }));
  }
  return ram(wrapperName, { children });
}

/**
 * Sérialise BG-3 InvoiceReferencedDocument (référence facture antérieure).
 * BT-26 utilise `<qdt:DateTimeString>` (bug §9.4 #15).
 */
export function serializePrecedingInvoiceReference(ref: PrecedingInvoiceReference): XMLNode {
  const children: XMLNode[] = [ram("IssuerAssignedID", { text: ref.invoiceNumber })];
  if (ref.issueDate !== undefined) {
    children.push(serializeDateWrapper("FormattedIssueDateTime", ref.issueDate, true));
  }
  return ram("InvoiceReferencedDocument", { children });
}

/**
 * Helper défensif BG-24 AdditionalReferencedDocument (BR-FR-17/18) — anti-empty.
 * Source : fnfe-ctc-v1.3.1-br-fr-flux2-schematron.md §6.1 (#2) + §2.7.
 * Retourne `undefined` si `name` (BT-123) est vide. Pour une pièce jointe
 * (`typeCode === "916"`), valide en amont que `name` ∈ liste fermée
 * `ALLOWED_ATTACHMENT_CODES_V131` (BR-FR-17) — lève `FacturXCodeError` sinon.
 * Réutilise `serializeAdditionalReferencedDocument` (ordre XSD préservé).
 */
export function buildAdditionalReferencedDocument(
  name: string | undefined,
  typeCode: string,
  opts: {
    documentID?: string;
    referenceTypeCode?: string;
    externalLocationURI?: string;
    attachment?: AttachedBinaryObject;
  } = {},
): XMLNode | undefined {
  if (name === undefined || name.trim() === "") return undefined;
  if (typeCode === ATTACHMENT_TYPE_CODE && !isAllowedAttachmentCode(name)) {
    throw new FacturXCodeError(
      `Nom de pièce jointe "${name}" hors liste fermée BR-FR-17 (TypeCode 916).`,
    );
  }
  const doc: AdditionalReferenceDocument = {
    documentID: opts.documentID ?? name,
    typeCode,
    description: name,
    referenceTypeCode: opts.referenceTypeCode,
    externalLocationURI: opts.externalLocationURI,
    attachedDocument: opts.attachment,
  };
  return serializeAdditionalReferencedDocument(doc);
}

/**
 * Helper défensif BT-125 pièce jointe binaire (BR-FR-17/18 + BR-FREXT-CL-24).
 * Source : fnfe-ctc-v1.3.1-br-fr-flux2-schematron.md §6.1 (#6).
 * Retourne `undefined` s'il n'y a pas de binaire à embarquer. Force
 * `TypeCode=916` et valide `name` ∈ liste fermée (via
 * `buildAdditionalReferencedDocument`). `name` par défaut `LISIBLE`.
 */
export function buildAttachmentDocument(
  attachment: AttachedBinaryObject | undefined,
  name = "LISIBLE",
  documentID?: string,
): XMLNode | undefined {
  if (attachment === undefined) return undefined;
  return buildAdditionalReferencedDocument(name, ATTACHMENT_TYPE_CODE, {
    attachment,
    documentID: documentID ?? attachment.filename,
  });
}
