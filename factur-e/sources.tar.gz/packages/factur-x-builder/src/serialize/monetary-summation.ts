// Sérialisation BG-22 SpecifiedTradeSettlementHeaderMonetarySummation.
// Référence : codebase-facturx-swift.md §5.19 + §9.4 #6.
//
// Ordre XSD strict (TradeSettlementHeaderMonetarySummationType) :
//   1. LineTotalAmount (BT-106)
//   2. ChargeTotalAmount (BT-108)  — AVANT AllowanceTotalAmount (bug §9.4 #6)
//   3. AllowanceTotalAmount (BT-107)
//   4. TaxBasisTotalAmount (BT-109)
//   5. TaxTotalAmount currencyID=BT-5 (BT-110)
//   6. TaxTotalAmount currencyID=BT-6 (BT-111) — second bloc, devise comptabilisation
//   7. RoundingAmount (BT-114)
//   8. GrandTotalAmount (BT-112)
//   9. TotalPrepaidAmount (BT-113)
//  10. DuePayableAmount (BT-115)
//
// Règle CII-DT-031 (EN16931 + Factur-X) : `@currencyID` est INTERDIT sur les
// montants, SAUF `ram:TaxTotalAmount` (BT-110 devise facture BT-5 / BT-111 devise
// comptabilisation BT-6). Correction sprint-06 du choix sprint-05 qui propageait
// `currencyID` partout (commentaire mal-attribué BR-DEC-13/14 — qui concerne le
// nombre de décimales, pas la devise). Cf. T-CL-FACTURX-BUILDER-REFACTOR-CTC-FR.

import type { MonetarySummation } from "@factur-e/factur-x-model";

import { ram, type XMLNode } from "../xml/index.js";
import { serializeAmount } from "./amount.js";

export function serializeMonetarySummation(ms: MonetarySummation, currencyID: string): XMLNode {
  const children: XMLNode[] = [serializeAmount("LineTotalAmount", ms.lineTotalAmount)];
  if (ms.chargeTotalAmount !== undefined) {
    children.push(serializeAmount("ChargeTotalAmount", ms.chargeTotalAmount));
  }
  if (ms.allowanceTotalAmount !== undefined) {
    children.push(serializeAmount("AllowanceTotalAmount", ms.allowanceTotalAmount));
  }
  children.push(serializeAmount("TaxBasisTotalAmount", ms.taxBasisTotalAmount));
  // Seuls les TaxTotalAmount portent @currencyID (CII-DT-031).
  if (ms.vatTotalAmount !== undefined) {
    children.push(
      serializeAmount(
        "TaxTotalAmount",
        ms.vatTotalAmount.value,
        ms.vatTotalAmount.currencyID ?? currencyID,
      ),
    );
  }
  if (ms.taxCurrencyVATTotalAmount !== undefined) {
    children.push(
      serializeAmount(
        "TaxTotalAmount",
        ms.taxCurrencyVATTotalAmount.value,
        ms.taxCurrencyVATTotalAmount.currencyID ?? currencyID,
      ),
    );
  }
  if (ms.roundingAmount !== undefined) {
    children.push(serializeAmount("RoundingAmount", ms.roundingAmount));
  }
  children.push(serializeAmount("GrandTotalAmount", ms.grandTotalAmount));
  if (ms.paidAmount !== undefined) {
    children.push(serializeAmount("TotalPrepaidAmount", ms.paidAmount));
  }
  children.push(serializeAmount("DuePayableAmount", ms.duePayableAmount));

  return ram("SpecifiedTradeSettlementHeaderMonetarySummation", { children });
}
