// Sérialisation BG-3/10/14/16/20/21/22/23 + payment terms → ApplicableHeaderTradeSettlement.
// Référence : codebase-facturx-swift.md §5.15 + bugs §9.4 #4/#5/#17/#20/#25.
//
// Ordre XSD strict :
//    1. CreditorReferenceID (BT-90)                   ← bug §9.4 #20 (modèle)
//    2. PaymentReference (BT-83)
//    3. TaxCurrencyCode (BT-6)                        ← bug §9.4 #4 (avant InvoiceCurrencyCode)
//    4. InvoiceCurrencyCode (BT-5)
//    5. PayeeTradeParty (BG-10) — restreint
//    6. SpecifiedTradeSettlementPaymentMeans (BG-16, n blocs si multi-comptes)
//    7. ApplicableTradeTax (BG-23, 1..n)
//    8. BillingSpecifiedPeriod (BG-14)
//    9. SpecifiedTradeAllowanceCharge (BG-20, false)
//   10. SpecifiedTradeAllowanceCharge (BG-21, true)
//   11. SpecifiedTradePaymentTerms (BT-20 + BT-9 + BT-89 redirected)
//   12. SpecifiedTradeSettlementHeaderMonetarySummation (BG-22)
//   13. InvoiceReferencedDocument (BG-3)              ← bug §9.4 #5 (après BG-22)

import type { HeaderTradeSettlement, Identifier } from "@factur-e/factur-x-model";
import { TAX_TYPE_VAT } from "@factur-e/factur-x-model";

import { ram, type XMLNode } from "../xml/index.js";
import { serializeAmount } from "./amount.js";
import { serializeDocumentAllowanceCharge } from "./allowance-charge.js";
import { serializeBillingPeriod } from "./billing-period.js";
import { formatPercent } from "./format.js";
import { serializeMonetarySummation } from "./monetary-summation.js";
import { serializePaymentMeansBlocks } from "./payment.js";
import { serializePaymentTerms } from "./payment-terms.js";
import { serializePrecedingInvoiceReference } from "./reference-document.js";
import { serializePayeeTradeParty } from "./trade-party.js";
import { serializeVATBreakdown } from "./vat-breakdown.js";

/**
 * Charge logistique BT-X-272 (EXTENDED-CTC-FR). Donnée d'entrée du helper
 * `buildSpecifiedLogisticsServiceCharge` (non encore portée par le modèle —
 * cf. NOTE-COWORK extension modèle sprint-06+).
 */
export interface LogisticsServiceCharge {
  /** BT-X-273 — description de la prestation logistique. */
  description?: string;
  /** BT-X-272 — montant de la charge logistique (incluse dans BT-108). */
  appliedAmount: number;
  /** BT-X-274 — catégorie TVA appliquée (BR-FR-15). */
  vatCategoryCode: string;
  /** BT-X-275 — taux TVA appliqué. */
  vatRate?: number;
}

/**
 * Helper EXTENDED-CTC-FR — `ram:SpecifiedLogisticsServiceCharge` (BT-X-272,
 * BR-FREXT-CO-12 : Logistics inclus dans BT-108). Source :
 * fnfe-ctc-v1.3.1-extended-ctc-fr-schematron.md §7.3.
 * Retourne un tableau (vide si aucune charge). À insérer après
 * `SpecifiedTradeAllowanceCharge` et avant `SpecifiedTradePaymentTerms` (ordre XSD).
 */
export function buildSpecifiedLogisticsServiceCharge(
  charges: readonly LogisticsServiceCharge[] | undefined,
): XMLNode[] {
  if (charges === undefined || charges.length === 0) return [];
  return charges.map((c) => {
    const taxChildren: XMLNode[] = [
      ram("TypeCode", { text: TAX_TYPE_VAT }),
      ram("CategoryCode", { text: c.vatCategoryCode }),
    ];
    if (c.vatRate !== undefined) {
      taxChildren.push(ram("RateApplicablePercent", { text: formatPercent(c.vatRate) }));
    }
    const children: XMLNode[] = [];
    if (c.description !== undefined && c.description.trim() !== "") {
      children.push(ram("Description", { text: c.description }));
    }
    children.push(serializeAmount("AppliedAmount", c.appliedAmount));
    children.push(ram("AppliedTradeTax", { children: taxChildren }));
    return ram("SpecifiedLogisticsServiceCharge", { children });
  });
}

export function serializeHeaderTradeSettlement(ts: HeaderTradeSettlement): XMLNode {
  const currencyID = ts.invoiceCurrencyCode;
  const children: XMLNode[] = [];

  // 1. CreditorReferenceID (BT-90).
  if (ts.creditorReferenceID !== undefined) {
    children.push(ram("CreditorReferenceID", { text: ts.creditorReferenceID.value }));
  }

  // 2. PaymentReference (BT-83).
  if (ts.paymentReference !== undefined) {
    children.push(ram("PaymentReference", { text: ts.paymentReference }));
  }

  // 3. TaxCurrencyCode (BT-6) — AVANT InvoiceCurrencyCode.
  if (ts.vatAccountingCurrencyCode !== undefined) {
    children.push(ram("TaxCurrencyCode", { text: ts.vatAccountingCurrencyCode }));
  }

  // 4. InvoiceCurrencyCode (BT-5).
  children.push(ram("InvoiceCurrencyCode", { text: currencyID }));

  // 5. PayeeTradeParty (BG-10).
  if (ts.payeeParty !== undefined) {
    children.push(serializePayeeTradeParty(ts.payeeParty));
  }

  // 6. SpecifiedTradeSettlementPaymentMeans — n blocs si multi-comptes.
  // BT-89 (mandate) sera REDIRIGÉ vers SpecifiedTradePaymentTerms (cf. point 11).
  let collectedMandateID: Identifier | undefined;
  if (ts.paymentMeans !== undefined) {
    for (const pm of ts.paymentMeans) {
      // On retient le premier mandate ID rencontré pour PaymentTerms.
      if (collectedMandateID === undefined && pm.directDebitMandateID !== undefined) {
        collectedMandateID = pm.directDebitMandateID;
      }
      for (const block of serializePaymentMeansBlocks(pm)) {
        children.push(block);
      }
    }
  }

  // 7. ApplicableTradeTax (BG-23) — 1..n.
  for (const breakdown of ts.vatBreakdowns) {
    children.push(serializeVATBreakdown(breakdown));
  }

  // 8. BillingSpecifiedPeriod (BG-14).
  if (ts.billingPeriod !== undefined) {
    const period = serializeBillingPeriod(ts.billingPeriod);
    if (period !== null) children.push(period);
  }

  // 9. SpecifiedTradeAllowanceCharge — BG-20 (false).
  if (ts.documentAllowances !== undefined) {
    for (const ac of ts.documentAllowances) {
      children.push(serializeDocumentAllowanceCharge(ac));
    }
  }
  // 10. SpecifiedTradeAllowanceCharge — BG-21 (true).
  if (ts.documentCharges !== undefined) {
    for (const ac of ts.documentCharges) {
      children.push(serializeDocumentAllowanceCharge(ac));
    }
  }

  // 11. SpecifiedTradePaymentTerms (BT-20 + BT-9 + BT-89 redirected).
  const paymentTerms = serializePaymentTerms({
    description: ts.paymentTermsDescription,
    dueDate: ts.dueDate,
    directDebitMandateID: collectedMandateID,
  });
  if (paymentTerms !== null) children.push(paymentTerms);

  // 12. SpecifiedTradeSettlementHeaderMonetarySummation (BG-22).
  children.push(serializeMonetarySummation(ts.monetarySummation, currencyID));

  // 13. InvoiceReferencedDocument (BG-3) — APRÈS BG-22.
  if (ts.precedingInvoices !== undefined) {
    for (const ref of ts.precedingInvoices) {
      children.push(serializePrecedingInvoiceReference(ref));
    }
  }

  return ram("ApplicableHeaderTradeSettlement", { children });
}
