// Sérialisation `TradeContact` → `<ram:DefinedTradeContact>`.
// Référence : codebase-facturx-swift.md §3.3 + §5.11.
//
// Ordre XSD :
//   PersonName → TelephoneUniversalCommunication/CompleteNumber → EmailURIUniversalCommunication/URIID.
//
// Note profil EN16931 : 0..1 contact (bug §9.4 #23 — Swift ne borne pas).
// Le sérialiseur est appelé pour un seul contact ; la cardinalité côté
// `serializeTradeParty` limitera à 1 si besoin.

import type { TradeContact } from "@factur-e/factur-x-model";

import { ram, type XMLNode } from "../xml/index.js";

export function serializeTradeContact(contact: TradeContact): XMLNode {
  const children: XMLNode[] = [];
  if (contact.personName !== undefined) {
    children.push(ram("PersonName", { text: contact.personName }));
  }
  if (contact.telephoneNumber !== undefined) {
    children.push(
      ram("TelephoneUniversalCommunication", {
        children: [ram("CompleteNumber", { text: contact.telephoneNumber })],
      }),
    );
  }
  if (contact.emailAddress !== undefined) {
    children.push(
      ram("EmailURIUniversalCommunication", {
        children: [ram("URIID", { text: contact.emailAddress })],
      }),
    );
  }
  return ram("DefinedTradeContact", { children });
}
