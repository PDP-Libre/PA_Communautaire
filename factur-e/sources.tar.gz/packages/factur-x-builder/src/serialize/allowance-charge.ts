// Sérialisation BG-20/21 (header) et BG-27/28 (ligne) → SpecifiedTradeAllowanceCharge.
// Référence : codebase-facturx-swift.md §5.17 + §9.4 #8/#9/#10/#11/#12 + audit §8.
//
// Ordre XSD strict (TradeAllowanceChargeType) :
//   1. ChargeIndicator wrapper (bug §9.4 #8 — Swift n'avait pas le wrapper)
//      → udt:Indicator (true/false)
//   2. CalculationPercent (BT-94/101 / BT-137/142)
//   3. BasisAmount (BT-93/100 / BT-138/143, currencyID requis BR-DEC-13/14)
//   4. ActualAmount (BT-92/99 / BT-136/141, currencyID requis)
//   5. ReasonCode (BT-98/105 / BT-140/145)
//   6. Reason (BT-97/104 / BT-139/144) — BR-42/43 : Reason OU ReasonCode requis
//   7. CategoryTradeTax (header uniquement, BG-20/21) :
//      TypeCode "VAT" → CategoryCode (BT-95/102) → RateApplicablePercent (BT-96/103)
//
// Bug §9.4 #11 (CategoryTradeTax) : ordre TypeCode → CategoryCode → RateApplicablePercent
// (le Swift sortait CategoryCode → TypeCode).

import type { DocumentAllowanceCharge, LineAllowanceCharge } from "@factur-e/factur-x-model";
import { TAX_TYPE_VAT } from "@factur-e/factur-x-model";

import { ram, udt, type XMLNode } from "../xml/index.js";
import { serializeAmount } from "./amount.js";
import { formatPercent } from "./format.js";

function serializeChargeIndicator(isCharge: boolean): XMLNode {
  return ram("ChargeIndicator", {
    children: [udt("Indicator", { text: isCharge ? "true" : "false" })],
  });
}

/**
 * Sérialise une remise/charge au niveau document (BG-20 / BG-21) avec
 * `CategoryTradeTax` obligatoire pour rattacher à une ligne TVA.
 *
 * @param ac  Données. CII-DT-031 : BasisAmount/ActualAmount sans @currencyID.
 */
export function serializeDocumentAllowanceCharge(ac: DocumentAllowanceCharge): XMLNode {
  const children: XMLNode[] = [serializeChargeIndicator(ac.isCharge)];

  if (ac.calculationPercent !== undefined) {
    children.push(ram("CalculationPercent", { text: formatPercent(ac.calculationPercent) }));
  }
  if (ac.basisAmount !== undefined) {
    children.push(serializeAmount("BasisAmount", ac.basisAmount));
  }
  children.push(serializeAmount("ActualAmount", ac.actualAmount));

  if (ac.reasonCode !== undefined) {
    children.push(ram("ReasonCode", { text: ac.reasonCode }));
  }
  if (ac.reason !== undefined) {
    children.push(ram("Reason", { text: ac.reason }));
  }

  // CategoryTradeTax — TradeTaxType : TypeCode → CategoryCode → RateApplicablePercent.
  const taxChildren: XMLNode[] = [
    ram("TypeCode", { text: TAX_TYPE_VAT }),
    ram("CategoryCode", { text: ac.taxCategoryCode }),
  ];
  if (ac.taxPercent !== undefined) {
    taxChildren.push(ram("RateApplicablePercent", { text: formatPercent(ac.taxPercent) }));
  }
  children.push(ram("CategoryTradeTax", { children: taxChildren }));

  return ram("SpecifiedTradeAllowanceCharge", { children });
}

/**
 * Sérialise une remise/charge au niveau ligne (BG-27 / BG-28). Pas de
 * `CategoryTradeTax` — la TVA est portée par la ligne (BG-30).
 *
 * @param ac  Données. CII-DT-031 : BasisAmount/ActualAmount sans @currencyID.
 */
export function serializeLineAllowanceCharge(ac: LineAllowanceCharge): XMLNode {
  const children: XMLNode[] = [serializeChargeIndicator(ac.isCharge)];

  if (ac.calculationPercent !== undefined) {
    children.push(ram("CalculationPercent", { text: formatPercent(ac.calculationPercent) }));
  }
  if (ac.basisAmount !== undefined) {
    children.push(serializeAmount("BasisAmount", ac.basisAmount));
  }
  children.push(serializeAmount("ActualAmount", ac.actualAmount));

  if (ac.reasonCode !== undefined) {
    children.push(ram("ReasonCode", { text: ac.reasonCode }));
  }
  if (ac.reason !== undefined) {
    children.push(ram("Reason", { text: ac.reason }));
  }

  return ram("SpecifiedTradeAllowanceCharge", { children });
}
