// Sérialisation BG-16 SpecifiedTradeSettlementPaymentMeans + BG-17 + BG-18.
// Référence : codebase-facturx-swift.md §5.18 + §9.4 #14/#16/#25/#26.
//
// Ordre XSD strict (TradeSettlementPaymentMeansType) :
//   1. TypeCode (BT-81)
//   2. Information (BT-82)
//   3. ApplicableTradeSettlementFinancialCard (BG-18) : ID (BT-87) → CardholderName (BT-88)
//   4. PayerPartyDebtorFinancialAccount (BT-91) : IBANID
//   5. PayeePartyCreditorFinancialAccount (BG-17) : IBANID OR ProprietaryID + AccountName
//   6. PayeeSpecifiedCreditorFinancialInstitution : BICID (BT-86)
//
// Multi-comptes (bug §9.4 #25) : un bloc PaymentMeans XML par compte
// FinancialAccountDetails. Si `payeeFinancialAccounts` contient n entrées,
// on émet n blocs. Le caller (`serializeHeaderTradeSettlement`) doit
// itérer sur le résultat de `serializePaymentMeansBlocks`.
//
// IBAN vs ProprietaryID (bug §9.4 #26) : si `accountID.schemeID === "IBAN"`
// (ou absent — IBAN par défaut), on émet `<ram:IBANID>` ; sinon `<ram:ProprietaryID>`
// en texte direct (type udt:IDType, pas de wrapper <ram:ID> enfant).
//
// BT-89 (directDebitMandateID) : NON émis ici — sera émis dans
// `<ram:SpecifiedTradePaymentTerms>` (cf. `payment-terms.ts`).

import type {
  FinancialAccount,
  FinancialAccountDetails,
  PaymentCard,
  PaymentMeans,
} from "@factur-e/factur-x-model";

import { ram, type XMLNode } from "../xml/index.js";
import { serializeIdentifier } from "./identifier.js";

/** Type 84 IBAN — émet `<ram:IBANID>VALUE</ram:IBANID>`. Sinon `<ram:ProprietaryID>`. */
function serializeAccountID(accountID: { value: string; schemeID?: string }): XMLNode {
  const isIban = accountID.schemeID === undefined || accountID.schemeID === "IBAN";
  return ram(isIban ? "IBANID" : "ProprietaryID", { text: accountID.value });
}

function serializePaymentCard(card: PaymentCard): XMLNode {
  const children: XMLNode[] = [ram("ID", { text: card.primaryAccountNumber })];
  if (card.cardholderName !== undefined) {
    children.push(ram("CardholderName", { text: card.cardholderName }));
  }
  return ram("ApplicableTradeSettlementFinancialCard", { children });
}

function serializePayerFinancialAccount(account: FinancialAccount): XMLNode {
  return ram("PayerPartyDebtorFinancialAccount", {
    children: [serializeAccountID(account.accountID)],
  });
}

function serializePayeeFinancialAccount(details: FinancialAccountDetails): XMLNode {
  const children: XMLNode[] = [serializeAccountID(details.accountID)];
  if (details.accountName !== undefined) {
    children.push(ram("AccountName", { text: details.accountName }));
  }
  return ram("PayeePartyCreditorFinancialAccount", { children });
}

function serializeFinancialInstitution(details: FinancialAccountDetails): XMLNode | null {
  if (details.financialInstitutionID === undefined) return null;
  return ram("PayeeSpecifiedCreditorFinancialInstitution", {
    children: [serializeIdentifier("BICID", details.financialInstitutionID)],
  });
}

/** Construit le tronc commun (TypeCode/Information/Card/PayerAccount). */
function buildCommonChildren(pm: PaymentMeans): XMLNode[] {
  const children: XMLNode[] = [ram("TypeCode", { text: pm.typeCode })];
  if (pm.information !== undefined) {
    children.push(ram("Information", { text: pm.information }));
  }
  if (pm.paymentCard !== undefined) {
    children.push(serializePaymentCard(pm.paymentCard));
  }
  if (pm.payerFinancialAccount !== undefined) {
    children.push(serializePayerFinancialAccount(pm.payerFinancialAccount));
  }
  return children;
}

/**
 * Sérialise un (ou plusieurs) bloc(s) `SpecifiedTradeSettlementPaymentMeans`.
 * Si `payeeFinancialAccounts` contient n comptes, émet n blocs (bug §9.4 #25).
 * Si pas de compte, émet 1 bloc avec le tronc commun.
 */
export function serializePaymentMeansBlocks(pm: PaymentMeans): XMLNode[] {
  const accounts = pm.payeeFinancialAccounts ?? [];
  if (accounts.length === 0) {
    return [ram("SpecifiedTradeSettlementPaymentMeans", { children: buildCommonChildren(pm) })];
  }
  return accounts.map((details) => {
    const children = buildCommonChildren(pm);
    children.push(serializePayeeFinancialAccount(details));
    const institution = serializeFinancialInstitution(details);
    if (institution !== null) {
      children.push(institution);
    }
    return ram("SpecifiedTradeSettlementPaymentMeans", { children });
  });
}
