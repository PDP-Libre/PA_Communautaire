// Mini-DOM XML pour la sérialisation CII.
// Surface publique : type `XMLNode`, helpers de construction `ram/rsm/udt/qdt`,
// échappement, rendu déterministe.

export * from "./escape.js";
export * from "./namespaces.js";
export * from "./node.js";
export * from "./render.js";
