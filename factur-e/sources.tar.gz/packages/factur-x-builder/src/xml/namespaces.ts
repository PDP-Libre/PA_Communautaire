// Namespaces XML CII D22B utilisés par Factur-X.
// Référence : codebase-facturx-swift.md §4 + §9.3.
//
// Ces 4 namespaces sont déclarés sur la racine `<rsm:CrossIndustryInvoice>`
// uniquement (pas redéclarés sur les enfants — convention déterministe ADR-003).

export const RSM_NS = "urn:un:unece:uncefact:data:standard:CrossIndustryInvoice:100" as const;
export const RAM_NS =
  "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:100" as const;
export const UDT_NS = "urn:un:unece:uncefact:data:standard:UnqualifiedDataType:100" as const;
export const QDT_NS = "urn:un:unece:uncefact:data:standard:QualifiedDataType:100" as const;

/** Map prefix → URI. Tri alphabétique pour sortie déterministe (cf. ADR-003). */
export const ROOT_NAMESPACES = {
  qdt: QDT_NS,
  ram: RAM_NS,
  rsm: RSM_NS,
  udt: UDT_NS,
} as const;

export type NamespacePrefix = keyof typeof ROOT_NAMESPACES;
