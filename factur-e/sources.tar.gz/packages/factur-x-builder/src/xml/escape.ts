// Échappement XML strict — ordre `& < > " '` (codebase-facturx-swift.md §9.5).
//
// Ordre crucial : remplacer `&` EN PREMIER, sinon `&amp;` issu de `<` ou `>`
// se retrouve double-échappé en `&amp;amp;`. Test couvert dans
// `tests/xml/escape.test.ts` avec la chaîne `< & > " '`.

const REPLACEMENTS: readonly (readonly [RegExp, string])[] = [
  [/&/g, "&amp;"],
  [/</g, "&lt;"],
  [/>/g, "&gt;"],
  [/"/g, "&quot;"],
  [/'/g, "&apos;"],
];

/** Échappe une chaîne pour insertion dans un nœud XML (texte ou attribut). */
export function escapeXML(s: string): string {
  let result = s;
  for (const [pattern, replacement] of REPLACEMENTS) {
    result = result.replace(pattern, replacement);
  }
  return result;
}
