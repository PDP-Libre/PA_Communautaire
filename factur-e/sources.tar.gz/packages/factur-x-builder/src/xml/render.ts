// Sérialisation XML déterministe d'un `XMLNode`.
// Référence : codebase-facturx-swift.md §4 + §9.6.
//
// Conventions actées par ADR-003 D3 :
//   - Déclaration `<?xml version="1.0" encoding="UTF-8"?>` + `\n`.
//   - Indentation **4 espaces** par niveau.
//   - Tri alphabétique des attributs (`Object.keys(attrs).sort()`).
//   - Tri alphabétique des préfixes namespace sur la racine.
//   - Self-closing `<.../>` uniquement si pas de texte ET pas d'enfants.
//   - Échappement strict — ordre `& < > " '` (cf. `escape.ts`).
//   - Sortie byte-identique entre deux runs sur la même entrée.

import { escapeXML } from "./escape.js";
import type { XMLNode } from "./node.js";
import { ROOT_NAMESPACES } from "./namespaces.js";

const INDENT_UNIT = "    "; // 4 espaces (codebase-facturx-swift.md §4 + §9.6)
const XML_DECLARATION = '<?xml version="1.0" encoding="UTF-8"?>\n';

function renderAttributes(attrs: Readonly<Record<string, string>>): string {
  const keys = Object.keys(attrs).sort();
  return keys
    .map((k) => {
      const v = attrs[k] ?? "";
      return ` ${k}="${escapeXML(v)}"`;
    })
    .join("");
}

/**
 * Construit la chaîne d'attributs `xmlns:` triée alphabétiquement par préfixe.
 * Utilisée uniquement sur l'élément racine (cf. ADR-003 §"Conventions").
 */
function renderRootNamespaces(): string {
  const prefixes = Object.keys(ROOT_NAMESPACES).sort();
  return prefixes
    .map((p) => {
      const uri = ROOT_NAMESPACES[p as keyof typeof ROOT_NAMESPACES];
      return ` xmlns:${p}="${escapeXML(uri)}"`;
    })
    .join("");
}

interface RenderOptions {
  /** Si vrai, l'élément reçoit la déclaration des namespaces sur sa balise ouvrante. */
  isRoot?: boolean;
  /** Niveau d'indentation courant (0 pour la racine). */
  level?: number;
}

/**
 * Rend récursivement un `XMLNode` en chaîne XML indentée.
 *
 * @param node  Nœud à sérialiser.
 * @param opts  `isRoot` ajoute les `xmlns:` ; `level` pose l'indentation.
 * @returns     Chaîne XML (sans déclaration `<?xml?>` — utiliser `renderDocument` pour cela).
 */
export function renderElement(node: XMLNode, opts: RenderOptions = {}): string {
  const isRoot = opts.isRoot ?? false;
  const level = opts.level ?? 0;
  const indent = INDENT_UNIT.repeat(level);
  const tag = `${node.prefix}:${node.name}`;
  const namespaceDecl = isRoot ? renderRootNamespaces() : "";
  const attrsDecl = node.attributes !== undefined ? renderAttributes(node.attributes) : "";

  const hasText = node.text !== undefined;
  const hasChildren = node.children !== undefined && node.children.length > 0;

  // Self-closing : pas de texte ET pas d'enfants.
  if (!hasText && !hasChildren) {
    return `${indent}<${tag}${namespaceDecl}${attrsDecl}/>`;
  }

  // Text-only : balise ouvrante + texte échappé + balise fermante, sur une ligne.
  if (hasText && !hasChildren) {
    return `${indent}<${tag}${namespaceDecl}${attrsDecl}>${escapeXML(node.text ?? "")}</${tag}>`;
  }

  // Children : balise ouvrante, enfants indentés, balise fermante alignée.
  const childrenStr = (node.children ?? [])
    .map((c) => renderElement(c, { level: level + 1 }))
    .join("\n");
  return `${indent}<${tag}${namespaceDecl}${attrsDecl}>\n${childrenStr}\n${indent}</${tag}>`;
}

/**
 * Rend un document XML complet : déclaration `<?xml?>` + élément racine
 * (avec `xmlns:` sur la racine).
 */
export function renderDocument(root: XMLNode): string {
  return XML_DECLARATION + renderElement(root, { isRoot: true, level: 0 });
}
