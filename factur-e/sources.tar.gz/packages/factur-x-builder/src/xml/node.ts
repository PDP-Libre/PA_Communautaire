// Mini-DOM `XMLNode` — port direct du modèle Swift décrit dans
// codebase-facturx-swift.md §4. Volontairement minimaliste : pas de DTD,
// XPath, XSLT — uniquement ce qui est nécessaire à la sérialisation CII.
//
// Architecture data-first (ADR-003 D2) : `XMLNode` est un type pur, pas une
// classe avec méthodes. Les helpers `ram()`, `rsm()`, `udt()`, `qdt()`
// produisent des nœuds dans les bons préfixes namespace.

import type { NamespacePrefix } from "./namespaces.js";

export interface XMLNode {
  /** Nom local de l'élément (sans préfixe). Le préfixe vit dans `prefix`. */
  readonly name: string;
  /** Préfixe namespace (`rsm`/`ram`/`udt`/`qdt`). */
  readonly prefix: NamespacePrefix;
  /**
   * Attributs (clé → valeur). À la sérialisation, triés alphabétiquement par
   * clé (déterminisme — cf. ADR-003 §"Déterminisme").
   */
  readonly attributes?: Readonly<Record<string, string>>;
  /**
   * Contenu textuel (mutuellement exclusif avec `children` — un nœud porte
   * du texte OU des enfants, jamais les deux dans un même rendu).
   */
  readonly text?: string;
  /** Enfants — leur ordre est strictement préservé (ordre XSD imposé). */
  readonly children?: readonly XMLNode[];
}

/** Helper : crée un nœud avec préfixe `ram:`. */
export function ram(name: string, options: Omit<XMLNode, "name" | "prefix"> = {}): XMLNode {
  return { name, prefix: "ram", ...options };
}

/** Helper : crée un nœud avec préfixe `rsm:` (réservé à la racine et ses enfants directs). */
export function rsm(name: string, options: Omit<XMLNode, "name" | "prefix"> = {}): XMLNode {
  return { name, prefix: "rsm", ...options };
}

/** Helper : crée un nœud avec préfixe `udt:` (DateTimeString, Indicator, ...). */
export function udt(name: string, options: Omit<XMLNode, "name" | "prefix"> = {}): XMLNode {
  return { name, prefix: "udt", ...options };
}

/**
 * Helper : crée un nœud avec préfixe `qdt:`. Utilisé uniquement pour
 * `<qdt:DateTimeString>` du `FormattedIssueDateTime` BT-26 dans BG-3
 * (cf. codebase-facturx-swift.md §9.4 #15 — bug Swift à corriger).
 */
export function qdt(name: string, options: Omit<XMLNode, "name" | "prefix"> = {}): XMLNode {
  return { name, prefix: "qdt", ...options };
}
