// `generateCII(invoice)` — orchestration top-level de la sérialisation CII D22B.
// Référence : codebase-facturx-swift.md §5.1 (racine) + ADR-003 D3.
//
// Sortie déterministe byte-identique pour un même `invoice` (cf. ADR-003) :
//   - Indentation 4 espaces.
//   - Tri alphabétique des attributs et des préfixes namespace.
//   - Échappement strict (`& < > " '`).
//
// L'élément racine `<rsm:CrossIndustryInvoice>` porte les 4 namespaces
// (`qdt`/`ram`/`rsm`/`udt`) — pas de redéclaration sur les enfants.

import type { CrossIndustryInvoice } from "@factur-e/factur-x-model";

import { renderDocument, rsm, type XMLNode } from "./xml/index.js";
import {
  serializeExchangedDocument,
  serializeExchangedDocumentContext,
} from "./serialize/exchanged-document.js";
import { serializeSupplyChainTradeTransaction } from "./serialize/trade-transaction.js";

/**
 * Génère le XML CII D22B complet pour une facture EN 16931 / Factur-X.
 *
 * @param invoice  Facture validée (typée par `@factur-e/factur-x-model`).
 *                 NB : ne valide pas BR-* — appeler `validateInvoice` du
 *                 modèle en amont si besoin.
 * @returns        XML déterministe, prêt à être validé contre la XSD EXTENDED
 *                 (via `validateExtendedXsd`) puis embarqué dans un PDF/A-3.
 */
export function generateCII(invoice: CrossIndustryInvoice): string {
  const root: XMLNode = rsm("CrossIndustryInvoice", {
    children: [
      serializeExchangedDocumentContext(invoice.documentContext),
      serializeExchangedDocument(invoice.exchangedDocument),
      serializeSupplyChainTradeTransaction(invoice.tradeTransaction),
    ],
  });
  return renderDocument(root);
}
