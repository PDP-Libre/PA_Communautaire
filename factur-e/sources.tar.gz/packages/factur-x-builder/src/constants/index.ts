// Barrel constantes builder BR-FR-CTC-Flux2 + EXTENDED-CTC-FR V1.3.1.
// Localisation builder-local (Q3) — distinct des codes EN16931 génériques de
// `@factur-e/factur-x-model` (mutex strict, non touché).

export * from "./br-fr-codes.js";
export * from "./br-fr-formats.js";
