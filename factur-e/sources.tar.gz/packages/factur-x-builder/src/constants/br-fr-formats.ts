// Formats décimaux + identifiants BR-FR-CTC-Flux2 V1.3.1 — regex verbatim.
//
// Source de vérité (ADR-013 D3 verbatim) :
//   docs/standards/fnfe-ctc-v1.3.1-br-fr-flux2-schematron.md §2.1 + §2.11.
//
// Gardes amont builder : valident la forme sérialisée d'une valeur AVANT
// XSD/Schematron, pour produire un refus métier explicite plutôt qu'un échec
// Schematron opaque (cohérent apprentissage rétro sprint-05 #16).

/** BR-FR-DEC-01 — montants : max 19 chiffres, max 2 décimales, `-` autorisé. */
export const DECIMAL_19_2_RE = /^[-]?\d{1,19}(\.\d{1,2})?$/;

/** BR-FR-DEC-02 — quantités : max 19 chiffres, max 4 décimales, `-` autorisé. */
export const DECIMAL_19_4_RE = /^[-]?\d{1,19}(\.\d{1,4})?$/;

/** BR-FR-DEC-03 — prix unitaires positifs : max 19 chiffres, max 6 décimales. */
export const DECIMAL_19_6_POSITIVE_RE = /^\d{1,19}(\.\d{1,6})?$/;

/** BR-FR-DEC-04 — taux TVA positifs : max 4 chiffres, max 2 décimales. */
export const PERCENT_4_2_POSITIVE_RE = /^\d{1,4}(\.\d{1,2})?$/;

/** BR-FR-02 — format identifiant facture : `[A-Za-z0-9+\-_/]+` (sans espace, sans `.`). */
export const INVOICE_ID_FORMAT_RE = /^[A-Za-z0-9+\-_/]+$/;

/** BR-FR-01 — longueur max d'un identifiant de facture (BT-1 / BT-25). */
export const INVOICE_ID_MAX_LENGTH = 35;

/** Erreur métier builder — valeur hors format décimal BR-FR-DEC. */
export class FacturXFormatError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "FacturXFormatError";
  }
}

/** BR-FR-DEC-01 — vrai si la chaîne respecte le format montant 19/2. */
export function isValidAmount19_2(s: string): boolean {
  return DECIMAL_19_2_RE.test(s);
}

/** BR-FR-DEC-02 — vrai si la chaîne respecte le format quantité 19/4. */
export function isValidQuantity19_4(s: string): boolean {
  return DECIMAL_19_4_RE.test(s);
}

/** BR-FR-DEC-03 — vrai si la chaîne respecte le format prix unitaire 19/6 positif. */
export function isValidUnitPrice19_6(s: string): boolean {
  return DECIMAL_19_6_POSITIVE_RE.test(s);
}

/** BR-FR-DEC-04 — vrai si la chaîne respecte le format taux TVA 4/2 positif. */
export function isValidVatRate4_2(s: string): boolean {
  return PERCENT_4_2_POSITIVE_RE.test(s);
}

/**
 * BR-FR-DEC-01 — formate un montant (point POSIX, 2 décimales) et garantit la
 * conformité 19/2. Lève `FacturXFormatError` si la partie entière dépasse
 * 19 chiffres (cas impossible pour des montants réalistes — garde défensive).
 */
export function formatAmount19_2(value: number): string {
  const s = value.toFixed(2);
  if (!isValidAmount19_2(s)) {
    throw new FacturXFormatError(
      `Montant "${s}" hors format BR-FR-DEC-01 (^[-]?\\d{1,19}(\\.\\d{1,2})?$).`,
    );
  }
  return s;
}

/** BR-FR-DEC-02 — formate une quantité (point POSIX, 4 décimales) + garde 19/4. */
export function formatQuantity19_4(value: number): string {
  const s = value.toFixed(4);
  if (!isValidQuantity19_4(s)) {
    throw new FacturXFormatError(
      `Quantité "${s}" hors format BR-FR-DEC-02 (^[-]?\\d{1,19}(\\.\\d{1,4})?$).`,
    );
  }
  return s;
}

/** BR-FR-DEC-03 — formate un prix unitaire positif (point POSIX, 6 décimales) + garde 19/6. */
export function formatUnitPrice19_6(value: number): string {
  const s = value.toFixed(6);
  if (!isValidUnitPrice19_6(s)) {
    throw new FacturXFormatError(
      `Prix unitaire "${s}" hors format BR-FR-DEC-03 (^\\d{1,19}(\\.\\d{1,6})?$) — doit être positif.`,
    );
  }
  return s;
}

/** BR-FR-DEC-04 — formate un taux TVA positif (point POSIX, 2 décimales) + garde 4/2. */
export function formatVatRate4_2(value: number): string {
  const s = value.toFixed(2);
  if (!isValidVatRate4_2(s)) {
    throw new FacturXFormatError(
      `Taux TVA "${s}" hors format BR-FR-DEC-04 (^\\d{1,4}(\\.\\d{1,2})?$) — doit être positif ≤ 9999.99.`,
    );
  }
  return s;
}

/** BR-FR-01 + BR-FR-02 — vrai si l'identifiant respecte longueur ≤ 35 ET format. */
export function isValidInvoiceId(id: string): boolean {
  return id.length > 0 && id.length <= INVOICE_ID_MAX_LENGTH && INVOICE_ID_FORMAT_RE.test(id);
}

/**
 * BR-FR-01 + BR-FR-02 — assainit un identifiant de facture (BT-1 / BT-25) :
 *   - remplace tout caractère hors `[A-Za-z0-9+\-_/]` (espaces, `.`, etc.) par `-` ;
 *   - effondre les `-` consécutifs issus du remplacement ;
 *   - tronque à 35 caractères (BR-FR-01).
 * Idempotent sur une entrée déjà conforme. Lève si l'entrée est vide après
 * assainissement (aucun caractère exploitable).
 */
export function sanitizeInvoiceId(raw: string): string {
  const replaced = raw.replace(/[^A-Za-z0-9+\-_/]+/g, "-").replace(/-{2,}/g, "-");
  const trimmed = replaced.replace(/^-+|-+$/g, "");
  const sanitized = trimmed.slice(0, INVOICE_ID_MAX_LENGTH);
  if (sanitized.length === 0) {
    throw new FacturXFormatError(
      `Identifiant de facture "${raw}" vide après assainissement BR-FR-02 (aucun caractère [A-Za-z0-9+\\-_/]).`,
    );
  }
  return sanitized;
}
