// Constantes BR-FR-CTC-Flux2 + EXTENDED-CTC-FR V1.3.1 — listes fermées verbatim.
//
// Source de vérité (ADR-013 D3 verbatim, ADR-015 pipeline docs/standards) :
//   - docs/standards/fnfe-ctc-v1.3.1-br-fr-flux2-schematron.md §2
//   - docs/standards/fnfe-ctc-v1.3.1-extended-ctc-fr-schematron.md §4.3
//
// Ces listes pilotent la validation amont du builder (refus métier explicite
// AVANT XSD/Schematron — apprentissage rétro sprint-05 #16). Politique
// builder V1 plus stricte que l'EXTENDED-CTC-FR officiel : cf. ALLOWED_BILLING_MODES
// (exclut B8/S8/M8 cotraitance — arbitrage Bruno C1) et la garde A-strict O+S
// portée côté `apps/api/src/services/invoice-form-to-model.ts`.
//
// Localisation builder-local (Q3) : ces codes sont des règles CTC françaises
// propres au builder, distinctes des codes EN16931 génériques de
// `@factur-e/factur-x-model` (mutex strict, non touché ici).

/**
 * BR-FR-04 — Code type document ∈ liste fermée 16 codes UNTDID 1001.
 * Verbatim flux2 §2.1 : {380, 389, 393, 501, 386, 500, 384, 471, 472, 473,
 * 261, 262, 381, 396, 502, 503}.
 * Contextes : BT-3 (`ExchangedDocument/TypeCode`) + BT-3 ligne
 * (`InvoiceReferencedDocument/TypeCode`).
 */
export const ALLOWED_DOCUMENT_TYPE_CODES = [
  "380",
  "389",
  "393",
  "501",
  "386",
  "500",
  "384",
  "471",
  "472",
  "473",
  "261",
  "262",
  "381",
  "396",
  "502",
  "503",
] as const;

export type AllowedDocumentTypeCode = (typeof ALLOWED_DOCUMENT_TYPE_CODES)[number];

/**
 * BR-FR-08 — Mode de facturation BT-23 ∈ liste fermée.
 *
 * Le Schematron officiel autorise 17 modes dont B8/S8/M8 (= cotraitance
 * multi-vendor, déclenche 18 fatales BR-FR-MV-01..13). Politique Factur-E V1
 * (arbitrage Bruno C1) : **14 modes hors cotraitance**. La cotraitance est
 * backlog sprint-09+ post-réforme 2027 (pas de feature flag V1 — Z6).
 * Verbatim flux2 §2.3 (sous-ensemble des 17).
 */
export const ALLOWED_BILLING_MODES = [
  "B1",
  "S1",
  "M1",
  "B2",
  "S2",
  "M2",
  "S3",
  "B4",
  "S4",
  "M4",
  "S5",
  "S6",
  "B7",
  "S7",
] as const;

export type AllowedBillingMode = (typeof ALLOWED_BILLING_MODES)[number];

/** Modes cotraitance refusés V1 (BR-FR-MV fatales) — documentés pour le message d'erreur. */
export const COTRAITANCE_BILLING_MODES = ["B8", "S8", "M8"] as const;

/**
 * BR-FR-15 — CategoryCode TVA ∈ {S, E, AE, K, G, O, Z} (interdit L, M en France).
 * Verbatim flux2 §2.6. Contextes : BT-95/BT-102 (allowance/charge), BT-118
 * (header), BT-151 (ligne — tolérance lignes GROUP/INFORMATION sans code).
 */
export const ALLOWED_VAT_CATEGORY_CODES_FR = ["S", "E", "AE", "K", "G", "O", "Z"] as const;

export type AllowedVatCategoryCodeFr = (typeof ALLOWED_VAT_CATEGORY_CODES_FR)[number];

/**
 * BR-FR-16 — RateApplicablePercent ∈ liste taux français autorisés.
 * Verbatim flux2 §2.6 : 0/10/13/20 + 8.5/19.6/2.1/5.5/7/20.6/1.05/0.9/1.75/9.2/9.6
 * (+ variantes décimales — ex. "20.00", "5.50", gérées par `isValidFrVatRate`).
 * Contextes : BT-96/BT-103/BT-119/BT-152.
 */
export const ALLOWED_FR_VAT_RATES = [
  0, 10, 13, 20, 8.5, 19.6, 2.1, 5.5, 7, 20.6, 1.05, 0.9, 1.75, 9.2, 9.6,
] as const;

/**
 * BR-FR-17 — Nom pièce jointe ∈ liste fermée 12 valeurs (V1.3.1 ajoute
 * `RECAPITULATIF_COTRAITANCE`). Verbatim flux2 §2.7.
 * Contexte : `AdditionalReferencedDocument[TypeCode='916']/Name`.
 */
export const ALLOWED_ATTACHMENT_CODES_V131 = [
  "RIB",
  "LISIBLE",
  "FEUILLE_DE_STYLE",
  "PJA",
  "BORDEREAU_SUIVI",
  "DOCUMENT_ANNEXE",
  "BON_LIVRAISON",
  "BON_COMMANDE",
  "BORDEREAU_SUIVI_VALIDATION",
  "ETAT_ACOMPTE",
  "FACTURE_PAIEMENT_DIRECT",
  "RECAPITULATIF_COTRAITANCE",
] as const;

export type AllowedAttachmentCodeV131 = (typeof ALLOWED_ATTACHMENT_CODES_V131)[number];

/**
 * BR-FREXT-CL-27 — INCOTERM (BT-X-22 / DeliveryTypeCode) ∈ whitelist FR 13 valeurs
 * (vs UNTDID 4053 complet). Verbatim extended-ctc-fr §4.3 :
 * 1, 2, CFR, CIF, CIP, CPT, DAP, DDP, DPU, EXW, FAS, FCA, FOB.
 * Contexte : `ApplicableTradeDeliveryTerms/DeliveryTypeCode`.
 */
export const INCOTERM_WHITELIST_FR = [
  "1",
  "2",
  "CFR",
  "CIF",
  "CIP",
  "CPT",
  "DAP",
  "DDP",
  "DPU",
  "EXW",
  "FAS",
  "FCA",
  "FOB",
] as const;

export type IncotermFr = (typeof INCOTERM_WHITELIST_FR)[number];

/**
 * BR-FREXT-05/06/08/11/12 + BR-FREXT-22..27 + BR-FREXT-CO-04 — sous-type de ligne
 * `LineStatusReasonCode` (EXT-FR-FE-163 / BT-X-8) ∈ {DETAIL, GROUP, INFORMATION}.
 * DETAIL par défaut si absent. Verbatim extended-ctc-fr §4.
 */
export const LINE_SUBTYPE_CODES = ["DETAIL", "GROUP", "INFORMATION"] as const;

export type LineSubtypeCode = (typeof LINE_SUBTYPE_CODES)[number];

// ---------------------------------------------------------------------------
// Assertions / prédicats — gardes amont builder (avant XSD/Schematron).
// ---------------------------------------------------------------------------

/** Erreur métier builder — code refusé par une liste fermée BR-FR/BR-FREXT. */
export class FacturXCodeError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "FacturXCodeError";
  }
}

/** BR-FR-04 — vrai si `code` ∈ liste fermée 16 codes type document. */
export function isValidDocumentTypeCode(code: string): code is AllowedDocumentTypeCode {
  return (ALLOWED_DOCUMENT_TYPE_CODES as readonly string[]).includes(code);
}

/** BR-FR-04 — lève `FacturXCodeError` si `code` hors liste fermée. */
export function assertValidDocumentTypeCode(code: string): void {
  if (!isValidDocumentTypeCode(code)) {
    throw new FacturXCodeError(
      `Code type document BT-3 "${code}" hors liste fermée BR-FR-04 (${ALLOWED_DOCUMENT_TYPE_CODES.join(", ")}).`,
    );
  }
}

/** BR-FR-08 + C1 — vrai si `mode` ∈ 14 modes V1 (hors cotraitance B8/S8/M8). */
export function isAllowedBillingMode(mode: string): mode is AllowedBillingMode {
  return (ALLOWED_BILLING_MODES as readonly string[]).includes(mode);
}

/** BR-FR-15 — vrai si `code` ∈ {S, E, AE, K, G, O, Z}. */
export function isAllowedVatCategoryCodeFr(code: string): code is AllowedVatCategoryCodeFr {
  return (ALLOWED_VAT_CATEGORY_CODES_FR as readonly string[]).includes(code);
}

/**
 * BR-FR-16 — vrai si `rate` ∈ liste taux FR (tolère variantes décimales :
 * "20", "20.0", "20.00" valident tous le taux 20). Accepte number ou string.
 */
export function isValidFrVatRate(rate: number | string): boolean {
  const n = typeof rate === "number" ? rate : Number(rate);
  if (!Number.isFinite(n)) return false;
  // Comparaison tolérante au bruit flottant (taux à 2 décimales max).
  return (ALLOWED_FR_VAT_RATES as readonly number[]).some(
    (allowed) => Math.abs(allowed - n) < 1e-9,
  );
}

/** BR-FR-17 — vrai si `name` ∈ liste fermée 12 codes pièce jointe V1.3.1. */
export function isAllowedAttachmentCode(name: string): name is AllowedAttachmentCodeV131 {
  return (ALLOWED_ATTACHMENT_CODES_V131 as readonly string[]).includes(name);
}

/** BR-FREXT-CL-27 — vrai si `code` ∈ whitelist INCOTERM FR 13 valeurs. */
export function isValidIncotermFr(code: string): code is IncotermFr {
  return (INCOTERM_WHITELIST_FR as readonly string[]).includes(code);
}

/** Sous-type de ligne — vrai si `code` ∈ {DETAIL, GROUP, INFORMATION}. */
export function isValidLineSubtype(code: string): code is LineSubtypeCode {
  return (LINE_SUBTYPE_CODES as readonly string[]).includes(code);
}
