// Rendu PDF lisible « maison » d'une facture REÇUE au format XML pur (T-CL-RECV
// -READABLE-VIEW-CONVERSION sprint-07, Axe B). Cas d'usage : la Plateforme
// Agréée ne fournit pas de `docType=ReadableView` (XML pur entrant) → fallback
// transparent côté Acquéreur, zéro 415 sur la fiche réception.
//
// Z8 (récap pré-code, arbitrage Bruno) : rendu **réduit** depuis le parser léger
// `parseInvoiceMetadata` — PAS une reconstruction fidèle ni un PDF/A-3b + XML
// embarqué (≠ ré-émission Factur-X). La contrainte veraPDF 146/146 ne
// s'applique donc PAS à cette sortie (elle vaut pour l'émission W1). On rend
// uniquement les champs présents (dégradation propre du manquant) et on étiquette
// clairement « vue lisible reconstituée » ≠ document original. Le parser CII
// fidèle reste backlog (sprint-08+, cf. finding G reconstruction mode avancé).

import { PDFDocument, StandardFonts, rgb, type PDFFont, type PDFPage } from "pdf-lib";

import { parseInvoiceMetadata } from "./parser/parse-invoice-metadata.js";
import type { InvoiceMetadata } from "./parser/types.js";

const A4 = { width: 595.28, height: 841.89 } as const;
const MARGIN = 56;
const FG = rgb(0.12, 0.12, 0.12);
const MUTED = rgb(0.45, 0.45, 0.45);

const EUR = new Intl.NumberFormat("fr-FR", {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

/**
 * Remplace les espaces insécables/fins (U+00A0, U+202F séparateur de milliers
 * `Intl fr-FR`, U+2009) par une espace ASCII : la police standard Helvetica
 * (WinAnsi, non embarquée — sortie non PDF/A-3b Z8) ne sait pas les encoder.
 */
function winAnsiSafe(s: string): string {
  return s.replace(/[\u00A0\u202F\u2009]/g, " ");
}

/** Montant en centimes → « 1 234,56 € » (espaces ASCII, WinAnsi-safe). */
function euros(cents: number): string {
  return winAnsiSafe(`${EUR.format(cents / 100)} €`);
}

/** ISO `YYYY-MM-DD` → `DD/MM/YYYY` (best-effort, sinon valeur brute). */
function frDate(iso: string | undefined): string {
  if (iso === undefined) return "—";
  const [y, m, d] = iso.slice(0, 10).split("-");
  return y !== undefined && m !== undefined && d !== undefined ? `${d}/${m}/${y}` : iso;
}

const TYPE_LABELS: Record<string, string> = {
  "380": "Facture",
  "381": "Avoir",
  "384": "Facture rectificative",
};

function typeLabel(code: string): string {
  return TYPE_LABELS[code] ?? `Document ${code}`;
}

/** Curseur de dessin top-down avec pagination automatique. */
interface Cursor {
  page: PDFPage;
  y: number;
}

/**
 * Rend un PDF lisible réduit à partir du XML d'une facture reçue (CII /
 * Factur-X / UBL). Lève si le XML est illisible (`parseInvoiceMetadata`
 * `InvoiceParsingError`) — l'appelant retombe alors sur le 415.
 */
export async function renderPdfFromXml(xmlContent: string): Promise<Buffer> {
  const meta = parseInvoiceMetadata(xmlContent);
  const doc = await PDFDocument.create();
  const font = await doc.embedFont(StandardFonts.Helvetica);
  const bold = await doc.embedFont(StandardFonts.HelveticaBold);

  const cur: Cursor = { page: doc.addPage([A4.width, A4.height]), y: A4.height - MARGIN };
  const ensure = (needed: number): void => {
    if (cur.y - needed < MARGIN) {
      cur.page = doc.addPage([A4.width, A4.height]);
      cur.y = A4.height - MARGIN;
    }
  };
  const text = (s: string, opts: { size?: number; f?: PDFFont; color?: typeof FG } = {}): void => {
    const size = opts.size ?? 10;
    ensure(size + 4);
    cur.page.drawText(winAnsiSafe(s), {
      x: MARGIN,
      y: cur.y,
      size,
      font: opts.f ?? font,
      color: opts.color ?? FG,
    });
    cur.y -= size + 4;
  };
  const gap = (h = 8): void => {
    cur.y -= h;
  };

  // Étiquette « reconstituée » (Z8 — ce n'est pas le document original).
  text("Vue lisible reconstituée — généré par votre Plateforme Agréée à partir du XML reçu.", {
    size: 8,
    color: MUTED,
  });
  gap(6);

  // En-tête : type + numéro.
  text(`${typeLabel(meta.document.documentType)} ${meta.document.invoiceNumber}`, {
    size: 16,
    f: bold,
  });
  text(`Date d'émission : ${frDate(meta.document.issueDate)}`, { color: MUTED });
  if (meta.document.dueDate !== undefined) {
    text(`Échéance : ${frDate(meta.document.dueDate)}`, { color: MUTED });
  }
  gap();

  // Parties.
  text("Fournisseur", { f: bold });
  text(meta.parties.seller.name);
  text(`SIREN ${meta.parties.seller.siren}`, { color: MUTED });
  if (meta.parties.seller.address !== undefined)
    text(meta.parties.seller.address, { color: MUTED });
  gap();
  text("Acquéreur", { f: bold });
  text(meta.parties.buyer.name);
  text(`SIREN ${meta.parties.buyer.siren}`, { color: MUTED });
  gap();

  // Lignes (best-effort — dégradation propre si absentes).
  text("Détail", { f: bold });
  if (meta.lines.length === 0) {
    text("Détail des lignes non disponible.", { color: MUTED });
  } else {
    for (const line of meta.lines) {
      const lineTotal = euros(line.quantity * line.priceHt);
      text(
        `• ${line.description} — ${String(line.quantity)} × ${euros(line.priceHt)} = ${lineTotal}`,
      );
    }
  }
  gap();

  // Totaux.
  text("Totaux", { f: bold });
  text(`Total HT : ${euros(meta.totals.subtotalHt)}`);
  text(`TVA : ${euros(meta.totals.vatAmount)}`);
  text(`Total TTC : ${euros(meta.totals.totalTtc)}`, { f: bold });
  if (meta.totals.balanceDue !== meta.totals.totalTtc) {
    text(`Net à payer : ${euros(meta.totals.balanceDue)}`);
  }

  // Paiement (si présent).
  if (meta.paymentTerms?.iban !== undefined) {
    gap();
    text("Paiement", { f: bold });
    text(`IBAN : ${meta.paymentTerms.iban}`, { color: MUTED });
  }

  return Buffer.from(await doc.save());
}

export type { InvoiceMetadata };
