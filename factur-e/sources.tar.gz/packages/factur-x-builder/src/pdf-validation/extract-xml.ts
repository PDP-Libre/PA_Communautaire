// Extraction du XML CII embarqué dans un PDF Factur-X.
//
// Parcourt les indirect objects, trouve le premier `PDFRawStream` dont
// `/Subtype` vaut `text/xml` (ou la forme encodée `text#2Fxml`), décompresse
// si `FlateDecode` est appliqué, puis renvoie la chaîne UTF-8.
//
// Utilisé par le CLI `factur-x:validate` (cf. `src/cli/validate.ts`) et le
// test d'intégration bout-en-bout (cf. `tests/integration/e2e-pdfa3.test.ts`).

import { inflateSync } from "node:zlib";

import { PDFDocument, PDFName, PDFRawStream } from "pdf-lib";

function decodeIfFlate(stream: PDFRawStream): Uint8Array {
  const filter = stream.dict.lookup(PDFName.of("Filter"));
  const filterStr = filter === undefined ? "" : filter.toString();
  const raw = stream.contents;
  if (filterStr.includes("FlateDecode")) {
    return new Uint8Array(inflateSync(Buffer.from(raw)));
  }
  return raw;
}

/**
 * Extrait le XML embarqué (premier flux `Subtype=text/xml`).
 * Renvoie `null` si aucun flux de ce type n'est présent dans le PDF.
 */
export async function extractEmbeddedXml(pdfBytes: Uint8Array): Promise<string | null> {
  const pdfDoc = await PDFDocument.load(pdfBytes, { throwOnInvalidObject: false });
  for (const [, obj] of pdfDoc.context.enumerateIndirectObjects()) {
    if (!(obj instanceof PDFRawStream)) continue;
    const subtype = obj.dict.lookup(PDFName.of("Subtype"));
    if (subtype === undefined) continue;
    const subtypeStr = subtype.toString();
    if (!/text\/xml|text#2Fxml/i.test(subtypeStr)) continue;
    const decoded = decodeIfFlate(obj);
    return new TextDecoder().decode(decoded);
  }
  return null;
}
