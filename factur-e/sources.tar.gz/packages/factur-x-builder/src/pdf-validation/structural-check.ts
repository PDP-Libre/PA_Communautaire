// Fallback structurel : sans veraPDF, on vérifie la *forme* attendue d'un
// PDF/A-3 Factur-X. Ce n'est PAS une vraie validation PDF/A — veraPDF reste
// la référence pour la conformité (cf. ADR-004 §D4).
//
// Promu depuis `spikes/pdfa3/bin/structural-check.ts` à T-CL-06.
//
// Critères vérifiés :
//    1. Signature `%PDF-1.x` en tête (1.4 → 1.7 acceptés pour PDF/A-3).
//    2. Présence d'un OutputIntent avec `OutputConditionIdentifier (sRGB IEC61966-2.1)`.
//    3. Présence d'un dictionnaire `Metadata` (XMP) référencé par le Catalog.
//    4. XMP contient `pdfaid:part = 3` et `pdfaid:conformance = B`.
//    5. XMP contient le namespace `urn:factur-x:pdfa:CrossIndustryDocument:invoice:1p0#`.
//    6. XMP contient `fx:DocumentType = INVOICE` et `fx:DocumentFileName = factur-x.xml`.
//    7. Document Catalog porte un `/AF` array.
//    8. EmbeddedFiles contient une entrée `factur-x.xml`.
//    9. AFRelationship est `Alternative` (ou `Source`/`Data` — accepté en filière FR).
//   10. Trailer `/ID [<hex> <hex>]` (PDF/A-3 §6.1.3).
//   11. Au moins une font embarquée (FontFile2/3 stream — PDF/A-3 §6.2.11.4.1).
//
// Usage : `pnpm factur-x:validate <pdf>` (cf. scripts racine T-CL-06).
//          Ou direct : `tsx packages/factur-x-builder/src/pdf-validation/structural-check.ts <pdf>`.
// Exit code : 0 si tous les checks passent, 1 sinon (avec rapport détaillé sur stderr).

import { readFile } from "node:fs/promises";

interface CheckResult {
  name: string;
  ok: boolean;
  details?: string;
}

const FX_NAMESPACE = "urn:factur-x:pdfa:CrossIndustryDocument:invoice:1p0#";

function check(name: string, ok: boolean, details?: string): CheckResult {
  return details === undefined ? { name, ok } : { name, ok, details };
}

function structuralChecks(pdfBytes: Uint8Array): CheckResult[] {
  // PDF est binaire mais les marqueurs structurels qu'on cherche sont en ASCII.
  // On décode en latin-1 pour un mapping byte→char fidèle.
  const raw = Buffer.from(pdfBytes).toString("latin1");
  const checks: CheckResult[] = [];

  // 1. Signature PDF.
  const headerMatch = /^%PDF-1\.([4-7])/.exec(raw);
  checks.push(
    check(
      "PDF header version 1.4..1.7",
      headerMatch !== null,
      headerMatch === null ? `header: ${raw.slice(0, 20)}` : undefined,
    ),
  );

  // 2. OutputIntent sRGB.
  checks.push(
    check(
      "OutputIntent with sRGB IEC61966-2.1",
      raw.includes("/Type /OutputIntent") || raw.includes("/Type/OutputIntent"),
    ),
  );
  checks.push(
    check("OutputConditionIdentifier sRGB IEC61966-2.1", raw.includes("sRGB IEC61966-2.1")),
  );

  // 3 + 4. Metadata stream + PDF/A-3 part B.
  const hasMetadataStream = /\/Metadata\s+\d+\s+\d+\s+R/.test(raw);
  checks.push(check("Catalog references /Metadata stream", hasMetadataStream));

  // Extraction du XMP — entre les deux marqueurs `<?xpacket`. On cherche la
  // première occurrence de `<?xpacket begin=` puis le `<?xpacket end="w"?>`.
  const xmpStart = raw.indexOf("<?xpacket begin=");
  const xmpEnd = raw.indexOf('<?xpacket end="w"?>');
  const xmp = xmpStart !== -1 && xmpEnd > xmpStart ? raw.slice(xmpStart, xmpEnd + 22) : "";
  const hasXmp = xmp.length > 0;
  checks.push(check("XMP packet present", hasXmp));
  checks.push(
    check("XMP declares pdfaid:part 3", hasXmp && /<pdfaid:part>\s*3\s*<\/pdfaid:part>/.test(xmp)),
  );
  checks.push(
    check(
      "XMP declares pdfaid:conformance B",
      hasXmp && /<pdfaid:conformance>\s*B\s*<\/pdfaid:conformance>/.test(xmp),
    ),
  );

  // 5 + 6. Factur-X namespace + properties.
  checks.push(check("XMP declares Factur-X namespace", hasXmp && xmp.includes(FX_NAMESPACE)));
  checks.push(
    check(
      "XMP declares fx:DocumentType INVOICE",
      hasXmp && /<fx:DocumentType>\s*INVOICE\s*<\/fx:DocumentType>/.test(xmp),
    ),
  );
  checks.push(
    check(
      "XMP declares fx:DocumentFileName factur-x.xml",
      hasXmp && /<fx:DocumentFileName>\s*factur-x\.xml\s*<\/fx:DocumentFileName>/.test(xmp),
    ),
  );
  checks.push(
    check(
      "XMP declares pdfaExtension:schemas with fx prefix",
      hasXmp && /<pdfaSchema:prefix>\s*fx\s*<\/pdfaSchema:prefix>/.test(xmp),
    ),
  );

  // 7. Catalog AF.
  checks.push(check("Catalog has /AF entry", /\/AF\s*\[/.test(raw)));

  // 8. EmbeddedFiles entry.
  checks.push(
    check(
      "EmbeddedFiles contains factur-x.xml",
      raw.includes("factur-x.xml") && (raw.includes("/EmbeddedFiles") || raw.includes("/EF ")),
    ),
  );

  // 9. AFRelationship.
  const accepted = ["Alternative", "Source", "Data"];
  const found = accepted.find((rel) => raw.includes(`/AFRelationship /${rel}`));
  checks.push(
    check(
      "AFRelationship in {Alternative,Source,Data}",
      found !== undefined,
      found === undefined ? "no /AFRelationship found" : `using ${found}`,
    ),
  );

  // 10. Trailer /ID — paire d'identifiants exigée par PDF/A-3 §6.1.3.
  // Sérialisé en hexadécimal entre crochets, ex: `/ID [<abcdef…> <abcdef…>]`.
  checks.push(
    check(
      "Trailer /ID present (PDF/A-3 §6.1.3)",
      /\/ID\s*\[\s*<[0-9A-Fa-f]+>\s*<[0-9A-Fa-f]+>\s*\]/.test(raw),
    ),
  );

  // 11. Au moins une font embarquée (Subtype /TrueType ou /Type0 + /FontFile2/3).
  // Détection grossière mais suffisante pour signaler l'absence flagrante.
  checks.push(
    check(
      "At least one embedded font (FontFile2/3 stream)",
      /\/FontFile[23]\s+\d+\s+\d+\s+R/.test(raw),
    ),
  );

  return checks;
}

async function main(): Promise<void> {
  const arg = process.argv[2];
  if (arg === undefined) {
    process.stderr.write("usage: tsx structural-check.ts <pdf-path>\n");
    process.exit(2);
  }
  const bytes = await readFile(arg);
  const results = structuralChecks(new Uint8Array(bytes));
  let allOk = true;
  for (const r of results) {
    const symbol = r.ok ? "✓" : "✗";
    process.stdout.write(
      `${symbol} ${r.name}${r.details === undefined ? "" : ` — ${r.details}`}\n`,
    );
    if (!r.ok) allOk = false;
  }
  if (!allOk) {
    process.stderr.write(
      "\n[structural-check] FAIL — au moins un check a échoué. NB : ce fallback ne remplace pas veraPDF.\n",
    );
    process.exit(1);
  }
  process.stdout.write(
    "\n[structural-check] OK — structure compatible PDF/A-3 + Factur-X. Validation PDF/A complète : exécuter veraPDF (cf. bin/validate-pdfa.sh).\n",
  );
}

// CLI : exécute `main` uniquement quand le fichier est l'entry point (pas en import test).
const invokedDirectly =
  process.argv[1] !== undefined && import.meta.url === `file://${process.argv[1]}`;
if (invokedDirectly) {
  main().catch((err: unknown) => {
    process.stderr.write(`${String(err)}\n`);
    process.exit(1);
  });
}

export { structuralChecks };
