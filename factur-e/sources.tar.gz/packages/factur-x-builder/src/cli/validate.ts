// CLI : `pnpm factur-x:validate <pdf>`.
// Référence : plan.md sprint-01 T-CL-06 + CLAUDE.md §8.5 (slash command /factur-x-check).
//
// Validation Factur-X complète sur un PDF :
//   1. PDF/A-3 conformity → délégué à `bin/validate-pdfa.sh` (veraPDF officiel
//      si dispo, sinon structural-check Node-side).
//   2. XML CII embarqué (nom `factur-x.xml` strict, MIME `text/xml`,
//      AFRelationship dans {Alternative, Source, Data}).
//   3. XMP extension Factur-X (`fx:` namespace + DocumentType=INVOICE).
//   4. Validation XSD EXTENDED du XML extrait.
//
// Étapes 1 + 3 sont déjà couvertes par `structuralChecks` du fallback
// (16 vérifications). Étapes 2 + 4 ajoutées ici : extraction du XML
// embarqué + validation XSD via `validateExtendedXsd`.

import { spawnSync } from "node:child_process";
import { readFile } from "node:fs/promises";
import path from "node:path";

import { extractEmbeddedXml } from "../pdf-validation/extract-xml.js";
import { structuralChecks } from "../pdf-validation/structural-check.js";
import { type FacturXProfileKey, validateExtendedXsd } from "../validate-xsd.js";
import { validateCascade } from "../schematron/validate-cascade.js";

/** Profil émission depuis le préfixe du nom de fichier (défaut extended-ctc-fr). */
function detectProfile(pdfPath: string): FacturXProfileKey {
  return path.basename(pdfPath).toLowerCase().startsWith("en16931-")
    ? "en16931"
    : "extended-ctc-fr";
}

const REPO_ROOT = path.resolve(import.meta.dirname, "..", "..", "..", "..");
const VALIDATE_SCRIPT = path.join(REPO_ROOT, "bin", "validate-pdfa.sh");

interface ValidationStep {
  name: string;
  ok: boolean;
  details?: string;
}

function runStructuralCheck(pdfBytes: Uint8Array): ValidationStep[] {
  return structuralChecks(pdfBytes).map((r) => ({
    name: r.name,
    ok: r.ok,
    details: r.details,
  }));
}

function tryRunVeraPDF(pdfPath: string): ValidationStep | null {
  // Si validate-pdfa.sh existe, on l'invoque pour bénéficier de veraPDF
  // officiel. Sinon on signale qu'il manque (rare — toujours présent en repo).
  const result = spawnSync("bash", [VALIDATE_SCRIPT, pdfPath], {
    encoding: "utf-8",
    stdio: ["ignore", "pipe", "pipe"],
  });
  if (result.error !== undefined) {
    return null;
  }
  const ok = result.status === 0;
  return {
    name: "PDF/A-3b conformity (validate-pdfa.sh)",
    ok,
    details: ok ? "OK" : (result.stderr || result.stdout).split("\n").slice(-3).join(" / "),
  };
}

async function main(): Promise<void> {
  const args = process.argv.slice(2);
  const flagSchematron = args.includes("--schematron");
  const pdfPath = args.find((a) => !a.startsWith("--"));
  if (pdfPath === undefined) {
    process.stderr.write("usage: pnpm factur-x:validate [--schematron] <pdf-path>\n");
    process.exit(2);
  }

  process.stdout.write(`[factur-x:validate] ${pdfPath}\n\n`);

  const pdfBytes = await readFile(pdfPath);
  const steps: ValidationStep[] = [];

  // 1. Conformance PDF/A-3 (délégué à bin/validate-pdfa.sh — veraPDF ou fallback).
  const pdfAStep = tryRunVeraPDF(pdfPath);
  if (pdfAStep !== null) {
    steps.push(pdfAStep);
  } else {
    // Fallback in-process : structural-check seul (subset des checks veraPDF).
    process.stdout.write(
      "[factur-x:validate] bin/validate-pdfa.sh indisponible — fallback structurel in-process.\n",
    );
    steps.push(...runStructuralCheck(new Uint8Array(pdfBytes)));
  }

  // 2 + 3. XMP + XML CII attaché — déjà couvert par structuralChecks (présence
  // namespace fx:, fx:DocumentType=INVOICE, fx:DocumentFileName=factur-x.xml,
  // /AF, EmbeddedFiles, AFRelationship). On les rajoute toujours pour clarté
  // si veraPDF a été utilisé seul (verbosité limitée par défaut).
  if (pdfAStep !== null) {
    const inProc = runStructuralCheck(new Uint8Array(pdfBytes));
    for (const s of inProc) {
      // Évite la duplication : on ne pousse que les checks Factur-X spécifiques.
      if (
        s.name.startsWith("XMP declares") ||
        s.name.includes("factur-x.xml") ||
        s.name.includes("AFRelationship")
      ) {
        steps.push(s);
      }
    }
  }

  // 4. XML extrait + validation XSD EXTENDED.
  const xml = await extractEmbeddedXml(new Uint8Array(pdfBytes));
  if (xml === null) {
    steps.push({
      name: "XML CII extrait du PDF",
      ok: false,
      details: "aucun flux PDFRawStream avec /Subtype /text/xml trouvé",
    });
  } else {
    steps.push({
      name: "XML CII extrait du PDF",
      ok: true,
      details: `${String(xml.length)} chars`,
    });
    const xsdResult = await validateExtendedXsd(xml);
    if (xsdResult.ok) {
      steps.push({ name: "XML CII valide vs XSD EXTENDED", ok: true });
    } else {
      const first = xsdResult.errors[0];
      steps.push({
        name: "XML CII valide vs XSD EXTENDED",
        ok: false,
        details: `${String(xsdResult.errors.length)} erreur(s) — ex: L${String(first?.line ?? 0)} ${first?.message.trim() ?? ""}`,
      });
    }

    // 5. Cascade Schematron embarquée (optionnelle, `--schematron`).
    if (flagSchematron) {
      const profile = detectProfile(pdfPath);
      const cascade = await validateCascade(xml, profile);
      for (const step of cascade.steps) {
        if (step.step === "xsd") continue;
        // `na`/`skipped`/`error` ne disqualifient pas (dégradé V1) ; seuls
        // `fatal` et les warnings comptent comme non-ok.
        const stepOk = step.status !== "fatal" && step.warnings.length === 0;
        const counts = `${String(step.fatals.length)} fatal, ${String(step.warnings.length)} warning`;
        steps.push({
          name: `${step.step} [${step.status}]`,
          ok: stepOk,
          details: step.detail ?? counts,
        });
      }
    }
  }

  // Rapport final.
  let allOk = true;
  for (const s of steps) {
    const symbol = s.ok ? "✓" : "✗";
    process.stdout.write(
      `${symbol} ${s.name}${s.details === undefined ? "" : ` — ${s.details}`}\n`,
    );
    if (!s.ok) allOk = false;
  }
  process.stdout.write(
    allOk
      ? "\n[factur-x:validate] ✓ Conforme Factur-X (PDF/A-3 + XMP fx: + AF factur-x.xml + XSD EXTENDED).\n"
      : "\n[factur-x:validate] ✗ Échec — voir détails ci-dessus.\n",
  );
  process.exit(allOk ? 0 : 1);
}

main().catch((err: unknown) => {
  process.stderr.write(`[factur-x:validate] ✗ ${String(err)}\n`);
  process.exit(1);
});
