// CLI : `pnpm factur-x:generate-sample [--profile <key>] [input-path]`.
// Référence : plan.md sprint-01 T-CL-06 + ADR-004 §"Annexe — recette technique".
//
// Pipeline :
//   1. Charge un objet TS d'exemple (`samples/<slug>-sample-001.input.ts`
//      par défaut, `samples/extended-ctc-fr-sample-001.input.ts` si pas de profil).
//   2. Sérialise en XML CII via `generateCII`.
//   3. Valide l'XML contre la XSD du profil cible via `validateXsd` — fail-fast
//      si KO. Si le XSD profil n'est pas présent au repo, validation skip avec
//      warning, on continue.
//   4. Assemble le PDF/A-3b via `assembleFacturXPdfA3` (Roboto subset + sRGB
//      ICC + AF) avec `conformanceLevel` aligné au profil cible.
//   5. Écrit le PDF à côté de l'input.
//   6. Exit 0 sur succès, 1 sinon (avec rapport d'erreur).
//
// Sprint-06 T-CL-FACTURX-BUILDER-REFACTOR-CTC-FR (ADR-016 candidat D1) — hard
// switch émission V2 : `--profile en16931 | extended-ctc-fr` (2 profils seuls).

import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";

import type { CrossIndustryInvoice } from "@factur-e/factur-x-model";
import { FX_CONFORMANCE_LEVELS, type FxConformanceLevel } from "@factur-e/factur-x-model";

import { renderInvoicePdfFromModel } from "../pdf-assembly/render-invoice-pdf.js";
import { generateCII } from "../generate-cii.js";
import { type FacturXProfileKey, validateXsd } from "../validate-xsd.js";

// HERE = .../packages/factur-x-builder/src/cli — samples/ vit au niveau du package.
const PACKAGE_ROOT = path.resolve(import.meta.dirname, "..", "..");
const SAMPLES_DIR = path.join(PACKAGE_ROOT, "samples");

/**
 * Mapping profil → XMP conformance level + nom canonique d'input.
 * `extended-ctc-fr` réutilise le conformance level XMP EXTENDED (la relaxation
 * CTC-FR est portée par le Schematron, pas par le niveau de conformité Factur-X).
 */
const PROFILE_META: Record<FacturXProfileKey, { conformance: FxConformanceLevel; slug: string }> = {
  en16931: { conformance: FX_CONFORMANCE_LEVELS.EN16931, slug: "en16931" },
  "extended-ctc-fr": { conformance: FX_CONFORMANCE_LEVELS.EXTENDED, slug: "extended-ctc-fr" },
};

const VALID_PROFILES = Object.keys(PROFILE_META) as readonly FacturXProfileKey[];

function parseArgs(argv: readonly string[]): {
  profile: FacturXProfileKey;
  inputPath: string;
} {
  let profile: FacturXProfileKey = "extended-ctc-fr";
  let inputPath: string | undefined;

  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === "--profile") {
      const next = argv[i + 1];
      if (next === undefined || !VALID_PROFILES.includes(next as FacturXProfileKey)) {
        process.stderr.write(
          `usage: pnpm factur-x:generate-sample [--profile <${VALID_PROFILES.join("|")}>] [input-path]\n`,
        );
        process.exit(2);
      }
      profile = next as FacturXProfileKey;
      i++;
    } else if (arg !== undefined && !arg.startsWith("--")) {
      inputPath = arg;
    }
  }

  // Input par défaut : `samples/<slug>-sample-001.input.ts`.
  if (inputPath === undefined) {
    inputPath = path.join(SAMPLES_DIR, `${PROFILE_META[profile].slug}-sample-001.input.ts`);
  } else if (!path.isAbsolute(inputPath)) {
    // Résolution relative au cwd appelant (utile pour validate-batch + usage direct).
    inputPath = path.resolve(process.cwd(), inputPath);
  }
  return { profile, inputPath };
}

async function loadInput(inputPath: string): Promise<CrossIndustryInvoice> {
  const mod = (await import(inputPath)) as Record<string, unknown>;
  // Trouve la première export qui ressemble à une CrossIndustryInvoice.
  for (const value of Object.values(mod)) {
    if (
      typeof value === "object" &&
      value !== null &&
      "documentContext" in value &&
      "exchangedDocument" in value &&
      "tradeTransaction" in value
    ) {
      return value as CrossIndustryInvoice;
    }
  }
  throw new Error(
    `Aucune export CrossIndustryInvoice trouvée dans ${inputPath}. Attendu : export d'un objet avec documentContext + exchangedDocument + tradeTransaction.`,
  );
}

async function main(): Promise<void> {
  const { profile, inputPath } = parseArgs(process.argv.slice(2));
  const outputPath = inputPath.replace(/\.input\.ts$/, ".pdf");

  process.stdout.write(`[generate-sample] profile : ${profile}\n`);
  process.stdout.write(`[generate-sample] input   : ${inputPath}\n`);
  process.stdout.write(`[generate-sample] output  : ${outputPath}\n\n`);

  const invoice = await loadInput(inputPath);

  // 2. CII XML.
  const xml = generateCII(invoice);
  process.stdout.write(`[generate-sample] ✓ CII XML généré (${String(xml.length)} chars)\n`);

  // 3. XSD validation (fail-fast).
  const xsdResult = await validateXsd(xml, profile);
  if (!xsdResult.ok) {
    process.stderr.write(
      `[generate-sample] ✗ XML CII invalide vs XSD ${profile.toUpperCase()} (${String(xsdResult.errors.length)} erreurs) :\n`,
    );
    for (const e of xsdResult.errors.slice(0, 5)) {
      process.stderr.write(`  L${String(e.line)} C${String(e.column)} — ${e.message.trim()}\n`);
    }
    process.exit(1);
  }
  if (xsdResult.value.skipped) {
    process.stdout.write(
      `[generate-sample] ⚠ XSD ${profile.toUpperCase()} validation SKIP — ${xsdResult.value.skipReason ?? "XSD absent"}\n`,
    );
  } else {
    process.stdout.write(`[generate-sample] ✓ XML CII valide vs XSD ${profile.toUpperCase()}\n`);
  }

  // 4. PDF/A-3 via le moteur de template Nunjucks (Axe B sprint-07 V2). Le
  // sample n'a pas d'enrichissement BDD (Capital social / RCS / logo) — les
  // sections concernées restent vides proprement (rendu défensif).
  const xmlBytes = new TextEncoder().encode(xml);
  const pdfBytes = await renderInvoicePdfFromModel({
    invoice,
    xmlBytes,
    conformanceLevel: PROFILE_META[profile].conformance,
    footerLine: invoice.tradeTransaction.tradeAgreement.sellerTradeParty.name,
    // Date figée pour reproductibilité du sample (sortie déterministe).
    generationDate: new Date(
      `${invoice.exchangedDocument.issueDate.value.slice(0, 4)}-${invoice.exchangedDocument.issueDate.value.slice(4, 6)}-${invoice.exchangedDocument.issueDate.value.slice(6, 8)}T10:00:00Z`,
    ),
  });

  // 5. Écriture.
  await mkdir(path.dirname(outputPath), { recursive: true });
  await writeFile(outputPath, pdfBytes);
  process.stdout.write(`[generate-sample] ✓ PDF/A-3 écrit : ${String(pdfBytes.length)} octets\n`);
  process.stdout.write(
    `\n[generate-sample] Validation : bash bin/validate-pdfa.sh ${outputPath}\n`,
  );
}

main().catch((err: unknown) => {
  process.stderr.write(`[generate-sample] ✗ ${String(err)}\n`);
  process.exit(1);
});
