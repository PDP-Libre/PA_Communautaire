// CLI : `pnpm factur-x:validate-batch [--schematron]`.
// Sprint-06 T-CL-FACTURX-BUILDER-REFACTOR-CTC-FR — itère sur
// `packages/factur-x-builder/samples/*.pdf` et exécute :
//   1. Conformité PDF/A-3 (`bin/validate-pdfa.sh` veraPDF).
//   2. Extraction du XML embarqué (`factur-x.xml`).
//   3. Détection profil via préfixe nom fichier (en16931 / extended-ctc-fr).
//   4. Validation XSD profil cible (`validateXsd`). Skip gracieux si absent.
//   5. **Flag `--schematron`** : engine Schematron embarqué saxon-js (cascade
//      XSD → EN16931 → EXTENDED-CTC-FR → BR-FR-Flux2, skip hors-profil).
//      NOTE V1 : le Schematron EXTENDED-CTC-FR peut rapporter `error` (limitation
//      saxon-js HE sur l'arithmétique décimale — validation déléguée à la
//      sandbox SuperPDP + validateur web). Un `error` engine ne disqualifie pas
//      le sample (DoD dégradé V1 : 0 fatal + 0 warning sur étapes exécutées).
//
// Reporting stdout : `N/M samples OK` + détails par sample. Exit 0 si tous OK.

import { readFile, readdir } from "node:fs/promises";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import path from "node:path";

import { extractEmbeddedXml } from "../pdf-validation/extract-xml.js";
import { type FacturXProfileKey, validateXsd } from "../validate-xsd.js";
import { type CascadeResult, validateCascade } from "../schematron/validate-cascade.js";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const PACKAGE_ROOT = path.resolve(HERE, "..", "..");
const REPO_ROOT = path.resolve(PACKAGE_ROOT, "..", "..");
const SAMPLES_DIR = path.join(PACKAGE_ROOT, "samples");
const VALIDATE_SCRIPT = path.join(REPO_ROOT, "bin", "validate-pdfa.sh");

interface SampleResult {
  filename: string;
  profile: FacturXProfileKey;
  pdfA: { ok: boolean; details?: string };
  xmlExtracted: { ok: boolean; details?: string };
  xsd: { ok: boolean; skipped: boolean; details?: string };
  /** Présent uniquement si `--schematron` est passé et le XML est extrait. */
  cascade?: CascadeResult;
}

/** Détecte le profil Factur-X depuis le préfixe du nom de fichier. */
function detectProfileFromFilename(filename: string): FacturXProfileKey {
  const base = path.basename(filename).toLowerCase();
  if (base.startsWith("en16931-")) return "en16931";
  return "extended-ctc-fr";
}

function runPdfACheck(pdfPath: string): { ok: boolean; details?: string } {
  const result = spawnSync("bash", [VALIDATE_SCRIPT, pdfPath], {
    encoding: "utf-8",
    stdio: ["ignore", "pipe", "pipe"],
  });
  if (result.error !== undefined) {
    return { ok: false, details: `script error: ${result.error.message}` };
  }
  const ok = result.status === 0;
  return ok
    ? { ok: true }
    : {
        ok: false,
        details: (result.stderr || result.stdout).split("\n").slice(-3).join(" / "),
      };
}

async function validateSample(pdfPath: string, flagSchematron: boolean): Promise<SampleResult> {
  const filename = path.basename(pdfPath);
  const profile = detectProfileFromFilename(pdfPath);

  const pdfA = runPdfACheck(pdfPath);

  const pdfBytes = await readFile(pdfPath);
  const xml = await extractEmbeddedXml(new Uint8Array(pdfBytes));
  const xmlExtracted =
    xml === null
      ? { ok: false, details: "aucun flux <Subtype text/xml> trouvé" }
      : { ok: true, details: `${String(xml.length)} chars` };

  let xsd: SampleResult["xsd"];
  if (xml === null) {
    xsd = { ok: false, skipped: false, details: "skip — XML non extrait" };
  } else {
    const result = await validateXsd(xml, profile);
    if (!result.ok) {
      const first = result.errors[0];
      xsd = {
        ok: false,
        skipped: false,
        details: `${String(result.errors.length)} erreur(s) — ex L${String(first?.line ?? 0)} : ${first?.message.trim() ?? ""}`,
      };
    } else if (result.value.skipped) {
      xsd = { ok: true, skipped: true, details: result.value.skipReason ?? "XSD profil absent" };
    } else {
      xsd = { ok: true, skipped: false };
    }
  }

  // Engine Schematron embarqué (cascade séquentielle stricte, reporting cumulé).
  let cascade: CascadeResult | undefined;
  if (flagSchematron && xml !== null) {
    cascade = await validateCascade(xml, profile);
  }

  return { filename, profile, pdfA, xmlExtracted, xsd, cascade };
}

const STEP_LABEL: Record<string, string> = {
  xsd: "XSD",
  "schematron-en16931": "Schematron EN16931",
  "schematron-extended-ctc-fr": "Schematron EXTENDED-CTC-FR",
  "schematron-br-fr-flux2": "Schematron BR-FR-Flux2",
};

const STATUS_SYMBOL: Record<string, string> = {
  ok: "✓",
  warning: "⚠",
  fatal: "✗",
  error: "⚠",
  na: "·",
  skipped: "·",
};

/** Un sample est OK si veraPDF + XML + XSD ok, et 0 fatal + 0 warning Schematron. */
function isSampleOk(r: SampleResult): boolean {
  if (!r.pdfA.ok || !r.xmlExtracted.ok || !r.xsd.ok) return false;
  if (r.cascade === undefined) return true;
  // Dégradé V1 : `error` engine (EXTENDED-CTC-FR/saxon-js HE) toléré ; on exige
  // 0 fatal + 0 warning sur les étapes réellement exécutées.
  return !r.cascade.steps.some((s) => s.status === "fatal" || s.warnings.length > 0);
}

function printResult(r: SampleResult): boolean {
  const symbol = (ok: boolean): string => (ok ? "✓" : "✗");
  process.stdout.write(`\n[${r.filename}] profile=${r.profile}\n`);
  process.stdout.write(
    `  ${symbol(r.pdfA.ok)} PDF/A-3 conformity${r.pdfA.details === undefined ? "" : ` — ${r.pdfA.details}`}\n`,
  );
  process.stdout.write(
    `  ${symbol(r.xmlExtracted.ok)} XML CII extraction${r.xmlExtracted.details === undefined ? "" : ` — ${r.xmlExtracted.details}`}\n`,
  );
  const xsdSymbol = r.xsd.skipped ? "⚠" : symbol(r.xsd.ok);
  process.stdout.write(
    `  ${xsdSymbol} XSD ${r.profile.toUpperCase()} validation${r.xsd.details === undefined ? "" : ` — ${r.xsd.details}`}\n`,
  );
  if (r.cascade !== undefined) {
    for (const step of r.cascade.steps) {
      if (step.step === "xsd") continue; // déjà affiché ci-dessus.
      const sym = STATUS_SYMBOL[step.status] ?? "?";
      const counts =
        step.fatals.length > 0 || step.warnings.length > 0
          ? ` (${String(step.fatals.length)} fatal, ${String(step.warnings.length)} warning)`
          : "";
      const detail = step.detail !== undefined ? ` — ${step.detail}` : "";
      process.stdout.write(
        `  ${sym} ${STEP_LABEL[step.step] ?? step.step}: ${step.status}${counts}${detail}\n`,
      );
    }
  }
  return isSampleOk(r);
}

async function main(): Promise<void> {
  const flagSchematron = process.argv.includes("--schematron");

  process.stdout.write(`[validate-batch] samples : ${SAMPLES_DIR}\n`);
  process.stdout.write(`[validate-batch] flag --schematron : ${flagSchematron ? "ON" : "OFF"}\n`);

  const entries = await readdir(SAMPLES_DIR);
  const pdfs = entries.filter((f) => f.endsWith(".pdf")).sort();

  if (pdfs.length === 0) {
    process.stderr.write(`[validate-batch] ✗ aucun PDF trouvé dans ${SAMPLES_DIR}\n`);
    process.exit(1);
  }

  process.stdout.write(`[validate-batch] ${String(pdfs.length)} sample(s) PDF détecté(s)\n`);

  const results: SampleResult[] = [];
  for (const pdf of pdfs) {
    results.push(await validateSample(path.join(SAMPLES_DIR, pdf), flagSchematron));
  }

  let okCount = 0;
  for (const r of results) {
    if (printResult(r)) okCount++;
  }

  const total = results.length;
  process.stdout.write(`\n[validate-batch] ── Récapitulatif ──\n`);
  process.stdout.write(`  ${String(okCount)}/${String(total)} samples OK\n`);
  const skippedXsd = results.filter((r) => r.xsd.skipped).length;
  if (skippedXsd > 0) {
    process.stdout.write(
      `  ${String(skippedXsd)}/${String(total)} validations XSD skip (XSD profil absent — garde Schematron prend le relais)\n`,
    );
  }
  const engineErrors = results.filter((r) => r.cascade?.engineErrors === true).length;
  if (engineErrors > 0) {
    process.stdout.write(
      `  ${String(engineErrors)}/${String(total)} avec erreur engine Schematron (EXTENDED-CTC-FR / saxon-js HE — délégué sandbox SuperPDP, dégradé V1)\n`,
    );
  }
  process.stdout.write(
    `\n[validate-batch] ${okCount === total ? "✓ Tous les samples OK." : "✗ Échec — voir détails ci-dessus."}\n`,
  );
  process.exit(okCount === total ? 0 : 1);
}

main().catch((err: unknown) => {
  process.stderr.write(`[validate-batch] ✗ ${String(err)}\n`);
  process.exit(1);
});
