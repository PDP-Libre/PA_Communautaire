// Parser de l'HTML intermédiaire (rendu Nunjucks) → blocs typés consommés par
// pdf-lib (`assemble.ts`). Pont template → PDF qui préserve veraPDF (pdf-lib
// dessine du texte positionné, pas de moteur de layout HTML).
//
// Vocabulaire contraint (cf. base-document.njk) — pas un parser HTML générique :
//   <section data-block="NAME"> … </section>            bloc ordonné, non imbriqué
//   <p [data-bold] [data-italic] [data-size="N"] [data-align="…"]>texte</p>
//   <table><thead><tr><th data-align>…</th></tr></thead>
//          <tbody><tr><td data-align>seg<br>seg</td></tr></tbody></table>
// Le texte des `{{ }}` est échappé par Nunjucks (autoescape) → on dé-échappe ici.

export type Align = "left" | "right" | "center";

export interface PdfTextLine {
  text: string;
  bold: boolean;
  italic: boolean;
  size?: number;
  align: Align;
}

export interface PdfTextBlock {
  kind: "text";
  name: string;
  lines: PdfTextLine[];
}

export interface PdfTableColumn {
  header: string;
  align: Align;
}

export interface PdfTableCell {
  /** Segments séparés par `<br>` — 1er = principal, suivants = sous-lignes. */
  segments: string[];
  align: Align;
}

export interface PdfTableBlock {
  kind: "table";
  name: string;
  columns: PdfTableColumn[];
  rows: PdfTableCell[][];
}

export type PdfBlock = PdfTextBlock | PdfTableBlock;

const SECTION_RE = /<section\s+data-block="([^"]+)"\s*>([\s\S]*?)<\/section>/g;
const P_RE = /<p\b([^>]*)>([\s\S]*?)<\/p>/g;
const TH_RE = /<th\b([^>]*)>([\s\S]*?)<\/th>/g;
const TR_RE = /<tr\b[^>]*>([\s\S]*?)<\/tr>/g;
const TD_RE = /<td\b([^>]*)>([\s\S]*?)<\/td>/g;

function decodeEntities(s: string): string {
  return s
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&#x27;/gi, "'")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&"); // toujours en dernier
}

function attrAlign(attrs: string): Align {
  const m = /data-align="(left|right|center)"/.exec(attrs);
  return m === null ? "left" : ((m[1] ?? "left") as Align);
}

function attrSize(attrs: string): number | undefined {
  const m = /data-size="(\d+)"/.exec(attrs);
  return m?.[1] === undefined ? undefined : Number(m[1]);
}

/** Texte d'une cellule/paragraphe : split `<br>` + dé-échappe + trim. */
function textSegments(raw: string): string[] {
  return raw
    .split(/<br\s*\/?>/i)
    .map((seg) => decodeEntities(seg.replace(/\s+/g, " ").trim()))
    .filter((seg) => seg.length > 0);
}

function parseTextLines(body: string): PdfTextLine[] {
  const lines: PdfTextLine[] = [];
  for (const m of body.matchAll(P_RE)) {
    const attrs = m[1] ?? "";
    const segments = textSegments(m[2] ?? "");
    const text = segments.join(" ");
    if (text.length === 0) continue;
    lines.push({
      text,
      bold: /\bdata-bold\b/.test(attrs),
      italic: /\bdata-italic\b/.test(attrs),
      size: attrSize(attrs),
      align: attrAlign(attrs),
    });
  }
  return lines;
}

function parseTable(name: string, body: string): PdfTableBlock {
  const columns: PdfTableColumn[] = [];
  const theadMatch = /<thead\b[^>]*>([\s\S]*?)<\/thead>/i.exec(body);
  if (theadMatch?.[1] !== undefined) {
    for (const m of theadMatch[1].matchAll(TH_RE)) {
      columns.push({ header: textSegments(m[2] ?? "").join(" "), align: attrAlign(m[1] ?? "") });
    }
  }
  const rows: PdfTableCell[][] = [];
  const tbodyMatch = /<tbody\b[^>]*>([\s\S]*?)<\/tbody>/i.exec(body);
  const tbody = tbodyMatch?.[1] ?? "";
  for (const tr of tbody.matchAll(TR_RE)) {
    const cells: PdfTableCell[] = [];
    for (const td of (tr[1] ?? "").matchAll(TD_RE)) {
      cells.push({ segments: textSegments(td[2] ?? ""), align: attrAlign(td[1] ?? "") });
    }
    if (cells.length > 0) rows.push(cells);
  }
  return { kind: "table", name, columns, rows };
}

/** Parse l'HTML intermédiaire en blocs ordonnés. Blocs vides ignorés. */
export function parseHtmlToBlocks(html: string): PdfBlock[] {
  const blocks: PdfBlock[] = [];
  for (const m of html.matchAll(SECTION_RE)) {
    const name = m[1] ?? "";
    const body = m[2] ?? "";
    if (/<table\b/i.test(body)) {
      blocks.push(parseTable(name, body));
    } else {
      const lines = parseTextLines(body);
      if (lines.length > 0) blocks.push({ kind: "text", name, lines });
    }
  }
  return blocks;
}
