// Construction du paquet XMP pour un PDF/A-3 Factur-X.
//
// Le XMP doit déclarer :
//   - Le profil PDF/A-3 (`pdfaid:part=3`, `pdfaid:conformance=B`).
//   - Le schéma d'extension `fx:` Factur-X (cf. `docs/external/factur-x-1.07.3/extension-schema-xmp.txt`).
//   - Les métadonnées Dublin Core, PDF, XMP de base.
//
// La sortie est déterministe (chaînes en dur, pas de Map iterator) pour permettre
// des golden-file tests et un diff propre. Cf. ADR-003 §"Déterminisme".
//
// Toutes les valeurs Factur-X figées (URI, prefix, DocumentType, Version,
// ConformanceLevel) viennent de `@factur-e/factur-x-model:codes` — pas de
// hardcode local.

import {
  FX_DOCUMENT_TYPE,
  FX_VERSION,
  FX_XMP_NAMESPACE_URI,
  FX_XMP_PREFIX,
  type FxConformanceLevel,
} from "@factur-e/factur-x-model";

const PDFAID_NAMESPACE = "http://www.aiim.org/pdfa/ns/id/";
const PDFA_EXTENSION_NAMESPACE = "http://www.aiim.org/pdfa/ns/extension/";
const PDFA_SCHEMA_NAMESPACE = "http://www.aiim.org/pdfa/ns/schema#";
const PDFA_PROPERTY_NAMESPACE = "http://www.aiim.org/pdfa/ns/property#";

export interface XmpInput {
  /** BT-1 — numéro de la facture (utilisé pour `dc:title`). */
  invoiceNumber: string;
  /** BT-27 — nom du vendeur (utilisé pour `dc:creator`). */
  sellerName: string;
  /**
   * Profil Factur-X (`MINIMUM`, `BASIC WL`, `BASIC`, `EN 16931`, `EXTENDED`).
   * Cf. `extension-schema-xmp.txt` — valeurs autorisées par fx:ConformanceLevel.
   */
  conformanceLevel: FxConformanceLevel;
  /** Date de génération (UTC). Stockée en `xmp:CreateDate` ISO 8601. */
  generationDate: Date;
}

/** Échappement XML strict, ordre `& < > " '` (cf. ADR-003 §"Échappement"). */
function escape(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function isoDate(d: Date): string {
  // YYYY-MM-DDThh:mm:ssZ — XMP standard.
  return `${d.toISOString().split(".")[0] ?? ""}Z`;
}

/**
 * Génère un paquet XMP complet avec :
 *  - Dublin Core (dc:title, dc:creator, dc:description).
 *  - PDF (pdf:Producer).
 *  - XMP (xmp:CreatorTool, xmp:CreateDate, xmp:ModifyDate).
 *  - PDF/A-3 (pdfaid:part=3, pdfaid:conformance=B).
 *  - Extension PDF/A déclarant le schéma Factur-X.
 *  - Propriétés Factur-X (fx:DocumentType, fx:DocumentFileName, fx:Version, fx:ConformanceLevel).
 */
export function buildFacturXXmp(input: XmpInput): string {
  const created = isoDate(input.generationDate);
  const title = escape(`Facture ${input.invoiceNumber}`);
  const creator = escape(input.sellerName);
  const description = escape("Facture électronique Factur-X EN 16931");

  // BOM (U+FEFF) au début du paquet XMP — convention Adobe XMP 2004.
  const BOM = "﻿";
  return `<?xpacket begin="${BOM}" id="W5M0MpCehiHzreSzNTczkc9d"?>
<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Factur-e">
  <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
    <rdf:Description rdf:about=""
        xmlns:dc="http://purl.org/dc/elements/1.1/">
      <dc:title>
        <rdf:Alt>
          <rdf:li xml:lang="x-default">${title}</rdf:li>
        </rdf:Alt>
      </dc:title>
      <dc:creator>
        <rdf:Seq>
          <rdf:li>${creator}</rdf:li>
        </rdf:Seq>
      </dc:creator>
      <dc:description>
        <rdf:Alt>
          <rdf:li xml:lang="x-default">${description}</rdf:li>
        </rdf:Alt>
      </dc:description>
    </rdf:Description>
    <rdf:Description rdf:about=""
        xmlns:pdf="http://ns.adobe.com/pdf/1.3/">
      <pdf:Producer>Factur-e builder spike</pdf:Producer>
    </rdf:Description>
    <rdf:Description rdf:about=""
        xmlns:xmp="http://ns.adobe.com/xap/1.0/">
      <xmp:CreatorTool>Factur-e</xmp:CreatorTool>
      <xmp:CreateDate>${created}</xmp:CreateDate>
      <xmp:ModifyDate>${created}</xmp:ModifyDate>
    </rdf:Description>
    <rdf:Description rdf:about=""
        xmlns:pdfaid="${PDFAID_NAMESPACE}">
      <pdfaid:part>3</pdfaid:part>
      <pdfaid:conformance>B</pdfaid:conformance>
    </rdf:Description>
    <rdf:Description rdf:about=""
        xmlns:pdfaExtension="${PDFA_EXTENSION_NAMESPACE}"
        xmlns:pdfaSchema="${PDFA_SCHEMA_NAMESPACE}"
        xmlns:pdfaProperty="${PDFA_PROPERTY_NAMESPACE}">
      <pdfaExtension:schemas>
        <rdf:Bag>
          <rdf:li rdf:parseType="Resource">
            <pdfaSchema:schema>Factur-X PDFA Extension Schema</pdfaSchema:schema>
            <pdfaSchema:namespaceURI>${FX_XMP_NAMESPACE_URI}</pdfaSchema:namespaceURI>
            <pdfaSchema:prefix>${FX_XMP_PREFIX}</pdfaSchema:prefix>
            <pdfaSchema:property>
              <rdf:Seq>
                <rdf:li rdf:parseType="Resource">
                  <pdfaProperty:name>DocumentFileName</pdfaProperty:name>
                  <pdfaProperty:valueType>Text</pdfaProperty:valueType>
                  <pdfaProperty:category>external</pdfaProperty:category>
                  <pdfaProperty:description>Name of the embedded XML invoice file</pdfaProperty:description>
                </rdf:li>
                <rdf:li rdf:parseType="Resource">
                  <pdfaProperty:name>DocumentType</pdfaProperty:name>
                  <pdfaProperty:valueType>Text</pdfaProperty:valueType>
                  <pdfaProperty:category>external</pdfaProperty:category>
                  <pdfaProperty:description>${FX_DOCUMENT_TYPE}</pdfaProperty:description>
                </rdf:li>
                <rdf:li rdf:parseType="Resource">
                  <pdfaProperty:name>Version</pdfaProperty:name>
                  <pdfaProperty:valueType>Text</pdfaProperty:valueType>
                  <pdfaProperty:category>external</pdfaProperty:category>
                  <pdfaProperty:description>Factur-X version</pdfaProperty:description>
                </rdf:li>
                <rdf:li rdf:parseType="Resource">
                  <pdfaProperty:name>ConformanceLevel</pdfaProperty:name>
                  <pdfaProperty:valueType>Text</pdfaProperty:valueType>
                  <pdfaProperty:category>external</pdfaProperty:category>
                  <pdfaProperty:description>Factur-X conformance level</pdfaProperty:description>
                </rdf:li>
              </rdf:Seq>
            </pdfaSchema:property>
          </rdf:li>
        </rdf:Bag>
      </pdfaExtension:schemas>
    </rdf:Description>
    <rdf:Description rdf:about=""
        xmlns:${FX_XMP_PREFIX}="${FX_XMP_NAMESPACE_URI}">
      <${FX_XMP_PREFIX}:DocumentType>${FX_DOCUMENT_TYPE}</${FX_XMP_PREFIX}:DocumentType>
      <${FX_XMP_PREFIX}:DocumentFileName>factur-x.xml</${FX_XMP_PREFIX}:DocumentFileName>
      <${FX_XMP_PREFIX}:Version>${FX_VERSION}</${FX_XMP_PREFIX}:Version>
      <${FX_XMP_PREFIX}:ConformanceLevel>${input.conformanceLevel}</${FX_XMP_PREFIX}:ConformanceLevel>
    </rdf:Description>
  </rdf:RDF>
</x:xmpmeta>
<?xpacket end="w"?>`;
}
