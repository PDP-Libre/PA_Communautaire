// Rendu Nunjucks des templates de facture `.njk` (Option α — moteur de template
// Mozilla Nunjucks, portage JS officiel de Jinja ; référence Bruno
// https://jinja.palletsprojects.com/). Le rendu produit un HTML intermédiaire
// (vocabulaire contraint, cf. `html-to-pdf-blocks.ts`) consommé ensuite par
// pdf-lib — pipeline qui préserve ADR-004 PDF/A-3b (zéro Chromium prod).
//
// Trois filtres custom FR (ZG-B9) — formats verbatim glossaire utilisateur §3.4 :
//   |format_date_fr   YYYYMMDD       → "JJ/MM/YYYY"
//   |format_amount_fr number|string  → "9 500,00" (espace fin milliers, virgule)
//   |format_vat_rate  number         → "20 %" / "5,5 %" / "0 %"
// Le symbole "€" et les préfixes ("SIREN ", "Total HT : ") vivent dans les
// templates (verbatim — ADR-013 D3), pas dans les filtres.

import { fileURLToPath } from "node:url";
import path from "node:path";

import nunjucks from "nunjucks";

const HERE = path.dirname(fileURLToPath(import.meta.url));
// HERE = .../packages/factur-x-builder/{src,dist}/pdf-assembly → templates à ../../templates.
export const TEMPLATES_DIR = path.resolve(HERE, "..", "..", "templates");

/** Espace fine insécable U+202F — séparateur de milliers FR (glossaire §3.4). */
export const NBSP = String.fromCharCode(0x202f);

/** YYYYMMDD → JJ/MM/YYYY. Retourne la valeur brute si format inattendu. */
export function formatDateFr(value: unknown): string {
  const s = typeof value === "string" ? value : "";
  if (!/^\d{8}$/.test(s)) return s;
  return `${s.slice(6, 8)}/${s.slice(4, 6)}/${s.slice(0, 4)}`;
}

/** number|string → "9 500,00" (2 décimales, séparateur milliers fin, virgule). */
export function formatAmountFr(value: unknown): string {
  const n = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(n)) return "";
  const fixed = n.toFixed(2); // "9500.00" | "-1234.50"
  const negative = fixed.startsWith("-");
  const parts = (negative ? fixed.slice(1) : fixed).split(".");
  const intPart = parts[0] ?? "0";
  const decPart = parts[1] ?? "00";
  const grouped = intPart.replace(/\B(?=(\d{3})+(?!\d))/g, NBSP);
  return `${negative ? "-" : ""}${grouped},${decPart}`;
}

/** number → "20 %" / "5,5 %" / "0 %" (décimales superflues coupées, virgule). */
export function formatVatRateFr(value: unknown): string {
  const n = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(n)) return "";
  // Jusqu'à 2 décimales, sans zéros de fin.
  const rounded = Math.round(n * 100) / 100;
  const str = String(rounded).replace(".", ",");
  return `${str} %`;
}

let cachedEnv: nunjucks.Environment | undefined;

/** Environnement Nunjucks (loader + filtres) — caché au scope module. */
export function getTemplateEnv(): nunjucks.Environment {
  if (cachedEnv !== undefined) return cachedEnv;
  const loader = new nunjucks.FileSystemLoader(TEMPLATES_DIR, { noCache: false });
  const env = new nunjucks.Environment(loader, {
    autoescape: true, // échappe le texte injecté (sécurité + parser HTML aval)
    throwOnUndefined: false,
    trimBlocks: true,
    lstripBlocks: true,
  });
  env.addFilter("format_date_fr", formatDateFr);
  env.addFilter("format_amount_fr", formatAmountFr);
  env.addFilter("format_vat_rate", formatVatRateFr);
  cachedEnv = env;
  return env;
}

/** Réinitialise le cache d'environnement — utile en test (filtres/loader). */
export function resetTemplateEnv(): void {
  cachedEnv = undefined;
}

/**
 * Rend un template `.njk` avec son contexte de données. Retourne l'HTML
 * intermédiaire (string). `templateName` est relatif à `TEMPLATES_DIR`
 * (ex "invoice-default.njk").
 */
export function renderInvoiceTemplate(
  context: Record<string, unknown>,
  templateName: string,
): string {
  return getTemplateEnv().render(templateName, { data: context });
}
