// Assemblage PDF/A-3b Factur-X via pdf-lib.
//
// Promu depuis `spikes/pdfa3/assemble-pdfa3.ts` à T-CL-06 — module prod
// désormais. Recette validée veraPDF flavour 3b (146/146 rules) cf. ADR-004.
//
// Étapes (cf. doc Factur-X §8 et `codebase-facturx-swift.md` §8 + ADR-004 §Annexe) :
//   1. Création du PDF, version 1.7.
//   2. Page A4 minimale avec le numéro de facture en clair (lisibilité humaine),
//      en police TTF embarquée (Roboto Apache 2.0) — PDF/A interdit les fonts non embed.
//   3. OutputIntent sRGB IEC61966-2.1 (profil ICC embarqué) — pré-requis PDF/A.
//   4. Métadonnées XMP avec extension Factur-X (`fx:`) et déclaration PDF/A-3 partie 3 conformance B.
//   5. Embed du `factur-x.xml` comme Associated File (AF) niveau Document.
//   6. Liaison via `/AF` et `/EmbeddedFiles` du Document Catalog.
//   7. Trailer `/ID` (deux PDFHexString — ISO 32000-1 §14.4 / ISO 19005-3 §6.1.3).
//
// [DEBT] ADR-004 §"Conséquences sur les artefacts" : le profil ICC embarqué
// (sRGB IEC61966-2.1, 3 144 octets, source /System/Library/ColorSync/) a une
// licence Microsoft ambiguë. À remplacer par version OpenICC public domain.

import { createHash } from "node:crypto";
import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import path from "node:path";
import fontkit from "@pdf-lib/fontkit";
import {
  AFRelationship,
  type PDFFont,
  type PDFImage,
  type PDFPage,
  PDFArray,
  PDFDocument,
  PDFHexString,
  PDFName,
  PDFRawStream,
  PDFString,
  decodePDFRawStream,
} from "pdf-lib";

import {
  FACTUR_X_XML_FILENAME,
  FACTUR_X_XML_MIME_TYPE,
  type FxConformanceLevel,
} from "@factur-e/factur-x-model";

import { FONT_PATH } from "./font.js";
import type { Align, PdfBlock, PdfTableBlock, PdfTextBlock } from "./html-to-pdf-blocks.js";
import { LAYOUT, lineHeight, tableHeaderHeight, tableRowHeight } from "./pagination.js";
import type { PdfLogo } from "./template-context.js";
import { buildFacturXXmp } from "./xmp.js";

const HERE = path.dirname(fileURLToPath(import.meta.url));
// HERE = .../packages/factur-x-builder/src/pdf-assembly → assets sont à ../../assets
const ASSETS_DIR = path.resolve(HERE, "..", "..", "assets");
const ICC_PATH = path.join(ASSETS_DIR, "sRGB.icc");

/**
 * Contenu rendu (moteur de template Nunjucks → blocs paginés) à dessiner par
 * pdf-lib. Absent = stub MVP minimal (rétro-compat tests + appelants non migrés).
 */
export interface PdfRenderContent {
  /** Pages déjà paginées (`paginateBlocks`). En-tête répété, table scindée. */
  pages: PdfBlock[][];
  /** Logo PNG/JPEG (ZG-B3) — dessiné en haut à droite de chaque page. */
  logo?: PdfLogo;
  /** Ligne de pied de page optionnelle (ex Capital social) — répétée. */
  footerLine?: string;
}

export interface AssembleInput {
  /** XML CII bytes (UTF-8) du `factur-x.xml`. */
  xmlBytes: Uint8Array;
  /** Métadonnées humaines pour la page visuelle + XMP. */
  metadata: {
    invoiceNumber: string;
    sellerName: string;
  };
  /**
   * Profil de conformance déclaré dans le XMP `fx:`. Doit refléter le profil
   * du XML embarqué. Le PDF lui-même reste PDF/A-3 partie 3 conformance B.
   */
  conformanceLevel: FxConformanceLevel;
  /** Date de génération — par défaut `new Date()`. Permet du déterminisme en test. */
  generationDate?: Date;
  /** Contenu moteur de template. Absent → page stub minimale (rétro-compat). */
  content?: PdfRenderContent;
}

/** Largeurs relatives des 6 colonnes de la table de lignes (somme = 1). */
const LINE_COL_WEIGHTS = [0.4, 0.1, 0.08, 0.17, 0.15, 0.1] as const;

/**
 * Calcule un identifiant 16 octets (32 hex) déterministe à partir des inputs.
 * Utilisé comme paire `/ID` du trailer PDF (ISO 19005-3 §6.1.3 + ISO 32000-1 §14.4).
 * Pour un nouveau PDF, les deux valeurs sont identiques (premier save = pas d'update).
 */
function computeFileIdentifier(
  invoiceNumber: string,
  sellerName: string,
  generationDate: Date,
): string {
  const seed = `${invoiceNumber}|${sellerName}|${generationDate.toISOString()}`;
  return createHash("md5").update(seed).digest("hex");
}

// ---------------------------------------------------------------------------
// Dessin des blocs (moteur de template → pdf-lib). Faux-gras par double frappe
// (Roboto-Bold non embarqué V1 — Roboto-Regular déjà validé veraPDF, zéro
// risque PDF/A). Italique non supporté V1 (rendu en Regular).
// ---------------------------------------------------------------------------

function textWidth(font: PDFFont, text: string, size: number): number {
  try {
    return font.widthOfTextAtSize(text, size);
  } catch {
    return text.length * size * 0.5; // garde-fou glyphe absent
  }
}

/** Tronque avec "…" si le texte dépasse `maxWidth`. */
function fitText(font: PDFFont, text: string, size: number, maxWidth: number): string {
  if (maxWidth <= 0 || textWidth(font, text, size) <= maxWidth) return text;
  let t = text;
  while (t.length > 1 && textWidth(font, `${t}…`, size) > maxWidth) t = t.slice(0, -1);
  return `${t}…`;
}

function alignedX(
  font: PDFFont,
  text: string,
  size: number,
  align: Align,
  left: number,
  right: number,
): number {
  if (align === "left") return left;
  const w = textWidth(font, text, size);
  if (align === "right") return right - w;
  return left + (right - left - w) / 2;
}

/** Dessine le texte ; en gras, double frappe décalée (faux-gras). */
function strike(
  page: PDFPage,
  font: PDFFont,
  text: string,
  x: number,
  y: number,
  size: number,
  bold: boolean,
): void {
  page.drawText(text, { x, y, size, font });
  if (bold) page.drawText(text, { x: x + 0.3, y, size, font });
}

function drawTextBlock(page: PDFPage, font: PDFFont, block: PdfTextBlock, startY: number): number {
  const left = LAYOUT.marginX;
  const right = LAYOUT.pageWidth - LAYOUT.marginX;
  let y = startY;
  for (const line of block.lines) {
    const size = line.size ?? LAYOUT.baseFontSize;
    const text = fitText(font, line.text, size, right - left);
    const x = alignedX(font, text, size, line.align, left, right);
    strike(page, font, text, x, y - size, size, line.bold);
    y -= lineHeight(size);
  }
  return y - LAYOUT.blockGap;
}

function columnEdges(
  left: number,
  right: number,
  count: number,
): { left: number; right: number }[] {
  const total = right - left;
  const weights =
    count === LINE_COL_WEIGHTS.length
      ? (LINE_COL_WEIGHTS as readonly number[])
      : Array.from({ length: count }, () => 1 / count);
  const edges: { left: number; right: number }[] = [];
  let acc = left;
  for (let i = 0; i < count; i++) {
    const w = total * (weights[i] ?? 1 / count);
    edges.push({ left: acc, right: acc + w });
    acc += w;
  }
  return edges;
}

function drawTableBlock(
  page: PDFPage,
  font: PDFFont,
  block: PdfTableBlock,
  startY: number,
): number {
  const left = LAYOUT.marginX;
  const right = LAYOUT.pageWidth - LAYOUT.marginX;
  const size = LAYOUT.baseFontSize;
  const cellPad = 3;
  let y = startY;
  const edges = columnEdges(left, right, Math.max(block.columns.length, 1));

  // En-tête de colonnes (gras) + filet.
  block.columns.forEach((col, i) => {
    const edge = edges[i];
    if (edge === undefined) return;
    const maxW = edge.right - edge.left - cellPad;
    const t = fitText(font, col.header, size, maxW);
    const x = alignedX(font, t, size, col.align, edge.left, edge.right - cellPad);
    strike(page, font, t, x, y - size, size, true);
  });
  y -= lineHeight(size);
  page.drawLine({ start: { x: left, y }, end: { x: right, y }, thickness: 0.5 });
  y -= tableHeaderHeight() - lineHeight(size);

  // Lignes de données (segments séparés par <br> en sous-lignes plus petites).
  for (const row of block.rows) {
    row.forEach((cell, i) => {
      const edge = edges[i];
      if (edge === undefined) return;
      const maxW = edge.right - edge.left - cellPad;
      let segY = y - size;
      cell.segments.forEach((seg, si) => {
        const segSize = si === 0 ? size : size - 1;
        const t = fitText(font, seg, segSize, maxW);
        const x = alignedX(font, t, segSize, cell.align, edge.left, edge.right - cellPad);
        strike(page, font, t, x, segY, segSize, false);
        segY -= lineHeight(size);
      });
    });
    y -= tableRowHeight(row);
  }
  return y - LAYOUT.blockGap;
}

function drawLogo(page: PDFPage, image: PDFImage): void {
  const maxH = LAYOUT.logoHeight;
  const maxW = 150;
  const scale = Math.min(maxW / image.width, maxH / image.height, 1);
  const w = image.width * scale;
  const h = image.height * scale;
  page.drawImage(image, {
    x: LAYOUT.pageWidth - LAYOUT.marginX - w,
    y: LAYOUT.contentTop - h,
    width: w,
    height: h,
  });
}

function drawFooter(
  page: PDFPage,
  font: PDFFont,
  pageNo: number,
  total: number,
  footerLine: string | undefined,
): void {
  const size = LAYOUT.footerSize;
  const left = LAYOUT.marginX;
  const right = LAYOUT.pageWidth - LAYOUT.marginX;
  const baseY = 44;
  if (footerLine !== undefined && footerLine !== "") {
    const t = fitText(font, footerLine, size, right - left);
    const x = alignedX(font, t, size, "center", left, right);
    strike(page, font, t, x, baseY + lineHeight(size), size, false);
  }
  // F4 (recette sprint-07) — « Page X / Y » toujours rendu, y compris en
  // mono-page (« Page 1 / 1 »).
  const label = `Page ${String(pageNo)} / ${String(total)}`;
  const x = alignedX(font, label, size, "center", left, right);
  strike(page, font, label, x, baseY, size, false);
}

async function drawRenderedContent(
  pdfDoc: PDFDocument,
  font: PDFFont,
  content: PdfRenderContent,
): Promise<void> {
  let logoImage: PDFImage | undefined;
  if (content.logo !== undefined) {
    logoImage =
      content.logo.format === "png"
        ? await pdfDoc.embedPng(content.logo.bytes)
        : await pdfDoc.embedJpg(content.logo.bytes);
  }
  const total = content.pages.length;
  content.pages.forEach((blocks, idx) => {
    const page = pdfDoc.addPage([LAYOUT.pageWidth, LAYOUT.pageHeight]);
    page.setFont(font);
    if (logoImage !== undefined) drawLogo(page, logoImage);
    let y: number = LAYOUT.contentTop;
    for (const block of blocks) {
      y =
        block.kind === "text"
          ? drawTextBlock(page, font, block, y)
          : drawTableBlock(page, font, block, y);
    }
    drawFooter(page, font, idx + 1, total, content.footerLine);
  });
}

export async function assembleFacturXPdfA3(input: AssembleInput): Promise<Uint8Array> {
  const generationDate = input.generationDate ?? new Date();
  const pdfDoc = await PDFDocument.create({ updateMetadata: false });
  // Fontkit nécessaire pour `embedFont(ttfBytes)` (les Standard 14 fonts
  // ne sont pas embed et violent PDF/A-3 §6.2.11.4.1).
  pdfDoc.registerFontkit(fontkit);

  // 1. Métadonnées PDF standard (avant XMP — pdf-lib ne les écrit pas dans Info
  // si on injecte le XMP nous-mêmes, mais on les pose par sécurité).
  pdfDoc.setTitle(`Facture ${input.metadata.invoiceNumber}`);
  pdfDoc.setAuthor(input.metadata.sellerName);
  pdfDoc.setSubject("Facture électronique Factur-X EN 16931");
  pdfDoc.setProducer("Factur-e builder spike");
  pdfDoc.setCreator("Factur-e");
  pdfDoc.setCreationDate(generationDate);
  pdfDoc.setModificationDate(generationDate);

  // 2. Pages visuelles avec police Roboto embarquée (PDF/A-3 §6.2.11.4.1
  // exige que toutes les fonts utilisées soient embed — les StandardFonts
  // de pdf-lib ne le sont pas). Si `content` fourni → rendu moteur de
  // template paginé ; sinon stub MVP minimal (rétro-compat tests + appelants
  // non migrés vers `renderInvoicePdfFromModel`).
  const fontBytes = await readFile(FONT_PATH);
  const font = await pdfDoc.embedFont(fontBytes, { subset: true });
  if (input.content !== undefined && input.content.pages.length > 0) {
    await drawRenderedContent(pdfDoc, font, input.content);
  } else {
    const page = pdfDoc.addPage([LAYOUT.pageWidth, LAYOUT.pageHeight]);
    page.setFont(font);
    page.drawText(`Facture ${input.metadata.invoiceNumber}`, { x: 50, y: 800, size: 14 });
    page.drawText(input.metadata.sellerName, { x: 50, y: 770, size: 10 });
    page.drawText("Document hybride PDF/A-3 + factur-x.xml (cf. annexe XML CII).", {
      x: 50,
      y: 740,
      size: 10,
    });
  }

  // 3. OutputIntent sRGB. Lecture du profil ICC embarqué.
  const iccBytes = await readFile(ICC_PATH);
  const iccStream = pdfDoc.context.stream(iccBytes, {
    N: 3,
    Length: iccBytes.length,
  });
  const iccStreamRef = pdfDoc.context.register(iccStream);

  const outputIntent = pdfDoc.context.obj({
    Type: "OutputIntent",
    S: "GTS_PDFA1",
    OutputConditionIdentifier: PDFString.of("sRGB IEC61966-2.1"),
    OutputCondition: PDFString.of("sRGB IEC61966-2.1"),
    Info: PDFString.of("sRGB IEC61966-2.1"),
    RegistryName: PDFString.of("http://www.color.org"),
    DestOutputProfile: iccStreamRef,
  });
  const outputIntentRef = pdfDoc.context.register(outputIntent);
  const outputIntentsArray = pdfDoc.context.obj([outputIntentRef]);
  pdfDoc.catalog.set(PDFName.of("OutputIntents"), outputIntentsArray);

  // 4. Métadonnées XMP — PDF/A-3 + extension fx: Factur-X.
  const xmp = buildFacturXXmp({
    invoiceNumber: input.metadata.invoiceNumber,
    sellerName: input.metadata.sellerName,
    conformanceLevel: input.conformanceLevel,
    generationDate,
  });
  const xmpBytes = new TextEncoder().encode(xmp);
  const metadataStream = pdfDoc.context.stream(xmpBytes, {
    Type: "Metadata",
    Subtype: "XML",
    Length: xmpBytes.length,
  });
  const metadataRef = pdfDoc.context.register(metadataStream);
  pdfDoc.catalog.set(PDFName.of("Metadata"), metadataRef);

  // 5. Attachement du XML CII en Associated File.
  // L'API haut-niveau `attach` de pdf-lib pose les bons champs (EFF, AFRelationship,
  // /Type /Filespec, /UF, /F, /EF avec /F + /UF). On confirme en post.
  await pdfDoc.attach(input.xmlBytes, FACTUR_X_XML_FILENAME, {
    mimeType: FACTUR_X_XML_MIME_TYPE,
    description: "Factur-X XML invoice (CII)",
    creationDate: generationDate,
    modificationDate: generationDate,
    afRelationship: AFRelationship.Alternative,
  });

  // 7. Trailer /ID — pdf-lib v1.17 ne le pose pas avec useObjectStreams: false.
  //    PDF/A-3 §6.1.3 exige une paire d'identifiants (premier doc = identique).
  const fileId = computeFileIdentifier(
    input.metadata.invoiceNumber,
    input.metadata.sellerName,
    generationDate,
  );
  const idHex = PDFHexString.of(fileId);
  pdfDoc.context.trailerInfo.ID = pdfDoc.context.obj([idHex, idHex]);

  // 6. Sauvegarde. Note : pdf-lib n'a pas de mode "déterministe" natif, mais
  // l'option useObjectStreams: false simplifie la structure pour les golden tests.
  return pdfDoc.save({
    useObjectStreams: false,
    addDefaultPage: false,
  });
}

// Ré-export bas-niveau utile pour les tests structurels.
export { decodePDFRawStream, PDFArray, PDFHexString, PDFName, PDFRawStream };
