// Retour-ligne automatique des blocs texte pleine largeur (F2 recette sprint-07
// : mention LME PMD tronquée par `fitText`, clip single-line). Appliqué AVANT la
// pagination pour que les hauteurs estimées (`textBlockHeight`) correspondent à
// l'avance verticale dessinée par `assemble.ts` (invariant pagination.ts §8-9).
//
// Périmètre V1 : blocs texte pleine largeur (mentions légales, notes, pied,
// mention d'en-tête). Les cellules de tableau (largeur par colonne) restent en
// `fitText`-troncature — segments courts, hors scope F2.

import type { PDFFont } from "pdf-lib";

import type { PdfBlock, PdfTextLine } from "./html-to-pdf-blocks.js";
import { LAYOUT } from "./pagination.js";

/** Largeur disponible pour un bloc texte pleine largeur (marges gauche/droite). */
const FULL_WIDTH = LAYOUT.pageWidth - 2 * LAYOUT.marginX;

function measure(font: PDFFont, text: string, size: number): number {
  try {
    return font.widthOfTextAtSize(text, size);
  } catch {
    return text.length * size * 0.5; // garde-fou glyphe absent (cf. assemble.textWidth)
  }
}

/**
 * Découpe `text` en lignes qui tiennent dans `maxWidth`, en coupant aux espaces.
 * Un mot seul plus large que `maxWidth` est conservé tel quel (rare : URL, IBAN)
 * — `fitText` le tronquera en dernier recours à l'assemblage. Retourne toujours
 * au moins une ligne.
 */
export function wrapText(font: PDFFont, text: string, size: number, maxWidth: number): string[] {
  if (maxWidth <= 0 || measure(font, text, size) <= maxWidth) return [text];
  const words = text.split(/\s+/);
  const lines: string[] = [];
  let current = "";
  for (const word of words) {
    const candidate = current === "" ? word : `${current} ${word}`;
    if (measure(font, candidate, size) <= maxWidth) {
      current = candidate;
      continue;
    }
    if (current !== "") lines.push(current);
    current = word;
  }
  if (current !== "") lines.push(current);
  return lines.length > 0 ? lines : [text];
}

/**
 * Applique le wrap à chaque ligne des blocs texte (pleine largeur). Une
 * `PdfTextLine` débordante devient N lignes conservant `align`/`size`/`bold`.
 * Les blocs table sont retournés inchangés.
 */
export function wrapTextBlocks(blocks: PdfBlock[], font: PDFFont): PdfBlock[] {
  return blocks.map((block) => {
    if (block.kind !== "text") return block;
    const lines: PdfTextLine[] = block.lines.flatMap((line) => {
      const size = line.size ?? LAYOUT.baseFontSize;
      return wrapText(font, line.text, size, FULL_WIDTH).map((text) => ({ ...line, text }));
    });
    return { ...block, lines };
  });
}
