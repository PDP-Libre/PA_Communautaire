// Chargement de la police Roboto (Apache 2.0) partagée par l'assemblage PDF/A-3
// (`assemble.ts`, font de dessin embarquée) et le wrap font-aware (`text-wrap.ts`,
// font de MESURE). PDF/A interdit les fonts non embarquées — Roboto-Regular est
// déjà validée veraPDF (cf. ADR-004).

import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import path from "node:path";
import fontkit from "@pdf-lib/fontkit";
import { PDFDocument, type PDFFont } from "pdf-lib";

const HERE = path.dirname(fileURLToPath(import.meta.url));
// HERE = .../packages/factur-x-builder/src/pdf-assembly → assets à ../../assets
const ASSETS_DIR = path.resolve(HERE, "..", "..", "assets");
export const FONT_PATH = path.join(ASSETS_DIR, "Roboto-Regular.ttf");

/** Octets bruts de la police (TTF). */
export function loadFontBytes(): Promise<Buffer> {
  return readFile(FONT_PATH);
}

/**
 * Font de MESURE (`widthOfTextAtSize`) pour le wrap font-aware — embarquée dans
 * un document pdf-lib jetable, indépendant du PDF final. Mêmes métriques que la
 * font de dessin (même TTF) : le wrap calculé ici correspond exactement à
 * l'avance horizontale appliquée à l'assemblage. `subset: false` (pas de
 * sous-ensemble — on mesure, on ne sérialise pas).
 */
export async function createMeasureFont(): Promise<PDFFont> {
  const doc = await PDFDocument.create();
  doc.registerFontkit(fontkit);
  return doc.embedFont(await loadFontBytes(), { subset: false });
}
