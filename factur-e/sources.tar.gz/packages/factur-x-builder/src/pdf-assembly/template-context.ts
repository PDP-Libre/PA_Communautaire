// `PdfTemplateContext` — modèle de données injecté runtime dans les templates
// Nunjucks `.njk` (ADR-013 D4 slots data injection : les templates reçoivent
// leur contexte, ils ne hardcodent aucune donnée métier).
//
// Source de vérité : le modèle EN 16931 `CrossIndustryInvoice` (CII) +
// un enrichissement `PdfEnrichment` peuplé par la couche `apps/api` pour les
// champs ABSENTS du CII mais requis au PDF (Capital social, RCS, forme
// juridique, logo binaire, INCOTERM finding K1). Le builder n'a pas d'accès
// BDD : tout ce qui n'est pas dans le CII transite par `PdfEnrichment`.
//
// Les libellés de préfixe ("SIREN ", "Total HT : ", …) vivent dans les
// templates `.njk` (verbatim glossaire utilisateur §2 — ADR-013 D3). Ce module
// ne fait que mapper la donnée brute typée.

import {
  INVOICE_TYPE_CODES,
  NOTE_SUBJECT_CODES,
  PAYMENT_MEANS_CODES,
  UNIT_CODES,
  type CrossIndustryInvoice,
  type PostalAddress,
} from "@factur-e/factur-x-model";

// ---------------------------------------------------------------------------
// Enrichissement BDD — champs hors CII fournis par `apps/api`.
// ---------------------------------------------------------------------------

/** Logo customer déjà téléchargé (S3) — PNG/JPEG only (ZG-B3). */
export interface PdfLogo {
  bytes: Uint8Array;
  /** Format embarqué par pdf-lib — SVG non supporté (fallback texte amont). */
  format: "png" | "jpeg";
}

/** Champs vendeur absents du CII (table `customers`). */
export interface PdfSellerEnrichment {
  /** `customers.rcs` — affiché préfixé "RCS " (BT-30 voisin). */
  rcs?: string | null;
  /** Libellé forme juridique résolu amont via `juridiqueLabel(code)`. */
  juridiqueLabel?: string | null;
  /** `customers.capital_social` (numeric→text "10000.00"). Affiché si présent
   *  (le formulaire ne le capture que pour SAS/SA/SARL — pas de flag requis). */
  capitalSocial?: string | null;
}

/** Enrichissement PDF complet (tout optionnel — rendu défensif si absent). */
export interface PdfEnrichment {
  seller?: PdfSellerEnrichment;
  /** Logo binaire (dessiné par pdf-lib, hors template texte). */
  logo?: PdfLogo;
  /** INCOTERM (BT-X-22) — finding K1 : non mappé `formToModel` V1, donc
   *  fourni ici si disponible, sinon section §4.9 vide proprement. */
  incoterm?: string | null;
  /** Codes internes par `lineID` — `invoice_lines` ne les persiste pas V1
   *  (NOTE-COWORK), donc optionnel et généralement absent. */
  lineInternalCodes?: Record<string, string>;
}

// ---------------------------------------------------------------------------
// Contexte de template (consommé par Nunjucks).
// ---------------------------------------------------------------------------

export interface PdfPartyContext {
  name: string;
  /** BT-28 / BT-45 — appellation commerciale (si distincte de la raison sociale). */
  tradingName?: string;
  addressLines: string[];
  /** SIREN/SIRET (valeur seule — le template ajoute le préfixe "SIREN "). */
  siren?: string;
  /** BT-29 / BT-46 — identifiant privé (GLN/DUNS). */
  globalId?: string;
  vatNumber?: string;
  // Vendeur uniquement (enrichissement) :
  rcs?: string;
  juridiqueLabel?: string;
  /** Montant brut "10000.00" — formaté par `|format_amount_fr` au template. */
  capitalSocial?: string;
}

export interface PdfLineContext {
  internalCode?: string;
  label: string;
  description?: string;
  quantity: number;
  unitLabel: string;
  unitPriceHt: number;
  allowance?: number;
  lineNetAmount: number;
  vatRatePercent?: number;
}

export interface PdfVatBreakdownContext {
  ratePercent?: number;
  /** BT-116 — base imposable du taux. */
  basisAmount: number;
  /** BT-117 — montant de TVA du taux. */
  calculatedAmount: number;
  categoryCode: string;
  /** BT-120 — motif d'exonération (si catégorie exonérée). */
  exemptionReason?: string;
}

export interface PdfTotalsContext {
  totalHt: number;
  documentAllowance?: number;
  /** BG-21 — frais/charge au niveau document. */
  documentCharge?: number;
  vatBreakdowns: PdfVatBreakdownContext[];
  vatTotal: number;
  grandTotal: number;
  paidAmount?: number;
  duePayable: number;
}

export interface PdfPaymentContext {
  iban?: string;
  bic?: string;
  paymentTerms?: string;
  /** YYYYMMDD — formaté `|format_date_fr`. */
  dueDate?: string;
  methodLabel?: string;
  /** BT-83 — référence de paiement (réconciliation End-to-End). */
  reference?: string;
}

/** BG-10 — bénéficiaire du paiement, si distinct du vendeur (factoring). */
export interface PdfPayeeContext {
  name: string;
  globalId?: string;
  siren?: string;
}

/** Références acheteur / commande / contrat (BT-10 / BT-13 / BT-12). */
export interface PdfReferencesContext {
  buyerReference?: string;
  buyerOrderReference?: string;
  contractReference?: string;
}

/** BG-11/BG-12 — représentant fiscal du vendeur. */
export interface PdfTaxRepresentativeContext {
  name: string;
  addressLines: string[];
  vatNumber?: string;
}

export interface PdfPrecedingInvoiceContext {
  number: string;
  /** YYYYMMDD — formaté `|format_date_fr`. */
  issueDate: string;
}

export interface PdfNoteContext {
  content: string;
}

/** §4.9 — Livraison (INCOTERM + date + références + adresse). */
export interface PdfDeliveryContext {
  /** Libellé long FR INCOTERM (ex "DAP — Rendu au lieu de destination"). */
  incotermLabel?: string;
  /** BT-72 — date de livraison (YYYYMMDD). */
  date?: string;
  /** BT-16 — n° de bon de livraison / d'expédition. */
  despatchReference?: string;
  addressLines?: string[];
}

export interface PdfTemplateContext {
  /** BT-3 — 380 / 381 / 384. Pilote le choix du template `.njk`. */
  documentTypeCode: string;
  invoiceNumber: string;
  /** YYYYMMDD. */
  issueDate: string;
  dueDate?: string;
  /** BT-5 — devise de facturation (ISO 4217). */
  currency: string;
  seller: PdfPartyContext;
  buyer: PdfPartyContext;
  /** BG-11/BG-12 — représentant fiscal du vendeur (si présent). */
  taxRepresentative?: PdfTaxRepresentativeContext;
  /** Présent si logo embarqué — le template réserve la place, l'image est
   *  dessinée par `assemble.ts` (binaire, hors HTML texte). */
  hasLogo: boolean;
  precedingInvoice?: PdfPrecedingInvoiceContext;
  /** Références acheteur / commande / contrat (si présentes). */
  references?: PdfReferencesContext;
  lines: PdfLineContext[];
  totals: PdfTotalsContext;
  payment?: PdfPaymentContext;
  /** BG-10 — bénéficiaire distinct du vendeur (si présent). */
  payee?: PdfPayeeContext;
  /** §4.8 — mentions légales LME (BR-FR-05 PMT/PMD/AAB). */
  legalMentions: PdfNoteContext[];
  /** §4.9 — Livraison / INCOTERM (finding K1 défensif). */
  delivery?: PdfDeliveryContext;
  /** §4.10 — note publique / commentaires (sans qualifier) — pied de tableau lignes. */
  notes: PdfNoteContext[];
  /** §4.10 — mentions de pied (REG/TXD…) — pied de page après LME. */
  footerMentions: PdfNoteContext[];
}

// ---------------------------------------------------------------------------
// Tables de libellés (verbatim — codes fermés spec).
// ---------------------------------------------------------------------------

/** Libellés courts FR d'unité (BT-130 UN/ECE Rec 20). Fallback = code brut. */
const UNIT_LABELS_FR: Record<string, string> = {
  [UNIT_CODES.PIECE]: "u",
  [UNIT_CODES.HOUR]: "h",
  [UNIT_CODES.DAY]: "j",
  [UNIT_CODES.MONTH]: "mois",
  [UNIT_CODES.YEAR]: "an",
  [UNIT_CODES.MINUTE]: "min",
  [UNIT_CODES.KILOGRAM]: "kg",
  [UNIT_CODES.GRAM]: "g",
  [UNIT_CODES.TONNE]: "t",
  [UNIT_CODES.LITRE]: "L",
  [UNIT_CODES.METRE]: "m",
  [UNIT_CODES.SQUARE_METRE]: "m²",
  [UNIT_CODES.CUBIC_METRE]: "m³",
  [UNIT_CODES.KILOMETRE]: "km",
};

/** Libellés courts FR de moyen de paiement (BT-81 UNTDID 4461). */
const PAYMENT_METHOD_LABELS_FR: Record<string, string> = {
  [PAYMENT_MEANS_CODES.CASH]: "Espèces",
  [PAYMENT_MEANS_CODES.CHEQUE]: "Chèque",
  [PAYMENT_MEANS_CODES.CREDIT_TRANSFER]: "Virement",
  [PAYMENT_MEANS_CODES.BANK_PAYMENT]: "Virement",
  [PAYMENT_MEANS_CODES.CARD]: "Carte bancaire",
  [PAYMENT_MEANS_CODES.DIRECT_DEBIT]: "Prélèvement SEPA",
  [PAYMENT_MEANS_CODES.SEPA_CREDIT_TRANSFER]: "Virement SEPA",
  [PAYMENT_MEANS_CODES.SEPA_DIRECT_DEBIT]: "Prélèvement SEPA",
};

/** Libellés longs FR INCOTERM (BR-FREXT-CL-27 whitelist 13 valeurs). */
const INCOTERM_LABELS_FR: Record<string, string> = {
  "1": "Départ usine (ancien)",
  "2": "Franco transporteur (ancien)",
  CFR: "CFR — Coût et fret",
  CIF: "CIF — Coût, assurance et fret",
  CIP: "CIP — Port payé, assurance comprise",
  CPT: "CPT — Port payé jusqu'à",
  DAP: "DAP — Rendu au lieu de destination",
  DDP: "DDP — Rendu droits acquittés",
  DPU: "DPU — Rendu au lieu de destination déchargé",
  EXW: "EXW — À l'usine",
  FAS: "FAS — Franco le long du navire",
  FCA: "FCA — Franco transporteur",
  FOB: "FOB — Franco à bord",
};

/** Sujets de note classés comme mentions légales LME (§4.8). */
const LME_SUBJECT_CODES = new Set<string>([
  NOTE_SUBJECT_CODES.PAYMENT_TERMS, // PMT
  NOTE_SUBJECT_CODES.PAYMENT_MEANS_NOTE, // PMD
  NOTE_SUBJECT_CODES.ADDITIONAL_BUYER_REF, // AAB
]);

// ---------------------------------------------------------------------------
// Helpers de mapping.
// ---------------------------------------------------------------------------

/** Assemble les lignes d'adresse postale dans l'ordre lisible FR. */
function addressToLines(addr: PostalAddress | undefined): string[] {
  if (addr === undefined) return [];
  const lines: string[] = [];
  if (addr.lineOne !== undefined && addr.lineOne !== "") lines.push(addr.lineOne);
  if (addr.lineTwo !== undefined && addr.lineTwo !== "") lines.push(addr.lineTwo);
  if (addr.lineThree !== undefined && addr.lineThree !== "") lines.push(addr.lineThree);
  const cityLine = [addr.postalCode, addr.cityName].filter((v) => v !== undefined && v !== "");
  if (cityLine.length > 0) lines.push(cityLine.join(" "));
  if (addr.countryCode !== "" && addr.countryCode !== "FR") {
    lines.push(addr.countryCode);
  }
  return lines;
}

function unitLabel(code: string): string {
  return UNIT_LABELS_FR[code] ?? code;
}

function nonEmpty(value: string | null | undefined): string | undefined {
  return value !== null && value !== undefined && value !== "" ? value : undefined;
}

/**
 * Construit le `PdfTemplateContext` à partir du modèle CII + enrichissement BDD.
 * Tout champ absent dégrade proprement (sections conditionnelles `{% if %}`
 * côté template — ADR-009 fail-safe).
 */
export function buildTemplateContext(
  invoice: CrossIndustryInvoice,
  enrichment: PdfEnrichment = {},
): PdfTemplateContext {
  const { exchangedDocument: doc, tradeTransaction: tx } = invoice;
  const { tradeAgreement: agreement, tradeSettlement: settlement, tradeDelivery: delivery } = tx;

  const seller = agreement.sellerTradeParty;
  const buyer = agreement.buyerTradeParty;
  const sellerEnr = enrichment.seller ?? {};

  const sellerCtx: PdfPartyContext = {
    name: seller.name,
    tradingName: nonEmpty(seller.tradingName),
    addressLines: addressToLines(seller.postalAddress),
    siren: seller.legalRegistrationID?.value,
    globalId: seller.globalID?.value,
    vatNumber: seller.vatID?.value,
    rcs: nonEmpty(sellerEnr.rcs),
    juridiqueLabel: nonEmpty(sellerEnr.juridiqueLabel),
    capitalSocial: nonEmpty(sellerEnr.capitalSocial),
  };

  const buyerCtx: PdfPartyContext = {
    name: buyer.name,
    tradingName: nonEmpty(buyer.tradingName),
    addressLines: addressToLines(buyer.postalAddress),
    siren: buyer.legalRegistrationID?.value,
    globalId: buyer.globalID?.value,
    vatNumber: buyer.vatID?.value,
  };

  const taxRep = agreement.sellerTaxRepresentative;
  const taxRepresentative: PdfTaxRepresentativeContext | undefined =
    taxRep !== undefined
      ? {
          name: taxRep.name,
          addressLines: addressToLines(taxRep.postalAddress),
          vatNumber: taxRep.vatID.value,
        }
      : undefined;

  const references = mapReferences(agreement);

  const lines: PdfLineContext[] = tx.lineItems.map((item) => {
    const allowanceTotal = (item.tradeSettlement.lineAllowances ?? [])
      .filter((a) => !a.isCharge)
      .reduce((sum, a) => sum + a.actualAmount, 0);
    return {
      internalCode:
        enrichment.lineInternalCodes?.[item.lineID] ?? item.product.sellerAssignedID?.value,
      label: item.product.name,
      description: nonEmpty(item.product.description),
      quantity: item.tradeDelivery.billedQuantity,
      unitLabel: unitLabel(item.tradeDelivery.unitCode),
      unitPriceHt: item.tradeAgreement.netPrice,
      allowance: allowanceTotal > 0 ? allowanceTotal : undefined,
      lineNetAmount: item.tradeSettlement.netLineAmount,
      vatRatePercent: item.tradeSettlement.vatInformation.ratePercent,
    };
  });

  const ms = settlement.monetarySummation;
  const sumAC = (list: typeof settlement.documentAllowances, charge: boolean): number =>
    (list ?? []).filter((a) => a.isCharge === charge).reduce((sum, a) => sum + a.actualAmount, 0);
  const documentAllowance = sumAC(settlement.documentAllowances, false);
  const documentCharge =
    sumAC(settlement.documentAllowances, true) + sumAC(settlement.documentCharges, true);
  const totals: PdfTotalsContext = {
    totalHt: ms.taxBasisTotalAmount,
    documentAllowance: documentAllowance > 0 ? documentAllowance : undefined,
    documentCharge: documentCharge > 0 ? documentCharge : undefined,
    vatBreakdowns: settlement.vatBreakdowns.map((vb) => ({
      ratePercent: vb.ratePercent,
      basisAmount: vb.taxBasisAmount,
      calculatedAmount: vb.calculatedAmount,
      categoryCode: vb.categoryCode,
      exemptionReason: nonEmpty(vb.exemptionReason),
    })),
    vatTotal: ms.vatTotalAmount?.value ?? 0,
    grandTotal: ms.grandTotalAmount,
    paidAmount: ms.paidAmount !== undefined && ms.paidAmount > 0 ? ms.paidAmount : undefined,
    duePayable: ms.duePayableAmount,
  };

  const payment = mapPayment(invoice);
  const payee = mapPayee(settlement.payeeParty);

  const preceding = settlement.precedingInvoices?.[0];
  const precedingInvoice: PdfPrecedingInvoiceContext | undefined =
    preceding !== undefined
      ? { number: preceding.invoiceNumber, issueDate: preceding.issueDate?.value ?? "" }
      : undefined;

  // Tri des notes BG-1 en 3 zones distinctes (placements différents au PDF) :
  //  - LME (PMT/PMD/AAB)         → mentions légales bas de page (§4.8).
  //  - Note publique (sans code) → pied de tableau lignes (§4.10).
  //  - Mentions de pied (REG/TXD…) → pied de page après LME (§4.10).
  const allNotes = doc.includedNotes ?? [];
  const legalMentions: PdfNoteContext[] = allNotes
    .filter((n) => n.subjectCode !== undefined && LME_SUBJECT_CODES.has(n.subjectCode))
    .map((n) => ({ content: n.content }));
  const notes: PdfNoteContext[] = allNotes
    .filter((n) => n.subjectCode === undefined)
    .map((n) => ({ content: n.content }));
  const footerMentions: PdfNoteContext[] = allNotes
    .filter((n) => n.subjectCode !== undefined && !LME_SUBJECT_CODES.has(n.subjectCode))
    .map((n) => ({ content: n.content }));

  const deliveryCtx = mapDelivery(enrichment.incoterm, delivery);

  return {
    documentTypeCode: doc.invoiceTypeCode,
    invoiceNumber: doc.invoiceNumber,
    issueDate: doc.issueDate.value,
    dueDate: settlement.dueDate?.value,
    currency: settlement.invoiceCurrencyCode,
    seller: sellerCtx,
    buyer: buyerCtx,
    taxRepresentative,
    hasLogo: enrichment.logo !== undefined,
    precedingInvoice,
    references,
    lines,
    totals,
    payment,
    payee,
    legalMentions,
    delivery: deliveryCtx,
    notes,
    footerMentions,
  };
}

function mapPayment(invoice: CrossIndustryInvoice): PdfPaymentContext | undefined {
  const settlement = invoice.tradeTransaction.tradeSettlement;
  const means = settlement.paymentMeans?.[0];
  const account = means?.payeeFinancialAccounts?.[0];
  // IBAN affiché uniquement si le compte est qualifié IBAN (sinon ProprietaryID
  // bancaire non pertinent au PDF lisible).
  const iban = account?.accountID.schemeID === "IBAN" ? account.accountID.value : undefined;
  const ctx: PdfPaymentContext = {
    iban: nonEmpty(iban),
    bic: nonEmpty(account?.financialInstitutionID?.value),
    paymentTerms: nonEmpty(settlement.paymentTermsDescription),
    dueDate: settlement.dueDate?.value,
    methodLabel:
      means?.typeCode !== undefined ? PAYMENT_METHOD_LABELS_FR[means.typeCode] : undefined,
    reference: nonEmpty(settlement.paymentReference),
  };
  // Aucun champ paiement → pas de bloc (rendu défensif finding G).
  if (
    ctx.iban === undefined &&
    ctx.bic === undefined &&
    ctx.paymentTerms === undefined &&
    ctx.methodLabel === undefined &&
    ctx.dueDate === undefined &&
    ctx.reference === undefined
  ) {
    return undefined;
  }
  return ctx;
}

/** BG-10 — bénéficiaire distinct du vendeur (factoring / cession de créance). */
function mapPayee(
  payee: CrossIndustryInvoice["tradeTransaction"]["tradeSettlement"]["payeeParty"],
): PdfPayeeContext | undefined {
  if (payee === undefined) return undefined;
  return {
    name: payee.name,
    globalId: payee.globalID?.value,
    siren: payee.legalRegistrationID?.value,
  };
}

function mapReferences(
  agreement: CrossIndustryInvoice["tradeTransaction"]["tradeAgreement"],
): PdfReferencesContext | undefined {
  const ctx: PdfReferencesContext = {
    buyerReference: nonEmpty(agreement.buyerReference),
    buyerOrderReference: nonEmpty(agreement.buyerOrderReference),
    contractReference: nonEmpty(agreement.contractReference),
  };
  if (
    ctx.buyerReference === undefined &&
    ctx.buyerOrderReference === undefined &&
    ctx.contractReference === undefined
  ) {
    return undefined;
  }
  return ctx;
}

function mapDelivery(
  incotermCode: string | null | undefined,
  delivery: CrossIndustryInvoice["tradeTransaction"]["tradeDelivery"],
): PdfDeliveryContext | undefined {
  const code = nonEmpty(incotermCode);
  const incotermLabel = code !== undefined ? (INCOTERM_LABELS_FR[code] ?? code) : undefined;
  const addressLines = addressToLines(delivery.deliveryAddress);
  const ctx: PdfDeliveryContext = {
    incotermLabel,
    date: delivery.actualDeliveryDate?.value,
    despatchReference: nonEmpty(delivery.despatchAdviceReference),
    addressLines: addressLines.length > 0 ? addressLines : undefined,
  };
  if (
    ctx.incotermLabel === undefined &&
    ctx.date === undefined &&
    ctx.despatchReference === undefined &&
    ctx.addressLines === undefined
  ) {
    return undefined;
  }
  return ctx;
}

/** Choisit le template `.njk` selon BT-3 (380 / 381 / 384). */
export function templateNameFor(documentTypeCode: string): string {
  switch (documentTypeCode) {
    case INVOICE_TYPE_CODES.CREDIT_NOTE: // 381
      return "credit-note.njk";
    case INVOICE_TYPE_CODES.CORRECTIVE: // 384
      return "corrective-invoice.njk";
    default: // 380 + variantes facture
      return "invoice-default.njk";
  }
}
