// Pagination multi-page (ZG-B2) — Sophie TPE 30-60 fact/mois, factures
// multi-lignes courantes. Découpe le flux de blocs en pages A4 : l'en-tête
// (vendeur + titre) est répété en haut de chaque page, la table de lignes est
// scindée quand elle déborde, le pied "Page X / Y" + Capital social est dessiné
// par `assemble.ts` à partir du nombre de pages retourné ici.
//
// Hypothèse V1 : pas de retour-ligne automatique (chaque segment = une ligne).
// Les hauteurs estimées ici DOIVENT correspondre à l'avance verticale appliquée
// par `assemble.ts` (helpers partagés exportés) pour éviter tout débordement.

import type { PdfBlock, PdfTableBlock, PdfTextBlock } from "./html-to-pdf-blocks.js";

export const LAYOUT = {
  pageWidth: 595.28,
  pageHeight: 841.89,
  marginX: 50,
  /** Ordonnée de départ du contenu (haut de page). */
  contentTop: 800,
  /** Ordonnée plancher du contenu (sous laquelle on pagine). Laisse un espace
   *  net au-dessus du pied de page interne (Capital social + "Page X / Y"
   *  dessinés vers y≈44-64 par `assemble.ts`). */
  contentBottom: 78,
  baseFontSize: 9,
  /** Interligne ajouté à la taille de police. */
  lineGap: 4,
  /** Espace vertical après un bloc. */
  blockGap: 12,
  /** Hauteur supplémentaire d'une ligne d'en-tête de table (filet inclus). */
  tableHeaderExtra: 6,
  footerSize: 8,
  /** Marge réservée au logo en haut (si présent) — décale le 1er bloc. */
  logoHeight: 48,
} as const;

/** Noms de blocs répétés en haut de chaque page. */
export const REPEAT_BLOCK_NAMES = ["header", "title"] as const;

/** Hauteur d'une ligne de texte pour une taille donnée. */
export function lineHeight(size: number): number {
  return size + LAYOUT.lineGap;
}

/** Hauteur totale d'un bloc texte (lignes + espace de bloc). */
export function textBlockHeight(block: PdfTextBlock): number {
  const sum = block.lines.reduce((acc, l) => acc + lineHeight(l.size ?? LAYOUT.baseFontSize), 0);
  return sum + LAYOUT.blockGap;
}

/** Hauteur d'une ligne de données de table (max segments parmi les cellules). */
export function tableRowHeight(row: PdfTableBlock["rows"][number]): number {
  const maxSegments = row.reduce((m, cell) => Math.max(m, cell.segments.length), 1);
  return maxSegments * lineHeight(LAYOUT.baseFontSize);
}

/** Hauteur fixe d'en-tête de table (ligne de titres + filet + espace bloc). */
export function tableHeaderHeight(): number {
  return lineHeight(LAYOUT.baseFontSize) + LAYOUT.tableHeaderExtra;
}

function blockHeight(block: PdfBlock): number {
  return block.kind === "text"
    ? textBlockHeight(block)
    : tableHeaderHeight() +
        block.rows.reduce((acc, r) => acc + tableRowHeight(r), 0) +
        LAYOUT.blockGap;
}

function tableChunk(block: PdfTableBlock, rows: PdfTableBlock["rows"]): PdfTableBlock {
  return { kind: "table", name: block.name, columns: block.columns, rows };
}

/**
 * Découpe les blocs en pages. L'en-tête (`header` + `title`) est cloné en tête
 * de chaque page ; la table `lines` est scindée si nécessaire. Retourne au
 * moins une page (même vide).
 */
export function paginateBlocks(blocks: PdfBlock[]): PdfBlock[][] {
  const repeatNames = new Set<string>(REPEAT_BLOCK_NAMES);
  const repeatBlocks = blocks.filter((b) => repeatNames.has(b.name));
  const flowBlocks = blocks.filter((b) => !repeatNames.has(b.name));

  // Le logo est un overlay haut-droite (`assemble.ts` le dessine à x droite,
  // y haut) : il ne consomme PAS la hauteur de flux — le 1er bloc (vendeur) est
  // à gauche. On ne réserve donc rien en haut. L'ancienne réserve `logoHeight`
  // amputait le budget vertical alors que l'assemblage ne décalait pas le
  // contenu → saut de page prématuré (page 1 à moitié vide). Cf. recette
  // fx-380-adv-riche T-CL-PDF-MOTEUR-V2.
  const budget = LAYOUT.contentTop - LAYOUT.contentBottom;
  const repeatHeight = repeatBlocks.reduce((acc, b) => acc + blockHeight(b), 0);

  const pages: PdfBlock[][] = [];
  let current: PdfBlock[] = [...repeatBlocks];
  let used = repeatHeight;
  let hasFlow = false;

  const pushPage = (): void => {
    pages.push(current);
  };
  const newPage = (): void => {
    pushPage();
    current = [...repeatBlocks];
    used = repeatHeight;
    hasFlow = false;
  };

  for (const block of flowBlocks) {
    if (block.kind === "text") {
      const h = textBlockHeight(block);
      if (hasFlow && used + h > budget) newPage();
      current.push(block);
      used += h;
      hasFlow = true;
      continue;
    }

    // Table : scinde les lignes par page.
    const remaining = [...block.rows];
    const headerH = tableHeaderHeight();
    while (remaining.length > 0) {
      let available = budget - used - headerH;
      const chunk: PdfTableBlock["rows"] = [];
      while (remaining.length > 0) {
        const nextRow = remaining[0];
        if (nextRow === undefined) break;
        const rh = tableRowHeight(nextRow);
        if (rh > available && chunk.length > 0) break;
        if (rh > available && chunk.length === 0 && hasFlow) break; // déborde → nouvelle page
        chunk.push(nextRow);
        remaining.shift();
        available -= rh;
      }
      if (chunk.length === 0) {
        // Rien ne tient sur cette page → page neuve (garde-fou anti-boucle :
        // sur page vierge on force au moins une ligne au tour suivant).
        newPage();
        continue;
      }
      current.push(tableChunk(block, chunk));
      used += headerH + chunk.reduce((acc, r) => acc + tableRowHeight(r), 0) + LAYOUT.blockGap;
      hasFlow = true;
      if (remaining.length > 0) newPage();
    }
  }

  pushPage();
  return pages;
}
