// Orchestrateur public du rendu PDF par moteur de template (Axe B sprint-07 V2).
//
//   CrossIndustryInvoice (+ enrichissement BDD)
//     → buildTemplateContext         (template-context.ts)
//     → renderInvoiceTemplate        (Nunjucks → HTML intermédiaire)
//     → parseHtmlToBlocks            (HTML → blocs typés)
//     → paginateBlocks               (pages A4, en-tête répété, table scindée)
//     → assembleFacturXPdfA3({content}) (pdf-lib PDF/A-3b — ADR-004 préservé)
//
// `xmlBytes` est fourni par l'appelant (déjà généré + validé XSD côté `apps/api`)
// pour éviter une re-sérialisation CII. Le builder n'accède pas à la BDD :
// Capital social / RCS / forme juridique / logo / INCOTERM transitent par
// `enrichment` (cf. template-context.ts).

import type { CrossIndustryInvoice, FxConformanceLevel } from "@factur-e/factur-x-model";

import { assembleFacturXPdfA3 } from "./assemble.js";
import { createMeasureFont } from "./font.js";
import { parseHtmlToBlocks, type PdfBlock } from "./html-to-pdf-blocks.js";
import { paginateBlocks } from "./pagination.js";
import { renderInvoiceTemplate } from "./render-template.js";
import { buildTemplateContext, templateNameFor, type PdfEnrichment } from "./template-context.js";
import { wrapTextBlocks } from "./text-wrap.js";

/**
 * Pipeline partagé context → HTML → blocs → wrap (F2) → pages A4. Source unique
 * du contenu paginé, consommée par `renderInvoicePdfFromModel` (dessin) et
 * `renderInvoiceTextLines` (oracle texte des tests corpus §3.4).
 */
async function buildPaginatedPages(
  invoice: CrossIndustryInvoice,
  enrichment: PdfEnrichment | undefined,
): Promise<PdfBlock[][]> {
  const context = buildTemplateContext(invoice, enrichment);
  const templateName = templateNameFor(context.documentTypeCode);
  const html = renderInvoiceTemplate(context as unknown as Record<string, unknown>, templateName);
  const blocks = parseHtmlToBlocks(html);
  // F2 — wrap font-aware AVANT pagination (hauteurs paginées = dessin).
  const wrapped = wrapTextBlocks(blocks, await createMeasureFont());
  return paginateBlocks(wrapped);
}

export interface RenderInvoicePdfInput {
  /** Modèle EN 16931 (déjà mappé depuis le formulaire / la BDD). */
  invoice: CrossIndustryInvoice;
  /** XML CII `factur-x.xml` (UTF-8) déjà sérialisé + validé XSD par l'appelant. */
  xmlBytes: Uint8Array;
  /** Profil de conformance déclaré au XMP (doit refléter le XML embarqué). */
  conformanceLevel: FxConformanceLevel;
  /** Champs hors CII (customers + logo + INCOTERM). Tout optionnel. */
  enrichment?: PdfEnrichment;
  /** Date de génération — déterminisme test. */
  generationDate?: Date;
  /** Ligne de pied de page répétée (ex Capital social) — optionnelle. */
  footerLine?: string;
}

/**
 * Génère le PDF/A-3b Factur-X complet via le moteur de template. Le choix du
 * template `.njk` est piloté par BT-3 (380 facture / 381 avoir / 384
 * rectificative).
 */
export async function renderInvoicePdfFromModel(input: RenderInvoicePdfInput): Promise<Uint8Array> {
  const context = buildTemplateContext(input.invoice, input.enrichment);
  const pages = await buildPaginatedPages(input.invoice, input.enrichment);

  return assembleFacturXPdfA3({
    xmlBytes: input.xmlBytes,
    metadata: { invoiceNumber: context.invoiceNumber, sellerName: context.seller.name },
    conformanceLevel: input.conformanceLevel,
    generationDate: input.generationDate,
    content: { pages, logo: input.enrichment?.logo, footerLine: input.footerLine },
  });
}

/**
 * Texte rendu dans l'ordre de lecture (lignes des blocs paginés réellement
 * dessinés : en-tête répété, table scindée, wrap F2 appliqué). Oracle
 * DÉTERMINISTE des assertions de contenu PDF (corpus §3.4 : `mustContain` /
 * `mustNotContain` / `mustContainInOrder`), indépendant de la rasterisation et
 * de l'extraction de police. Le résidu visuel (position exacte, lisibilité)
 * reste une vérif humaine (cf. `humanCheck`).
 */
export async function renderInvoiceTextLines(input: {
  invoice: CrossIndustryInvoice;
  enrichment?: PdfEnrichment;
}): Promise<string[]> {
  const pages = await buildPaginatedPages(input.invoice, input.enrichment);
  const lines: string[] = [];
  for (const page of pages) {
    for (const block of page) {
      if (block.kind === "text") {
        for (const line of block.lines) lines.push(line.text);
      } else {
        for (const column of block.columns) lines.push(column.header);
        for (const row of block.rows) for (const cell of row) lines.push(...cell.segments);
      }
    }
  }
  return lines;
}
