// Orchestrateur public du rendu PDF par moteur de template (Axe B sprint-07 V2).
//
//   CrossIndustryInvoice (+ enrichissement BDD)
//     → buildTemplateContext         (template-context.ts)
//     → renderInvoiceTemplate        (Nunjucks → HTML intermédiaire)
//     → parseHtmlToBlocks            (HTML → blocs typés)
//     → paginateBlocks               (pages A4, en-tête répété, table scindée)
//     → assembleFacturXPdfA3({content}) (pdf-lib PDF/A-3b — ADR-004 préservé)
//
// `xmlBytes` est fourni par l'appelant (déjà généré + validé XSD côté `apps/api`)
// pour éviter une re-sérialisation CII. Le builder n'accède pas à la BDD :
// Capital social / RCS / forme juridique / logo / INCOTERM transitent par
// `enrichment` (cf. template-context.ts).

import type { CrossIndustryInvoice, FxConformanceLevel } from "@factur-e/factur-x-model";

import { assembleFacturXPdfA3 } from "./assemble.js";
import { parseHtmlToBlocks } from "./html-to-pdf-blocks.js";
import { paginateBlocks } from "./pagination.js";
import { renderInvoiceTemplate } from "./render-template.js";
import { buildTemplateContext, templateNameFor, type PdfEnrichment } from "./template-context.js";

export interface RenderInvoicePdfInput {
  /** Modèle EN 16931 (déjà mappé depuis le formulaire / la BDD). */
  invoice: CrossIndustryInvoice;
  /** XML CII `factur-x.xml` (UTF-8) déjà sérialisé + validé XSD par l'appelant. */
  xmlBytes: Uint8Array;
  /** Profil de conformance déclaré au XMP (doit refléter le XML embarqué). */
  conformanceLevel: FxConformanceLevel;
  /** Champs hors CII (customers + logo + INCOTERM). Tout optionnel. */
  enrichment?: PdfEnrichment;
  /** Date de génération — déterminisme test. */
  generationDate?: Date;
  /** Ligne de pied de page répétée (ex Capital social) — optionnelle. */
  footerLine?: string;
}

/**
 * Génère le PDF/A-3b Factur-X complet via le moteur de template. Le choix du
 * template `.njk` est piloté par BT-3 (380 facture / 381 avoir / 384
 * rectificative).
 */
export async function renderInvoicePdfFromModel(input: RenderInvoicePdfInput): Promise<Uint8Array> {
  const context = buildTemplateContext(input.invoice, input.enrichment);
  const templateName = templateNameFor(context.documentTypeCode);
  const html = renderInvoiceTemplate(context as unknown as Record<string, unknown>, templateName);
  const blocks = parseHtmlToBlocks(html);
  const pages = paginateBlocks(blocks, { hasLogo: context.hasLogo });

  return assembleFacturXPdfA3({
    xmlBytes: input.xmlBytes,
    metadata: { invoiceNumber: context.invoiceNumber, sellerName: context.seller.name },
    conformanceLevel: input.conformanceLevel,
    generationDate: input.generationDate,
    content: { pages, logo: input.enrichment?.logo, footerLine: input.footerLine },
  });
}
