// Parser de métadonnées de factures REÇUES (T-CL-RECV-API sprint-05 W2).
// Lecture seule, tolérante (pas de Schematron — PA trustée). Supporte
// Factur-X / CII pur (CrossIndustryInvoice) + UBL 2.1 (Invoice).
//
// Réutilise `libxmljs2` (déjà dep sprint-01) pour un XPath namespace-aware
// précis sur les 113 entrées BT/BG (`docs/product/mapping-bt-bg.md`).

import libxmljs from "libxmljs2";

import { QDT_NS, RAM_NS, RSM_NS, UDT_NS } from "../xml/namespaces.js";

import {
  InvoiceParsingError,
  type InvoiceFormat,
  type InvoiceMetadata,
  type ParsedLine,
} from "./types.js";

const UBL_INVOICE_NS = "urn:oasis:names:specification:ubl:schema:xsd:Invoice-2";
const CAC_NS = "urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2";
const CBC_NS = "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2";

const CII_NS = { rsm: RSM_NS, ram: RAM_NS, udt: UDT_NS, qdt: QDT_NS } as const;
const UBL_NS = { ubl: UBL_INVOICE_NS, cac: CAC_NS, cbc: CBC_NS } as const;

/** Abstraction minimale d'un nœud libxmljs2 (évite la dépendance aux types
 *  exacts exportés, qui varient selon la version). NB : `.get` peut
 *  retourner `undefined` (pas `null`) en cas d'absence → normalisé par `q`. */
interface XNode {
  get(xpath: string, ns?: Record<string, string>): XNode | null | undefined;
  find(xpath: string, ns?: Record<string, string>): XNode[] | null | undefined;
  text(): string;
  attr(name: string): { value(): string } | null | undefined;
  name(): string;
  namespace(): { href(): string } | null | undefined;
}

type Ns = Record<string, string>;

/** `node.get` normalisé : `null` si absent (libxmljs2 renvoie `undefined`). */
function q(node: XNode, xpath: string, ns: Ns): XNode | null {
  return node.get(xpath, ns) ?? null;
}

/** `node.find` normalisé : tableau (jamais `undefined`). */
function qall(node: XNode, xpath: string, ns: Ns): XNode[] {
  return node.find(xpath, ns) ?? [];
}

/**
 * Parse un XML de facture EN 16931 (CII/Factur-X ou UBL) vers
 * `InvoiceMetadata`. Tolérant : champs optionnels absents → `undefined`.
 *
 * @throws {InvoiceParsingError} XML vide, malformé, ou racine non reconnue.
 */
export function parseInvoiceMetadata(xml: string): InvoiceMetadata {
  if (typeof xml !== "string" || xml.trim() === "") {
    throw new InvoiceParsingError("XML vide.");
  }

  let root: XNode | null;
  try {
    const doc = libxmljs.parseXml(xml);
    const parsedRoot: unknown = doc.root();
    root = (parsedRoot as XNode | null) ?? null;
  } catch (err) {
    throw new InvoiceParsingError(
      `XML malformé : ${err instanceof Error ? err.message : String(err)}`,
    );
  }
  if (root === null) {
    throw new InvoiceParsingError("XML sans élément racine.");
  }

  const rootName = root.name();
  const rootNs = root.namespace()?.href() ?? "";

  if (rootName === "CrossIndustryInvoice" && rootNs === RSM_NS) {
    return parseCII(root);
  }
  if (rootName === "Invoice" && rootNs === UBL_INVOICE_NS) {
    return parseUBL(root);
  }
  throw new InvoiceParsingError(
    `Format racine non reconnu : <${rootName}> (ns="${rootNs}"). Attendu CrossIndustryInvoice (CII) ou Invoice (UBL).`,
  );
}

// ─────────────────────────────────────────────────────────────────────
// CII / Factur-X
// ─────────────────────────────────────────────────────────────────────

function parseCII(root: XNode): InvoiceMetadata {
  // Différenciation facturx vs cii pur via le profil (GuidelineSpecified
  // DocumentContextParameter/ID — URN contient "factur-x" / "zugferd").
  const profile = textOf(
    root,
    "rsm:ExchangedDocumentContext/ram:GuidelineSpecifiedDocumentContextParameter/ram:ID",
    CII_NS,
  );
  const format: InvoiceFormat =
    profile !== undefined && /factur-x|zugferd/i.test(profile) ? "facturx" : "cii";

  const doc = q(root, "rsm:ExchangedDocument", CII_NS);
  const settlement = q(root, ".//ram:ApplicableHeaderTradeSettlement", CII_NS);
  const sellerNode = q(root, ".//ram:SellerTradeParty", CII_NS);
  const buyerNode = q(root, ".//ram:BuyerTradeParty", CII_NS);
  const summation =
    settlement !== null
      ? q(settlement, "ram:SpecifiedTradeSettlementHeaderMonetarySummation", CII_NS)
      : null;
  const meansNode =
    settlement !== null ? q(settlement, "ram:SpecifiedTradeSettlementPaymentMeans", CII_NS) : null;

  const lines: ParsedLine[] = qall(root, ".//ram:IncludedSupplyChainTradeLineItem", CII_NS).map(
    (li) => ({
      id: textOf(li, "ram:AssociatedDocumentLineDocument/ram:LineID", CII_NS) ?? "",
      description: textOf(li, "ram:SpecifiedTradeProduct/ram:Name", CII_NS) ?? "",
      quantity: numOf(li, "ram:SpecifiedLineTradeDelivery/ram:BilledQuantity", CII_NS) ?? 0,
      unitCode:
        attrOf(li, "ram:SpecifiedLineTradeDelivery/ram:BilledQuantity", "unitCode", CII_NS) ?? "",
      priceHt:
        centsOf(
          li,
          "ram:SpecifiedLineTradeAgreement/ram:NetPriceProductTradePrice/ram:ChargeAmount",
          CII_NS,
        ) ?? 0,
      vatRate:
        numOf(
          li,
          "ram:SpecifiedLineTradeSettlement/ram:ApplicableTradeTax/ram:RateApplicablePercent",
          CII_NS,
        ) ?? 0,
    }),
  );

  const notes =
    doc !== null
      ? qall(doc, "ram:IncludedNote", CII_NS).map((n) => ({
          subjectCode: textOf(n, "ram:SubjectCode", CII_NS) ?? "",
          content: textOf(n, "ram:Content", CII_NS) ?? "",
        }))
      : [];

  return assemble({
    format,
    invoiceNumber: doc !== null ? textOf(doc, "ram:ID", CII_NS) : undefined,
    issueDate: ciiDateToIso(
      doc !== null ? textOf(doc, "ram:IssueDateTime/udt:DateTimeString", CII_NS) : undefined,
    ),
    dueDate: ciiDateToIso(
      settlement !== null
        ? textOf(
            settlement,
            "ram:SpecifiedTradePaymentTerms/ram:DueDateDateTime/udt:DateTimeString",
            CII_NS,
          )
        : undefined,
    ),
    currency:
      settlement !== null ? textOf(settlement, "ram:InvoiceCurrencyCode", CII_NS) : undefined,
    documentType: doc !== null ? textOf(doc, "ram:TypeCode", CII_NS) : undefined,
    // BG-3 — InvoiceReferencedDocument (sous HeaderTradeSettlement, après la
    // MonetarySummation). `.//` tolérant : on cherche depuis la racine.
    precedingInvoiceReference: ciiPrecedingRef(q(root, ".//ram:InvoiceReferencedDocument", CII_NS)),
    seller: {
      siren:
        sellerNode !== null
          ? textOf(sellerNode, "ram:SpecifiedLegalOrganization/ram:ID", CII_NS)
          : undefined,
      name: sellerNode !== null ? textOf(sellerNode, "ram:Name", CII_NS) : undefined,
      vatNumber:
        sellerNode !== null
          ? textOf(sellerNode, "ram:SpecifiedTaxRegistration/ram:ID", CII_NS)
          : undefined,
      electronicAddress:
        sellerNode !== null
          ? textOf(sellerNode, "ram:URIUniversalCommunication/ram:URIID", CII_NS)
          : undefined,
      address: sellerNode !== null ? ciiAddress(sellerNode) : undefined,
    },
    buyer: {
      siren:
        buyerNode !== null
          ? textOf(buyerNode, "ram:SpecifiedLegalOrganization/ram:ID", CII_NS)
          : undefined,
      name: buyerNode !== null ? textOf(buyerNode, "ram:Name", CII_NS) : undefined,
    },
    lines,
    totals: {
      subtotalHt:
        summation !== null ? centsOf(summation, "ram:LineTotalAmount", CII_NS) : undefined,
      vatAmount: summation !== null ? centsOf(summation, "ram:TaxTotalAmount", CII_NS) : undefined,
      totalTtc: summation !== null ? centsOf(summation, "ram:GrandTotalAmount", CII_NS) : undefined,
      balanceDue:
        summation !== null ? centsOf(summation, "ram:DuePayableAmount", CII_NS) : undefined,
    },
    iban:
      meansNode !== null
        ? textOf(meansNode, "ram:PayeePartyCreditorFinancialAccount/ram:IBANID", CII_NS)
        : undefined,
    paymentMeans: meansNode !== null ? textOf(meansNode, "ram:TypeCode", CII_NS) : undefined,
    notes,
  });
}

/** BG-3 CII — `ram:InvoiceReferencedDocument` : BT-25 `IssuerAssignedID` +
 *  BT-26 `FormattedIssueDateTime/qdt:DateTimeString` (format 102). */
function ciiPrecedingRef(
  node: XNode | null,
): { invoiceNumber: string; issueDate?: string } | undefined {
  if (node === null) return undefined;
  const invoiceNumber = textOf(node, "ram:IssuerAssignedID", CII_NS);
  if (invoiceNumber === undefined) return undefined;
  const issueDate = ciiDateToIso(
    textOf(node, "ram:FormattedIssueDateTime/qdt:DateTimeString", CII_NS),
  );
  return { invoiceNumber, ...(issueDate !== undefined ? { issueDate } : {}) };
}

function ciiAddress(party: XNode): string | undefined {
  const addr = q(party, "ram:PostalTradeAddress", CII_NS);
  if (addr === null) return undefined;
  const parts = [
    textOf(addr, "ram:LineOne", CII_NS),
    textOf(addr, "ram:PostcodeCode", CII_NS),
    textOf(addr, "ram:CityName", CII_NS),
    textOf(addr, "ram:CountryID", CII_NS),
  ].filter((p): p is string => p !== undefined && p !== "");
  return parts.length > 0 ? parts.join(" ") : undefined;
}

// ─────────────────────────────────────────────────────────────────────
// UBL 2.1
// ─────────────────────────────────────────────────────────────────────

function parseUBL(root: XNode): InvoiceMetadata {
  const sellerNode = q(root, "cac:AccountingSupplierParty/cac:Party", UBL_NS);
  const buyerNode = q(root, "cac:AccountingCustomerParty/cac:Party", UBL_NS);
  const monetary = q(root, "cac:LegalMonetaryTotal", UBL_NS);
  const meansNode = q(root, "cac:PaymentMeans", UBL_NS);

  const lines: ParsedLine[] = qall(root, "cac:InvoiceLine", UBL_NS).map((li) => ({
    id: textOf(li, "cbc:ID", UBL_NS) ?? "",
    description: textOf(li, "cac:Item/cbc:Name", UBL_NS) ?? "",
    quantity: numOf(li, "cbc:InvoicedQuantity", UBL_NS) ?? 0,
    unitCode: attrOf(li, "cbc:InvoicedQuantity", "unitCode", UBL_NS) ?? "",
    priceHt: centsOf(li, "cac:Price/cbc:PriceAmount", UBL_NS) ?? 0,
    vatRate: numOf(li, "cac:Item/cac:ClassifiedTaxCategory/cbc:Percent", UBL_NS) ?? 0,
  }));

  const notes = qall(root, "cbc:Note", UBL_NS).map((n) => ({ subjectCode: "", content: n.text() }));

  return assemble({
    format: "ubl",
    invoiceNumber: textOf(root, "cbc:ID", UBL_NS),
    issueDate: textOf(root, "cbc:IssueDate", UBL_NS),
    dueDate: textOf(root, "cbc:DueDate", UBL_NS),
    currency: textOf(root, "cbc:DocumentCurrencyCode", UBL_NS),
    documentType: textOf(root, "cbc:InvoiceTypeCode", UBL_NS),
    // BG-3 — cac:BillingReference/cac:InvoiceDocumentReference (BT-25 cbc:ID
    // + BT-26 cbc:IssueDate déjà ISO).
    precedingInvoiceReference: ublPrecedingRef(
      q(root, "cac:BillingReference/cac:InvoiceDocumentReference", UBL_NS),
    ),
    seller: {
      siren:
        sellerNode !== null
          ? textOf(sellerNode, "cac:PartyLegalEntity/cbc:CompanyID", UBL_NS)
          : undefined,
      name: sellerNode !== null ? ublPartyName(sellerNode) : undefined,
      vatNumber:
        sellerNode !== null
          ? textOf(sellerNode, "cac:PartyTaxScheme/cbc:CompanyID", UBL_NS)
          : undefined,
      electronicAddress:
        sellerNode !== null ? textOf(sellerNode, "cbc:EndpointID", UBL_NS) : undefined,
      address: sellerNode !== null ? ublAddress(sellerNode) : undefined,
    },
    buyer: {
      siren:
        buyerNode !== null
          ? textOf(buyerNode, "cac:PartyLegalEntity/cbc:CompanyID", UBL_NS)
          : undefined,
      name: buyerNode !== null ? ublPartyName(buyerNode) : undefined,
    },
    lines,
    totals: {
      subtotalHt:
        monetary !== null ? centsOf(monetary, "cbc:LineExtensionAmount", UBL_NS) : undefined,
      vatAmount: centsOf(root, "cac:TaxTotal/cbc:TaxAmount", UBL_NS),
      totalTtc: monetary !== null ? centsOf(monetary, "cbc:TaxInclusiveAmount", UBL_NS) : undefined,
      balanceDue: monetary !== null ? centsOf(monetary, "cbc:PayableAmount", UBL_NS) : undefined,
    },
    iban:
      meansNode !== null
        ? textOf(meansNode, "cac:PayeeFinancialAccount/cbc:ID", UBL_NS)
        : undefined,
    paymentMeans:
      meansNode !== null ? textOf(meansNode, "cbc:PaymentMeansCode", UBL_NS) : undefined,
    notes,
  });
}

/** BG-3 UBL — `cac:InvoiceDocumentReference` : BT-25 `cbc:ID` + BT-26
 *  `cbc:IssueDate` (déjà ISO `YYYY-MM-DD`). */
function ublPrecedingRef(
  node: XNode | null,
): { invoiceNumber: string; issueDate?: string } | undefined {
  if (node === null) return undefined;
  const invoiceNumber = textOf(node, "cbc:ID", UBL_NS);
  if (invoiceNumber === undefined) return undefined;
  const issueDate = textOf(node, "cbc:IssueDate", UBL_NS);
  return { invoiceNumber, ...(issueDate !== undefined ? { issueDate } : {}) };
}

function ublPartyName(party: XNode): string | undefined {
  return (
    textOf(party, "cac:PartyLegalEntity/cbc:RegistrationName", UBL_NS) ??
    textOf(party, "cac:PartyName/cbc:Name", UBL_NS)
  );
}

function ublAddress(party: XNode): string | undefined {
  const addr = q(party, "cac:PostalAddress", UBL_NS);
  if (addr === null) return undefined;
  const parts = [
    textOf(addr, "cbc:StreetName", UBL_NS),
    textOf(addr, "cbc:PostalZone", UBL_NS),
    textOf(addr, "cbc:CityName", UBL_NS),
    textOf(addr, "cac:Country/cbc:IdentificationCode", UBL_NS),
  ].filter((p): p is string => p !== undefined && p !== "");
  return parts.length > 0 ? parts.join(" ") : undefined;
}

// ─────────────────────────────────────────────────────────────────────
// Assemblage + helpers
// ─────────────────────────────────────────────────────────────────────

interface RawFields {
  format: InvoiceFormat;
  invoiceNumber: string | undefined;
  issueDate: string | undefined;
  dueDate: string | undefined;
  currency: string | undefined;
  documentType: string | undefined;
  precedingInvoiceReference: { invoiceNumber: string; issueDate?: string } | undefined;
  seller: {
    siren: string | undefined;
    name: string | undefined;
    vatNumber: string | undefined;
    electronicAddress: string | undefined;
    address: string | undefined;
  };
  buyer: { siren: string | undefined; name: string | undefined };
  lines: ParsedLine[];
  totals: {
    subtotalHt: number | undefined;
    vatAmount: number | undefined;
    totalTtc: number | undefined;
    balanceDue: number | undefined;
  };
  iban: string | undefined;
  paymentMeans: string | undefined;
  notes: { subjectCode: string; content: string }[];
}

function assemble(r: RawFields): InvoiceMetadata {
  const paymentTerms: NonNullable<InvoiceMetadata["paymentTerms"]> = {};
  if (r.iban !== undefined) paymentTerms.iban = r.iban;
  if (r.paymentMeans !== undefined) paymentTerms.paymentMeans = r.paymentMeans;
  if (r.notes.length > 0) paymentTerms.notes = r.notes;

  const meta: InvoiceMetadata = {
    format: r.format,
    document: {
      invoiceNumber: r.invoiceNumber ?? "",
      issueDate: r.issueDate ?? "",
      currency: r.currency ?? "EUR",
      documentType: r.documentType ?? "380",
    },
    parties: {
      seller: { siren: r.seller.siren ?? "", name: r.seller.name ?? "" },
      buyer: { siren: r.buyer.siren ?? "", name: r.buyer.name ?? "" },
    },
    lines: r.lines,
    totals: {
      subtotalHt: r.totals.subtotalHt ?? 0,
      vatAmount: r.totals.vatAmount ?? 0,
      totalTtc: r.totals.totalTtc ?? 0,
      balanceDue: r.totals.balanceDue ?? 0,
    },
  };
  if (r.dueDate !== undefined) meta.document.dueDate = r.dueDate;
  if (r.precedingInvoiceReference !== undefined) {
    meta.document.precedingInvoiceReference = r.precedingInvoiceReference;
  }
  if (r.seller.address !== undefined) meta.parties.seller.address = r.seller.address;
  if (r.seller.vatNumber !== undefined) meta.parties.seller.vatNumber = r.seller.vatNumber;
  if (r.seller.electronicAddress !== undefined) {
    meta.parties.seller.electronicAddress = r.seller.electronicAddress;
  }
  if (Object.keys(paymentTerms).length > 0) meta.paymentTerms = paymentTerms;
  return meta;
}

/** Texte d'un nœud trouvé par xpath relatif, ou `undefined` si absent/vide. */
function textOf(node: XNode, xpath: string, ns: Ns): string | undefined {
  const found = q(node, xpath, ns);
  if (found === null) return undefined;
  const text = found.text().trim();
  return text === "" ? undefined : text;
}

/** Valeur d'attribut d'un nœud trouvé par xpath, ou `undefined`. */
function attrOf(node: XNode, xpath: string, attrName: string, ns: Ns): string | undefined {
  const found = q(node, xpath, ns);
  if (found === null) return undefined;
  const a = found.attr(attrName);
  return a !== null && a !== undefined ? a.value() : undefined;
}

/** Nombre décimal d'un nœud, ou `undefined`. */
function numOf(node: XNode, xpath: string, ns: Ns): number | undefined {
  const raw = textOf(node, xpath, ns);
  if (raw === undefined) return undefined;
  const n = Number.parseFloat(raw);
  return Number.isFinite(n) ? n : undefined;
}

/** Montant décimal d'un nœud → centimes (entier), ou `undefined`. */
function centsOf(node: XNode, xpath: string, ns: Ns): number | undefined {
  const n = numOf(node, xpath, ns);
  return n === undefined ? undefined : Math.round(n * 100);
}

/** Date CII `udt:DateTimeString` format 102 (`YYYYMMDD`) → ISO
 *  `YYYY-MM-DD`. Passe-plat si déjà ISO ou non reconnu. */
function ciiDateToIso(raw: string | undefined): string | undefined {
  if (raw === undefined) return undefined;
  if (/^\d{8}$/.test(raw)) return `${raw.slice(0, 4)}-${raw.slice(4, 6)}-${raw.slice(6, 8)}`;
  return raw;
}
