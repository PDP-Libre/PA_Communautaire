/**
 * Types du parser de métadonnées de factures REÇUES (T-CL-RECV-API
 * sprint-05 W2). Lecture seule — extrait les BT/BG EN 16931 essentiels +
 * exposés (mode UI avancé, anticipation sprint-06+) depuis un XML
 * Factur-X (CII), CII pur ou UBL 2.1.
 *
 * Distinct de `InvoiceModel` (`factur-x-model`, émission) : le parser ne
 * (re)valide pas (pas de Schematron — PA SuperPDP trustée pour
 * `docType=Original`), il lit de manière tolérante (champs optionnels OK).
 *
 * Montants en **centimes** (number entier) pour éviter les flottants —
 * cohérent `received_invoices.total_ttc_cents`. Taux TVA en pourcent.
 */

export type InvoiceFormat = "facturx" | "ubl" | "cii";

export interface ParsedSeller {
  /** BT-30 SIREN (SpecifiedLegalOrganization / PartyLegalEntity CompanyID). */
  siren: string;
  /** BT-27/44 raison sociale. */
  name: string;
  /** BG-5 adresse postale concaténée (best-effort), si présente. */
  address?: string;
  /** BT-31 numéro de TVA, si présent. */
  vatNumber?: string;
  /** BT-34/49 adresse électronique Peppol (EndpointID / URIID), si présente. */
  electronicAddress?: string;
}

export interface ParsedBuyer {
  /** BT-47 SIREN acheteur (moi). */
  siren: string;
  /** BT-44 raison sociale acheteur. */
  name: string;
}

export interface ParsedLine {
  /** BT-126 identifiant de ligne. */
  id: string;
  /** BT-153 désignation. */
  description: string;
  /** BT-129 quantité facturée. */
  quantity: number;
  /** BT-130 code unité (UN/ECE Rec 20). */
  unitCode: string;
  /** BT-146 prix unitaire HT en centimes. */
  priceHt: number;
  /** BT-152 taux de TVA en pourcent. */
  vatRate: number;
}

export interface InvoiceMetadata {
  format: InvoiceFormat;
  document: {
    /** BT-1 numéro de facture. */
    invoiceNumber: string;
    /** BT-2 date d'émission (ISO `YYYY-MM-DD`). */
    issueDate: string;
    /** BT-9 échéance (ISO `YYYY-MM-DD`), si présente. */
    dueDate?: string;
    /** BT-5 devise. */
    currency: string;
    /** BT-3 type de document (380 facture, 381 avoir, 384 rectificative...). */
    documentType: string;
    /** BG-3 (BR-55) — référence à la facture d'origine (BT-25 numéro + BT-26
     *  date) pour un avoir (381) / rectificative (384). Absent sinon. */
    precedingInvoiceReference?: { invoiceNumber: string; issueDate?: string };
  };
  parties: {
    seller: ParsedSeller;
    buyer: ParsedBuyer;
  };
  lines: ParsedLine[];
  totals: {
    /** BT-106 somme des nets de lignes (cents). */
    subtotalHt: number;
    /** BT-117/110 montant total TVA (cents). */
    vatAmount: number;
    /** BT-112 total TTC (cents). */
    totalTtc: number;
    /** BT-115 net à payer (cents). */
    balanceDue: number;
  };
  paymentTerms?: {
    /** BT-58/84 IBAN bénéficiaire, si présent. */
    iban?: string;
    /** BT-81 code moyen de paiement (UNTDID 4461), si présent. */
    paymentMeans?: string;
    /** BG-1 notes document (BT-21 sujet + BT-22 contenu), si présentes. */
    notes?: { subjectCode: string; content: string }[];
  };
}

/** Erreur de parsing — XML vide, malformé, ou format racine non reconnu.
 *  Le caller (route fiche) doit dégrader sans bloquer (brief §6 :
 *  "Données techniques illisibles" + lien XML brut). */
export class InvoiceParsingError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "InvoiceParsingError";
  }
}
