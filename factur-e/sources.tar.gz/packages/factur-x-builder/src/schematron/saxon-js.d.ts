// Déclaration de types minimale pour `saxon-js` (2.7.x, CommonJS, sans types).
// On ne déclare que la surface consommée par l'engine Schematron embarqué :
// `SaxonJS.transform(options, "async") → Promise<{ principalResult }>`.

declare module "saxon-js" {
  /** SEF (Stylesheet Export File) chargé en mémoire — objet JSON opaque. */
  export type CompiledStylesheet = Record<string, unknown>;

  export interface TransformOptions {
    /** SEF déjà parsé (JSON.parse) — réutilisable, cache module-scope. */
    stylesheetInternal?: CompiledStylesheet;
    /** Chemin fichier du SEF (alternative à `stylesheetInternal`). */
    stylesheetFileName?: string;
    /** Contenu texte du SEF. */
    stylesheetText?: string;
    /** XML source en chaîne (alternative à `sourceFileName`). */
    sourceText?: string;
    /** Mode de sortie — `"serialized"` retourne `principalResult: string`. */
    destination?: "serialized" | "document" | "application" | "file";
  }

  export interface TransformResult {
    /** Résultat sérialisé (SVRL XML) quand `destination: "serialized"`. */
    principalResult?: string;
  }

  export function transform(options: TransformOptions, execMode: "async"): Promise<TransformResult>;
  export function transform(options: TransformOptions, execMode?: "sync"): TransformResult;

  const SaxonJS: {
    transform: typeof transform;
  };
  export default SaxonJS;
}
