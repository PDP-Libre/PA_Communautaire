// Engine Schematron embarqué — saxon-js (Option B, ADR-016 candidat D4).
//
// Source : docs/standards/fnfe-ctc-v1.3.1-en16931-schematron.md §8.4
// (XSLT 2.0 saxon-js, ~50-100 ms/sample). Les Schematrons FNFE-MPE V1.3.1 sont
// fournis sous forme de XSLT 2.0 (queryBinding="xslt2") qui émettent du SVRL.
// On les pré-compile en SEF (`.sef.json`, via `xslt3`) et on les exécute via
// `SaxonJS.transform`. Cache module-scope du SEF parsé → cold start payé une
// seule fois par stylesheet.
//
// Le SEF est chargé une fois (readFile + JSON.parse) puis réutilisé via
// `stylesheetInternal` — pas de relecture du fichier (~2-6 MB) à chaque appel.

import { readFile } from "node:fs/promises";

import { SaxonJS, type CompiledStylesheet } from "./saxon-js-shim.js";

export type { CompiledStylesheet };

/** Cache module-scope : chemin SEF → stylesheet compilé (parsé). */
const sefCache = new Map<string, CompiledStylesheet>();

/**
 * Charge (et met en cache) un SEF Schematron pré-compilé. Coûteux la première
 * fois (lecture + parse JSON), gratuit ensuite.
 */
export async function loadXslt(sefPath: string): Promise<CompiledStylesheet> {
  const cached = sefCache.get(sefPath);
  if (cached !== undefined) return cached;
  const raw = await readFile(sefPath, "utf-8");
  const sef = JSON.parse(raw) as CompiledStylesheet;
  sefCache.set(sefPath, sef);
  return sef;
}

/**
 * Exécute un Schematron compilé sur un XML CII et retourne le SVRL sérialisé.
 * @throws si le XML est malformé (erreur saxon-js propagée).
 */
export async function runValidation(xml: string, stylesheet: CompiledStylesheet): Promise<string> {
  const result = await SaxonJS.transform(
    {
      stylesheetInternal: stylesheet,
      sourceText: xml,
      destination: "serialized",
    },
    "async",
  );
  return result.principalResult ?? "";
}

/** Réinitialise le cache des SEF — utile en test (mesure cold start). */
export function resetXsltCache(): void {
  sefCache.clear();
}
