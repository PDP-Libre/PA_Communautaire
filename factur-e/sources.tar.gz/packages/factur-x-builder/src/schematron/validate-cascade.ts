// Pipeline de validation en cascade (ADR-016 candidat D4) — Z5 Option A :
// séquentielle stricte, reporting cumulé (Bruno doit voir tous les warnings).
//
// Ordre : XSD (libxmljs2) → Schematron EN16931 → Schematron EXTENDED-CTC-FR →
// Schematron BR-FR-Flux2. Skip des Schematrons hors-profil :
//   - profil `en16931`        : XSD EN16931 + Schematron EN16931 (canal PEPPOL
//     UE strict) ; EXTENDED-CTC-FR + BR-FR-Flux2 = SKIPPED (hors canal FR).
//   - profil `extended-ctc-fr`: XSD EXTENDED + Schematron EXTENDED-CTC-FR +
//     BR-FR-Flux2 (canal SuperPDP/PA FR) ; Schematron EN16931 strict = N/A
//     (l'EXTENDED-CTC-FR porte déjà les relaxations FR vs EN16931).
//
// Fail-fast uniquement sur échec XSD structurel (les Schematron nécessitent un
// XML structurellement valide). Les étapes Schematron applicables s'exécutent
// toutes et cumulent fatals + warnings.

import { fileURLToPath } from "node:url";
import path from "node:path";

import { type FacturXProfileKey, type ValidationError, validateXsd } from "../validate-xsd.js";
import { loadXslt, runValidation } from "./engine.js";
import {
  type SvrlAssertion,
  fatalAssertions,
  parseSvrl,
  warningAssertions,
} from "./svrl-parser.js";

const HERE = path.dirname(fileURLToPath(import.meta.url));
// HERE = .../src/schematron → 2× ".." pour atteindre la racine du package.
const SCHEMATRON_DIR = path.resolve(HERE, "..", "..", "schemas", "schematron");

/** Chemins des SEF Schematron pré-compilés (CII). */
export const SEF_PATHS = {
  en16931: path.join(SCHEMATRON_DIR, "en16931", "EN16931-CII-validation.sef.json"),
  "extended-ctc-fr": path.join(
    SCHEMATRON_DIR,
    "extended-ctc-fr",
    "EXTENDED-CTC-FR-CII-V1.3.1.sef.json",
  ),
  "br-fr-flux2": path.join(
    SCHEMATRON_DIR,
    "br-fr-flux2",
    "BR-FR-Flux2-Schematron-CII_V1.3.1.sef.json",
  ),
} as const;

export type SchematronKey = keyof typeof SEF_PATHS;

export type CascadeStepName =
  | "xsd"
  | "schematron-en16931"
  | "schematron-extended-ctc-fr"
  | "schematron-br-fr-flux2";

export type CascadeStepStatus = "ok" | "fatal" | "warning" | "skipped" | "na" | "error";

export interface CascadeStepResult {
  step: CascadeStepName;
  status: CascadeStepStatus;
  /** Assertions Schematron fatales (vide hors Schematron). */
  fatals: SvrlAssertion[];
  /** Assertions Schematron warning (vide hors Schematron). */
  warnings: SvrlAssertion[];
  /** Erreurs XSD (uniquement étape `xsd`). */
  xsdErrors?: ValidationError[];
  /** Détail libre (raison de skip/na). */
  detail?: string;
}

export interface CascadeResult {
  profile: FacturXProfileKey;
  steps: CascadeStepResult[];
  /** Aucune fatale (XSD err ou Schematron fatal) sur l'ensemble. */
  ok: boolean;
  /** Aucun warning Schematron sur l'ensemble (objectif sandbox SuperPDP). */
  zeroWarning: boolean;
  /** Au moins une étape Schematron en erreur engine (limitation saxon-js HE). */
  engineErrors: boolean;
}

/** Plan des Schematrons applicables par profil d'émission. */
const SCHEMATRON_PLAN: Record<
  FacturXProfileKey,
  { applies: readonly SchematronKey[]; naReason: Partial<Record<SchematronKey, string>> }
> = {
  en16931: {
    applies: ["en16931"],
    naReason: {
      "extended-ctc-fr": "profil EN16931 strict (hors canal FR)",
      "br-fr-flux2": "profil EN16931 strict (hors canal FR)",
    },
  },
  "extended-ctc-fr": {
    applies: ["extended-ctc-fr", "br-fr-flux2"],
    naReason: {
      en16931: "EXTENDED-CTC-FR porte déjà les relaxations FR vs EN16931 strict",
    },
  },
};

const SCHEMATRON_STEP_NAME: Record<SchematronKey, CascadeStepName> = {
  en16931: "schematron-en16931",
  "extended-ctc-fr": "schematron-extended-ctc-fr",
  "br-fr-flux2": "schematron-br-fr-flux2",
};

const ALL_SCHEMATRONS: readonly SchematronKey[] = ["en16931", "extended-ctc-fr", "br-fr-flux2"];

async function runSchematronStep(xml: string, key: SchematronKey): Promise<CascadeStepResult> {
  // Fail-safe (ADR-009 D1) : un échec engine saxon-js (ex. limitation type
  // xs:decimal/xs:double de l'EXTENDED-CTC-FR sur CII non typé — NOTE-COWORK)
  // est capturé en statut `error`, sans interrompre la cascade.
  try {
    const sef = await loadXslt(SEF_PATHS[key]);
    const svrl = await runValidation(xml, sef);
    const assertions = parseSvrl(svrl);
    const fatals = fatalAssertions(assertions);
    const warnings = warningAssertions(assertions);
    return {
      step: SCHEMATRON_STEP_NAME[key],
      status: fatals.length > 0 ? "fatal" : warnings.length > 0 ? "warning" : "ok",
      fatals,
      warnings,
    };
  } catch (e) {
    return {
      step: SCHEMATRON_STEP_NAME[key],
      status: "error",
      fatals: [],
      warnings: [],
      detail: `engine saxon-js : ${e instanceof Error ? e.message : String(e)}`,
    };
  }
}

/**
 * Valide un XML CII en cascade pour le profil d'émission donné.
 * Reporting cumulé (Z5-A) : exécute toutes les étapes applicables et agrège.
 */
export async function validateCascade(
  xml: string,
  profile: FacturXProfileKey,
): Promise<CascadeResult> {
  const steps: CascadeStepResult[] = [];
  const plan = SCHEMATRON_PLAN[profile];

  // 1. XSD (fail-fast si erreur structurelle — Schematron impossible ensuite).
  const xsd = await validateXsd(xml, profile);
  if (!xsd.ok) {
    steps.push({ step: "xsd", status: "fatal", fatals: [], warnings: [], xsdErrors: xsd.errors });
    // Étapes Schematron non exécutées (XML structurellement invalide).
    for (const key of ALL_SCHEMATRONS) {
      steps.push({
        step: SCHEMATRON_STEP_NAME[key],
        status: "skipped",
        fatals: [],
        warnings: [],
        detail: "non exécuté — XSD en échec (fail-fast structurel)",
      });
    }
    return { profile, steps, ok: false, zeroWarning: true, engineErrors: false };
  }
  steps.push({
    step: "xsd",
    status: xsd.value.skipped ? "skipped" : "ok",
    fatals: [],
    warnings: [],
    detail: xsd.value.skipped ? xsd.value.skipReason : undefined,
  });

  // 2. Schematrons — applicables exécutés, les autres marqués SKIPPED/N/A.
  for (const key of ALL_SCHEMATRONS) {
    if (plan.applies.includes(key)) {
      steps.push(await runSchematronStep(xml, key));
    } else {
      steps.push({
        step: SCHEMATRON_STEP_NAME[key],
        status: "na",
        fatals: [],
        warnings: [],
        detail: plan.naReason[key] ?? "hors profil",
      });
    }
  }

  const ok = !steps.some((s) => s.status === "fatal");
  const zeroWarning = !steps.some((s) => s.warnings.length > 0);
  const engineErrors = steps.some((s) => s.status === "error");
  return { profile, steps, ok, zeroWarning, engineErrors };
}
