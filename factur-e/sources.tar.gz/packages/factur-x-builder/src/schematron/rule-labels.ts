// Libellés FR des règles Schematron (S1 — T-CL-S1-RULE-LABELS).
//
// Stratégie V1 minimale (cf. docs/standards/s1-validation-emission-schematron.md §6
// + ADR-013 D3 verbatim) : le `svrl:text` parsé par `svrl-parser` est DÉJÀ une
// description humaine présente dans le SVRL — c'est le libellé par défaut affiché
// à l'UI. Cette table fournit un **override FR fin**, verbatim FNFE, uniquement
// pour les règles dont le `svrl:text` officiel est en anglais (EN16931 / EXTENDED)
// et qui sont les plus susceptibles de surface à l'émission.
//
// Volontairement NON exhaustive (354 règles) : on n'override que ce qui apporte une
// valeur claire, le reste retombe sur le `svrl:text`. Extensible au fil des retours
// recette sans changement de contrat.

/**
 * Override de libellé FR par identifiant de règle (verbatim FNFE / AFNOR).
 * Clé = `ruleId` du SVRL (peut contenir un suffixe `_BT-xx`, on tente aussi la
 * racine avant le premier `_`).
 */
const RULE_LABELS_FR: Readonly<Record<string, string>> = {
  // EN16931 — identification fiscale du vendeur requise par catégorie de TVA
  // (BR-{cat}-02). Cas utilisateur fréquent : n° de TVA vendeur non renseigné.
  // Message FR actionnable (le svrl:text officiel est en anglais).
  "BR-S-02":
    "N° de TVA du vendeur manquant : il est obligatoire pour une ligne au taux normal. " +
    "Renseignez-le dans Paramètres > Entreprise.",
  "BR-Z-02":
    "N° de TVA du vendeur manquant : il est obligatoire pour une ligne au taux zéro. " +
    "Renseignez-le dans Paramètres > Entreprise.",
  "BR-E-02":
    "N° de TVA du vendeur manquant : il est obligatoire pour une ligne exonérée de TVA. " +
    "Renseignez-le dans Paramètres > Entreprise.",
  "BR-AE-02":
    "N° de TVA du vendeur manquant : il est obligatoire pour une ligne en autoliquidation. " +
    "Renseignez-le dans Paramètres > Entreprise.",
  // EN16931 — règles de cohérence des totaux (svrl:text anglais).
  "BR-CO-10": "La somme des montants nets de ligne doit égaler le total HT des lignes.",
  "BR-CO-11": "La somme des remises au niveau document doit égaler le total des remises.",
  "BR-CO-12": "La somme des charges au niveau document doit égaler le total des charges.",
  "BR-CO-13":
    "Le total HT doit égaler la somme des montants de ligne, moins les remises, plus les charges.",
  "BR-CO-15": "Le total TTC doit égaler le total HT plus le montant total de TVA.",
  "BR-CO-16": "Le montant restant dû doit égaler le total TTC moins les acomptes déjà versés.",
  // EXTENDED-CTC-FR — tolérances décimales (règles patchées PSVI).
  "BR-FREXT-CO-10": "Écart de calcul sur les montants nets de ligne (catégorie TVA « Zéro »).",
  "BR-FREXT-CO-11": "Écart de calcul sur le total des remises au niveau document.",
  "BR-FREXT-CO-12": "Écart de calcul sur le total des charges au niveau document.",
};

/**
 * Retourne le libellé FR override d'une règle Schematron, ou `undefined` si non
 * couvert (l'appelant retombe alors sur le `message` svrl:text). Tente l'`id`
 * complet puis sa racine (avant le premier `_`, ex. `BR-FR-23_BT-49` → `BR-FR-23`).
 */
export function schematronRuleLabel(ruleId: string): string | undefined {
  if (ruleId in RULE_LABELS_FR) return RULE_LABELS_FR[ruleId];
  const root = ruleId.split("_")[0];
  if (root !== undefined && root !== ruleId && root in RULE_LABELS_FR) {
    return RULE_LABELS_FR[root];
  }
  return undefined;
}
