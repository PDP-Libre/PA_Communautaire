// Shim typé pour `saxon-js` (2.7.x, CommonJS) qui ne fournit pas de types.
//
// Centralise l'unique import non typé du moteur : les consommateurs du package
// (y compris `apps/api` qui compile les sources via `types: src/index.ts`) n'ont
// ainsi pas besoin d'une déclaration ambient externe. On n'expose que la surface
// réellement consommée par l'engine Schematron embarqué.

/** SEF (Stylesheet Export File) chargé en mémoire — objet JSON opaque. */
export type CompiledStylesheet = Record<string, unknown>;

export interface TransformOptions {
  /** SEF déjà parsé (JSON.parse) — réutilisable, cache module-scope. */
  stylesheetInternal?: CompiledStylesheet;
  /** XML source en chaîne. */
  sourceText?: string;
  /** `"serialized"` retourne `principalResult: string` (SVRL). */
  destination?: "serialized" | "document" | "application" | "file";
}

export interface TransformResult {
  /** Résultat sérialisé (SVRL XML) quand `destination: "serialized"`. */
  principalResult?: string;
}

// @ts-expect-error — saxon-js ne livre pas de déclaration de types (TS7016).
import SaxonJSRaw from "saxon-js";

/** Surface typée minimale de `SaxonJS.transform` en mode asynchrone. */
export const SaxonJS = SaxonJSRaw as {
  transform(options: TransformOptions, execMode: "async"): Promise<TransformResult>;
};
