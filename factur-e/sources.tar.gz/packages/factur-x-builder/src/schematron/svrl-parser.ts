// Parseur SVRL (Schematron Validation Reporting Language) → liste d'assertions.
//
// Les Schematrons FNFE-MPE émettent du SVRL (namespace
// `http://purl.oclc.org/dsdl/svrl`). On extrait :
//   - `svrl:failed-assert`     → assertion FATALE échouée (la règle n'est pas
//     respectée alors qu'elle aurait dû l'être) ;
//   - `svrl:successful-report` → signalement (souvent warning métier).
// La sévérité réelle est portée par l'attribut `@flag` (fatal | warning | info).
//
// Réutilise `libxmljs2` (déjà dépendance du builder pour la validation XSD).

import libxmljs from "libxmljs2";

const SVRL_NS = { svrl: "http://purl.oclc.org/dsdl/svrl" };

/** Surface minimale consommée d'un nœud libxmljs2 (types upstream incomplets). */
interface XmlTextNode {
  text(): string;
}

export type SvrlSeverity = "fatal" | "warning";

export interface SvrlAssertion {
  /** Identifiant de règle (`@id`, ex. "BR-FR-04") — `""` si absent. */
  ruleId: string;
  /** Sévérité dérivée de `@flag` (`fatal` sinon `warning`). */
  severity: SvrlSeverity;
  /** Type d'enregistrement SVRL d'origine. */
  kind: "failed-assert" | "successful-report";
  /** Message humain (`svrl:text`). */
  message: string;
  /** Localisation XPath de l'élément en faute (`@location`). */
  xpath: string;
}

function textOf(node: libxmljs.Element): string {
  const t = node.get("svrl:text", SVRL_NS) as unknown as XmlTextNode | null;
  return t === null ? "" : t.text().trim().replace(/\s+/g, " ");
}

function attr(node: libxmljs.Element, name: string): string {
  return node.attr(name)?.value() ?? "";
}

function severityFromFlag(flag: string): SvrlSeverity {
  return flag.toLowerCase() === "fatal" ? "fatal" : "warning";
}

/**
 * Parse un document SVRL et retourne toutes les assertions (failed-assert +
 * successful-report), dans l'ordre du document.
 */
export function parseSvrl(svrlXml: string): SvrlAssertion[] {
  const doc = libxmljs.parseXml(svrlXml);
  const assertions: SvrlAssertion[] = [];

  const collect = (xpath: string, kind: SvrlAssertion["kind"]): void => {
    for (const node of doc.find(xpath, SVRL_NS)) {
      const el = node as libxmljs.Element;
      assertions.push({
        ruleId: attr(el, "id"),
        severity: severityFromFlag(attr(el, "flag")),
        kind,
        message: textOf(el),
        xpath: attr(el, "location"),
      });
    }
  };

  collect("//svrl:failed-assert", "failed-assert");
  collect("//svrl:successful-report", "successful-report");
  return assertions;
}

/** Filtre les assertions fatales (`@flag=fatal`). */
export function fatalAssertions(assertions: readonly SvrlAssertion[]): SvrlAssertion[] {
  return assertions.filter((a) => a.severity === "fatal");
}

/** Filtre les assertions warning (`@flag=warning|info`). */
export function warningAssertions(assertions: readonly SvrlAssertion[]): SvrlAssertion[] {
  return assertions.filter((a) => a.severity === "warning");
}
