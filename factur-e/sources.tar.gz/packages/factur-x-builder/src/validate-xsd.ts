// Validation XSD profils émission V2 Factur-X via libxmljs2 (libxml2 bindings).
//
// Sprint-01 ADR-004 — version initiale `validateExtendedXsd` (EXTENDED only).
// Sprint-06 T-CL-FACTURX-BUILDER-REFACTOR-CTC-FR (ADR-016 candidat D1) — hard
// switch émission V2 : 2 profils seuls `en16931` + `extended-ctc-fr`. Les
// profils MINIMUM / BASIC WL / BASIC sont retirés de l'émission. Cache par
// profil pour préserver la perf ~2 ms / validation (cf. spike T-CL-05 bench).
//
// XSDs : `en16931` → `docs/external/factur-x-1.08/EN16931/` (Q1 — XSD 1.08, base
// CII D22B identique, faute de 1.07.3 EN16931 disponible) ; `extended-ctc-fr` →
// `docs/external/factur-x-1.07.3/EXTENDED/`. Si un XSD est absent, `validateXsd`
// retourne `ok({skipped:true})` — la pipeline reste verte en signalant l'absence.
//
// API rétro-compatible : `validateExtendedXsd(xml)` préservé (→ extended-ctc-fr).

import { access, readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import path from "node:path";

import libxmljs from "libxmljs2";

import { type Result, err, ok } from "./result.js";

const HERE = path.dirname(fileURLToPath(import.meta.url));
// HERE = .../packages/factur-x-builder/src → 3× ".." pour atteindre la racine du worktree.
const REPO_ROOT = path.resolve(HERE, "..", "..", "..");
const EXTERNAL_BASE = path.resolve(REPO_ROOT, "docs/external");

/**
 * Profils Factur-X validables à l'émission V2 (sprint-06 T-CL-FACTURX-BUILDER-
 * REFACTOR-CTC-FR — ADR-016 candidat D1). Deux profils seuls :
 *  - `en16931`        : canal PEPPOL UE strict (cardinalités EN16931).
 *  - `extended-ctc-fr`: canal SuperPDP/PA FR réforme (relaxations Schematron).
 *
 * Les profils MINIMUM / BASIC WL / BASIC sont supprimés de l'émission V2.
 * La réception (`apps/api`) reste agnostique du profil entrant — cf. Z7.
 */
export type FacturXProfileKey = "en16931" | "extended-ctc-fr";

/**
 * Mapping profil → répertoire + entry XSD attendu.
 *
 * NOTE-COWORK (Q1) : aucun XSD EN16931 Factur-X 1.07.3 n'est disponible dans le
 * repo ni l'archive FNFE-MPE locale ; on s'appuie sur le XSD EN16931 Factur-X
 * **1.08** (base CII D22B identique, cardinalités EN16931 stables). La garde
 * stricte EN16931 réelle reste le Schematron EN16931 V1.3.15 (cf. validate-cascade).
 */
const XSD_LOCATIONS: Record<FacturXProfileKey, { dir: string; entry: string }> = {
  en16931: {
    dir: path.join(EXTERNAL_BASE, "factur-x-1.08", "EN16931"),
    entry: "Factur-X_1.08_EN16931.xsd",
  },
  "extended-ctc-fr": {
    dir: path.join(EXTERNAL_BASE, "factur-x-1.07.3", "EXTENDED"),
    entry: "Factur-X_1.07.3_EXTENDED.xsd",
  },
};

export interface ValidationError {
  /** Message libxml2 brut. */
  message: string;
  /** Numéro de ligne dans le XML validé (1-based, 0 si non disponible). */
  line: number;
  /**
   * Colonne dans le XML (1-based) — libxmljs2 ne l'expose pas systématiquement,
   * dans ce cas on garde 0.
   */
  column: number;
  /** Code libxml (entier). */
  code?: number;
}

/** Cache par profil — entrée `null` = XSD absent du repo (skip gracieux). */
const cachedSchemas = new Map<FacturXProfileKey, libxmljs.Document | null>();

async function fileExists(p: string): Promise<boolean> {
  try {
    await access(p);
    return true;
  } catch {
    return false;
  }
}

/**
 * Charge et compile le XSD du profil — coûteux la première fois.
 * Si le fichier d'entrée n'existe pas, retourne `null` (skip gracieux).
 */
async function loadSchema(profile: FacturXProfileKey): Promise<libxmljs.Document | null> {
  if (cachedSchemas.has(profile)) {
    return cachedSchemas.get(profile) ?? null;
  }
  const { dir, entry } = XSD_LOCATIONS[profile];
  const entryPath = path.join(dir, entry);
  if (!(await fileExists(entryPath))) {
    cachedSchemas.set(profile, null);
    return null;
  }
  const xsdBuffer = await readFile(entryPath);
  const baseUrl = `file://${dir}/`;
  const xsdDoc = libxmljs.parseXml(xsdBuffer.toString("utf-8"), {
    baseUrl,
    nonet: false, // permet à libxml2 de charger les imports voisins (file://).
  });
  cachedSchemas.set(profile, xsdDoc);
  return xsdDoc;
}

/**
 * Résultat structuré incluant le cas "XSD profil non disponible localement".
 * Quand `skipped === true`, le XSD n'est pas dans le repo (cas transitoire
 * Z5 sprint-05 W1) — la pipeline reste verte mais signale au caller.
 */
export interface ValidateXsdOutcome {
  profile: FacturXProfileKey;
  skipped: boolean;
  skipReason?: string;
}

/**
 * Valide un XML CII contre le XSD du profil indiqué.
 *
 * @param xml      XML à valider (UTF-8 string).
 * @param profile  Profil cible (`"extended-ctc-fr"` par défaut).
 */
export async function validateXsd(
  xml: string,
  profile: FacturXProfileKey = "extended-ctc-fr",
): Promise<Result<ValidateXsdOutcome, ValidationError>> {
  const xsdDoc = await loadSchema(profile);
  if (xsdDoc === null) {
    const { dir, entry } = XSD_LOCATIONS[profile];
    return ok({
      profile,
      skipped: true,
      skipReason: `XSD profil "${profile}" absent du repo (${path.relative(REPO_ROOT, path.join(dir, entry))}). Validation XSD skip gracieux — la garde stricte reste le Schematron du profil.`,
    });
  }
  const xmlDoc = libxmljs.parseXml(xml);
  const valid = xmlDoc.validate(xsdDoc);
  if (valid) return ok({ profile, skipped: false });
  const rawErrors = xmlDoc.validationErrors as readonly {
    message?: string;
    line?: number;
    column?: number;
    code?: number;
  }[];
  const errors: ValidationError[] = rawErrors.map((e) => ({
    message: e.message ?? "(unknown)",
    line: e.line ?? 0,
    column: e.column ?? 0,
    code: typeof e.code === "number" ? e.code : undefined,
  }));
  return err(errors);
}

/**
 * Alias rétro-compatible sprint-01 — valide profil EXTENDED-CTC-FR uniquement.
 * Retourne `Result<true, ValidationError>` à l'identique pour ne pas casser
 * les consommateurs existants (`apps/api/src/services/invoice-*`, tests).
 */
export async function validateExtendedXsd(xml: string): Promise<Result<true, ValidationError>> {
  const r = await validateXsd(xml, "extended-ctc-fr");
  if (!r.ok) return r;
  // L'alias historique retourne `true` même si skipped (cas impossible en
  // pratique pour EXTENDED-CTC-FR — XSD présent au repo depuis sprint-01).
  return ok(true);
}

/** Réinitialise le cache du/des schéma(s) — utile en test pour mesurer un cold-start. */
export function resetSchemaCache(): void {
  cachedSchemas.clear();
}

/** Chemin absolu de l'entry XSD EXTENDED-CTC-FR (utile pour tests/diagnostics). */
export const XSD_PATH = path.join(
  XSD_LOCATIONS["extended-ctc-fr"].dir,
  XSD_LOCATIONS["extended-ctc-fr"].entry,
);
