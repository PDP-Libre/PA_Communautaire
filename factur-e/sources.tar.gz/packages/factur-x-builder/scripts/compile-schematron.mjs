// Compile les Schematrons CTC-FR V1.3.1 (.xsl/.xslt) en SEF (.sef.json) pour
// l'engine saxon-js embarqué. Régénère les artefacts versionnés sous
// `schemas/schematron/<profil>/`.
//
// Usage : pnpm --filter @factur-e/factur-x-builder compile-schematron
//
// Le compilateur `xslt3` (Saxonica) est une devDependency ; on l'invoque via
// son binaire résolu depuis node_modules.

import { spawnSync } from "node:child_process";
import { existsSync, mkdtempSync, readFileSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import process from "node:process";
import { fileURLToPath } from "node:url";
import path from "node:path";

import { patchPsvi } from "./patch-psvi.mjs";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const PACKAGE_ROOT = path.resolve(HERE, "..");
const SCH = path.join(PACKAGE_ROOT, "schemas", "schematron");
const XSLT3 = path.join(PACKAGE_ROOT, "node_modules", ".bin", "xslt3");

/**
 * Stylesheets à compiler : { src, out, patch }. `patch: true` applique le patch
 * PSVI (3 règles BR-FREXT-CO-10/11/12) à la compilation — l'officiel `.xsl` reste
 * pristine au repo, l'intermédiaire patché est écrit en tmpdir (cf. patch-psvi.mjs).
 */
const TARGETS = [
  {
    src: "en16931/EN16931-CII-validation.xslt",
    out: "en16931/EN16931-CII-validation.sef.json",
    patch: false,
  },
  {
    src: "extended-ctc-fr/EXTENDED-CTC-FR-CII-V1.3.1.xsl",
    out: "extended-ctc-fr/EXTENDED-CTC-FR-CII-V1.3.1.sef.json",
    patch: true,
  },
  {
    src: "br-fr-flux2/BR-FR-Flux2-Schematron-CII_V1.3.1.xsl",
    out: "br-fr-flux2/BR-FR-Flux2-Schematron-CII_V1.3.1.sef.json",
    patch: false,
  },
];

if (!existsSync(XSLT3)) {
  process.stderr.write(
    `[compile-schematron] ✗ xslt3 introuvable (${XSLT3}). Lancez 'pnpm install'.\n`,
  );
  process.exit(1);
}

let failed = 0;
for (const { src, out, patch } of TARGETS) {
  const srcPath = path.join(SCH, src);
  const outPath = path.join(SCH, out);
  // Source compilée : l'officiel, ou un intermédiaire patché PSVI (le .xsl est
  // auto-contenu, pas d'xsl:include → compilation en tmpdir sans souci de résolution).
  let xslPath = srcPath;
  if (patch) {
    const { patched, wrapped } = patchPsvi(readFileSync(srcPath, "utf-8"));
    const dir = mkdtempSync(path.join(tmpdir(), "facturx-psvi-"));
    xslPath = path.join(dir, path.basename(src));
    writeFileSync(xslPath, patched, "utf-8");
    process.stdout.write(`[compile-schematron] patch PSVI : ${String(wrapped)} sum() enveloppés\n`);
  }
  process.stdout.write(`[compile-schematron] ${src} → ${out}\n`);
  const r = spawnSync(XSLT3, [`-xsl:${xslPath}`, `-export:${outPath}`, "-nogo"], {
    stdio: ["ignore", "ignore", "inherit"],
  });
  if (r.status !== 0) {
    process.stderr.write(`[compile-schematron] ✗ échec compilation ${src}\n`);
    failed++;
  }
}

process.stdout.write(
  failed === 0
    ? `[compile-schematron] ✓ ${String(TARGETS.length)} SEF régénérés.\n`
    : `[compile-schematron] ✗ ${String(failed)} échec(s).\n`,
);
process.exit(failed === 0 ? 0 : 1);
