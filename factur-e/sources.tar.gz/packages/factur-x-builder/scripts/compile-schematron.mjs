// Compile les Schematrons CTC-FR V1.3.1 (.xsl/.xslt) en SEF (.sef.json) pour
// l'engine saxon-js embarqué. Régénère les artefacts versionnés sous
// `schemas/schematron/<profil>/`.
//
// Usage : pnpm --filter @factur-e/factur-x-builder compile-schematron
//
// Le compilateur `xslt3` (Saxonica) est une devDependency ; on l'invoque via
// son binaire résolu depuis node_modules.

import { spawnSync } from "node:child_process";
import { existsSync } from "node:fs";
import process from "node:process";
import { fileURLToPath } from "node:url";
import path from "node:path";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const PACKAGE_ROOT = path.resolve(HERE, "..");
const SCH = path.join(PACKAGE_ROOT, "schemas", "schematron");
const XSLT3 = path.join(PACKAGE_ROOT, "node_modules", ".bin", "xslt3");

/** Stylesheets à compiler : [source .xsl/.xslt, SEF cible]. */
const TARGETS = [
  ["en16931/EN16931-CII-validation.xslt", "en16931/EN16931-CII-validation.sef.json"],
  [
    "extended-ctc-fr/EXTENDED-CTC-FR-CII-V1.3.1.xsl",
    "extended-ctc-fr/EXTENDED-CTC-FR-CII-V1.3.1.sef.json",
  ],
  [
    "br-fr-flux2/BR-FR-Flux2-Schematron-CII_V1.3.1.xsl",
    "br-fr-flux2/BR-FR-Flux2-Schematron-CII_V1.3.1.sef.json",
  ],
];

if (!existsSync(XSLT3)) {
  process.stderr.write(
    `[compile-schematron] ✗ xslt3 introuvable (${XSLT3}). Lancez 'pnpm install'.\n`,
  );
  process.exit(1);
}

let failed = 0;
for (const [src, out] of TARGETS) {
  const srcPath = path.join(SCH, src);
  const outPath = path.join(SCH, out);
  process.stdout.write(`[compile-schematron] ${src} → ${out}\n`);
  const r = spawnSync(XSLT3, [`-xsl:${srcPath}`, `-export:${outPath}`, "-nogo"], {
    stdio: ["ignore", "ignore", "inherit"],
  });
  if (r.status !== 0) {
    process.stderr.write(`[compile-schematron] ✗ échec compilation ${src}\n`);
    failed++;
  }
}

process.stdout.write(
  failed === 0
    ? `[compile-schematron] ✓ ${String(TARGETS.length)} SEF régénérés.\n`
    : `[compile-schematron] ✗ ${String(failed)} échec(s).\n`,
);
process.exit(failed === 0 ? 0 : 1);
