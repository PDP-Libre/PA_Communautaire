// Déclarations de types pour le module de patch PSVI (scripts/patch-psvi.mjs).
// Le script reste en .mjs (exécuté tel quel par `node` dans compile-schematron.mjs) ;
// ce .d.mts donne les types aux consommateurs TS (tests).

/** Règles tripwire attestant qu'on patche bien le Schematron EXTENDED-CTC-FR attendu. */
export const PSVI_SENTINEL_RULES: readonly string[];

/** Enveloppe chaque `sum(X)` en `sum(for $v in X return xs:decimal($v))`. Idempotent. */
export function wrapSums(expr: string): { expr: string; wrapped: number };

/**
 * Applique le patch PSVI à un XSLT Schematron EXTENDED-CTC-FR (toutes les sommes de
 * montants). Vérifie d'abord la présence des règles tripwire.
 * @throws si une règle tripwire est absente (version FNFE inattendue)
 */
export function patchPsvi(src: string): { patched: string; wrapped: number };
