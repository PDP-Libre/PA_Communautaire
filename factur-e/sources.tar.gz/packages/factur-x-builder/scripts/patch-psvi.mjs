// Patch PSVI déterministe pour saxon-js HE (« Home Edition »).
//
// Contexte (docs/standards/s1-validation-emission-schematron.md §5) : saxon-js HE
// n'est pas schema-aware (pas de PSVI — réservé à la version payante). Les valeurs
// CII ne sont pas typées : `sum(<montants>)` est évalué en xs:double, alors que de
// nombreuses règles de calcul attendent xs:decimal → saxon-js plante (erreur moteur
// « Required item type of first operand of 'arith' is xs:decimal; supplied xs:double »).
//
// NOTE divergence doc §5 : la note directeur cite « 3 règles » (BR-FREXT-CO-10/11/12,
// observées sur une facture riche). Mesuré sur nos fixtures, le problème touche AUSSI
// les calculs TVA par catégorie (BR-CO-09/BR-S/BR-Z…). Le correctif est donc appliqué
// à TOUTES les sommes de montants, pas aux 3 seules règles. Le garde-fou CI
// (engineErrors === false) verrouille la couverture réelle.
//
// Correctif : forcer chaque somme en xs:decimal —
//   sum(X)  ->  sum(for $v in X return xs:decimal($v))
// Sémantique identique (et plus juste pour de la monnaie). Appliqué à la compilation,
// donc réappliquable à chaque version FNFE sans modifier l'officiel à la main.
//
// Module pur (pas d'I/O) pour être testable unitairement + consommé par
// compile-schematron.mjs.

/**
 * Règles tripwire : leur présence atteste qu'on patche bien le Schematron
 * EXTENDED-CTC-FR attendu. Si une version FNFE les renomme/supprime, le patch
 * échoue bruyamment plutôt que de wrapper un fichier inattendu.
 */
export const PSVI_SENTINEL_RULES = ["BR-FREXT-CO-10", "BR-FREXT-CO-11", "BR-FREXT-CO-12"];

const SUM_OPEN = "sum(";
const WRAP_PREFIX = "for $v in ";
const WRAP_SUFFIX = " return xs:decimal($v)";

/**
 * Enveloppe chaque `sum(ARG)` d'une expression XPath en
 * `sum(for $v in ARG return xs:decimal($v))`. Gère les parenthèses imbriquées
 * (prédicats `[not(...)]`, `xs:decimal(...)`, etc.). Idempotent : une somme déjà
 * patchée (argument commençant par `for $v in `) est laissée intacte.
 *
 * @param {string} expr expression XPath (valeur d'un attribut `test=`)
 * @returns {{ expr: string, wrapped: number }}
 */
export function wrapSums(expr) {
  let out = "";
  let i = 0;
  let wrapped = 0;
  for (;;) {
    const idx = expr.indexOf(SUM_OPEN, i);
    if (idx === -1) {
      out += expr.slice(i);
      break;
    }
    out += expr.slice(i, idx + SUM_OPEN.length);
    // Extraction de l'argument à parenthèses équilibrées.
    let depth = 1;
    let j = idx + SUM_OPEN.length;
    while (j < expr.length && depth > 0) {
      const c = expr[j];
      if (c === "(") depth++;
      else if (c === ")") {
        depth--;
        if (depth === 0) break;
      }
      j++;
    }
    if (depth !== 0) {
      throw new Error("[patch-psvi] parenthèse sum() non équilibrée");
    }
    const arg = expr.slice(idx + SUM_OPEN.length, j);
    if (arg.startsWith(WRAP_PREFIX)) {
      out += arg; // déjà patché — idempotent
    } else {
      out += `${WRAP_PREFIX}${arg}${WRAP_SUFFIX}`;
      wrapped++;
    }
    out += ")";
    i = j + 1;
  }
  return { expr: out, wrapped };
}

/**
 * Applique le patch PSVI à un XSLT Schematron EXTENDED-CTC-FR : enveloppe chaque
 * `sum(X)` en `sum(for $v in X return xs:decimal($v))` (toutes les sommes de
 * montants, cf. note divergence en tête de module). Vérifie d'abord la présence des
 * règles tripwire (garde-fou version FNFE).
 *
 * Les seuls `sum(` du fichier sont des expressions XPath (la prose SVRL utilise
 * « Sum of » / « Σ », jamais `sum(`) : l'enveloppe globale est donc sûre.
 *
 * @param {string} src source XSLT (verbatim FNFE)
 * @returns {{ patched: string, wrapped: number }}
 * @throws si une règle tripwire est absente (version FNFE inattendue)
 */
export function patchPsvi(src) {
  for (const ruleId of PSVI_SENTINEL_RULES) {
    if (!src.includes(`>${ruleId}</xsl:attribute>`)) {
      throw new Error(
        `[patch-psvi] règle tripwire absente (version FNFE inattendue ?) : ${ruleId}`,
      );
    }
  }
  const { expr, wrapped } = wrapSums(src);
  return { patched: expr, wrapped };
}
