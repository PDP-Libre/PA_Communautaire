import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    include: ["spikes/**/tests/**/*.test.ts", "src/**/*.test.ts", "tests/**/*.test.ts"],
    testTimeout: 30_000, // libxmljs2 cold start (compile XSD ~ 200 ms) + safety margin.
    coverage: {
      provider: "v8",
      reporter: ["text", "html"],
      include: ["spikes/**/*.ts", "src/**/*.ts"],
      exclude: ["**/tests/**", "**/index.ts", "**/bin/**"],
    },
  },
});
