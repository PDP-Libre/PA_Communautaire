# Schematrons FNFE-MPE CTC-FR V1.3.1 — engine embarqué saxon-js

Schematrons officiels FNFE-MPE (Forum National de la Facture Électronique), version
**2026_04_30_FNFE_SCHEMATRONS_FR_CTC_V1.3.1**, compilés en XSLT 2.0 émetteurs de SVRL.
Consommés par l'engine embarqué `src/schematron/` (ADR-016 candidat D4, sprint-06).

## Contenu (profil CII uniquement — Factur-X = CII)

| Dossier | Source `.xsl`/`.xslt` (verbatim FNFE-MPE) | SEF compilé (`.sef.json`) | Profil émission |
|---|---|---|---|
| `en16931/` | `EN16931-CII-validation.xslt` (V1.3.15) | idem `.sef.json` | EN16931 (canal PEPPOL UE) |
| `extended-ctc-fr/` | `EXTENDED-CTC-FR-CII-V1.3.1.xsl` | idem `.sef.json` | EXTENDED-CTC-FR (canal FR) |
| `br-fr-flux2/` | `BR-FR-Flux2-Schematron-CII_V1.3.1.xsl` | idem `.sef.json` | EXTENDED-CTC-FR (canal FR) |

Les variantes UBL ne sont pas embarquées (Factur-X est exclusivement CII).

## Licence

Les fichiers source `.xsl` / `.xslt` sont publiés par la FNFE-MPE sous **EUPL**
(European Union Public Licence) — v1.2 pour les Schematrons EN16931, v1.3.1 pour les
Schematrons EXTENDED-CTC-FR et BR-FR-Flux2. Les en-têtes de licence sont préservés
intacts dans les fichiers source. Les SEF (`.sef.json`) sont des artefacts dérivés de
ces sources, soumis à la même licence.

## Régénération des SEF

Les `.sef.json` sont compilés depuis les `.xsl`/`.xslt` via le compilateur Saxonica
`xslt3` (devDependency). Pour régénérer (ex. nouvelle version FNFE-MPE) :

```bash
pnpm --filter @factur-e/factur-x-builder compile-schematron
```

Cf. `scripts/compile-schematron.mjs`. Les SEF sont versionnés au repo pour éviter une
étape de compilation en CI/runtime (cold start XSLT évité — cf. perf ~50-100 ms/sample).

## Patch PSVI (EXTENDED-CTC-FR)

Le moteur runtime `saxon-js` HE n'est pas schema-aware (PSVI réservé à la version
payante). Les valeurs CII n'étant pas typées, `sum(<montants>)` est évalué en
`xs:double` alors que les règles de calcul attendent `xs:decimal` → saxon-js plante
(`Required item type of first operand of 'arith' is xs:decimal`).

Correctif appliqué **à la compilation** (`scripts/patch-psvi.mjs`), sur un intermédiaire
en `tmpdir` — le `.xsl` officiel reste **pristine** au repo : chaque somme est forcée en
décimal, `sum(X)` → `sum(for $v in X return xs:decimal($v))`. Sémantique identique (et
plus juste pour de la monnaie), réappliquable à chaque version FNFE sans édition manuelle.

NB : la note directeur (`docs/standards/s1-validation-emission-schematron.md` §5) cite
« 3 règles » (`BR-FREXT-CO-10/11/12`) ; mesuré sur les fixtures, le problème touche aussi
les calculs TVA par catégorie — le patch couvre donc **toutes** les sommes de montants.
Garde-fou : `tests/schematron/psvi-guardrail.test.ts` casse le build si une erreur moteur
réapparaît (`engineErrors === true`).
