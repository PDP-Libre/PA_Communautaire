# Schematrons FNFE-MPE CTC-FR V1.3.1 — engine embarqué saxon-js

Schematrons officiels FNFE-MPE (Forum National de la Facture Électronique), version
**2026_04_30_FNFE_SCHEMATRONS_FR_CTC_V1.3.1**, compilés en XSLT 2.0 émetteurs de SVRL.
Consommés par l'engine embarqué `src/schematron/` (ADR-016 candidat D4, sprint-06).

## Contenu (profil CII uniquement — Factur-X = CII)

| Dossier | Source `.xsl`/`.xslt` (verbatim FNFE-MPE) | SEF compilé (`.sef.json`) | Profil émission |
|---|---|---|---|
| `en16931/` | `EN16931-CII-validation.xslt` (V1.3.15) | idem `.sef.json` | EN16931 (canal PEPPOL UE) |
| `extended-ctc-fr/` | `EXTENDED-CTC-FR-CII-V1.3.1.xsl` | idem `.sef.json` | EXTENDED-CTC-FR (canal FR) |
| `br-fr-flux2/` | `BR-FR-Flux2-Schematron-CII_V1.3.1.xsl` | idem `.sef.json` | EXTENDED-CTC-FR (canal FR) |

Les variantes UBL ne sont pas embarquées (Factur-X est exclusivement CII).

## Licence

Les fichiers source `.xsl` / `.xslt` sont publiés par la FNFE-MPE sous **EUPL**
(European Union Public Licence) — v1.2 pour les Schematrons EN16931, v1.3.1 pour les
Schematrons EXTENDED-CTC-FR et BR-FR-Flux2. Les en-têtes de licence sont préservés
intacts dans les fichiers source. Les SEF (`.sef.json`) sont des artefacts dérivés de
ces sources, soumis à la même licence.

## Régénération des SEF

Les `.sef.json` sont compilés depuis les `.xsl`/`.xslt` via le compilateur Saxonica
`xslt3` (devDependency). Pour régénérer (ex. nouvelle version FNFE-MPE) :

```bash
pnpm --filter @factur-e/factur-x-builder compile-schematron
```

Cf. `scripts/compile-schematron.mjs`. Les SEF sont versionnés au repo pour éviter une
étape de compilation en CI/runtime (cold start XSLT évité — cf. perf ~50-100 ms/sample).
