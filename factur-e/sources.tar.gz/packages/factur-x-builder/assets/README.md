# Assets du spike PDF/A-3

Fichiers binaires embarqués dans le PDF généré.

## `Roboto-Regular.ttf` — Apache License 2.0

Police Roboto Regular (Google), 158 604 octets.
- Licence : Apache 2.0 — redistribution autorisée, voir
  https://www.apache.org/licenses/LICENSE-2.0
- Source : projet [Roboto](https://fonts.google.com/specimen/Roboto) de Google,
  copié depuis `~/Library/Fonts/Roboto-Regular.ttf` sur la machine de
  développement.
- Usage : embarqué dans le PDF via `pdfDoc.embedFont(bytes, { subset: true })`
  pour satisfaire ISO 19005-3 §6.2.11.4.1 (toutes les fonts utilisées doivent
  être embarquées dans un PDF/A).

Choix Roboto plutôt qu'Helvetica/Arial : licence claire, glyphes Latin
complets, rendu propre à toutes les tailles, ~160 ko.

## `sRGB.icc` — sRGB IEC61966-2.1

Profil ICC sRGB IEC61966-2.1, 3 144 octets.
- Source : `/System/Library/ColorSync/Profiles/sRGB Profile.icc` (macOS).
- Usage : embarqué comme `OutputIntent.DestOutputProfile` pour satisfaire
  ISO 19005-3 §6.2.4.3 (un OutputIntent ICC est obligatoire en PDF/A).
- **[DEBT] Licence redistribution Microsoft à clarifier en T-CL-06.** Option
  recommandée : remplacer par le profil OpenICC sRGB v2 public-domain.
