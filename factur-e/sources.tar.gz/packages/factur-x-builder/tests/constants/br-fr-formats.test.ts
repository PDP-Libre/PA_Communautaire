// Tests formats décimaux + sanitizeInvoiceId BR-FR-CTC-Flux2 V1.3.1.

import { describe, expect, it } from "vitest";

import {
  FacturXFormatError,
  INVOICE_ID_MAX_LENGTH,
  formatAmount19_2,
  formatQuantity19_4,
  formatUnitPrice19_6,
  formatVatRate4_2,
  isValidAmount19_2,
  isValidInvoiceId,
  isValidQuantity19_4,
  isValidUnitPrice19_6,
  isValidVatRate4_2,
  sanitizeInvoiceId,
} from "../../src/constants/index.js";

describe("BR-FR-DEC-01 — montants 19/2", () => {
  it("accepte/refuse selon le regex verbatim", () => {
    expect(isValidAmount19_2("12.00")).toBe(true);
    expect(isValidAmount19_2("-12.5")).toBe(true);
    expect(isValidAmount19_2("12.345")).toBe(false); // 3 décimales
    expect(isValidAmount19_2("12,00")).toBe(false); // virgule
  });

  it("formatAmount19_2 produit un point POSIX 2 décimales", () => {
    expect(formatAmount19_2(12)).toBe("12.00");
    expect(formatAmount19_2(-3.5)).toBe("-3.50");
  });
});

describe("BR-FR-DEC-02 — quantités 19/4", () => {
  it("accepte 4 décimales, refuse 5", () => {
    expect(isValidQuantity19_4("1.5000")).toBe(true);
    expect(isValidQuantity19_4("1.50000")).toBe(false);
  });

  it("formatQuantity19_4 produit 4 décimales", () => {
    expect(formatQuantity19_4(1.5)).toBe("1.5000");
  });
});

describe("BR-FR-DEC-03 — prix unitaires 19/6 positifs", () => {
  it("refuse les négatifs", () => {
    expect(isValidUnitPrice19_6("10.123456")).toBe(true);
    expect(isValidUnitPrice19_6("-10.00")).toBe(false);
  });

  it("formatUnitPrice19_6 produit 6 décimales", () => {
    expect(formatUnitPrice19_6(10)).toBe("10.000000");
  });

  it("formatUnitPrice19_6 lève sur valeur négative", () => {
    expect(() => formatUnitPrice19_6(-1)).toThrow(FacturXFormatError);
  });
});

describe("BR-FR-DEC-04 — taux TVA 4/2 positifs", () => {
  it("max 4 chiffres entiers, 2 décimales", () => {
    expect(isValidVatRate4_2("20.00")).toBe(true);
    expect(isValidVatRate4_2("9999.99")).toBe(true);
    expect(isValidVatRate4_2("10000.00")).toBe(false); // 5 chiffres entiers
    expect(isValidVatRate4_2("-20.00")).toBe(false);
  });

  it("formatVatRate4_2 produit 2 décimales", () => {
    expect(formatVatRate4_2(20)).toBe("20.00");
  });
});

describe("BR-FR-01 + BR-FR-02 — sanitizeInvoiceId / isValidInvoiceId", () => {
  it("isValidInvoiceId : longueur ≤ 35 + format [A-Za-z0-9+-_/]", () => {
    expect(isValidInvoiceId("FAC-2026-001")).toBe(true);
    expect(isValidInvoiceId("FAC 2026 001")).toBe(false); // espaces
    expect(isValidInvoiceId("FAC.2026.001")).toBe(false); // point interdit
    expect(isValidInvoiceId("A".repeat(36))).toBe(false); // > 35
    expect(isValidInvoiceId("")).toBe(false);
  });

  it("sanitizeInvoiceId remplace espaces/points et effondre les tirets", () => {
    expect(sanitizeInvoiceId("FAC 2026 001")).toBe("FAC-2026-001");
    expect(sanitizeInvoiceId("FAC.2026.001")).toBe("FAC-2026-001");
    expect(sanitizeInvoiceId("FAC   2026")).toBe("FAC-2026");
  });

  it("sanitizeInvoiceId est idempotent sur une entrée conforme", () => {
    const ok = "FAC-2026-001/A+B_C";
    expect(sanitizeInvoiceId(ok)).toBe(ok);
    expect(isValidInvoiceId(sanitizeInvoiceId(ok))).toBe(true);
  });

  it("sanitizeInvoiceId tronque à 35 caractères", () => {
    const long = "INV-" + "9".repeat(60);
    const out = sanitizeInvoiceId(long);
    expect(out.length).toBe(INVOICE_ID_MAX_LENGTH);
    expect(isValidInvoiceId(out)).toBe(true);
  });

  it("sanitizeInvoiceId lève si vide après assainissement", () => {
    expect(() => sanitizeInvoiceId("   ...   ")).toThrow(FacturXFormatError);
  });
});
