// Tests constantes/codes BR-FR-CTC-Flux2 + EXTENDED-CTC-FR V1.3.1.
// Vérifie les listes fermées verbatim + les gardes amont builder.

import { describe, expect, it } from "vitest";

import {
  ALLOWED_ATTACHMENT_CODES_V131,
  ALLOWED_BILLING_MODES,
  ALLOWED_DOCUMENT_TYPE_CODES,
  ALLOWED_FR_VAT_RATES,
  ALLOWED_VAT_CATEGORY_CODES_FR,
  COTRAITANCE_BILLING_MODES,
  FacturXCodeError,
  INCOTERM_WHITELIST_FR,
  LINE_SUBTYPE_CODES,
  assertValidDocumentTypeCode,
  isAllowedAttachmentCode,
  isAllowedBillingMode,
  isAllowedVatCategoryCodeFr,
  isValidDocumentTypeCode,
  isValidFrVatRate,
  isValidIncotermFr,
  isValidLineSubtype,
} from "../../src/constants/index.js";

describe("BR-FR-04 — codes type document (liste fermée 16)", () => {
  it("contient exactement les 16 codes verbatim", () => {
    expect([...ALLOWED_DOCUMENT_TYPE_CODES]).toEqual([
      "380",
      "389",
      "393",
      "501",
      "386",
      "500",
      "384",
      "471",
      "472",
      "473",
      "261",
      "262",
      "381",
      "396",
      "502",
      "503",
    ]);
    expect(ALLOWED_DOCUMENT_TYPE_CODES).toHaveLength(16);
  });

  it("isValidDocumentTypeCode accepte un code de la liste, refuse hors-liste", () => {
    expect(isValidDocumentTypeCode("380")).toBe(true);
    expect(isValidDocumentTypeCode("388")).toBe(false); // 388 hors liste FR
    expect(isValidDocumentTypeCode("")).toBe(false);
  });

  it("assertValidDocumentTypeCode lève FacturXCodeError hors-liste", () => {
    expect(() => {
      assertValidDocumentTypeCode("380");
    }).not.toThrow();
    expect(() => {
      assertValidDocumentTypeCode("999");
    }).toThrow(FacturXCodeError);
    expect(() => {
      assertValidDocumentTypeCode("999");
    }).toThrow(/BR-FR-04/);
  });
});

describe("BR-FR-08 + C1 — modes facturation (14 V1, hors cotraitance)", () => {
  it("contient 14 modes verbatim sans B8/S8/M8", () => {
    expect([...ALLOWED_BILLING_MODES]).toEqual([
      "B1",
      "S1",
      "M1",
      "B2",
      "S2",
      "M2",
      "S3",
      "B4",
      "S4",
      "M4",
      "S5",
      "S6",
      "B7",
      "S7",
    ]);
    expect(ALLOWED_BILLING_MODES).toHaveLength(14);
  });

  it("exclut les modes cotraitance B8/S8/M8", () => {
    expect([...COTRAITANCE_BILLING_MODES]).toEqual(["B8", "S8", "M8"]);
    for (const m of COTRAITANCE_BILLING_MODES) {
      expect(isAllowedBillingMode(m)).toBe(false);
    }
  });

  it("isAllowedBillingMode accepte les 14 modes V1", () => {
    for (const m of ALLOWED_BILLING_MODES) {
      expect(isAllowedBillingMode(m)).toBe(true);
    }
  });
});

describe("BR-FR-15 — catégories TVA FR", () => {
  it("contient {S, E, AE, K, G, O, Z}", () => {
    expect([...ALLOWED_VAT_CATEGORY_CODES_FR]).toEqual(["S", "E", "AE", "K", "G", "O", "Z"]);
  });

  it("refuse L et M (IGIC/IPSI espagnol)", () => {
    expect(isAllowedVatCategoryCodeFr("S")).toBe(true);
    expect(isAllowedVatCategoryCodeFr("L")).toBe(false);
    expect(isAllowedVatCategoryCodeFr("M")).toBe(false);
  });
});

describe("BR-FR-16 — taux TVA FR (variantes décimales tolérées)", () => {
  it("contient les 15 taux verbatim", () => {
    expect([...ALLOWED_FR_VAT_RATES]).toEqual([
      0, 10, 13, 20, 8.5, 19.6, 2.1, 5.5, 7, 20.6, 1.05, 0.9, 1.75, 9.2, 9.6,
    ]);
  });

  it("isValidFrVatRate tolère number et string + variantes décimales", () => {
    expect(isValidFrVatRate(20)).toBe(true);
    expect(isValidFrVatRate("20.00")).toBe(true);
    expect(isValidFrVatRate("5.5")).toBe(true);
    expect(isValidFrVatRate(8.5)).toBe(true);
    expect(isValidFrVatRate(15)).toBe(false); // taux non FR
    expect(isValidFrVatRate("abc")).toBe(false);
  });
});

describe("BR-FR-17 — codes pièces jointes V1.3.1 (12)", () => {
  it("contient les 12 codes dont RECAPITULATIF_COTRAITANCE (ajout V1.3.1)", () => {
    expect(ALLOWED_ATTACHMENT_CODES_V131).toHaveLength(12);
    expect(ALLOWED_ATTACHMENT_CODES_V131).toContain("RECAPITULATIF_COTRAITANCE");
    expect(ALLOWED_ATTACHMENT_CODES_V131).toContain("LISIBLE");
  });

  it("isAllowedAttachmentCode refuse un code inconnu", () => {
    expect(isAllowedAttachmentCode("RIB")).toBe(true);
    expect(isAllowedAttachmentCode("FACTURE")).toBe(false);
  });
});

describe("BR-FREXT-CL-27 — whitelist INCOTERM FR (13)", () => {
  it("contient les 13 valeurs verbatim", () => {
    expect([...INCOTERM_WHITELIST_FR]).toEqual([
      "1",
      "2",
      "CFR",
      "CIF",
      "CIP",
      "CPT",
      "DAP",
      "DDP",
      "DPU",
      "EXW",
      "FAS",
      "FCA",
      "FOB",
    ]);
  });

  it("isValidIncotermFr refuse un incoterm hors whitelist (ex. DAT retiré)", () => {
    expect(isValidIncotermFr("FCA")).toBe(true);
    expect(isValidIncotermFr("DAT")).toBe(false);
  });
});

describe("Sous-types de ligne EXTENDED (LineStatusReasonCode)", () => {
  it("contient {DETAIL, GROUP, INFORMATION}", () => {
    expect([...LINE_SUBTYPE_CODES]).toEqual(["DETAIL", "GROUP", "INFORMATION"]);
  });

  it("isValidLineSubtype refuse une valeur inconnue", () => {
    expect(isValidLineSubtype("GROUP")).toBe(true);
    expect(isValidLineSubtype("SUMMARY")).toBe(false);
  });
});
