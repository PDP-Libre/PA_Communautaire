// Tests unitaires du patch PSVI (scripts/patch-psvi.mjs) — logique pure, sans I/O.
// Le comportement de bout en bout (engineErrors === false sur les SEF régénérés) est
// couvert par psvi-guardrail.test.ts ; ici on verrouille les invariants du transform.

import { describe, expect, it } from "vitest";

import { PSVI_SENTINEL_RULES, patchPsvi, wrapSums } from "../../scripts/patch-psvi.mjs";

describe("wrapSums", () => {
  it("enveloppe une somme simple en xs:decimal", () => {
    const { expr, wrapped } = wrapSums("sum(a/b)");
    expect(expr).toBe("sum(for $v in a/b return xs:decimal($v))");
    expect(wrapped).toBe(1);
  });

  it("gère les parenthèses imbriquées (prédicats) et les sommes multiples", () => {
    const input = "round(sum(a/b[not(c)]/d)) + round(sum(e/f))";
    const { expr, wrapped } = wrapSums(input);
    expect(wrapped).toBe(2);
    expect(expr).toBe(
      "round(sum(for $v in a/b[not(c)]/d return xs:decimal($v))) + " +
        "round(sum(for $v in e/f return xs:decimal($v)))",
    );
  });

  it("est idempotent (une somme déjà patchée n'est pas re-enveloppée)", () => {
    const once = wrapSums("sum(a/b)").expr;
    const twice = wrapSums(once);
    expect(twice.wrapped).toBe(0);
    expect(twice.expr).toBe(once);
  });

  it("laisse intacte une expression sans somme", () => {
    const { expr, wrapped } = wrapSums("count(a/b) * xs:decimal(100)");
    expect(wrapped).toBe(0);
    expect(expr).toBe("count(a/b) * xs:decimal(100)");
  });
});

describe("patchPsvi", () => {
  const sentinelMarkup = PSVI_SENTINEL_RULES.map(
    (id) => `<xsl:attribute name="id">${id}</xsl:attribute>`,
  ).join("\n");

  it("exige les règles tripwire (échoue sur un XSLT inattendu)", () => {
    expect(() => patchPsvi('<xsl:when test="sum(a)"/>')).toThrow(/tripwire/);
  });

  it("enveloppe toutes les sommes quand les tripwires sont présents", () => {
    const src = `${sentinelMarkup}\n<xsl:when test="sum(a) + sum(b/c)"/>`;
    const { patched, wrapped } = patchPsvi(src);
    expect(wrapped).toBe(2);
    expect(patched).toContain("sum(for $v in a return xs:decimal($v))");
    expect(patched).toContain("sum(for $v in b/c return xs:decimal($v))");
    // Idempotent au niveau document complet.
    expect(patchPsvi(patched).wrapped).toBe(0);
  });
});
