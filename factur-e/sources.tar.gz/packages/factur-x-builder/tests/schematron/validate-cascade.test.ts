// Tests cascade de validation (XSD → Schematron EN16931 → EXTENDED-CTC-FR →
// BR-FR-Flux2) avec skip hors-profil (Z5-A séquentielle stricte, reporting cumulé).

import { describe, expect, it } from "vitest";

import { generateCII } from "../../src/generate-cii.js";
import { type CascadeStepName, validateCascade } from "../../src/schematron/validate-cascade.js";

import { minimalInvoice } from "../integration/fixtures.js";

const xml = generateCII(minimalInvoice);

function stepStatus(
  steps: { step: CascadeStepName; status: string }[],
  step: CascadeStepName,
): string {
  return steps.find((s) => s.step === step)?.status ?? "missing";
}

describe("validateCascade — profil extended-ctc-fr (canal FR)", () => {
  it("exécute XSD + EXTENDED-CTC-FR + BR-FR-Flux2, marque EN16931 N/A", async () => {
    const r = await validateCascade(xml, "extended-ctc-fr");
    expect(r.profile).toBe("extended-ctc-fr");
    expect(r.steps.map((s) => s.step)).toEqual([
      "xsd",
      "schematron-en16931",
      "schematron-extended-ctc-fr",
      "schematron-br-fr-flux2",
    ]);
    // XSD EXTENDED présent au repo → ok.
    expect(stepStatus(r.steps, "xsd")).toBe("ok");
    // EN16931 strict non applicable au canal FR.
    expect(stepStatus(r.steps, "schematron-en16931")).toBe("na");
    // Les 2 Schematrons FR sont réellement exécutés (statut métier ou erreur
    // engine — l'EXTENDED-CTC-FR peut lever une limitation saxon-js HE sur les
    // règles à arithmétique décimale, cf. NOTE-COWORK).
    expect(["ok", "warning", "fatal", "error"]).toContain(
      stepStatus(r.steps, "schematron-extended-ctc-fr"),
    );
    expect(["ok", "warning", "fatal"]).toContain(stepStatus(r.steps, "schematron-br-fr-flux2"));
    expect(typeof r.ok).toBe("boolean");
    expect(typeof r.zeroWarning).toBe("boolean");
    expect(typeof r.engineErrors).toBe("boolean");
  });
});

describe("validateCascade — profil en16931 (canal PEPPOL UE)", () => {
  it("ne déclenche jamais EXTENDED-CTC-FR ni BR-FR-Flux2 (hors canal FR)", async () => {
    const r = await validateCascade(xml, "en16931");
    expect(r.profile).toBe("en16931");
    // Quel que soit le verdict XSD, les Schematrons FR ne sont pas exécutés.
    expect(["na", "skipped"]).toContain(stepStatus(r.steps, "schematron-extended-ctc-fr"));
    expect(["na", "skipped"]).toContain(stepStatus(r.steps, "schematron-br-fr-flux2"));
  });
});
