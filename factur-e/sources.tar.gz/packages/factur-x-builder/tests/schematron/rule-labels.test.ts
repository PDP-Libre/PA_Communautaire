import { describe, expect, it } from "vitest";

import { schematronRuleLabel } from "../../src/schematron/rule-labels.js";

describe("schematronRuleLabel", () => {
  it("retourne le libellé FR override d'une règle connue", () => {
    expect(schematronRuleLabel("BR-CO-15")).toMatch(/total TTC/i);
  });

  it("résout la racine d'un id suffixé (ex. BR-CO-15_BT-112)", () => {
    expect(schematronRuleLabel("BR-CO-15_BT-112")).toBe(schematronRuleLabel("BR-CO-15"));
  });

  it("donne un libellé FR actionnable pour l'identification fiscale vendeur (BR-S-02)", () => {
    for (const id of ["BR-S-02", "BR-Z-02", "BR-E-02", "BR-AE-02"]) {
      const label = schematronRuleLabel(id);
      expect(label).toMatch(/TVA du vendeur/i);
      expect(label).toMatch(/Paramètres > Entreprise/);
    }
  });

  it("couvre les 3 règles PSVI patchées", () => {
    for (const id of ["BR-FREXT-CO-10", "BR-FREXT-CO-11", "BR-FREXT-CO-12"]) {
      expect(schematronRuleLabel(id)).toBeDefined();
    }
  });

  it("retombe sur undefined pour une règle non couverte (fallback svrl:text)", () => {
    expect(schematronRuleLabel("BR-FR-99_BT-1")).toBeUndefined();
  });
});
