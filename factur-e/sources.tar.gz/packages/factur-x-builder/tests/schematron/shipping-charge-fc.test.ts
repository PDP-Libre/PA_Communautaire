import { describe, expect, it } from "vitest";

import type { CrossIndustryInvoice } from "@factur-e/factur-x-model";

import { generateCII } from "../../src/generate-cii.js";
import { validateCascade } from "../../src/schematron/validate-cascade.js";

import { minimalInvoice } from "../integration/fixtures.js";

/**
 * Finding J — la charge frais de port (BG-21, reasonCode UNTDID 7161 "FC")
 * + le rééquilibrage des totaux (BT-108 + base + TVA) ne doivent pas
 * introduire de fatal Schematron FR (BR-CO/BR-S équilibre + code FC accepté).
 *
 * Baseline `minimalInvoice` (HT 100, TVA 20 % → TTC 120) + charge 50 HT à
 * 20 % → HT 100, charge 50, base 150, TVA 30, TTC 180.
 */

const withShippingCharge: CrossIndustryInvoice = {
  ...minimalInvoice,
  tradeTransaction: {
    ...minimalInvoice.tradeTransaction,
    tradeSettlement: {
      ...minimalInvoice.tradeTransaction.tradeSettlement,
      vatBreakdowns: [
        { taxBasisAmount: 150, calculatedAmount: 30, categoryCode: "S", ratePercent: 20 },
      ],
      monetarySummation: {
        lineTotalAmount: 100,
        chargeTotalAmount: 50,
        taxBasisTotalAmount: 150,
        vatTotalAmount: { value: 30, currencyID: "EUR" },
        grandTotalAmount: 180,
        duePayableAmount: 180,
      },
      documentCharges: [
        {
          isCharge: true,
          actualAmount: 50,
          taxCategoryCode: "S",
          taxPercent: 20,
          reason: "Frais de port",
          reasonCode: "FC",
        },
      ],
    },
  },
};

async function fatalSteps(model: CrossIndustryInvoice): Promise<string[]> {
  const res = await validateCascade(generateCII(model), "extended-ctc-fr");
  return res.steps.filter((s) => s.status === "fatal").map((s) => s.step);
}

describe("finding J — charge frais de port BG-21 FC vs Schematron FR", () => {
  it("la charge FC + rééquilibrage n'ajoute aucun fatal vs baseline", async () => {
    const [baseFatals, chargeFatals] = await Promise.all([
      fatalSteps(minimalInvoice),
      fatalSteps(withShippingCharge),
    ]);
    expect(chargeFatals).toEqual(baseFatals);
  });

  it("le XML CII sérialise bien la charge BG-21 (ReasonCode FC + ChargeTotalAmount)", () => {
    const xml = generateCII(withShippingCharge);
    expect(xml).toContain("<ram:ChargeTotalAmount>50.00</ram:ChargeTotalAmount>");
    expect(xml).toContain("<ram:ReasonCode>FC</ram:ReasonCode>");
    expect(xml).toContain("<ram:Reason>Frais de port</ram:Reason>");
  });
});
