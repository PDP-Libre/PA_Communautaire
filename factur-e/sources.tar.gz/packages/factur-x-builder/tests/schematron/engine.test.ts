// Tests engine Schematron saxon-js : cache SEF module-scope + runValidation + reset.

import { describe, expect, it, beforeEach } from "vitest";

import { loadXslt, resetXsltCache, runValidation } from "../../src/schematron/engine.js";
import { SEF_PATHS } from "../../src/schematron/validate-cascade.js";

const MINIMAL_CII = `<?xml version="1.0" encoding="UTF-8"?>
<rsm:CrossIndustryInvoice
  xmlns:rsm="urn:un:unece:uncefact:data:standard:CrossIndustryInvoice:100"
  xmlns:ram="urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:100">
  <rsm:ExchangedDocument><ram:ID>INV-001</ram:ID><ram:TypeCode>380</ram:TypeCode></rsm:ExchangedDocument>
</rsm:CrossIndustryInvoice>`;

describe("engine Schematron saxon-js", () => {
  beforeEach(() => {
    resetXsltCache();
  });

  it("loadXslt met le SEF en cache (même référence au 2e appel)", async () => {
    const a = await loadXslt(SEF_PATHS["br-fr-flux2"]);
    const b = await loadXslt(SEF_PATHS["br-fr-flux2"]);
    expect(a).toBe(b);
  });

  it("resetXsltCache force un re-load (référence différente)", async () => {
    const a = await loadXslt(SEF_PATHS["br-fr-flux2"]);
    resetXsltCache();
    const c = await loadXslt(SEF_PATHS["br-fr-flux2"]);
    expect(a).not.toBe(c);
  });

  it("runValidation produit un document SVRL", async () => {
    const sef = await loadXslt(SEF_PATHS["br-fr-flux2"]);
    const svrl = await runValidation(MINIMAL_CII, sef);
    expect(svrl).toContain("schematron-output");
  });

  it("runValidation rejette un XML malformé", async () => {
    const sef = await loadXslt(SEF_PATHS["br-fr-flux2"]);
    await expect(runValidation("<rsm:CrossIndustryInvoice><unclosed>", sef)).rejects.toBeDefined();
  });
});
