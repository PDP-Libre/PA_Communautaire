// Garde-fou PSVI (docs/standards/s1-validation-emission-schematron.md §5).
//
// Le moteur saxon-js HE n'est pas schema-aware : sans le patch PSVI, les 3 règles
// décimales BR-FREXT-CO-10/11/12 plantent (erreur moteur) à chaque validation
// EXTENDED-CTC-FR. Le patch (scripts/patch-psvi.mjs, appliqué à la compilation des
// SEF) force ces sommes en xs:decimal.
//
// Ce test CASSE LE BUILD si l'erreur moteur réapparaît (engineErrors === true) — par
// ex. SEF régénérés sans le patch, ou nouvelle version FNFE introduisant un cas du
// même type. Le build casse, pas la prod (cf. ADR-009 fail-safe runtime, mais
// garde-fou en amont). Il vérifie aussi que la cascade BLOQUE une facture non
// conforme (verdict métier réellement calculé, pas un plantage masqué).

import { describe, expect, it } from "vitest";

import { generateCII } from "../../src/generate-cii.js";
import { validateCascade } from "../../src/schematron/validate-cascade.js";
import { extendedSampleInvoice } from "../../samples/extended-ctc-fr-sample-001.input.js";
import { minimalInvoice } from "../integration/fixtures.js";

/** Factures de référence conformes (profil canal FR EXTENDED-CTC-FR). */
const REFERENCE_INVOICES = [
  { label: "minimalInvoice", invoice: minimalInvoice },
  { label: "extendedSampleInvoice", invoice: extendedSampleInvoice },
] as const;

describe("garde-fou PSVI — aucune erreur moteur sur les factures de référence", () => {
  for (const { label, invoice } of REFERENCE_INVOICES) {
    it(`${label} : cascade EXTENDED-CTC-FR sans erreur moteur`, async () => {
      const xml = generateCII(invoice);
      const r = await validateCascade(xml, "extended-ctc-fr");

      // Cœur du garde-fou : la limitation PSVI ne doit plus se manifester.
      expect(r.engineErrors).toBe(false);
      // Aucune étape ne doit être en statut `error` (plantage moteur saxon-js).
      const errored = r.steps.filter((s) => s.status === "error");
      expect(errored).toEqual([]);
      // Les Schematrons FR ont produit un verdict métier (ok/warning/fatal), preuve
      // qu'ils se sont réellement exécutés (et non court-circuités par un plantage).
      const extended = r.steps.find((s) => s.step === "schematron-extended-ctc-fr");
      expect(["ok", "warning", "fatal"]).toContain(extended?.status);
    });
  }
});

describe("garde-fou PSVI — la cascade bloque une facture non conforme", () => {
  it("total falsifié (grandTotalAmount) → fatale détectée, sans erreur moteur", async () => {
    const tampered = structuredClone(minimalInvoice);
    // BR-CO-15 : grandTotalAmount = taxBasisTotal + vatTotal (120). On le casse.
    tampered.tradeTransaction.tradeSettlement.monetarySummation.grandTotalAmount = 999;
    tampered.tradeTransaction.tradeSettlement.monetarySummation.duePayableAmount = 999;
    const xml = generateCII(tampered);
    const r = await validateCascade(xml, "extended-ctc-fr");

    expect(r.engineErrors).toBe(false); // verdict calculé, pas un plantage
    expect(r.ok).toBe(false); // au moins une fatale
    const fatals = r.steps.flatMap((s) => s.fatals);
    expect(fatals.length).toBeGreaterThan(0);
  });
});
