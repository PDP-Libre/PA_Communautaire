// Tests parseur SVRL → assertions (failed-assert + successful-report + sévérité @flag).

import { describe, expect, it } from "vitest";

import { fatalAssertions, parseSvrl, warningAssertions } from "../../src/schematron/svrl-parser.js";

const SVRL = `<?xml version="1.0" encoding="UTF-8"?>
<svrl:schematron-output xmlns:svrl="http://purl.oclc.org/dsdl/svrl">
  <svrl:failed-assert test="..." location="/rsm:CrossIndustryInvoice[1]" flag="fatal" id="BR-FR-MV-01">
    <svrl:text>Cotraitance non supportée.</svrl:text>
  </svrl:failed-assert>
  <svrl:successful-report test="..." location="/rsm:CrossIndustryInvoice[1]/rsm:ExchangedDocument[1]" flag="warning" id="BR-FR-05">
    <svrl:text>Note PMT manquante   dans   BG-1.</svrl:text>
  </svrl:successful-report>
</svrl:schematron-output>`;

describe("parseSvrl", () => {
  it("extrait failed-assert + successful-report avec id/flag/location/text", () => {
    const a = parseSvrl(SVRL);
    expect(a).toHaveLength(2);

    const fa = a.find((x) => x.kind === "failed-assert");
    expect(fa?.ruleId).toBe("BR-FR-MV-01");
    expect(fa?.severity).toBe("fatal");
    expect(fa?.xpath).toBe("/rsm:CrossIndustryInvoice[1]");
    expect(fa?.message).toBe("Cotraitance non supportée.");

    const sr = a.find((x) => x.kind === "successful-report");
    expect(sr?.ruleId).toBe("BR-FR-05");
    expect(sr?.severity).toBe("warning");
    // Espaces internes normalisés.
    expect(sr?.message).toBe("Note PMT manquante dans BG-1.");
  });

  it("fatalAssertions / warningAssertions partitionnent par sévérité", () => {
    const a = parseSvrl(SVRL);
    expect(fatalAssertions(a)).toHaveLength(1);
    expect(warningAssertions(a)).toHaveLength(1);
  });

  it("document SVRL vide → aucune assertion", () => {
    const empty = `<svrl:schematron-output xmlns:svrl="http://purl.oclc.org/dsdl/svrl"/>`;
    expect(parseSvrl(empty)).toEqual([]);
  });
});
