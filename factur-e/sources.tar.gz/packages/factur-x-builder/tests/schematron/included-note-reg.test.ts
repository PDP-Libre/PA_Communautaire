import { describe, expect, it } from "vitest";

import type { CrossIndustryInvoice, DocumentNote } from "@factur-e/factur-x-model";

import { generateCII } from "../../src/generate-cii.js";
import { validateCascade } from "../../src/schematron/validate-cascade.js";

import { minimalInvoice } from "../integration/fixtures.js";

/**
 * Finding K2 — footerMentions → BG-1 IncludedNote `subjectCode:REG` (Option B1).
 * Vérifie que la note REG cohabite avec les 3 mentions LME auto (PMT/PMD/AAB)
 * sans violer BR-FR-06 (unicité limitée à PMT/PMD/AAB/TXD — REG libre).
 */

// Les 3 mentions légales LME (BR-FR-05) toujours présentes + notes utilisateur.
const lmeNotes: DocumentNote[] = [
  { content: "Note publique" },
  { content: "Commentaire général" },
  { content: "Indemnité forfaitaire de 40 € pour frais de recouvrement.", subjectCode: "PMT" },
  { content: "Pénalités de retard : 3× le taux d'intérêt légal.", subjectCode: "PMD" },
  { content: "Pas d'escompte pour paiement anticipé.", subjectCode: "AAB" },
];

function withNotes(notes: DocumentNote[]): CrossIndustryInvoice {
  return {
    ...minimalInvoice,
    exchangedDocument: { ...minimalInvoice.exchangedDocument, includedNotes: notes },
  };
}

async function fatals(model: CrossIndustryInvoice): Promise<string[]> {
  const res = await validateCascade(generateCII(model), "extended-ctc-fr");
  return res.steps.filter((s) => s.status === "fatal").map((s) => s.step);
}

describe("finding K2 — footerMentions IncludedNote REG vs Schematron FR", () => {
  it("sérialise la note REG (Content + SubjectCode)", () => {
    const xml = generateCII(
      withNotes([{ content: "Mention légale de pied", subjectCode: "REG" }, ...lmeNotes]),
    );
    expect(xml).toContain("<ram:SubjectCode>REG</ram:SubjectCode>");
    expect(xml).toContain("Mention légale de pied");
  });

  it("la note REG n'ajoute aucun fatal vs le même document sans REG (BR-FR-06 OK)", async () => {
    const [base, withReg] = await Promise.all([
      fatals(withNotes(lmeNotes)),
      fatals(withNotes([{ content: "Mention légale de pied", subjectCode: "REG" }, ...lmeNotes])),
    ]);
    expect(withReg).toEqual(base);
  });
});
