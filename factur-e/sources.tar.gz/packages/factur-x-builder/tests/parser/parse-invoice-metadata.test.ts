import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";

import { describe, expect, it } from "vitest";

import { InvoiceParsingError, parseInvoiceMetadata } from "../../src/index.js";

/**
 * T-CL-RECV-API sprint-05 W2 — Tests parser `parseInvoiceMetadata`.
 *
 * Couvre (≥ 10 cas) :
 *  - Factur-X EXTENDED réel (fixture sprint-01) → tous champs + notes + 3 lignes
 *  - CII pur (profil sans factur-x) → format 'cii'
 *  - UBL Invoice 2.1 → extraction complète
 *  - Edge : XML vide → exception
 *  - Edge : XML malformé → exception
 *  - Edge : racine non reconnue → exception
 *  - Edge : champs optionnels manquants (UBL minimal) → nullable
 *  - Edge : multi-lignes (5 lignes UBL)
 *  - Edge : TVA exonérée (vatRate 0, vatAmount 0)
 *  - Edge : devise non-EUR (USD préservée)
 */

const EXTENDED_FIXTURE = readFileSync(
  fileURLToPath(new URL("../../spikes/xsd/fixtures/extended-reference.xml", import.meta.url)),
  "utf8",
);

interface UblLine {
  id: string;
  name: string;
  qty: number;
  unit: string;
  price: number;
  vat: number;
}

/** Builder UBL 2.1 paramétrique pour les fixtures inline. */
function ublXml(o: {
  number: string;
  issueDate: string;
  dueDate?: string;
  currency: string;
  typeCode?: string;
  sellerSiren: string;
  sellerName: string;
  buyerSiren: string;
  buyerName: string;
  lines: UblLine[];
  iban?: string;
  paymentMeansCode?: string;
  lineExtAmount: string;
  taxAmount: string;
  taxInclAmount: string;
  payableAmount: string;
}): string {
  const lineXml = o.lines
    .map(
      (l) => `
  <cac:InvoiceLine>
    <cbc:ID>${l.id}</cbc:ID>
    <cbc:InvoicedQuantity unitCode="${l.unit}">${String(l.qty)}</cbc:InvoicedQuantity>
    <cac:Item>
      <cbc:Name>${l.name}</cbc:Name>
      <cac:ClassifiedTaxCategory><cbc:Percent>${String(l.vat)}</cbc:Percent></cac:ClassifiedTaxCategory>
    </cac:Item>
    <cac:Price><cbc:PriceAmount currencyID="${o.currency}">${String(l.price)}</cbc:PriceAmount></cac:Price>
  </cac:InvoiceLine>`,
    )
    .join("");
  const dueXml = o.dueDate !== undefined ? `<cbc:DueDate>${o.dueDate}</cbc:DueDate>` : "";
  const meansXml =
    o.iban !== undefined || o.paymentMeansCode !== undefined
      ? `<cac:PaymentMeans>
    <cbc:PaymentMeansCode>${o.paymentMeansCode ?? "30"}</cbc:PaymentMeansCode>
    ${o.iban !== undefined ? `<cac:PayeeFinancialAccount><cbc:ID>${o.iban}</cbc:ID></cac:PayeeFinancialAccount>` : ""}
  </cac:PaymentMeans>`
      : "";
  return `<?xml version="1.0" encoding="UTF-8"?>
<Invoice xmlns="urn:oasis:names:specification:ubl:schema:xsd:Invoice-2"
  xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2"
  xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2">
  <cbc:ID>${o.number}</cbc:ID>
  <cbc:IssueDate>${o.issueDate}</cbc:IssueDate>
  ${dueXml}
  <cbc:InvoiceTypeCode>${o.typeCode ?? "380"}</cbc:InvoiceTypeCode>
  <cbc:DocumentCurrencyCode>${o.currency}</cbc:DocumentCurrencyCode>
  <cac:AccountingSupplierParty><cac:Party>
    <cbc:EndpointID schemeID="0225">0225:${o.sellerSiren}</cbc:EndpointID>
    <cac:PartyLegalEntity>
      <cbc:RegistrationName>${o.sellerName}</cbc:RegistrationName>
      <cbc:CompanyID>${o.sellerSiren}</cbc:CompanyID>
    </cac:PartyLegalEntity>
  </cac:Party></cac:AccountingSupplierParty>
  <cac:AccountingCustomerParty><cac:Party>
    <cac:PartyLegalEntity>
      <cbc:RegistrationName>${o.buyerName}</cbc:RegistrationName>
      <cbc:CompanyID>${o.buyerSiren}</cbc:CompanyID>
    </cac:PartyLegalEntity>
  </cac:Party></cac:AccountingCustomerParty>
  ${meansXml}
  <cac:TaxTotal><cbc:TaxAmount currencyID="${o.currency}">${o.taxAmount}</cbc:TaxAmount></cac:TaxTotal>
  <cac:LegalMonetaryTotal>
    <cbc:LineExtensionAmount currencyID="${o.currency}">${o.lineExtAmount}</cbc:LineExtensionAmount>
    <cbc:TaxInclusiveAmount currencyID="${o.currency}">${o.taxInclAmount}</cbc:TaxInclusiveAmount>
    <cbc:PayableAmount currencyID="${o.currency}">${o.payableAmount}</cbc:PayableAmount>
  </cac:LegalMonetaryTotal>
  ${lineXml}
</Invoice>`;
}

const ublBase = {
  number: "UBL-2026-001",
  issueDate: "2026-05-18",
  dueDate: "2026-06-17",
  currency: "EUR",
  sellerSiren: "552100554",
  sellerName: "Tricatel SAS",
  buyerSiren: "315143296",
  buyerName: "Burger Queen",
  iban: "FR7630006000011234567890189",
  lines: [{ id: "1", name: "Prestation conseil", qty: 2, unit: "C62", price: 500, vat: 20 }],
  lineExtAmount: "1000.00",
  taxAmount: "200.00",
  taxInclAmount: "1200.00",
  payableAmount: "1200.00",
};

describe("parseInvoiceMetadata (T-CL-RECV-API sprint-05 W2)", () => {
  it("Factur-X EXTENDED réel → tous champs + notes + 3 lignes", () => {
    const meta = parseInvoiceMetadata(EXTENDED_FIXTURE);

    expect(meta.format).toBe("facturx");
    expect(meta.document.invoiceNumber).toBe("F20220023");
    expect(meta.document.documentType).toBe("380");
    expect(meta.document.issueDate).toBe("2022-01-31");
    expect(meta.document.currency).toBe("EUR");

    expect(meta.parties.seller.name).toBe("LE FOURNISSEUR");
    expect(meta.parties.seller.siren).toBe("123456782");

    expect(meta.lines).toHaveLength(3);
    const vatRates = meta.lines.map((l) => l.vatRate);
    expect(vatRates).toEqual(expect.arrayContaining([0, 10, 20]));

    // Totaux en cents : LineTotal 95.00 / TVA 4.90 / TTC 104.90.
    expect(meta.totals.subtotalHt).toBe(9500);
    expect(meta.totals.vatAmount).toBe(490);
    expect(meta.totals.totalTtc).toBe(10490);
    expect(meta.totals.balanceDue).toBe(10490);

    // Notes document-level (REG/ABL/AAI/PMD/PMT/AAB).
    expect(meta.paymentTerms?.notes).toBeDefined();
    expect(meta.paymentTerms?.notes?.some((n) => n.subjectCode === "REG")).toBe(true);
  });

  it("CII pur (profil sans factur-x) → format 'cii'", () => {
    const ciiPur = EXTENDED_FIXTURE.replace(
      "urn:cen.eu:en16931:2017#conformant#urn:factur-x.eu:1p0:extended",
      "urn:cen.eu:en16931:2017",
    );
    const meta = parseInvoiceMetadata(ciiPur);
    expect(meta.format).toBe("cii");
    expect(meta.document.invoiceNumber).toBe("F20220023");
  });

  it("UBL Invoice 2.1 → extraction complète", () => {
    const meta = parseInvoiceMetadata(ublXml(ublBase));

    expect(meta.format).toBe("ubl");
    expect(meta.document.invoiceNumber).toBe("UBL-2026-001");
    expect(meta.document.issueDate).toBe("2026-05-18");
    expect(meta.document.dueDate).toBe("2026-06-17");
    expect(meta.document.currency).toBe("EUR");
    expect(meta.parties.seller.siren).toBe("552100554");
    expect(meta.parties.seller.name).toBe("Tricatel SAS");
    expect(meta.parties.buyer.siren).toBe("315143296");
    expect(meta.lines).toHaveLength(1);
    expect(meta.lines[0]?.unitCode).toBe("C62");
    expect(meta.lines[0]?.priceHt).toBe(50000); // 500.00 € → cents
    expect(meta.lines[0]?.vatRate).toBe(20);
    expect(meta.totals.subtotalHt).toBe(100000);
    expect(meta.totals.vatAmount).toBe(20000);
    expect(meta.totals.totalTtc).toBe(120000);
    expect(meta.paymentTerms?.iban).toBe("FR7630006000011234567890189");
  });

  it("Edge — XML vide → InvoiceParsingError", () => {
    expect(() => parseInvoiceMetadata("")).toThrow(InvoiceParsingError);
    expect(() => parseInvoiceMetadata("   ")).toThrow(InvoiceParsingError);
  });

  it("Edge — XML malformé → InvoiceParsingError", () => {
    expect(() => parseInvoiceMetadata("<Invoice><unclosed>")).toThrow(InvoiceParsingError);
  });

  it("Edge — racine non reconnue → InvoiceParsingError", () => {
    expect(() => parseInvoiceMetadata('<?xml version="1.0"?><Foo>bar</Foo>')).toThrow(
      InvoiceParsingError,
    );
  });

  it("Edge — champs optionnels manquants (UBL minimal) → nullable", () => {
    const minimal = ublXml({
      ...ublBase,
      dueDate: undefined,
      iban: undefined,
      paymentMeansCode: undefined,
    });
    const meta = parseInvoiceMetadata(minimal);
    expect(meta.document.dueDate).toBeUndefined();
    expect(meta.paymentTerms).toBeUndefined();
    expect(meta.document.invoiceNumber).toBe("UBL-2026-001");
  });

  it("Edge — multi-lignes (5 lignes UBL)", () => {
    const lines: UblLine[] = Array.from({ length: 5 }, (_, i) => ({
      id: String(i + 1),
      name: `Ligne ${String(i + 1)}`,
      qty: i + 1,
      unit: "C62",
      price: 100,
      vat: 20,
    }));
    const meta = parseInvoiceMetadata(ublXml({ ...ublBase, lines }));
    expect(meta.lines).toHaveLength(5);
    expect(meta.lines[4]?.id).toBe("5");
  });

  it("Edge — TVA exonérée (vatRate 0, vatAmount 0)", () => {
    const exempt = ublXml({
      ...ublBase,
      lines: [{ id: "1", name: "Service exonéré", qty: 1, unit: "C62", price: 1000, vat: 0 }],
      taxAmount: "0.00",
      taxInclAmount: "1000.00",
      payableAmount: "1000.00",
    });
    const meta = parseInvoiceMetadata(exempt);
    expect(meta.lines[0]?.vatRate).toBe(0);
    expect(meta.totals.vatAmount).toBe(0);
    expect(meta.totals.totalTtc).toBe(100000);
  });

  it("Edge — devise non-EUR (USD préservée)", () => {
    const usd = ublXml({ ...ublBase, currency: "USD" });
    const meta = parseInvoiceMetadata(usd);
    expect(meta.document.currency).toBe("USD");
  });
});
