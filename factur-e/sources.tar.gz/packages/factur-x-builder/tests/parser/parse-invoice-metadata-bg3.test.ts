import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";

import { describe, expect, it } from "vitest";

import { parseInvoiceMetadata } from "../../src/index.js";

/**
 * T-CL-CREDIT-NOTES sprint-06 — extraction BG-3 `precedingInvoiceReference`
 * (BR-55) sur avoirs (381) / rectificatives (384), CII + UBL, + non-régression
 * facture standard 380 (pas de BG-3).
 */

const EXTENDED_FIXTURE = readFileSync(
  fileURLToPath(new URL("../../spikes/xsd/fixtures/extended-reference.xml", import.meta.url)),
  "utf8",
);

/** CII minimal paramétrique avec InvoiceReferencedDocument (BG-3) optionnel. */
function ciiXml(o: {
  number: string;
  typeCode: string;
  issueDate: string; // YYYYMMDD
  preceding?: { number: string; issueDate?: string }; // issueDate YYYYMMDD
}): string {
  const bg3 =
    o.preceding !== undefined
      ? `<ram:InvoiceReferencedDocument>
            <ram:IssuerAssignedID>${o.preceding.number}</ram:IssuerAssignedID>
            ${
              o.preceding.issueDate !== undefined
                ? `<ram:FormattedIssueDateTime><qdt:DateTimeString format="102">${o.preceding.issueDate}</qdt:DateTimeString></ram:FormattedIssueDateTime>`
                : ""
            }
          </ram:InvoiceReferencedDocument>`
      : "";
  return `<?xml version="1.0" encoding="UTF-8"?>
<rsm:CrossIndustryInvoice
  xmlns:rsm="urn:un:unece:uncefact:data:standard:CrossIndustryInvoice:100"
  xmlns:ram="urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:100"
  xmlns:udt="urn:un:unece:uncefact:data:standard:UnqualifiedDataType:100"
  xmlns:qdt="urn:un:unece:uncefact:data:standard:QualifiedDataType:100">
  <rsm:ExchangedDocument>
    <ram:ID>${o.number}</ram:ID>
    <ram:TypeCode>${o.typeCode}</ram:TypeCode>
    <ram:IssueDateTime><udt:DateTimeString format="102">${o.issueDate}</udt:DateTimeString></ram:IssueDateTime>
  </rsm:ExchangedDocument>
  <rsm:SupplyChainTradeTransaction>
    <ram:ApplicableHeaderTradeSettlement>
      <ram:InvoiceCurrencyCode>EUR</ram:InvoiceCurrencyCode>
      ${bg3}
    </ram:ApplicableHeaderTradeSettlement>
  </rsm:SupplyChainTradeTransaction>
</rsm:CrossIndustryInvoice>`;
}

/** UBL minimal avec cac:BillingReference (BG-3) optionnel. */
function ublAvoirXml(o: {
  number: string;
  typeCode: string;
  preceding?: { number: string; issueDate?: string };
}): string {
  const bg3 =
    o.preceding !== undefined
      ? `<cac:BillingReference><cac:InvoiceDocumentReference>
          <cbc:ID>${o.preceding.number}</cbc:ID>
          ${o.preceding.issueDate !== undefined ? `<cbc:IssueDate>${o.preceding.issueDate}</cbc:IssueDate>` : ""}
        </cac:InvoiceDocumentReference></cac:BillingReference>`
      : "";
  return `<?xml version="1.0" encoding="UTF-8"?>
<Invoice xmlns="urn:oasis:names:specification:ubl:schema:xsd:Invoice-2"
  xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2"
  xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2">
  <cbc:ID>${o.number}</cbc:ID>
  <cbc:IssueDate>2026-05-20</cbc:IssueDate>
  <cbc:InvoiceTypeCode>${o.typeCode}</cbc:InvoiceTypeCode>
  <cbc:DocumentCurrencyCode>EUR</cbc:DocumentCurrencyCode>
  ${bg3}
</Invoice>`;
}

describe("parseInvoiceMetadata — BG-3 precedingInvoiceReference (L11)", () => {
  it("CII avoir 381 → documentType 381 + BG-3 (BT-25 + BT-26)", () => {
    const meta = parseInvoiceMetadata(
      ciiXml({
        number: "AV-2026-001",
        typeCode: "381",
        issueDate: "20260201",
        preceding: { number: "F-2026-0042", issueDate: "20260115" },
      }),
    );
    expect(meta.document.documentType).toBe("381");
    expect(meta.document.precedingInvoiceReference).toEqual({
      invoiceNumber: "F-2026-0042",
      issueDate: "2026-01-15",
    });
  });

  it("CII rectificative 384 → documentType 384 + BG-3 (BT-25 sans BT-26)", () => {
    const meta = parseInvoiceMetadata(
      ciiXml({
        number: "R-2026-001",
        typeCode: "384",
        issueDate: "20260202",
        preceding: { number: "F-2026-0099" },
      }),
    );
    expect(meta.document.documentType).toBe("384");
    expect(meta.document.precedingInvoiceReference).toEqual({ invoiceNumber: "F-2026-0099" });
  });

  it("UBL avoir 381 → BG-3 via BillingReference", () => {
    const meta = parseInvoiceMetadata(
      ublAvoirXml({
        number: "AV-UBL-001",
        typeCode: "381",
        preceding: { number: "FA-2026-7", issueDate: "2026-03-10" },
      }),
    );
    expect(meta.format).toBe("ubl");
    expect(meta.document.documentType).toBe("381");
    expect(meta.document.precedingInvoiceReference).toEqual({
      invoiceNumber: "FA-2026-7",
      issueDate: "2026-03-10",
    });
  });

  it("CII facture standard 380 sans BG-3 → precedingInvoiceReference absent (non-régression)", () => {
    const meta = parseInvoiceMetadata(
      ciiXml({ number: "F-2026-0042", typeCode: "380", issueDate: "20260115" }),
    );
    expect(meta.document.documentType).toBe("380");
    expect(meta.document.precedingInvoiceReference).toBeUndefined();
  });

  it("Fixture EXTENDED réelle → extraction BG-3 robuste (InvoiceReferencedDocument présent)", () => {
    // L'échantillon EXTENDED de référence porte un BG-3 (BT-25 F20220003 +
    // BT-26 2022-01-01) — confirme l'extraction sur un XML réel, pas seulement
    // synthétique.
    const meta = parseInvoiceMetadata(EXTENDED_FIXTURE);
    expect(meta.document.documentType).toBe("380");
    expect(meta.document.precedingInvoiceReference).toEqual({
      invoiceNumber: "F20220003",
      issueDate: "2022-01-01",
    });
  });
});
