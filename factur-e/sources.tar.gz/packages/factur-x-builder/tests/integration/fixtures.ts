// Fixtures partagées par les tests d'intégration de la sérialisation CII.
// Volontairement isolées de `@factur-e/factur-x-model/tests/fixtures` pour
// garder ce package autonome.

import type { CrossIndustryInvoice } from "@factur-e/factur-x-model";
import {
  FACTUR_X_PROFILES,
  INVOICE_TYPE_CODES,
  PAYMENT_MEANS_CODES,
  SCHEME_IDS,
  UNIT_CODES,
  VAT_CATEGORY_CODES,
} from "@factur-e/factur-x-model";

/** Facture minimale FR → FR : 1 ligne, TVA 20 %, virement IBAN. */
export const minimalInvoice: CrossIndustryInvoice = {
  documentContext: {
    specificationID: { value: FACTUR_X_PROFILES.EXTENDED },
  },
  exchangedDocument: {
    invoiceNumber: "FA-2026-001",
    invoiceTypeCode: INVOICE_TYPE_CODES.COMMERCIAL,
    issueDate: { value: "20260415", format: "102" },
  },
  tradeTransaction: {
    lineItems: [
      {
        lineID: "1",
        product: { name: "Prestation de conseil" },
        tradeAgreement: { netPrice: 100 },
        tradeDelivery: {
          billedQuantity: 1,
          unitCode: UNIT_CODES.PIECE,
        },
        tradeSettlement: {
          vatInformation: {
            categoryCode: VAT_CATEGORY_CODES.STANDARD,
            ratePercent: 20,
          },
          netLineAmount: 100,
        },
      },
    ],
    tradeAgreement: {
      sellerTradeParty: {
        name: "Mon Entreprise SAS",
        postalAddress: {
          countryCode: "FR",
          postalCode: "75001",
          cityName: "Paris",
          lineOne: "1 rue de Rivoli",
        },
        legalRegistrationID: {
          value: "123456789",
          schemeID: SCHEME_IDS.SIREN_SIRET,
        },
        vatID: { value: "FR12123456789", schemeID: SCHEME_IDS.VAT },
      },
      buyerTradeParty: {
        name: "Client SARL",
        postalAddress: { countryCode: "FR", cityName: "Lyon" },
      },
    },
    tradeDelivery: {},
    tradeSettlement: {
      invoiceCurrencyCode: "EUR",
      vatBreakdowns: [
        {
          taxBasisAmount: 100,
          calculatedAmount: 20,
          categoryCode: VAT_CATEGORY_CODES.STANDARD,
          ratePercent: 20,
        },
      ],
      monetarySummation: {
        lineTotalAmount: 100,
        taxBasisTotalAmount: 100,
        vatTotalAmount: { value: 20, currencyID: "EUR" },
        grandTotalAmount: 120,
        duePayableAmount: 120,
      },
      paymentTermsDescription: "À 30 jours",
      paymentMeans: [
        {
          typeCode: PAYMENT_MEANS_CODES.CREDIT_TRANSFER,
          payeeFinancialAccounts: [
            {
              accountID: {
                value: "FR7630006000011234567890189",
                schemeID: "IBAN",
              },
            },
          ],
        },
      ],
    },
  },
};
