// Test d'intégration profils émission V2 `validateXsd(xml, profile?)` —
// sprint-06 T-CL-FACTURX-BUILDER-REFACTOR-CTC-FR (ADR-016 candidat D1).
// Vérifie :
//   1. Alias `validateExtendedXsd(xml)` rétro-compatible sprint-01 (→ extended-ctc-fr).
//   2. `validateXsd(xml, "extended-ctc-fr")` retourne `ok({ skipped: false })`
//      sur XML conforme (XSD EXTENDED 1.07.3 présent depuis sprint-01).
//   3. `validateXsd(xml, "en16931")` charge le XSD EN16931 1.08 (Q1) — pas de
//      skip ; ok ou err selon cardinalités, mais XSD résolu.
//   4. Profil par défaut = `extended-ctc-fr`.
//   5. Cache par profil cohérent (resetSchemaCache).

import { describe, expect, it, beforeEach } from "vitest";

import { generateCII } from "../../src/generate-cii.js";
import { resetSchemaCache, validateExtendedXsd, validateXsd } from "../../src/validate-xsd.js";

import { minimalInvoice } from "./fixtures.js";

describe("validateXsd — profils émission V2 (en16931 + extended-ctc-fr)", () => {
  beforeEach(() => {
    resetSchemaCache();
  });

  it("alias validateExtendedXsd préservé rétro-compat (Result<true, ValidationError>)", async () => {
    const xml = generateCII(minimalInvoice);
    const r = await validateExtendedXsd(xml);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    // L'alias historique retourne `true` (pas l'objet structuré).
    expect(r.value).toBe(true);
  });

  it("validateXsd(xml, 'extended-ctc-fr') retourne ok({skipped:false}) sur XML conforme", async () => {
    const xml = generateCII(minimalInvoice);
    const r = await validateXsd(xml, "extended-ctc-fr");
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.value.profile).toBe("extended-ctc-fr");
    expect(r.value.skipped).toBe(false);
  });

  it("validateXsd(xml, 'en16931') charge le XSD EN16931 1.08 — pas de skip", async () => {
    const xml = generateCII(minimalInvoice);
    const r = await validateXsd(xml, "en16931");
    // Le XSD EN16931 1.08 est présent au repo (Q1) : pas de skip gracieux.
    // L'XML EXTENDED peut contenir des éléments hors-EN16931 → err possible,
    // ce qui prouve tout autant que le XSD a bien été résolu et appliqué.
    if (r.ok) {
      expect(r.value.profile).toBe("en16931");
      expect(r.value.skipped).toBe(false);
    } else {
      expect(r.errors.length).toBeGreaterThan(0);
    }
  });

  it("validateXsd profil par défaut = extended-ctc-fr", async () => {
    const xml = generateCII(minimalInvoice);
    const r = await validateXsd(xml);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.value.profile).toBe("extended-ctc-fr");
  });

  it("resetSchemaCache() force re-load du schéma au prochain appel", async () => {
    const xml = generateCII(minimalInvoice);
    const r1 = await validateXsd(xml, "extended-ctc-fr");
    expect(r1.ok).toBe(true);
    resetSchemaCache();
    const r2 = await validateXsd(xml, "extended-ctc-fr");
    expect(r2.ok).toBe(true);
  });
});
