// Test d'intégration moteur de template PDF (Axe B sprint-07 V2) — pipeline
// complet CII → Nunjucks → HTML → blocs → pdf-lib PDF/A-3b, sur les 3 types de
// document (380 / 381 / 384). Vérifie la PRÉSERVATION inconditionnelle :
//   - checks structurels Factur-X (subset veraPDF — ADR-004) ;
//   - XMP fx: + factur-x.xml embarqué (XML CII round-trip byte-identique) ;
// et la pagination multi-page sur une facture longue.

import { PDFDocument } from "pdf-lib";
import { describe, expect, it } from "vitest";

import { NOTE_SUBJECT_CODES, type CrossIndustryInvoice } from "@factur-e/factur-x-model";
import {
  extractEmbeddedXml,
  generateCII,
  renderInvoicePdfFromModel,
  structuralChecks,
  validateExtendedXsd,
  type PdfEnrichment,
} from "../../src/index.js";

import { extendedSampleInvoice } from "../../samples/extended-ctc-fr-sample-001.input.js";
import { creditNote381Sample } from "../../samples/credit-note-381-sample-001.input.js";
import { corrective384Sample } from "../../samples/corrective-384-sample-001.input.js";

const GEN_DATE = new Date("2026-04-15T10:00:00Z");

async function renderAndCheck(
  invoice: CrossIndustryInvoice,
  enrichment?: PdfEnrichment,
): Promise<{ pdf: Uint8Array; xml: string }> {
  const xml = generateCII(invoice);
  const xsd = await validateExtendedXsd(xml);
  if (!xsd.ok) {
    const summary = xsd.errors
      .slice(0, 5)
      .map((e) => `  L${String(e.line)} — ${e.message.trim()}`)
      .join("\n");
    throw new Error(`XML CII invalide vs XSD EXTENDED :\n${summary}`);
  }
  const pdf = await renderInvoicePdfFromModel({
    invoice,
    xmlBytes: new TextEncoder().encode(xml),
    conformanceLevel: "EXTENDED",
    generationDate: GEN_DATE,
    enrichment,
  });
  return { pdf, xml };
}

function expectStructuralOk(pdf: Uint8Array): void {
  const failed = structuralChecks(pdf).filter((c) => !c.ok);
  if (failed.length > 0) {
    throw new Error(
      `Checks structurels échoués :\n${failed.map((c) => `  ✗ ${c.name}`).join("\n")}`,
    );
  }
  expect(failed).toHaveLength(0);
}

describe("renderInvoicePdfFromModel — pipeline complet par type de document", () => {
  it("380 facture standard — structural OK + XML round-trip + capital social", async () => {
    const { pdf, xml } = await renderAndCheck(extendedSampleInvoice, {
      seller: {
        rcs: "Paris B 000 000 002",
        juridiqueLabel: "Société par actions simplifiée (SAS)",
        capitalSocial: "50000.00",
      },
    });
    expectStructuralOk(pdf);
    expect(await extractEmbeddedXml(pdf)).toBe(xml);
    const raw = Buffer.from(pdf).toString("latin1");
    expect(raw).toContain("urn:factur-x:pdfa:CrossIndustryDocument:invoice:1p0#");
    expect(raw).toContain("factur-x.xml");
  });

  it("381 avoir — template credit-note rendu, structural OK + round-trip", async () => {
    const { pdf, xml } = await renderAndCheck(creditNote381Sample);
    expectStructuralOk(pdf);
    expect(await extractEmbeddedXml(pdf)).toBe(xml);
  });

  it("384 rectificative — template corrective rendu, structural OK + round-trip", async () => {
    const { pdf, xml } = await renderAndCheck(corrective384Sample);
    expectStructuralOk(pdf);
    expect(await extractEmbeddedXml(pdf)).toBe(xml);
  });

  it("section INCOTERM (post-fix K1) — structural préservé", async () => {
    const { pdf } = await renderAndCheck(extendedSampleInvoice, { incoterm: "DAP" });
    expectStructuralOk(pdf);
  });

  it("facture longue (50 lignes) → multi-page + structural préservé", async () => {
    const many: CrossIndustryInvoice = {
      ...extendedSampleInvoice,
      tradeTransaction: {
        ...extendedSampleInvoice.tradeTransaction,
        lineItems: Array.from({ length: 50 }, (_, i) => ({
          lineID: String(i + 1),
          product: { name: `Prestation ${String(i + 1)}`, countryOfOriginCode: "FR" },
          tradeAgreement: { netPrice: 100 },
          tradeDelivery: { billedQuantity: 1, unitCode: "C62" },
          tradeSettlement: {
            vatInformation: { categoryCode: "S", ratePercent: 20 },
            netLineAmount: 100,
          },
        })),
      },
    };
    // generateCII recalculerait les totaux côté amont en prod ; ici on rend le
    // PDF directement (le XML embarqué reste celui du sample original valide).
    const xml = generateCII(extendedSampleInvoice);
    const pdf = await renderInvoicePdfFromModel({
      invoice: many,
      xmlBytes: new TextEncoder().encode(xml),
      conformanceLevel: "EXTENDED",
      generationDate: GEN_DATE,
    });
    expectStructuralOk(pdf);
    const doc = await PDFDocument.load(pdf);
    expect(doc.getPageCount()).toBeGreaterThan(1);
  });

  // F2 + ZG-4 — une mention LME longue (wrap multi-ligne) combinée à un tableau
  // qui remplit la page : le wrap doit franchir une frontière de page sans
  // déborder ni casser le PDF/A (hauteurs paginées = avance dessinée).
  it("F2/ZG-4 : mention LME longue wrappée traversant une frontière de page", async () => {
    const longPmd =
      "Pénalités de retard : " +
      "trois fois le taux d'intérêt légal en vigueur exigibles sans rappel ".repeat(6) +
      "conformément aux articles L.441-10 et D.441-5 du Code de commerce.";
    const inv: CrossIndustryInvoice = {
      ...extendedSampleInvoice,
      exchangedDocument: {
        ...extendedSampleInvoice.exchangedDocument,
        includedNotes: [{ content: longPmd, subjectCode: NOTE_SUBJECT_CODES.PAYMENT_MEANS_NOTE }],
      },
      tradeTransaction: {
        ...extendedSampleInvoice.tradeTransaction,
        lineItems: Array.from({ length: 36 }, (_, i) => ({
          lineID: String(i + 1),
          product: { name: `Prestation ${String(i + 1)}`, countryOfOriginCode: "FR" },
          tradeAgreement: { netPrice: 100 },
          tradeDelivery: { billedQuantity: 1, unitCode: "C62" },
          tradeSettlement: {
            vatInformation: { categoryCode: "S", ratePercent: 20 },
            netLineAmount: 100,
          },
        })),
      },
    };
    const xml = generateCII(extendedSampleInvoice); // XML embarqué = sample valide
    const pdf = await renderInvoicePdfFromModel({
      invoice: inv,
      xmlBytes: new TextEncoder().encode(xml),
      conformanceLevel: "EXTENDED",
      generationDate: GEN_DATE,
    });
    expectStructuralOk(pdf);
    const doc = await PDFDocument.load(pdf);
    expect(doc.getPageCount()).toBeGreaterThan(1);
  });
});
