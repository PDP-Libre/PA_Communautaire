// Test d'intégration : `generateCII(invoice)` → validation contre XSD EXTENDED.
// Ce test croise le sérialiseur (T-CL-02) et le validateur XSD (promu de T-CL-05) :
// si le XML produit passe `validateExtendedXsd`, c'est la preuve que les
// 36 bugs §9.4 sont bien adressés au moins au niveau XSD (les Schematron
// restent à couvrir séparément).

import { describe, expect, it } from "vitest";

import { generateCII } from "../../src/generate-cii.js";
import { validateExtendedXsd } from "../../src/validate-xsd.js";

import { minimalInvoice } from "./fixtures.js";

describe("generateCII × validateExtendedXsd — fixture minimale", () => {
  it("produit un XML CII conforme à la XSD EXTENDED", async () => {
    const xml = generateCII(minimalInvoice);

    // Sanity checks structurels avant XSD pour diagnostic rapide en cas d'échec.
    expect(xml.startsWith('<?xml version="1.0" encoding="UTF-8"?>')).toBe(true);
    expect(xml).toContain("<rsm:CrossIndustryInvoice");
    expect(xml).toContain("xmlns:ram=");
    expect(xml).toContain("xmlns:rsm=");
    expect(xml).toContain("<ram:ID>FA-2026-001</ram:ID>");

    const result = await validateExtendedXsd(xml);
    if (!result.ok) {
      // Diagnostic verbeux : remonte les 5 premières erreurs avec ligne/message.
      const summary = result.errors
        .slice(0, 5)
        .map((e) => `  L${String(e.line)} C${String(e.column)} — ${e.message.trim()}`)
        .join("\n");
      throw new Error(
        `XML CII non valide vs XSD EXTENDED (${String(result.errors.length)} erreurs) :\n${summary}\n\n--- Début du XML produit ---\n${xml.slice(0, 800)}`,
      );
    }
    expect(result.value).toBe(true);
  });

  it("la sortie est byte-identique entre deux runs (déterminisme ADR-003)", () => {
    const a = generateCII(minimalInvoice);
    const b = generateCII(minimalInvoice);
    expect(b).toBe(a);
  });
});
