// Test bout-en-bout du pipeline Factur-X (T-CL-07).
//
// Vérifie le contrat complet du builder à partir d'un Document EXTENDED
// instancié en mémoire :
//   1. Sérialisation CII (`generateCII`).
//   2. Validation XSD EXTENDED (`validateExtendedXsd`).
//   3. Assemblage PDF/A-3b (`assembleFacturXPdfA3`).
//   4. Re-extraction du XML depuis le PDF (`extractEmbeddedXml`).
//   5. Re-validation XSD sur le XML extrait (round-trip byte-identique).
//   6. Checks structurels Factur-X (XMP fx:, AF, EmbeddedFiles, etc.).
//
// Pas d'appel CLI ni de spawn — entièrement in-process pour la CI.

import { describe, expect, it } from "vitest";

import {
  assembleFacturXPdfA3,
  extractEmbeddedXml,
  generateCII,
  structuralChecks,
  validateExtendedXsd,
} from "../../src/index.js";

import { extendedSampleInvoice } from "../../samples/extended-ctc-fr-sample-001.input.js";

const GENERATION_DATE = new Date("2026-04-15T10:00:00Z");

describe("E2E pipeline Factur-X EXTENDED — fixture sample", () => {
  it("CII → XSD → PDF/A-3 → re-extract → XSD passe en bout-en-bout", async () => {
    // 1. Sérialisation CII.
    const xml = generateCII(extendedSampleInvoice);
    expect(xml.startsWith('<?xml version="1.0" encoding="UTF-8"?>')).toBe(true);
    expect(xml).toContain("<ram:ID>FA-2026-EXT-001</ram:ID>");

    // 2. Validation XSD EXTENDED (fail-fast diagnostic).
    const xsdIn = await validateExtendedXsd(xml);
    if (!xsdIn.ok) {
      const summary = xsdIn.errors
        .slice(0, 5)
        .map((e) => `  L${String(e.line)} C${String(e.column)} — ${e.message.trim()}`)
        .join("\n");
      throw new Error(`XML CII invalide vs XSD EXTENDED :\n${summary}`);
    }

    // 3. Assemblage PDF/A-3b (date figée pour reproductibilité).
    const xmlBytes = new TextEncoder().encode(xml);
    const pdfBytes = await assembleFacturXPdfA3({
      xmlBytes,
      metadata: {
        invoiceNumber: extendedSampleInvoice.exchangedDocument.invoiceNumber,
        sellerName: extendedSampleInvoice.tradeTransaction.tradeAgreement.sellerTradeParty.name,
      },
      conformanceLevel: "EXTENDED",
      generationDate: GENERATION_DATE,
    });
    expect(pdfBytes.byteLength).toBeGreaterThan(10_000);

    // 4. Re-extraction du XML depuis le PDF.
    const extracted = await extractEmbeddedXml(pdfBytes);
    expect(extracted).not.toBeNull();
    // Round-trip byte-identique : ce qui sort du PDF doit être ce qu'on a injecté.
    expect(extracted).toBe(xml);

    // 5. Re-validation XSD sur le XML extrait.
    const xsdOut = await validateExtendedXsd(extracted ?? "");
    if (!xsdOut.ok) {
      const summary = xsdOut.errors
        .slice(0, 5)
        .map((e) => `  L${String(e.line)} C${String(e.column)} — ${e.message.trim()}`)
        .join("\n");
      throw new Error(`XML extrait invalide vs XSD EXTENDED :\n${summary}`);
    }

    // 6. Checks structurels Factur-X (subset des règles veraPDF).
    const checks = structuralChecks(pdfBytes);
    const failed = checks.filter((c) => !c.ok);
    if (failed.length > 0) {
      const detail = failed
        .map((c) => `  ✗ ${c.name}${c.details === undefined ? "" : ` — ${c.details}`}`)
        .join("\n");
      throw new Error(`Checks structurels échoués :\n${detail}`);
    }
    expect(failed).toHaveLength(0);
  });

  it("le PDF déclare bien Factur-X EXTENDED dans le XMP et porte factur-x.xml en pièce jointe", async () => {
    const xml = generateCII(extendedSampleInvoice);
    const pdfBytes = await assembleFacturXPdfA3({
      xmlBytes: new TextEncoder().encode(xml),
      metadata: {
        invoiceNumber: extendedSampleInvoice.exchangedDocument.invoiceNumber,
        sellerName: extendedSampleInvoice.tradeTransaction.tradeAgreement.sellerTradeParty.name,
      },
      conformanceLevel: "EXTENDED",
      generationDate: GENERATION_DATE,
    });

    const raw = Buffer.from(pdfBytes).toString("latin1");
    expect(raw).toContain("urn:factur-x:pdfa:CrossIndustryDocument:invoice:1p0#");
    expect(raw).toContain(">INVOICE<");
    expect(raw).toContain(">EXTENDED<");
    expect(raw).toContain("factur-x.xml");
  });
});
