import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";

import { describe, expect, it } from "vitest";

import { renderPdfFromXml } from "../src/pdf-render-from-xml.js";

/**
 * T-CL-RECV-READABLE-VIEW-CONVERSION sprint-07 (Axe B) — rendu PDF lisible
 * réduit depuis le XML d'une facture reçue. Z8 : PDF lisible reconstitué (PAS
 * PDF/A-3b + XML embarqué), veraPDF non applicable. On vérifie un PDF valide
 * (magic `%PDF-`) + la dégradation propre sur XML illisible.
 */

const EXTENDED_FIXTURE = readFileSync(
  fileURLToPath(new URL("../spikes/xsd/fixtures/extended-reference.xml", import.meta.url)),
  "utf8",
);

describe("renderPdfFromXml — readable-view maison réduit", () => {
  it("rend un PDF valide depuis un XML CII réel", async () => {
    const pdf = await renderPdfFromXml(EXTENDED_FIXTURE);
    expect(pdf.length).toBeGreaterThan(500);
    expect(pdf.subarray(0, 5).toString("latin1")).toBe("%PDF-");
  });

  it("lève sur XML illisible (l'appelant retombe sur le 415)", async () => {
    await expect(renderPdfFromXml("<not-an-invoice/>")).rejects.toThrow();
  });
});
