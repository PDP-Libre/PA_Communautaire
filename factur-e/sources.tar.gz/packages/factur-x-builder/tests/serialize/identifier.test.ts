import { describe, expect, it } from "vitest";

import { renderElement } from "../../src/xml/index.js";
import {
  serializeEmailIdentifier,
  serializeIdentifier,
  serializeVatIdentifier,
} from "../../src/serialize/identifier.js";

describe("serializeIdentifier", () => {
  it("rend `<ram:ID>VALUE</ram:ID>` sans schemeID", () => {
    expect(renderElement(serializeIdentifier("ID", { value: "FA-001" }))).toBe(
      "<ram:ID>FA-001</ram:ID>",
    );
  });

  it('rend `<ram:ID schemeID="…">VALUE</ram:ID>` avec schemeID', () => {
    expect(renderElement(serializeIdentifier("ID", { value: "123", schemeID: "0002" }))).toBe(
      `<ram:ID schemeID="0002">123</ram:ID>`,
    );
  });
});

describe('serializeVatIdentifier — force schemeID="VA" (BR-CO-9)', () => {
  it("force VA si schemeID absent", () => {
    expect(renderElement(serializeVatIdentifier("ID", { value: "FR12" }))).toBe(
      `<ram:ID schemeID="VA">FR12</ram:ID>`,
    );
  });

  it("préserve un schemeID déjà fourni", () => {
    expect(renderElement(serializeVatIdentifier("ID", { value: "X", schemeID: "VA" }))).toBe(
      `<ram:ID schemeID="VA">X</ram:ID>`,
    );
  });
});

describe('serializeEmailIdentifier — force schemeID="EM"', () => {
  it("force EM si absent", () => {
    expect(renderElement(serializeEmailIdentifier("URIID", { value: "x@example.com" }))).toBe(
      `<ram:URIID schemeID="EM">x@example.com</ram:URIID>`,
    );
  });
});
