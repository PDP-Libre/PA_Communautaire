import { describe, expect, it } from "vitest";

import type { CrossIndustryInvoice } from "@factur-e/factur-x-model";

import { FacturXCodeError } from "../../src/constants/index.js";
import { generateCII } from "../../src/generate-cii.js";
import { validateCascade } from "../../src/schematron/validate-cascade.js";

import { minimalInvoice } from "../integration/fixtures.js";

/**
 * Finding K1 — INCOTERM BT-X-22 (ApplicableTradeDeliveryTerms/DeliveryTypeCode),
 * whitelist 13 codes FR EXTENDED-CTC-FR (BR-FREXT-CL-27).
 *
 * Vérifie surtout l'ORDRE XSD : `ApplicableTradeDeliveryTerms` se place après
 * les `*TradeParty` et avant les `*ReferencedDocument` — une position erronée
 * (ex. "dernier enfant") produirait un fatal XSD.
 */

function withIncoterm(incoterm: string): CrossIndustryInvoice {
  return {
    ...minimalInvoice,
    tradeTransaction: {
      ...minimalInvoice.tradeTransaction,
      tradeAgreement: {
        ...minimalInvoice.tradeTransaction.tradeAgreement,
        // Ajout d'une référence de commande pour exercer l'ordre relatif
        // DeliveryTerms (avant) ↔ SellerOrderReferencedDocument (après).
        sellerOrderReference: "PO-XSD-ORDER",
        incoterm,
      },
    },
  };
}

describe("finding K1 — INCOTERM BT-X-22", () => {
  it("incoterm EXW → DeliveryTypeCode sérialisé, AVANT SellerOrderReferencedDocument", () => {
    const xml = generateCII(withIncoterm("EXW"));
    expect(xml).toContain("<ram:ApplicableTradeDeliveryTerms>");
    expect(xml).toContain("<ram:DeliveryTypeCode>EXW</ram:DeliveryTypeCode>");
    // Ordre XSD : DeliveryTerms avant la référence de commande.
    expect(xml.indexOf("ApplicableTradeDeliveryTerms")).toBeLessThan(
      xml.indexOf("SellerOrderReferencedDocument"),
    );
  });

  it("incoterm absent → pas d'ApplicableTradeDeliveryTerms", () => {
    const xml = generateCII(minimalInvoice);
    expect(xml).not.toContain("ApplicableTradeDeliveryTerms");
  });

  it("incoterm hors whitelist FR → FacturXCodeError", () => {
    expect(() => generateCII(withIncoterm("ZZZ"))).toThrow(FacturXCodeError);
  });

  it("incoterm DDP → XML valide XSD + pas de nouveau fatal Schematron FR", async () => {
    const base = await validateCascade(generateCII(minimalInvoice), "extended-ctc-fr");
    const withInc = await validateCascade(generateCII(withIncoterm("DDP")), "extended-ctc-fr");
    const fatals = (r: typeof base): string[] =>
      r.steps.filter((s) => s.status === "fatal").map((s) => s.step);
    // XSD doit rester ok (l'ordre des éléments est correct).
    expect(withInc.steps.find((s) => s.step === "xsd")?.status).toBe("ok");
    expect(fatals(withInc)).toEqual(fatals(base));
  });
});
