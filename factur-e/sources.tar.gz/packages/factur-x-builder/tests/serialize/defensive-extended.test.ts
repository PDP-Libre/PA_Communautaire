// Tests des helpers de sérialisation enrichis (sprint-06 T-CL-FACTURX-BUILDER-
// REFACTOR-CTC-FR) : 6 défensifs anti-empty Flux 2 + 3 EXTENDED-CTC-FR.

import type { SellerTaxRepresentativeParty, AttachedBinaryObject } from "@factur-e/factur-x-model";
import { SCHEME_IDS } from "@factur-e/factur-x-model";
import { describe, expect, it } from "vitest";

import { FacturXCodeError } from "../../src/constants/index.js";
import {
  buildAdditionalReferencedDocument,
  buildApplicableProductCharacteristic,
  buildAttachmentDocument,
  buildDeliveryTermsIncoterm,
  buildIncludedNote,
  buildLineSubtype,
  buildPayeeTradeParty,
  buildSellerTaxRepresentativeTradeParty,
  buildSpecifiedLogisticsServiceCharge,
} from "../../src/index.js";

import { minimalInvoice } from "../integration/fixtures.js";

const sellerParty = minimalInvoice.tradeTransaction.tradeAgreement.sellerTradeParty;

const taxRep: SellerTaxRepresentativeParty = {
  name: "Représentant Fiscal FR",
  postalAddress: { countryCode: "FR", cityName: "Paris" },
  vatID: { value: "FR99999999999", schemeID: SCHEME_IDS.VAT },
};

const pdf: AttachedBinaryObject = {
  content: new Uint8Array([0x25, 0x50, 0x44, 0x46]),
  filename: "facture-lisible.pdf",
  mimeCode: "application/pdf",
};

describe("buildIncludedNote (BR-FR-05/06) — défensif", () => {
  it("retourne un IncludedNote si content + subjectCode présents", () => {
    const n = buildIncludedNote("Conditions de paiement", "PMT");
    expect(n?.name).toBe("IncludedNote");
    expect(n?.children?.[0]?.name).toBe("Content");
    expect(n?.children?.[1]?.name).toBe("SubjectCode");
    expect(n?.children?.[1]?.text).toBe("PMT");
  });

  it("retourne undefined si content OU subjectCode vide", () => {
    expect(buildIncludedNote("", "PMT")).toBeUndefined();
    expect(buildIncludedNote("texte", "")).toBeUndefined();
    expect(buildIncludedNote("texte", undefined)).toBeUndefined();
    expect(buildIncludedNote("   ", "PMT")).toBeUndefined();
  });
});

describe("buildApplicableProductCharacteristic (BR-FR-27/28) — défensif", () => {
  it("retourne le bloc si name + value présents", () => {
    const n = buildApplicableProductCharacteristic("Couleur", "Bleu");
    expect(n?.name).toBe("ApplicableProductCharacteristic");
    expect(n?.children?.map((c) => c.name)).toEqual(["Description", "Value"]);
  });

  it("retourne undefined si name OU value vide", () => {
    expect(buildApplicableProductCharacteristic("", "Bleu")).toBeUndefined();
    expect(buildApplicableProductCharacteristic("Couleur", "")).toBeUndefined();
  });
});

describe("buildLineSubtype (EXTENDED LineStatusReasonCode)", () => {
  it("undefined pour absent ou DETAIL (défaut implicite)", () => {
    expect(buildLineSubtype(undefined)).toBeUndefined();
    expect(buildLineSubtype("DETAIL")).toBeUndefined();
  });

  it("émet LineStatusReasonCode pour GROUP / INFORMATION", () => {
    expect(buildLineSubtype("GROUP")?.name).toBe("LineStatusReasonCode");
    expect(buildLineSubtype("GROUP")?.text).toBe("GROUP");
    expect(buildLineSubtype("INFORMATION")?.text).toBe("INFORMATION");
  });

  it("lève sur valeur hors énumération", () => {
    expect(() => buildLineSubtype("SUMMARY")).toThrow(/EXTENDED-CTC-FR/);
  });
});

describe("buildAdditionalReferencedDocument (BR-FR-17/18) — défensif", () => {
  it("retourne undefined si name vide", () => {
    expect(buildAdditionalReferencedDocument("", "916")).toBeUndefined();
  });

  it("valide la liste fermée BR-FR-17 pour TypeCode 916", () => {
    const n = buildAdditionalReferencedDocument("LISIBLE", "916");
    expect(n?.name).toBe("AdditionalReferencedDocument");
    expect(() => buildAdditionalReferencedDocument("FACTURE", "916")).toThrow(FacturXCodeError);
  });

  it("n'applique pas la liste fermée pour un autre TypeCode (ex. 50)", () => {
    expect(buildAdditionalReferencedDocument("Bon de commande libre", "50")?.name).toBe(
      "AdditionalReferencedDocument",
    );
  });
});

describe("buildAttachmentDocument (BR-FR-17/18 + BR-FREXT-CL-24) — défensif", () => {
  it("undefined si pas de binaire", () => {
    expect(buildAttachmentDocument(undefined)).toBeUndefined();
  });

  it("émet un AdditionalReferencedDocument TypeCode 916 avec binaire", () => {
    const n = buildAttachmentDocument(pdf, "LISIBLE");
    expect(n?.name).toBe("AdditionalReferencedDocument");
    const childNames = n?.children?.map((c) => c.name) ?? [];
    expect(childNames).toContain("TypeCode");
    expect(childNames).toContain("AttachmentBinaryObject");
  });
});

describe("buildPayeeTradeParty / buildSellerTaxRepresentativeTradeParty — défensifs", () => {
  it("retournent undefined si la BG est absente", () => {
    expect(buildPayeeTradeParty(undefined)).toBeUndefined();
    expect(buildSellerTaxRepresentativeTradeParty(undefined)).toBeUndefined();
  });

  it("délèguent aux sérialiseurs existants si présents", () => {
    expect(buildPayeeTradeParty(sellerParty)?.name).toBe("PayeeTradeParty");
    expect(buildSellerTaxRepresentativeTradeParty(taxRep)?.name).toBe(
      "SellerTaxRepresentativeTradeParty",
    );
  });
});

describe("buildDeliveryTermsIncoterm (BR-FREXT-CL-27)", () => {
  it("undefined si absent", () => {
    expect(buildDeliveryTermsIncoterm(undefined)).toBeUndefined();
  });

  it("émet ApplicableTradeDeliveryTerms/DeliveryTypeCode pour un incoterm whitelisté", () => {
    const n = buildDeliveryTermsIncoterm("FCA");
    expect(n?.name).toBe("ApplicableTradeDeliveryTerms");
    expect(n?.children?.[0]?.name).toBe("DeliveryTypeCode");
    expect(n?.children?.[0]?.text).toBe("FCA");
  });

  it("lève sur incoterm hors whitelist (ex. DAT)", () => {
    expect(() => buildDeliveryTermsIncoterm("DAT")).toThrow(FacturXCodeError);
  });
});

describe("buildSpecifiedLogisticsServiceCharge (BT-X-272)", () => {
  it("tableau vide si aucune charge", () => {
    expect(buildSpecifiedLogisticsServiceCharge(undefined)).toEqual([]);
    expect(buildSpecifiedLogisticsServiceCharge([])).toEqual([]);
  });

  it("émet SpecifiedLogisticsServiceCharge avec AppliedAmount + AppliedTradeTax", () => {
    const nodes = buildSpecifiedLogisticsServiceCharge([
      { description: "Transport", appliedAmount: 15, vatCategoryCode: "S", vatRate: 20 },
    ]);
    expect(nodes).toHaveLength(1);
    expect(nodes[0]?.name).toBe("SpecifiedLogisticsServiceCharge");
    const childNames = nodes[0]?.children?.map((c) => c.name) ?? [];
    expect(childNames).toEqual(["Description", "AppliedAmount", "AppliedTradeTax"]);
  });
});
