import { describe, expect, it } from "vitest";

import type { CrossIndustryInvoice } from "@factur-e/factur-x-model";
import { VAT_CATEGORY_CODES } from "@factur-e/factur-x-model";

import { generateCII } from "../../src/generate-cii.js";

import { minimalInvoice } from "../integration/fixtures.js";

/**
 * Finding I — remise globale BG-20 (`SpecifiedTradeAllowanceCharge` document).
 *
 * Vérifie que le sérialiseur émet BT-93 `BasisAmount` + BT-94 `CalculationPercent`
 * + BT-92 `ActualAmount` dans l'ordre XSD (TradeAllowanceChargeType) quand le
 * modèle les porte — ce qui est désormais le cas en mode pourcentage (le montant
 * est dérivé serveur + BasisAmount renseigné, cf. `buildDocumentLevelAllowance`).
 */

/** Facture minimale + remise globale 10 % (base 1000, montant dérivé 100). */
const withDocAllowance: CrossIndustryInvoice = {
  ...minimalInvoice,
  tradeTransaction: {
    ...minimalInvoice.tradeTransaction,
    tradeSettlement: {
      ...minimalInvoice.tradeTransaction.tradeSettlement,
      documentAllowances: [
        {
          isCharge: false,
          actualAmount: 100,
          basisAmount: 1000,
          calculationPercent: 10,
          taxCategoryCode: VAT_CATEGORY_CODES.STANDARD,
          taxPercent: 20,
          reason: "Remise commerciale 10 %",
        },
      ],
    },
  },
};

describe("finding I — BG-20 remise globale (SpecifiedTradeAllowanceCharge)", () => {
  it("mode % → CalculationPercent + BasisAmount + ActualAmount sérialisés", () => {
    const xml = generateCII(withDocAllowance);
    expect(xml).toContain("<ram:SpecifiedTradeAllowanceCharge>");
    expect(xml).toContain("<ram:CalculationPercent>10.00</ram:CalculationPercent>");
    expect(xml).toContain("<ram:BasisAmount>1000.00</ram:BasisAmount>");
    expect(xml).toContain("<ram:ActualAmount>100.00</ram:ActualAmount>");
  });

  it("ordre XSD : CalculationPercent < BasisAmount < ActualAmount < CategoryTradeTax", () => {
    const xml = generateCII(withDocAllowance);
    // Scoper au bloc allowance : `BasisAmount` apparaît aussi dans le
    // VATBreakdown (ApplicableTradeTax) émis plus haut dans le settlement.
    const block = xml.slice(
      xml.indexOf("<ram:SpecifiedTradeAllowanceCharge>"),
      xml.indexOf("</ram:SpecifiedTradeAllowanceCharge>"),
    );
    const iPercent = block.indexOf("CalculationPercent");
    const iBasis = block.indexOf("BasisAmount");
    const iActual = block.indexOf("ActualAmount");
    const iCatTax = block.indexOf("CategoryTradeTax");
    expect(iPercent).toBeLessThan(iBasis);
    expect(iBasis).toBeLessThan(iActual);
    expect(iActual).toBeLessThan(iCatTax);
  });

  it("CategoryTradeTax rattache la remise au bucket TVA S 20 %", () => {
    const xml = generateCII(withDocAllowance);
    expect(xml).toContain("<ram:CategoryCode>S</ram:CategoryCode>");
    expect(xml).toContain("<ram:RateApplicablePercent>20.00</ram:RateApplicablePercent>");
  });
});
