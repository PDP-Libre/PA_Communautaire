import { describe, expect, it } from "vitest";
import { formatAmount, formatPercent, formatQuantity } from "../../src/serialize/format.js";

describe("formatAmount — 2 décimales POSIX", () => {
  it("12 → 12.00", () => {
    expect(formatAmount(12)).toBe("12.00");
  });
  it("12.345 → 12.35 (arrondi banker JS standard `toFixed`)", () => {
    expect(formatAmount(12.345)).toBe("12.35");
  });
  it("0 → 0.00", () => {
    expect(formatAmount(0)).toBe("0.00");
  });
  it("nombres négatifs", () => {
    expect(formatAmount(-1.5)).toBe("-1.50");
  });
});

describe("formatPercent — 2 décimales POSIX", () => {
  it("20 → 20.00", () => {
    expect(formatPercent(20)).toBe("20.00");
  });
  it("0.5 → 0.50", () => {
    expect(formatPercent(0.5)).toBe("0.50");
  });
});

describe("formatQuantity — 4 décimales POSIX", () => {
  it("3 → 3.0000", () => {
    expect(formatQuantity(3)).toBe("3.0000");
  });
  it("1.23456 → 1.2346", () => {
    expect(formatQuantity(1.23456)).toBe("1.2346");
  });
});
