import { describe, expect, it } from "vitest";

import type { PdfBlock, PdfTableBlock } from "../../src/pdf-assembly/html-to-pdf-blocks.js";
import { paginateBlocks } from "../../src/pdf-assembly/pagination.js";

function textBlock(name: string, n = 1): PdfBlock {
  return {
    kind: "text",
    name,
    lines: Array.from({ length: n }, (_, i) => ({
      text: `${name}-${String(i)}`,
      bold: false,
      italic: false,
      align: "left",
    })),
  };
}

function linesTable(rowCount: number): PdfTableBlock {
  return {
    kind: "table",
    name: "lines",
    columns: [
      { header: "Libellé", align: "left" },
      { header: "Total HT", align: "right" },
    ],
    rows: Array.from({ length: rowCount }, (_, i) => [
      { segments: [`Ligne ${String(i)}`], align: "left" as const },
      { segments: [`${String(i)},00 €`], align: "right" as const },
    ]),
  };
}

function doc(rowCount: number): PdfBlock[] {
  return [
    textBlock("header", 4),
    textBlock("title", 2),
    linesTable(rowCount),
    textBlock("totals", 6),
  ];
}

/** Total des lignes de table à travers toutes les pages. */
function totalTableRows(pages: PdfBlock[][]): number {
  return pages.reduce(
    (sum, page) =>
      sum +
      page
        .filter((b): b is PdfTableBlock => b.kind === "table")
        .reduce((s, t) => s + t.rows.length, 0),
    0,
  );
}

describe("paginateBlocks", () => {
  it("facture courte (5 lignes) tient sur une seule page", () => {
    const pages = paginateBlocks(doc(5));
    expect(pages).toHaveLength(1);
    expect(totalTableRows(pages)).toBe(5);
  });

  it("facture longue déborde sur plusieurs pages", () => {
    const pages = paginateBlocks(doc(120));
    expect(pages.length).toBeGreaterThan(1);
  });

  it("aucune ligne perdue lors du découpage (50 lignes)", () => {
    expect(totalTableRows(paginateBlocks(doc(50)))).toBe(50);
  });

  it("aucune ligne perdue (200 lignes, ≥3 pages)", () => {
    const pages = paginateBlocks(doc(200));
    expect(pages.length).toBeGreaterThanOrEqual(3);
    expect(totalTableRows(pages)).toBe(200);
  });

  it("en-tête (header + title) répété en tête de chaque page", () => {
    const pages = paginateBlocks(doc(120));
    expect(pages.length).toBeGreaterThan(1);
    for (const page of pages) {
      expect(page[0]?.name).toBe("header");
      expect(page[1]?.name).toBe("title");
    }
  });

  it("retourne au moins une page même sans bloc de flux", () => {
    expect(paginateBlocks([textBlock("header")])).toHaveLength(1);
  });

  it("pas de saut de page prématuré : un contenu qui tient dans le budget plein reste sur 1 page", () => {
    // ~36 lignes : hauteur entre l'ancien budget amputé de la réserve logo
    // (LAYOUT.logoHeight) et le budget plein. L'ancienne réserve provoquait un
    // 2ᵉ page à moitié vide (recette fx-380-adv-riche, T-CL-PDF-MOTEUR-V2).
    const pages = paginateBlocks(doc(36));
    expect(pages).toHaveLength(1);
    expect(totalTableRows(pages)).toBe(36);
  });
});
