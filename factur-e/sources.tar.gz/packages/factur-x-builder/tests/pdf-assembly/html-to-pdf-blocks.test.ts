import { describe, expect, it } from "vitest";

import {
  parseHtmlToBlocks,
  type PdfTableBlock,
  type PdfTextBlock,
} from "../../src/pdf-assembly/html-to-pdf-blocks.js";

describe("parseHtmlToBlocks — parser HTML intermédiaire → blocs typés", () => {
  it("extrait un bloc texte avec attributs bold/size/align", () => {
    const html = `
      <section data-block="title">
        <p data-bold data-size="16">Facture FA-1</p>
        <p data-align="right">Date d'émission : 15/04/2026</p>
      </section>`;
    const blocks = parseHtmlToBlocks(html);
    expect(blocks).toHaveLength(1);
    const block = blocks[0] as PdfTextBlock;
    expect(block.kind).toBe("text");
    expect(block.name).toBe("title");
    expect(block.lines[0]).toMatchObject({
      text: "Facture FA-1",
      bold: true,
      size: 16,
      align: "left",
    });
    expect(block.lines[1]).toMatchObject({ text: "Date d'émission : 15/04/2026", align: "right" });
  });

  it("conserve l'ordre des blocs", () => {
    const html = `
      <section data-block="header"><p>A</p></section>
      <section data-block="buyer"><p>B</p></section>
      <section data-block="totals"><p>C</p></section>`;
    expect(parseHtmlToBlocks(html).map((b) => b.name)).toEqual(["header", "buyer", "totals"]);
  });

  it("parse une table avec en-têtes + lignes + alignements", () => {
    const html = `
      <section data-block="lines">
        <table>
          <thead><tr><th data-align="left">Libellé</th><th data-align="right">Total HT</th></tr></thead>
          <tbody>
            <tr><td data-align="left">Prestation</td><td data-align="right">1 000,00 €</td></tr>
            <tr><td data-align="left">Frais</td><td data-align="right">500,00 €</td></tr>
          </tbody>
        </table>
      </section>`;
    const block = parseHtmlToBlocks(html)[0] as PdfTableBlock;
    expect(block.kind).toBe("table");
    expect(block.columns).toEqual([
      { header: "Libellé", align: "left" },
      { header: "Total HT", align: "right" },
    ]);
    expect(block.rows).toHaveLength(2);
    expect(block.rows[0]?.[0]).toMatchObject({ segments: ["Prestation"], align: "left" });
    expect(block.rows[0]?.[1]?.segments).toEqual(["1 000,00 €"]);
  });

  it("découpe une cellule multi-segments sur <br> (description / remise)", () => {
    const html = `
      <section data-block="lines">
        <table><thead><tr><th data-align="left">Libellé</th></tr></thead>
        <tbody><tr><td data-align="left">Audit<br>Revue mensuelle<br>Remise : 50,00 €</td></tr></tbody></table>
      </section>`;
    const block = parseHtmlToBlocks(html)[0] as PdfTableBlock;
    expect(block.rows[0]?.[0]?.segments).toEqual(["Audit", "Revue mensuelle", "Remise : 50,00 €"]);
  });

  it("dé-échappe les entités HTML injectées par autoescape", () => {
    const html = `<section data-block="header"><p>R&amp;D &lt;Service&gt; d&#39;audit</p></section>`;
    const block = parseHtmlToBlocks(html)[0] as PdfTextBlock;
    expect(block.lines[0]?.text).toBe("R&D <Service> d'audit");
  });

  it("ignore les blocs vides (sections sans <p> ni table)", () => {
    const html = `<section data-block="notes">  </section><section data-block="header"><p>X</p></section>`;
    expect(parseHtmlToBlocks(html).map((b) => b.name)).toEqual(["header"]);
  });

  it("aligne par défaut à gauche si data-align absent", () => {
    const block = parseHtmlToBlocks(
      `<section data-block="h"><p>X</p></section>`,
    )[0] as PdfTextBlock;
    expect(block.lines[0]?.align).toBe("left");
  });
});
