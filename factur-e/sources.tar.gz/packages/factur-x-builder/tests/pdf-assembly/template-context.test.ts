import { describe, expect, it } from "vitest";

import {
  buildTemplateContext,
  templateNameFor,
  type PdfEnrichment,
} from "../../src/pdf-assembly/template-context.js";
import { extendedSampleInvoice } from "../../samples/extended-ctc-fr-sample-001.input.js";

const ENRICHMENT: PdfEnrichment = {
  seller: {
    rcs: "Paris B 000 000 002",
    juridiqueLabel: "Société par actions simplifiée (SAS)",
    capitalSocial: "50000.00",
  },
};

describe("buildTemplateContext — mapping CII → contexte", () => {
  it("mappe l'en-tête document (BT-3 / numéro / dates)", () => {
    const ctx = buildTemplateContext(extendedSampleInvoice);
    expect(ctx.documentTypeCode).toBe("380");
    expect(ctx.invoiceNumber).toBe("FA-2026-EXT-001");
    expect(ctx.issueDate).toBe("20260415");
    expect(ctx.dueDate).toBe("20260531");
  });

  it("mappe le vendeur + enrichissement BDD (RCS / juridique / capital)", () => {
    const ctx = buildTemplateContext(extendedSampleInvoice, ENRICHMENT);
    expect(ctx.seller.name).toBe("Burger Queen");
    expect(ctx.seller.siren).toBe("000000002");
    expect(ctx.seller.vatNumber).toBe("FR00000000002");
    expect(ctx.seller.addressLines).toContain("10 avenue des Champs-Élysées");
    expect(ctx.seller.rcs).toBe("Paris B 000 000 002");
    expect(ctx.seller.juridiqueLabel).toBe("Société par actions simplifiée (SAS)");
    expect(ctx.seller.capitalSocial).toBe("50000.00");
  });

  it("capital social absent si non fourni (EI sans capital — défensif)", () => {
    const ctx = buildTemplateContext(extendedSampleInvoice);
    expect(ctx.seller.capitalSocial).toBeUndefined();
    expect(ctx.seller.rcs).toBeUndefined();
  });

  it("mappe l'acheteur (BG-7/BG-8)", () => {
    const ctx = buildTemplateContext(extendedSampleInvoice);
    expect(ctx.buyer.name).toBe("Tricatel");
    expect(ctx.buyer.siren).toBe("000000001");
    expect(ctx.buyer.addressLines.length).toBeGreaterThan(0);
  });

  it("mappe les lignes (BT-153/129/146/131/152 + unité courte)", () => {
    const ctx = buildTemplateContext(extendedSampleInvoice);
    expect(ctx.lines).toHaveLength(2);
    const first = ctx.lines[0];
    expect(first?.label).toBe("Audit conformité — forfait mensuel");
    expect(first?.description).toBe("Revue mensuelle des dépôts.");
    expect(first?.quantity).toBe(6);
    expect(first?.unitLabel).toBe("mois"); // MON → "mois"
    expect(first?.unitPriceHt).toBe(1500);
    expect(first?.lineNetAmount).toBe(9000);
    expect(first?.vatRatePercent).toBe(20);
  });

  it("mappe les totaux (BT-109/110/112/115) + ventilation TVA", () => {
    const ctx = buildTemplateContext(extendedSampleInvoice);
    expect(ctx.totals.totalHt).toBe(9500);
    expect(ctx.totals.vatTotal).toBe(1900);
    expect(ctx.totals.grandTotal).toBe(11400);
    expect(ctx.totals.duePayable).toBe(11400.5);
    expect(ctx.totals.vatBreakdowns).toHaveLength(1);
    expect(ctx.totals.vatBreakdowns[0]?.ratePercent).toBe(20);
  });

  it("mappe le paiement (IBAN/BIC/conditions/échéance)", () => {
    const ctx = buildTemplateContext(extendedSampleInvoice);
    expect(ctx.payment?.iban).toBe("FR7630006000011234567890189");
    expect(ctx.payment?.bic).toBe("AGRIFRPP");
    expect(ctx.payment?.methodLabel).toBe("Virement"); // typeCode 30
    expect(ctx.payment?.paymentTerms).toBe("Paiement à 30 jours fin de mois.");
  });

  it("résout la facture précédente BG-3", () => {
    const ctx = buildTemplateContext(extendedSampleInvoice);
    expect(ctx.precedingInvoice?.number).toBe("FA-2026-EXT-000");
    expect(ctx.precedingInvoice?.issueDate).toBe("20260315");
  });

  it("trie les notes en 3 zones : LME / note publique / mentions de pied", () => {
    const ctx = buildTemplateContext(extendedSampleInvoice);
    // Le sample porte 3 notes BR-FR-05 (PMT/PMD/AAB) + 1 note TAX_INFO (TXD).
    expect(ctx.legalMentions).toHaveLength(3); // PMT/PMD/AAB
    expect(ctx.notes).toHaveLength(0); // aucune note sans subjectCode
    expect(ctx.footerMentions).toHaveLength(1); // TXD (mention de pied)
    expect(ctx.footerMentions[0]?.content).toContain("TVA acquittée sur les débits");
  });

  it("note publique (sans subjectCode) → bucket notes ; REG → mentions de pied", () => {
    const withNotes = structuredClone(extendedSampleInvoice);
    withNotes.exchangedDocument.includedNotes = [
      { content: "Merci de régler sous 30 jours." }, // sans code → note publique
      { content: "Membre d'une association agréée.", subjectCode: "REG" },
      ...(withNotes.exchangedDocument.includedNotes ?? []),
    ];
    const ctx = buildTemplateContext(withNotes);
    expect(ctx.notes.map((n) => n.content)).toEqual(["Merci de régler sous 30 jours."]);
    expect(ctx.footerMentions.map((n) => n.content)).toContain("Membre d'une association agréée.");
  });

  it("Livraison : INCOTERM (enrichissement) + date BT-72 + adresse BG-15", () => {
    const ctx = buildTemplateContext(extendedSampleInvoice, { incoterm: "DAP" });
    expect(ctx.delivery?.incotermLabel).toBe("DAP — Rendu au lieu de destination");
    expect(ctx.delivery?.date).toBe("20260415"); // BT-72 du sample
    expect(ctx.delivery?.addressLines?.length).toBeGreaterThan(0);
  });

  it("Livraison sans INCOTERM : date + adresse présentes (pre-fix K1)", () => {
    const ctx = buildTemplateContext(extendedSampleInvoice);
    expect(ctx.delivery?.incotermLabel).toBeUndefined();
    expect(ctx.delivery?.date).toBe("20260415");
  });

  it("Devise BT-5 + base TVA BT-116 + représentant fiscal + bénéficiaire BG-10", () => {
    const ctx = buildTemplateContext(extendedSampleInvoice);
    expect(ctx.currency).toBe("EUR");
    expect(ctx.totals.vatBreakdowns[0]?.basisAmount).toBe(9500);
    expect(ctx.taxRepresentative?.name).toBe("Cabinet Représentant Fiscal SAS");
    expect(ctx.payee?.name).toBe("Société de Factoring SA");
    expect(ctx.payment?.reference).toBe("FA-2026-EXT-001");
  });

  it("hasLogo reflète la présence du logo enrichi", () => {
    const withLogo = buildTemplateContext(extendedSampleInvoice, {
      logo: { bytes: new Uint8Array([1, 2, 3]), format: "png" },
    });
    expect(withLogo.hasLogo).toBe(true);
    expect(buildTemplateContext(extendedSampleInvoice).hasLogo).toBe(false);
  });
});

describe("templateNameFor — choix du template selon BT-3", () => {
  it("380 → invoice-default.njk", () => {
    expect(templateNameFor("380")).toBe("invoice-default.njk");
  });
  it("381 → credit-note.njk", () => {
    expect(templateNameFor("381")).toBe("credit-note.njk");
  });
  it("384 → corrective-invoice.njk", () => {
    expect(templateNameFor("384")).toBe("corrective-invoice.njk");
  });
  it("type inconnu → invoice-default.njk (fallback)", () => {
    expect(templateNameFor("999")).toBe("invoice-default.njk");
  });
});
