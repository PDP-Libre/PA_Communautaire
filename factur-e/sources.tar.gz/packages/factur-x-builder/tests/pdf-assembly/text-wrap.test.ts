// F2 (recette sprint-07) — wrap font-aware des blocs texte pleine largeur :
// la mention LME PMD complète DOIT être découpée en plusieurs lignes au lieu
// d'être tronquée (`fitText` clip single-line). Oracle déterministe via la font
// de mesure réelle (mêmes métriques que le dessin).

import { describe, expect, it } from "vitest";

import { createMeasureFont } from "../../src/pdf-assembly/font.js";
import type { PdfBlock } from "../../src/pdf-assembly/html-to-pdf-blocks.js";
import { LAYOUT } from "../../src/pdf-assembly/pagination.js";
import { wrapText, wrapTextBlocks } from "../../src/pdf-assembly/text-wrap.js";

const FULL_WIDTH = LAYOUT.pageWidth - 2 * LAYOUT.marginX;
const SIZE = 8; // taille des mentions légales (data-size="8")

// Mention PMD AFNOR complète (oracle F2 anti-troncature).
const PMD_MENTION =
  "Pénalités de retard : trois fois le taux d'intérêt légal en vigueur, exigibles " +
  "sans rappel dès le lendemain de la date d'échéance, conformément aux articles " +
  "L.441-10 et D.441-5 du Code de commerce.";

describe("wrapText — retour-ligne aux espaces", () => {
  it("texte court → une seule ligne", async () => {
    const font = await createMeasureFont();
    expect(wrapText(font, "Total HT : 800,00 €", SIZE, FULL_WIDTH)).toEqual([
      "Total HT : 800,00 €",
    ]);
  });

  it("PMD complète → 2 lignes ou plus, chacune ≤ largeur utile (anti-troncature)", async () => {
    const font = await createMeasureFont();
    const lines = wrapText(font, PMD_MENTION, SIZE, FULL_WIDTH);
    expect(lines.length).toBeGreaterThanOrEqual(2);
    for (const line of lines) {
      expect(font.widthOfTextAtSize(line, SIZE)).toBeLessThanOrEqual(FULL_WIDTH);
    }
    // Aucune perte : les mots concaténés reconstituent la mention d'origine.
    expect(lines.join(" ")).toBe(PMD_MENTION);
  });

  it("mot unique plus large que la largeur → conservé tel quel (fitText tronquera)", async () => {
    const font = await createMeasureFont();
    const longWord = "X".repeat(500);
    expect(wrapText(font, longWord, SIZE, FULL_WIDTH)).toEqual([longWord]);
  });
});

describe("wrapTextBlocks — applique le wrap aux blocs texte, ignore les tables", () => {
  it("éclate une ligne débordante en N lignes (align/size/bold préservés)", async () => {
    const font = await createMeasureFont();
    const blocks: PdfBlock[] = [
      {
        kind: "text",
        name: "lme_mentions",
        lines: [{ text: PMD_MENTION, bold: false, italic: true, size: SIZE, align: "left" }],
      },
    ];
    const [wrapped] = wrapTextBlocks(blocks, font);
    if (wrapped?.kind !== "text") throw new Error("bloc texte attendu");
    expect(wrapped.lines.length).toBeGreaterThanOrEqual(2);
    expect(wrapped.lines.every((l) => l.italic && l.align === "left" && l.size === SIZE)).toBe(
      true,
    );
  });

  it("bloc table retourné inchangé (cellules hors scope F2)", async () => {
    const font = await createMeasureFont();
    const table: PdfBlock = {
      kind: "table",
      name: "lines",
      columns: [{ header: "Libellé", align: "left" }],
      rows: [[{ segments: ["Prestation"], align: "left" }]],
    };
    expect(wrapTextBlocks([table], font)).toEqual([table]);
  });
});
