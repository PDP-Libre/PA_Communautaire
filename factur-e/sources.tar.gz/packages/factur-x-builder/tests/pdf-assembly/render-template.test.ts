import { describe, expect, it } from "vitest";

import {
  NBSP,
  formatAmountFr,
  formatDateFr,
  formatVatRateFr,
  renderInvoiceTemplate,
  resetTemplateEnv,
} from "../../src/pdf-assembly/render-template.js";
import type { PdfTemplateContext } from "../../src/pdf-assembly/template-context.js";

/** Contexte minimal valide pour exercer le rendu des templates. */
function baseContext(overrides: Partial<PdfTemplateContext> = {}): PdfTemplateContext {
  return {
    documentTypeCode: "380",
    invoiceNumber: "FA-2026-001",
    issueDate: "20260415",
    dueDate: "20260531",
    currency: "EUR",
    seller: {
      name: "Mon Entreprise SAS",
      addressLines: ["10 rue de Paris", "75008 Paris"],
      siren: "123456789",
      vatNumber: "FR12345678900",
      rcs: "Paris B 123 456 789",
      juridiqueLabel: "Société par actions simplifiée (SAS)",
      capitalSocial: "50000.00",
    },
    buyer: { name: "Client SARL", addressLines: ["1 rue du Client", "75011 Paris"] },
    hasLogo: false,
    lines: [
      {
        label: "Prestation",
        quantity: 1,
        unitLabel: "forfait",
        unitPriceHt: 1000,
        lineNetAmount: 1000,
        vatRatePercent: 20,
      },
    ],
    totals: {
      totalHt: 1000,
      vatBreakdowns: [
        { ratePercent: 20, basisAmount: 1000, calculatedAmount: 200, categoryCode: "S" },
      ],
      vatTotal: 200,
      grandTotal: 1200,
      duePayable: 1200,
    },
    legalMentions: [{ content: "Pénalités de retard : 3 fois le taux d'intérêt légal." }],
    notes: [],
    ...overrides,
  };
}

describe("filtres Nunjucks custom FR (ZG-B9)", () => {
  it("format_date_fr — YYYYMMDD → JJ/MM/YYYY", () => {
    expect(formatDateFr("20260415")).toBe("15/04/2026");
    expect(formatDateFr("20261231")).toBe("31/12/2026");
  });

  it("format_date_fr — valeur invalide renvoyée brute", () => {
    expect(formatDateFr("2026")).toBe("2026");
    expect(formatDateFr(undefined)).toBe("");
  });

  it("format_amount_fr — séparateur milliers fin + virgule décimale", () => {
    expect(formatAmountFr(9500)).toBe(`9${NBSP}500,00`);
    expect(formatAmountFr(1234567.5)).toBe(`1${NBSP}234${NBSP}567,50`);
    expect(formatAmountFr(12)).toBe("12,00");
  });

  it("format_amount_fr — accepte les chaînes (capital_social numeric→text)", () => {
    expect(formatAmountFr("50000.00")).toBe(`50${NBSP}000,00`);
  });

  it("format_amount_fr — montant négatif", () => {
    expect(formatAmountFr(-1234.5)).toBe(`-1${NBSP}234,50`);
  });

  it("format_vat_rate — entier / décimal / zéro", () => {
    expect(formatVatRateFr(20)).toBe("20 %");
    expect(formatVatRateFr(5.5)).toBe("5,5 %");
    expect(formatVatRateFr(0)).toBe("0 %");
  });
});

describe("renderInvoiceTemplate", () => {
  it("rend invoice-default.njk (380) — titre Facture + sections clés", () => {
    resetTemplateEnv();
    const html = renderInvoiceTemplate(
      baseContext() as unknown as Record<string, unknown>,
      "invoice-default.njk",
    );
    expect(html).toContain('data-block="header"');
    expect(html).toContain("Facture FA-2026-001");
    expect(html).toContain("Mon Entreprise SAS");
    expect(html).toContain("SIREN 123456789");
    expect(html).toContain("Capital social : 50");
    expect(html).toContain("Date d'émission : "); // texte littéral du template (non autoescapé)
    expect(html).toContain('data-block="lines"');
    expect(html).toContain("Total TTC : 1");
  });

  it("rend credit-note.njk (381) — titre Avoir + référence BG-3 verbatim", () => {
    const ctx = baseContext({
      documentTypeCode: "381",
      precedingInvoice: { number: "FA-2026-000", issueDate: "20260315" },
    });
    const html = renderInvoiceTemplate(
      ctx as unknown as Record<string, unknown>,
      "credit-note.njk",
    );
    expect(html).toContain("Avoir FA-2026-001");
    expect(html).toContain('data-block="linked_invoice"');
    expect(html).toContain("Avoir de la facture FA-2026-000 du 15/03/2026");
  });

  it("rend corrective-invoice.njk (384) — titre Rectificative + référence BG-3", () => {
    const ctx = baseContext({
      documentTypeCode: "384",
      precedingInvoice: { number: "FA-2026-000", issueDate: "20260315" },
    });
    const html = renderInvoiceTemplate(
      ctx as unknown as Record<string, unknown>,
      "corrective-invoice.njk",
    );
    expect(html).toContain("Facture rectificative FA-2026-001");
    expect(html).toContain("Rectificative de la facture FA-2026-000 du 15/03/2026");
  });

  it("héritage base-document — sections communes présentes dans un enfant", () => {
    const ctx = baseContext({ documentTypeCode: "381" });
    const html = renderInvoiceTemplate(
      ctx as unknown as Record<string, unknown>,
      "credit-note.njk",
    );
    // En-tête + lignes + totaux + LME héritées de base-document.njk.
    expect(html).toContain('data-block="header"');
    expect(html).toContain('data-block="totals"');
    expect(html).toContain('data-block="lme_mentions"');
  });

  it("sections conditionnelles défensives — payment/delivery/notes/payee absents", () => {
    const ctx = baseContext({
      payment: undefined,
      delivery: undefined,
      notes: [],
      payee: undefined,
    });
    const html = renderInvoiceTemplate(
      ctx as unknown as Record<string, unknown>,
      "invoice-default.njk",
    );
    expect(html).not.toContain('data-block="payment"');
    expect(html).not.toContain('data-block="delivery"');
    expect(html).not.toContain('data-block="payee"');
    expect(html).not.toContain('data-block="notes"');
  });

  it("section Livraison/INCOTERM rendue si présente (post-fix K1)", () => {
    const ctx = baseContext({
      delivery: {
        incotermLabel: "DAP — Rendu au lieu de destination",
        date: "20260415",
        addressLines: ["Zone Fret", "75011 Paris"],
      },
    });
    const html = renderInvoiceTemplate(
      ctx as unknown as Record<string, unknown>,
      "invoice-default.njk",
    );
    expect(html).toContain('data-block="delivery"');
    expect(html).toContain("DAP — Rendu au lieu de destination");
    expect(html).toContain("Date de livraison : 15/04/2026");
  });

  it("Devise BT-5 (Minimum) + base TVA BT-116 rendues", () => {
    const html = renderInvoiceTemplate(
      baseContext() as unknown as Record<string, unknown>,
      "invoice-default.njk",
    );
    expect(html).toContain("Devise : EUR");
    expect(html).toContain("TVA 20 % sur 1");
  });

  it("template absent → lève une erreur", () => {
    expect(() =>
      renderInvoiceTemplate(
        baseContext() as unknown as Record<string, unknown>,
        "does-not-exist.njk",
      ),
    ).toThrow();
  });
});
