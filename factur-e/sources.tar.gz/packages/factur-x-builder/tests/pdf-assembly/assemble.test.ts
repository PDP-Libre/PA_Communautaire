import { PDFDocument } from "pdf-lib";
import { describe, expect, it } from "vitest";

import { assembleFacturXPdfA3, type PdfRenderContent } from "../../src/pdf-assembly/assemble.js";
import type { PdfBlock, PdfTableBlock } from "../../src/pdf-assembly/html-to-pdf-blocks.js";
import { structuralChecks } from "../../src/pdf-validation/structural-check.js";

const SAMPLE_XML = `<?xml version="1.0" encoding="UTF-8"?>
<rsm:CrossIndustryInvoice
    xmlns:rsm="urn:un:unece:uncefact:data:standard:CrossIndustryInvoice:100">
    <rsm:ExchangedDocument><ram:ID>FA-TEST-001</ram:ID></rsm:ExchangedDocument>
</rsm:CrossIndustryInvoice>`;

async function buildSamplePdf(): Promise<Uint8Array> {
  return assembleFacturXPdfA3({
    xmlBytes: new TextEncoder().encode(SAMPLE_XML),
    metadata: {
      invoiceNumber: "FA-TEST-001",
      sellerName: "Mon Entreprise SAS",
    },
    conformanceLevel: "EXTENDED",
    generationDate: new Date("2026-04-15T10:00:00Z"),
  });
}

describe("assembleFacturXPdfA3", () => {
  it("produit un PDF non vide", async () => {
    const pdf = await buildSamplePdf();
    expect(pdf.byteLength).toBeGreaterThan(1000);
  });

  it("commence par la signature %PDF-1.x", async () => {
    const pdf = await buildSamplePdf();
    const head = Buffer.from(pdf.slice(0, 8)).toString("latin1");
    expect(head).toMatch(/^%PDF-1\.[4-7]/);
  });

  it("passe tous les checks structurels (fallback veraPDF)", async () => {
    const pdf = await buildSamplePdf();
    const results = structuralChecks(pdf);
    const failed = results.filter((r) => !r.ok);
    if (failed.length > 0) {
      throw new Error(
        `Structural checks failed:\n${failed.map((r) => `  ✗ ${r.name}${r.details === undefined ? "" : ` — ${r.details}`}`).join("\n")}`,
      );
    }
    expect(failed).toHaveLength(0);
  });

  it("embarque le XML CII sous le nom factur-x.xml", async () => {
    const pdf = await buildSamplePdf();
    const raw = Buffer.from(pdf).toString("latin1");
    expect(raw).toContain("factur-x.xml");
  });

  it("déclare le namespace Factur-X dans le XMP", async () => {
    const pdf = await buildSamplePdf();
    const raw = Buffer.from(pdf).toString("latin1");
    expect(raw).toContain("urn:factur-x:pdfa:CrossIndustryDocument:invoice:1p0#");
    expect(raw).toContain("INVOICE");
    expect(raw).toContain("EN 16931");
  });

  it("est déterministe pour une même date de génération", async () => {
    // pdf-lib expose un peu de hasard (object stream order). On compare
    // ici les marqueurs structurels — le déterminisme byte-identique total
    // n'est pas garanti par pdf-lib v1.x ; documenté en [DEBT] dans la trace.
    const pdf1 = await buildSamplePdf();
    const pdf2 = await buildSamplePdf();
    const xmp1 = Buffer.from(pdf1).toString("latin1");
    const xmp2 = Buffer.from(pdf2).toString("latin1");
    const start1 = xmp1.indexOf("<?xpacket begin=");
    const start2 = xmp2.indexOf("<?xpacket begin=");
    expect(start1).toBeGreaterThan(0);
    expect(start2).toBeGreaterThan(0);
    // Même contenu XMP (chaîne déterministe construite par xmp.ts).
    const end1 = xmp1.indexOf('<?xpacket end="w"?>', start1);
    const end2 = xmp2.indexOf('<?xpacket end="w"?>', start2);
    expect(xmp1.slice(start1, end1)).toBe(xmp2.slice(start2, end2));
  });

  it("conserve une page visuelle avec le numéro de facture", async () => {
    const pdf = await buildSamplePdf();
    const raw = Buffer.from(pdf).toString("latin1");
    expect(raw).toContain("FA-TEST-001");
  });
});

// ── Chemin moteur de template (`content`) — Axe B sprint-07 V2 ──────────────

function textBlock(name: string, lines: { text: string; size?: number }[]): PdfBlock {
  return {
    kind: "text",
    name,
    lines: lines.map((l) => ({
      text: l.text,
      bold: false,
      italic: false,
      size: l.size,
      align: "left",
    })),
  };
}

function bigTable(rows: number): PdfTableBlock {
  return {
    kind: "table",
    name: "lines",
    columns: [
      { header: "Libellé", align: "left" },
      { header: "Total HT", align: "right" },
    ],
    rows: Array.from({ length: rows }, (_, i) => [
      { segments: [`Ligne ${String(i)}`], align: "left" as const },
      { segments: [`${String(i)},00 €`], align: "right" as const },
    ]),
  };
}

async function assembleWithContent(content: PdfRenderContent): Promise<Uint8Array> {
  return assembleFacturXPdfA3({
    xmlBytes: new TextEncoder().encode(SAMPLE_XML),
    metadata: { invoiceNumber: "FA-TEST-001", sellerName: "Mon Entreprise SAS" },
    conformanceLevel: "EXTENDED",
    generationDate: new Date("2026-04-15T10:00:00Z"),
    content,
  });
}

describe("assembleFacturXPdfA3 — rendu moteur de template (content)", () => {
  const sections = [
    textBlock("header", [{ text: "Burger Queen", size: 11 }, { text: "SIREN 000000002" }]),
    textBlock("title", [{ text: "Facture FA-TEST-001", size: 16 }]),
    textBlock("buyer", [{ text: "Client" }, { text: "Tricatel" }]),
    bigTable(2),
    textBlock("totals", [{ text: "Total TTC : 11 400,00 €" }]),
    textBlock("lme_mentions", [{ text: "Pénalités de retard : 3 fois le taux légal", size: 8 }]),
  ];

  it("passe les checks structurels (veraPDF subset) avec contenu rendu", async () => {
    const pdf = await assembleWithContent({ pages: [sections] });
    const failed = structuralChecks(pdf).filter((r) => !r.ok);
    expect(failed).toHaveLength(0);
  });

  it("préserve le XMP fx: et le factur-x.xml embarqué", async () => {
    const pdf = await assembleWithContent({ pages: [sections] });
    const raw = Buffer.from(pdf).toString("latin1");
    expect(raw).toContain("urn:factur-x:pdfa:CrossIndustryDocument:invoice:1p0#");
    expect(raw).toContain("EXTENDED");
    expect(raw).toContain("factur-x.xml");
  });

  it("dessine une page par entrée de pagination (multi-page)", async () => {
    const pdf = await assembleWithContent({ pages: [sections, sections, sections] });
    const doc = await PDFDocument.load(pdf);
    expect(doc.getPageCount()).toBe(3);
  });

  it("contenu vide → fallback page stub (rétro-compat, 1 page)", async () => {
    const pdf = await assembleWithContent({ pages: [] });
    const doc = await PDFDocument.load(pdf);
    expect(doc.getPageCount()).toBe(1);
  });

  it("PDF rendu plus volumineux que le stub minimal (contenu réel)", async () => {
    const stub = await assembleFacturXPdfA3({
      xmlBytes: new TextEncoder().encode(SAMPLE_XML),
      metadata: { invoiceNumber: "FA-TEST-001", sellerName: "X" },
      conformanceLevel: "EXTENDED",
      generationDate: new Date("2026-04-15T10:00:00Z"),
    });
    const rendered = await assembleWithContent({ pages: [sections] });
    expect(rendered.byteLength).toBeGreaterThan(stub.byteLength);
  });
});
