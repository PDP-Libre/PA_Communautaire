import { describe, expect, it } from "vitest";
import {
  ram,
  qdt,
  renderDocument,
  renderElement,
  rsm,
  udt,
  type XMLNode,
} from "../../src/xml/index.js";

describe("renderElement — self-closing", () => {
  it("rend un élément vide en `<.../>`", () => {
    expect(renderElement(ram("Empty"))).toBe("<ram:Empty/>");
  });

  it("self-closing même avec attributs", () => {
    expect(renderElement(ram("WithAttr", { attributes: { schemeID: "VA" } }))).toBe(
      `<ram:WithAttr schemeID="VA"/>`,
    );
  });
});

describe("renderElement — texte", () => {
  it("rend un nœud avec texte sur une ligne", () => {
    expect(renderElement(ram("ID", { text: "FA-001" }))).toBe("<ram:ID>FA-001</ram:ID>");
  });

  it("échappe le texte (caractères XML)", () => {
    expect(renderElement(ram("Note", { text: `< & > " '` }))).toBe(
      "<ram:Note>&lt; &amp; &gt; &quot; &apos;</ram:Note>",
    );
  });

  it("échappe les attributs", () => {
    expect(renderElement(ram("X", { attributes: { v: `< & "` }, text: "y" }))).toBe(
      `<ram:X v="&lt; &amp; &quot;">y</ram:X>`,
    );
  });
});

describe("renderElement — enfants + indentation", () => {
  it("indente les enfants de 4 espaces par niveau", () => {
    const node: XMLNode = ram("Outer", {
      children: [ram("A", { text: "1" }), ram("B", { text: "2" })],
    });
    expect(renderElement(node)).toBe(
      ["<ram:Outer>", "    <ram:A>1</ram:A>", "    <ram:B>2</ram:B>", "</ram:Outer>"].join("\n"),
    );
  });

  it("indente correctement à 3 niveaux d'imbrication", () => {
    const node: XMLNode = ram("L1", {
      children: [
        ram("L2", {
          children: [ram("L3", { text: "x" })],
        }),
      ],
    });
    expect(renderElement(node)).toBe(
      ["<ram:L1>", "    <ram:L2>", "        <ram:L3>x</ram:L3>", "    </ram:L2>", "</ram:L1>"].join(
        "\n",
      ),
    );
  });
});

describe("renderElement — tri alphabétique des attributs", () => {
  it("ordonne les attributs par clé pour déterminisme", () => {
    const node = ram("X", {
      attributes: { z: "3", a: "1", m: "2" },
      text: "v",
    });
    expect(renderElement(node)).toBe(`<ram:X a="1" m="2" z="3">v</ram:X>`);
  });
});

describe("renderElement — préfixes ram/rsm/udt/qdt", () => {
  it("respecte chaque préfixe", () => {
    expect(renderElement(rsm("Root"))).toBe("<rsm:Root/>");
    expect(renderElement(ram("X"))).toBe("<ram:X/>");
    expect(renderElement(udt("D", { text: "20260415", attributes: { format: "102" } }))).toBe(
      `<udt:D format="102">20260415</udt:D>`,
    );
    expect(renderElement(qdt("D", { text: "20260415", attributes: { format: "102" } }))).toBe(
      `<qdt:D format="102">20260415</qdt:D>`,
    );
  });
});

describe("renderDocument — racine + déclaration + namespaces triés", () => {
  it("ajoute la déclaration XML et les namespaces sur la racine", () => {
    const out = renderDocument(rsm("CrossIndustryInvoice"));
    expect(out).toBe(
      [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<rsm:CrossIndustryInvoice xmlns:qdt="urn:un:unece:uncefact:data:standard:QualifiedDataType:100" xmlns:ram="urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:100" xmlns:rsm="urn:un:unece:uncefact:data:standard:CrossIndustryInvoice:100" xmlns:udt="urn:un:unece:uncefact:data:standard:UnqualifiedDataType:100"/>',
      ].join("\n"),
    );
  });

  it("les enfants ne re-déclarent pas les namespaces", () => {
    const out = renderDocument(
      rsm("CrossIndustryInvoice", {
        children: [rsm("ExchangedDocumentContext", { children: [] })],
      }),
    );
    expect(out).toContain("xmlns:rsm=");
    // Le child ne doit pas avoir un xmlns:
    expect(out).not.toMatch(/<rsm:ExchangedDocumentContext\s+xmlns:/);
  });
});

describe("Déterminisme byte-identique (ADR-003 §Déterminisme)", () => {
  it("rend deux fois le même nœud à l'identique", () => {
    const node = ram("X", {
      attributes: { b: "2", a: "1" },
      children: [ram("Inner", { text: "v" })],
    });
    expect(renderElement(node)).toBe(renderElement(node));
  });

  it("rend dix fois le même document à l'identique", () => {
    const doc: XMLNode = rsm("Root", {
      children: [
        ram("X", { text: "v", attributes: { a: "1" } }),
        ram("Y", { children: [udt("Z", { text: "z" })] }),
      ],
    });
    const first = renderDocument(doc);
    for (let i = 0; i < 10; i += 1) {
      expect(renderDocument(doc)).toBe(first);
    }
  });
});
