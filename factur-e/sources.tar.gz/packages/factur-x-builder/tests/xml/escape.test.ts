import { describe, expect, it } from "vitest";
import { escapeXML } from "../../src/xml/escape.js";

describe("escapeXML — ordre `& < > \" '`", () => {
  it("échappe l'esperluette en premier (sinon double-échappement)", () => {
    expect(escapeXML("&")).toBe("&amp;");
    expect(escapeXML("&amp;")).toBe("&amp;amp;");
  });

  it("échappe les 5 caractères XML standards", () => {
    expect(escapeXML("<")).toBe("&lt;");
    expect(escapeXML(">")).toBe("&gt;");
    expect(escapeXML('"')).toBe("&quot;");
    expect(escapeXML("'")).toBe("&apos;");
  });

  it("échappe une chaîne contenant tous les caractères en une passe", () => {
    expect(escapeXML(`< & > " '`)).toBe("&lt; &amp; &gt; &quot; &apos;");
  });

  it("ne touche pas aux caractères Unicode hors ASCII (UTF-8 préservé)", () => {
    expect(escapeXML("Société Tröllëtt — €1 234,56")).toBe("Société Tröllëtt — €1 234,56");
  });

  it("retourne la chaîne vide telle quelle", () => {
    expect(escapeXML("")).toBe("");
  });
});
