// Benchmark : 100 validations consécutives de la fixture EXTENDED.
// Cible plan.md : < 10 ms par validation (post cold-start).

import { readFile } from "node:fs/promises";

import { FIXTURE_PATH } from "./extract-fixture.js";
import { resetSchemaCache, validateExtendedXsd } from "./validate-extended.js";

const ITER = 100;

function format(ns: bigint): string {
  return `${(Number(ns) / 1_000_000).toFixed(2)} ms`;
}

async function main(): Promise<void> {
  const xml = await readFile(FIXTURE_PATH, "utf-8");

  // Cold start : recompile + valide une fois.
  resetSchemaCache();
  const coldStart = process.hrtime.bigint();
  await validateExtendedXsd(xml);
  const coldElapsed = process.hrtime.bigint() - coldStart;

  // Warm runs.
  const samples: bigint[] = [];
  for (let i = 0; i < ITER; i += 1) {
    const t0 = process.hrtime.bigint();
    const r = await validateExtendedXsd(xml);
    const t1 = process.hrtime.bigint();
    if (!r.ok) {
      throw new Error(
        `Iteration ${String(i)} failed XSD validation: ${r.errors[0]?.message ?? "?"}`,
      );
    }
    samples.push(t1 - t0);
  }

  samples.sort((a, b) => (a < b ? -1 : a > b ? 1 : 0));
  const min = samples[0] ?? 0n;
  const max = samples[ITER - 1] ?? 0n;
  const median = samples[Math.floor(ITER / 2)] ?? 0n;
  const total = samples.reduce<bigint>((acc, n) => acc + n, 0n);
  const mean = total / BigInt(ITER);

  process.stdout.write(`[bench] cold start (compile+validate): ${format(coldElapsed)}\n`);
  process.stdout.write(`[bench] warm validations (n=${String(ITER)})\n`);
  process.stdout.write(`        min    : ${format(min)}\n`);
  process.stdout.write(`        median : ${format(median)}\n`);
  process.stdout.write(`        mean   : ${format(mean)}\n`);
  process.stdout.write(`        max    : ${format(max)}\n`);

  const meanMs = Number(mean) / 1_000_000;
  if (meanMs > 10) {
    process.stdout.write(
      `[bench] [QUESTION] mean ${meanMs.toFixed(2)} ms > 10 ms cible. Réviser cache, préchauffe ou worker.\n`,
    );
  } else {
    process.stdout.write(`[bench] OK — mean ${meanMs.toFixed(2)} ms < 10 ms cible.\n`);
  }
}

main().catch((e: unknown) => {
  process.stderr.write(`${String(e)}\n`);
  process.exit(1);
});
