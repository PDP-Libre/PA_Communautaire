// Extrait le `factur-x.xml` embarqué dans un PDF de référence FNFE-MPE
// (`docs/external/factur-x-1.07.3/examples/EXTENDED/*.pdf`) et le sauve
// dans `tests/fixtures/extended-reference.xml`.
//
// pdf-lib n'expose pas d'API haut-niveau pour relire les EmbeddedFiles.
// Approche : on parcourt tous les objets indirects à la recherche d'un
// `PDFRawStream` dont le dictionnaire `/Subtype = /text#2Fxml` (PDF
// hex-name encoding de `text/xml`) ou dont le nom de fichier associé
// est `factur-x.xml`. On inflate ensuite le flux Flate.

import { mkdir, readFile, writeFile } from "node:fs/promises";
import { inflateSync } from "node:zlib";
import { fileURLToPath } from "node:url";
import path from "node:path";

import { PDFDocument, PDFName, PDFRawStream } from "pdf-lib";

const HERE = path.dirname(fileURLToPath(import.meta.url));
// HERE = .../packages/factur-x-builder/spikes/xsd → 4× ".." pour atteindre la racine du worktree.
const REPO_ROOT = path.resolve(HERE, "..", "..", "..", "..");
const PDF_PATH = path.join(
  REPO_ROOT,
  "docs/external/factur-x-1.07.3/examples/EXTENDED",
  "Facture_F20220023-LE_FOURNISSEUR-POUR-LE_CLIENT_EXTENDED.pdf",
);
const FIXTURE_PATH = path.join(HERE, "fixtures", "extended-reference.xml");

function dictHasSubtypeXml(stream: PDFRawStream): boolean {
  const subtype = stream.dict.lookup(PDFName.of("Subtype"));
  if (subtype === undefined) return false;
  // PDFName toString() rend par exemple "/text#2Fxml" ou "/text/xml" selon pdf-lib version.
  const s = subtype.toString();
  return /text\/xml|text#2Fxml/i.test(s);
}

function decodeIfFlate(stream: PDFRawStream): Uint8Array {
  const filter = stream.dict.lookup(PDFName.of("Filter"));
  const filterStr = filter === undefined ? "" : filter.toString();
  const raw = stream.contents;
  if (filterStr.includes("FlateDecode")) {
    return new Uint8Array(inflateSync(Buffer.from(raw)));
  }
  return raw;
}

export async function extractFacturXml(pdfPath: string): Promise<Uint8Array> {
  const pdfBytes = await readFile(pdfPath);
  const pdfDoc = await PDFDocument.load(pdfBytes, {
    throwOnInvalidObject: false,
  });
  const indirectObjects = pdfDoc.context.enumerateIndirectObjects();
  for (const [, obj] of indirectObjects) {
    if (!(obj instanceof PDFRawStream)) continue;
    if (!dictHasSubtypeXml(obj)) continue;
    const decoded = decodeIfFlate(obj);
    // Sanity check : commence par une déclaration XML CrossIndustryInvoice ?
    const head = new TextDecoder().decode(decoded.slice(0, 200));
    if (head.includes("CrossIndustryInvoice") || head.includes("<?xml")) {
      return decoded;
    }
  }
  throw new Error(
    `factur-x.xml introuvable dans ${pdfPath} (aucun flux PDFRawStream avec /Subtype /text/xml).`,
  );
}

async function main(): Promise<void> {
  const arg = process.argv[2] ?? PDF_PATH;
  const xml = await extractFacturXml(arg);
  await mkdir(path.dirname(FIXTURE_PATH), { recursive: true });
  await writeFile(FIXTURE_PATH, xml);
  process.stdout.write(
    `[extract-fixture] ${String(xml.byteLength)} bytes written to ${FIXTURE_PATH}\n`,
  );
}

const invokedDirectly =
  process.argv[1] !== undefined && import.meta.url === `file://${process.argv[1]}`;
if (invokedDirectly) {
  main().catch((e: unknown) => {
    process.stderr.write(`${String(e)}\n`);
    process.exit(1);
  });
}

export { FIXTURE_PATH, PDF_PATH };
