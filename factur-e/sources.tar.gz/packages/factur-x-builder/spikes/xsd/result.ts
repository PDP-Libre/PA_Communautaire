// Type Result<T, E> autonome pour le spike — duplique celui de
// `@factur-e/factur-x-model` pour garder le spike indépendant.
// T-CL-06 décidera s'il faut consommer le Result du modèle ou garder un type local.

export type Result<T, E> = { ok: true; value: T } | { ok: false; errors: E[] };

export function ok<T>(value: T): { ok: true; value: T } {
  return { ok: true, value };
}

export function err<E>(errors: E[]): { ok: false; errors: E[] } {
  return { ok: false, errors };
}
