import { readFile } from "node:fs/promises";
import path from "node:path";

import { afterAll, beforeAll, describe, expect, it } from "vitest";

import { extractFacturXml, FIXTURE_PATH, PDF_PATH } from "../extract-fixture.js";
import { validateExtendedXsd } from "../validate-extended.js";

let fixtureXml = "";

async function ensureFixture(): Promise<void> {
  try {
    fixtureXml = await readFile(FIXTURE_PATH, "utf-8");
  } catch {
    // Première exécution : extraire la fixture du PDF de référence.
    const bytes = await extractFacturXml(PDF_PATH);
    const { writeFile, mkdir } = await import("node:fs/promises");
    await mkdir(path.dirname(FIXTURE_PATH), { recursive: true });
    await writeFile(FIXTURE_PATH, bytes);
    fixtureXml = new TextDecoder().decode(bytes);
  }
}

beforeAll(async () => {
  await ensureFixture();
});

describe("validateExtendedXsd — happy paths", () => {
  it("valide la fixture extraite du PDF FNFE-MPE Factur_F20220023", async () => {
    const result = await validateExtendedXsd(fixtureXml);
    if (!result.ok) {
      throw new Error(
        `Expected XSD ok, got ${String(result.errors.length)} errors:\n${result.errors
          .slice(0, 5)
          .map((e) => `  L${String(e.line)} ${e.message.trim()}`)
          .join("\n")}`,
      );
    }
    expect(result.value).toBe(true);
  });
});

describe("validateExtendedXsd — détection d'erreur XSD exploitable", () => {
  it("détecte un ordre XSD violé (BuyerOrderReferencedDocument avant SellerTradeParty)", async () => {
    // CII impose un ordre strict dans HeaderTradeAgreement :
    //   BuyerReference → SellerTradeParty → BuyerTradeParty → ... → BuyerOrderReferencedDocument
    // Inverser SellerTradeParty et BuyerOrderReferencedDocument doit casser la grammaire.
    // (Le test "ordre" est plus représentatif des bugs §9.4 que la suppression d'un champ optionnel XSD.)
    const broken = fixtureXml.replace(
      /(<ram:SellerTradeParty>[\s\S]*?<\/ram:SellerTradeParty>)([\s\S]*?)(<ram:BuyerOrderReferencedDocument>[\s\S]*?<\/ram:BuyerOrderReferencedDocument>)/,
      "$3$2$1",
    );
    if (broken === fixtureXml) {
      // Si la fixture ne contient pas BuyerOrderReferencedDocument, fallback :
      // on force un attribut interdit sur l'élément racine.
      const altBroken = fixtureXml.replace(
        "<rsm:CrossIndustryInvoice",
        '<rsm:CrossIndustryInvoice illegalAttr="x"',
      );
      const result = await validateExtendedXsd(altBroken);
      expect(result.ok).toBe(false);
      if (result.ok) throw new Error("expected fail");
      expect(result.errors[0]?.message.length ?? 0).toBeGreaterThan(10);
      return;
    }
    const result = await validateExtendedXsd(broken);
    expect(result.ok).toBe(false);
    if (result.ok) throw new Error("expected fail");
    expect(result.errors.length).toBeGreaterThan(0);
    expect(result.errors[0]?.message.length ?? 0).toBeGreaterThan(10);
  });

  it("détecte un élément racine inattendu", async () => {
    const garbage = '<?xml version="1.0"?><Foo/>';
    const result = await validateExtendedXsd(garbage);
    expect(result.ok).toBe(false);
    if (result.ok) throw new Error("expected fail");
    expect(result.errors[0]?.message).toMatch(/element|root|Foo/i);
  });
});

describe("validateExtendedXsd — API Result discriminée", () => {
  it("retourne { ok: true, value: true } sur succès", async () => {
    const result = await validateExtendedXsd(fixtureXml);
    if (!result.ok) throw new Error("expected ok");
    expect(result.value).toBe(true);
    // Compile-time check via expect.
    expect("errors" in result).toBe(false);
  });

  it("retourne { ok: false, errors: ValidationError[] } sur échec", async () => {
    const result = await validateExtendedXsd("<bad/>");
    if (result.ok) throw new Error("expected fail");
    expect(Array.isArray(result.errors)).toBe(true);
    const e = result.errors[0];
    if (e === undefined) throw new Error("no error");
    expect(typeof e.message).toBe("string");
    expect(typeof e.line).toBe("number");
  });
});

afterAll(() => {
  // pas de teardown — le cache schema est process-scoped.
});
