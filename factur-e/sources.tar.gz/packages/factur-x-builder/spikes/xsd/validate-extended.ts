// Validation XSD EXTENDED via libxmljs2 (libxml2 bindings).
//
// Charge en cache les XSD EXTENDED de `docs/external/factur-x-1.07.3/EXTENDED/`
// au premier appel. Le schéma compilé est conservé entre validations pour
// éviter le coût de recompilation (~50–200 ms) — c'est l'optimisation clé du
// spike pour atteindre la cible < 10 ms par validation.
//
// API : `validateExtendedXsd(xml: string) → Result<true, ValidationError[]>`.

import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import path from "node:path";

import libxmljs from "libxmljs2";

import { type Result, err, ok } from "./result.js";

const HERE = path.dirname(fileURLToPath(import.meta.url));
// HERE = .../packages/factur-x-builder/spikes/xsd → 4× ".." pour atteindre la racine du worktree.
const REPO_ROOT = path.resolve(HERE, "..", "..", "..", "..");
const XSD_DIR = path.resolve(REPO_ROOT, "docs/external/factur-x-1.07.3/EXTENDED");
const XSD_ENTRY = path.join(XSD_DIR, "Factur-X_1.07.3_EXTENDED.xsd");

export interface ValidationError {
  /** Message libxml2 brut. */
  message: string;
  /** Numéro de ligne dans le XML validé (1-based, 0 si non disponible). */
  line: number;
  /**
   * Colonne dans le XML (1-based) — libxmljs2 ne l'expose pas systématiquement,
   * dans ce cas on garde 0.
   */
  column: number;
  /** Code libxml (entier). */
  code?: number;
}

let cachedSchema: libxmljs.Document | null = null;

/**
 * Charge et compile le XSD EXTENDED — coûteux la première fois.
 * `baseUrl` est nécessaire pour résoudre les `xs:import` vers les XSD CII voisines.
 */
async function loadSchema(): Promise<libxmljs.Document> {
  if (cachedSchema !== null) return cachedSchema;
  const xsdBuffer = await readFile(XSD_ENTRY);
  // Le baseUrl est nécessaire pour que libxml2 résolve les xs:import relatifs.
  const baseUrl = `file://${XSD_DIR}/`;
  const xsdDoc = libxmljs.parseXml(xsdBuffer.toString("utf-8"), {
    baseUrl,
    nonet: false, // permet à libxml2 de charger les imports voisins (file://).
  });
  cachedSchema = xsdDoc;
  return xsdDoc;
}

/**
 * Valide un XML CII contre le XSD EXTENDED.
 *
 * Performance : le premier appel paye ~50–200 ms de chargement+compilation,
 * les suivants ~1–5 ms grâce au cache `cachedSchema`.
 */
export async function validateExtendedXsd(xml: string): Promise<Result<true, ValidationError>> {
  const xsdDoc = await loadSchema();
  const xmlDoc = libxmljs.parseXml(xml);
  const valid = xmlDoc.validate(xsdDoc);
  if (valid) return ok(true);
  const rawErrors = xmlDoc.validationErrors as readonly {
    message?: string;
    line?: number;
    column?: number;
    code?: number;
  }[];
  const errors: ValidationError[] = rawErrors.map((e) => ({
    message: e.message ?? "(unknown)",
    line: e.line ?? 0,
    column: e.column ?? 0,
    code: typeof e.code === "number" ? e.code : undefined,
  }));
  return err(errors);
}

/** Réinitialise le cache du schéma — utilisé en test pour mesurer le cold-start. */
export function resetSchemaCache(): void {
  cachedSchema = null;
}

export const XSD_PATH = XSD_ENTRY;
