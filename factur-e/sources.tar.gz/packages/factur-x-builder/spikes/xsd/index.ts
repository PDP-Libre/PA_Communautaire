// CLI : valide un XML CII contre le XSD EXTENDED.
//   pnpm --filter @factur-e/factur-x-builder spike:xsd <xml-path>
// Sans argument : valide la fixture extraite.

import { readFile } from "node:fs/promises";

import { FIXTURE_PATH } from "./extract-fixture.js";
import { validateExtendedXsd } from "./validate-extended.js";

async function main(): Promise<void> {
  const xmlPath = process.argv[2] ?? FIXTURE_PATH;
  const xml = await readFile(xmlPath, "utf-8");
  const result = await validateExtendedXsd(xml);
  if (result.ok) {
    process.stdout.write(`[spike:xsd] ✓ ${xmlPath} — XSD EXTENDED valid.\n`);
    return;
  }
  process.stdout.write(
    `[spike:xsd] ✗ ${xmlPath} — ${String(result.errors.length)} validation error(s) :\n`,
  );
  for (const e of result.errors) {
    process.stdout.write(
      `  line ${String(e.line)} col ${String(e.column)} : ${e.message.trim()}\n`,
    );
  }
  process.exit(1);
}

main().catch((e: unknown) => {
  process.stderr.write(`${String(e)}\n`);
  process.exit(1);
});
